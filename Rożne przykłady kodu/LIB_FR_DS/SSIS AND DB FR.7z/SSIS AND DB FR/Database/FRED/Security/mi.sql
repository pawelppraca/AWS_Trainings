﻿CREATE SCHEMA [mi]
    AUTHORIZATION [dbo];

GO
--GRANT EXECUTE
--   ON SCHEMA::[mi] TO [LM\ggs-lsm-finrisks-it-np];--change to prod

