﻿CREATE SCHEMA [FinancialRisks]
    AUTHORIZATION [dbo];

GO
--GRANT EXECUTE
--    ON SCHEMA::[FinancialRisks] TO [LM\ggs-lsm-finrisks-it-np];

