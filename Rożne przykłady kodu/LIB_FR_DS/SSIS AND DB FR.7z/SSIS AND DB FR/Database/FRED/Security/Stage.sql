﻿CREATE SCHEMA [stage]
    AUTHORIZATION [dbo];

GO
--GRANT EXECUTE
--   ON SCHEMA::[sources] TO [LM\ggs-lsm-finrisks-it-np];

