﻿CREATE TABLE [mi].[FRED_GFR] 
(
    [CobId]          INT              NOT NULL,
    [RiskID]         NVARCHAR (255)   NOT NULL,
    [Cedant]         NVARCHAR (3)     NOT NULL,
    [Data_Quarter]   INT              NOT NULL,
    [Year]           FLOAT            NOT NULL,
    [Assured]        NVARCHAR (MAX)   NOT NULL,
    [Risk_Code]      NVARCHAR (10)    NOT NULL,
    [Lead_Syndicate] NVARCHAR (1)     NOT NULL,
    [Country]        NVARCHAR (255)   NOT NULL,
    [Inception_Date] DATE             NOT NULL,
    [Expiry_Date]    DATE             NOT NULL,
    [Ccy]            NVARCHAR (3)     NOT NULL,
    [PolicyLimit]    NUMERIC(18,0)    NOT NULL,
    [USD_Limit]      INT              NOT NULL,
    [USD_NET_EPI]    INT              NOT NULL,
    [USD_Exposure]   NUMERIC (38, 12) NOT NULL,
    [Obligor]        NVARCHAR (max)   NOT NULL,
	[UploadDate]     DATETIME             NULL
);



















