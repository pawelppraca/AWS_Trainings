USE [msdb]
GO

/****** Object:  Job [FRED_CSMUpload']    Script Date: 9/29/2021 6:23:58 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
 ,@FOLDER_NAME VARCHAR(128) = 'FRED'
, @ENVREFERENCE VARCHAR(20) 
, @SERVER  VARCHAR(30) = @@SERVERNAME
, @MIGRATEDATA VARCHAR(300)
, @SSISOWNER VARCHAR(30)
, @PACKAGEEXECUTIONPROXY VARCHAR(30)

SELECT @SSISOWNER = CASE @SERVER
			        WHEN 'VMBID-GSQLDB01' THEN 'LM\sagsdAAP-SSIS' --change later
					WHEN 'VMBIT-GSQLDB01' THEN 'LM\sagstAAP-SSIS' --change later
					WHEN 'VMBIS-GSQLDB01' THEN 'LM\sagssAAP-SSIS' --change later
			        WHEN 'VMBIP-GSQLDB14' THEN 'LM\n0110252' --change later  LM\sagsp-FRED-SSIS
					END

SELECT @PACKAGEEXECUTIONPROXY = CASE @SERVER
					WHEN 'VMBID-GSQLDB01' THEN 'Pr-AAP-DEV-System' --change later
					WHEN 'VMBIT-GSQLDB01' THEN 'Pr-AAP-SIT-System'--change later
					WHEN 'VMBIS-GSQLDB01' THEN 'Pr-AAP-UAT-System'--change later
			        WHEN 'VMBIP-GSQLDB14' THEN 'PR-FRED-PRD-System'
					END


--JOB Commands for each step
SET @ENVREFERENCE = ( SELECT reference_id FROM ssisdb.CATALOG.environment_references WHERE environment_folder_name = @FOLDER_NAME )
SET  @MIGRATEDATA = N'/ISSERVER "\"\SSISDB\FRED\FRED\FREDMigrateData.dtsx\"" /SERVER "\"' + @SERVER + '\"" /ENVREFERENCE '+@ENVREFERENCE+' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'

/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 9/29/2021 6:23:59 AM ******/
--IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
--BEGIN
--EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
--IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

--END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = N'FRED_MigrateData')

BEGIN
	EXEC msdb.dbo.sp_delete_job @job_name=N'FRED_MigrateData', @delete_unused_schedule=1
END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'FRED_MigrateData', 
		@enabled=0, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Runs MigrateData SSIS package to migrate data from current prod server to new prod server', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=@SSISOWNER, 
		@notify_email_operator_name=N'SQLDBA', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ExecuteIdentifyMappingsPackage]    Script Date: 10/1/2021 10:28:24 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ExecuteMigrateDataPackage', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=@MIGRATEDATA,
		@database_name=N'master', 
		@flags=0,
		@proxy_name=@PACKAGEEXECUTIONPROXY
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


