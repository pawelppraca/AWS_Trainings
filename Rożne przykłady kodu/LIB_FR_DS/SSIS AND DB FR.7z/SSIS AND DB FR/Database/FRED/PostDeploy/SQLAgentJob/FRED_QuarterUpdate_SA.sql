USE [msdb]
GO


BEGIN TRANSACTION
DECLARE @ReturnCode INT
 ,@FOLDER_NAME VARCHAR(128) = 'FRED'
, @ENVREFERENCE VARCHAR(20) 
, @SERVER  VARCHAR(30) = @@SERVERNAME
, @IDENTIFYMAPPINGS VARCHAR(300)
, @CHECKFORFILES VARCHAR(300)
, @GFR VARCHAR(300)
, @GFRSOURCE VARCHAR(300)
, @Ironshore VARCHAR(300)
, @LMIEDIRECTSURETY VARCHAR(300)
, @PTC VARCHAR(300)
, @PECLINES VARCHAR(300)
, @SSISOWNER VARCHAR(30)
, @PACKAGEEXECUTIONPROXY VARCHAR(30)

SELECT @SSISOWNER = CASE @SERVER
			        WHEN 'VMBID-GSQLDB01' THEN 'LM\sagsd-FRED-SSIS' 
					WHEN 'VMBIT-GSQLDB01' THEN 'LM\sagst-FRED-SSIS' 
					WHEN 'VMBIS-GSQLDB01' THEN 'LM\sagss-FRED-SSIS' 
			        WHEN 'VMBIP-GSQLDB14' THEN 'LM\n0110252' --change later
					END

SELECT @PACKAGEEXECUTIONPROXY = CASE @SERVER
					WHEN 'VMBID-GSQLDB01' THEN 'PR-FRED-DEV-System' 
					WHEN 'VMBIT-GSQLDB01' THEN 'PR-FRED-SIT-System'
					WHEN 'VMBIS-GSQLDB01' THEN 'PR-FRED-UAT-System'
			        WHEN 'VMBIP-GSQLDB14' THEN 'PR-FRED-PRD-System'
					END


--JOB Commands for each step
SET @ENVREFERENCE = ( SELECT reference_id FROM ssisdb.CATALOG.environment_references WHERE environment_folder_name = @FOLDER_NAME )
SET @CHECKFORFILES =  N'/ISSERVER "\"\SSISDB\FRED\FRED\FileName.dtsx\"" /SERVER "\"' + @SERVER + '\"" /ENVREFERENCE '+@ENVREFERENCE+' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'
SET @GFRSOURCE =  N'/ISSERVER "\"\SSISDB\FRED\FRED\GetGFRSource.dtsx\"" /SERVER "\"' + @SERVER + '\"" /ENVREFERENCE '+@ENVREFERENCE+' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'
SET @GFR =  N'/ISSERVER "\"\SSISDB\FRED\FRED\GFR.dtsx\"" /SERVER "\"' + @SERVER + '\"" /ENVREFERENCE '+@ENVREFERENCE+' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'
SET @Ironshore=  N'/ISSERVER "\"\SSISDB\FRED\FRED\Ironshore.dtsx\"" /SERVER "\"' + @SERVER + '\"" /ENVREFERENCE '+@ENVREFERENCE+' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'
SET @LMIEDIRECTSURETY =  N'/ISSERVER "\"\SSISDB\FRED\FRED\LMIEDirectSurety.dtsx\"" /SERVER "\"' + @SERVER + '\"" /ENVREFERENCE '+@ENVREFERENCE+' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'
SET @PTC =  N'/ISSERVER "\"\SSISDB\FRED\FRED\PTC.dtsx\"" /SERVER "\"' + @SERVER + '\"" /ENVREFERENCE '+@ENVREFERENCE+' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'
SET @PECLINES =  N'/ISSERVER "\"\SSISDB\FRED\FRED\PECLines.dtsx\"" /SERVER "\"' + @SERVER + '\"" /ENVREFERENCE '+@ENVREFERENCE+' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'
SET @IDENTIFYMAPPINGS = N'/ISSERVER "\"\SSISDB\FRED\FRED\IdentifyMappings.dtsx\"" /SERVER "\"' + @SERVER + '\"" /ENVREFERENCE '+@ENVREFERENCE+' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'

/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 9/29/2021 6:23:59 AM ******/
--IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
--BEGIN
--EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
--IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

--END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = N'FRED_QuarterUpdate')

BEGIN
	EXEC msdb.dbo.sp_delete_job @job_name=N'FRED_QuarterUpdate', @delete_unused_schedule=1
END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'FRED_QuarterUpdate', 
		@enabled=0, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Run quarterly to get all data for FRED update', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=@SSISOWNER, 
		@notify_email_operator_name=N'SQLDBA', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CheckForFiles]    Script Date: 9/29/2021 6:24:00 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CheckForFiles', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=@CHECKFORFILES,
		@database_name=N'master', 
		@flags=0,
		@proxy_name=@PACKAGEEXECUTIONPROXY
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [GFR source]    Script Date: 9/29/2021 6:24:00 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'GFR Source', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=@GFRSOURCE,
		@database_name=N'master', 
		@flags=0,
		@proxy_name=@PACKAGEEXECUTIONPROXY
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [GFR]    Script Date: 9/29/2021 6:24:00 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'GFR', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=@GFR,
		@database_name=N'master', 
		@flags=0,
		@proxy_name=@PACKAGEEXECUTIONPROXY
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Ironshore]    Script Date: 9/29/2021 6:24:00 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Ironshore', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=@IRONSHORE,
		@database_name=N'master', 
		@flags=0,
		@proxy_name=@PACKAGEEXECUTIONPROXY
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [LMIEDirectSurety]    Script Date: 9/29/2021 6:24:00 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'LMIEDirectSurety', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=@LMIEDIRECTSURETY,
		@database_name=N'master', 
		@flags=0,
		@proxy_name=@PACKAGEEXECUTIONPROXY
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PTC]    Script Date: 9/29/2021 6:24:00 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PTC', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=@PTC,
		@database_name=N'master', 
		@flags=0,
		@proxy_name=@PACKAGEEXECUTIONPROXY
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PecLines]    Script Date: 9/29/2021 6:24:00 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PecLines', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=@PECLINES,
		@database_name=N'master', 
		@flags=0,
		@proxy_name=@PACKAGEEXECUTIONPROXY
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IdentifyMappings]    Script Date: 9/29/2021 6:24:01 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IdentifyMappings', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=@IDENTIFYMAPPINGS, 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=@PACKAGEEXECUTIONPROXY
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'FRED_QuarterUpdateSchedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=62, 
		@freq_subday_type=8, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20190311, 
		@active_end_date=99991231, 
		@active_start_time=90000, 
		@active_end_time=170000 
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


