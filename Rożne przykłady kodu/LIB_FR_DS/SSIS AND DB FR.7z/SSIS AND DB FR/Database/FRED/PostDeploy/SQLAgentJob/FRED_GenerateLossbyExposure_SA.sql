USE [msdb]
GO

BEGIN TRANSACTION
DECLARE @ReturnCode INT
, @SSISOWNER VARCHAR(30)
, @PACKAGEEXECUTIONPROXY VARCHAR(30)
, @SERVER  VARCHAR(30) = @@SERVERNAME

SELECT @SSISOWNER = CASE @SERVER
			        WHEN 'VMBID-GSQLDB01' THEN 'LM\sagsd-FRED-SSIS' 
					WHEN 'VMBIT-GSQLDB01' THEN 'LM\sagst-FRED-SSIS' 
					WHEN 'VMBIS-GSQLDB01' THEN 'LM\sagss-FRED-SSIS' 
			        WHEN 'VMBIP-GSQLDB14' THEN 'LM\n0110252' --change later
					END

SELECT @PACKAGEEXECUTIONPROXY = CASE @SERVER
					WHEN 'VMBID-GSQLDB01' THEN 'PR-FRED-DEV-System' 
					WHEN 'VMBIT-GSQLDB01' THEN 'PR-FRED-SIT-System'
					WHEN 'VMBIS-GSQLDB01' THEN 'PR-FRED-UAT-System'
			        WHEN 'VMBIP-GSQLDB14' THEN 'PR-FRED-PRD-System'
					END



/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 9/29/2021 6:23:59 AM ******/
--IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
--BEGIN
--EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
--IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

--END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = N'FRED_QuarterUpdate')

BEGIN
	EXEC msdb.dbo.sp_delete_job @job_name=N'FRED_GenerateLossByExposure', @delete_unused_schedule=1
END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'FRED_GenerateLossByExposure', 
		@enabled=0, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Runs Stored Procedure to populate LossByExposure', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=@SSISOWNER, 
		@notify_email_operator_name=N'SQLDBA', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ExecuteGenerateLossByExposureProcedure]    Script Date: 10/1/2021 9:02:26 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ExecuteGenerateLossByExposureProcedure', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC FinancialRisks.GenerateLossByExposure', 
		@database_name=N'FRED', 
		@flags=0
	
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'FREDGenerateLossByExposureSchedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20210928, 
		@active_end_date=99991231, 
		@active_start_time=200500, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


