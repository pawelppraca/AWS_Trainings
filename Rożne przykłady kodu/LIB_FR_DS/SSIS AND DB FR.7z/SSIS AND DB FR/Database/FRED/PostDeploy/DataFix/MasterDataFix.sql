﻿--Post Deploy master script
:r "testDatafix1.sql"
:r "testDatafix2.sql"
