use FRED 
go
truncate table   [FinancialRisks].[ExposuresQueue]