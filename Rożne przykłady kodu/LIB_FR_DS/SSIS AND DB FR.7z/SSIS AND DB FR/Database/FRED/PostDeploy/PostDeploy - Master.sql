﻿--Post Deploy master script
--:r ".\MetaData\SSISEnvVariables.sql"

