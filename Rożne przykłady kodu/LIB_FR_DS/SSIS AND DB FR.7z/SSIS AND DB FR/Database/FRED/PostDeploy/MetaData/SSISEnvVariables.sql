-- script to create SSIS environment variables in each of the environments
--general variables

DECLARE @ENVIRONMENT_VARIABLES TABLE (
  [name]        NVARCHAR(128)
, [value]       NVARCHAR(1024)
, [description] NVARCHAR(1024)
);

DECLARE 
 @FOLDER_NAME             NVARCHAR(128) = N'FRED'
,@PROJECT_NAME             NVARCHAR(128) = N'FRED'
,@FOLDER_ID               BIGINT
,@ENVIRONMENT_ID          INT -- maynot need
,@VARIABLE_NAME           NVARCHAR(128)
,@VARIABLE_VALUE          NVARCHAR(1024)
,@VARIABLE_DESCRIPTION    NVARCHAR(1024)
,@SOURCE_ENVIRONMENT_NAME NVARCHAR(128)
,@TARGET_ENVIRONMENT_NAME NVARCHAR(128)


-- Set sever specific variables

IF  @@SERVERNAME = 'VMBID-GSQLDB01' 
BEGIN

   SET @TARGET_ENVIRONMENT_NAME = N'DEV'
   SET @SOURCE_ENVIRONMENT_NAME = N'DEV'
   INSERT @ENVIRONMENT_VARIABLES
   SELECT [name], [value], [description]
     FROM (
     VALUES
       --
     -- PASTE the Environmental variables to create
     --
    ('ArchiveLocation','\\VMBID-GSQLDB01\FinancialRisk-Upload\Archive\','')
   ,('BDXEmail','Alistair.haddow@liberty-it.co.uk','')
   ,('BDXError','\\VMBID-GSQLDB01\FinancialRisk-Upload\PecLines','')
   ,('ClientMap','\\VMBID-GSQLDB01\FinancialRisk-Upload\PecLines\InitialLoad\Client_Map_template.xlsx','')
   ,('CompanySpreadsheet','\\VMBID-GSQLDB01\FinancialRisk-Upload\PecLines\InitialLoad\Company_Paper_template.xlsx','')
   ,('CorrectionsFileLocation','\\VMBID-GSQLDB01\FinancialRisk-Upload\Corrections\FRED_UpdateCorrections.xlsx','')
    ,('CSMModelFileLocation','\\VMBID-GSQLDB01\FinancialRisk-Upload\CSM\','')
   ,('DataAnalyticsDBName','Actuarial_Analytics','')
   ,('DataAnalyticsDBServer','VMBIT-GSQLDB01','')
   ,('FREDDBName','FRED','')
   ,('FREDDBServer','VMBID-GSQLDB01','')
   ,('EmailFrom','LSMDataAnalyticsDev@LibertyMutual.com','')
   ,('EmailTo','Alistair.haddow@liberty-it.co.uk','')
   ,('EmailToMapping','Alistair.haddow@liberty-it.co.uk','')
   ,('Ironshore','\\VMBID-GSQLDB01\FinancialRisk-Upload\Ironshore\Ironshore.xlsx','')
   ,('LMIEInput','\\VMBID-GSQLDB01\FinancialRisk-Upload\LMIE\LMIE.xlsx','')
   ,('PecLinesBorderauxFilesLocation','\\VMBID-GSQLDB01\FinancialRisk-Upload\PecLines\Borderaux Files','')
   ,('PecLinesProgramLiveFileLocation','\\VMBID-GSQLDB01\FinancialRisk-Upload\PecLines\Programme_Live.xlsx','')
   ,('PTCAccessDBFileLocation','D:\FinancialRisk-Upload\PTC\PTC.mdb','')
   ,('ReuploadLocation','\\VMBID-GSQLDB01\FinancialRisk-Upload\Reupload\Yes.txt','')
   ,('SMTPServer','smtprelay.lmig.com','')
   ,('TreatyReassignmentFileLocation','\\VMBID-GSQLDB01\FinancialRisk-Upload\PecLines\Reassignments\TreatyReassignments.xlsx','')
   ,('UnmappedCedantsInput','\\VMBID-GSQLDB01\FinancialRisk-Upload\Mappings\Input\Cedants\UnmappedCedants.xlsx','')
   ,('UnmappedCountriesInput','\\VMBID-GSQLDB01\FinancialRisk-Upload\Mappings\Input\Countries\UnmappedCountries.xlsx','')
   ,('UnmappedObligorsInput','\\VMBID-GSQLDB01\FinancialRisk-Upload\Mappings\Input\Obligors\UnmappedObligors.xlsx','')
   ,('UnmappedOutput','\\VMBID-GSQLDB01\FinancialRisk-Upload\Mappings\Output\','')
   ,('AsAtDateFile','\\VMBID-GSQLDB01\FinancialRisk-Upload\AsAtDate.xlsx','')
    ) AS v([name], [value], [description]);

END
ELSE IF  @@SERVERNAME = 'VMBIT-GSQLDB01' 
BEGIN

   SET @TARGET_ENVIRONMENT_NAME  = N'SIT'
   SET @SOURCE_ENVIRONMENT_NAME  = N'SIT'
   INSERT @ENVIRONMENT_VARIABLES
   SELECT [name], [value], [description]
     FROM (
     VALUES
       --
     -- PASTE the Environmental variables to create    
    ('ArchiveLocation','\\VMBIT-GSQLDB01\FinancialRisk-Upload\Archive\','')
   ,('BDXEmail','Conor.Murphy@liberty-it.co.uk','')
   ,('BDXError','\\VMBIT-GSQLDB01\FinancialRisk-Upload\PecLines','')
   ,('ClientMap','\\VMBIT-GSQLDB01\FinancialRisk-Upload\PecLines\InitialLoad\Client_Map_template.xlsx','')
   ,('CompanySpreadsheet','\\VMBIT-GSQLDB01\FinancialRisk-Upload\PecLines\InitialLoad\Company_Paper_template.xlsx','')
   ,('CorrectionsFileLocation','\\VMBIT-GSQLDB01\FinancialRisk-Upload\Corrections\FRED_UpdateCorrections.xlsx','')
   ,('CSMModelFileLocation','\\VMBIT-GSQLDB01\FinancialRisk-Upload\CSM\','')
   ,('DataAnalyticsDBName','Actuarial_Analytics','')
   ,('DataAnalyticsDBServer','VMBIT-GSQLDB01','')
   ,('FREDDBName','FRED','')
   ,('FREDDBServer','VMBIT-GSQLDB01','')
   ,('EmailFrom','LSMDataAnalyticsSIT@LibertyMutual.com','')
   ,('EmailTo','Conor.Murphy@liberty-it.co.uk','')
   ,('EmailToMapping','Conor.Murphy@liberty-it.co.uk','')
   ,('Ironshore','\\VMBIT-GSQLDB01\FinancialRisk-Upload\Ironshore\Ironshore.xlsx','')
   ,('LMIEInput','\\VMBIT-GSQLDB01\FinancialRisk-Upload\LMIE\LMIE.xlsx','')
   ,('PecLinesBorderauxFilesLocation','\\VMBIT-GSQLDB01\FinancialRisk-Upload\PecLines\Borderaux Files','')
   ,('PecLinesProgramLiveFileLocation','\\VMBIT-GSQLDB01\FinancialRisk-Upload\PecLines\Programme_Live.xlsx','')
   ,('PTCAccessDBFileLocation','D:\FinancialRisk-Upload\PTC\PTC.mdb','')
   ,('ReuploadLocation','\\VMBIT-GSQLDB01\FinancialRisk-Upload\Reupload\Yes.txt','')
   ,('SMTPServer','smtprelay.lmig.com','')
   ,('TreatyReassignmentFileLocation','\\VMBIT-GSQLDB01\FinancialRisk-Upload\PecLines\Reassignments\TreatyReassignments.xlsx','')
   ,('UnmappedCedantsInput','\\VMBIT-GSQLDB01\FinancialRisk-Upload\Mappings\Input\Cedants\UnmappedCedants.xlsx','')
   ,('UnmappedCountriesInput','\\VMBIT-GSQLDB01\FinancialRisk-Upload\Mappings\Input\Countries\UnmappedCountries.xlsx','')
   ,('UnmappedObligorsInput','\\VMBIT-GSQLDB01\FinancialRisk-Upload\Mappings\Input\Obligors\UnmappedObligors.xlsx','')
   ,('UnmappedOutput','\\VMBIT-GSQLDB01\FinancialRisk-Upload\Mappings\Output\','')
   ,('AsAtDateFile','\\VMBIT-GSQLDB01\FinancialRisk-Upload\AsAtDate.xlsx','')
    ) AS v([name], [value], [description]);

	--SELECT * FROM @ENVIRONMENT_VARIABLES;  -- debug output
END
ELSE IF  @@SERVERNAME = 'VMBIS-GSQLDB01' 
BEGIN

   SET @TARGET_ENVIRONMENT_NAME  = N'UAT'
   SET @SOURCE_ENVIRONMENT_NAME  = N'UAT'
   INSERT @ENVIRONMENT_VARIABLES
   SELECT [name], [value], [description]
     FROM (
     VALUES
       --
     -- PASTE the Environmental variables to create    
    ('ArchiveLocation','\\VMBIS-GSQLDB01\FinancialRisk-Upload\Archive\','')
   ,('BDXEmail','Stuart.Farnam@LibertyGlobalGroup.com','')
   ,('BDXError','\\VMBIS-GSQLDB01\FinancialRisk-Upload\PecLines','')
   ,('ClientMap','\\VMBIS-GSQLDB01\FinancialRisk-Upload\PecLines\InitialLoad\Client_Map_template.xlsx','')
   ,('CompanySpreadsheet','\\VMBIS-GSQLDB01\FinancialRisk-Upload\PecLines\InitialLoad\Company_Paper_template.xlsx','')
   ,('CorrectionsFileLocation','\\VMBIS-GSQLDB01\FinancialRisk-Upload\Corrections\FRED_UpdateCorrections.xlsx','')
   ,('CSMModelFileLocation','\\VMBIS-GSQLDB01\FinancialRisk-Upload\CSM\','')
   ,('DataAnalyticsDBName','Actuarial_Analytics','')
   ,('DataAnalyticsDBServer','VMBIS-GSQLDB01','')
   ,('FREDDBName','FRED','')
   ,('FREDDBServer','VMBIS-GSQLDB01','')
   ,('EmailFrom','LSMDataAnalyticsUAT@LibertyMutual.com','')
   ,('EmailTo','FREDSupportDL@LibertyMutual.com','')
   ,('EmailToMapping','FREDSupportDL@LibertyMutual.com','')
   ,('Ironshore','\\VMBIS-GSQLDB01\FinancialRisk-Upload\Ironshore\Ironshore.xlsx','')
   ,('LMIEInput','\\VMBIS-GSQLDB01\FinancialRisk-Upload\LMIE\LMIE.xlsx','')
   ,('PecLinesBorderauxFilesLocation','\\VMBIS-GSQLDB01\FinancialRisk-Upload\PecLines\Borderaux Files','')
   ,('PecLinesProgramLiveFileLocation','\\VMBIS-GSQLDB01\FinancialRisk-Upload\PecLines\Programme_Live.xlsx','')
   ,('PTCAccessDBFileLocation','D:\FinancialRisk-Upload\PTC\PTC.mdb','')
   ,('ReuploadLocation','\\VMBIS-GSQLDB01\FinancialRisk-Upload\Reupload\Yes.txt','')
   ,('SMTPServer','smtprelay.lmig.com','')
   ,('TreatyReassignmentFileLocation','\\VMBIS-GSQLDB01\FinancialRisk-Upload\PecLines\Reassignments\TreatyReassignments.xlsx','')
   ,('UnmappedCedantsInput','\\VMBIS-GSQLDB01\FinancialRisk-Upload\Mappings\Input\Cedants\UnmappedCedants.xlsx','')
   ,('UnmappedCountriesInput','\\VMBIS-GSQLDB01\FinancialRisk-Upload\Mappings\Input\Countries\UnmappedCountries.xlsx','')
   ,('UnmappedObligorsInput','\\VMBIS-GSQLDB01\FinancialRisk-Upload\Mappings\Input\Obligors\UnmappedObligors.xlsx','')
   ,('UnmappedOutput','\\VMBIS-GSQLDB01\FinancialRisk-Upload\Mappings\Output\','')
   ,('AsAtDateFile','\\VMBIS-GSQLDB01\FinancialRisk-Upload\AsAtDate.xlsx','')
    ) AS v([name], [value], [description]);

	--SELECT * FROM @ENVIRONMENT_VARIABLES;  -- debug output
END
ELSE IF  @@SERVERNAME = 'VMBIP-GSQLDB14' 
BEGIN

   SET @TARGET_ENVIRONMENT_NAME  = N'PRD'
   SET @SOURCE_ENVIRONMENT_NAME  = N'PRD'
   INSERT @ENVIRONMENT_VARIABLES
   SELECT [name], [value], [description]
     FROM (
     VALUES
       --
     -- PASTE the Environmental variables to create    
     ('ArchiveLocation','\\VMBIP-GSQLDB14\FinancialRisk-Upload\Archive\','')
    ,('BDXEmail','FREDSupportDL@LibertyMutual.com','')
    ,('BDXError','\\VMBIP-GSQLDB14\FinancialRisk-Upload\PecLines','')
    ,('ClientMap','\\VMBIP-GSQLDB14\FinancialRisk-Upload\PecLines\InitialLoad\Client_Map_template.xlsx','')
    ,('CompanySpreadsheet','\\VMBIP-GSQLDB14\FinancialRisk-Upload\PecLines\InitialLoad\Company_Paper_template.xlsx','')
    ,('CorrectionsFileLocation','\\VMBIP-GSQLDB14\FinancialRisk-Upload\Corrections\FRED_UpdateCorrections.xlsx','')
    ,('CSMModelFileLocation','\\VMBIP-GSQLDB14\FinancialRisk-Upload\CSM\','')
    ,('DataAnalyticsDBName','Actuarial_Analytics','')
    ,('DataAnalyticsDBServer','VMBIP-GSQLDB01','') 
    ,('FREDDBName','FRED','')
    ,('FREDDBServer','VMBIP-GSQLDB14','') 
    ,('EmailFrom','LSMDataAnalyticsPRD@LibertyMutual.com','')
    ,('EmailTo','FREDSupportDL@LibertyMutual.com','')
    ,('EmailToMapping','FREDSupportDL@LibertyMutual.com','')
    ,('Ironshore','\\VMBIP-GSQLDB14\FinancialRisk-Upload\Ironshore\Ironshore.xlsx','')
    ,('LMIEInput','\\VMBIP-GSQLDB14\FinancialRisk-Upload\LMIE\LMIE.xlsx','')
    ,('PecLinesBorderauxFilesLocation','\\VMBIP-GSQLDB14\FinancialRisk-Upload\PecLines\Borderaux Files','')
    ,('PecLinesProgramLiveFileLocation','\\VMBIP-GSQLDB14\FinancialRisk-Upload\PecLines\Programme_Live.xlsx','')
    ,('PTCAccessDBFileLocation','K:\FinancialRisk-Upload\PTC\PTC.mdb','')
    ,('ReuploadLocation','\\VMBIP-GSQLDB14\FinancialRisk-Upload\Reupload\Yes.txt','')
    ,('SMTPServer','smtprelay.lmig.com','')
    ,('TreatyReassignmentFileLocation','\\VMBIP-GSQLDB14\FinancialRisk-Upload\PecLines\Reassignments\TreatyReassignments.xlsx','')
    ,('UnmappedCedantsInput','\\VMBIP-GSQLDB14\FinancialRisk-Upload\Mappings\Input\Cedants\UnmappedCedants.xlsx','')
    ,('UnmappedCountriesInput','\\VMBIP-GSQLDB14\FinancialRisk-Upload\Mappings\Input\Countries\UnmappedCountries.xlsx','')
    ,('UnmappedObligorsInput','\\VMBIP-GSQLDB14\FinancialRisk-Upload\Mappings\Input\Obligors\UnmappedObligors.xlsx','')
    ,('UnmappedOutput','\\VMBIP-GSQLDB14\FinancialRisk-Upload\Mappings\Output\','')
	,('AsAtDateFile','\\VMBIP-GSQLDB14\FinancialRisk-Upload\AsAtDate.xlsx','')
    ) AS v([name], [value], [description]);

	--SELECT * FROM @ENVIRONMENT_VARIABLES;  -- debug output
END

-- Create Folder
IF NOT EXISTS (SELECT 1 FROM [SSISDB].[catalog].[folders] WHERE name = @FOLDER_NAME)
   EXEC [SSISDB].[catalog].[create_folder] @folder_name=@FOLDER_NAME, @folder_id=@FOLDER_ID OUTPUT
--ELSE
--   SET @FOLDER_ID = (SELECT folder_id FROM [SSISDB].[catalog].[folders] WHERE name = @FOLDER_NAME)

--- Create Environment (if necessary)


IF NOT EXISTS ( SELECT *, f.name FROM ssisdb.catalog.environments e 
 JOIN [SSISDB].[catalog].[folders] f ON e.[folder_id] = f.[folder_id] 
 WHERE e.name=@TARGET_ENVIRONMENT_NAME  and f.name = @FOLDER_NAME)
BEGIN
	EXEC [SSISDB].[catalog].[create_environment] @environment_name=@TARGET_ENVIRONMENT_NAME, @environment_description=N'Environment for FRED', @folder_name=@FOLDER_NAME
    Print 'Environment '+@TARGET_ENVIRONMENT_NAME+' Created'
END
-- Create Environmnet Reference
Declare @reference_id bigint
IF NOT EXISTS (select environment_name from ssisdb.catalog.environment_references where environment_name= @TARGET_ENVIRONMENT_NAME and environment_folder_name = @FOLDER_NAME)
BEGIN
   EXEC [SSISDB].[catalog].[create_environment_reference] @environment_name= @TARGET_ENVIRONMENT_NAME, @environment_folder_name=@FOLDER_NAME, @reference_id=@reference_id OUTPUT, @project_name=@PROJECT_NAME, @folder_name=@FOLDER_NAME, @reference_type=A
   Print 'Environment '+@TARGET_ENVIRONMENT_NAME+' reference created'	
END
SELECT TOP 1
 @VARIABLE_NAME = [name]
,@VARIABLE_VALUE = [value]
,@VARIABLE_DESCRIPTION = [description]
FROM @ENVIRONMENT_VARIABLES

WHILE @VARIABLE_NAME IS NOT NULL
BEGIN
   --PRINT @VARIABLE_NAME
    -- create environment variable if it doesn't exist
   IF NOT EXISTS (
        SELECT 1 FROM [SSISDB].[catalog].[environments] e JOIN 
	               [SSISDB].[catalog].[environment_variables] v ON e.[environment_id] = v.[environment_id]
				   JOIN [SSISDB].[catalog].[folders] f ON e.[folder_id] = f.[folder_id] 
      WHERE e.name =@TARGET_ENVIRONMENT_NAME 
	  AND v.name = @VARIABLE_NAME 
	  AND  f.name = @FOLDER_NAME
	  
   )
      EXEC [SSISDB].[catalog].[create_environment_variable]
        @variable_name=@VARIABLE_NAME
      , @sensitive=0
      , @description=@VARIABLE_DESCRIPTION
      , @environment_name=@TARGET_ENVIRONMENT_NAME
      , @folder_name=@FOLDER_NAME
      , @value=@VARIABLE_VALUE
      , @data_type=N'String'
   ELSE
    -- update environment variable value if it exists
      EXEC [SSISDB].[catalog].[set_environment_variable_value]
        @folder_name = @FOLDER_NAME
      , @environment_name = @TARGET_ENVIRONMENT_NAME
      , @variable_name = @VARIABLE_NAME
      , @value = @VARIABLE_VALUE

  EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=@VARIABLE_NAME, @object_name=@PROJECT_NAME, @folder_name=@FOLDER_NAME, @project_name=@PROJECT_NAME, @value_type=R, @parameter_value=@VARIABLE_NAME

   DELETE TOP (1) FROM @ENVIRONMENT_VARIABLES
   SET @VARIABLE_NAME = null
   SELECT TOP 1
     @VARIABLE_NAME = [name]
    ,@VARIABLE_VALUE = [value]
    ,@VARIABLE_DESCRIPTION = [description]
    FROM @ENVIRONMENT_VARIABLES
END

