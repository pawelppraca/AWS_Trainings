﻿CREATE TABLE [sources].[dwhr_ISOCurrencies_Staging] (
    [rid]                    INT            IDENTITY (1, 1)    NOT NULL,
    [ISOCurrencyKey]         INT            NULL,
    [ISOCurrencyCode]        NVARCHAR (255) NULL,
    [ISOCurrencyName]        NVARCHAR (255) NULL,
    [SettlementCurrencyFlag] NVARCHAR (50)  NULL,
    [_DateCreated]           DATETIME2 (7)  NULL,
    [_EventExecutionKey]     INT            NULL,
    [_LastAction]            NVARCHAR (1)   NULL,
    [_MergeKey]              NVARCHAR (255) NULL,
    [_SourceSystemCode]      NVARCHAR (50)  NULL,
    [LoadID]                 INT            NULL,
	[UploadDate]             datetime       NULL,
    CONSTRAINT [PK_SrcsDwhrISOCurrenciesStaging] PRIMARY KEY CLUSTERED ([rid] ASC)
);

