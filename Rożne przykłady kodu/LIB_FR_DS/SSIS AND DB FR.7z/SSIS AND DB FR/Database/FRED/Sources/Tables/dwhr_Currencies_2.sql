﻿CREATE TABLE [sources].[dwhr_Currencies_2] (
	[rid] [int] NOT NULL,
	[CurrencyKey] [int] NOT NULL,
	[CurrencyCode] [nvarchar](50) NULL,
	[CurrencyName] [nvarchar](100) NULL,
	[ISOCurrencyKey] [int] NULL,
	[_DateCreated] [datetime2](7) NULL,
	[_EventExecutionKey] [int] NULL,
	[_LastAction] [nvarchar](1) NULL,
	[_MergeKey] [nvarchar](255) NULL,
	[_SourceSystemCode] [nvarchar](50) NULL,
	[LoadID] [int] NOT NULL,
	[UploadDate] [datetime] NULL,
	[UploadFredDate] [datetime] NULL,
 CONSTRAINT [PK_SrcsDwhrCurrencies2] PRIMARY KEY CLUSTERED 
(
	[CurrencyKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO