﻿CREATE TABLE [sources].[dwhr_ISOCurrencies_WORK](
	[rid] 						INT					NOT NULL,
	[ISOCurrencyKey]			INT					NOT NULL,
	[ISOCurrencyCode]			NVARCHAR (255)		NULL,
	[ISOCurrencyName]			NVARCHAR (255)		NULL,
	[SettlementCurrencyFlag]	NVARCHAR (50)		NULL,
	[LoadID]					INT					NULL,
	[UploadDate]				DATETIME			NULL,
	[UploadFredDate]			DATETIME			NULL,
	[_DateCreated]				DATETIME2 (7)		NULL,
	[_EventExecutionKey]		INT					NULL,
	[_LastAction]				NVARCHAR (1)		NULL,
	[_MergeKey]					NVARCHAR (255)		NULL,
	[_SourceSystemCode]			NVARCHAR(50)		NULL,
	[_SourceChecksum]			INT					NULL,
	[_TargetChecksum]			INT					NULL,

 CONSTRAINT [PK_SrcsDwhrISOCurrenciesWORK] PRIMARY KEY CLUSTERED 
(
	[ISOCurrencyKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
