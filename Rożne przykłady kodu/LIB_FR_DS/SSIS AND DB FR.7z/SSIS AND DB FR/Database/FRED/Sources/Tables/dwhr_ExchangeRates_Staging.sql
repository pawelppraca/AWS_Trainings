﻿CREATE TABLE [sources].[dwhr_ExchangeRates_Staging] (
    [rid]                  INT            IDENTITY (1, 1)    NOT NULL,
    [ExchangeRateKey]      INT             NULL,
    [ISOCurrencyFromKey]   INT             NULL,
    [ISOCurrencyToKey]     INT             NULL,
    [ExchangeRateDateKey]  DATE            NULL,
    [ExchangeRateTypeCode] NVARCHAR (255)  NULL,
    [ExchangeRateTypeName] NVARCHAR (255)  NULL,
    [ExchangeRate]         NUMERIC (31, 7) NULL,
    [_DateCreated]         DATETIME2 (7)   NULL,
    [_EventExecutionKey]   INT             NULL,
    [_LastAction]          NVARCHAR (1)    NULL,
    [_MergeKey]            NVARCHAR (255)  NULL,
    [_SourceSystemCode]    NVARCHAR (50)   NULL,
    [LoadID]               INT             NULL,
	[UploadDate]        datetime        NULL,
    CONSTRAINT [PK_SrcsDWHRXratesStaging] PRIMARY KEY CLUSTERED ([rid] ASC)
);

