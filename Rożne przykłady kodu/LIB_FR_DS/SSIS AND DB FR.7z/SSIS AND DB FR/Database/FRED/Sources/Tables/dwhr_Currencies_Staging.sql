﻿
CREATE TABLE [sources].[dwhr_Currencies_Staging] (
    [rid]                INT            IDENTITY (1, 1)    NOT NULL,
    [CurrencyKey]        INT            NULL,
    [CurrencyCode]       NVARCHAR (50)  NULL,
    [CurrencyName]       NVARCHAR (100) NULL,
    [ISOCurrencyKey]     INT            NULL,
    [_DateCreated]       DATETIME2 (7)  NULL,
    [_EventExecutionKey] INT            NULL,
    [_LastAction]        NVARCHAR (1)   NULL,
    [_MergeKey]          NVARCHAR (255) NULL,
    [_SourceSystemCode]  NVARCHAR (50)  NULL,
    [LoadID]             INT            NOT NULL,
	[UploadDate]        datetime        NULL,

    CONSTRAINT [PK_SrcsDwhrCurrenciesStaging] PRIMARY KEY CLUSTERED ([rid] ASC)
);
