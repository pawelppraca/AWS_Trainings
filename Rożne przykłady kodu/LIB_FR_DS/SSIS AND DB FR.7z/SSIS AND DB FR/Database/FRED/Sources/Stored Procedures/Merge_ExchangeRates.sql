﻿CREATE PROCEDURE [Sources].[Merge_ExchangeRates]

AS
BEGIN
	
		MERGE [sources].[dwhr_ExchangeRates_2]  AS t 
		USING [sources].[dwhr_ExchangeRates_WORK] AS s 
		ON 
		(
			t.[ExchangeRateKey] = s.[ExchangeRateKey] 
		)
		WHEN MATCHED AND s.[_LastAction] IN ('I', 'U') AND s.[ExchangeRate]	> 0
		THEN 
		UPDATE 
		SET 
				[rid]					= s.[rid]					
			,	[ExchangeRateKey]		= s.[ExchangeRateKey]		
			,	[ISOCurrencyFromKey]	= s.[ISOCurrencyFromKey]	
			,	[ISOCurrencyToKey]		= s.[ISOCurrencyToKey]		
			,	[ExchangeRateDateKey]	= s.[ExchangeRateDateKey]	
    		,	[ExchangeRateTypeCode]	= s.[ExchangeRateTypeCode]	
    		,	[ExchangeRateTypeName]	= s.[ExchangeRateTypeName]	
			,	[ExchangeRate]			= s.[ExchangeRate]			
			,	[LoadID]				= s.[LoadID]				
			,	[UploadDate]			= s.[UploadDate]			
			,	[UploadFredDate]		= s.[UploadFredDate]		
			,	[_DateCreated]			= s.[_DateCreated]			
			,	[_EventExecutionKey]	= s.[_EventExecutionKey]	
			,	[_LastAction]			= s.[_LastAction]			
			,	[_MergeKey]				= s.[_MergeKey]				
			,	[_SourceSystemCode]		= s.[_SourceSystemCode]		

		WHEN NOT MATCHED BY TARGET AND s.[_LastAction] IN ('I', 'U')  AND s.[ExchangeRate]	> 0
		THEN 
		INSERT 
		( 
			[rid]					
		,	[ExchangeRateKey]		
		,	[ISOCurrencyFromKey]	
		,	[ISOCurrencyToKey]		
		,	[ExchangeRateDateKey]	
		,	[ExchangeRateTypeCode]	
		,	[ExchangeRateTypeName]	
		,	[ExchangeRate]			
		,	[LoadID]				
		,	[UploadDate]			
		,	[UploadFredDate]		
		,	[_DateCreated]			
		,	[_EventExecutionKey]	
		,	[_LastAction]			
		,	[_MergeKey]				
		,	[_SourceSystemCode]		
		)
		VALUES
		(
			s.[rid]					
		,s.[ExchangeRateKey]		
		,s.[ISOCurrencyFromKey]	
		,s.[ISOCurrencyToKey]		
		,s.[ExchangeRateDateKey]	
		,s.[ExchangeRateTypeCode]	
		,s.[ExchangeRateTypeName]	
		,s.[ExchangeRate]			
		,s.[LoadID]				
		,s.[UploadDate]			
		,s.[UploadFredDate]		
		,s.[_DateCreated]			
		,s.[_EventExecutionKey]	
		,s.[_LastAction]			
		,s.[_MergeKey]				
		,s.[_SourceSystemCode]
	);

RETURN 0	

END
