﻿CREATE PROCEDURE [Sources].[Merge_Currencies]

AS
BEGIN
	
		MERGE [sources].[dwhr_Currencies_2]  AS t 
		USING [sources].[dwhr_Currencies_WORK] AS s 
		ON 
		(
			t.[CurrencyKey] = s.[CurrencyKey] 
		)
		WHEN MATCHED AND s.[_LastAction] IN ('I', 'U') 
		THEN 
		UPDATE 
		SET 
			[rid]					= s.[rid]
		,	[CurrencyCode]		    = s.[CurrencyCode]		
		,	[CurrencyName]		    = s.[CurrencyName]		
		,	[ISOCurrencyKey]	    = s.[ISOCurrencyKey]	
		,	[_DateCreated]		    = s.[_DateCreated]		
		,	[_EventExecutionKey]    = s.[_EventExecutionKey]
		,	[_LastAction]		    = s.[_LastAction]		
		,	[_MergeKey]			    = s.[_MergeKey]			
		,	[_SourceSystemCode]	    = s.[_SourceSystemCode]	
		,	[LoadID]			    = s.[LoadID]			
		,	[UploadDate]		    = s.[UploadDate]		
		,	[UploadFredDate]		= s.[UploadFredDate]		

		WHEN NOT MATCHED BY TARGET AND s.[_LastAction] IN ('I', 'U') THEN 
		INSERT 
		( 
			[rid]				
		,	[CurrencyKey]		
		,	[CurrencyCode]		
		,	[CurrencyName]		
		,	[ISOCurrencyKey]	
		,	[_DateCreated]		
		,	[_EventExecutionKey]
		,	[_LastAction]		
		,	[_MergeKey]			
		,	[_SourceSystemCode]	
		,	[LoadID]			
		,	[UploadDate]
		,	[UploadFredDate]
		

		)
		VALUES
		(
			s.[rid]				
		,	s.[CurrencyKey]		
		,	s.[CurrencyCode]		
		,	s.[CurrencyName]		
		,	s.[ISOCurrencyKey]	
		,	s.[_DateCreated]		
		,	s.[_EventExecutionKey]
		,	s.[_LastAction]		
		,	s.[_MergeKey]			
		,	s.[_SourceSystemCode]	
		,	s.[LoadID]			
		,	s.[UploadDate]		
		,	s.[UploadFredDate]		
		);

RETURN 0

END
