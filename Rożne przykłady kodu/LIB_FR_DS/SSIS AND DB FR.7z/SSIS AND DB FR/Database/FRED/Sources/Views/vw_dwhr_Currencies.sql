﻿CREATE VIEW [sources].[vw_dwhr_Currencies] 

AS
SELECT
   [rid]
    , [CurrencyKey]
    ,[CurrencyCode]
    ,[CurrencyName] 
    ,[ISOCurrencyKey]
    ,[_DateCreated] 
    ,[_EventExecutionKey] 
    ,[_LastAction] 
    ,[_MergeKey] 
    ,[_SourceSystemCode] 
    ,[LoadID] 
FROM  [sources].[dwhr_Currencies_2] 
GO