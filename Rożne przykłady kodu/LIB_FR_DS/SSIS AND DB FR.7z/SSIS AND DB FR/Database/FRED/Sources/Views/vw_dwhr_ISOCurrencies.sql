﻿CREATE VIEW  sources.vw_dwhr_ISOCurrencies

AS
SELECT
   rid
   ,ISOCurrencyKey
   ,ISOCurrencyCode
   ,ISOCurrencyName
   ,SettlementCurrencyFlag
   ,_DateCreated
   , _EventExecutionKey
   ,_LastAction
   ,_MergeKey
   ,_SourceSystemCode
   ,LoadID
FROM   sources.dwhr_ISOCurrencies_2
GO