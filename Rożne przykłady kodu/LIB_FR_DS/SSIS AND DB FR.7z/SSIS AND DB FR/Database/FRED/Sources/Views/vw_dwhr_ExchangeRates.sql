﻿CREATE VIEW [sources].[vw_dwhr_ExchangeRates] AS

SELECT
    rid
   ,ExchangeRateKey
   ,ISOCurrencyFromKey
   ,ISOCurrencyToKey
   ,ExchangeRateDateKey
   ,ExchangeRateTypeCode
   ,ExchangeRateTypeName
   ,ExchangeRate
   ,_DateCreated
   ,_EventExecutionKey
   ,_LastAction
   ,_MergeKey
   ,_SourceSystemCode
   , LoadID
   FROM 
[sources].[dwhr_ExchangeRates_2]
  GO