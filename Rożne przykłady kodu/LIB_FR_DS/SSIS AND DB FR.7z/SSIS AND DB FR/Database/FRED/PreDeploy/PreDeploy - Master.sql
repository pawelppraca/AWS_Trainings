﻿--Pre Deploy master

:r ".\OneTimeScript.sql"
