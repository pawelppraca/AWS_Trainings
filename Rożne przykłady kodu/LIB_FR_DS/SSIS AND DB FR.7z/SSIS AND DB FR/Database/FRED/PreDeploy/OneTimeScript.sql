﻿----add script
--IF(@@SERVERNAME = '????')
--BEGIN


	
--END 

