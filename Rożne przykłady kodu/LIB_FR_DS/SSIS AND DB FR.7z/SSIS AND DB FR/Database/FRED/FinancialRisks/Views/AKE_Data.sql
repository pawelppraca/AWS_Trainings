﻿



/*********************************************/
CREATE VIEW [FinancialRisks].[AKE_Data]
 AS
SELECT DISTINCT
ClassOfBusiness,
CedantName,
EntityName,
CountryName,
TradeSectorName,
CapitalIqId,
SUM(LibertyExposure) AS LibertyExposure,
ExpiryDate,
RiskCode,
InforceDate,
Paper
FROM (
SELECT DISTINCT 
ClassOfBusiness,
Name as CedantName,
EntityName,
CountryName,
TradeSectorName,
CapitalIqId,
--GrossExposure,
--XL CALC
CASE WHEN AuditCode = 'XL' THEN
     CASE WHEN GrossExposure > (tr.Excess /tcr.Rate) THEN  
          CASE WHEN (GrossExposure - tr.Excess) > (tr.Limit / tcr.Rate) THEN (tr.Limit / tcr.Rate) * SignedLine ELSE (GrossExposure - (tr.Excess / tcr.Rate) ) * tr.SignedLine END
      ELSE 0 END
--QS CALC
WHEN AuditCode in ('QS', 'BA') THEN 
        CASE WHEN ISNULL(tr.Limit / tcr.Rate,0) > 0 THEN
                    CASE WHEN GrossExposure > (tr.Limit / tcr.Rate) THEN (tr.Limit / tcr.Rate) * tr.SignedLine ELSE GrossExposure * tr.SignedLine END
        ELSE GrossExposure * SignedLine END
WHEN innerQuery.CobId in (1,2,6) THEN GrossExposure --LMIE/GFR For LMIE and GFR that don't have treatys attached
ELSE -1 -- hack so can exclude treaty rows not matching 
END AS LibertyExposure,
innerQuery.ExpiryDate,
innerQuery.RiskCode,
innerQuery.InforceDate,
Paper
FROM (
SELECT DISTINCT
            cob.Name as ClassOfBusiness,
            CASE WHEN ex.GrossExposure / ecr.Rate > ISNULL(ex.Limit / ecr.Rate,0) AND ISNULL(ex.Limit / ecr.Rate,0) > 0 THEN ISNULL(ex.Limit / ecr.Rate,0) ELSE ex.GrossExposure / ecr.Rate END AS GrossExposure,
            CAST(ex.ExpiryDate AS DATE) AS ExpiryDate,
            ce.Name,

			case when en.EntityName like '%Ministry%' 
		  then case when  en.EntityName  like '%'+co.CountryName+'%'
					then en.EntityName
					else en.EntityName +' - ' + co.CountryName  
				END
		  else en.EntityName
		END as EntityName,

           -- en.EntityName,
            en.CapitalIqId,
            co.CountryName,
            ts.TradeSectorName,
            ex.CedantId,
            ex.InforceDate,
            ex.RiskCode,
                             ex.CobId,
                             CAST(ex.InceptionDate AS DATE) AS InceptionDate
FROM FinancialRisks.Exposures ex
LEFT JOIN FinancialRisks.Cedant AS ce ON ce.CedantId = ex.CedantId
LEFT JOIN FinancialRisks.Entities en ON en.EntityId = ex.ObligorEntityId
LEFT JOIN FinancialRisks.Countries co ON co.CountryId = ex.CountryId
LEFT JOIN FinancialRisks.TradeSector ts on ts.TradeSectorID = en.TradeSectorId
LEFT JOIN FinancialRisks.COB cob on cob.CobId = ex.CobId
LEFT JOIN FinancialRisks.Currencies ecr on ecr.CurrencyId = ex.CurrencyId
WHERE LEN(en.EntityName) > 1 -- exclude blank entities
) innerQuery
LEFT JOIN FinancialRisks.RiskCodeMappings rc on rc.RiskCode = innerQuery.RiskCode
LEFT JOIN FinancialRisks.Treaties tr on tr.RiskCodeGroupId = rc.RiskCodeGroupId and tr.InforceDate = innerQuery.InforceDate and tr.CedantId = innerQuery.CedantId 
LEFT JOIN FinancialRisks.Currencies tcr on tcr.CurrencyId = tr.CurrencyId
WHERE ((innerQuery.InceptionDate >= tr.InceptionDate AND innerQuery.InceptionDate <= tr.ExpiryDate) OR innerQuery.Name = 'LIB')
) query2
WHERE LibertyExposure != -1 -- exclude treaty dups
GROUP BY
InforceDate,
ClassOfBusiness,
Paper,
CedantName,
EntityName,
RiskCode,
CountryName,
TradeSectorName,
CapitalIqId,
ExpiryDate

Union 

select
'Ironsure Reinsurance' as ClassOfBusiness,
'' as CedantName,
--Obligor as EntityName,
case when Obligor like '%Ministry%' 
		  then case when  Obligor  like '%'+co.CountryName+'%'
					then Obligor
					else Obligor +' - ' + co.CountryName  
				END
		  else Obligor
		END as EntityName,

co.CountryName,
'' as TradeSectorName,
en.CapitalIqId,
SUM(GrossExposure) AS LibertyExposure,
expiry_date as ExpiryDate,
RiskCode,
InforceDate,
'' AS Paper
FROM FinancialRisks.Ironshore_Data id
LEFT JOIN FinancialRisks.Countries co ON co.CountryId = id.CountryId
LEFT JOIN FinancialRisks.Entities en ON en.EntityId = id.entityId
GROUP BY
InforceDate,
Obligor,
RiskCode,
CountryName,
CapitalIqId,
expiry_date