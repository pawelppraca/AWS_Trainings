﻿/*********************************************/
/*
ChangeLog:
-----------
2022-10-12 - by Pawel P. (FP) - GSGL-790 - Amend Currency and Rate for both Exposure and Treaty - https://forge.lmig.com/issues/browse/GSGL-790
	Line 129-138:   Add new Columns: ExposureRate, ExposureCurrency, TreatyRate, TreatyCurrency

2023-02-16 - by Pawel P. (FP) - GSGL-896 - Remove columns Rate and CurrencyName - https://forge.lmig.com/issues/browse/GSGL-896
2023.05.29 - by Pawel P. (FP) - GSGL1096 - New column Industry ffrom Exposures - https://forge.lmig.com/issues/browse/GSGL-1096
2023.09.07 - by Pawel P. (FP) - RollBack GSGL-1283 to deploy on new PROD old version
2023.09.11 - by Pawel P. (FP) - Restore rollbacked changes related to GSGL-1283
2023.11.06 - by Pawel P. (FP) - GSGL-1372 - Display new field OriginalEntityinFile and OriginalCountryinFile
 
 */

CREATE VIEW [FinancialRisks].[vw_ExposureOverview]
AS
SELECT EX.[ExposureId]
        ,lbe.CedantName
        ,lbe.[CobId]
        ,lbe.ReportingClass
        ,lbe.ClassOfBusiness
        ,lbe.ClassLGD
        ,lbe.SovereignRating
        ,EX.[RiskReference]
        ,EX.[CurrencyId]                                                AS 'Exposure_Currency_ID'
        ,lbe.RateGroup
        ,EX.[Year]
        ,EX.[DataQuarter]
        ,EX.[AssuredEntityId]
        ,EX.[RiskCode]
        ,EX.[LeadSyndicate]
        ,EX.[InceptionDate]                                             AS 'Exposure Inception Date'
        ,EX.[ExpiryDate]                                                AS 'Exposure Expiry Date'
        ,EX.[Limit]
        ,EX.[UsdLimit]
        ,EX.[GrossPremium]
        ,EX.GrossExposure                                               AS 'OriginalGrossExposure'
        ,lbe.[GrossExposure]
        ,lbe.LibertyExposure
        ,lbe.[ObligorEntityId]
        ,lbe.EntityName
        ,CASE when lbe.OriginalEntityinFile is null THEN
            CASE
            WHEN op.ObligorPseudonym IS NULL
                 AND lbe.ObligorEntityId IN (SELECT DISTINCT EntityId
                                            FROM   FinancialRisks.Entities
                                            WHERE  EntityName LIKE '%obligor name not supplied%'
                                                OR EntityName = 'No obligor name supplied') THEN op.ObligorPseudonym
            WHEN op.ObligorPseudonym IS NULL THEN lbe.EntityName
            ELSE op.ObligorPseudonym
            END
         ELSE lbe.OriginalEntityinFile END                              AS 'Original Entity in File'
        ,lbe.OriginalEntityinFile                                       AS 'Original Entity in File - Actual'
        ,CASE
            WHEN op.ObligorPseudonym IS NULL
                 AND lbe.ObligorEntityId IN (SELECT DISTINCT EntityId
                                             FROM   FinancialRisks.Entities
                                             WHERE  EntityName LIKE '%obligor name not supplied%' OR EntityName = 'No obligor name supplied') 
                                             THEN   op.ObligorPseudonym
            WHEN op.ObligorPseudonym IS NULL THEN lbe.EntityName
            ELSE op.ObligorPseudonym
            END                                                          AS 'Original Entity in File - Derived'
        ,lbe.CapitalIqId
        ,lbe.SPRating
        ,lbe.GCHPRating
        ,lbe.LibertyRating
        ,lbe.DefaultRating
        ,lbe.OverrideRating
        ,lbe.UltimateRating
        ,lbe.TradeSectorId
        ,lbe.DefaultTradeSectorId
        ,lbe.OverrideTradeSectorId
        ,lbe.UltimateTradeSectorId
        ,lbe.TopLevelTradeSectorID
        ,EX.[CountryId]
        ,lbe.CountryName
        ,Case when lbe.OriginalCountryinFile is null then
            CASE
            WHEN cp.CountryPseudonym IS NULL
                AND ex.CountryId IN (SELECT DISTINCT CountryId
                                    FROM   FinancialRisks.Countries
                                    WHERE  CountryName LIKE '%No country name supplied%') THEN cp.CountryPseudonym
            WHEN cp.CountryPseudonym IS NULL THEN lbe.CountryName
            ELSE cp.CountryPseudonym
            END
         ELSE lbe.OriginalCountryinFile END                             AS 'Original Country in File'
        ,lbe.OriginalCountryinFile                                      AS 'Original Country in File - Actual'
        ,CASE
            WHEN cp.CountryPseudonym IS NULL
                AND ex.CountryId IN (SELECT DISTINCT CountryId
                                    FROM   FinancialRisks.Countries
                                    WHERE  CountryName LIKE '%No country name supplied%') THEN cp.CountryPseudonym
            WHEN cp.CountryPseudonym IS NULL THEN lbe.CountryName
            ELSE cp.CountryPseudonym
            END                                                        AS 'Original Country in File - Derived'
        ,e.[Domicile]
        ,lbe.DefaultDomicile
        ,lbe.OverrideDomicile
        ,lbe.UltimateDomicile
        ,ctrs.[Region]                                                  AS 'Exposure Region'
        ,lbe.[Region]                                                   AS 'Entity Region' -- vchange order to group types of data
        ,lbe.TradeSectorName
        ,lbe.DefaultTradeSectorName
        ,lbe.OverrideTradeSectorName
        ,lbe.UltimateTradeSectorName
        ,lbe.TopLevelTradeSectorName
        ,EX.[ObligorPseudID]
        ,EX.[CountryPseudID]
        ,EX.[SBU]
        ,EX.[Office]
        ,CASE
        WHEN ex.AssumedLive IS NULL THEN 'No'
        ELSE ex.AssumedLive
        END                                                             AS AssumedLive
        ,EX.[ProductLine]
        ,EX.[NoBillingOffsetTotalSuretyExposureNetPGE]
        ,EX.[NetSuretyExposure]
        ,EX.[Assured]
        ,TR.[TreatyID]
        ,TR.[CedantId]
        ,TR.[NewReference]                                              AS 'TreatyReference'
        ,TR.[Year]                                                      AS 'TreatyYear'
        ,TR.[AuditCode]
        ,TR.[RiskCodeGroupId]
        ,TR.[RetroOnly]
        ,TR.[InceptionDate]                                             AS 'Treaty Inception Date'
        ,TR.[ExpiryDate]                                                AS 'Treaty Expiry Date'
        ,TR.[CurrencyId]
        ,TR.[Limit]                                                     AS 'TreatyLimit'
        ,TR.[Excess]
        ,TR.[OccDeductible]
        ,TR.[AggDeductible]
        ,TR.[NumReinstatements]
        ,TR.[ReinstatementAmount]
        ,TR.[SignedLine]
        ,TR.[OurShare]
        ,TR.[ROL]
        ,TR.[CobId]                                                     AS 'TreatyCobiD'
        ,TR.[Paper]
        ,TR.[Source]													AS 'TreatySource'
        ,lbe.TreatyType
        ,EX.[InforceDate]
        ,EX.[Source]
        ,EX.[UploadDate]
        ,e.[ParentEntityName]
        ,e.[ParentCapitalIqId]
        ,e.[ParentSPRating]
        ,e.[ParentGCHPRating]
        ,e.[ParentLibertyRating]
        ,e.[ParentDomicile]
        ,EX.[LocalId]
        ,CASE
			WHEN lbe.ExposureRate IS NULL OR lbe.ExposureRate = 0 THEN 'NR'
			ELSE Cast(lbe.ExposureRate AS VARCHAR(25))
         END                                                            AS 'ExposureRate'	-- GSGL-790 - New column added by PP
	    ,lbe.ExposureCurrency																-- GSGL-790 - New column added by PP
        ,CASE
			WHEN lbe.TreatyRate IS NULL OR lbe.TreatyRate = 0 THEN 'NR'
			ELSE Cast(lbe.TreatyRate AS VARCHAR(25))
         END                                                            AS 'TreatyRate'		-- GSGL-790 - New column added by PP
	    ,lbe.TreatyCurrency																	-- GSGL-790 - New column added by PP
        ,ex.Industry                                                                        -- GSGL-1096 - New column added by PP

FROM   FinancialRisks.LossByExposure lbe
        LEFT JOIN FinancialRisks.Exposures ex ON ex.ExposureId = lbe.ExposureId
        LEFT JOIN FinancialRisks.Entities e   ON e.EntityId = ex.ObligorEntityId
        LEFT JOIN FinancialRisks.Treaties tr   ON tr.TreatyID = lbe.TreatyID
        LEFT JOIN FinancialRisks.ObligorPseudonym op ON op.ObligorPseudonymId = ex.ObligorPseudID
        LEFT JOIN FinancialRisks.CountryPseudonym cp ON cp.CountryPseudonymId = ex.CountryPseudID
        INNER JOIN FinancialRisks.Countries ctrs ON ex.CountryID = ctrs.CountryID




