﻿

  
/*********************************************/
CREATE VIEW [FinancialRisks].[vw_ExposureOverview_Archive]
 AS
SELECT DISTINCT 
	   EntityName, 
	   SPRating,
	   CedantName, 
	   ReportingClass, 
	   CountryName, 
	   SovereignRating,
	   TradeSectorName, 
	   InceptionDate,
	   ExpiryDate,
	   CASE WHEN CedantName = 'LIB' THEN NULL ELSE TreatyType END AS TreatyType,
	   CurrencyName, 
     GrossExposure,
	--XL CALC
	CASE WHEN TreatyType = 'XL' THEN
		CASE WHEN GrossExposure > (Excess /Rate) THEN  
			 CASE WHEN (GrossExposure - Excess) > (TreatyLimit / Rate) THEN (TreatyLimit / Rate) * SignedLine ELSE (GrossExposure - (Excess / Rate) ) * SignedLine END
		ELSE 0 END
	--QS CALC
	WHEN TreatyType in ('QS', 'BA') THEN 
		CASE WHEN ISNULL(TreatyLimit / Rate,0) > 0 THEN
			CASE WHEN GrossExposure > (TreatyLimit / Rate) THEN (TreatyLimit / Rate) * SignedLine ELSE GrossExposure * SignedLine END
		ELSE GrossExposure * SignedLine END
	ELSE GrossExposure -- For LMIE and GFR that don't have treatys attached
	END AS LibertyExposure,
	InforceDate
FROM
(
	SELECT DISTINCT tr.NewReference as SystemTreatyId
	, c.Name as CedantName,cob.ReportingClass,e.RiskReference,e.InceptionDate,e.ExpiryDate, tr.Limit as TreatyLimit, cr.CurrencyName,
	 tcr.Rate, e.CurrencyId,
	 tr.AuditCode as TreatyType, tr.Excess, tr.SignedLine, tr.OurShare,
	CASE WHEN e.GrossExposure / cr.Rate > ISNULL(e.Limit / cr.Rate,0) AND ISNULL(e.Limit / cr.Rate,0) > 0 THEN ISNULL(e.Limit / cr.Rate,0) ELSE e.GrossExposure / cr.Rate END AS GrossExposure, 
	 
	 case when en.EntityName like '%Ministry%' 
		  then case when  en.EntityName  like '%'+co.CountryName+'%'
					then en.EntityName
					else en.EntityName +' - ' + co.CountryName  
				END
		  else en.EntityName
		END as EntityName,

	-- en.EntityName, 

	
	 co.CountryName,
	 ts.TradeSectorName,
	 en.SPRating,
	 co.SovereignRating,
	 e.InforceDate
	FROM FinancialRisks.archive_Exposures e
	--cedants
	LEFT JOIN FinancialRisks.archive_Cedant c on c.CedantID = e.CedantId
	--exposure riskcode mappings
	LEFT JOIN FinancialRisks.RiskCodeMappings riskCodeMappings on riskCodeMappings.riskCode = e.RiskCode 
	--join treaties to exposures on cedant, risk code group and inforcedate
	LEFT JOIN FinancialRisks.archive_Treaties tr on tr.CedantId = c.CedantID and tr.RiskCodeGroupId = riskCodeMappings.RiskCodeGroupId and tr.InforceDate = e.InforceDate
	--exposure currency data
	LEFT JOIN FinancialRisks.Currencies cr on cr.CurrencyId = e.CurrencyId
	--treaties currency data
	LEFT JOIN FinancialRisks.Currencies tcr on tcr.CurrencyId = tr.CurrencyId
	--reporting classes data
	LEFT JOIN FinancialRisks.COB cob on cob.CobId = e.CobId
	--obligor data
	LEFT JOIN FinancialRisks.archive_Entities en on en.EntityId = e.ObligorEntityId
	--country data
	LEFT JOIN FinancialRisks.archive_Countries co on co.CountryId = e.CountryId
	--trade sector data
	LEFT JOIN FinancialRisks.TradeSector ts on ts.TradeSectorID = en.TradeSectorId

	WHERE ((e.InceptionDate >= tr.InceptionDate AND e.InceptionDate <= tr.ExpiryDate) OR c.Name = 'LIB')
	AND e.RiskCode in ('CF','CR')
	AND en.EntityName != 'No capital IQ ID Assigned.'
	AND LEN(en.EntityName) > 1
) innerQuery