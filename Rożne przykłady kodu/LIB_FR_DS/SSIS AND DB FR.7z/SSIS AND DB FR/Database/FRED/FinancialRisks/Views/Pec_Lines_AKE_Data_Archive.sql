﻿
/*********************************************/
CREATE VIEW [FinancialRisks].[Pec_Lines_AKE_Data_Archive]
 AS
SELECT    distinct   ClassOfBusiness
      ,[CedantName]	 
	  ,[EntityName]
      ,[CountryName]
      ,[TradeSectorName]
 	  ,CapitalIQID
	  ,GCHPRating
	 ,ParentCapitalIqId
	 ,ParentEntityName
	 ,ParentGCHPRating
	  ,InceptionDate
     ,[ExpiryDate]
       ,SUM([LibertyExposure]) as GrossExposure
	   ,RiskCode
	  ,Paper
	  ,InforceDate
    FROM
	(
 SELECT distinct  EntityName, 
	   SPRating,
	   CedantName, 
	   ClassOfBusiness, 
	   CobId,
	   CountryName, 
	   SovereignRating,
	   TradeSectorName, 
	   InceptionDate,
	   ExpiryDate, 
	   TreatyType, 
	   CurrencyName, 
     GrossExposure, 
	--XL CALC
	CASE WHEN TreatyType = 'XL' THEN
		CASE WHEN GrossExposure > (Excess /Rate) THEN  
			 CASE WHEN (GrossExposure - Excess) > (TreatyLimit / Rate) THEN (TreatyLimit / Rate) ELSE GrossExposure - (Excess / Rate) END
		ELSE 0 END
	--QS CALC
	WHEN TreatyType = 'QS' THEN 
		CASE WHEN ISNULL(TreatyLimit / Rate,0) > 0 THEN
			CASE WHEN GrossExposure > (TreatyLimit / Rate) THEN (TreatyLimit / Rate) ELSE GrossExposure END
		ELSE GrossExposure END
	END 
	--NOW APPLY LINE SIZE
	* SignedLine * OurShare AS LibertyExposure,
	InforceDate
	,RiskCode,CapitalIQID	 ,GCHPRating
	 ,ParentCapitalIqId
	 ,ParentEntityName
	 ,ParentGCHPRating,Paper
FROM
(
	SELECT  distinct  tr.NewReference as SystemTreatyId, c.Name as CedantName,cob.Name as 'ClassOfBusiness', cob.CobId,
	e.RiskReference,e.InceptionDate,e.ExpiryDate, tr.Limit as TreatyLimit, cr.CurrencyName,
	 tcr.Rate, e.CurrencyId,
	 tr.AuditCode as TreatyType, tr.Excess, tr.SignedLine, tr.OurShare,
	CASE WHEN e.GrossExposure / cr.Rate > ISNULL(e.Limit / cr.Rate,0) AND ISNULL(e.Limit / cr.Rate,0) > 0 THEN ISNULL(e.Limit / cr.Rate,0) ELSE e.GrossExposure / cr.Rate END AS GrossExposure, 
	 en.EntityName, 
	 co.CountryName,
	 ts.TradeSectorName,
	 en.SPRating,
	 co.SovereignRating,
	 e.InforceDate
	 ,E.RiskCode
	 ,en.CapitalIqId
	 ,en.GCHPRating
	 ,en.ParentCapitalIqId
	 ,en.ParentEntityName
	 ,en.ParentGCHPRating
	 ,tr.Paper
	FROM FinancialRisks.archive_Exposures e
	--cedants
	LEFT JOIN FinancialRisks.archive_Cedant c on c.CedantID = e.CedantId
	--exposure riskcode mappings
	LEFT JOIN FinancialRisks.RiskCodeMappings riskCodeMappings on riskCodeMappings.riskCode = e.RiskCode 
	--join treaties to exposures on cedant, risk code group and inforcedate
	LEFT JOIN FinancialRisks.archive_Treaties tr on tr.CedantId = c.CedantID and tr.RiskCodeGroupId = riskCodeMappings.RiskCodeGroupId and tr.InforceDate = e.InforceDate
	--exposure currency data
	LEFT JOIN FinancialRisks.Currencies cr on cr.CurrencyId = e.CurrencyId
	--treaties currency data
	LEFT JOIN FinancialRisks.Currencies tcr on tcr.CurrencyId = tr.CurrencyId
	--reporting classes data
	LEFT JOIN FinancialRisks.COB cob on cob.CobId = e.CobId
	--obligor data
	LEFT JOIN FinancialRisks.archive_Entities en on en.EntityId = e.ObligorEntityId
	--country data
	LEFT JOIN FinancialRisks.archive_Countries co on co.CountryId = e.CountryId
	--trade sector data
	LEFT JOIN FinancialRisks.TradeSector ts on ts.TradeSectorID = en.TradeSectorId

	WHERE ((e.InceptionDate >= tr.InceptionDate AND e.InceptionDate <= tr.ExpiryDate) OR c.Name = 'LIB')
	AND LEN(en.EntityName) > 1 
) innerQuery
)A
WHERE -- old COBS before COB name changed GSGL-252 by Pawel P. from FP --ClassOfBusiness in ('Paris Trade Credit','Pecuniary Lines','Pecuniary Lines Surety')
	 CobId in (3,4,5) -- using COBIDs after COB name changed GSGL-252 by Pawel P. from FP
GROUP BY ClassOfBusiness, CobId,CedantName,EntityName,CountryName,TradeSectorName,CapitalIQID,GCHPRating
	 ,ParentCapitalIqId
	 ,ParentEntityName
	 ,ParentGCHPRating,InceptionDate,ExpiryDate,RiskCode,Paper,InforceDate