﻿CREATE VIEW [FinancialRisks].[vw_LossByExposure]
AS
SELECT ExposureId
        ,ObligorEntityId
        ,EntityName
        ,CapitalIqId
        ,Region
        ,SPRating
        ,GCHPRating
        ,LibertyRating
        ,CedantName
        ,ReportingClass
        ,ClassOfBusiness
        ,CobId
        ,CountryName
        ,ClassLGD
        ,SovereignRating
        ,TradeSectorName
        ,TradeSectorID
        ,InceptionDate
        ,ExpiryDate
        ,RateGroup
        ,CASE
			WHEN CedantName = 'LIB' THEN NULL
			ELSE TreatyType
        END AS TreatyType
        ,CurrencyName
        ,GrossExposure
        ,
        --XL CALC
        CASE
        WHEN TreatyType = 'XL' THEN
            CASE
            WHEN GrossExposure > ( Excess / Rate ) THEN
                CASE
                WHEN ( GrossExposure - Excess ) > ( TreatyLimit / Rate ) THEN ( TreatyLimit / Rate ) * SignedLine
                ELSE ( GrossExposure - ( Excess / Rate ) ) * SignedLine
                END
            ELSE 0
            END
        --QS CALC
        WHEN TreatyType IN ( 'QS', 'BA' ) THEN
            CASE
            WHEN Isnull(TreatyLimit / Rate, 0) > 0 THEN
                CASE
                WHEN GrossExposure > ( TreatyLimit / Rate ) THEN ( TreatyLimit / Rate ) * SignedLine
                ELSE GrossExposure * SignedLine
                END
            ELSE GrossExposure * SignedLine
            END
        ELSE GrossExposure -- For LMIE and GFR that don't have treatys attached
        END AS LibertyExposure
        ,InforceDate
        ,LocalId
FROM   (SELECT DISTINCT tr.NewReference AS SystemTreatyId
                        ,e.ExposureId
                        ,c.[Name]       AS CedantName
                        ,cob.ReportingClass
                        ,e.RiskReference
                        ,e.InceptionDate
                        ,e.ExpiryDate
                        ,tr.Limit       AS TreatyLimit
                        ,cr.CurrencyName
                        ,cr.RateGroup
                        ,tcr.Rate
                        ,e.CurrencyId
                        ,cob.CobId
                        ,cob.[Name]     AS ClassOfBusiness
                        ,tr.AuditCode   AS TreatyType
                        ,tr.Excess
                        ,tr.SignedLine
                        ,tr.OurShare
                        ,CASE
                            WHEN e.cobid NOT IN ( 1, 2, 5 ) THEN --COB IDs for GFR and PTC which allready have their Currencies FX rates applied
                            CASE
                                WHEN e.GrossExposure / cr.Rate > Isnull(e.Limit / cr.Rate, 0)
                                    AND Isnull(e.Limit / cr.Rate, 0) > 0 THEN Isnull(e.Limit / cr.Rate, 0)
                                ELSE e.GrossExposure / cr.Rate
                            END
                            ELSE e.GrossExposure
                        END            AS GrossExposure
                        ,CASE
                            WHEN en.EntityName LIKE '%Ministry%' THEN
                            CASE
                                WHEN en.EntityName LIKE '%' + co.CountryName + '%' THEN en.EntityName
                                ELSE en.EntityName + ' - ' + co.CountryName
                            END
                            ELSE en.EntityName
                        END            AS EntityName
                        ,
                        en.EntityId     AS ObligorEntityId
                        ,co.CountryName
                        ,co.Region
                        ,ts.TradeSectorName
                        ,ts.TradeSectorId
                        ,cob.ClassLGD
                        ,en.SPRating
                        ,en.GCHPRating
                        ,en.LibertyRating
                        ,en.CapitalIqId
                        ,co.SovereignRating
                        ,e.InforceDate
                        ,e.LocalId
        FROM   FinancialRisks.Exposures e
                --cedants
                LEFT JOIN FinancialRisks.Cedant c ON c.CedantID = e.CedantId
                --exposure riskcode mappings
                LEFT JOIN FinancialRisks.RiskCodeMappings riskCodeMappings  ON riskCodeMappings.riskCode = e.RiskCode
                --join treaties to exposures on cedant, risk code group and inforcedate
                LEFT JOIN FinancialRisks.Treaties tr
                    ON tr.CedantId = c.CedantID
                        AND tr.RiskCodeGroupId = riskCodeMappings.RiskCodeGroupId
                        AND tr.InforceDate = e.InforceDate
                --exposure currency data
                LEFT JOIN FinancialRisks.Currencies cr ON cr.CurrencyID = e.CurrencyID
                --treaties currency data
                LEFT JOIN FinancialRisks.Currencies tcr ON tcr.CurrencyID = tr.CurrencyID
                --reporting classes data
                LEFT JOIN FinancialRisks.COB cob ON cob.CobId = e.CobId
                --obligor data
                LEFT JOIN FinancialRisks.Entities en ON en.EntityId = e.ObligorEntityId
                --country data
                LEFT JOIN FinancialRisks.Countries co ON co.CountryId = e.CountryId
                --trade sector data
                LEFT JOIN FinancialRisks.TradeSector ts ON ts.TradeSectorID = en.TradeSectorId
        WHERE  ( ( e.InceptionDate >= tr.InceptionDate AND e.InceptionDate <= tr.ExpiryDate )
                OR c.[Name] = 'LIB' )
            AND e.RiskCode IN ( 'CF', 'CR', 'SB', 'SU', 'FG' )
            AND en.EntityName != 'No capital IQ ID Assigned.'
            AND Len(en.EntityName) > 1
            AND ( e.RiskReference IS NULL OR e.RiskReference <> '584110/01/18' )
	) innerQuery 




