﻿
/*********************************************/
Create   VIEW [FinancialRisks].[vw_Obligors]
 AS 
 SELECT [EntityId]
      ,[EntityName]
      ,[ParentEntityName]
      ,[CapitalIqId]
      ,[ParentCapitalIqId]
      ,[SPRating]
      ,[GCHPRating]
      ,[LibertyRating]
      ,[TradeSectorId]
      ,[ParentSPRating]
      ,[ParentGCHPRating]
      ,[ParentLibertyRating]
      ,[Domicile]
      ,[ParentDomicile]
	  ,[ObligorPseudonymId]
      ,[ObligorID]
      ,[ObligorPseudonym]
  FROM [FinancialRisks].[Entities] e
  left join [FinancialRisks].[ObligorPseudonym]  Op on e.EntityId = op.ObligorID