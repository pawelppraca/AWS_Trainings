﻿CREATE VIEW [FinancialRisks].[vw_Pec_Lines_autopoz]
AS
select * from [FinancialRisks].vw_Pec_Lines_iris
union
select * from [FinancialRisks].vw_Pec_Lines_genius