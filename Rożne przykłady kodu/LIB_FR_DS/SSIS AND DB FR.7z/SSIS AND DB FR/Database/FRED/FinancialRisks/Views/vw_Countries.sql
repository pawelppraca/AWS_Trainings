﻿
/*********************************************/
Create   VIEW [FinancialRisks].[vw_Countries]
 AS SELECT TOP (1000) c.[CountryId]
      ,[CountryName]
      ,[CountryCapitalIqId]
      ,[ISOCountryName]
      ,[Alpha3Code]
      ,[ISO2Code]
      ,[SovereignRating]
      ,[Region]
	  ,[CountryPseudonymId]
      ,cp.[CountryPseudonym]
  FROM [FinancialRisks].[Countries] C
  LEFT JOIN [FinancialRisks].[CountryPseudonym]  CP on c.CountryId = cp.CountryID