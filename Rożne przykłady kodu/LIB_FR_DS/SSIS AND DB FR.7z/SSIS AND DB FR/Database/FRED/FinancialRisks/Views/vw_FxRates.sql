﻿/*
ChangeLog:
-----------
2023-12-06 - by Pawel P. (FP) - GSGL-1390 - Adding new View of FX Rates - https://forge.lmig.com/issues/browse/GSGL-1390

*/
CREATE VIEW [FinancialRisks].[vw_FxRates]
	AS 
	            SELECT    									
                        DISTINCT    									
                        ccyFrom.CurrencyCode  AS 'Name'	,								
                        roe.ExchangeRate   AS 'rate',
						YEAR(roe.ExchangeRateDateKey) AS 'year'
            FROM    									
                        [sources].[vw_dwhr_Currencies] ccyFrom   									
                        INNER JOIN sources.vw_dwhr_ISOCurrencies ccyFromISO ON ccyFrom.ISOCurrencyKey = ccyFromISO.ISOCurrencyKey   									
                        INNER JOIN sources.vw_dwhr_ExchangeRates roe ON ccyFromISO.ISOCurrencyKey = roe.ISOCurrencyFromKey   									
                        INNER JOIN sources.vw_dwhr_ISOCurrencies ccyToISO ON roe.ISOCurrencyToKey = ccyToISO.ISOCurrencyKey   									
            WHERE    									
                        ccyToISO.ISOCurrencyCode = N'USD'   									
                      	AND roe.ExchangeRateTypeCode = N'[GAAP Plan]' 			