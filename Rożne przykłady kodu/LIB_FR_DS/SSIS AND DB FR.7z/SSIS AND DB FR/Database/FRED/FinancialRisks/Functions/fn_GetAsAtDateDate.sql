﻿CREATE FUNCTION [FinancialRisks].[fn_GetAsAtDateDate]
(
)
RETURNS DATETIME
AS
BEGIN
	DECLARE @AsAtDate DATETIME 


	SET @AsAtDate =  ISNULL((SELECT DISTINCT AsAtDate FROM FinancialRisks.AsAtDate),GETDATE())
	RETURN @AsAtDate

END