﻿CREATE FUNCTION [FinancialRisks].[fn_RemoveBadChar]
(
    @StringTobeCleaned Varchar(255)
    
)

RETURNS Varchar(255)
AS
BEGIN
	DECLARE @CleanedString Varchar(255)

-- remove    bad characters
-- Replace | with /


DECLARE @Pattern varchar(255) = '%['+ CHAR(13)+ CHAR(10)+CHAR(9)+CHAR(175)+Char(160) +Char(160)+']%';

--DECLARE @Stringtofix varchar(255);
 
--- first replace 
-- CHAR(9)   Horizontal Tab
-- CHAR(10)  New Line
-- CHAR(13)  Carraige Return
-- CHAR(160) Non Breaking space
-- CHAR(175) spacing macron - overline
-- with space 
WITH FixBadChars AS (SELECT @StringTobeCleaned as Stringtofix
                           , @StringTobeCleaned AS FixedString
							, 1 AS MyCounter
							, 1 as Id
               
                UNION ALL
                SELECT StringToFix
			   ,CAST( Stuff(FixedString, PatIndex(@Pattern
               ,FixedString COLLATE Latin1_General_BIN2), 1, ' ') AS varchar(255)) AS FixedString
				,MyCounter + 1 as MyCounter
				, Id
                FROM FixBadChars
               WHERE FixedString COLLATE Latin1_General_BIN2 LIKE @Pattern
				)

SELECT @CleanedString =REPLACE( replace(replace(LTRIM(RTRIM ( REPLACE(FixedString, '|', '/'))),'  ',' '+CHAR(1)) -- CHAR(1) is unlikely to appear, removes repeating spaces
      ,CHAR(1)+' ','')    ,CHAR(1),'')
FROM FixBadChars
WHERE MyCounter = 
        (SELECT MAX(MyCounter) 
        FROM FixBadChars Fixed
        WHERE Fixed.Id = FixBadChars.Id)
OPTION (MAXRECURSION 1000);

 --remove specfic characters replace with nothing
 -- re-rest pattern

 SET @Pattern ='%[€"¥„“¿*#?`÷?\”]%';

WITH FixBadChars AS (SELECT @CleanedString as Stringtofix
                           , @CleanedString AS FixedString
							, 1 AS MyCounter
							, 1 as Id
               
                UNION ALL
                SELECT StringToFix
			   ,CAST( Stuff(FixedString, PatIndex(@Pattern
               ,FixedString COLLATE Latin1_General_BIN2), 1, '') AS varchar(255)) AS FixedString
				,MyCounter + 1 as MyCounter
				, Id
                FROM FixBadChars
               WHERE FixedString COLLATE Latin1_General_BIN2 LIKE @Pattern
				)

SELECT @CleanedString = REPLACE( replace(replace (LTRIM(RTRIM ( FixedString)),'  ',' '+CHAR(1)) -- CHAR(1) is unlikely to appear, removes repeating spaces
      ,CHAR(1)+' ','')    ,CHAR(1),'')
FROM FixBadChars
WHERE MyCounter = 
        (SELECT MAX(MyCounter) 
        FROM FixBadChars Fixed
        WHERE Fixed.Id = FixBadChars.Id)
OPTION (MAXRECURSION 1000);

RETURN @CleanedString

END

GO