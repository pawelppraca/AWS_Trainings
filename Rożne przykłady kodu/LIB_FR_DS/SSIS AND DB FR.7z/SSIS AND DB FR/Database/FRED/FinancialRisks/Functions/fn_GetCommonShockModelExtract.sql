﻿
CREATE FUNCTION FinancialRisks.fn_GetCommonShockModelExtract(
@inforcedate datetime
)
RETURNS TABLE 
AS 
RETURN
(
	WITH
			RCTE AS
	       (
	              SELECT  TradeSectorParentID, TradeSectorID, 1 AS Lvl
				  FROM FinancialRisks.TradeSector
	                 WHERE TradeSectorParentID <> 0
	              UNION ALL
	              SELECT rh.TradeSectorParentID, rc.TradeSectorID, Lvl+1 AS Lvl 
	              FROM FinancialRisks.TradeSector rh
	              INNER JOIN RCTE rc ON rh.TradeSectorID = rc.TradeSectorParentID
	                 WHERE rh.TradeSectorParentID <> 0
	       )
	       ,CTE_RN AS 
	       (
	              SELECT *, ROW_NUMBER() OVER (PARTITION BY r.TradeSectorID ORDER BY r.Lvl DESC) RN
	              FROM RCTE r
	       ), CTE_UltimateTS AS
		   (
				  SELECT c.TradeSectorID,ts2.TradeSectorName,c.TradeSectorParentID AS UltimateParentID,ts.TradeSectorName AS UltimateParentName FROM CTE_RN c
				  INNER JOIN FinancialRisks.TradeSector ts ON ts.TradeSectorID = c.TradeSectorParentID
				  INNER JOIN FinancialRisks.TradeSector ts2 ON ts2.TradeSectorID = c.TradeSectorID
				  WHERE RN=1 
		   ), CTE_ClassAvgPD AS
		   (
				  SELECT ClassOfBusinessID,
				  avg(CAST([1_Yr_PD] as float)) AS [1_Yr_Class_Avg],
				  avg(CAST([1_Yr_PD] AS float)) AS [2_Yr_Class_Avg],
				  avg(CAST([1_Yr_PD] AS float)) AS [3_Yr_Class_Avg],
				  avg(CAST([1_Yr_PD] AS float)) AS [4_Yr_Class_Avg],
				  avg(CAST([1_Yr_PD] AS float)) AS [5_Yr_Class_Avg],
				  avg(CAST([1_Yr_PD] AS float)) AS [6_Yr_Class_Avg],
				  avg(CAST([1_Yr_PD] AS float)) AS [7_Yr_Class_Avg],
				  avg(CAST([1_Yr_PD] AS float)) AS [8_Yr_Class_Avg],
				  avg(CAST([1_Yr_PD] AS float)) AS [9_Yr_Class_Avg],
				  avg(CAST([1_Yr_PD] AS float)) AS [10_Yr_Class_Avg]
				  FROM
				  (
				  SELECT CASE WHEN CobId IN (1,2) THEN 8 ELSE CobId END AS ClassOfBusinessID, ISNULL(ISNULL(r.RatingType,s.RatingType),t.RatingType) AS FinalRating
				  FROM FinancialRisks.vw_LossByExposure lbe
				  LEFT JOIN FinancialRisks.Ratings r on r.RatingType = lbe.SPRating
				  LEFT JOIN FinancialRisks.Ratings s on s.RatingType = lbe.GCHPRating
				  LEFT JOIN FinancialRisks.Ratings t on t.RatingType = lbe.LibertyRating
				  LEFT JOIN FinancialRisks.RatingDefaultProbability pr ON pr.RatingID = r.RatingID
				  LEFT JOIN FinancialRisks.RatingDefaultProbability pr2 ON pr2.RatingID = s.RatingID
				  LEFT JOIN FinancialRisks.RatingDefaultProbability pr3 ON pr3.RatingID = t.RatingID
				  WHERE lbe.InforceDate = @inforcedate
				  ) p
				  INNER JOIN FinancialRisks.Industry_PD_Matrix im ON im.Rating = p.FinalRating
				  WHERE im.IndustryNo = 0 AND FinalRating IS NOT NULL AND FinalRating <> 'NR'
				  GROUP BY ClassOfBusinessID
			)
	
	--By class
	SELECT ObligorEntityID,ClassOfBusiness,CobId,EntityName,CapitalIQID,Region,TradeSectorID,Industry,FinalRating,ClassLGD,NetExposure,
	[PD1],[PD2],[PD3],[PD4],[PD5],[PD6],[PD7],[PD8],[PD9],[PD10] 
	FROM
	(
	SELECT ROW_NUMBER() OVER (PARTITION BY x.CobId,x.ObligorEntityID ORDER BY NetExposure DESC) AS Rnk,x.ObligorEntityID,x.ClassOfBusiness,x.CobID,x.EntityName,x.CapitalIQID, x.Region, im.TradeSectorID,im.Industry,x.FinalRating, x.ClassLGD, x.NetExposure,
	ISNULL([1_Yr_PD],[1_Yr_Class_Avg]) AS [PD1],
	ISNULL([2_Yr_PD],[2_Yr_Class_Avg]) AS [PD2],
	ISNULL([3_Yr_PD],[3_Yr_Class_Avg]) AS [PD3],
	ISNULL([4_Yr_PD],[4_Yr_Class_Avg]) AS [PD4],
	ISNULL([5_Yr_PD],[5_Yr_Class_Avg]) AS [PD5],
	ISNULL([6_Yr_PD],[6_Yr_Class_Avg]) AS [PD6],
	ISNULL([7_Yr_PD],[7_Yr_Class_Avg]) AS [PD7],
	ISNULL([8_Yr_PD],[8_Yr_Class_Avg]) AS [PD8],
	ISNULL([9_Yr_PD],[9_Yr_Class_Avg]) AS [PD9],
	ISNULL([10_Yr_PD],[10_Yr_Class_Avg]) AS [PD10]
	FROM
	(
	SELECT ObligorEntityId, ClassOfBusiness, CobId, EntityName, CapitalIqId, Region,
	ISNULL(ISNULL(uts.UltimateParentID,lbe.TradeSectorID),0) UltimateTradeSectorID, lbe.TradeSectorName,
	ISNULL(ISNULL(r.RatingType,s.RatingType),t.RatingType) AS FinalRating,
	lbe.ClassLGD,
	SUM(lbe.LibertyExposure) as NetExposure
	FROM FinancialRisks.vw_LossByExposure lbe
	LEFT JOIN FinancialRisks.Ratings r on r.RatingType = lbe.SPRating
	LEFT JOIN FinancialRisks.Ratings s on s.RatingType = lbe.GCHPRating
	LEFT JOIN FinancialRisks.Ratings t on t.RatingType = lbe.LibertyRating
	LEFT JOIN FinancialRisks.RatingDefaultProbability pr ON pr.RatingID = r.RatingID
	LEFT JOIN FinancialRisks.RatingDefaultProbability pr2 ON pr2.RatingID = s.RatingID
	LEFT JOIN FinancialRisks.RatingDefaultProbability pr3 ON pr3.RatingID = t.RatingID
	LEFT JOIN CTE_UltimateTS uts ON uts.TradeSectorID = lbe.TradeSectorID
	WHERE lbe.InforceDate = @inforcedate
	GROUP BY ObligorEntityID, ClassOfBusiness,cobId, EntityName, CapitalIQID, Region, ClassLGD,
	lbe.TradeSectorID,uts.UltimateParentID,lbe.TradeSectorName,r.RatingType,s.RatingType,t.RatingType
	HAVING SUM(lbe.LibertyExposure) > 0
	) x
	INNER JOIN CTE_ClassAvgPD cpd ON cpd.ClassOfBusinessID = (CASE WHEN x.CobId IN (1,2) THEN 8 ELSE x.CobId END)
	LEFT JOIN FinancialRisks.Industry_PD_Matrix im ON im.TradeSectorID = x.UltimateTradeSectorID AND im.Rating = x.FinalRating
	) xx
	WHERE Rnk = 1
)