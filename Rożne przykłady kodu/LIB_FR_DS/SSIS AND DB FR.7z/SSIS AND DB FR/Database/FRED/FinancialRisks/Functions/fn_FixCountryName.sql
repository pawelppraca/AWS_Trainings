﻿CREATE FUNCTION [FinancialRisks].[fn_FixCountryName]
(
	@CountryName NVARCHAR(255)
)
RETURNS NVARCHAR(255)
/**********************************************************************************************************
* SP Name:[FinancialRisks].[fn_FixCountryName]
* Parameters:
*		 @CountryName NVARCHAR(255)
*  
* Purpose:	This functions updates country name by removing bad charcters 
*              
* Revision Date/Time:
2023-04-23	Piotr Fedczyszyn	Creation 
*
**********************************************************************************************************/
AS
BEGIN
	IF @CountryName = '?' RETURN '?'   -- avoid to leave empty country
	RETURN [FinancialRisks].fn_RemoveBadChar(@CountryName);

END
