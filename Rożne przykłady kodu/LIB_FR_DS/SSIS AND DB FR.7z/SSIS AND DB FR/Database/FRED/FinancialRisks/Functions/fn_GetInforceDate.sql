﻿
CREATE FUNCTION [FinancialRisks].[fn_GetInforceDate]
(
)
RETURNS DATETIME
AS
BEGIN
	DECLARE @Quarter INT, @Year INT, @InforceDate DATETIME ,@LastInforceDate DATETIME

	Select @LastInforceDate = (SELECT distinct max([LastRunTime])FROM [FinancialRisks].[AddNewData])

	SET @Quarter = DATEPART(QUARTER, @LastInforceDate)
	SET @Year = DATEPART(YEAR, @LastInforceDate) 

	SELECT @InforceDate =  CASE @Quarter
		   WHEN 1 THEN CAST(CONCAT(@Year,'-4','-01') AS DATETIME)

		   WHEN 2 THEN CAST(CONCAT(@Year,'-7','-01') AS DATETIME)

		   WHEN 3 THEN CAST(CONCAT(@Year,'-10','-01') AS DATETIME)

		   WHEN 4 THEN CAST(CONCAT(@Year +1,'-1','-01') AS DATETIME)
		   END

	RETURN @InforceDate

END