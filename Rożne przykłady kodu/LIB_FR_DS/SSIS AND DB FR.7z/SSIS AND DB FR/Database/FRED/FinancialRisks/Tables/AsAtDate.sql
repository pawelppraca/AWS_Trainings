﻿CREATE TABLE [FinancialRisks].[AsAtDate]
(
	[AsAtDate] DATETIME NULL, 
    [DefaultFlag] INT NULL
)
