﻿CREATE TABLE [FinancialRisks].[archive_Exposures] (
    [ExposureId]      INT           IDENTITY (1, 1) NOT NULL,
    [CedantId]        INT           NULL,
    [CobId]           INT           NULL,
    [RiskReference]   VARCHAR (25)  NULL,
    [CurrencyId]      INT           NULL,
    [Year]            INT           NULL,
    [DataQuarter]     INT           NULL,
    [AssuredEntityId] INT           NULL,
    [RiskCode]        VARCHAR (5)   NULL,
    [LeadSyndicate]   VARCHAR (150) NULL,
    [CountryId]       INT           NULL,
    [InceptionDate]   DATETIME      NULL,
    [ExpiryDate]      DATETIME      NULL,
    [Limit]           NUMERIC (18)  NULL,
    [UsdLimit]        NUMERIC (18)  NULL,
    [GrossPremium]    NUMERIC (18)  NULL,
    [GrossExposure]   NUMERIC (18)  NULL,
    [ObligorEntityId] INT           NULL,
    [InforceDate]     DATETIME      NULL,
    [Source]          VARCHAR (250) NULL
);

