﻿CREATE TABLE [FinancialRisks].[Pec_Lines_Client Map] (
    [UWRef]           NVARCHAR (255) NULL,
    [ContractName]    NVARCHAR (255) NULL,
    [ReassuredGroup]  NVARCHAR (255) NULL,
    [Client ultimate] NVARCHAR (255) NULL
);

