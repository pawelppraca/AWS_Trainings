﻿CREATE TABLE [FinancialRisks].[RiskCodeMappings] (
    [RiskCodeMappingId]  INT          NOT NULL,
    [RiskCode]           VARCHAR (5)  NULL,
    [RiskCodeGroupId]    INT          NULL,
    [RiskCodeGroupAbbrv] VARCHAR (20) NULL,
    [RiskCodeGroupDesc]  VARCHAR (20) NULL,
    CONSTRAINT [PK_RiskCodeMappings] PRIMARY KEY CLUSTERED ([RiskCodeMappingId] ASC)
);

