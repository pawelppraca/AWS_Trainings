﻿CREATE TABLE [FinancialRisks].[archive_ObligorPseudonym] (
    [ObligorID]        INT           NULL,
    [ObligorPseudonym] VARCHAR (255) NULL
);

