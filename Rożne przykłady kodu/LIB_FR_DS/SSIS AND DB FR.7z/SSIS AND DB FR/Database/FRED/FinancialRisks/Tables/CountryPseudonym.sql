﻿CREATE TABLE [FinancialRisks].[CountryPseudonym] (
    [CountryPseudonymId] INT           IDENTITY (1, 1) NOT NULL,
    [CountryID]          INT           NULL,
    [CountryPseudonym]   VARCHAR (255) NULL,
    CONSTRAINT [PK_CountryPseudonym] PRIMARY KEY CLUSTERED ([CountryPseudonymId] ASC)  ,
    CONSTRAINT [FK_CountryPseudonym_CountryID] FOREIGN KEY ([CountryID]) REFERENCES [FinancialRisks].[Countries] ([CountryId]),
    CONSTRAINT [CountryPseudonym_Unique] UNIQUE NONCLUSTERED ([CountryPseudonym] ASC)
);

