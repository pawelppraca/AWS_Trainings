﻿CREATE TABLE [FinancialRisks].[CountryPseudonymsTemp]
  (
     [UnmappedCountryName] [VARCHAR](100)   NULL,
     [PseudonymOrNew]      [VARCHAR](10)    NULL,
     [MappedCountryName]   [VARCHAR](100)   NULL,
     [CountryName]         [VARCHAR](100)   NULL,
     [CountryCapitalIqId]  [VARCHAR](100)   NULL,
     [ISOCountryName]      [VARCHAR](100)   NULL,
     [Alpha3Code]          [VARCHAR](3)     NULL,
     [ISO2Code]            [VARCHAR](2)     NULL,
     [SovereignRating]     [VARCHAR](10)    NULL,
  )
ON [PRIMARY] 