﻿CREATE TABLE [FinancialRisks].[archive_Entities] (
    [EntityId]            INT           IDENTITY (1, 1) NOT NULL,
    [EntityName]          VARCHAR (255) NOT NULL,
    [ParentEntityName]    VARCHAR (255) NULL,
    [CapitalIqId]         VARCHAR (30)  NULL,
    [ParentCapitalIqId]   VARCHAR (30)  NULL,
    [SPRating]            VARCHAR (30)  NULL,
    [GCHPRating]          VARCHAR (30)  NULL,
    [LibertyRating]       VARCHAR (30)  NULL,
    [TradeSectorId]       INT           NULL,
    [ParentSPRating]      VARCHAR (30)  NULL,
    [ParentGCHPRating]    VARCHAR (30)  NULL,
    [ParentLibertyRating] VARCHAR (30)  NULL,
    [Domicile]            VARCHAR (100) NULL,
    [ParentDomicile]      VARCHAR (100) NULL
);

