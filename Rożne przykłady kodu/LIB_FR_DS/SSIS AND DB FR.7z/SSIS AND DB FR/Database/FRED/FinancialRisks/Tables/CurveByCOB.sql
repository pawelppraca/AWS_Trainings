﻿CREATE TABLE [FinancialRisks].[CurveByCOB] (
    [ClassOfBusinessID] INT        NULL,
    [SimNo]             INT        NULL,
    [SimPeriod]         INT        NULL,
    [Loss]              FLOAT (53) NULL,
    [InforceDate]       DATETIME   NULL,
	[ReinstatedLoss] FLOAT NULL
);

