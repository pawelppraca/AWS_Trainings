﻿CREATE TABLE [FinancialRisks].[TradeSector] (
    [TradeSectorID]       INT           IDENTITY (1, 1) NOT NULL,
    [TradeSectorName]     VARCHAR (100) NULL,
    [AKETradeSector]      VARCHAR (28)  NULL,
    [TradeSectorParentID] INT           NULL,
    [MappingInd]          BIT           NULL,
    CONSTRAINT [PK_TradeSector] PRIMARY KEY CLUSTERED ([TradeSectorID] ASC)
);

