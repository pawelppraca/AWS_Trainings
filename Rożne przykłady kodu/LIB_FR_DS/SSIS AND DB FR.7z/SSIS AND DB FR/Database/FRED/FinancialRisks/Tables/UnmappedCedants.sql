﻿CREATE TABLE [FinancialRisks].[UnmappedCedants] (
    [QueueID]            BIGINT        NOT NULL,
    [Source]             VARCHAR (250) NULL,
    [UnmappedCedantName] VARCHAR (150) NULL,
    [MappedCedantName]   VARCHAR (1)   NOT NULL,
    [NewCedant]          VARCHAR (1)   NOT NULL,
    [Queue]              VARCHAR (9)   NOT NULL
);

