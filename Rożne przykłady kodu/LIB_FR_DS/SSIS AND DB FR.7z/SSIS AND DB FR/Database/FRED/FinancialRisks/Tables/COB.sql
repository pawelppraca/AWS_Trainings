﻿CREATE TABLE [FinancialRisks].[COB] (
    [CobId]          INT          IDENTITY (1, 1) NOT NULL,
    [Name]           VARCHAR (50) NOT NULL,
    [ReportingClass] VARCHAR (50) NULL,
    [ClassLGD]       FLOAT (53)   NULL,
     CONSTRAINT [PK_COB] PRIMARY KEY CLUSTERED ([CobId] ASC)  )

