﻿CREATE TABLE [FinancialRisks].[Countries] 
(
    [CountryId]          INT           IDENTITY (1, 1) NOT NULL,
    [CountryName]        VARCHAR (100) NOT NULL,
    [CountryCapitalIqId] VARCHAR (100) NULL,
    [ISOCountryName]     VARCHAR (100) NULL,
    [Alpha3Code]         VARCHAR (3)   NULL,
    [ISO2Code]           VARCHAR (2)   NULL,
    [SovereignRating]    VARCHAR (10)  NULL,
    [CountryPseudonym]   VARCHAR (MAX) NULL,
    [Region]             VARCHAR (255) NULL,

    CONSTRAINT [PK_Countries] PRIMARY KEY CLUSTERED ([CountryId] ASC)  ,
    CONSTRAINT [CountryName_Unique]         UNIQUE NONCLUSTERED (CountryName ASC),
)
GO 
CREATE  UNIQUE NONCLUSTERED INDEX [CountryCapitalIqId_Unique] ON [FinancialRisks].[Countries] 
    (CountryCapitalIqId ASC) 
WHERE CountryCapitalIqId IS NOT NULL 

