﻿CREATE TABLE [FinancialRisks].[CSM_Model_OutputV2](
	[SimulationID] [int] NULL,
	[DefaultSimNo] [varchar](50) NULL,
	[Entity] [int] NULL,
	[ClassID] [int] NULL,
	[DefaultYear] [varchar](50) NULL,
	[SimLGD] [varchar](100) NULL,
	[InforceDate] [datetime] NULL
) ON [PRIMARY]
GO
CREATE CLUSTERED INDEX [IX_CSM_Model_OutputV2] ON [FinancialRisks].[CSM_Model_OutputV2]
(
	[Entity] ASC,
	[ClassID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO