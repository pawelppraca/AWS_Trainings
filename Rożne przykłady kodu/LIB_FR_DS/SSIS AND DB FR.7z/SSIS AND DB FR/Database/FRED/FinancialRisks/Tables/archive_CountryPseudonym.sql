﻿CREATE TABLE [FinancialRisks].[archive_CountryPseudonym] (
    [CountryID]        INT           NULL,
    [CountryPseudonym] VARCHAR (255) NULL
);

