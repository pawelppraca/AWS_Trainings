﻿CREATE TABLE [FinancialRisks].[Ironshore_Data_Queue] (
    [QueueId]         INT           IDENTITY (1, 1) NOT NULL,
    [riskReference]   VARCHAR (24)  NULL,
    [country]         VARCHAR (150) NULL,
    [countryId]       INT           NULL,
    [inception_date]  DATETIME      NULL,
    [expiry_date]     DATETIME      NULL,
    [obligor]         VARCHAR (150) NULL,
    [entityId]        INT           NULL,
    [GrossExposure]   FLOAT (53)    NULL,
    [LimitLiability]  FLOAT (53)    NULL,
    [Insured]         VARCHAR (150) NULL,
    [TransactionType] VARCHAR (50)  NULL,
    [InforceDate]     DATETIME      NULL,
    [Source]          VARCHAR (250) NULL,
    [UserNotified]    VARCHAR (3)   CONSTRAINT [df_UserNotified] DEFAULT  ('No') NOT NULL,
    [ObligorPseudID]  INT           NULL,
    [CountryPseudID]  INT           NULL,
    [OriginalEntityinFile]          NVARCHAR(250) NULL,
    [OriginalCountryinFile]         NVARCHAR(250) NULL

);

