﻿CREATE TABLE [FinancialRisks].[Ironshore_Data] (
    [IronshoreDataId] INT           IDENTITY (1, 1) NOT NULL,
    [riskReference]   VARCHAR (24)  NULL,
    [country]         VARCHAR (150) NULL,
    [countryId]       INT           NULL,
    [inception_date]  DATETIME      NULL,
    [expiry_date]     DATETIME      NULL,
    [obligor]         VARCHAR (150) NULL,
    [entityId]        INT           NULL,
    [GrossExposure]   FLOAT (53)    NULL,
    [LimitLiability]  FLOAT (53)    NULL,
    [Insured]         VARCHAR (150) NULL,
    [RiskCode]        VARCHAR (50)  NULL,
    [InforceDate]     DATETIME      NULL,
    [ObligorPseudID]  INT           NULL,
    [CountryPseudID]  INT           NULL,
    [OriginalEntityinFile]          NVARCHAR(250) NULL,
    [OriginalCountryinFile]         NVARCHAR(250) NULL

);

