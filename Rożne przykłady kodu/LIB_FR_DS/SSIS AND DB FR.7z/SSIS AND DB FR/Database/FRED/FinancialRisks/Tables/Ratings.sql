﻿CREATE TABLE [FinancialRisks].[Ratings] (
    [RatingID]            INT             IDENTITY (1, 1) NOT NULL,
    [RatingType]          VARCHAR (255)   NULL,
    [RatingIndex]         INT             NULL,
    [DefaultProbability]  NUMERIC (18, 6) NULL,
    [ReferenceUploadDate] DATETIME        NULL,
    CONSTRAINT [PK_Ratings] PRIMARY KEY CLUSTERED ([RatingID] ASC)
);

