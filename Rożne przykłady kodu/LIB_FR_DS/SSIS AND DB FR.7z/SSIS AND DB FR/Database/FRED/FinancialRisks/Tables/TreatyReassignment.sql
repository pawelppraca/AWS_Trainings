﻿CREATE TABLE [FinancialRisks].[TreatyReassignment] (
    [CedantName]           VARCHAR (255) NOT NULL,
    [ReportingClass]       VARCHAR (255) NOT NULL,
    [TreatyReference]      VARCHAR (255) NOT NULL,
    [Class]                VARCHAR (255) NOT NULL,
    [ActualReportingClass] VARCHAR (255) NOT NULL,
    [Changing]             VARCHAR (255) NOT NULL,
    [InforceDate]          DATETIME2 (7) NOT NULL,

);
GO

CREATE UNIQUE NONCLUSTERED INDEX [TreatyReassignment4GenerateLossByExposure_Unique] ON	 [FinancialRisks].[TreatyReassignment] 
	(CedantName		  ASC
	,TreatyReference  ASC
	,InforceDate 	  ASC
	-- fitered on it ,Changing		  ASC
	)
	WHERE Changing = 'YES' ;



 