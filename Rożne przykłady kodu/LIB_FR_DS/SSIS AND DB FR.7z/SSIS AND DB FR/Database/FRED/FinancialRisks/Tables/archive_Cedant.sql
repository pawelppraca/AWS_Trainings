﻿CREATE TABLE [FinancialRisks].[archive_Cedant] (
    [CedantId] INT           IDENTITY (1, 1) NOT NULL,
    [Name]     VARCHAR (150) NULL
);

