﻿CREATE TABLE [FinancialRisks].[ObligorPseudonym] (
    [ObligorPseudonymId] INT           IDENTITY (1, 1) NOT NULL,
    [ObligorID]          INT           NULL,
    [ObligorPseudonym]   VARCHAR (255) NULL,
    CONSTRAINT [PK_ObligorPseudonym] PRIMARY KEY CLUSTERED ([ObligorPseudonymId] ASC),
    CONSTRAINT [FK_ObligorPseudonym] FOREIGN KEY ([ObligorID]) REFERENCES [FinancialRisks].[Entities] ([EntityId]),
    CONSTRAINT [ObligorPseudonym_Unique] UNIQUE NONCLUSTERED ([ObligorPseudonym] ASC)
);

