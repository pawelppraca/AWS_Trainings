﻿CREATE TABLE [FinancialRisks].[Cedant] (
    [CedantId] INT           IDENTITY (1, 1) NOT NULL,
    [Name]     VARCHAR (150) NULL,
    CONSTRAINT [PK_Cedant] PRIMARY KEY CLUSTERED ([CedantId] ASC)  )


