﻿CREATE TABLE [FinancialRisks].[audit_LogSSISPackage] (
    [LogID]            INT              IDENTITY (1, 1) NOT NULL,
    [ParentLogID]      INT              NULL,
    [Description]      VARCHAR (50)     NULL,
    [PackageName]      VARCHAR (50)     NOT NULL,
    [PackageGuid]      UNIQUEIDENTIFIER NOT NULL,
    [MachineName]      VARCHAR (50)     NOT NULL,
    [ExecutionGuid]    UNIQUEIDENTIFIER NOT NULL,
    [Operator]         VARCHAR (50)     NOT NULL,
    [StartTime]        DATETIME         NOT NULL,
    [EndTime]          DATETIME         NULL,
    [Status]           TINYINT          NOT NULL,
    [FailureTask]      NVARCHAR (2048)  NULL,
    [FileName]         VARCHAR (50)     NULL,
    [FileRowCount]     INT              NULL,
    [MappedRowCount]   INT              NULL,
    [UnmappedRowCount] INT              NULL,
    CONSTRAINT [PK_ExecutionLog] PRIMARY KEY CLUSTERED ([LogID] ASC)
);

