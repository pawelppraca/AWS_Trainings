﻿CREATE TABLE [FinancialRisks].[fullCurve] (
    [SimNo]       INT        NULL,
    [SimPeriod]   INT        NULL,
    [Loss]        FLOAT (53) NULL,
    [InforceDate] DATETIME   NULL
);

