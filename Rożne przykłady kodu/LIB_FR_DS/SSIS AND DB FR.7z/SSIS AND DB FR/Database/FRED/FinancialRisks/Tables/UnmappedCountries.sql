﻿CREATE TABLE [FinancialRisks].[UnmappedCountries] (
    [QueueID]             BIGINT        NOT NULL,
    [Source]              VARCHAR (250) NULL,
    [UnmappedCountryName] VARCHAR (150) NULL,
    [MappedCountryName]   VARCHAR (1)   NOT NULL,
    [NewPseudonym]        VARCHAR (1)   NOT NULL,
    [Queue]               VARCHAR (9)   NOT NULL
);

