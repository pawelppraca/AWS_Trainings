﻿CREATE TABLE [FinancialRisks].[audit_ServiceErrorLog] (
    [ErrorLogID]    INT            IDENTITY (1, 1) NOT NULL,
    [ActiveCode]    VARCHAR (200)  NULL,
    [ActiveObject]  VARCHAR (200)  NULL,
    [ErrorText]     VARCHAR (1000) NOT NULL,
    [NetworkUserId] VARCHAR (128)  NULL,
    [StackTrace]    VARCHAR (4000) NULL,
    [WorkstationId] VARCHAR (128)  NULL,
    [CreatedBy]     VARCHAR (50)   NOT NULL,
    [CreatedDate]   DATETIME       NOT NULL,
    [ModifiedBy]    VARCHAR (50)   NOT NULL,
    [ModifiedDate]  DATETIME       NOT NULL,
    CONSTRAINT [PK_ErrorLog] PRIMARY KEY CLUSTERED ([ErrorLogID] ASC) WITH (FILLFACTOR = 90)
);

