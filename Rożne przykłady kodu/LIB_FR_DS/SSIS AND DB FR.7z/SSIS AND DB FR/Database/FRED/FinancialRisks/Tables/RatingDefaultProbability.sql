﻿CREATE TABLE [FinancialRisks].[RatingDefaultProbability] (
    [RatingID]            INT             NULL,
    [AveragePD]           NUMERIC (18, 5) NULL,
    [Y1]                  NUMERIC (18, 5) NULL,
    [Y2]                  NUMERIC (18, 5) NULL,
    [Y3]                  NUMERIC (18, 5) NULL,
    [Y4]                  NUMERIC (18, 5) NULL,
    [Y5]                  NUMERIC (18, 5) NULL,
    [Y6]                  NUMERIC (18, 5) NULL,
    [Y7]                  NUMERIC (18, 5) NULL,
    [Y8]                  NUMERIC (18, 5) NULL,
    [Y9]                  NUMERIC (18, 5) NULL,
    [Y10]                 NUMERIC (18, 5) NULL,
    [Y11]                 NUMERIC (18, 5) NULL,
    [Y12]                 NUMERIC (18, 5) NULL,
    [Y13]                 NUMERIC (18, 5) NULL,
    [Y14]                 NUMERIC (18, 5) NULL,
    [Y15]                 NUMERIC (18, 5) NULL,
    [ReferenceUploadDate] DATETIME        NULL
);

