﻿CREATE TABLE [FinancialRisks].[UnmappedObligors] (
    [QueueID]             BIGINT        NOT NULL,
    [Source]              VARCHAR (250)		NULL,
    [UnmappedObligorName] VARCHAR (255)		NULL,
    [MappedObligorName]   VARCHAR (1)   NOT NULL,
    [NewPseudonym]        VARCHAR (1)   NOT NULL,
    [Queue]               VARCHAR (9)   NOT NULL,
	TotalGrossExposure	  NUMERIC (18)		NULL,
	CurrencyName		  VARCHAR (9)		NULL,
	USD_TotalExposure	  NUMERIC (18)		NULL
);

