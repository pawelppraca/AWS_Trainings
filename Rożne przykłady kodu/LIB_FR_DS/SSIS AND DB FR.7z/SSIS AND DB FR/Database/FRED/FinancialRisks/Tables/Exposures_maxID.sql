﻿CREATE TABLE [FinancialRisks].[Exposures_maxID] (
    [ExposureID] INT NULL
);

