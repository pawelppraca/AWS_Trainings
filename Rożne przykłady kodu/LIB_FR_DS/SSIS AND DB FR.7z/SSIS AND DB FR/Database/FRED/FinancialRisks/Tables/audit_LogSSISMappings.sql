﻿CREATE TABLE [FinancialRisks].[audit_LogSSISMappings] (
    [LogID]       INT          IDENTITY (1, 1) NOT NULL,
    [InforceDate] DATETIME     NOT NULL,
    [Type]        VARCHAR (50) NOT NULL,
    [Unmapped]    INT          NOT NULL,
    CONSTRAINT [LogID] PRIMARY KEY CLUSTERED ([LogID] ASC)
);

