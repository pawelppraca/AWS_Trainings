﻿CREATE TABLE [FinancialRisks].[AddNewData] (
    [PackageName]  NVARCHAR (50) NULL,
    [AddNewData]   NVARCHAR (5)  NULL,
    [LastRunTime]  DATETIME      NULL,
    [FormatErrors] VARCHAR (5)   NULL
);

