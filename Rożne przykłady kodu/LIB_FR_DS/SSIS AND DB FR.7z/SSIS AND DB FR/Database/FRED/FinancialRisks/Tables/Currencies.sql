﻿CREATE TABLE [FinancialRisks].[Currencies] (
    [CurrencyId]   INT         IDENTITY (1, 1) NOT NULL,
    [CurrencyName] VARCHAR (3) NOT NULL,
    [Rate]         FLOAT (53)  NOT NULL,
    [RateGroup]    INT         NULL,
    CONSTRAINT Currencies_PK PRIMARY KEY CLUSTERED ([CurrencyId] ASC)
);

