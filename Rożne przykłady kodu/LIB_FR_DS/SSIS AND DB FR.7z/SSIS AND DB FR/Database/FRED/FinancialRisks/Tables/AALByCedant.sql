﻿CREATE TABLE [FinancialRisks].[AALByCedant] (
    [ClassOfBusinessID] INT            NOT NULL,
    [SystemTreatyID]    NVARCHAR (50)  NOT NULL,
    [CedantName]        NVARCHAR (150) NULL,
    [LossNT]            FLOAT (53)     NOT NULL,
    [LossNT_Unmatched]  FLOAT (53)     NOT NULL,
    [LossNT_NotRated]   FLOAT (53)     NOT NULL,
    [InforceDate]       DATETIME       NULL
);

