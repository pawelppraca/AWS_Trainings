﻿CREATE TABLE [FinancialRisks].[RemovedPseudomyms](
	[Entityid] [int] NULL,
	[obligorpseudonymid] [int] NULL,
	[obligorName] [varchar](max) NULL,
	[NewEntityid] [int] NULL,
	[Run] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]