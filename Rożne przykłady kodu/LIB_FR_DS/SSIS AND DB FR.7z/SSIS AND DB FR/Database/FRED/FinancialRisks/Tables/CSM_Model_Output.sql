﻿CREATE TABLE [FinancialRisks].[CSM_Model_Output] (
    [SimulationID] INT           NOT NULL,
    [DefaultSimNo] INT           NOT NULL,
    [Entity]       INT           NOT NULL,
    [ClassID]      NVARCHAR (50) NOT NULL,
    [DefaultYear]  NVARCHAR (50) NOT NULL,
    [SimLGD]       FLOAT (53)    NOT NULL
);

