﻿CREATE TABLE [FinancialRisks].[MappingsStatus] (
    [MappingType] NVARCHAR (10) NULL,
    [Status]      NVARCHAR (10) NULL
);

