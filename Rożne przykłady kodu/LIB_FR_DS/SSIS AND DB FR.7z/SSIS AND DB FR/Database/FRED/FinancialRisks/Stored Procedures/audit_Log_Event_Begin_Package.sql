﻿CREATE procedure [FinancialRisks].[audit_Log_Event_Begin_Package]
	 @ParentLogID		int
	,@Description		varchar(50) = null
	,@PackageName		varchar(50)
	,@PackageGuid		uniqueidentifier
	,@MachineName		varchar(50)
	,@ExecutionGuid		uniqueidentifier
	,@operator			varchar(30)
	,@logID				int output
with execute as caller
as
/**********************************************************************************************************
* SP Name:
*		audit.Log_Event_Begin_Package
* Parameters:
*		 @ParentLogID		int
*		,@Description		varchar(50) = null
*		,@PackageName		varchar(50)
*		,@PackageGuid		uniqueidentifier
*		,@MachineName		varchar(50)
*		,@ExecutionGuid		uniqueidentifier
*		,@operator			varchar(30)
*		,@logID				int = null output
*  
* Purpose:	This stored procedure logs a starting event to the custom event-log table
*              
* Example:
		declare @logID int
		exec audit.Log_Event_Begin_Package 
			 0, 'Description'
			,'PackageName' ,'00000000-0000-0000-0000-000000000000'
			,'MachineName', '00000000-0000-0000-0000-000000000000'
			,null, @logID output
		select * from audit.LogSSISPackage where LogID = @logID
*              
* Revision Date/Time:
*	May 25, 2005	(G Dickinson)	- Authored
*	August 10, 2005	(G Dickinson)	- Coalesce @logicalDate, @operator, commenting
*
**********************************************************************************************************/
begin
	set nocount on

	--Coalesce @operator
	set @operator = nullif(ltrim(rtrim(@operator)), '')
	set @operator = isnull(@operator, suser_sname())

	--Root-level nodes should have a null parent
	if @ParentLogID <= 0 set @ParentLogID = null

	--Root-level nodes should not have a null Description
	set @Description = nullif(ltrim(rtrim(@Description)), '')
	if @Description is null and @ParentLogID is null set @Description = @PackageName

	--Insert the log record
	insert into FinancialRisks.audit_LogSSISPackage(
		 ParentLogID
		,Description
		,PackageName
		,PackageGuid
		,MachineName
		,ExecutionGuid
		,Operator
		,StartTime
		,EndTime
		,Status
		,FailureTask
	) values (
		@ParentLogID
		,@Description
		,@PackageName
		,@PackageGuid 
		,@MachineName
		,@ExecutionGuid
		,@operator
		,getdate() --Note: This should NOT be @logicalDate
		,null
		,0	--InProcess
		,null
	)
	set @logID = scope_identity()

	set nocount off
end --proc