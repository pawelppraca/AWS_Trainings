﻿CREATE   PROCEDURE [FinancialRisks].[uspUpdateCorrectionsRemoveAllPseudonyms] (@entityid AS INT)
AS
BEGIN
BEGIN TRANSACTION [RemoveAllPseudonyms]

	BEGIN TRY
	
	DECLARE 
		@obligorpseudonymid INT,
		@run INT,
		@obligorName VARCHAR(MAX);


		SET @run = (SELECT MAX(RUN) from FinancialRisks.RemovedPseudomyms);

	DECLARE cursor_product CURSOR
	FOR SELECT 
		DISTINCT ObligorPseudonymId, ObligorPseudonym
		FROM FinancialRisks.ObligorPseudonym WHERE ObligorID = @entityid

	OPEN cursor_product;

	FETCH NEXT FROM cursor_product INTO 
		@obligorpseudonymid,
		@obligorName;

	WHILE @@FETCH_STATUS = 0
		BEGIN
			EXEC [FinancialRisks].[uspUpdateCorrectionsCreateEntityFromPseudonym] @obligorpseudonymid;


			Declare @SumVal VARCHAR(MAX);
			Select @SumVal= CAST(EntityName AS VARCHAR) + ' - ' +CAST(EntityID AS VARCHAR) FROM FinancialRisks.entities WHERE entityname = @obligorName
			Print @SumVal;

			INSERT INTO FinancialRisks.RemovedPseudomyms(entityid,obligorpseudonymid,obligorName,NewEntityid,Run)
			SELECT @entityid,@obligorpseudonymid,@obligorName,(select EntityId from financialrisks.Entities where entityname = @obligorname),@run
			 
			FETCH NEXT FROM cursor_product INTO 
				@obligorpseudonymid,
				@obligorName;
		END;

	CLOSE cursor_product;

	DEALLOCATE cursor_product;


	COMMIT TRANSACTION [RemoveAllPseudonyms]

	END TRY

BEGIN CATCH

	ROLLBACK TRANSACTION [RemoveAllPseudonyms]

	                 --THROW ERROR
                        INSERT INTO [FinancialRisks].Mapping_Errors
                                VALUES
                                (SUSER_SNAME(),
                                ERROR_NUMBER(),
                                ERROR_STATE(),
                                ERROR_SEVERITY(),
                                ERROR_LINE(),
                                ERROR_PROCEDURE(),
                                ERROR_MESSAGE(),
                                GETDATE());

END CATCH  


END;
GO


