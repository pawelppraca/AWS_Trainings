﻿CREATE PROC [FinancialRisks].[Commonshockmodelextract] @InforceDate DATETIME2
/*

2022-08-05		Piotr Fedczyszyn	 	   GSGL-825 FRED Quarterly Update 01-01-22 - code beautify



*/
AS
    -- certain entities where a unique entity name is not available are defaulted such as 'No obligor name supplied' 
    -- to ensure a large number of entities are not grouped under the common names in the CSM
    -- it is a bit rubbish but there is a fudge to use the exposure id * -1 create a more Unqiue obligor id
    SELECT CASE
             WHEN lbe.EntityName = 'No obligor name supplied' THEN lbe.exposureid * -1
             ELSE lbe.ObligorEntityId
           END ObligorEntityId
           ,lbe.ClassOfBusiness
           ,lbe.CobId
           ,lbe.EntityName
           ,lbe.CapitalIqId
           ,lbe.[Entity Region]
           ,lbe.TopLevelTradeSectorID
           ,lbe.TopLevelTradeSectorName
           ,lbe.UltimateTradeSectorName
           ,lbe.UltimateRating
           ,lbe.SPRating
           ,lbe.GCHPRating
           ,lbe.LibertyRating
           ,lbe.ClassLGD
           ,lbe.LibertyExposure
           ,lbe.InforceDate
    INTO   #lbeCSM
    FROM   FinancialRisks.vw_ExposureOverview lbe
    WHERE  lbe.InforceDate = @InforceDate
       AND lbe.RiskCode IN ( 'CF', 'CR', 'SB', 'SU', 'FG', 'PB', 'PQ' )
       AND lbe.InforceDate = @InforceDate

    DECLARE @ReferenceUploadDate DATETIME

    SET @ReferenceUploadDate = (SELECT Max (ReferenceUploadDate) AS ReferenceUploadDate FROM   FinancialRisks.Ratings)


	;WITH ClassRatings AS
	(
		SELECT CASE
					WHEN lbe.CobId IN ( 1, 2 ) THEN 8
					ELSE lbe.CobId
				END                                                       AS ClassOfBusinessID
				,ISNULL(ISNULL(r.RatingType, s.RatingType), t.RatingType) AS FinalRating
		FROM   #lbeCSM lbe
				LEFT JOIN FinancialRisks.Ratings r
						ON r.RatingType = lbe.SPRating
							AND r.ReferenceUploadDate = @ReferenceUploadDate
				LEFT JOIN FinancialRisks.Ratings s
						ON s.RatingType = lbe.GCHPRating
							AND s.ReferenceUploadDate = @ReferenceUploadDate
				LEFT JOIN FinancialRisks.Ratings t
						ON t.RatingType = lbe.LibertyRating
							AND t.ReferenceUploadDate = @ReferenceUploadDate
				LEFT JOIN FinancialRisks.RatingDefaultProbability pr
						ON pr.RatingID = r.RatingID
							AND pr.ReferenceUploadDate = @ReferenceUploadDate
				LEFT JOIN FinancialRisks.RatingDefaultProbability pr2
						ON pr2.RatingID = s.RatingID
							AND pr2.ReferenceUploadDate = @ReferenceUploadDate
				LEFT JOIN FinancialRisks.RatingDefaultProbability pr3
						ON pr3.RatingID = t.RatingID
							AND pr3.ReferenceUploadDate = @ReferenceUploadDate
		WHERE  lbe.InforceDate = @InforceDate -- Date of refresh
         
	)
    SELECT ClassRatings.ClassOfBusinessID
           --,Avg(Cast(im.[1_Yr_PD] AS FLOAT)) AS [1_Yr_Class_Avg]
           --,Avg(Cast(im.[2_Yr_PD] AS FLOAT)) AS [2_Yr_Class_Avg]
           --,Avg(Cast(im.[3_Yr_PD] AS FLOAT)) AS [3_Yr_Class_Avg]
           --,Avg(Cast(im.[4_Yr_PD] AS FLOAT)) AS [4_Yr_Class_Avg]
           --,Avg(Cast(im.[5_Yr_PD] AS FLOAT)) AS [5_Yr_Class_Avg]
           --,Avg(Cast(im.[6_Yr_PD] AS FLOAT)) AS [6_Yr_Class_Avg]
           --,Avg(Cast(im.[7_Yr_PD] AS FLOAT)) AS [7_Yr_Class_Avg]
           --,Avg(Cast(im.[8_Yr_PD] AS FLOAT)) AS [8_Yr_Class_Avg]
           --,Avg(Cast(im.[9_Yr_PD] AS FLOAT)) AS [9_Yr_Class_Avg]
           --,Avg(Cast(im.[10_Yr_PD] AS FLOAT)) AS [10_Yr_Class_Avg]
           ,Avg(Cast(im.[1_Yr_PD] AS FLOAT)) AS [1_Yr_Class_Avg]
           ,Avg(Cast(im.[1_Yr_PD] AS FLOAT)) AS [2_Yr_Class_Avg]
           ,Avg(Cast(im.[1_Yr_PD] AS FLOAT)) AS [3_Yr_Class_Avg]
           ,Avg(Cast(im.[1_Yr_PD] AS FLOAT)) AS [4_Yr_Class_Avg]
           ,Avg(Cast(im.[1_Yr_PD] AS FLOAT)) AS [5_Yr_Class_Avg]
           ,Avg(Cast(im.[1_Yr_PD] AS FLOAT)) AS [6_Yr_Class_Avg]
           ,Avg(Cast(im.[1_Yr_PD] AS FLOAT)) AS [7_Yr_Class_Avg]
           ,Avg(Cast(im.[1_Yr_PD] AS FLOAT)) AS [8_Yr_Class_Avg]
           ,Avg(Cast(im.[1_Yr_PD] AS FLOAT)) AS [9_Yr_Class_Avg]
           ,Avg(Cast(im.[1_Yr_PD] AS FLOAT)) AS [10_Yr_Class_Avg]
    INTO   #ClassAvgPD
    FROM ClassRatings
    INNER JOIN FinancialRisks.Industry_PD_Matrix AS im	ON im.Rating = ClassRatings.FinalRating
    WHERE  im.IndustryNo = 0
       AND ClassRatings.FinalRating IS NOT NULL
       AND ClassRatings.FinalRating <> 'NR'
       AND ClassRatings.FinalRating <> 'D'
       AND im.ReferenceUploadDate = @ReferenceUploadDate
    GROUP  BY ClassRatings.ClassOfBusinessID
	;

	-----------------------------------Insert ---------------------------------

	WITH ExposuresSums AS
	(SELECT ObligorEntityId
                ,ClassOfBusiness
                ,CobId
                ,lbe.EntityName
                ,CapitalIqId
                ,[Entity Region]           AS Region
                ,lbe.TopLevelTradeSectorID AS TopLevelTradeSectorID
                ,lbe.TopLevelTradeSectorName
                ,lbe.UltimateRating        AS FinalRating
                ,lbe.ClassLGD
                ,Sum(lbe.LibertyExposure)  AS NetExposure
                ,lbe.InforceDate
        FROM   #lbeCSM lbe
                LEFT JOIN FinancialRisks.Ratings r
                        ON r.RatingType = lbe.UltimateRating
                            AND r.ReferenceUploadDate = @ReferenceUploadDate
                LEFT JOIN FinancialRisks.RatingDefaultProbability pr
                        ON pr.RatingID = r.RatingID
                            AND pr.ReferenceUploadDate = @ReferenceUploadDate
        WHERE  lbe.InforceDate = @InforceDate
            AND lbe.LibertyExposure IS NOT NULL
        GROUP  BY ObligorEntityId
                    ,ClassOfBusiness
                    ,cobId
                    ,lbe.EntityName
                    ,CapitalIQID
                    ,[Entity Region]
                    ,ClassLGD
                    ,TopLevelTradeSectorID
                    ,r.RatingType
                    ,lbe.InforceDate
                    ,UltimateTradeSectorName
                    ,UltimateRating
                    ,TopLevelTradeSectorName
        HAVING Sum(lbe.LibertyExposure) > 0
	)
	, ExposuresSumsOrdered AS
	 (SELECT ROW_NUMBER()	 OVER (
                       PARTITION BY ExposuresSums.CobId, ExposuresSums.ObligorEntityID
                       ORDER BY ExposuresSums.NetExposure DESC)         AS Rnk
                   ,ExposuresSums.ObligorEntityID
                   ,ExposuresSums.ClassOfBusiness
                   ,ExposuresSums.CobID
                   ,ExposuresSums.EntityName
                   ,ExposuresSums.CapitalIQID
                   ,ExposuresSums.Region
                   ,ExposuresSums.TopLevelTradeSectorID               AS TradeSectorId
                   ,ExposuresSums.TopLevelTradeSectorName             AS Industry
                   ,ExposuresSums.FinalRating
                   ,ExposuresSums.ClassLGD
                   ,ExposuresSums.NetExposure
                   ,ISNULL(im.[1_Yr_PD], cpd.[1_Yr_Class_Avg])   AS [PD1]
                   ,ISNULL(im.[2_Yr_PD], cpd.[2_Yr_Class_Avg])   AS [PD2]
                   ,ISNULL(im.[3_Yr_PD], cpd.[3_Yr_Class_Avg])   AS [PD3]
                   ,ISNULL(im.[4_Yr_PD], cpd.[4_Yr_Class_Avg])   AS [PD4]
                   ,ISNULL(im.[5_Yr_PD], cpd.[5_Yr_Class_Avg])   AS [PD5]
                   ,ISNULL(im.[6_Yr_PD], cpd.[6_Yr_Class_Avg])   AS [PD6]
                   ,ISNULL(im.[7_Yr_PD], cpd.[7_Yr_Class_Avg])   AS [PD7]
                   ,ISNULL(im.[8_Yr_PD], cpd.[8_Yr_Class_Avg])   AS [PD8]
                   ,ISNULL(im.[9_Yr_PD], cpd.[9_Yr_Class_Avg])   AS [PD9]
                   ,ISNULL(im.[10_Yr_PD],cpd.[10_Yr_Class_Avg])  AS [PD10]
                   ,ExposuresSums.inforcedate
            FROM   ExposuresSums  
            INNER JOIN #ClassAvgPD cpd
                    ON cpd.ClassOfBusinessID = ( CASE
                                                    WHEN ExposuresSums.CobId IN ( 1, 2 ) THEN 8
                                                    ELSE ExposuresSums.CobId
                                                END )
            LEFT JOIN FinancialRisks.Industry_PD_Matrix im
                    ON im.TradeSectorID = ExposuresSums.TopLevelTradeSectorID
                        AND im.Rating = ExposuresSums.FinalRating
	)
    INSERT INTO [FinancialRisks].[CSMOutput]
                ([ObligorEntityID]
                 ,[ClassOfBusiness]
                 ,[CobId]
                 ,[EntityName]
                 ,[CapitalIQID]
                 ,[Region]
                 ,[TradeSectorID]
                 ,[Industry]
                 ,[FinalRating]
                 ,[ClassLGD]
                 ,[NetExposure]
                 ,[PD1]
                 ,[PD2]
                 ,[PD3]
                 ,[PD4]
                 ,[PD5]
                 ,[PD6]
                 ,[PD7]
                 ,[PD8]
                 ,[PD9]
                 ,[PD10]
                 ,[InforceDate]
                 ,[ReferenceUploadDate])
    --By class
    SELECT  eso.ObligorEntityID
           ,eso.ClassOfBusiness
           ,eso.CobId
           ,eso.EntityName
           ,eso.CapitalIQID
           ,eso.Region
           ,eso.TradeSectorID
           ,eso.Industry
           ,eso.FinalRating
           ,eso.ClassLGD
           ,eso.NetExposure
           ,eso.[PD1]
           ,eso.[PD2]
           ,eso.[PD3]
           ,eso.[PD4]
           ,eso.[PD5]
           ,eso.[PD6]
           ,eso.[PD7]
           ,eso.[PD8]
           ,eso.[PD9]
           ,eso.[PD10]
           ,eso.inforcedate
           ,@ReferenceUploadDate AS[ReferenceUploadDate]
    FROM   ExposuresSumsOrdered	 eso
    WHERE  eso.Rnk = 1
    ORDER  BY EntityName


