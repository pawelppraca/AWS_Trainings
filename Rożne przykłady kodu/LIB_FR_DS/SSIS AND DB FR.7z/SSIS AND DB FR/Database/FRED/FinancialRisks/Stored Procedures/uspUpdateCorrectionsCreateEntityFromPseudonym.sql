﻿CREATE   PROCEDURE FinancialRisks.[uspUpdateCorrectionsCreateEntityFromPseudonym] (@PSEUDONYM_ID AS INT)
AS
BEGIN
BEGIN TRANSACTION [CreateEntityFromPseudonym]

BEGIN TRY
	
	--INSERT PSEUDONYM INTO ENTITY TABLE
	INSERT INTO FinancialRisks.Entities 
	(
	
	[EntityName] ,
	[ParentEntityName] ,
	[CapitalIqId] ,
	[ParentCapitalIqId] ,
	[SPRating] ,
	[GCHPRating] ,
	[LibertyRating] ,
	[TradeSectorId] ,
	[ParentSPRating] ,
	[ParentGCHPRating] ,
	[ParentLibertyRating],
	[Domicile] ,
	[ParentDomicile] 

	)
	SELECT ObligorPseudonym as EntityName 
	 ,NULL AS[ParentEntityName]
     ,NULL as [CapitalIqId]
     ,NULL as [ParentCapitalIqId]
     ,NULL as [SPRating]
     ,NULL as [GCHPRating]
     ,NULL as [LibertyRating]
     ,NULL as [TradeSectorId]
     ,NULL as [ParentSPRating]
     ,NULL as [ParentGCHPRating]
     ,NULL as [ParentLibertyRating]
     ,NULL as [Domicile]
     ,NULL as [ParentDomicile]
	from financialrisks.ObligorPseudonym
	WHERE ObligorPseudonymId = @PSEUDONYM_ID


	--UPDATE OBLIGOR PSEUDONYM BEFORE DELETION FOR EASY UPDATING OF ENTITY IN EXPOSURE TABLE
	UPDATE financialrisks.ObligorPseudonym 
	SET ObligorID = EntityId 
	FROM financialrisks.ObligorPseudonym 
	INNER JOIN FinancialRisks.Entities on EntityName = ObligorPseudonym 
	WHERE EntityName = (SELECT ObligorPseudonym FROM FinancialRisks.ObligorPseudonym WHERE ObligorPseudonymId =@PSEUDONYM_ID)
	
	--UPDATE EXPOSURE TABLE TO HAVE NEW ENTITY ID AS PSEUDONYM'S OBLIGOR ID
	UPDATE financialrisks.Exposures SET ObligorEntityId = op.ObligorID, ObligorPseudID = NULL
	FROM FinancialRisks.Exposures e
	INNER JOIN FinancialRisks.ObligorPseudonym op ON e.ObligorPseudID = op.ObligorPseudonymId 
	WHERE ObligorPseudonymId = @PSEUDONYM_ID 

	--UPDATE IRONSHORE TABLE
	UPDATE FinancialRisks.Ironshore_Data 
	SET entityId=ObligorID, ObligorPseudID = NULL
	FROM FinancialRisks.Ironshore_Data id
	INNER JOIN FinancialRisks.ObligorPseudonym op ON id.ObligorPseudID = op.ObligorPseudonymId
	 WHERE ObligorPseudonymId = @PSEUDONYM_ID
	
	--REMOVE FROM PSEUDONYM
	DELETE FROM FinancialRisks.ObligorPseudonym
	 WHERE ObligorPseudonymId = @PSEUDONYM_ID


	COMMIT TRANSACTION [CreateEntityFromPseudonym]

END TRY

BEGIN CATCH

	ROLLBACK TRANSACTION [CreateEntityFromPseudonym]

	--THROW ERROR
    INSERT INTO [FinancialRisks].[Mapping_Errors]
                                VALUES
                                (SUSER_SNAME(),
                                ERROR_NUMBER(),
                                ERROR_STATE(),
                                ERROR_SEVERITY(),
                                ERROR_LINE(),
                                ERROR_PROCEDURE(),
                                ERROR_MESSAGE(),
                                GETDATE());

END CATCH  


END;