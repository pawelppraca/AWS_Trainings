﻿CREATE PROCEDURE [FinancialRisks].[CheckForUnmappedObligorsInExposureAndIronshoreQueue]
/*   

 -- RETURNS unmapped obligors count

2022-08-05		Piotr Fedczyszyn	 	   GGSGL-728 Identify Mappings outputs the TotalExposure and Currency from queue into unmapped obligors file  - creation 

*/
AS
BEGIN
	DECLARE @ret	INT = 0	   -- RETURN VALUE

	IF ((SELECT Count(*) FROM  [FinancialRisks].[MappingsStatus] WHERE [Status] = 'Generating') = 0
		AND	 (SELECT DISTINCT [Status] FROM  [FinancialRisks].[MappingsStatus] WHERE [MappingType] ='Entities' ) = 'WAITING'
	   )
	BEGIN
 
	  SET nocount ON ;
	  SELECT queueid,
			 [Source],
			 unmappedobligorname,
			 mappedobligorname,
			 newpseudonym ,
			 [queue]
	  INTO   #unmappedobligors
	  FROM   (
				SELECT DISTINCT exposurequeueid AS queueid,
								[Source],
								obligorentityname AS unmappedobligorname,
								''                AS mappedobligorname,
								''                AS newpseudonym ,
								'Exposures'       AS queue
				FROM            financialrisks.exposuresqueue q
				WHERE           Isnumeric(q.obligorentityname)=0
				UNION
				SELECT DISTINCT queueid AS queueid,
								[Source],
								obligor     AS unmappedobligorname,
								''          AS mappedobligorname,
								''          AS newpseudonym ,
								'Ironshore' AS queue
				FROM            financialrisks.ironshore_data_queue dq
				WHERE           Isnumeric(dq.entityid)=0 
			 )a
	  ;

	  IF ( SELECT Count (*)  FROM   #unmappedobligors) > 0
	  BEGIN
		UPDATE [FinancialRisks].[MappingsStatus]
		SET    [Status]= 'Generating'
		WHERE  [MappingType] = 'Entities'
		;
		DROP TABLE if exists [FinancialRisks].[UnmappedObligors] ;


		;WITH currencyfxrates AS 
		(
			SELECT DISTINCT ccyFrom.currencycode          AS 'Name',
							roe.exchangerate              AS 'rate',
							YEAR(roe.exchangeratedatekey) AS 'year'
			 --into #CurrencyFXRates                     
			FROM   [sources].[vw_dwhr_currencies] ccyFrom
			INNER JOIN sources.vw_dwhr_isocurrencies ccyFromISO	 ON ccyFrom.isocurrencykey = ccyFromISO.isocurrencykey
			INNER JOIN sources.vw_dwhr_exchangerates roe		 ON ccyFromISO.isocurrencykey = roe.isocurrencyfromkey
			INNER JOIN sources.vw_dwhr_isocurrencies ccyToISO	 ON roe.isocurrencytokey = ccyToISO.isocurrencykey
			WHERE  ccyToISO.isocurrencycode = N'USD'
					AND roe.exchangeratetypecode = N'[GAAP Plan]'
		),
		Quotas AS
		(
			SELECT eq.obligorentityname,
				   eq.grossexposure,
				   c.currencyname,
				   CASE
					 WHEN eq.cobid NOT IN ( 1, 2, 5 ) THEN
					   --COB IDs for GFR AND PTC which allready have their Currencies FX rates applied
					   CASE
						 WHEN eq.grossexposure / ecr.rate > ISNULL( eq.limit / ecr.rate, 0)
							  AND ISNULL(eq.limit / ecr.rate, 0) > 0 THEN
						 ISNULL(eq.limit / ecr.rate, 0)
						 ELSE eq.grossexposure / ecr.rate
					   END
					 ELSE eq.grossexposure
				   END									AS GrossExposureUSD
			FROM   [FinancialRisks].exposuresqueue eq
			LEFT JOIN [FinancialRisks].currencies c		 ON eq.currencyid = c.currencyid
			LEFT JOIN currencyfxrates ecr
					ON c.currencyname = ecr.[name]
					AND ecr.[year] = Year(Getdate())
		)
 		SELECT	queueid,
				[Source],
				unmappedobligorname,
				MAX (mappedobligorname) as mappedobligorname,
				MAX (newpseudonym)		as newpseudonym,
				[queue],
				Sum(grossexposure)    AS TotalGrossExposure,
				CurrencyName,
				cONVERT ( NUMERIC (18) , Convert (decimal(22,0), Sum(grossexposureusd))) AS USD_TotalExposure
 	    INTO   [FinancialRisks].[UnmappedObligors]
		FROM   #unmappedobligors AS unmapped
		LEFT JOIN Quotas  ON unmapped.unmappedobligorname = Quotas.ObligorEntityName
		GROUP BY
				queueid,
				[Source],
				unmappedobligorname,
				--MAX (mappedobligorname) as mappedobligorname,
				--MAX (newpseudonym)  as newpseudonym,
				[queue],		
				obligorentityname,
				currencyname

		DROP TABLE #unmappedobligors
		SELECT  @ret = COUNT (*) FROM   [FinancialRisks].[UnmappedObligors]
	  END
	  ELSE
	  BEGIN
		TRUNCATE TABLE [FinancialRisks].[UnmappedObligors]; -- clean UnmappedObligors remainig from previous run 
		DROP TABLE #unmappedobligors  ;
	  END
	END
 
	RETURN (SELECT @ret	)--AS unmappedobligorsinqueue 
END
