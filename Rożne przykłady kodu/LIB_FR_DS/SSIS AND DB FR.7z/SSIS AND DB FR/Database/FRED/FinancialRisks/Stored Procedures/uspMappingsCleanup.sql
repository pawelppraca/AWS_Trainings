﻿

CREATE procedure [FinancialRisks].[uspMappingsCleanup]
as
/**********************************************************************************************************

**********************************************************************************************************/
begin
	set nocount on


Insert Into [FinancialRisks].[Cedant] ([Name])
Select distinct
CedantName
from [FinancialRisks].[ExposuresQueue]
where ISNUMERIC(CedantName) = 0 and CedantName not in (select name from [FinancialRisks].[Cedant])


;WITH Obligors(ObligorID, ObligorName) AS 
(
	SELECT EntityId as ObligorId, EntityName as ObligorName
	FROM FinancialRisks.Entities
	UNION
	SELECT ObligorId, ObligorPseudonym as ObligorName
	FROM FinancialRisks.ObligorPseudonym
),
-- Get distinct list of all possible country and pseudoynm names and their ids
Countries(CountryID, CountryName) AS
(
	SELECT CountryId, CountryName
	FROM FinancialRisks.Countries
	UNION
	SELECT CountryId, CountryPseudonym AS CountryName
	FROM FinancialRisks.CountryPseudonym
)
  SELECT exposuresQueue.ExposureQueueId
      , cedant.[CedantID]
      , exposuresQueue.[CobId]
      , LTRIM(RTRIM(exposuresQueue.[RiskReference])) [RiskReference]
      , exposuresQueue.[CurrencyId]
      , exposuresQueue.[Year]
      , exposuresQueue.[DataQuarter]
      , exposuresQueue.[AssuredEntityId]
      , LTRIM(RTRIM(exposuresQueue.[RiskCode])) [RiskCode]
      , LTRIM(RTRIM(exposuresQueue.[LeadSyndicate])) [LeadSyndicate]
      , countries.CountryID as [CountryId]
      , exposuresQueue.[InceptionDate]
      , exposuresQueue.[ExpiryDate]
      , exposuresQueue.[Limit]
      , exposuresQueue.[UsdLimit]
      , exposuresQueue.[GrossPremium]
      , exposuresQueue.[GrossExposure]
      , obligors.ObligorID as [ObligorEntityId]
      , exposuresQueue.[InforceDate]
  INTO  #tempQueue
  FROM [FinancialRisks].[ExposuresQueue] exposuresQueue
  INNER JOIN [FinancialRisks].[Cedant] cedant on cedant.Name = exposuresQueue.cedantName
  INNER JOIN Obligors obligors on obligors.ObligorName = exposuresQueue.ObligorEntityName
  INNER JOIN Countries countries on countries.CountryName = exposuresQueue.CountryName
  WHERE [Status] = 'NEW'


INSERT INTO [FinancialRisks].[Exposures]
			([CedantId]
           ,[CobId]
           ,[RiskReference]
           ,[CurrencyId]
           ,[Year]
           ,[DataQuarter]
           ,[AssuredEntityId]
           ,[RiskCode]
           ,[LeadSyndicate]
           ,[CountryId]
           ,[InceptionDate]
           ,[ExpiryDate]
           ,[Limit]
           ,[UsdLimit]
           ,[GrossPremium]
           ,[GrossExposure]
           ,[ObligorEntityId]
           ,[InforceDate])
Select 
            [CedantId]
           ,[CobId]
           ,[RiskReference]
           ,[CurrencyId]
           ,[Year]
           ,[DataQuarter]
           ,[AssuredEntityId]
           ,[RiskCode]
           ,[LeadSyndicate]
           ,[CountryId]
           ,[InceptionDate]
           ,[ExpiryDate]
           ,[Limit]
           ,[UsdLimit]
           ,[GrossPremium]
           ,[GrossExposure]
           ,[ObligorEntityId]
           ,[InforceDate]
  FROM #tempQueue
  
  DELETE FROM FinancialRisks.ExposuresQueue where ExposureQueueId in (select ExposureQueueId from #tempQueue)

  DROP TABLE #tempQueue
  
  set nocount off
end --proc