﻿
/*********************************************/
/*
ChangeLog:
-----------
2023.05.26 - by Pawel P. (FP) - GSGL-1076 - Two-phase Obligor Mappings - https://forge.lmig.com/issues/browse/GSGL-1076
2023.05.29 - by Pawel P. (FP) - GSGL-1096 - New column Industry from Exposures - https://forge.lmig.com/issues/browse/GSGL-1096
2023.07.21 - by PP - GSGL1231 only comment 
2023.07.24 - by PP - GSGL1231 only comment, change in comment only
2023.08.18 - by PP - GSGL-1207 - Issue with Processing on UAT 
2023.08.29 - by Piotr Fedczysyzn.  - GSGL-1283 fixing Bug with EntityRegion / ExposureRegioni  
2023.09.07 - by PP - RollBack GSGL-1283 and GSGL-1076
2023.09.11 - By PP - Restore rollbacked changes related to GSGL-1283 only
2023.11.06 - by PP - GSGL-1376 - Add new fields [OriginalEntityinFile] ,[OriginalCountryinFile]
2023.12.19 - by PP - GSGL-1411 - Replace NUll and "0" ObligorName in ExposuresQueue to 'No obligor name supplied'
2024.07.02 - by PP - Dummy chnage - Comment only
 */

CREATE PROCEDURE [FinancialRisks].[uspCleanupExposureStaging] @CobId INT
AS

/********************************************************************************************/
-- Get distinct list of all possible country names and their ids
SELECT CountryID
       ,CountryName
       ,CountryPseudonymId
       ,Region
INTO   #country
FROM   (SELECT CountryId
               ,CountryName
               ,null AS CountryPseudonymId
               ,Region
        FROM   financialrisks.Countries
        UNION
        SELECT cpp.CountryId
               ,cpp.CountryPseudonym AS CountryName
               ,cpp.CountryPseudonymId
               ,ccc.Region 
        FROM   financialrisks.CountryPseudonym AS cpp
        INNER JOIN financialrisks.Countries ccc
        ON cpp.CountryID = ccc.CountryId
        )a

UPDATE [FinancialRisks].[ExposuresQueue]
SET    [CountryName] = countries.CountryID
       ,CountryPseudID = countries.CountryPseudonymId
       ,Region = countries.Region
FROM [FinancialRisks].[ExposuresQueue] AS eq
INNER JOIN #country countries
   ON countries.CountryName = [FinancialRisks].[fn_RemoveBadChar](eq.CountryName)
WHERE [Status] = 'NEW'
  AND [CobId] = @CobId

DECLARE @noCountryid INT

SELECT TOP(1) @noCountryid =  CountryID
FROM   [FinancialRisks].[Countries]
WHERE  CountryName = 'No country name supplied'

IF @CobId <> 6
BEGIN
    UPDATE [FinancialRisks].[ExposuresQueue]
    SET    [CountryName] = @noCountryid
           ,Region = null
    WHERE  [CountryName] IS NULL
        OR [CountryName] = ''
END 

/********************************************************************************************/


-- Get distinct list of all possible obligor names and their ids
SELECT ObligorID
        ,ltrim(rtrim(ObligorName)) AS 'ObligorName'
        ,ObligorPseudonymId
        ,CountryName
        ,ParentCountryName
INTO  #Obligors FROM
(
	SELECT  EntityId as ObligorId
            ,RTRIM(LTRIM(EntityName)) AS ObligorName 
            ,'' AS ObligorPseudonymId
            ,Domicile AS 'CountryName'
            ,ParentDomicile ParentCountryName
	FROM FinancialRisks.Entities
	UNION
	SELECT  ObligorId
            ,rtrim(ltrim(ObligorPseudonym)) as ObligorName
            ,ObligorPseudonymId,''as 'CountryName'
            ,'' ParentCountryName
	FROM FinancialRisks.ObligorPseudonym
)b


--GSGL-1411 - Update Empty Obligors 
UPDATE eq 
    SET ObligorEntityName = 'No obligor name supplied'
FROM [FinancialRisks].[ExposuresQueue] eq 
WHERE  (
            LTRIM(RTRIM(eq.ObligorEntityName)) IS NULL 
            OR LTRIM(RTRIM(eq.ObligorEntityName))='0' 
            OR ISNUMERIC([ObligorEntityName]) = 1
       )


--Map those with valid IDS and with the country
--GSGL-1076 - 
UPDATE [FinancialRisks].[ExposuresQueue]
SET    [ObligorEntityName] = obligors.ObligorID
       ,ObligorPseudID     = obligors.ObligorPseudonymId
FROM   [FinancialRisks].[ExposuresQueue] eq
INNER JOIN [FinancialRisks].Countries c
    ON c.countryid = eq.countryName
    AND ISNUMERIC(eq.countryName) = 1
INNER JOIN #obligors obligors
    ON obligors.ObligorName = LTRIM(RTRIM(eq.ObligorEntityName)) + '/' + c.CountryName
WHERE  eq.[Status] = 'NEW'
   AND eq.[CobId] = @CobId



UPDATE [FinancialRisks].[ExposuresQueue] 
    SET [ObligorEntityName] = obligors.ObligorID 
    ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
INNER JOIN [FinancialRisks].Countries c ON c.CountryName=obligors.countryName and c.countryid=eq.countryName AND ISNUMERIC(eq.countryName) = 1 
  WHERE [Status] = 'NEW'
  AND [CobId] = @CobId
  and ISNUMERIC([ObligorEntityName]) = 0 --Not maped earlier



--Map those with valid IDS  and without the country but with ParentCountry
UPDATE [FinancialRisks].[ExposuresQueue]
    SET [ObligorEntityName] =obligors.ObligorID 
    ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
  WHERE [Status] = 'NEW'
  AND [CobId] = @CobId
  and ISNUMERIC([ObligorEntityName]) = 0 --Not maped earlier
  and obligors.CountryName = obligors.ParentCountryName



--Map those with valid IDS  and without the country
UPDATE [FinancialRisks].[ExposuresQueue]
SET    [ObligorEntityName] = obligors.ObligorID
       ,ObligorPseudID     = obligors.ObligorPseudonymId
FROM   [FinancialRisks].[ExposuresQueue] eq
       INNER JOIN #obligors obligors
               ON obligors.ObligorName = LTRIM(RTRIM(eq.ObligorEntityName))
WHERE  [Status] = 'NEW'
       AND [CobId] = @CobId
       AND ISNUMERIC([ObligorEntityName]) = 0 --Not maped earlier


---- Map Countries based on domicile
IF @CobId = 6
BEGIN
    UPDATE [FinancialRisks].[ExposuresQueue]
    SET    [CountryName] = countries.CountryID
    FROM   [FinancialRisks].[ExposuresQueue] eq
    INNER JOIN financialrisks.Entities ent
            ON ent.EntityId = eq.ObligorEntityName
    INNER JOIN #country countries
            ON countries.CountryName = LTRIM(RTRIM(ent.Domicile))
    WHERE  [Status] = 'NEW'
            AND [CobId] = @CobId
            AND ISNUMERIC([ObligorEntityName]) = 1

    UPDATE [FinancialRisks].[ExposuresQueue]
    SET    [CountryName] = @noCountryid
    WHERE  ( [CountryName] IS NULL OR [CountryName] = '' )
        AND [Status] = 'NEW'
        AND [CobId] = @CobId
        AND ISNUMERIC([ObligorEntityName]) = 1
END 
------- Map non CF with no obligor name supplied to the one obligor
DECLARE @entityid INT

SET @entityid = (SELECT EntityID
                 FROM   [FinancialRisks].[Entities]
                 WHERE  EntityName = 'No obligor name supplied')

UPDATE [FinancialRisks].[ExposuresQueue]
SET    [ObligorEntityName] = @entityid
WHERE  ( [ObligorEntityName] IS NULL OR [ObligorEntityName] = '' )
    AND LTRIM(RTRIM([RiskCode])) <> 'CF'
    AND [Status] = 'NEW'
    AND [CobId] = @CobId

-- Map  CF with no obligor name supplied to obligor with CD + Country Name + not supplied
INSERT INTO [FinancialRisks].[Entities]
            ([EntityName])
SELECT DISTINCT 'CF ' + c.CountryName
                + ' obligor name not supplied' AS NAME
FROM   [FinancialRisks].[ExposuresQueue]e
INNER JOIN [FinancialRisks].Countries c
        ON e.CountryName = c.CountryId
WHERE  ( [ObligorEntityName] IS NULL  OR [ObligorEntityName] = '' )
    AND LTRIM(RTRIM([RiskCode])) = 'CF'
    AND ISNUMERIC(e.CountryName) = 1
    AND 'CF ' + c.CountryName  + ' obligor name not supplied' NOT IN (SELECT EntityName AS ObligorName  FROM   financialrisks.Entities)

UPDATE [FinancialRisks].[ExposuresQueue]
SET    ObligorEntityName = ent.EntityId
FROM   [FinancialRisks].[ExposuresQueue]   AS e
INNER JOIN [FinancialRisks].Countries c
        ON e.CountryName = c.CountryId
INNER JOIN [FinancialRisks].Entities ent
        ON ent.EntityName = 'CF ' + c.CountryName + ' obligor name not supplied'
WHERE  ( e.[ObligorEntityName] IS NULL
          OR e.[ObligorEntityName] = '' )
       AND LTRIM(RTRIM(e.[RiskCode])) = 'CF'
       AND ISNUMERIC(e.CountryName) = 1
/********************************************************************************************/
-- Get distinct list of all possible cedant names and their ids
SELECT CedantId
       ,NAME
INTO   #cedants
FROM   (SELECT CedantId
               ,NAME
        FROM   financialrisks.Cedant)b

UPDATE [FinancialRisks].[ExposuresQueue]
SET    cedantName = cedant.[CedantId]
FROM   [FinancialRisks].[ExposuresQueue]    AS eq
INNER JOIN #cedants                         AS cedant   ON   cedant.NAME = LTRIM(RTRIM(eq.cedantName))
WHERE eq.[Status] = 'NEW'
  AND eq.[CobId] = @CobId 
/********************************************************************************************/

SELECT  ExposureQueueId
       ,[CedantName]                  AS [CedantId]
       ,[CobId]
       ,LTRIM(RTRIM([RiskReference])) AS [RiskReference]
       ,[CurrencyId]
       ,[Year]
       ,[DataQuarter]
       ,[AssuredEntityId]
       ,LTRIM(RTRIM([RiskCode]))      AS [RiskCode]
       ,LTRIM(RTRIM([LeadSyndicate])) AS [LeadSyndicate]
       ,[CountryName]                 AS CountryID
       ,[InceptionDate]
       ,[ExpiryDate]
       ,[Limit]
       ,[UsdLimit]
       ,[GrossPremium]
       ,[GrossExposure]
       ,[ObligorEntityName]           AS EntityId
       ,[InforceDate]
       ,[source]
       ,ObligorPseudID
       ,CountryPseudID
       ,SBU
       ,Office
       ,AssumedLive
       ,NoBillingOffsetTotalSuretyExposureNetPGE
       ,NetSuretyExposure
       ,ProductLine
       ,region
       ,assured
       ,LGDSD_Surety
       ,Max_Cap
       ,Collateral
       ,LocalId
       ,Industry
	  ,[OriginalEntityinFile]
	  ,[OriginalCountryinFile]
INTO   #temptable
FROM   [FinancialRisks].[ExposuresQueue] 
WHERE  ISNUMERIC([CedantName]) = 1
    AND ISNUMERIC([CountryName]) = 1
    AND ISNUMERIC([ObligorEntityName]) = 1
    AND [Status] = 'NEW'
    AND [CobId] = @CobId 

INSERT INTO [FinancialRisks].[Exposures]
            ([CedantId]
             ,[CobId]
             ,[RiskReference]
             ,[CurrencyId]
             ,[Year]
             ,[DataQuarter]
             ,[AssuredEntityId]
             ,[RiskCode]
             ,[LeadSyndicate]
             ,[CountryId]
             ,[InceptionDate]
             ,[ExpiryDate]
             ,[Limit]
             ,[UsdLimit]
             ,[GrossPremium]
             ,[GrossExposure]
             ,[ObligorEntityId]
             ,[InforceDate]
             ,[Source]
             ,ObligorPseudID
             ,CountryPseudID
             ,SBU
             ,Office
             ,AssumedLive
             ,NoBillingOffsetTotalSuretyExposureNetPGE
             ,NetSuretyExposure
             ,ProductLine
             ,region
             ,Assured
             ,LGDSD_Surety
             ,Max_Cap
             ,Collateral
             ,uploaddate
             ,LocalId
             ,Industry
	         ,[OriginalEntityinFile]
	         ,[OriginalCountryinFile]
             )
SELECT [CedantId]
       ,[CobId]
       ,[RiskReference]
       ,[CurrencyId]
       ,[Year]
       ,[DataQuarter]
       ,[AssuredEntityId]
       ,[RiskCode]
       ,[LeadSyndicate]
       ,[CountryId]
       ,[InceptionDate]
       ,[ExpiryDate]
       ,[Limit]
       ,[UsdLimit]
       ,[GrossPremium]
       ,[GrossExposure]
       ,EntityId
       ,[InforceDate]
       ,[Source]
       ,ObligorPseudID
       ,CountryPseudID
       ,SBU
       ,Office
       ,AssumedLive
       ,NoBillingOffsetTotalSuretyExposureNetPGE
       ,NetSuretyExposure
       ,ProductLine
       ,region
       ,assured
       ,LGDSD_Surety
       ,Max_Cap
       ,Collateral
       ,CONVERT(DATE, GETDATE())
       ,LocalId
       ,Industry
	   ,[OriginalEntityinFile]
	   ,[OriginalCountryinFile]
FROM   #temptable

DELETE FROM [FinancialRisks].[ExposuresQueue]
WHERE [ExposureQueueId] IN (SELECT [ExposureQueueId] FROM #TempTable)

DROP TABLE #TempTable
DROP TABLE #Obligors
DROP TABLE #country