﻿
/*********************************************/
/*
ChangeLog:
-----------
2023.05.26 - by Pawel P. (FP) - GSGL-1076 - Two-phase Obligor Mappings - https://forge.lmig.com/issues/browse/GSGL-1076
2023.09.07 - by Pawel P. (FP) - RollBack GSGL-1076
2023.11.06 - by PP - GSGL-1376 - Add new fields [OriginalEntityinFile] ,[OriginalCountryinFile]
 */


CREATE PROCEDURE [FinancialRisks].[uspCleanupIronshoreQueue]
AS
/********************************************************************************************/
-- Get distinct list of all possible country names and their ids
SELECT CountryID
       ,CountryName
       ,CountryPseudonymId
--       ,Region
INTO   #country
FROM  (SELECT CountryId
               ,CountryName
               ,''AS CountryPseudonymId
--               ,Region
        FROM   FinancialRisks.Countries
        UNION
        SELECT cpp.CountryId
               ,cpp.CountryPseudonym AS CountryName
               ,cpp.CountryPseudonymId
--               ,ccc.Region 
        FROM   financialrisks.CountryPseudonym AS cpp
        --INNER JOIN financialrisks.Countries ccc
        --ON cpp.CountryID = ccc.CountryId
    ) a

UPDATE [FinancialRisks].[Ironshore_Data_Queue]
SET    [countryId] = countries.CountryID
       ,CountryPseudID = countries.CountryPseudonymId
FROM   [FinancialRisks].[Ironshore_Data_Queue]  AS eq
INNER JOIN #country                             AS countries          ON countries.CountryName = [FinancialRisks].[FN_REMOVEBADCHAR](eq.country) 

DECLARE @noCountryid INT

SELECT TOP (1) @noCountryid = CountryID
FROM   [FinancialRisks].[Countries]
WHERE  CountryName = 'No country name supplied';

UPDATE [FinancialRisks].[Ironshore_Data_Queue]
SET    [countryId] = @noCountryid
WHERE  country IS NULL
        OR country = '' 
-- Get distinct list of all possible obligor names and their ids
SELECT ObligorID
       ,LTRIM(RTRIM(ObligorName)) AS 'ObligorName'
       ,ObligorPseudonymId
INTO   #Obligors
FROM   (SELECT EntityId                  AS ObligorId
               ,LTRIM(RTRIM(EntityName)) AS ObligorName
               ,''                       AS ObligorPseudonymId
        FROM   FinancialRisks.Entities
        UNION
        SELECT ObligorId
               ,LTRIM(RTRIM(ObligorPseudonym)) AS ObligorName
               ,ObligorPseudonymId
        FROM   FinancialRisks.ObligorPseudonym
       )b 

--Map those with valid IDS
UPDATE [FinancialRisks].[Ironshore_Data_Queue]
SET    entityId = obligors.ObligorID
       ,ObligorPseudID = obligors.ObligorPseudonymId
FROM   [FinancialRisks].[Ironshore_Data_Queue] eq
       INNER JOIN [FinancialRisks].Countries c
               ON c.countryid = eq.[countryId]
       INNER JOIN #Obligors obligors
               ON obligors.ObligorName = LTRIM(RTRIM(eq.obligor)) + '/' + c.CountryName

--Map those with valid IDS
UPDATE [FinancialRisks].[Ironshore_Data_Queue]
SET    entityId = obligors.ObligorID
       ,ObligorPseudID = obligors.ObligorPseudonymId
FROM   [FinancialRisks].[Ironshore_Data_Queue] eq
       INNER JOIN #Obligors obligors
               ON obligors.ObligorName = LTRIM(RTRIM(eq.obligor))
WHERE  ISNUMERIC(eq.entityId) = 0 --Not maped earlier


SELECT QueueId
       ,LTRIM(RTRIM([riskReference])) [riskReference]
       ,CASE
          WHEN LTRIM(RTRIM([TransactionType])) IN ( 'MTSB', 'STSB', 'RCF', 'STF', 'MB', 'SS' ) THEN 'CR'
          WHEN LTRIM(RTRIM([TransactionType])) = 'PRI' THEN 'PR'
          ELSE LTRIM(RTRIM([TransactionType]))
        END                           AS [RiskCode]
       ,[obligor]
       ,EntityId
       ,IDQ.[Country]
       ,CountryID
       ,[LimitLiability]
       ,[inception_date]
       ,[expiry_date]
       ,[insured]
       ,IDQ.[InforceDate]
       ,IDQ.[UserNotified]
       ,[GrossExposure]
       ,ObligorPseudID
       ,CountryPseudID
	  ,[OriginalEntityinFile]
	  ,[OriginalCountryinFile]
INTO   #TempTable
FROM   [FinancialRisks].[Ironshore_Data_Queue] AS IDQ
WHERE  ISNUMERIC(EntityId) = 1
       AND ISNUMERIC(CountryID) = 1

INSERT INTO [FinancialRisks].[Ironshore_Data]
        ([riskReference]
        ,[country]
        ,[countryId]
        ,[inception_date]
        ,[expiry_date]
        ,[obligor]
        ,[entityId]
        ,[GrossExposure]
        ,[LimitLiability]
        ,[Insured]
        ,[RiskCode]
        ,[InforceDate]
        ,ObligorPseudID
        ,CountryPseudID
        ,[OriginalEntityinFile]
	   ,[OriginalCountryinFile]
        )
SELECT [riskReference]
       ,[country]
       ,[countryId]
       ,[inception_date]
       ,[expiry_date]
       ,[obligor]
       ,[entityId]
       ,[GrossExposure]
       ,[LimitLiability]
       ,[Insured]
       ,[RiskCode]
       ,[InforceDate]
       ,ObligorPseudID
       ,CountryPseudID
      ,[OriginalEntityinFile]
	  ,[OriginalCountryinFile]
FROM   #TempTable

DELETE FROM [FinancialRisks].[Ironshore_Data_Queue]
WHERE  QueueId IN (SELECT QueueId  FROM   #TempTable) 

DROP TABLE #TempTable
DROP TABLE #Obligors
DROP TABLE #country