﻿CREATE PROCEDURE [FinancialRisks].[uspUpdateCountryMappings]
AS
/*
ChangeLog:
-----------
2022-05-22 - Piotr fedczyszym  Creation - GSGL-1025 Update data of Countries in [FinancialRisks].Country table related to FRED 2
  
*/
BEGIN
    -- new country processing
    INSERT INTO [FinancialRisks].[Countries]
            ([CountryName],
            [CountryCapitalIqId],
            [ISOCountryName],
            [Alpha3Code],
            [ISO2Code],
            [SovereignRating])
    SELECT  NULLIF(LTRIM(RTRIM([CountryName])),''),
            NULLIF(LTRIM(RTRIM([CountryCapitalIqId])),''),
            NULLIF(LTRIM(RTRIM([ISOCountryName])),''),
            NULLIF(LTRIM(RTRIM([Alpha3Code])),''),
            NULLIF(LTRIM(RTRIM([ISO2Code])),''),
            NULLIF(LTRIM(RTRIM([SovereignRating])),'')
    FROM   [FinancialRisks].CountryPseudonymsTemp
    WHERE  [PseudonymOrNew] = 'New'
    AND [CountryName] NOT IN (SELECT CountryName FROM   [FinancialRisks].[Countries])
    AND NULLIF(LTRIM(RTRIM([CountryName])),'') IS NOT NULL

    -- New Pseudonym , New Country
    INSERT INTO [FinancialRisks].CountryPseudonym
                (CountryID,
                CountryPseudonym)
    SELECT DISTINCT co.CountryId,
                    [FinancialRisks].[fn_FixCountryName](temp.UnmappedCountryName)
    FROM   [FinancialRisks].CountryPseudonymsTemp temp
    JOIN [FinancialRisks].Countries co
        ON co.CountryName = temp.CountryName
    WHERE  temp.PseudonymOrNew = 'New'
    AND temp.CountryName <> [FinancialRisks].[fn_FixCountryName](temp.UnmappedCountryName)
    AND[FinancialRisks].[fn_FixCountryName](temp.UnmappedCountryName) NOT IN 
            (SELECT CountryPseudonym
             FROM [FinancialRisks].[CountryPseudonym]
             WHERE CountryPseudonym IS NOT NULL
            )
    AND [FinancialRisks].[fn_FixCountryName](temp.UnmappedCountryName) <> ''
    AND [FinancialRisks].[fn_FixCountryName](temp.UnmappedCountryName) IS NOT NULL


    -- New Pseudonym  Existing Country
    INSERT INTO [FinancialRisks].CountryPseudonym
                (CountryID,
                CountryPseudonym)
    SELECT DISTINCT co.CountryId,
                    [FinancialRisks].[fn_FixCountryName](temp.UnmappedCountryName)
    FROM   [FinancialRisks].CountryPseudonymsTemp temp
    JOIN [FinancialRisks].Countries co
        ON co.CountryName = temp.MappedCountryName
        AND [FinancialRisks].[fn_FixCountryName](temp.UnmappedCountryName) NOT IN 
                (SELECT CountryPseudonym
                 FROM [FinancialRisks].[CountryPseudonym]
                 WHERE CountryPseudonym IS NOT NULL
                )
    WHERE  temp.PseudonymOrNew = 'Pseudonym'
    AND [FinancialRisks].[fn_FixCountryName](temp.UnmappedCountryName) <> ''
    AND [FinancialRisks].[fn_FixCountryName](temp.UnmappedCountryName) IS NOT NULL

    -- update Country data when Countryname and CountryCapitalIqI is fitting  and CountryCapitalIqI is not null

     UPDATE cous
     SET
     --     cous.[CountryName]          = NULLIF(LTRIM(RTRIM(src.[CountryName])),''),
     --     cous.[CountryCapitalIqId]   = NULLIF(LTRIM(RTRIM(src.[CountryCapitalIqId])),''),
            cous.[ISOCountryName]       = NULLIF(LTRIM(RTRIM(src.[ISOCountryName])),''),
            cous.[Alpha3Code]           = NULLIF(LTRIM(RTRIM(src.[Alpha3Code])),''),
            cous.[ISO2Code]             = NULLIF(LTRIM(RTRIM(src.[ISO2Code])),''),
            cous.[SovereignRating]      = NULLIF(LTRIM(RTRIM(src.[SovereignRating])),'')
    FROM  [FinancialRisks].[Countries]                  AS cous
    INNER JOIN  [FinancialRisks].CountryPseudonymsTemp  AS src 
        ON  src.[CountryName]       = cous.CountryName
        AND src.CountryCapitalIqId  = cous.CountryCapitalIqId 
    WHERE  src.[PseudonymOrNew] = 'Update All'
    ;
    -- clean
    DELETE tmp
    FROM [FinancialRisks].CountryPseudonymsTemp tmp
    INNER JOIN [FinancialRisks].[Countries] cous
        ON  tmp.[CountryName]  = cous.CountryName
        AND tmp.CountryCapitalIqId = cous.CountryCapitalIqId 
    WHERE tmp.[PseudonymOrNew] = 'Update All'
 
    -- update Country data when Countryname and CountryCapitalIqI is fitting  and CountryCapitalIqI is  null

     UPDATE cous
     SET
     --     cous.[CountryName]          = NULLIF(LTRIM(RTRIM(src.[CountryName])),''),
     --     cous.[CountryCapitalIqId]   = NULLIF(LTRIM(RTRIM(src.[CountryCapitalIqId])),''),
            cous.[ISOCountryName]       = NULLIF(LTRIM(RTRIM(src.[ISOCountryName])),''),
            cous.[Alpha3Code]           = NULLIF(LTRIM(RTRIM(src.[Alpha3Code])),''),
            cous.[ISO2Code]             = NULLIF(LTRIM(RTRIM(src.[ISO2Code])),''),
            cous.[SovereignRating]      = NULLIF(LTRIM(RTRIM(src.[SovereignRating])),'')
    FROM  [FinancialRisks].[Countries]                  AS cous
    INNER JOIN  [FinancialRisks].CountryPseudonymsTemp  AS src 
        ON  src.[CountryName]       = cous.CountryName
        AND src.CountryCapitalIqId  IS NULL 
        AND cous.CountryCapitalIqId IS NULL
    WHERE  src.[PseudonymOrNew] = 'Update All'
    ;
    -- clean
    DELETE tmp
    FROM [FinancialRisks].CountryPseudonymsTemp tmp
    INNER JOIN [FinancialRisks].[Countries] cous
        ON  tmp.[CountryName]  = cous.CountryName
        AND tmp.CountryCapitalIqId  IS NULL 
        AND cous.CountryCapitalIqId IS NULL
    WHERE tmp.[PseudonymOrNew] = 'Update All'
 

     -- update Country data when Countryname  is fitting

     UPDATE cous
     SET
     --     cous.[CountryName]         = NULLIF(LTRIM(RTRIM(src.[CountryName])),''),
            cous.[CountryCapitalIqId]  = NULLIF(LTRIM(RTRIM(src.[CountryCapitalIqId])),''),
            cous.[ISOCountryName]      = NULLIF(LTRIM(RTRIM(src.[ISOCountryName])),''),
            cous.[Alpha3Code]          = NULLIF(LTRIM(RTRIM(src.[Alpha3Code])),''),
            cous.[ISO2Code]            = NULLIF(LTRIM(RTRIM(src.[ISO2Code])),''),
            cous.[SovereignRating]     = NULLIF(LTRIM(RTRIM(src.[SovereignRating])),'')
    FROM [FinancialRisks].[Countries]                   AS cous
    INNER JOIN [FinancialRisks].CountryPseudonymsTemp   AS src 
        ON  src.[CountryName]  = cous.CountryName
        --AND src.CountryCapitalIqId = cous.CountryCapitalIqId 
    WHERE  [PseudonymOrNew] = 'Update All'
    ;
    -- clean
    DELETE tmp
    FROM [FinancialRisks].CountryPseudonymsTemp tmp
    INNER JOIN [FinancialRisks].[Countries] cous
        ON  tmp.[CountryName]  = cous.CountryName
        --AND tmp.CountryCapitalIqId = cous.CountryCapitalIqId 
    WHERE tmp.[PseudonymOrNew] = 'Update All'
    ;

   -- update Country data when CountryCapitalIqI is fitting

     UPDATE cous
     SET
            cous.[CountryName]          = NULLIF(LTRIM(RTRIM(src.[CountryName])),''),
     --     cous.[CountryCapitalIqId]   = NULLIF(LTRIM(RTRIM(src.[CountryCapitalIqId])),''),
            cous.[ISOCountryName]       = NULLIF(LTRIM(RTRIM(src.[ISOCountryName])),''),
            cous.[Alpha3Code]           = NULLIF(LTRIM(RTRIM(src.[Alpha3Code])),''),
            cous.[ISO2Code]             = NULLIF(LTRIM(RTRIM(src.[ISO2Code])),''),
            cous.[SovereignRating]      = NULLIF(LTRIM(RTRIM(src.[SovereignRating])),'')
    FROM  [FinancialRisks].[Countries] AS cous
    INNER JOIN  [FinancialRisks].CountryPseudonymsTemp AS src 
        ON  --src.[CountryName]  = cous.CountryName
         src.CountryCapitalIqId = cous.CountryCapitalIqId 
    WHERE src.[PseudonymOrNew] = 'Update All'
      AND NULLIF(LTRIM(RTRIM(src.[CountryName])),'') is NOT NULL
   ;
    -- clean - last not necessary - uncoment when further processing
    --DELETE tmp
    --FROM [FinancialRisks].CountryPseudonymsTemp tmp
    --INNER JOIN [FinancialRisks].[Countries] cous
    --    ON  --tmp.[CountryName]  = cous.CountryName
    --     tmp.CountryCapitalIqId = cous.CountryCapitalIqId 
    --WHERE tmp.[PseudonymOrNew] = 'Update All'

    -- uncoment above when further processing

    RETURN 0
END 