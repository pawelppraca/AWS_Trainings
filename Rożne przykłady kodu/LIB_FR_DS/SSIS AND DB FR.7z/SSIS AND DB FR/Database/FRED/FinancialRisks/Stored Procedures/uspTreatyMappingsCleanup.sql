﻿

/*==========================================================================
*   CREATE PROCEDURE:
*==========================================================================*/

CREATE procedure [FinancialRisks].[uspTreatyMappingsCleanup]
as
/**********************************************************************************************************

**********************************************************************************************************/
begin
	set nocount on


Insert Into [FinancialRisks].[Cedant] ([Name])
Select distinct
CedantName
from [FinancialRisks].[TreatiesQueue]
where ISNUMERIC(CedantName) = 0 and CedantName not in (select name from [FinancialRisks].[Cedant])


SELECT cedant.[CedantId]
      ,[NewReference]
      ,[Year]
      ,[AuditCode]
      ,[RiskCodeGroupId]
      ,[RetroOnly]
      ,[InceptionDate]
      ,[ExpiryDate]
      ,[CurrencyId]
      ,[Limit]
      ,[Excess]
      ,[OccDeductible]
      ,[AggDeductible]
      ,[NumReinstatements]
      ,[ReinstatementAmount]
      ,[SignedLine]
      ,[OurShare]
      ,[ROL]
      ,[CobId]
      ,[Paper]
	  ,[InforceDate]
	  ,[TreatyQueueId]
 INTO #TempQueue
  FROM [FinancialRisks].[TreatiesQueue] treaties_queue
  INNER JOIN [FinancialRisks].[Cedant] cedant on cedant.Name = treaties_queue.CedantName


INSERT INTO [FinancialRisks].[Treaties]
           ([CedantId]
           ,[NewReference]
           ,[Year]
           ,[AuditCode]
           ,[RiskCodeGroupId]
           ,[RetroOnly]
           ,[InceptionDate]
           ,[ExpiryDate]
           ,[CurrencyId]
           ,[Limit]
           ,[Excess]
           ,[OccDeductible]
           ,[AggDeductible]
           ,[NumReinstatements]
           ,[ReinstatementAmount]
           ,[SignedLine]
           ,[OurShare]
           ,[ROL]
           ,[CobId]
           ,[Paper]
		    ,[InforceDate])
Select 
           [CedantId]
          ,[NewReference]
		  ,[Year]
		  ,[AuditCode]
		  ,[RiskCodeGroupId]
		  ,[RetroOnly]
		  ,[InceptionDate]
		  ,[ExpiryDate]
		  ,[CurrencyId]
		  ,[Limit]
		  ,[Excess]
		  ,[OccDeductible]
		  ,[AggDeductible]
		  ,[NumReinstatements]
		  ,[ReinstatementAmount]
		  ,[SignedLine]
		  ,[OurShare]
		  ,[ROL]
		  ,[CobId]
		  ,[Paper]
		  ,[InforceDate]
  FROM #TempQueue
  
  DELETE FROM FinancialRisks.TreatiesQueue where [TreatyQueueId] in (select [TreatyQueueId] from #TempQueue)

  DROP TABLE #TempQueue
  
  set nocount off
end --proc