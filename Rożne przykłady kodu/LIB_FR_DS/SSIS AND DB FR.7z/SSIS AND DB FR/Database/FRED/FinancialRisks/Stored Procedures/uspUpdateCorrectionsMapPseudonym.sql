﻿/*
ChangeLog:
-----------
2023.11.06 - by PP - GSGL-1376 - Add new fields [OriginalEntityinFile] ,[OriginalCountryinFile]
2023.11.16 - by PP - GSGL-1376 - Correct Misletter issue
 */



Create PROCEDURE [FinancialRisks].[uspUpdateCorrectionsMapPseudonym] (@New_Pseudonym AS Nvarchar(255), @OBLIGOR_ENTITY_ID AS INT)
AS
BEGIN

declare @ObligorPseudonymId int

BEGIN TRANSACTION [UpdateCorrections]

BEGIN TRY

	--INSERT PSEUDONYM INTO OBLIGORPSEUDONYM TABLE


    --check if new created ObligorPseudonym exists

    set @ObligorPseudonymId = null
    
    

    if NOT EXISTS (SELECT top 1 1 FROM [FinancialRisks].[ObligorPseudonym] WHERE [ObligorPseudonym] = LTRIM(RTRIM(@New_Pseudonym)))
    BEGIN
        INSERT INTO [FinancialRisks].[ObligorPseudonym]
                   ([ObligorID]
                   ,[ObligorPseudonym])
        VALUES
                   (@OBLIGOR_ENTITY_ID
                   ,@New_Pseudonym)
    END


   SELECT @ObligorPseudonymId = ObligorPseudonymId FROM [FinancialRisks].[ObligorPseudonym] WHERE [ObligorPseudonym] = LTRIM(RTRIM(@New_Pseudonym))

   --Remaping

    --creating temp table with 
     SELECT ObligorID
            ,ltrim(rtrim(ObligorName)) AS 'ObligorName'
            ,ObligorPseudonymId
            ,CountryName
            ,ParentCountryName
    INTO  #Obligors FROM
    (
	    SELECT  EntityId as ObligorId
                ,RTRIM(LTRIM(EntityName)) AS ObligorName 
                ,'' AS ObligorPseudonymId
                ,Domicile AS 'CountryName'
                ,ParentDomicile ParentCountryName
	    FROM FinancialRisks.Entities
	    UNION
	    SELECT  ObligorId
                ,rtrim(ltrim(ObligorPseudonym)) as ObligorName
                ,ObligorPseudonymId,''as 'CountryName'
                ,'' ParentCountryName
	    FROM FinancialRisks.ObligorPseudonym
    )b

    /*
    --Re-Maping with countries - Exposures
    update ex 
        SET ObligorEntityId = obligors.ObligorID, ex.ObligorPseudID = obligors.ObligorPseudonymId
    FROM  [FinancialRisks].exposures ex
    INNER JOIN [FinancialRisks].Countries c ON c.countryid = ex.CountryId 
    INNER JOIN [FinancialRisks].Entities e on e.entityid=ex.ObligorEntityId
    INNER JOIN #obligors obligors ON obligors.ObligorName = LTRIM(RTRIM(e.[EntityName])) + '/' + c.CountryName
    where Obligors.ObligorName = LTRIM(RTRIM(@New_Pseudonym))
    and c.countryName <> e.Domicile

    --Re-Maping with countries - IRonShore
	UPDATE id
        SET EntityId = obligors.ObligorID,  id.ObligorPseudID = obligors.ObligorPseudonymId
    FROM FinancialRisks.Ironshore_Data id 
    INNER JOIN [FinancialRisks].Countries c ON c.countryid = id.CountryId 
    INNER JOIN [FinancialRisks].Entities e on e.entityid=id.entityid
    INNER JOIN #obligors obligors ON obligors.ObligorName = LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName
    where Obligors.ObligorName = LTRIM(RTRIM(@New_Pseudonym))
    and c.countryName <> e.Domicile
*/

    --Re-Maping with countries - Exposures GSGL-1372, using new fields: [OriginalEntityinFile] and [OriginalCountryinFile]
    UPDATE ex 
        SET ObligorEntityId = obligors.ObligorID, ex.ObligorPseudID = obligors.ObligorPseudonymId
    FROM  [FinancialRisks].exposures ex
    INNER JOIN #obligors obligors ON obligors.ObligorName = LTRIM(RTRIM(ex.[OriginalEntityinFile])) + '/' + ex.[OriginalCountryinFile]
    WHERE Obligors.ObligorName = LTRIM(RTRIM(@New_Pseudonym))
    AND ex.[OriginalEntityinFile] is not null



    --Re-Maping with countries - IRonShore
	UPDATE id
        SET EntityId = obligors.ObligorID,  id.ObligorPseudID = obligors.ObligorPseudonymId
    FROM FinancialRisks.Ironshore_Data id 
    INNER JOIN #obligors obligors ON obligors.ObligorName = LTRIM(RTRIM(id.[OriginalEntityinFile])) + '/' + id.[OriginalCountryinFile]
    WHERE Obligors.ObligorName = LTRIM(RTRIM(@New_Pseudonym))
    AND id.[OriginalEntityinFile] is not null






	COMMIT TRANSACTION [UpdateCorrections]

END TRY


BEGIN CATCH

	ROLLBACK TRANSACTION [UpdateCorrections]

	--THROW ERROR
    INSERT INTO [FinancialRisks].[Mapping_Errors]
                                VALUES
                                (SUSER_SNAME(),
                                ERROR_NUMBER(),
                                ERROR_STATE(),
                                ERROR_SEVERITY(),
                                ERROR_LINE(),
                                ERROR_PROCEDURE(),
                                ERROR_MESSAGE(),
                                GETDATE());

END CATCH  


END