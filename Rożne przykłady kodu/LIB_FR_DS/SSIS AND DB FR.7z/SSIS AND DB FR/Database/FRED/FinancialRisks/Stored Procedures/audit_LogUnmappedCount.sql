﻿CREATE PROCEDURE [FinancialRisks].[audit_LogUnmappedCount]
	@typeName nvarchar(30)  
AS
DECLARE @countOfRows INT = 0
	   ,@inforceDate DATETIME 

SELECT @inforceDate=MAX( inforcedate) 
FROM financialrisks.ExposuresQueue
;
IF (@inforceDate is NOT NULL ) 
BEGIN
	SELECT @countOfRows = count(*) 
	FROM [FinancialRisks].[audit_LogSSISMappings] 
	WHERE [Type] = @typeName 
	and inforcedate = @inforceDate
	;
	IF @countOfRows <> 0 
	BEGIN
		INSERT INTO [FinancialRisks].[audit_LogSSISMappings]
				   ([InforceDate],[Type],[Unmapped])
		VALUES
			  (@inforceDate
			  ,@typeName
			  ,@countOfRows
			  )	 ;
	END
END
RETURN 0


   
