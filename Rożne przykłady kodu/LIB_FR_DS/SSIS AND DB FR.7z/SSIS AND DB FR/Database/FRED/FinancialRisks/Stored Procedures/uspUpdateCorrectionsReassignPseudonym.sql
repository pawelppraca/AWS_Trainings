﻿CREATE   PROCEDURE FinancialRisks.[uspUpdateCorrectionsReassignPseudonym] (@OBLIGOR_ENTITY_ID AS INT,@ENTITY_ID AS INT)
AS
BEGIN

BEGIN TRANSACTION [UpdateCorrections]

BEGIN TRY

		----UPDATE EXPOSURES
	UPDATE FinancialRisks.Exposures SET ObligorEntityId = @ENTITY_ID  WHERE ObligorPseudID = @OBLIGOR_ENTITY_ID

	UPDATE FinancialRisks.Ironshore_Data SET EntityId = @ENTITY_ID  WHERE ObligorPseudID = @OBLIGOR_ENTITY_ID

	----UPDATE OBLIGORPSEUDONYM
	UPDATE FinancialRisks.ObligorPseudonym SET obligorID = @ENTITY_ID  WHERE ObligorPseudonymId = @OBLIGOR_ENTITY_ID

	COMMIT TRANSACTION [UpdateCorrections]

END TRY

BEGIN CATCH

	ROLLBACK TRANSACTION [UpdateCorrections]

	--THROW ERROR
    INSERT INTO [FinancialRisks].[Mapping_Errors]
                                VALUES
                                (SUSER_SNAME(),
                                ERROR_NUMBER(),
                                ERROR_STATE(),
                                ERROR_SEVERITY(),
                                ERROR_LINE(),
                                ERROR_PROCEDURE(),
                                ERROR_MESSAGE(),
                                GETDATE());

END CATCH  



END;