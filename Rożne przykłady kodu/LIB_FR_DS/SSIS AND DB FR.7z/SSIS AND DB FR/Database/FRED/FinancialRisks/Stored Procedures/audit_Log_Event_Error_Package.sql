﻿CREATE procedure [FinancialRisks].[audit_Log_Event_Error_Package]
	 @logID		int
	,@message	varchar(64) = null	--optional, for custom failures
with execute as caller
as
/**********************************************************************************************************
* SP Name:
*		[audit].[Log_Event_Error_Package]
* Parameters:
*		 @logID		int
*		,@message	varchar(64) = null	--optional, for custom failures
*  
* Purpose:	This stored procedure logs an error entry in the custom event-log table.
*	Status = 0: Running (Incomplete)
*	Status = 1: Complete
*	Status = 2: Failed
*              
* Example:
		exec [audit].[Log_Event_Error_Package] 1, 'Failed'
		select * from audit.LogSSISPackage where LogID = 1
*              
* Revision Date/Time:
*	May 25, 2005	(G Dickinson)	- Authored
*
**********************************************************************************************************/
begin
	set nocount on
	
	declare
		 @failureTask		varchar(64)
		,@packageName		varchar(64)
		,@executionGuid		uniqueidentifier

	if @message is null begin
		select 
			 @packageName = upper(PackageName)
			,@executionGuid = ExecutionGuid
		from FinancialRisks.audit_LogSSISPackage
		where LogID = @logID

		--select top 1 @failureTask = [source]
		--from [dbo].[sysssislog]
		--where executionid = @executionGuid
		--	and (upper([event]) = 'ONERROR')
		--	and upper([source]) <> @packageName
		--order by [endtime] desc
	end else begin
		set @failureTask = @message
	end --if

	update FinancialRisks.audit_LogSSISPackage set
		 EndTime = getdate()
		,Status = 2	--Failed
		,FailureTask = @failureTask
	where
		LogID = @logID

	set nocount off
end --proc