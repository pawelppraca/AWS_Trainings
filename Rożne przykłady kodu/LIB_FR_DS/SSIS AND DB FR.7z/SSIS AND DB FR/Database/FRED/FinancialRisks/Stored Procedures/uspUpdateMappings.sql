﻿CREATE   PROCEDURE [FinancialRisks].[uspUpdateMappings]
AS
BEGIN

BEGIN TRANSACTION [TranUpdateMapping]

  BEGIN TRY


                SET NOCOUNT ON;

                DROP TABLE IF EXISTS #tempCapIQMatches
                DROP TABLE IF EXISTS #tempMatchesNames
                DROP TABLE IF EXISTS #tempNoMatches
                DROP TABLE IF EXISTS #matches
                DROP TABLE IF EXISTS #pseudonyms
                DROP TABLE IF EXISTS #Duplicates
                DROP TABLE IF EXISTS #keepDelete
                DROP TABLE IF EXISTS #fix
                DROP TABLE IF EXISTS #InvalidMultiCapIQ
                DROP TABLE IF EXISTS #matchAlreadyExists
                DROP TABLE IF EXISTS #ObligorPseudonymsTempMatch
				DROP TABLE IF EXISTS #tempNamesChanges


                /*Identify Entities with more thatn 1 CAPIQ*/

                select EntityName 
                into #InvalidMultiCapIQ 
                from FinancialRisks.ObligorPseudonymsTemp 
                where EntityName  in 
                (select EntityName from  (
                select *
                , DENSE_RANK() OVER (PARTITION BY entityname ORDER BY [CapitalIqId] DESC ) AS ranking
                                from FinancialRisks.ObligorPseudonymsTemp 
                where EntityName in  
                ( select EntityName
                  from FinancialRisks.ObligorPseudonymsTemp 
                  group by EntityName
                  having count (EntityName) >1)
                  )a
                where ranking <>1)


                /*CapIQ Matches*/
                select  temp.UnmappedObligorName,temp.CapitalIqId,temp.EntityName as 'NewEntityName',en.EntityName as 'OldName',en.CapitalIqId as 'OldCapitalIQID',
                en.EntityId, temp.[EntityName],temp.ParentEntityName,temp.ParentCapitalIqId,temp.SPRating, temp.GCHPRating, temp.LibertyRating,temp.TradeSectorName,
                temp.ParentSPRating, temp.ParentGCHPRating,temp.Domicile,temp.ParentDomicile ,
				temp.DefaultTradeSectorName,	temp.DefaultDomicile, temp.DefaultRating,	
				temp.OverrideTradeSectorName, temp.OverrideDomicile, temp.OverrideRating
                into #tempCapIQMatches
                FROM [FinancialRisks].[ObligorPseudonymsTemp] temp
                inner join FinancialRisks.Entities en on temp.CapitalIqId = en.CapitalIqId
                where [PesudonymOrNew] = 'New' and temp.entityName not in (select EntityName  from  #InvalidMultiCapIQ )

                /*Name Matches*/
                select  temp.UnmappedObligorName,temp.CapitalIqId,temp.EntityName as 'NewEntityName',en.EntityName as 'OldName',en.CapitalIqId as 'OldCapitalIQID',
                en.EntityId, temp.[EntityName],temp.ParentEntityName,temp.ParentCapitalIqId,temp.SPRating, temp.GCHPRating, temp.LibertyRating,temp.TradeSectorName,
                temp.ParentSPRating, temp.ParentGCHPRating,temp.Domicile,temp.ParentDomicile ,
				temp.DefaultTradeSectorName,	temp.DefaultDomicile, temp.DefaultRating,	temp.OverrideTradeSectorName, temp.OverrideDomicile, temp.OverrideRating
                into #tempMatchesNames
                FROM [FinancialRisks].[ObligorPseudonymsTemp]  temp
                inner join FinancialRisks.Entities en on   RTRIM(LTRIM(temp.EntityName)) = en.EntityName
                where  temp.EntityName not in (select NewEntityName from #tempCapIQMatches)
                and [PesudonymOrNew] = 'New' and temp.entityName not in (select EntityName  from  #InvalidMultiCapIQ )


                /*No Matches*/
                select  *
                into #tempNoMatches
                FROM [FinancialRisks].[ObligorPseudonymsTemp] temp
                where UnmappedObligorName not in (
                select UnmappedObligorName from #tempCapIQMatches
                union
                select UnmappedObligorName from #tempMatchesNames 
                )and [PesudonymOrNew] = 'New' and temp.entityName not in (select EntityName  from  #InvalidMultiCapIQ )


                /*Name Matches - Update All, Update Name*/
                select  temp.UnmappedObligorName as UnmappedObligorName,temp.CapitalIqId,temp.EntityName as 'NewEntityName',en.EntityName as 'OldName',en.CapitalIqId as 'OldCapitalIQID',
                en.EntityId, temp.[EntityName],temp.ParentEntityName,temp.ParentCapitalIqId,temp.SPRating, temp.GCHPRating, temp.LibertyRating,temp.TradeSectorName,
                temp.ParentSPRating, temp.ParentGCHPRating,temp.Domicile,temp.ParentDomicile ,
				temp.DefaultTradeSectorName,	temp.DefaultDomicile, temp.DefaultRating,	temp.OverrideTradeSectorName, temp.OverrideDomicile, temp.OverrideRating
                into #tempNamesChanges
                FROM [FinancialRisks].[ObligorPseudonymsTemp]  temp
                inner join FinancialRisks.Entities en on   RTRIM(LTRIM(temp.EntityName)) <> en.EntityName and temp.ObligorID = en.EntityId
                where  temp.EntityName not in (select ObligorPseudonym from FinancialRisks.ObligorPseudonym)
                and [PesudonymOrNew] in ( 'Update Al','Update Na') and temp.entityName not in (select EntityName from  #InvalidMultiCapIQ)

                /* Find Unmapped obligors which has an EntityName whichalready exists and add as pseduonym not update entity then update entity information */
                select entityname, EntityId  into #matchAlreadyExists from FinancialRisks.Entities e
                where entityname in (select temp.entityname from  [FinancialRisks].[ObligorPseudonymsTemp] temp)

                select op.*, m.EntityId into #ObligorPseudonymsTempMatch from FinancialRisks.ObligorPseudonymsTemp op
                inner join #matchAlreadyExists m on m.EntityName = op.EntityName


                INSERT INTO FinancialRisks.ObligorPseudonym(ObligorID, ObligorPseudonym)
                select distinct EntityId,UnmappedObligorName from #ObligorPseudonymsTempMatch where UnmappedObligorName not in (select ObligorPseudonym from FinancialRisks.ObligorPseudonym)


                UPDATE FinancialRisks.Entities
                SET 
                ParentEntityName = temp.ParentEntityName,
                CapitalIqId = temp.CapitalIqId,
                ParentCapitalIqId = temp.ParentCapitalIqId,
                SPRating = temp.SPRating,
                GCHPRating = temp.GCHPRating,
                LibertyRating = temp.LibertyRating,
                TradeSectorID = ts.TradeSectorID,
                ParentSPRating = temp.ParentSPRating,
                ParentGCHPRating = temp.ParentGCHPRating,
                Domicile = temp.Domicile,
                ParentDomicile = temp.ParentDomicile,
				DefaultTradeSectorId = ts2.DefaultTradeSectorId,	
				DefaultDomicile = temp.DefaultDomicile, 
				DefaultRating = temp.DefaultRating,	
				OverrideTradeSectorId = ts3.OverrideTradeSectorId, 
				OverrideDomicile = temp.OverrideDomicile, 
				OverrideRating = temp.OverrideRating
                FROM FinancialRisks.Entities e
                INNER JOIN #ObligorPseudonymsTempMatch temp ON temp.EntityId = e.EntityID
                LEFT JOIN (SELECT distinct MAX(TradeSectorID) as TradeSectorID , TradeSectorName FROM FinancialRisks.TradeSector GROUP BY  TradeSectorName) ts on ts.TradeSectorName = temp.TradeSectorName
				LEFT JOIN (SELECT distinct MAX(TradeSectorID) as DefaultTradeSectorID , TradeSectorName as DefaultTradeSectorName FROM FinancialRisks.TradeSector GROUP BY  TradeSectorName) ts2 on ts2.DefaultTradeSectorName = temp.DefaultTradeSectorName
				LEFT JOIN (SELECT distinct MAX(TradeSectorID) as OverrideTradeSectorID , TradeSectorName as OverrideTradeSectorName FROM FinancialRisks.TradeSector GROUP BY  TradeSectorName) ts3 on ts3.OverrideTradeSectorName = temp.OverrideTradeSectorName
                /*Updates*/

                select distinct  entityid,EntityName,ParentEntityName ,CapitalIqId ,ParentCapitalIqId ,SPRating  ,GCHPRating  ,LibertyRating,TradeSectorName,ParentSPRating ,ParentGCHPRating ,Domicile ,ParentDomicile ,
				DefaultTradeSectorName,	DefaultDomicile, DefaultRating,	OverrideTradeSectorName, OverrideDomicile, OverrideRating
                into #matches 
                from #tempCapIQMatches
                union
                select  entityid,EntityName,ParentEntityName ,CapitalIqId ,ParentCapitalIqId ,SPRating  ,GCHPRating  ,LibertyRating,TradeSectorName,ParentSPRating ,ParentGCHPRating ,Domicile ,ParentDomicile ,
				DefaultTradeSectorName,	DefaultDomicile, DefaultRating,	OverrideTradeSectorName, OverrideDomicile, OverrideRating
                from #tempMatchesNames



                /*Update old name to new name and other details */


                UPDATE FinancialRisks.Entities
                SET EntityName = temp.[EntityName],
                ParentEntityName = temp.ParentEntityName,
                CapitalIqId = temp.CapitalIqId,
                ParentCapitalIqId = temp.ParentCapitalIqId,
                SPRating = temp.SPRating,
                GCHPRating = temp.GCHPRating,
                LibertyRating = temp.LibertyRating,
                TradeSectorID = ts.TradeSectorID,
                ParentSPRating = temp.ParentSPRating,
                ParentGCHPRating = temp.ParentGCHPRating,
                Domicile = temp.Domicile,
                ParentDomicile = temp.ParentDomicile,
				DefaultTradeSectorId = ts2.DefaultTradeSectorId,	
				DefaultDomicile = temp.DefaultDomicile, 
				DefaultRating = temp.DefaultRating,	
				OverrideTradeSectorId = ts3.OverrideTradeSectorId, 
				OverrideDomicile = temp.OverrideDomicile, 
				OverrideRating = temp.OverrideRating
                FROM FinancialRisks.Entities e
                INNER JOIN #matches temp ON temp.EntityId = e.EntityID
                                                LEFT JOIN (SELECT distinct MAX(TradeSectorID) as TradeSectorID , TradeSectorName
                                                                FROM FinancialRisks.TradeSector
                                                                GROUP BY  TradeSectorName) ts on ts.TradeSectorName = temp.TradeSectorName
												LEFT JOIN (SELECT distinct MAX(TradeSectorID) as DefaultTradeSectorId , TradeSectorName as DefaultTradeSectorName
                                                                FROM FinancialRisks.TradeSector
                                                                GROUP BY  TradeSectorName) ts2 on ts2.DefaultTradeSectorName = temp.DefaultTradeSectorName
												LEFT JOIN (SELECT distinct MAX(TradeSectorID) as OverrideTradeSectorId , TradeSectorName as OverrideTradeSectorName
                                                                FROM FinancialRisks.TradeSector
                                                                GROUP BY  TradeSectorName) ts3 on ts3.OverrideTradeSectorName = temp.OverrideTradeSectorName
                where temp.entityname not in (select entityname from #matchAlreadyExists)

                /*New*/


                --Select * from #tempNoMatches
                --Insert New
                INSERT INTO [FinancialRisks].[Entities]
                                                  ([EntityName]
                                                  ,[ParentEntityName]
                                                  ,[CapitalIqId]
                                                  ,[ParentCapitalIqId]
                                                  ,[SPRating]
                                                  ,[GCHPRating]
                                                  ,[LibertyRating]
                                                  ,[TradeSectorId]
                                                  ,[ParentSPRating]
                                                  ,[ParentGCHPRating]
                                                  ,[ParentLibertyRating]
                                                  ,[Domicile]
                                                  ,[ParentDomicile]
												  ,DefaultTradeSectorId
												  ,DefaultDomicile
												  ,DefaultRating
												  ,OverrideTradeSectorId
												  ,OverrideDomicile
												  ,OverrideRating)
                Select distinct rtrim(ltrim([EntityName])) as '[EntityName]'
                                  ,[ParentEntityName]
                                  ,[CapitalIqId]
                                  ,[ParentCapitalIqId]
                                  ,[SPRating]
                                  ,[GCHPRating]
                                  ,[LibertyRating]
                                  ,[TradeSectorID]
                                  ,[ParentSPRating]
                                  ,[ParentGCHPRating]
                                  ,[ParentLibertyRating]
                                  ,[Domicile]
                                  ,[ParentDomicile]
								  ,DefaultTradeSectorId
									,DefaultDomicile
									,DefaultRating
									,OverrideTradeSectorId
									,OverrideDomicile
									,OverrideRating
                                  FROM #tempNoMatches temp
                                                LEFT JOIN (SELECT distinct MAX(TradeSectorID) as TradeSectorID , TradeSectorName
                                                                FROM FinancialRisks.TradeSector
                                                                GROUP BY  TradeSectorName) ts on ts.TradeSectorName = temp.TradeSectorName
												LEFT JOIN (SELECT distinct MAX(TradeSectorID) as DefaultTradeSectorId , TradeSectorName as DefaultTradeSectorName
                                                                FROM FinancialRisks.TradeSector
                                                                GROUP BY  TradeSectorName) ts2 on ts2.DefaultTradeSectorName = temp.DefaultTradeSectorName
												LEFT JOIN (SELECT distinct MAX(TradeSectorID) as OverrideTradeSectorId , TradeSectorName as OverrideTradeSectorName
                                                                FROM FinancialRisks.TradeSector
                                                                GROUP BY  TradeSectorName) ts3 on ts3.OverrideTradeSectorName = temp.OverrideTradeSectorName

                /*Pseudonyms*/
                select distinct ObligorID,ObligorPseudonym
                into #pseudonyms
                from
                (select DISTINCT EntityId AS 'ObligorID',OldName AS 'ObligorPseudonym' 
                from #tempCapIQMatches
                where NewEntityName <> oldname and EntityName not in (select entityname from #matchAlreadyExists) 
                UNION 
                select DISTINCT EntityId AS 'ObligorID',UnmappedObligorName AS 'ObligorPseudonym' from #tempCapIQMatches
                where NewEntityName <> oldname and EntityName not in (select entityname from #matchAlreadyExists) 
                UNION
                select DISTINCT EntityId AS 'ObligorID',UnmappedObligorName AS 'ObligorPseudonym' from #tempCapIQMatches
                where NewEntityName = oldname and EntityName not in (select entityname from #matchAlreadyExists) 
                union
                select DISTINCT EntityId AS 'ObligorID',UnmappedObligorName AS 'ObligorPseudonym' from #tempMatchesNames where EntityName not in (select entityname from #matchAlreadyExists) 
                union
                Select DISTINCT ent.EntityId AS 'ObligorID',temp.UnmappedObligorName AS 'ObligorPseudonym' 
                from #tempNoMatches temp
                inner join FinancialRisks.Entities ent on ent.EntityName = RTRIM(LTRIM(temp.EntityName))
                where temp.UnmappedObligorName <> temp.EntityName and temp.EntityName not in (select entityname from #matchAlreadyExists) 
                union
                select DISTINCT EntityId AS 'ObligorID',OldName AS 'ObligorPseudonym' from #tempNamesChanges where EntityName not in (select entityname from #matchAlreadyExists) 

                )a
                where ObligorPseudonym not in (select ObligorPseudonym from financialrisks.ObligorPseudonym)

                INSERT INTO FinancialRisks.ObligorPseudonym(ObligorID, ObligorPseudonym)
                select distinct ObligorID,ObligorPseudonym
                from  #pseudonyms


                DROP TABLE IF EXISTS #tempCapIQMatches
                DROP TABLE IF EXISTS #tempMatchesNames
                DROP TABLE IF EXISTS #tempNoMatches
                DROP TABLE IF EXISTS #matches
                DROP TABLE IF EXISTS #pseudonyms
				DROP TABLE IF EXISTS #tempNamesChanges


                /*Update All Fields for obligor*/
                UPDATE FinancialRisks.Entities
                SET EntityName = tmou.[EntityName],
                ParentEntityName = tmou.ParentEntityName,
                CapitalIqId = tmou.CapitalIqId,
                ParentCapitalIqId = tmou.ParentCapitalIqId,
                SPRating = tmou.SPRating,
                GCHPRating = tmou.GCHPRating,
                LibertyRating = tmou.LibertyRating,
                TradeSectorID = ts.TradeSectorID,
                ParentSPRating = tmou.ParentSPRating,
                ParentGCHPRating = tmou.ParentGCHPRating,
                Domicile = tmou.Domicile,
                ParentDomicile = tmou.ParentDomicile,
				DefaultTradeSectorId = ts2.TradeSectorId,	
				DefaultDomicile = tmou.DefaultDomicile, 
				DefaultRating = tmou.DefaultRating,	
				OverrideTradeSectorId = ts3.TradeSectorId, 
				OverrideDomicile = tmou.OverrideDomicile, 
				OverrideRating = tmou.OverrideRating
                FROM FinancialRisks.Entities e
                INNER JOIN FinancialRisks.ObligorPseudonymsTemp tmou ON tmou.[ObligorID] = e.EntityID
                LEFT JOIN FinancialRisks.TradeSector ts ON ts.TradeSectorName = tmou.[TradeSectorName]   
				LEFT JOIN FinancialRisks.TradeSector ts2 ON ts2.TradeSectorName = tmou.DefaultTradeSectorName
				LEFT JOIN FinancialRisks.TradeSector ts3 ON ts3.TradeSectorName = tmou.OverrideTradeSectorName
                Where tmou.[PesudonymOrNew] = 'Update Al'


                /*Update Name Field for obligor*/
                UPDATE FinancialRisks.Entities
                SET EntityName = tmou.[EntityName]
                FROM FinancialRisks.Entities e
                INNER JOIN FinancialRisks.ObligorPseudonymsTemp tmou ON tmou.[ObligorID] = e.EntityID
                Where tmou.[PesudonymOrNew] = 'Update Na'


                COMMIT TRANSACTION [TranUpdateMapping]

                 

  END TRY

  BEGIN CATCH

                                ROLLBACK TRANSACTION [TranUpdateMapping]

                  --THROW ERROR
                                                INSERT INTO [FinancialRisks].Mapping_Errors
                                VALUES
                                (SUSER_SNAME(),
                                ERROR_NUMBER(),
                                ERROR_STATE(),
                                ERROR_SEVERITY(),
                                ERROR_LINE(),
                                ERROR_PROCEDURE(),
                                ERROR_MESSAGE(),
                                GETDATE());
  END CATCH  


END
GO


