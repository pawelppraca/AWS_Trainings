﻿CREATE PROCEDURE [FinancialRisks].[uspToggleIdentityInsert] @Option VARCHAR(3)
AS
   IF(@Option = 'ON')
    BEGIN
		PRINT 'Turning Identity Insert on'
		SET IDENTITY_INSERT [FinancialRisks].[Entities] ON
	END
   ELSE 
    BEGIN
		PRINT 'Turning Identity Insert off'
		SET IDENTITY_INSERT [FinancialRisks].[Entities] OFF
	END