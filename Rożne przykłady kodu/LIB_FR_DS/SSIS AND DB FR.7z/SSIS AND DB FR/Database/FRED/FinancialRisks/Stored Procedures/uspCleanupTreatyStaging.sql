﻿
CREATE PROCEDURE [FinancialRisks].[uspCleanupTreatyStaging] @CobId INT
AS

/********************************************************************************************/

UPDATE [FinancialRisks].[TreatiesQueue]
set cedantName =cedant.[CedantId]
FROM [FinancialRisks].[TreatiesQueue] eq
INNER JOIN [FinancialRisks].[Cedant] cedant on cedant.Name = ltrim(rtrim(eq.cedantName))
  AND [CobId] = @CobId
/********************************************************************************************/

SELECT [TreatyQueueId]
      ,[CedantName]
      ,[NewReference]
      ,[Year]
      ,[AuditCode]
      ,[RiskCodeGroupId]
      ,[RetroOnly]
      ,[InceptionDate]
      ,[ExpiryDate]
      ,[CurrencyId]
      ,[Limit]
      ,[Excess]
      ,[OccDeductible]
      ,[AggDeductible]
      ,[NumReinstatements]
      ,[ReinstatementAmount]
      ,[SignedLine]
      ,[OurShare]
      ,[ROL]
      ,[CobId]
      ,[Paper]
      ,[InforceDate]
      ,[Source]
      ,[UserNotified]
	  INTO #TempTable
  FROM [FinancialRisks].[TreatiesQueue] treaties_queue
  where ISNUMERIC([CedantName]) = 1
	and  [CobID] = @CobId

INSERT INTO [FinancialRisks].[Treaties]
           (CedantId
      ,[NewReference]
      ,[Year]
      ,[AuditCode]
      ,[RiskCodeGroupId]
      ,[RetroOnly]
      ,[InceptionDate]
      ,[ExpiryDate]
      ,[CurrencyId]
      ,[Limit]
      ,[Excess]
      ,[OccDeductible]
      ,[AggDeductible]
      ,[NumReinstatements]
      ,[ReinstatementAmount]
      ,[SignedLine]
      ,[OurShare]
      ,[ROL]
      ,[CobId]
      ,[Paper]
      ,[InforceDate]
      ,[Source]
)	 SELECT
	 [CedantName]
      ,[NewReference]
      ,[Year]
      ,[AuditCode]
      ,[RiskCodeGroupId]
      ,[RetroOnly]
      ,[InceptionDate]
      ,[ExpiryDate]
      ,[CurrencyId]
      ,[Limit]
      ,[Excess]
      ,[OccDeductible]
      ,[AggDeductible]
      ,[NumReinstatements]
      ,[ReinstatementAmount]
      ,[SignedLine]
      ,[OurShare]
      ,[ROL]
      ,[CobId]
      ,[Paper]
      ,[InforceDate]
      ,[Source]
	FROM   #TempTable

DELETE FROM [FinancialRisks].[TreatiesQueue]
WHERE TreatyQueueId IN (SELECT TreatyQueueId FROM #TempTable)

DROP TABLE #TempTable