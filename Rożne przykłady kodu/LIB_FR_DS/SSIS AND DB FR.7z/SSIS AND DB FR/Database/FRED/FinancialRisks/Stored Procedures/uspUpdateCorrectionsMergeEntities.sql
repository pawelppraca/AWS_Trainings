﻿--STORED PROC 1
CREATE   PROCEDURE FinancialRisks.[uspUpdateCorrectionsMergeEntities] (@BEFORE_ENTITY_ID AS INT,@AFTER_ENTITY_ID AS INT)
AS
BEGIN
BEGIN TRANSACTION [UpdateCorrections]

BEGIN TRY
	----UPDATE EXPOSURES
	UPDATE FinancialRisks.Exposures SET ObligorEntityId = @AFTER_ENTITY_ID
	--FROM FinancialRisks.Exposures 
	--INNER JOIN FinancialRisks.ObligorPseudonym ON ObligorPseudID=ObligorPseudonymId
	WHERE ObligorEntityId = @BEFORE_ENTITY_ID

	UPDATE FinancialRisks.Ironshore_Data SET EntityId = @AFTER_ENTITY_ID
	--FROM FinancialRisks.Ironshore_Data
	--INNER JOIN FinancialRisks.ObligorPseudonym ON ObligorPseudID=ObligorPseudonymId
	WHERE EntityId = @BEFORE_ENTITY_ID

	----UPDATE  ObligorPseudonym

	UPDATE FinancialRisks.ObligorPseudonym SET ObligorID = @AFTER_ENTITY_ID WHERE ObligorID = @BEFORE_ENTITY_ID

	----INSERT PREVIOUS ENTITY TO ObligorPseudonym
	INSERT INTO FinancialRisks.ObligorPseudonym (ObligorID,ObligorPseudonym)
	SELECT @AFTER_ENTITY_ID AS ObligorID, EntityName AS ObligorPseudonym FROM FinancialRisks.Entities e WHERE EntityId = @BEFORE_ENTITY_ID
	AND  EntityName not in (SELECT obligorPseudonym from FinancialRisks.ObligorPseudonym where Entityname = ObligorPseudonym)
	
	--DELETE NOW THAT ENTITY IN PSEUDONYM TABLE
	DELETE FROM  FinancialRisks.Entities WHERE EntityId = @BEFORE_ENTITY_ID

	COMMIT TRANSACTION [UpdateCorrections]

END TRY

BEGIN CATCH

	ROLLBACK TRANSACTION [UpdateCorrections]

	--THROW ERROR
    INSERT INTO [FinancialRisks].[Mapping_Errors]
                                VALUES
                                (SUSER_SNAME(),
                                ERROR_NUMBER(),
                                ERROR_STATE(),
                                ERROR_SEVERITY(),
                                ERROR_LINE(),
                                ERROR_PROCEDURE(),
                                ERROR_MESSAGE(),
                                GETDATE());

END CATCH  


END;