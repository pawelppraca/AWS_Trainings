GFR OLD

;WITH FX AS   									
									
(   									
            SELECT    									
                        ccyFrom.CurrencykEY, 									
                        ccyfrom.ISOCurrencyKey,  									
                        ccyFrom.CurrencyCode,									
                        YEAR(roe.ExchangeRateDateKey) as FXYear,  									
                        roe.ExchangeRate   									
            FROM    									
                        [sources].[vw_dwhr_Currencies] ccyFrom   									
                        INNER JOIN sources.vw_dwhr_ISOCurrencies ccyFromISO ON ccyFrom.ISOCurrencyKey = ccyFromISO.ISOCurrencyKey   									
                        INNER JOIN sources.vw_dwhr_ExchangeRates roe ON ccyFromISO.ISOCurrencyKey = roe.ISOCurrencyFromKey   									
                        INNER JOIN sources.vw_dwhr_ISOCurrencies ccyToISO ON roe.ISOCurrencyToKey = ccyToISO.ISOCurrencyKey   									
            WHERE    									
                        ccyToISO.ISOCurrencyCode = N'USD'   									
                      --  AND roe.ExchangeRateTypeCode = N'[Lloyd''s PIM]'  									
						AND roe.ExchangeRateTypeCode = N'[GAAP Plan]' 			
						AND YEAR(roe.ExchangeRateDateKey) = year(getdate()) 			
), 									
									
									
 E1(N) AS (SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL									
           SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL									
           SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL									
           SELECT 1),                 --10E1  									
 E2(N) AS (SELECT 1 FROM E1 a, E1 b), --10E2  									
 E4(N) AS (SELECT 1 FROM E2 a, E2 b), --10E3  									
 E8(N) AS (SELECT 1 FROM E4 a, E4 b), --10E4  									
E16(N) AS (SELECT 1 FROM E8 a, E8 b),  --10E16 									
									
-- synd amort GFE									
Base1 as (									
									
SELECT p.UnderwriterReference,									
p.InceptionDateKey,									
p.ExpiryDateKey,									
--clients.ClientName as Obligor,									
									
									
CASE clients.ClientName									
    WHEN N'<<Unknown>>' THEN ''									
    ELSE clients.ClientName									
END AS Obligor,  									
									
Clients.[D&BDUNSNumber] as CapIQ,									
	gfea.AreaName as areaname,								
       Coalesce(am.AmortisationStartDateKey, p.InceptionDateKey) as AmortisationStartDateKey									
									
	   ,(gfe.GlobalFinancialExposure * COALESCE(p.signedpercentage, p.EstimatedSignedPercentage)/100) AS AmortisationAmountOrig								
	   ,((gfe.GlobalFinancialExposure * COALESCE(p.signedpercentage, p.EstimatedSignedPercentage)/100))/FX.ExchangeRate AS AmortisationAmount 								
	   ,COALESCE(DATEADD(DAY,-1,am2.AmortisationStartDateKey), DATEADD(DAY,1,am.AmortisationStartDateKey), DATEADD(DAY,1,p.expirydatekey) ) as AmortisationEndDateKey								
	   ,COALESCE(am2.AmortisationAmount/FX.ExchangeRate, 0) as NextAmortisationAmount								
	   ,COALESCE(am2.AmortisationAmount, 0) as NextAmortisationAmountOrig								
	   ,(am.AmortisationAmount/FX.ExchangeRate)-COALESCE(am2.AmortisationAmount/FX.ExchangeRate,0)  AS AmountToBeAmortisedPeriod								
	    ,(am.AmortisationAmount)-COALESCE(am2.AmortisationAmount,0)  AS AmountToBeAmortisedPeriodOrig								
	  	   							
									
									
FROM sources.vw_dwhr_Policies p									
		INNER JOIN sources.vw_dwhr_MasterReservingClassHierarchy mrc ON p.ClassAccumulatorKey = mrc.ClassAccumulatorKey AND mrc.MasterReservingClassName = 'Financial Risk Solutions - UK and Ireland'							
		LEFT JOIN sources.vw_dwhr_Clients clients on clients.ClientKey = p.ObligorKey 							
		LEFT JOIN sources.vw_dwhr_Amortisations am on p.PolicyKey = am.PolicyKey AND am._lastaction <> 'D'							
		LEFT JOIN sources.vw_dwhr_Amortisations am2 on am.AmortisationsSequence -1 = am2.AmortisationsSequence AND am.PolicyKey = am2.PolicyKey AND am2._lastaction <> 'D'							
		INNER JOIN FX on FX.CurrencyKey = p.PrimaryCurrencyKey --and p.PolicyYearOfAccount = FX.FXYear							
		LEFT JOIN (Select PolicyReference, areakey,gfe._CurrentFlag, sum(globalfinancialexposure / FX.ExchangeRate) as globalfinancialexposure from sources.vw_dwhr_GlobalFinancialExposures gfe							
		INNER JOIN FX on FX.CurrencyKey = gfe.CurrencyKey-- and '20' + left(right(PolicyReference,5),2) = FX.FXYear							
																										
		group by PolicyReference, areakey,gfe._CurrentFlag) gfe 							
									
		on LEFT(gfe.PolicyReference, 12) = p.UnderwriterReference AND gfe._CurrentFlag = 1  							
									
		INNER JOIN sources.vw_dwhr_Areas gfea ON gfea.AreaKey = gfe.AreaKey							
									
									
WHERE p._CurrentFlag = 1									
									
 AND getdate() between p.InceptionDateKey AND p.ExpiryDateKey									
-- and UnderwriterReference like  '%582483%' 									
--  and (UnderwriterReference like  '%582510%' or UnderwriterReference like '%582541%') AND clients.ClientName like '%alabama%'									
)									
									
-- synd amort LIMIT									
,									
Base2 as (									
									
SELECT p.UnderwriterReference,									
case when DeclarationCount >= 0 THEN limits.InceptionDateKey else p.InceptionDateKey end as InceptionDateKey,									
case when DeclarationCount >= 0 then limits.ExpiryDateKey else p.ExpiryDateKey end as ExpiryDateKey,									
									
--Obligor,									
CASE Obligor									
    WHEN N'<<Unknown>>' THEN ''									
    ELSE Obligor									
END AS Obligor,									
									
limits.[D&BDUNSNumber] as CapIQ, 									
limits.areaname,									
       Coalesce(am.AmortisationStartDateKey, case when DeclarationCount >= 0 THEN limits.InceptionDateKey else p.InceptionDateKey end) as AmortisationStartDateKey,									
	   limits.LibertyShare as AmortisedAmountOrig,								
       limits.LibertyShare/FX.ExchangeRate as AmortisationAmount									
	   --coalesce(am.AmortisationAmount,(limits.LibertyShare/FX.ExchangeRate) /** (p.WrittenPercentage/100)*/) as AmortisationAmount								
	   ,COALESCE(DATEADD(DAY,-1,am2.AmortisationStartDateKey), DATEADD(DAY,1,am.AmortisationStartDateKey), DATEADD(DAY,1,case when DeclarationCount >= 0 then limits.ExpiryDateKey else p.ExpiryDateKey end) ) as AmortisationEndDateKey								
	   ,COALESCE(am2.AmortisationAmount/FX.ExchangeRate, 0) as NextAmortisationAmount								
	    ,COALESCE(am2.AmortisationAmount, 0) as NextAmortisationAmountOrig								
	   ,(am.AmortisationAmount/FX.ExchangeRate)-COALESCE(am2.AmortisationAmount/FX.ExchangeRate,0)  AS AmountToBeAmortisedPeriod								
	     ,(am.AmortisationAmount)-COALESCE(am2.AmortisationAmount,0)  AS AmountToBeAmortisedPeriodOrig								
	  	   							
									
FROM sources.vw_dwhr_Policies p									
		INNER JOIN sources.vw_dwhr_MasterReservingClassHierarchy mrc ON p.ClassAccumulatorKey = mrc.ClassAccumulatorKey AND mrc.MasterReservingClassName = 'Financial Risk Solutions - UK and Ireland'							
		LEFT JOIN sources.vw_dwhr_Amortisations am on p.PolicyKey = am.PolicyKey AND am._lastaction <> 'D'							
		LEFT JOIN sources.vw_dwhr_Amortisations am2 on am.AmortisationsSequence -1 = am2.AmortisationsSequence AND am.PolicyKey = am2.PolicyKey AND am2._lastaction <> 'D'							
			Left join 						
		(select  limits.PolicyReference, areaname, Clientname as Obligor, obligor.[D&BDUNSNumber],sum(coalesce(LibertyShare,/*LimitOriginalCurrency amended to 0 as declarations show full 100% amount 15.01.2018 DB*/ 0)) as LibertyShare, 1 as DeclarationCount, d.InceptionDateKey, d.ExpiryDateKey FROM sources.vw_dwhr_limits	limits						
 		INNER JOIN sources.vw_dwhr_Policies p on p.PolicyKey = limits.PolicyKey AND p._CurrentFlag = 1							
		INNER JOIN sources.vw_dwhr_Declarations D  on limits.DeclarationKey = d.DeclarationKey							
		INNER JOIN sources.vw_dwhr_Clients obligor on obligor.ClientKey = d.ObligorKey							
		INNER JOIN sources.vw_dwhr_Areas a on a.AreaKey = d.AreaKey							
		 where  limits._CurrentFlag = 1 							
		-- and limits.PolicyReference like '%582541/01/17%' and Clientname like '%Front r%'							
									
		 group by 							
		 limits.PolicyReference, areaname, Clientname, obligor.[D&BDUNSNumber], d.InceptionDateKey, d.ExpiryDateKey) as limits							
		 on p.UnderwriterReference = left(limits.PolicyReference,12)							
		INNER JOIN FX on FX.CurrencyKey = p.PrimaryCurrencyKey-- and p.PolicyYearOfAccount = FX.FXYear							
																		
WHERE p._CurrentFlag = 1 									
AND getdate() between case when DeclarationCount >= 0 THEN limits.InceptionDateKey else p.InceptionDateKey end 									
						AND case when DeclarationCount >= 0 then limits.ExpiryDateKey else p.ExpiryDateKey end   			
									
--and UnderwriterReference like  '%582483%'									
--  and (UnderwriterReference like  '%582510%' or UnderwriterReference like '%582541%') AND obligor like '%alabama%'									
									
)									
									
,Amort as(									
									
--Get from GFE									
									
									
 SELECT									
-- 'GFE' as Source,									
UnderwriterReference									
,InceptionDateKey									
,ExpiryDateKey									
,AreaName									
,Obligor									
,CapIQ									
,AmortisationStartDateKey									
,AmortisationAmountOrig									
,AmortisationAmount									
,AmortisationEndDateKey									
,NextAmortisationAmount									
,NextAmortisationAmountOrig									
,AmountToBeAmortisedPeriod									
,AmountToBeAmortisedPeriod/(DATEDIFF(Day,AmortisationStartDateKey,AmortisationEndDateKey)+1) as DailyAmortisation									
,DATEADD(DAY,N-1,AmortisationStartDateKey) as DateKey									
,Coalesce(									
NextAmortisationAmount+AmountToBeAmortisedPeriod/(DATEDIFF(Day,AmortisationStartDateKey,AmortisationEndDateKey)+1)*DATEDIFF(Day,DATEADD(DAY,N-2,AmortisationStartDateKey),AmortisationEndDateKey)									
,									
Case When DATEADD(DAY,N-1,AmortisationStartDateKey) < AmortisationEndDateKey Then AmortisationAmount Else 0 End									
)									
as TotalAmortisationValueAtDate									
									
,Coalesce(									
NextAmortisationAmountOrig+AmountToBeAmortisedPeriod/(DATEDIFF(Day,AmortisationStartDateKey,AmortisationEndDateKey)+1)*DATEDIFF(Day,DATEADD(DAY,N-2,AmortisationStartDateKey),AmortisationEndDateKey)									
,									
Case When DATEADD(DAY,N-1,AmortisationStartDateKey) < AmortisationEndDateKey Then AmortisationAmountOrig Else 0 End									
)									
as TotalAmortisationValueAtDateOrig									
									
									
									
									
FROM									
Base1									
INNER JOIN (SELECT TOP (10000) N = ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) FROM E16) a ON a.N <= DATEDIFF(day,AmortisationStartDateKey,AmortisationEndDateKey)+1									
									
where 									
DATEADD(DAY,N-1,AmortisationStartDateKey) BETWEEN CONVERT(DATE, GetDate()) AND DATEADD(Year,5,CONVERT(DATE, GetDate())) 									
									
--DATEADD(DAY,N-1,AmortisationStartDateKey) >= CONVERT(DATE, GetDate()) 									
--AND DATEADD(DAY,N-1,AmortisationStartDateKey) < DATEADD(Year,5,CONVERT(DATE, GetDate())) 									
									
--and UnderwriterReference like  '%582510/01/16%' AND Obligor = 'RATCHABURI ELECTRICITY'									
									
--=====================================									
UNION ALL									
--=====================================									
									
									
									
--Get from LIMIT									
SELECT									
--'LIMIT' as Source,									
Base2.UnderwriterReference									
,InceptionDateKey									
,ExpiryDateKey									
,AreaName									
,Obligor									
,CapIQ									
,AmortisationStartDateKey									
,AmortisedAmountOrig									
,AmortisationAmount									
,AmortisationEndDateKey									
,NextAmortisationAmount									
,NextAmortisationAmountOrig									
,AmountToBeAmortisedPeriod									
,AmountToBeAmortisedPeriod/(DATEDIFF(Day,AmortisationStartDateKey,AmortisationEndDateKey)+1) as DailyAmortisation									
,DATEADD(DAY,N-1,AmortisationStartDateKey) as DateKey									
,--Coalesce(									
--NextAmortisationAmount+AmountToBeAmortisedPeriod/(DATEDIFF(DAY,AmortisationStartDateKey,AmortisationEndDateKey)+1)*DATEDIFF(DAY,DATEADD(DAY,N-2,AmortisationStartDateKey),AmortisationEndDateKey)									
--,									
Case When DATEADD(DAY,N-1,AmortisationStartDateKey) < AmortisationEndDateKey Then AmortisationAmount Else 0 End									
--)									
as TotalAmortisationValueAtDate,									
--,									
Case When DATEADD(DAY,N-1,AmortisationStartDateKey) < AmortisationEndDateKey Then AmortisedAmountOrig Else 0 End									
--)									
									
as TotalAmortisationValueAtDateOrig									
									
									
FROM									
Base2									
INNER JOIN (SELECT TOP (10000) N = ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) FROM E16) a ON a.N <= DATEDIFF(day,AmortisationStartDateKey,AmortisationEndDateKey)+1									
LEFT JOIN (Select Distinct UnderwriterReference from Base1) Base1 ON Base2.UnderwriterReference = Base1.UnderwriterReference 									
									
									
where 									
DATEADD(DAY,N-1,AmortisationStartDateKey) BETWEEN CONVERT(DATE, GetDate()) AND DATEADD(Year,5,CONVERT(DATE, GetDate())) 									
--and Base1.UnderwriterReference IS NULL									
--DATEADD(DAY,N-1,AmortisationStartDateKey) >= CONVERT(DATE, GetDate()) 									
--AND DATEADD(DAY,N-1,AmortisationStartDateKey) < DATEADD(Year,5,CONVERT(DATE, GetDate())) 									
									
--and base2.UnderwriterReference like  '%582510/01/16%' AND base2.Obligor = 'RATCHABURI ELECTRICITY'									
)									
									
									
,									
Report AS 									
(									
            --GFE reporting 									
            SELECT	cs.ContractStatusGroupName								
                        ,p.UnderwriterReference as UWRef									
						,pd.SlipReference			
                        ,p.PolicyYearOfAccount as YoA									
                        ,cca.MasterReservingClassName as ReservingClass									
                        ,COALESCE(ass.ClientName, pd.ContractName) as Assured 									
						,re.ClientName as Reassured   			
                        ,p.InceptionDateKey as Inception									
                        ,p.ExpiryDateKey as Expiry									
                        ,cc.ClassCode 									
                        ,p.RiskCode 									
                        ,gf.AreaName AS Area									
                        ,gf.AreaCode									
                        ,CASE oblg.ClientName 									
                                                WHEN N'<<Unknown>>' THEN N''									
                                                ELSE oblg.ClientName 									
                                    END as Obligor 									
						,pd.ObligorRatingCode		 	
						,oblg.[D&BDUNSNumber] as CapIQ			
                        ,FX.CurrencyCode as OriginalExposureCurrency 									
                        ,SUM(gf.GlobalFinancialExposure * COALESCE(p.signedpercentage, p.EstimatedSignedPercentage) / 100 / FX.ExchangeRate) AS [Exposure $]									
                        --,SUM(ppi.InitialPolicyPremiumEstimatedNetOriginalCurrency/polfx.ExchangeRate) as 'EPI�'  									
                        ,brk.BrokerName 									
                        ,cs.ContractStatusName									
                        ,p.EstimatedSignedPercentage as [EstSigning %]									
                        ,p.SignedPercentage AS [Signed %]									
                        ,typ.PolicyTypeName AS [Policy Type]									
                        ,'P' as [P/D]  									
                        ,'' as DeclarationNumber  									
                        ,'' as PolicyExpiry									
                        ,pd.ContractName as [Contract Name]									
						,pd.SecurityName as [Security]			
						,pd.StructureName as [Structure]			
                        ,ass.DomicileName									
                        ,junk.SpecificReinsuranceName as [Specific RI]									
                        ,per.PerilName									
                        ,BRH.LibertyBrokerGroupName as [Broker Group]									
						,pd.AdjustablePremiumRate			
            FROM (									
                        SELECT									
                                    ROW_NUMBER() OVER(PARTITION BY LEFT(gfe.PolicyReference, 12), gfe.AreaKey, gfe.CurrencyKey ORDER BY gfe._SequenceNumber DESC) AS ID,									
                                    gfe.CurrencyKey,									
                                    gfea.AreaCode,									
                                    gfea.AreaName,									
                                    LEFT(gfe.PolicyReference, 12) AS UnderwriterReference,									
                                    gfe.GlobalFinancialExposure									
                        FROM									
                                    sources.vw_dwhr_GlobalFinancialExposures gfe									
                                    INNER JOIN sources.vw_dwhr_Areas gfea ON gfea.AreaKey = gfe.AreaKey  									
                        WHERE 									
                                    gfe._CurrentFlag = 1  									
            ) gf  									
									
                        INNER JOIN sources.vw_dwhr_Policies p ON p.UnderwriterReference = gf.UnderwriterReference									
                        INNER JOIN sources.vw_dwhr_Class cc on cc.ClassKey = p.ClassKey  									
                        INNER JOIN sources.vw_dwhr_MasterReservingClassHierarchy cca on cca.ClassAccumulatorKey = p.ClassAccumulatorKey  									
                        --INNER JOIN mi.PolicyPremiumIncome ppi on ppi.PolicyKey = p.PolicyKey    									
                        --LEFT JOIN FX polfx on polfx.CurrencyKey = ppi.OriginalCurrencyKey  									
                        INNER JOIN FX on FX.CurrencyKey = gf.CurrencyKey --and p.PolicyYearOfAccount = FX.FXYear									
                        INNER JOIN sources.vw_dwhr_Clients oblg on oblg.ClientKey = p.ObligorKey  									
                        LEFT OUTER JOIN sources.vw_dwhr_PolicyAssureds pass on pass.PolicyReference = p.PolicyReference and pass._CurrentFlag = 1 and PrimaryAssuredFlag = N'Primary Assured'									
                        LEFT OUTER JOIN sources.vw_dwhr_Clients ass on pass.AssuredKey = ass.ClientKey									
						LEFT OUTER JOIN sources.vw_dwhr_PolicyReassureds pre on pre.PolicyReference = p.PolicyReference and pre._CurrentFlag = 1 and pre.PrimaryReassuredFlag = N'Primary Reassured'			
						LEFT OUTER JOIN sources.vw_dwhr_Clients re on pre.ReassuredKey = re.ClientKey			
                        INNER JOIN sources.vw_dwhr_Brokers Brk on brk.BrokerKey = p.BrokerKey									
                        INNER JOIN sources.vw_dwhr_PolicyTypes typ on typ.PolicyTypeKey = p.PolicyTypeKey  									
                        INNER JOIN sources.vw_dwhr_ContractStatus cs on cs.ContractStatusKey = p.PolicyStatusCurrentKey									
                        INNER JOIN sources.vw_dwhr_PolicyDetails pd on pd.PolicyDetailKey = p.PolicyDetailKey									
                        INNER JOIN sources.vw_dwhr_PolicyJunkDetails junk on junk.PolicyJunkDetailKey = p.PolicyJunkDetailKey									
                        INNER JOIN sources.vw_dwhr_Perils per on per.PerilKey = p.PerilKey									
                        INNER JOIN sources.vw_dwhr_MaterBrokerHierarchies brh on brh.BrokerCodeUnconformed = brk.BrokerCodeUnconformed									
						-- put IN to remove masterpolicies			
						LEFT JOIN sources.vw_dwhr_Declarations d on p.PolicyReference = d.PolicyReference 			
									
									
            WHERE    									
                        gf.ID = 1									
                        AND cca.MasterReservingClassName = N'Financial Risk Solutions - UK and Ireland'  									
                       --AND cs.ContractStatusGroupName IN (N'Active')									
					    AND cs.ContractStatusGroupName IN (N'Active', N'For Information')				
                        AND p.ExpiryDateKey >= CURRENT_TIMESTAMP									
                        AND p._CurrentFlag = 1									
						AND d.PolicyReference IS NULL			
									
            GROUP BY   									
						cs.ContractStatusGroupName			
                        ,p.UnderwriterReference 									
						,pd.SlipReference			
                        ,p.PolicyYearOfAccount									
                        ,ass.ClientName  									
                        ,cca.MasterReservingClassName  									
						,re.ClientName			
						,pd.ObligorRatingCode			
                        ,p.InceptionDateKey  									
                        ,p.ExpiryDateKey  									
                        ,cc.ClassCode  									
                        ,p.RiskCode  									
                        ,gf.AreaName									
                        ,gf.AreaCode									
                        ,oblg.ClientName 									
						,oblg.[D&BDUNSNumber] 			
                        ,FX.CurrencyCode 									
                        ,brk.BrokerName  									
                        ,cs.ContractStatusName 									
                        ,p.EstimatedSignedPercentage									
                        ,p.SignedPercentage									
                        ,typ.PolicyTypeName 									
                        ,pd.ContractName									
						,pd.SecurityName			
						,pd.StructureName			
                        ,ass.DomicileName									
                        ,junk.SpecificReinsuranceName									
                        ,per.PerilName									
                        ,BRH.LibertyBrokerGroupName									
						,pd.AdjustablePremiumRate			
									
            UNION ALL									
									
            --DECLARATIONS									
            SELECT   									
						cs.ContractStatusGroupName			
                        ,p.UnderwriterReference									
						,pd.SlipReference	  		
                        ,p.PolicyYearOfAccount  									
                        ,cca.MasterReservingClassName  									
                        ,COALESCE(c.ClientName, pd.ContractName)  as Assured  									
						,re.ClientName as ReAssured			
                        ,d.InceptionDateKey  									
                        ,d.ExpiryDateKey  									
                        ,class.ClassCode  									
                        ,p.RiskCode  									
                        ,a.AreaName as Area 									
                        ,a.AreaCode									
                        ,CASE obligor.ClientName									
                                                WHEN N'<<Unknown>>' THEN ''									
                                                ELSE obligor.ClientName 									
                        END AS Obligor  									
						,pd.ObligorRatingCode			
						,obligor.[D&BDUNSNumber] as CapIQ			
                        ,FX.CurrencyCode as OriginalExposureCurrency  									
                        -- ,SUM(((d.LibertyShare/100) * IsNull(p.signedpercentage, p.EstimatedSignedPercentage))/fxrate.ExchangeRate) as 'Exposure $'  									
                        ,SUM(d.LibertyShare / FX.ExchangeRate) as [Exposure $]									
                        --,SUM(ppi.InitialPolicyPremiumEstimatedNetOriginalCurrency/fxprem.ExchangeRate) as 'EPI�'  									
                        ,Brokers.BrokerName  									
                        ,cs.ContractStatusName 									
                        ,p.EstimatedSignedPercentage									
                        ,p.SignedPercentage									
                        ,typ.PolicyTypeName as 'Policy type'									
                        ,'D' as [P/D]  									
                        ,d.DeclarationNumber  									
                        ,P.ExpiryDateKey as PolicyExpiry									
                        ,pd.ContractName as [Contract Name]									
						,pd.SecurityName as [Security]			
						,pd.StructureName as [Structure]			
                        ,c.DomicileName as Domicile									
                        ,junk.SpecificReinsuranceName as [Specific RI]									
                        ,per.PerilName									
                        ,BRH.LibertyBrokerGroupName									
						,pd.AdjustablePremiumRate			
            FROM 									
                        sources.vw_dwhr_Declarations D   									
                        INNER JOIN sources.vw_dwhr_Policies p on p.PolicyReference = d.PolicyReference 									
                        INNER JOIN sources.vw_dwhr_Clients c on c.ClientKey = d.AssuredKey									
						INNER JOIN sources.vw_dwhr_Clients re on re.ClientKey = d.ReassuredKey			
                        INNER JOIN sources.vw_dwhr_Clients obligor on obligor.ClientKey = d.ObligorKey									
                        INNER JOIN sources.vw_dwhr_Class class on p.ClassKey = class.ClassKey									
                        INNER JOIN sources.vw_dwhr_Brokers brokers on p.BrokerKey = brokers.BrokerKey									
                        INNER JOIN FX on FX.CurrencyKey = d.CurrencyKey --and p.PolicyYearOfAccount = FX.FXYear									
                        INNER JOIN sources.vw_dwhr_MasterReservingClassHierarchy cca on cca.ClassAccumulatorKey = p.ClassAccumulatorKey									
                        INNER JOIN sources.vw_dwhr_PolicyTypes typ on typ.PolicyTypeKey = p.PolicyTypeKey									
                        INNER JOIN sources.vw_dwhr_Areas a on a.AreaKey = d.AreaKey									
                        INNER JOIN sources.vw_dwhr_ContractStatus cs on cs.ContractStatusKey = p.PolicyStatusCurrentKey									
                        INNER JOIN sources.vw_dwhr_Policydetails pd on pd.PolicyDetailKey = p.PolicyDetailKey									
                        INNER JOIN sources.vw_dwhr_PolicyJunkDetails junk on junk.PolicyJunkDetailKey = p.PolicyJunkDetailKey									
                        INNER JOIN sources.vw_dwhr_Perils per on per.PerilKey = p.PerilKey									
                        INNER JOIN sources.vw_dwhr_MaterBrokerHierarchies brh on brh.BrokerCodeUnconformed = brokers.BrokerCodeUnconformed									
            WHERE    									
                        cca.MasterReservingClassName = N'Financial Risk Solutions - UK and Ireland'  									
                        AND p._CurrentFlag = 1									
						-- AND cs.ContractStatusGroupName IN (N'Active')			
                        AND cs.ContractStatusGroupName IN (N'Active', N'For Information')									
                        AND (d.ExpiryDateKey >= CURRENT_TIMESTAMP OR d.ExpiryDateKey = '19000101')									
						AND d._lastaction <> 'D'			
            GROUP BY    									
                        cs.ContractStatusGroupName									
						,p.UnderwriterReference 			
						,pd.SlipReference	 		
                        ,p.PolicyYearOfAccount  									
                        ,cca.MasterReservingClassName  									
                        ,COALESCE(c.ClientName, pd.ContractName)									
						,re.ClientName			
                        ,d.InceptionDateKey  									
                        ,d.ExpiryDateKey  									
                        ,class.ClassCode  									
                        ,p.RiskCode  									
                        ,a.AreaName  									
                        ,a.areacode									
                        ,obligor.ClientName									
						,pd.ObligorRatingCode			
						,obligor.[D&BDUNSNumber]			
                        ,FX.CurrencyCode									
                        ,Brokers.BrokerName  									
                        ,cs.ContractStatusName 									
                        ,p.EstimatedSignedPercentage									
                        ,p.SignedPercentage									
                        ,typ.PolicyTypeName									
                        ,d.DeclarationNumber  									
                        ,P.ExpiryDateKey 									
                        ,pd.ContractName									
						,pd.SecurityName			
						,pd.StructureName			
                        ,c.DomicileName									
                        ,junk.SpecificReinsuranceName									
                        ,PerilName									
                        ,BRH.LibertyBrokerGroupName									
						,pd.AdjustablePremiumRate			
)									
									
									
									
SELECT 									
CASE WHEN  ContractStatusGroupName IN (N'Active') THEN 1 ELSE 2 END	AS CobId					
			
,r.UWRef as RiskID									
,'LIB' AS Cedant
,NULL AS Data_Quarter								
,r.YoA as [Year]									
,ltrim(rtrim(replace(r.Assured, char(9), ' '))) as Assured									
,r.Riskcode as Risk_Code									
,'' as Lead_Syndicate																
,r.Area as Country 									
,r.Inception as Inception_Date									
,r.Expiry as Expiry_Date									
,OriginalExposureCurrency as Ccy									
,NULL as PolicyLimit									
,NULL AS USD_Limit
,NULL AS USD_NET_EPI								
,ISNULL(AMORT.AmortisationAmountOrig,0) as USD_Exposure									
,r.Obligor									
					
													
         									
FROM 									
            Report r 									
			INNER JOIN AMORT ON AMORT.UnderwriterReference = r.UWRef AND AMORT.Areaname = r.area AND AMORT.Obligor = r.Obligor AND AMORT.ExpiryDateKey = r.expiry AND AMORT.DateKey = cast(getdate() as Date)						
            									
			LEFT JOIN (  						
                        SELECT  									
                                    p.UnderwriterReference as UWRef,									
									ccyFromISO.ISOCurrencyCode as PriCcy,
                                    SUM(i.InitialPolicyPremiumSEPINetOriginalCurrency) as [EPI in Original currency]									
                        FROM 									
                                    sources.vw_dwhr_Policies P									
                                    INNER JOIN sources.vw_dwhr_PolicyPremiumIncomeHistory I on p.PolicyKey = I.PolicyKey									
                                    INNER JOIN sources.vw_dwhr_MasterReservingClassHierarchy R on p.ClassAccumulatorKey = r.ClassAccumulatorKey									
                                    INNER JOIN sources.vw_dwhr_Currencies ccyFrom ON ccyfrom.CurrencyKey = i.OriginalCurrencyKey									
                                    INNER JOIN sources.vw_dwhr_ISOCurrencies ccyFromISO ON ccyFrom.ISOCurrencyKey = ccyFromISO.ISOCurrencyKey   									
                                    INNER JOIN sources.vw_dwhr_ExchangeRates roe ON ccyFromISO.ISOCurrencyKey = roe.ISOCurrencyFromKey   									
                                    INNER JOIN sources.vw_dwhr_ISOCurrencies ccyToISO ON roe.ISOCurrencyToKey = ccyToISO.ISOCurrencyKey   									
                                    INNER JOIN sources.vw_dwhr_ContractStatus cs on cs.ContractStatusKey = p.PolicyStatusCurrentKey									
									
                        WHERE 									
                                    r.MasterReservingClassName = N'Financial Risk Solutions - UK and Ireland'  									
                                    --and p._CurrentFlag = 1									
									-- and cs.ContractStatusGroupName IN (N'Active')
                                    and cs.ContractStatusGroupName IN (N'Active', N'For Information')									
                                    and roe.ExchangeRateTypeCode = N'[Reserving]'									
                                    and YEAR(roe.ExchangeRateDateKey) = YEAR(CURRENT_TIMESTAMP) - 1    									
                                    and ccyToISO.ISOCurrencyCode = N'GBP' 									
                        GROUP BY 									
                                    p.UnderwriterReference, ccyFromISO.ISOCurrencyCode									
            ) AS X 									
                        ON x.UWRef = r.UWRef									
--where r.Expiry > ?