USE [Actuarial_Analytics]
GO


DROP TABLE IF EXISTS #CSMOutputR_Reclassed;
DROP TABLE IF EXISTS #CSMOutputR_RC_byTreaty;
DROP TABLE IF EXISTS #CSMOutputR_RC_byObligor;
DROP TABLE IF EXISTS #lbecsm;
DROP TABLE IF EXISTS #lbetemp;

DECLARE @InforceDate AS DATETIME2
SET @InforceDate = '2021-01-01 00:00:00.000' (SELECT DISTINCT lastruntime FROM FinancialRisks.AddNewData);

SELECT
	a.InforceDate,
	a.CobID AS ClassOfBusiness,
	a.ReportingClass AS ReportingClass,
	a.CedantName,
	a.ObligorEntityId, 
	a.EntityName, 
	a.GCHPRating,
	a.LibertyRating, 
	a.SPRating, 
	a.TreatyType, 
	a.TreatyID, 
	a.TreatyReference,
	RiskReference, 
	a.ExposureID,
	a.TreatyLimit,
	a.Rate,
	a.Excess, 
	a.SignedLine, 
	a.OurShare, 
	a.GrossExposure, 
	a.LibertyExposure
	,a.NumReinstatements, 
	a.ReinstatementAmount INTO #lbeCSM
FROM FinancialRisks.vw_ExposureOverview a
			WHERE InforceDate = @InforceDate 
			AND RiskCode in  ('CF','CR', 'SB', 'SU', 'FG','PB','PQ') 

			--ADD Additional CLAUSES HERE
ORDER BY a.ObligorEntityId , a.ClassOfBusiness ,a.InforceDate


SELECT  
		ClassOfBusiness,
		SimNo,
		SimPeriod,
		SimLGD,
		ReportingClass,
		TreatyID,
		TreatyType,
		TreatyReference,
		RiskReference,
		ExposureID,
		Limit,
		Excess,
		[NumReinstatements],
		SignedLine,
		OurShare,
		ExpGR,
		LossGR,
		ExpNT,
        --XOL = APPLY XOL TERMS
        CASE WHEN TreatyType = 'XL' THEN
                CASE WHEN LossGR > Excess THEN
                    CASE WHEN LossGR > (Limit + Excess) THEN Limit ELSE LossGR - Excess END
                ELSE 0 END
        --QS = LossGR UNLESS LIMIT IS PRESENT THEN APPLY LIMIT + QS TERMS
        WHEN TreatyType  in ('QS', 'BA') THEN
                CASE WHEN LossGR > Limit AND Limit > 0 THEN Limit ELSE LossGR END
                WHEN TreatyID IS NULL THEN ExpGR
        END 
        --APPLY LINE AND OURSHARE
        * SignedLine * OurShare AS LossNT
		,CedantName
		,GCHPRating
		,LibertyRating
		,SPRating
		,EntityName

	INTO #CSMOutputR_Reclassed
       FROM (
			SELECT 
			lbe.ClassOfBusiness,
			lbe.ReportingClass, 
			lbe.CedantName,
			lbe.EntityName,
			lbe.GCHPRating,
			lbe.LibertyRating,
			lbe.SPRating
			,cast(CSMO.DefaultSimNo AS int) AS SimNo
			,CSMO.DefaultYear AS SimPeriod
			,lbe.TreatyType
			,lbe.TreatyID
			,lbe.TreatyReference
			,lbe.RiskReference
			,lbe.ExposureID
			,cast(CSMO.SimLGD AS float) AS SimLGD
			,ISNULL(lbe.TreatyLimit / (CASE WHEN lbe.Rate = 'NR' THEN 0 ELSE cast(lbe.Rate AS float) END),0) AS Limit
			,ISNULL(lbe.Excess / (CASE WHEN lbe.Rate = 'NR' THEN 0 ELSE cast(lbe.Rate AS float) END),0) AS Excess
			,lbe.[NumReinstatements]
			,isnull(lbe.SignedLine,1) AS SignedLine
			,isnull(lbe.OurShare,1)AS OurShare
			,sum(isnull(lbe.GrossExposure,0)) AS ExpGR
			,sum(lbe.LibertyExposure) AS ExpNT
			,sum(isnull(lbe.GrossExposure,0) * cast(CSMO.SimLGD AS float)) AS LossGR
			FROM #lbeCSM lbe
			INNER JOIN  FinancialRisks.CSM_Model_OutputV2 CSMO
			ON csmo.InforceDate = @InforceDate 
			AND CSMo.Entity = lbe.ObligorEntityId 
			AND CSMo.ClassID = lbe.ClassOfBusiness 
			AND  CSMO.inforcedate = lbe.InforceDate -- and DefaultSimNo = @SimNo
			where  lbe.InforceDate = @InforceDate
			GROUP BY
			lbe.ClassOfBusiness,
			lbe.ReportingClass,
			lbe.EntityName,
			lbe.CedantName,
			lbe.GCHPRating,
			lbe.LibertyRating,
			lbe.SPRating
			,cast(CSMO.DefaultSimNo AS int)
			,CSMO.DefaultYear
			,lbe.TreatyType
			,lbe.TreatyID
			,lbe.TreatyReference
			,lbe.RiskReference
			,lbe.ExposureID
			,cast(CSMO.SimLGD AS float)
			,ISNULL(lbe.TreatyLimit / (CASE WHEN lbe.Rate = 'NR' THEN 0 ELSE cast(lbe.Rate AS float) END),0)
			,ISNULL(lbe.Excess / (CASE WHEN lbe.Rate = 'NR' THEN 0 ELSE cast(lbe.Rate AS float) END),0) 
			,lbe.[NumReinstatements]
			,isnull(lbe.SignedLine,1) 
			,isnull(lbe.OurShare,1)
              )x          


SELECT 
	SimNo, 
	ClassOfBusiness,
	TreatyID, TreatyReference, TreatyType, 
	treatylimit,
	excess AS excess,
	NumReinstatements,
	MaxLimit,
	Loss_NT_Current,
	CASE 
	WHEN Loss_NT_Current > treatylimit * (1+NumReinstatements) THEN MaxLimit
	ELSE Loss_NT_Current
	END AS Loss_NT_Corrected

INTO #CSMOutputR_RC_byTreaty

FROM (
		SELECT 
			SimNo, 
			ClassOfBusiness,
			TreatyID, TreatyReference, TreatyType, 
			NumReinstatements,
			Limit AS treatylimit,
			excess AS excess,
			limit * (1+isnull(NumReinstatements,0)) AS MaxLimit,
			sum(isnull(LossNT,0)) AS Loss_NT_Current
		FROM #CSMOutputR_Reclassed
		GROUP BY 
			SimNo, 
			ClassOfBusiness,
			NumReinstatements,
			TreatyID, TreatyReference, TreatyType, 
			Limit,
			excess,
			limit * (1+isnull(NumReinstatements,0))
		) y
ORDER BY 
	SimNo, 
	ClassOfBusiness,
	TreatyID, TreatyReference, TreatyType;
--Select * from #CSMOutputR_RC_byTreaty
--select * from #CSMOutputR_Reclassed

/*  By Treaty - diff in current net loss vs max limit with reinstatements
				where current net loss > max limit => over exposed */

SELECT 
	SimNo, 
	ClassOfBusiness,
	TreatyID, TreatyReference, TreatyType, 
	treatylimit,
	excess,
	NumReinstatements,
	MaxLimit,
	Loss_NT_Current,
	Loss_NT_Corrected
FROM #CSMOutputR_RC_byTreaty
where Loss_NT_Current > (CASE WHEN Loss_NT_Current > MaxLimit THEN MaxLimit ELSE Loss_NT_Current END)
ORDER BY 
	SimNo, 
	ClassOfBusiness,
	TreatyID, 
	TreatyReference, 
	TreatyType;



SELECT sr.ClassOfBusiness,SimNo, sum(Loss_NT_corrected) Loss, SUM(Loss_NT_Current) lossuncorrected,@InforceDate AS 'InforceDate'
FROM #CSMOutputR_RC_byTreaty sr
GROUP BY sr.ClassOfBusiness,SimNo



--SELECT 
--	SimNo, 
--	ClassOfBusiness,
--	Obligor,
--	outwardlimit,
--	outwardExcess,
--	Loss_NT_Current,
--	CASE WHEN Loss_NT_Current - outwardExcess > 0 THEN Loss_NT_Current - outwardExcess  ELSE 0 END AS OutwardNetOfExcess,
--	CASE WHEN Loss_NT_Current - outwardExcess > 0 THEN
--		CASE WHEN Loss_NT_Current - outwardExcess > outwardlimit THEN outwardlimit
--			ELSE Loss_NT_Current - outwardExcess
--			END 
--		ELSE 0
--		END AS Outward60x40,
--	Loss_NT_Current - CASE WHEN Loss_NT_Current - outwardExcess > 0 THEN Loss_NT_Current - outwardExcess  ELSE 0 END AS OutwardOver60

--INTO #CSMOutputR_RC_byObligor

--FROM (
--		SELECT 
--			SimNo, 
--			ClassOfBusiness,
--			EntityName AS Obligor,
--			60000000 AS outwardlimit,
--			40000000 AS outwardExcess,
--			sum(isnull(LossNT,0)) AS Loss_NT_Current
--		FROM #CSMOutputR_Reclassed
--		group by 
--			SimNo, 
--			ClassOfBusiness,
--			EntityName
--		) y
--ORDER BY 
--	SimNo, 
--	ClassOfBusiness,
--	Obligor;


--SELECT * FROM
--(
--SELECT sr.ClassOfBusiness AS ClassOfBusinessID,SimNo, SUM(Loss_NT_corrected) Loss ,@InforceDate AS 'InforceDate'
--FROM #CSMOutputR_RC_byTreaty sr
--GROUP BY sr.ClassOfBusiness,SimNo
--) x
--UNION ALL
--SELECT cob.ClassOfBusinessID,cob.SimNo,cob.Loss,cob.InforceDate 
--FROM FinancialRisks.CurveByCOB cob WHERE InforceDate = @InforceDate
--AND cob.ClassOfBusinessID NOT IN (3,4,5)

/*  By Obligor - calculate 60x40 Outward  */
--SELECT 
--	SimNo, 
--	ClassOfBusiness,
--	Obligor,
--	outwardlimit,
--	outwardExcess,
--	Loss_NT_Current,
--	OutwardNetOfExcess,
--	Outward60x40,
--	OutwardOver60,
--	@InforceDate
--FROM #CSMOutputR_RC_byObligor
--where OutwardNetOfExcess > 0
--ORDER BY 
--	SimNo, 
--	ClassOfBusiness,
--	Obligor
--;
