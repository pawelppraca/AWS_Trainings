USE [msdb]
GO
/****** Object:  Job [FinancialRisks_UpdateMappings]    Script Date: 30/08/2019 10:12:14 ******/
IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = N'FinancialRisks_UpdateMappings')

BEGIN
	EXEC msdb.dbo.sp_delete_job @job_name=N'FinancialRisks_UpdateMappings', @delete_unused_schedule=1
END

/****** Object:  Job [FinancialRisks_UpdateMappings]    Script Date: 30/08/2019 10:12:14 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
DECLARE @Server VARCHAR(15) = @@SERVERNAME

DECLARE @SsisOwner VARCHAR(30)
SELECT @SsisOwner = CASE @@SERVERNAME
			        WHEN 'VMBID-GSQLDB01' THEN 'LM\sagsdAAP-SSIS'
					WHEN 'VMBIT-GSQLDB01' THEN 'LM\sagstAAP-SSIS'
					WHEN 'VMBIS-GSQLDB01' THEN 'LM\sagssAAP-SSIS'
			        WHEN 'VMBIP-GSQLDB01' THEN 'LM\sagspAAP-SSIS'
					END
DECLARE @PackageExecutionProxy VARCHAR(20) 
SELECT @PackageExecutionProxy = CASE @@SERVERNAME
					WHEN 'VMBID-GSQLDB01' THEN 'Pr-AAP-DEV-System'
					WHEN 'VMBIT-GSQLDB01' THEN 'Pr-AAP-SIT-System'
					WHEN 'VMBIS-GSQLDB01' THEN 'Pr-AAP-UAT-System'
			        WHEN 'VMBIP-GSQLDB01' THEN 'Pr-AAP-PRD-System'
					END
SELECT @Server = @@SERVERNAME

/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 30/08/2019 10:12:14 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'FinancialRisks_UpdateMappings', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Runs UpdateMappings SSIS package to pick up all updated exposure records from file share, update relevant mappings and write records to exposures table', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name= @SsisOwner, 
		@notify_email_operator_name=N'SQLDBA', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ExecuteUpdateMappingsPackage]    Script Date: 30/08/2019 10:12:14 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ExecuteUpdateMappingsPackage', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/ISSERVER "\"\SSISDB\FinancialRisks\FinancialRisks\FileName.dtsx\"" /SERVER "\"VMBIT-GSQLDB01\"" /ENVREFERENCE 16 /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name= @PackageExecutionProxy
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'UpdateMappingsScedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=62, 
		@freq_subday_type=8, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20190827, 
		@active_end_date=99991231, 
		@active_start_time=94500, 
		@active_end_time=174500
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO
/*
Set Environmental Variables START
========================================================================================================================================================================
*/
DECLARE @ArchiveLocation NVARCHAR(128)
DECLARE @BDXEmail NVARCHAR(128)
DECLARE @BDXError NVARCHAR(128)
Declare @Environment NVARCHAR(3)
Declare @ClientMap  NVARCHAR(128)
Declare @CompanySpreadsheet  NVARCHAR(128)
Declare @DataAnalyticsDBName  NVARCHAR(128)
Declare @DataAnalyticsDBServer  NVARCHAR(128)
Declare @EmailFrom  NVARCHAR(128)
Declare @EmailTo  NVARCHAR(128)
Declare @EmailToMapping  NVARCHAR(128)
Declare @Ironshore  NVARCHAR(128)
Declare @PecLinesBorderauxFilesLocation  NVARCHAR(128)
Declare @PecLinesProgramLiveFileLocation  NVARCHAR(128)
Declare @PTCAccessDBFileLocation  NVARCHAR(128)
Declare @SMTPServer  NVARCHAR(128)
Declare @UnmappedCedantsInput  NVARCHAR(128)
Declare @UnmappedCountriesInput  NVARCHAR(128)
Declare @UnmappedObligorsInput  NVARCHAR(128)
Declare @UnmappedOutput  NVARCHAR(128)




IF @@SERVERNAME = 'VMBID-GSQLDB01'
	BEGIN
	SET @Environment = 'DEV'
	SET @ArchiveLocation = '\\VMBID-GSQLDB01\FinancialRisk-Upload\Archive\'
	SET @BDXEmail = 'aidan.mckiernan@liberty-it.co.uk'
	SET @BDXError = '\\VMBID-GSQLDB01\FinancialRisk-Upload\PecLines'
	SET @ClientMap = '\\VMBID-GSQLDB01\FinancialRisk-Upload\PecLines\InitialLoad\Client_Map_template.xlsx'	
	SET @CompanySpreadsheet = '\\VMBID-GSQLDB01\FinancialRisk-Upload\PecLines\InitialLoad\Company_Paper_template.xlsx'
	SET @DataAnalyticsDBName = 'Actuarial_Analytics'
	SET @DataAnalyticsDBServer = 'VMBID-GSQLDB01'
	SET @EmailFrom = 'LSMDataAnalyticsDev@LibertyMutual.com'
	SET @EmailTo = 'aidan.mckiernan@liberty-it.co.uk'
	SET @EmailToMapping = 'aidan.mckiernan@liberty-it.co.uk'
	SET @Ironshore = '\\VMBID-GSQLDB01\FinancialRisk-Upload\Ironshore\Ironshore.xlsx'
	SET @PecLinesBorderauxFilesLocation = '\\VMBID-GSQLDB01\FinancialRisk-Upload\PecLines\Borderaux Files'
	SET @PecLinesProgramLiveFileLocation = '\\VMBID-GSQLDB01\FinancialRisk-Upload\PecLines\Programme_Live.xlsx'
	SET @PTCAccessDBFileLocation = '\\VMBID-GSQLDB01\FinancialRisk-Upload\PTC\PTC.mdb'
	SET @SMTPServer = 'smtprelay.lmig.com'
	SET @UnmappedCedantsInput = '\\VMBID-GSQLDB01\FinancialRisk-Upload\Mappings\Input\Cedants\UnmappedCedants.xlsx'
	SET @UnmappedCountriesInput = '\\VMBID-GSQLDB01\FinancialRisk-Upload\Mappings\Input\Countries\UnmappedCountries.xlsx'
	SET @UnmappedObligorsInput = '\\VMBID-GSQLDB01\FinancialRisk-Upload\Mappings\Input\Obligors\UnmappedObligors.xlsx'
	SET @UnmappedOutput = '\\VMBID-GSQLDB01\FinancialRisk-Upload\Mappings\Output\'
		Print 'Dev Variables Set'
	END


Else IF @@SERVERNAME = 'VMBIT-GSQLDB01'
	
	BEGIN
	SET @Environment = 'SIT'
	SET @ArchiveLocation = '\\VMBIT-GSQLDB01\FinancialRisk-Upload\Archive\'
	SET @BDXEmail = 'aidan.mckiernan@liberty-it.co.uk'
	SET @BDXError = '\\VMBIT-GSQLDB01\FinancialRisk-Upload\PecLines'
	SET @ClientMap = '\\VMBIT-GSQLDB01\FinancialRisk-Upload\PecLines\InitialLoad\Client_Map_template.xlsx'	
	SET @CompanySpreadsheet = '\\VMBIT-GSQLDB01\FinancialRisk-Upload\PecLines\InitialLoad\Company_Paper_template.xlsx'
	SET @DataAnalyticsDBName = 'Actuarial_Analytics'
	SET @DataAnalyticsDBServer = 'VMBIT-GSQLDB01'
	SET @EmailFrom = 'LSMDataAnalyticsSIT@LibertyMutual.com'
	SET @EmailTo = 'aidan.mckiernan@liberty-it.co.uk'
	SET @EmailToMapping = 'aidan.mckiernan@liberty-it.co.uk'
	SET @Ironshore = '\\VMBIT-GSQLDB01\FinancialRisk-Upload\Ironshore\Ironshore.xlsx'
	SET @PecLinesBorderauxFilesLocation = '\\VMBIT-GSQLDB01\FinancialRisk-Upload\PecLines\Borderaux Files'
	SET @PecLinesProgramLiveFileLocation = '\\VMBIT-GSQLDB01\FinancialRisk-Upload\PecLines\Programme_Live.xlsx'
	SET @PTCAccessDBFileLocation = '\\VMBIT-GSQLDB01\FinancialRisk-Upload\PTC\PTC.mdb'
	SET @SMTPServer = 'smtprelay.lmig.com'
	SET @UnmappedCedantsInput = '\\VMBIT-GSQLDB01\FinancialRisk-Upload\Mappings\Input\Cedants\UnmappedCedants.xlsx'
	SET @UnmappedCountriesInput = '\\VMBIT-GSQLDB01\FinancialRisk-Upload\Mappings\Input\Countries\UnmappedCountries.xlsx'
	SET @UnmappedObligorsInput = '\\VMBIT-GSQLDB01\FinancialRisk-Upload\Mappings\Input\Obligors\UnmappedObligors.xlsx'
	SET @UnmappedOutput = '\\VMBIT-GSQLDB01\FinancialRisk-Upload\Mappings\Output\'
	Print 'SIT Variables Set'
	END

Else IF @@SERVERNAME = 'VMBIS-GSQLDB01'
	BEGIN
	SET @Environment = 'UAT'
	SET @ArchiveLocation = '\\VMBIS-GSQLDB01\FinancialRisk-Upload\Archive\'
	SET @BDXEmail = 'aidan.mckiernan@liberty-it.co.uk'
	SET @BDXError = '\\VMBIS-GSQLDB01\FinancialRisk-Upload\PecLines'
	SET @ClientMap = '\\VMBIS-GSQLDB01\FinancialRisk-Upload\PecLines\InitialLoad\Client_Map_template.xlsx'	
	SET @CompanySpreadsheet = '\\VMBIS-GSQLDB01\FinancialRisk-Upload\PecLines\InitialLoad\Company_Paper_template.xlsx'
	SET @DataAnalyticsDBName = 'Actuarial_Analytics'
	SET @DataAnalyticsDBServer = 'VMBIS-GSQLDB01'
	SET @EmailFrom = 'LSMDataAnalyticsUAT@LibertyMutual.com'
	SET @EmailTo = 'aidan.mckiernan@liberty-it.co.uk'
	SET @EmailToMapping = 'aidan.mckiernan@liberty-it.co.uk'
	SET @Ironshore = '\\VMBIS-GSQLDB01\FinancialRisk-Upload\Ironshore\Ironshore.xlsx'
	SET @PecLinesBorderauxFilesLocation = '\\VMBIS-GSQLDB01\FinancialRisk-Upload\PecLines\Borderaux Files'
	SET @PecLinesProgramLiveFileLocation = '\\VMBIS-GSQLDB01\FinancialRisk-Upload\PecLines\Programme_Live.xlsx'
	SET @PTCAccessDBFileLocation = '\\VMBIS-GSQLDB01\FinancialRisk-Upload\PTC\PTC.mdb'
	SET @SMTPServer = 'smtprelay.lmig.com'
	SET @UnmappedCedantsInput = '\\VMBIS-GSQLDB01\FinancialRisk-Upload\Mappings\Input\Cedants\UnmappedCedants.xlsx'
	SET @UnmappedCountriesInput = '\\VMBIS-GSQLDB01\FinancialRisk-Upload\Mappings\Input\Countries\UnmappedCountries.xlsx'
	SET @UnmappedObligorsInput = '\\VMBIS-GSQLDB01\FinancialRisk-Upload\Mappings\Input\Obligors\UnmappedObligors.xlsx'
	SET @UnmappedOutput = '\\VMBIS-GSQLDB01\FinancialRisk-Upload\Mappings\Output\'
	Print 'UAT Variables Set'
	END

Else IF @@SERVERNAME = 'VMBIP-GSQLDB01'
	BEGIN
	SET @Environment = 'PRD'
	SET @ArchiveLocation = '\\VMBIP-GSQLDB01\FinancialRisk-Upload\Archive\'
	SET @BDXEmail = 'Tom.Ashworth@LibertyGlobalGroup.com;Gurpreet.Phull@LibertyGlobalGroup.com'
	SET @BDXError = '\\VMBIP-GSQLDB01\FinancialRisk-Upload\PecLines'
	SET @ClientMap = '\\VMBIP-GSQLDB01\FinancialRisk-Upload\PecLines\InitialLoad\Client_Map_template.xlsx'
	SET @CompanySpreadsheet = '\\VMBIP-GSQLDB01\FinancialRisk-Upload\PecLines\InitialLoad\Company_Paper_template.xlsx'
	SET @DataAnalyticsDBName = 'Actuarial_Analytics'
	SET @DataAnalyticsDBServer = 'VMBIP-GSQLDB01'
	SET @EmailFrom = 'LSMDataAnalyticsPRD@LibertyMutual.com'
	SET @EmailTo = 'LITGSLSMDataAnalytics@LibertyMutual.com'
	SET @EmailToMapping = 'Tom.Ashworth@LibertyGlobalGroup.com'
	SET @Ironshore = '\\VMBIP-GSQLDB01\FinancialRisk-Upload\Ironshore\Ironshore.xlsx'
	SET @PecLinesBorderauxFilesLocation = '\\VMBIP-GSQLDB01\FinancialRisk-Upload\PecLines\Borderaux Files'
	SET @PecLinesProgramLiveFileLocation = '\\VMBIP-GSQLDB01\FinancialRisk-Upload\PecLines\Programme_Live.xlsx'
	SET @PTCAccessDBFileLocation = '\\VMBIP-GSQLDB01\FinancialRisk-Upload\PTC\PTC.mdb'
	SET @SMTPServer = 'smtprelay.lmig.com'
	SET @UnmappedCedantsInput = '\\VMBIP-GSQLDB01\FinancialRisk-Upload\Mappings\Input\Cedants\UnmappedCedants.xlsx'
	SET @UnmappedCountriesInput = '\\VMBIP-GSQLDB01\FinancialRisk-Upload\Mappings\Input\Countries\UnmappedCountries.xlsx'
	SET @UnmappedObligorsInput = '\\VMBIP-GSQLDB01\FinancialRisk-Upload\Mappings\Input\Obligors\UnmappedObligors.xlsx'
	SET @UnmappedOutput = '\\VMBIP-GSQLDB01\FinancialRisk-Upload\Mappings\Output\'
	Print 'PRD Variables Set'
	END



/*
Set Environmental Vairbles END 

Create Environement With Variables
================================================1========================================================================================================================
*/

IF EXISTS (select name from ssisdb.catalog.environments where name=@Environment)
BEGIN
	EXEC [SSISDB].[catalog].[delete_environment] @environment_name=@Environment, @folder_name=N'FinancialRisks'
END
EXEC [SSISDB].[catalog].[create_environment] @environment_name=@Environment, @environment_description=N'Environment for FinancialRisks', @folder_name=N'FinancialRisks'
Print 'Environment '+@Environment+' Created'

EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name='ArchiveLocation', @sensitive=False, @description=N'', @environment_name=@Environment, @folder_name=N'FinancialRisks', @value=@ArchiveLocation, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name='BDXEmail', @sensitive=False, @description=N'', @environment_name=@Environment, @folder_name=N'FinancialRisks', @value=@BDXEmail, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name='BDXError', @sensitive=False, @description=N'', @environment_name=@Environment, @folder_name=N'FinancialRisks', @value=@BDXError, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name='ClientMap', @sensitive=False, @description=N'', @environment_name=@Environment, @folder_name=N'FinancialRisks', @value=@ClientMap, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name='CompanySpreadsheet', @sensitive=False, @description=N'', @environment_name=@Environment, @folder_name=N'FinancialRisks', @value=@CompanySpreadsheet, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name='DataAnalyticsDBName', @sensitive=False, @description=N'', @environment_name=@Environment, @folder_name=N'FinancialRisks', @value=@DataAnalyticsDBName, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name='DataAnalyticsDBServer', @sensitive=False, @description=N'', @environment_name=@Environment, @folder_name=N'FinancialRisks', @value=@DataAnalyticsDBServer, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name='EmailFrom', @sensitive=False, @description=N'', @environment_name=@Environment, @folder_name=N'FinancialRisks', @value=@EmailFrom, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name='EmailTo', @sensitive=False, @description=N'', @environment_name=@Environment, @folder_name=N'FinancialRisks', @value=@EmailTo, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name='EmailToMapping', @sensitive=False, @description=N'', @environment_name=@Environment, @folder_name=N'FinancialRisks', @value=@EmailToMapping, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name='Ironshore', @sensitive=False, @description=N'', @environment_name=@Environment, @folder_name=N'FinancialRisks', @value=@Ironshore, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name='PecLinesBorderauxFilesLocation', @sensitive=False, @description=N'', @environment_name=@Environment, @folder_name=N'FinancialRisks', @value=@PecLinesBorderauxFilesLocation, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name='PecLinesProgramLiveFileLocation', @sensitive=False, @description=N'', @environment_name=@Environment, @folder_name=N'FinancialRisks', @value=@PecLinesProgramLiveFileLocation, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name='PTCAccessDBFileLocation', @sensitive=False, @description=N'', @environment_name=@Environment, @folder_name=N'FinancialRisks', @value=@PTCAccessDBFileLocation, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name='SMTPServer', @sensitive=False, @description=N'', @environment_name=@Environment, @folder_name=N'FinancialRisks', @value=@SMTPServer, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name='UnmappedCedantsInput', @sensitive=False, @description=N'', @environment_name=@Environment, @folder_name=N'FinancialRisks', @value=@UnmappedCedantsInput, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name='UnmappedCountriesInput', @sensitive=False, @description=N'', @environment_name=@Environment, @folder_name=N'FinancialRisks', @value=@UnmappedCountriesInput, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name='UnmappedObligorsInput', @sensitive=False, @description=N'', @environment_name=@Environment, @folder_name=N'FinancialRisks', @value=@UnmappedObligorsInput, @data_type=N'String'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name='UnmappedOutput', @sensitive=False, @description=N'', @environment_name=@Environment, @folder_name=N'FinancialRisks', @value=@UnmappedOutput, @data_type=N'String'

Print 'Environment '+@Environment+' Variables created'

/*
Create  Environmental Reference
========================================================================================================================================================================
*/
IF EXISTS (select environment_name from ssisdb.catalog.environment_references where environment_name=@Environment)
BEGIN
	DECLARE @EnvRef   varchar(3) = (select reference_id from ssisdb.catalog.environment_references where environment_folder_name = 'FinancialRisks')
	EXEC [SSISDB].[catalog].[delete_environment_reference] @reference_id=@EnvRef
END

Declare @reference_id bigint
EXEC [SSISDB].[catalog].[create_environment_reference] @environment_name=@Environment, @environment_folder_name=N'FinancialRisks', @reference_id=@reference_id OUTPUT, @project_name=N'FinancialRisks', @folder_name=N'FinancialRisks', @reference_type=A
Print 'Environment '+@Environment+' reference created'

EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ArchiveLocation', @object_name=N'FinancialRisks', @folder_name=N'FinancialRisks', @project_name=N'FinancialRisks', @value_type=R, @parameter_value=N'ArchiveLocation'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'BDXEmail', @object_name=N'FinancialRisks', @folder_name=N'FinancialRisks', @project_name=N'FinancialRisks', @value_type=R, @parameter_value=N'BDXEmail'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'BDXError', @object_name=N'FinancialRisks', @folder_name=N'FinancialRisks', @project_name=N'FinancialRisks', @value_type=R, @parameter_value=N'BDXError'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'ClientMap', @object_name=N'FinancialRisks', @folder_name=N'FinancialRisks', @project_name=N'FinancialRisks', @value_type=R, @parameter_value=N'ClientMap'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'CompanySpreadsheet', @object_name=N'FinancialRisks', @folder_name=N'FinancialRisks', @project_name=N'FinancialRisks', @value_type=R, @parameter_value=N'CompanySpreadsheet'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'DataAnalyticsDBName', @object_name=N'FinancialRisks', @folder_name=N'FinancialRisks', @project_name=N'FinancialRisks', @value_type=R, @parameter_value=N'DataAnalyticsDBName'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'DataAnalyticsDBServer', @object_name=N'FinancialRisks', @folder_name=N'FinancialRisks', @project_name=N'FinancialRisks', @value_type=R, @parameter_value=N'DataAnalyticsDBServer'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'EmailFrom', @object_name=N'FinancialRisks', @folder_name=N'FinancialRisks', @project_name=N'FinancialRisks', @value_type=R, @parameter_value=N'EmailFrom'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'EmailTo', @object_name=N'FinancialRisks', @folder_name=N'FinancialRisks', @project_name=N'FinancialRisks', @value_type=R, @parameter_value=N'EmailTo'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'EmailToMapping', @object_name=N'FinancialRisks', @folder_name=N'FinancialRisks', @project_name=N'FinancialRisks', @value_type=R, @parameter_value=N'EmailToMapping'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'Ironshore', @object_name=N'FinancialRisks', @folder_name=N'FinancialRisks', @project_name=N'FinancialRisks', @value_type=R, @parameter_value=N'Ironshore'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'PecLinesBorderauxFilesLocation', @object_name=N'FinancialRisks', @folder_name=N'FinancialRisks', @project_name=N'FinancialRisks', @value_type=R, @parameter_value=N'PecLinesBorderauxFilesLocation'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'PecLinesProgramLiveFileLocation', @object_name=N'FinancialRisks', @folder_name=N'FinancialRisks', @project_name=N'FinancialRisks', @value_type=R, @parameter_value=N'PecLinesProgramLiveFileLocation'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'PTCAccessDBFileLocation', @object_name=N'FinancialRisks', @folder_name=N'FinancialRisks', @project_name=N'FinancialRisks', @value_type=R, @parameter_value=N'PTCAccessDBFileLocation'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'SMTPServer', @object_name=N'FinancialRisks', @folder_name=N'FinancialRisks', @project_name=N'FinancialRisks', @value_type=R, @parameter_value=N'SMTPServer'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'UnmappedCedantsInput', @object_name=N'FinancialRisks', @folder_name=N'FinancialRisks', @project_name=N'FinancialRisks', @value_type=R, @parameter_value=N'UnmappedCedantsInput'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'UnmappedCountriesInput', @object_name=N'FinancialRisks', @folder_name=N'FinancialRisks', @project_name=N'FinancialRisks', @value_type=R, @parameter_value=N'UnmappedCountriesInput'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'UnmappedObligorsInput', @object_name=N'FinancialRisks', @folder_name=N'FinancialRisks', @project_name=N'FinancialRisks', @value_type=R, @parameter_value=N'UnmappedObligorsInput'
EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=N'UnmappedOutput', @object_name=N'FinancialRisks', @folder_name=N'FinancialRisks', @project_name=N'FinancialRisks', @value_type=R, @parameter_value=N'UnmappedOutput'



Print 'Environment '+@Environment+' Variables value set'

--/*
--Map Job To  Environmental Reference
--========================================================================================================================================================================
--*/
DECLARE @Server VARCHAR(15) = @@SERVERNAME
DECLARE @EnvReference   varchar(3) = (select reference_id from ssisdb.catalog.environment_references where environment_folder_name = 'FinancialRisks')
DECLARE @InitialLoad NVARCHAR(300) = N'/ISSERVER "\"\SSISDB\FinancialRisks\FinancialRisks\FREDInitialLoadPackage.dtsx\"" /SERVER "\"' + @Server + '\"" /ENVREFERENCE '+@EnvReference+' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'
DECLARE @PecLines NVARCHAR(300)  = N'/ISSERVER "\"\SSISDB\FinancialRisks\FinancialRisks\PecLines.dtsx\"" /SERVER "\"' + @Server + '\"" /ENVREFERENCE '+@EnvReference+' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'
DECLARE @PTC NVARCHAR(300)  = N'/ISSERVER "\"\SSISDB\FinancialRisks\FinancialRisks\PTC.dtsx\"" /SERVER "\"' + @Server + '\"" /X86 /ENVREFERENCE '+@EnvReference+' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'
DECLARE @GFR NVARCHAR(300)  = N'/ISSERVER "\"\SSISDB\FinancialRisks\FinancialRisks\GFR.dtsx\"" /SERVER "\"' + @Server + '\"" /ENVREFERENCE '+@EnvReference+' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'
DECLARE @LMIEDirectSurety NVARCHAR(300) = N'/ISSERVER "\"\SSISDB\FinancialRisks\FinancialRisks\LMIEDirectSurety.dtsx\"" /SERVER "\"' + @Server + '\"" /ENVREFERENCE '+@EnvReference+' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'
DECLARE @IronshoreMap NVARCHAR(300)  = N'/ISSERVER "\"\SSISDB\FinancialRisks\FinancialRisks\Ironshore.dtsx\"" /SERVER "\"' + @Server + '\"" /ENVREFERENCE '+@EnvReference+' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'
DECLARE @IdentifyMappings NVARCHAR(300)= N'/ISSERVER "\"\SSISDB\FinancialRisks\FinancialRisks\IdentifyMappings.dtsx\"" /SERVER "\"' + @Server + '\"" /ENVREFERENCE '+@EnvReference+' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'
DECLARE @UpdateMappings NVARCHAR(300) = N'/ISSERVER "\"\SSISDB\FinancialRisks\FinancialRisks\UpdateMappings.dtsx\"" /SERVER "\"' + @Server + '\"" /ENVREFERENCE '+@EnvReference+' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'
DECLARE @CheckForFiles NVARCHAR(300) = N'/ISSERVER "\"\SSISDB\FinancialRisks\FinancialRisks\FileName.dtsx\"" /SERVER "\"' + @Server + '\"" /ENVREFERENCE '+@EnvReference+' /Par "\"$ServerOption::LOGGING_LEVEL(Int16)\"";1 /Par "\"$ServerOption::SYNCHRONIZED(Boolean)\"";True /CALLERINFO SQLAGENT /REPORTING E'
	

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = N'FinancialRisks_GFR')
BEGIN
	EXEC msdb.dbo.sp_update_jobstep @job_name=N'FinancialRisks_GFR', @step_id=1 , @command=@GFR
END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = N'FinancialRisks_IdentifyMappings')
BEGIN
	EXEC msdb.dbo.sp_update_jobstep @job_name=N'FinancialRisks_IdentifyMappings', @step_id=1 , @command=@IdentifyMappings
END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = N'FinancialRisks_InitialLoad')
BEGIN
	EXEC msdb.dbo.sp_update_jobstep @job_name=N'FinancialRisks_InitialLoad', @step_id=1 , @command=@InitialLoad
END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = N'FinancialRisks_Ironshore')
BEGIN
	EXEC msdb.dbo.sp_update_jobstep @job_name=N'FinancialRisks_Ironshore', @step_id=1 , @command=@IronshoreMap
END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = N'FinancialRisks_LMIEDirectSurety')
BEGIN
	EXEC msdb.dbo.sp_update_jobstep @job_name=N'FinancialRisks_LMIEDirectSurety', @step_id=1 , @command=@LMIEDirectSurety
END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = N'FinancialRisks_PecLines')
BEGIN
	EXEC msdb.dbo.sp_update_jobstep @job_name=N'FinancialRisks_PecLines', @step_id=1 , @command=@PecLines
END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = N'FinancialRisks_PTC')
BEGIN
	EXEC msdb.dbo.sp_update_jobstep @job_name=N'FinancialRisks_PTC', @step_id=1 , @command=@PTC
END

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = N'FinancialRisks_UpdateMappings')
BEGIN
	EXEC msdb.dbo.sp_update_jobstep @job_name=N'FinancialRisks_UpdateMappings', @step_id=1 , @command=@UpdateMappings
END

Print 'SQL Agent jobs updated to include reference to Environment '+@Environment+'.'

/*
Set Environmental Variables End
========================================================================================================================================================================
*/

Print 'SSIS Environment Update Completed'

/*
Update jobs Start
========================================================================================================================================================================
*/
IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs WHERE name = N'FinancialRisks_QuarterUpdate')

BEGIN
	EXEC msdb.dbo.sp_delete_job @job_name=N'FinancialRisks_QuarterUpdate', @delete_unused_schedule=1
END
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0

DECLARE @SsisOwner VARCHAR(30)
SELECT @SsisOwner = CASE @@SERVERNAME
			        WHEN 'VMBID-GSQLDB01' THEN 'LM\sagsdAAP-SSIS'
					WHEN 'VMBIT-GSQLDB01' THEN 'LM\sagstAAP-SSIS'
					WHEN 'VMBIS-GSQLDB01' THEN 'LM\sagssAAP-SSIS'
			        WHEN 'VMBIP-GSQLDB01' THEN 'LM\sagspAAP-SSIS'
					END
DECLARE @PackageExecutionProxy VARCHAR(20) 
SELECT @PackageExecutionProxy = CASE @@SERVERNAME
					WHEN 'VMBID-GSQLDB01' THEN 'Pr-AAP-DEV-System'
					WHEN 'VMBIT-GSQLDB01' THEN 'Pr-AAP-SIT-System'
					WHEN 'VMBIS-GSQLDB01' THEN 'Pr-AAP-UAT-System'
			        WHEN 'VMBIP-GSQLDB01' THEN 'Pr-AAP-PRD-System'
					END
SELECT @Server = @@SERVERNAME

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'FinancialRisks_QuarterUpdate', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Run quarterly to get all data for FRED update', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name= @SsisOwner, 
		@job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CheckForFiles]    Script Date: 11/03/2019 11:54:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CheckForFiles', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=@CheckForFiles,
		@database_name=N'master', 
		@flags=0
		,@proxy_name= @PackageExecutionProxy
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [GFR]    Script Date: 11/03/2019 11:54:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'GFR', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=@GFR,
		@database_name=N'master', 
		@flags=0
		,@proxy_name= @PackageExecutionProxy
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Ironshore]    Script Date: 11/03/2019 11:54:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Ironshore', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=@IronshoreMap,
		@database_name=N'master', 
		@flags=0
		,@proxy_name= @PackageExecutionProxy
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [LMIEDirectSurety]    Script Date: 11/03/2019 11:54:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'LMIEDirectSurety', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=@LMIEDirectSurety,
		@database_name=N'master', 
		@flags=0
		,@proxy_name= @PackageExecutionProxy
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PTC]    Script Date: 11/03/2019 11:54:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PTC', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=@PTC,
		@database_name=N'master', 
		@flags=0
		,@proxy_name= @PackageExecutionProxy
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PecLines]    Script Date: 11/03/2019 11:54:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PecLines', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=@PecLines,
		@database_name=N'master', 
		@flags=0
		,@proxy_name= @PackageExecutionProxy
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [IdentifyMappings]    Script Date: 11/03/2019 11:54:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'IdentifyMappings', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=@IdentifyMappings,
		@database_name=N'master', 
		@flags=0
		,@proxy_name= @PackageExecutionProxy
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'FinancialRisks_QuarterUpdateSchedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=62, 
		@freq_subday_type=8, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20190311, 
		@active_end_date=99991231, 
		@active_start_time=90000, 
		@active_end_time=170000 
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO
Print 'SQL Agent job created for upload.'





Print 'Schedule created for UpdateMappingsPackage'


/*
Update jobs End
========================================================================================================================================================================
*/

Print 'jobs Environment Update Completed'
PRINT 'Script Completed'