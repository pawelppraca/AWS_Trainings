USE [Actuarial_Analytics]
GO

/****** Object:  StoredProcedure [FinancialRisks].[CommonShockModelExtract]    Script Date: 09/09/2021 11:39:43 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




DROP TABLE IF  EXISTS #lbeCSM
DROP TABLE IF  EXISTS #ClassAvgPD
--CREATE PROC [FinancialRisks].[CommonShockModelExtract]
DECLARE @InforceDate DATETIME2
SET @InforceDate = (select distinct lastruntime from FinancialRisks.AddNewData)
--AS

select * 
into #lbeCSM
from FinancialRisks.vw_ExposureOverview where InforceDate = @InforceDate
and RiskCode in  ('CF','CR', 'SB', 'SU', 'FG','PB','PQ') -- ADDED MORE CLAUSES 
--and UltimateRating is not null
and UltimateTradeSectorID is not null 
and cobid = 5
--and UltimateDomicile is not null 
--and assured <> 'microsoft'
--select * from #lbecsm

DECLARE @ReferenceUploadDate datetime
set @ReferenceUploadDate = (SELECT max (ReferenceUploadDate) AS ReferenceUploadDate FROM FinancialRisks.Ratings)

SELECT ClassOfBusinessID,
avg(CAST([1_Yr_PD] as float)) AS [1_Yr_Class_Avg],
avg(CAST([1_Yr_PD] AS float)) AS [2_Yr_Class_Avg],
avg(CAST([1_Yr_PD] AS float)) AS [3_Yr_Class_Avg],
avg(CAST([1_Yr_PD] AS float)) AS [4_Yr_Class_Avg],
avg(CAST([1_Yr_PD] AS float)) AS [5_Yr_Class_Avg],
avg(CAST([1_Yr_PD] AS float)) AS [6_Yr_Class_Avg],
avg(CAST([1_Yr_PD] AS float)) AS [7_Yr_Class_Avg],
avg(CAST([1_Yr_PD] AS float)) AS [8_Yr_Class_Avg],
avg(CAST([1_Yr_PD] AS float)) AS [9_Yr_Class_Avg],
avg(CAST([1_Yr_PD] AS float)) AS [10_Yr_Class_Avg]
INTO #ClassAvgPD
FROM
(
SELECT CASE WHEN CobId IN (1,2) THEN 8 ELSE CobId END AS ClassOfBusinessID, ISNULL(ISNULL(r.RatingType,s.RatingType),t.RatingType) AS FinalRating
from #lbeCSM lbe
LEFT JOIN FinancialRisks.Ratings r on r.RatingType = lbe.SPRating and r.ReferenceUploadDate=@ReferenceUploadDate
LEFT JOIN FinancialRisks.Ratings s on s.RatingType = lbe.GCHPRating and s.ReferenceUploadDate=@ReferenceUploadDate
LEFT JOIN FinancialRisks.Ratings t on t.RatingType = lbe.LibertyRating and t.ReferenceUploadDate=@ReferenceUploadDate
LEFT JOIN FinancialRisks.RatingDefaultProbability pr ON pr.RatingID = r.RatingID and pr.ReferenceUploadDate=@ReferenceUploadDate
LEFT JOIN FinancialRisks.RatingDefaultProbability pr2 ON pr2.RatingID = s.RatingID and pr2.ReferenceUploadDate=@ReferenceUploadDate
LEFT JOIN FinancialRisks.RatingDefaultProbability pr3 ON pr3.RatingID = t.RatingID and pr3.ReferenceUploadDate=@ReferenceUploadDate
WHERE lbe.InforceDate = @InforceDate -- Date of refresh
) p
INNER JOIN FinancialRisks.Industry_PD_Matrix im ON im.Rating = p.FinalRating
WHERE im.IndustryNo = 0 AND FinalRating IS NOT NULL AND FinalRating <> 'NR' and im.ReferenceUploadDate = @ReferenceUploadDate AND FinalRating <> 'D' 
GROUP BY ClassOfBusinessID

--INSERT INTO [FinancialRisks].[CSMOutput]
--(

--[ObligorEntityID],[ClassOfBusiness],[CobId],[EntityName],[CapitalIQID],[Region],[TradeSectorID],[Industry],[FinalRating],[ClassLGD],[NetExposure],
--[PD1],[PD2],[PD3],[PD4],[PD5],[PD6],[PD7],[PD8],[PD9],[PD10],[InforceDate] ,[ReferenceUploadDate]
--)
--By class
SELECT ObligorEntityID,ClassOfBusiness,CobId,EntityName,CapitalIQID,Region,TradeSectorID,Industry,FinalRating,ClassLGD,NetExposure,
[PD1],[PD2],[PD3],[PD4],[PD5],[PD6],[PD7],[PD8],[PD9],[PD10] ,inforcedate,@ReferenceUploadDate as[ReferenceUploadDate]
 FROM
(
SELECT ROW_NUMBER() OVER (PARTITION BY x.CobId,x.ObligorEntityID ORDER BY NetExposure DESC) AS Rnk,x.ObligorEntityID,x.ClassOfBusiness,x.CobID,x.EntityName,x.CapitalIQID, x.Region, x.UltimateTradeSectorID as TradeSectorId,x.UltimateTradeSectorName as Industry,x.FinalRating, x.ClassLGD, x.NetExposure,
ISNULL([1_Yr_PD],[1_Yr_Class_Avg]) AS [PD1],
ISNULL([2_Yr_PD],[2_Yr_Class_Avg]) AS [PD2],
ISNULL([3_Yr_PD],[3_Yr_Class_Avg]) AS [PD3],
ISNULL([4_Yr_PD],[4_Yr_Class_Avg]) AS [PD4],
ISNULL([5_Yr_PD],[5_Yr_Class_Avg]) AS [PD5],
ISNULL([6_Yr_PD],[6_Yr_Class_Avg]) AS [PD6],
ISNULL([7_Yr_PD],[7_Yr_Class_Avg]) AS [PD7],
ISNULL([8_Yr_PD],[8_Yr_Class_Avg]) AS [PD8],
ISNULL([9_Yr_PD],[9_Yr_Class_Avg]) AS [PD9],
ISNULL([10_Yr_PD],[10_Yr_Class_Avg]) AS [PD10],x.inforcedate
FROM
(
SELECT ObligorEntityId, ClassOfBusiness, CobId, EntityName, CapitalIqId, [Entity Region] as Region,
lbe.TopLevelTradeSectorID as UltimateTradeSectorID, 
lbe.UltimateTradeSectorName,
lbe.UltimateRating AS FinalRating,
lbe.ClassLGD,
SUM(lbe.LibertyExposure) as NetExposure,lbe.InforceDate
from #lbeCSM lbe
LEFT JOIN FinancialRisks.Ratings r on r.RatingType = lbe.UltimateRating and r.ReferenceUploadDate=@ReferenceUploadDate
LEFT JOIN FinancialRisks.RatingDefaultProbability pr ON pr.RatingID = r.RatingID and pr.ReferenceUploadDate=@ReferenceUploadDate
--LEFT JOIN #UltimateTS uts ON uts.TradeSectorID = lbe.TradeSectorID
WHERE lbe.InforceDate = @InforceDate
and lbe.LibertyExposure is not null
GROUP BY ObligorEntityID, ClassOfBusiness,cobId,EntityName,CapitalIQID,[Entity Region], ClassLGD,
TopLevelTradeSectorID,r.RatingType,lbe.InforceDate,UltimateTradeSectorName,UltimateRating
HAVING SUM(lbe.LibertyExposure) > 0
) x
INNER JOIN #ClassAvgPD cpd ON cpd.ClassOfBusinessID = (CASE WHEN x.CobId IN (1,2) THEN 8 ELSE x.CobId END)
LEFT JOIN FinancialRisks.Industry_PD_Matrix im ON im.TradeSectorID = x.UltimateTradeSectorID AND im.Rating = x.FinalRating
) xx
WHERE Rnk = 1
ORDER BY EntityName







GO

USE [Actuarial_Analytics]
GO

/****** Object:  StoredProcedure [FinancialRisks].[CommonShockModelFinal]    Script Date: 09/09/2021 11:55:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
--EXTRACT DATA -> R Code Runs with Extract to product Output

--CREATE PROC [FinancialRisks].[CommonShockModelFinal]
DECLARE @InforceDate DATETIME2
SET @InforceDate = (select distinct lastruntime from FinancialRisks.AddNewData)
--AS


DROP TABLE IF EXISTS [FinancialRisks].[CSMOutputR]

SET NOCOUNT ON

DROP TABLE IF EXISTS #lbeCSM
SELECT * 
INTO #lbeCSM
FROM FinancialRisks.vw_ExposureOverview WHERE InforceDate = @InforceDate
and RiskCode in  ('CF','CR', 'SB', 'SU', 'FG','PB','PQ')
--and UltimateRating is not null
and UltimateTradeSectorID is not null 
and cobid = 5
--and UltimateDomicile is not null 
--and assured <> 'microsoft'
--select * from #lbecsm



SELECT ClassOfBusinessID,SimNo,SimPeriod,TreatyID,ExposureID,Limit,Excess,SignedLine,OurShare,ExpGR,LossGR,ExpNT,
                --XOL = APPLY XOL TERMS
                CASE WHEN TreatyType = 'XL' THEN
                        CASE WHEN LossGR > Excess THEN
                            CASE WHEN LossGR > (Limit + Excess) THEN Limit ELSE LossGR - Excess END
                        ELSE 0 END
                --QS = LossGR UNLESS LIMIT IS PRESENT THEN APPLY LIMIT + QS TERMS
                WHEN TreatyType  in ('QS', 'BA') THEN
                        CASE WHEN LossGR > Limit AND Limit > 0 THEN Limit ELSE LossGR END
                        when TreatyID is null then ExpGR
                END 
                --APPLY LINE AND OURSHARE
                * SignedLine * OurShare AS LossNT,
CedantName,
GCHPRating,
LibertyRating,
SPRating,
EntityName

				 into #CSMOutputR
       FROM   (
              SELECT 

              lbe.CobId as ClassOfBusinessID,
			  lbe.CedantName,
			  lbe.EntityName,
			  lbe.GCHPRating,
			  lbe.LibertyRating,
			  lbe.SPRating
              ,cast(CSMO.DefaultSimNo as int) as SimNo
              ,CSMO.DefaultYear as SimPeriod
              ,lbe.TreatyType
              ,lbe.TreatyID
              ,lbe.ExposureID
              ,cast(CSMO.SimLGD as float) as SimLGD
              ,ISNULL(lbe.TreatyLimit / (case when lbe.Rate = 'NR' then 0 else cast(lbe.Rate as float) end),0) AS Limit
              ,ISNULL(lbe.Excess / (case when lbe.Rate = 'NR' then 0 else cast(lbe.Rate as float) end),0) AS Excess
              ,isnull(lbe.SignedLine,1) as SignedLine
              ,isnull(lbe.OurShare,1)as OurShare
              ,sum(isnull(lbe.GrossExposure,0)) AS ExpGR
              ,sum(lbe.LibertyExposure) AS ExpNT
              ,sum(isnull(lbe.GrossExposure,0) * cast(CSMO.SimLGD as float)) AS LossGR
              FROM #lbeCSM lbe
              inner join FinancialRisks.CSM_Model_OutputV2 CSMO on CSMo.Entity = lbe.ObligorEntityId and CSMo.ClassID = lbe.CobId and  CSMO.inforcedate = lbe.InforceDate
              where  lbe.InforceDate = @InforceDate
              GROUP BY
              lbe.CobId,
			  lbe.EntityName,
			  lbe.CedantName,
			  lbe.GCHPRating,
			  lbe.LibertyRating,
			  lbe.SPRating
              ,cast(CSMO.DefaultSimNo as int)
              ,CSMO.DefaultYear
              ,lbe.TreatyType
              ,lbe.TreatyID
              ,lbe.ExposureID
              ,cast(CSMO.SimLGD as float)
              ,ISNULL(lbe.TreatyLimit / (case when lbe.Rate = 'NR' then 0 else cast(lbe.Rate as float) end),0)
              ,ISNULL(lbe.Excess / (case when lbe.Rate = 'NR' then 0 else cast(lbe.Rate as float) end),0) 
              ,isnull(lbe.SignedLine,1) 
              ,isnull(lbe.OurShare,1)
              )x          



--CRUVE BY CLASS
SELECT sr.ClassOfBusinessID,SimNo,SimPeriod,sum(LossNT) Loss ,@InforceDate as 'InforceDate'
FROM #CSMOutputR sr
GROUP BY sr.ClassOfBusinessID,SimNo,SimPeriod


DROP TABLE IF EXISTS #CSMOutputR -- DROP TABLE AS THIS IS A LARGE DATASET

--select * from FinancialRisks.Industry_PD_Matrix
