USE [Actuarial_Analytics]


SET NOCOUNT ON

GO
	
DROP TABLE IF EXISTS #LossByExposure
DROP TABLE IF EXISTS #CurrencyFXRates

GO

  SELECT    									
                        distinct    									
                        ccyFrom.CurrencyCode  as 'Name'	,								
                        roe.ExchangeRate   as 'rate',
						YEAR(roe.ExchangeRateDateKey) as 'year'
					into #CurrencyFXRates	 									
            FROM    									
                        [sources].[vw_dwhr_Currencies] ccyFrom   									
                        INNER JOIN sources.vw_dwhr_ISOCurrencies ccyFromISO ON ccyFrom.ISOCurrencyKey = ccyFromISO.ISOCurrencyKey   									
                        INNER JOIN sources.vw_dwhr_ExchangeRates roe ON ccyFromISO.ISOCurrencyKey = roe.ISOCurrencyFromKey   									
                        INNER JOIN sources.vw_dwhr_ISOCurrencies ccyToISO ON roe.ISOCurrencyToKey = ccyToISO.ISOCurrencyKey   									
            WHERE    									
                        ccyToISO.ISOCurrencyCode = N'USD'   									
                      --  AND roe.ExchangeRateTypeCode = N'[Lloyd''s PIM]'  									
						AND roe.ExchangeRateTypeCode = N'[GAAP Plan]' 			
						--AND YEAR(roe.ExchangeRateDateKey) = year(getdate()) 	


DECLARE @inforcedate datetime	
SET @inforcedate = '2019-10-01 00:00:00.000'	

DROP TABLE IF EXISTS #GFRLossByExposure


SELECT
	   ExposureId,
	   ObligorEntityId,
	   EntityName,
	   CapitalIqId,
	   Region,
	   SPRating,
	   GCHPRating,
	   LibertyRating,
	   CedantName, 
	   ReportingClass,
	   ClassOfBusiness,
	   CobId,
	   CountryName,
	   ClassLGD,
	   SovereignRating,
	   TradeSectorName,
	   TradeSectorId,
	   InceptionDate,
	   ExpiryDate,
	   RateGroup,
	   --CASE WHEN CedantName = 'LIB' THEN NULL ELSE TreatyType END AS TreatyType,
	   TreatyType,
	   CurrencyName, 
       GrossExposure,
	--XL CALC
	CASE WHEN TreatyType = 'XL' THEN
		CASE WHEN GrossExposure > (Excess /Rate) THEN  
			 CASE WHEN (GrossExposure - Excess) > (TreatyLimit / Rate) THEN (TreatyLimit / Rate) * SignedLine ELSE (GrossExposure - (Excess / Rate) ) * SignedLine END
		ELSE 0 END
	--QS CALC
	WHEN TreatyType in ('QS', 'BA') THEN 
		CASE WHEN ISNULL(TreatyLimit / Rate,0) > 0 THEN
			CASE WHEN GrossExposure > (TreatyLimit / Rate) THEN (TreatyLimit / Rate) * SignedLine ELSE GrossExposure * SignedLine END
		ELSE GrossExposure * SignedLine END
	ELSE GrossExposure -- For LMIE and GFR that don't have treatys attached
	END AS LibertyExposure,
	InforceDate,TreatyLimit,Rate,Excess,SignedLine,OurShare,TreatyID,RiskReference,SystemTreatyId,assured,UploadDate
	--DROP TABLE IF EXISTS #LossByExposure

INTO #GFRLossByExposure
FROM
(
	SELECT DISTINCT tr.NewReference as SystemTreatyId, e.ExposureId,
	c.Name as CedantName,cob.ReportingClass,e.RiskReference,e.InceptionDate,e.ExpiryDate, tr.Limit as TreatyLimit, ecr.Name AS CurrencyName, cr.RateGroup,
	 ttcr.Rate, e.CurrencyId, cob.CobId, cob.Name as ClassOfBusiness,
	 tr.AuditCode as TreatyType, tr.Excess, tr.SignedLine, tr.OurShare,
	CASE WHEN e.cobid NOT IN (1, 2, 5) THEN --COB IDs for GFR and PTC which allready have their Currencies FX rates applied
		CASE WHEN e.GrossExposure / ecr.Rate > ISNULL(e.Limit / ecr.Rate,0) AND ISNULL(e.Limit / ecr.Rate,0) > 0 
		THEN ISNULL(e.Limit / ecr.Rate,0) 
		ELSE e.GrossExposure / ecr.Rate END
	ELSE e.GrossExposure END AS GrossExposure, 
	 
	 case when en.EntityName like '%Ministry%' 
		  then case when  en.EntityName  like '%'+co.CountryName+'%'
					then en.EntityName
					else en.EntityName +' - ' + co.CountryName  
				END
		  else en.EntityName
		END as EntityName,
	 en.EntityId as ObligorEntityId,
	 co.CountryName,
	 co.Region,
	 ts.TradeSectorName,
	 ts.TradeSectorId,
	 cob.ClassLGD,
	 en.SPRating,
	 en.GCHPRating,
	 en.LibertyRating,
	 en.CapitalIqId,
	 co.SovereignRating,
	 e.InforceDate,TreatyID,assured,UploadDate
	FROM FinancialRisks.Exposures e
	--cedants
	LEFT JOIN FinancialRisks.Cedant c on c.CedantID = e.CedantId
	--exposure riskcode mappings
	LEFT JOIN FinancialRisks.RiskCodeMappings riskCodeMappings on riskCodeMappings.riskCode = e.RiskCode 
	--join treaties to exposures on cedant, risk code group and inforcedate
	LEFT JOIN FinancialRisks.Treaties tr on tr.CedantId = c.CedantID  and tr.InforceDate = e.InforceDate
	--exposure currency data
	LEFT JOIN FinancialRisks.Currencies cr on cr.CurrencyID = e.CurrencyID
	--2019 Currency Exchange Rates for Exposures
	LEFT JOIN #CurrencyFXRates ecr ON cr.CurrencyName = ecr.Name
	--treaties currency data
	LEFT JOIN FinancialRisks.Currencies tcr on tcr.CurrencyID = tr.CurrencyID
	--2019 Currency Exchange Rates for Treaties
	LEFT JOIN #CurrencyFXRates ttcr ON tcr.CurrencyName = ttcr.Name
	--reporting classes data
	LEFT JOIN FinancialRisks.COB cob on cob.CobId = e.CobId
	--obligor data
	LEFT JOIN FinancialRisks.Entities en on en.EntityId = e.ObligorEntityId
	--country data
	LEFT JOIN FinancialRisks.Countries co on co.CountryId = e.CountryId
	--trade sector data
	LEFT JOIN FinancialRisks.TradeSector ts on ts.TradeSectorID = en.TradeSectorId

	WHERE ((e.InceptionDate >= tr.InceptionDate AND e.InceptionDate <= tr.ExpiryDate) OR c.Name = 'LIB')
	AND e.RiskCode in ('CF','CR', 'SB', 'SU', 'FG','PB','PQ')
	AND en.EntityName != 'No capital IQ ID Assigned.'
	AND LEN(en.EntityName) > 1
	AND (e.RiskReference IS NULL OR e.RiskReference <> '584110/01/18')
	and e.InforceDate  =@inforcedate
	and e.Source in ('GFR')
) innerQuery

--select * from #GFRLMIELossByExposure where CobId = 1
--select * from #GFRLMIELossByExposure where CobId = 2

/**************************************************************************************************************************************/
DROP TABLE IF EXISTS #LMIELossByExposure


SELECT
	   ExposureId,
	   ObligorEntityId,
	   EntityName,
	   CapitalIqId,
	   Region,
	   SPRating,
	   GCHPRating,
	   LibertyRating,
	   CedantName, 
	   ReportingClass,
	   ClassOfBusiness,
	   CobId,
	   CountryName,
	   ClassLGD,
	   SovereignRating,
	   TradeSectorName,
	   TradeSectorId,
	   InceptionDate,
	   ExpiryDate,
	   RateGroup,
	   --CASE WHEN CedantName = 'LIB' THEN NULL ELSE TreatyType END AS TreatyType,
	   TreatyType,
	   CurrencyName, 
       GrossExposure,
	--XL CALC
	CASE WHEN TreatyType = 'XL' THEN
		CASE WHEN GrossExposure > (Excess /Rate) THEN  
			 CASE WHEN (GrossExposure - Excess) > (TreatyLimit / Rate) THEN (TreatyLimit / Rate) * SignedLine ELSE (GrossExposure - (Excess / Rate) ) * SignedLine END
		ELSE 0 END
	--QS CALC
	WHEN TreatyType in ('QS', 'BA') THEN 
		CASE WHEN ISNULL(TreatyLimit / Rate,0) > 0 THEN
			CASE WHEN GrossExposure > (TreatyLimit / Rate) THEN (TreatyLimit / Rate) * SignedLine ELSE GrossExposure * SignedLine END
		ELSE GrossExposure * SignedLine END
	ELSE GrossExposure -- For LMIE and GFR that don't have treatys attached
	END AS LibertyExposure,
	InforceDate,TreatyLimit,Rate,Excess,SignedLine,OurShare,TreatyID,RiskReference,SystemTreatyId,assured,UploadDate
	--DROP TABLE IF EXISTS #LossByExposure

INTO #LMIELossByExposure
FROM
(
	SELECT DISTINCT tr.NewReference as SystemTreatyId, e.ExposureId,
	c.Name as CedantName,cob.ReportingClass,e.RiskReference,e.InceptionDate,e.ExpiryDate, tr.Limit as TreatyLimit, ecr.Name AS CurrencyName, cr.RateGroup,
	 ttcr.Rate, e.CurrencyId, cob.CobId, cob.Name as ClassOfBusiness,
	 tr.AuditCode as TreatyType, tr.Excess, tr.SignedLine, tr.OurShare,
	CASE WHEN e.cobid NOT IN (1, 2, 5) THEN --COB IDs for GFR and PTC which allready have their Currencies FX rates applied
		CASE WHEN e.GrossExposure / ecr.Rate > ISNULL(e.Limit / ecr.Rate,0) AND ISNULL(e.Limit / ecr.Rate,0) > 0 
		THEN ISNULL(e.Limit / ecr.Rate,0) 
		ELSE e.GrossExposure / ecr.Rate END
	ELSE e.GrossExposure END AS GrossExposure, 
	 
	 case when en.EntityName like '%Ministry%' 
		  then case when  en.EntityName  like '%'+co.CountryName+'%'
					then en.EntityName
					else en.EntityName +' - ' + co.CountryName  
				END
		  else en.EntityName
		END as EntityName,
	 en.EntityId as ObligorEntityId,
	 co.CountryName,
	 co.Region,
	 ts.TradeSectorName,
	 ts.TradeSectorId,
	 cob.ClassLGD,
	 en.SPRating,
	 en.GCHPRating,
	 en.LibertyRating,
	 en.CapitalIqId,
	 co.SovereignRating,
	 e.InforceDate,TreatyID,assured,UploadDate
	FROM FinancialRisks.Exposures e
	--cedants
	LEFT JOIN FinancialRisks.Cedant c on c.CedantID = e.CedantId
	--exposure riskcode mappings
	LEFT JOIN FinancialRisks.RiskCodeMappings riskCodeMappings on riskCodeMappings.riskCode = e.RiskCode 
	--join treaties to exposures on cedant, risk code group and inforcedate
	LEFT JOIN FinancialRisks.Treaties tr on tr.CedantId = c.CedantID  and tr.InforceDate = e.InforceDate
	--exposure currency data
	LEFT JOIN FinancialRisks.Currencies cr on cr.CurrencyID = e.CurrencyID
	--2019 Currency Exchange Rates for Exposures
	LEFT JOIN #CurrencyFXRates ecr ON cr.CurrencyName = ecr.Name
	--treaties currency data
	LEFT JOIN FinancialRisks.Currencies tcr on tcr.CurrencyID = tr.CurrencyID
	--2019 Currency Exchange Rates for Treaties
	LEFT JOIN #CurrencyFXRates ttcr ON tcr.CurrencyName = ttcr.Name
	--reporting classes data
	LEFT JOIN FinancialRisks.COB cob on cob.CobId = e.CobId
	--obligor data
	LEFT JOIN FinancialRisks.Entities en on en.EntityId = e.ObligorEntityId
	--country data
	LEFT JOIN FinancialRisks.Countries co on co.CountryId = e.CountryId
	--trade sector data
	LEFT JOIN FinancialRisks.TradeSector ts on ts.TradeSectorID = en.TradeSectorId

	WHERE ((e.InceptionDate >= tr.InceptionDate AND e.InceptionDate <= tr.ExpiryDate) OR c.Name = 'LIB')
	AND e.RiskCode in ('CF','CR', 'SB', 'SU', 'FG','PB','PQ')
	AND en.EntityName != 'No capital IQ ID Assigned.'
	AND LEN(en.EntityName) > 1
	AND (e.RiskReference IS NULL OR e.RiskReference <> '584110/01/18')
	and e.InforceDate  =@inforcedate
	and e.Source in ('LMIE')
) innerQuery

--select * from #GFRLMIELossByExposure where CobId = 1
--select * from #GFRLMIELossByExposure where CobId = 2

/**************************************************************************************************************************************/
DROP TABLE IF EXISTS #PTCLossByExposure


SELECT
	   ExposureId,
	   ObligorEntityId,
	   EntityName,
	   CapitalIqId,
	   Region,
	   SPRating,
	   GCHPRating,
	   LibertyRating,
	   CedantName, 
	   ReportingClass,
	   ClassOfBusiness,
	   CobId,
	   CountryName,
	   ClassLGD,
	   SovereignRating,
	   TradeSectorName,
	   TradeSectorId,
	   InceptionDate,
	   ExpiryDate,
	   RateGroup,
	   --CASE WHEN CedantName = 'LIB' THEN NULL ELSE TreatyType END AS TreatyType,
	   TreatyType,
	   CurrencyName, 
       GrossExposure,
	--XL CALC
	CASE WHEN TreatyType = 'XL' THEN
		CASE WHEN GrossExposure > (Excess /Rate) THEN  
			 CASE WHEN (GrossExposure - Excess) > (TreatyLimit / Rate) THEN (TreatyLimit / Rate) * SignedLine ELSE (GrossExposure - (Excess / Rate) ) * SignedLine END
		ELSE 0 END
	--QS CALC
	WHEN TreatyType in ('QS', 'BA') THEN 
		CASE WHEN ISNULL(TreatyLimit / Rate,0) > 0 THEN
			CASE WHEN GrossExposure > (TreatyLimit / Rate) THEN (TreatyLimit / Rate) * SignedLine ELSE GrossExposure * SignedLine END
		ELSE GrossExposure * SignedLine END
	ELSE GrossExposure -- For LMIE and GFR that don't have treatys attached
	END AS LibertyExposure,
	InforceDate,TreatyLimit,Rate,Excess,SignedLine,OurShare,TreatyID,RiskReference,SystemTreatyId,assured,UploadDate
	--DROP TABLE IF EXISTS #LossByExposure

INTO #PTCLossByExposure
FROM
(
	SELECT DISTINCT tr.NewReference as SystemTreatyId, e.ExposureId,
	c.Name as CedantName,cob.ReportingClass,e.RiskReference,e.InceptionDate,e.ExpiryDate, tr.Limit as TreatyLimit, ecr.Name AS CurrencyName, cr.RateGroup,
	 ttcr.Rate, e.CurrencyId, cob.CobId, cob.Name as ClassOfBusiness,
	 tr.AuditCode as TreatyType, tr.Excess, tr.SignedLine, tr.OurShare,
	CASE WHEN e.cobid NOT IN (1, 2, 5) THEN --COB IDs for GFR and PTC which allready have their Currencies FX rates applied
		CASE WHEN e.GrossExposure / ecr.Rate > ISNULL(e.Limit / ecr.Rate,0) AND ISNULL(e.Limit / ecr.Rate,0) > 0 
		THEN ISNULL(e.Limit / ecr.Rate,0) 
		ELSE e.GrossExposure / ecr.Rate END
	ELSE e.GrossExposure END AS GrossExposure, 
	 
	 case when en.EntityName like '%Ministry%' 
		  then case when  en.EntityName  like '%'+co.CountryName+'%'
					then en.EntityName
					else en.EntityName +' - ' + co.CountryName  
				END
		  else en.EntityName
		END as EntityName,
	 en.EntityId as ObligorEntityId,
	 co.CountryName,
	 co.Region,
	 ts.TradeSectorName,
	 ts.TradeSectorId,
	 cob.ClassLGD,
	 en.SPRating,
	 en.GCHPRating,
	 en.LibertyRating,
	 en.CapitalIqId,
	 co.SovereignRating,
	 e.InforceDate,TreatyID,assured,UploadDate
	FROM FinancialRisks.Exposures e
	--cedants
	LEFT JOIN FinancialRisks.Cedant c on c.CedantID = e.CedantId
	--exposure riskcode mappings
	LEFT JOIN FinancialRisks.RiskCodeMappings riskCodeMappings on riskCodeMappings.riskCode = e.RiskCode 
	--join treaties to exposures on cedant, risk code group and inforcedate
	LEFT JOIN FinancialRisks.Treaties tr on tr.CedantId = c.CedantID  and tr.InforceDate = e.InforceDate and e.RiskReference=tr.NewReference
	--exposure currency data
	LEFT JOIN FinancialRisks.Currencies cr on cr.CurrencyID = e.CurrencyID
	--2019 Currency Exchange Rates for Exposures
	LEFT JOIN #CurrencyFXRates ecr ON cr.CurrencyName = ecr.Name
	--treaties currency data
	LEFT JOIN FinancialRisks.Currencies tcr on tcr.CurrencyID = tr.CurrencyID
	--2019 Currency Exchange Rates for Treaties
	LEFT JOIN #CurrencyFXRates ttcr ON tcr.CurrencyName = ttcr.Name
	--reporting classes data
	LEFT JOIN FinancialRisks.COB cob on cob.CobId = e.CobId
	--obligor data
	LEFT JOIN FinancialRisks.Entities en on en.EntityId = e.ObligorEntityId
	--country data
	LEFT JOIN FinancialRisks.Countries co on co.CountryId = e.CountryId
	--trade sector data
	LEFT JOIN FinancialRisks.TradeSector ts on ts.TradeSectorID = en.TradeSectorId

	WHERE ((e.InceptionDate >= tr.InceptionDate AND e.InceptionDate <= tr.ExpiryDate) OR c.Name = 'LIB')
	AND e.RiskCode in ('CF','CR', 'SB', 'SU', 'FG')
	and e.CedantId not in (178,181,182,183,184,186,191,213,214,368,370,371,459,588,589,590,646,648,649,690,745)
	AND en.EntityName != 'No capital IQ ID Assigned.'
	AND LEN(en.EntityName) > 1
	AND (e.RiskReference IS NULL OR e.RiskReference <> '584110/01/18')
	and e.InforceDate  = @inforcedate
	and e.Source = 'PTC'
) innerQuery
/**************************************************************************************************************************************/
DROP TABLE IF EXISTS #PecLossByExposure


SELECT
	   ExposureId,
	   ObligorEntityId,
	   EntityName,
	   CapitalIqId,
	   Region,
	   SPRating,
	   GCHPRating,
	   LibertyRating,
	   CedantName, 
	   ReportingClass,
	   ClassOfBusiness,
	   CobId,
	   CountryName,
	   ClassLGD,
	   SovereignRating,
	   TradeSectorName,
	   TradeSectorId,
	   InceptionDate,
	   ExpiryDate,
	   RateGroup,
	   --CASE WHEN CedantName = 'LIB' THEN NULL ELSE TreatyType END AS TreatyType,
	   TreatyType,
	   CurrencyName, 
       GrossExposure,
	--XL CALC
	CASE WHEN TreatyType = 'XL' THEN
		CASE WHEN GrossExposure > (Excess /Rate) THEN  
			 CASE WHEN (GrossExposure - Excess) > (TreatyLimit / Rate) THEN (TreatyLimit / Rate) * SignedLine ELSE (GrossExposure - (Excess / Rate) ) * SignedLine END
		ELSE 0 END
	--QS CALC
	WHEN TreatyType in ('QS', 'BA') THEN 
		CASE WHEN ISNULL(TreatyLimit / Rate,0) > 0 THEN
			CASE WHEN GrossExposure > (TreatyLimit / Rate) THEN (TreatyLimit / Rate) * SignedLine ELSE GrossExposure * SignedLine END
		ELSE GrossExposure * SignedLine END
	ELSE GrossExposure -- For LMIE and GFR that don't have treatys attached
	END AS LibertyExposure,
	InforceDate,TreatyLimit,Rate,Excess,SignedLine,OurShare,TreatyID,RiskReference,SystemTreatyId,assured,UploadDate
	--DROP TABLE IF EXISTS #LossByExposure

INTO #PecLossByExposure
FROM
(
	SELECT DISTINCT tr.NewReference as SystemTreatyId, e.ExposureId,
	c.Name as CedantName,cob.ReportingClass,e.RiskReference,e.InceptionDate,e.ExpiryDate, tr.Limit as TreatyLimit, ecr.Name AS CurrencyName, cr.RateGroup,
	 ttcr.Rate, e.CurrencyId, cob.CobId, cob.Name as ClassOfBusiness,
	 tr.AuditCode as TreatyType, tr.Excess, tr.SignedLine, tr.OurShare,
	CASE WHEN e.cobid NOT IN (1, 2, 5) THEN --COB IDs for GFR and PTC which allready have their Currencies FX rates applied
		CASE WHEN e.GrossExposure / ecr.Rate > ISNULL(e.Limit / ecr.Rate,0) AND ISNULL(e.Limit / ecr.Rate,0) > 0 
		THEN ISNULL(e.Limit / ecr.Rate,0) 
		ELSE e.GrossExposure / ecr.Rate END
	ELSE e.GrossExposure END AS GrossExposure, 
	 
	 case when en.EntityName like '%Ministry%' 
		  then case when  en.EntityName  like '%'+co.CountryName+'%'
					then en.EntityName
					else en.EntityName +' - ' + co.CountryName  
				END
		  else en.EntityName
		END as EntityName,
	 en.EntityId as ObligorEntityId,
	 co.CountryName,
	 co.Region,
	 ts.TradeSectorName,
	 ts.TradeSectorId,
	 cob.ClassLGD,
	 en.SPRating,
	 en.GCHPRating,
	 en.LibertyRating,
	 en.CapitalIqId,
	 co.SovereignRating,
	 e.InforceDate,TreatyID,assured,UploadDate
	FROM FinancialRisks.Exposures e
	--cedants
	LEFT JOIN FinancialRisks.Cedant c on c.CedantID = e.CedantId
	--exposure riskcode mappings
	LEFT JOIN FinancialRisks.RiskCodeMappings riskCodeMappings on riskCodeMappings.riskCode = e.RiskCode 
	--join treaties to exposures on cedant, risk code group and inforcedate
	LEFT JOIN FinancialRisks.Treaties tr on tr.CedantId = c.CedantID  and tr.InforceDate = e.InforceDate and riskCodeMappings.RiskCodeGroupId = tr.RiskCodeGroupId
	--exposure currency data
	LEFT JOIN FinancialRisks.Currencies cr on cr.CurrencyID = e.CurrencyID
	--2019 Currency Exchange Rates for Exposures
	LEFT JOIN #CurrencyFXRates ecr ON cr.CurrencyName = ecr.Name
	--treaties currency data
	LEFT JOIN FinancialRisks.Currencies tcr on tcr.CurrencyID = tr.CurrencyID
	--2019 Currency Exchange Rates for Treaties
	LEFT JOIN #CurrencyFXRates ttcr ON tcr.CurrencyName = ttcr.Name
	--reporting classes data
	LEFT JOIN FinancialRisks.COB cob on cob.CobId = e.CobId
	--obligor data
	LEFT JOIN FinancialRisks.Entities en on en.EntityId = e.ObligorEntityId
	--country data
	LEFT JOIN FinancialRisks.Countries co on co.CountryId = e.CountryId
	--trade sector data
	LEFT JOIN FinancialRisks.TradeSector ts on ts.TradeSectorID = en.TradeSectorId

	WHERE ((e.InceptionDate >= tr.InceptionDate AND e.InceptionDate <= tr.ExpiryDate) OR c.Name = 'LIB')
	AND e.RiskCode in ('CF','CR', 'SB', 'SU', 'FG')
	and e.CedantId not in (178,181,182,183,184,186,191,213,214,368,370,371,459,588,589,590,646,648,649,690,745)
	AND en.EntityName != 'No capital IQ ID Assigned.'
	AND LEN(en.EntityName) > 1
	AND (e.RiskReference IS NULL OR e.RiskReference <> '584110/01/18')
	and e.InforceDate  = @inforcedate
	and e.Source not in ('PTC','LMIE','GFR')
) innerQuery
/**************************************************************************************************************************************/

drop table if exists #GFR
select  ex.Source,	 	 
lbe.ExposureId,lbe.ObligorEntityId,
case when  op.ObligorPseudonym is null and lbe.ObligorEntityId in  (select distinct EntityId
						from FinancialRisks.Entities where EntityName like '%obligor name not supplied%' or EntityName = 'No obligor name supplied')
	 then op.ObligorPseudonym 
	 when op.ObligorPseudonym is null
	  then lbe.EntityName
else op.ObligorPseudonym end as 'Original Entity in file'
,lbe.EntityName,
--lbe.CapitalIqId,lbe.Region as 'Entity Region',lbe.SPRating,lbe.GCHPRating,lbe.LibertyRating,lbe.CedantName,'Direct Surety' as ReportingClass,'Direct Surety' as ClassOfBusiness,lbe.CobId,
lbe.CapitalIqId,lbe.Region as 'Entity Region',lbe.SPRating,lbe.GCHPRating,lbe.LibertyRating,lbe.CedantName,case when lbe.ReportingClass = 'LMIE Direct Surety' then 'Direct Surety' else lbe.ReportingClass end as ReportingClass,lbe.ClassOfBusiness,lbe.CobId,

case when  cp.CountryPseudonym is null and ex.countryid in  (select distinct countryid
						from FinancialRisks.Countries where CountryName like '%No country name supplied%' )
then cp.CountryPseudonym
	 when op.ObligorPseudonym is null
	  then lbe.CountryName
else cp.CountryPseudonym end as 'Original Country in file'
,lbe.CountryName,
lbe.ClassLGD,lbe.SovereignRating,lbe.TradeSectorName,lbe.TradeSectorId,lbe.InceptionDate,lbe.ExpiryDate,lbe.RateGroup,lbe.TreatyType,
lbe.CurrencyName,lbe.GrossExposure,lbe.LibertyExposure,lbe.InforceDate,lbe.TreatyLimit,lbe.Rate,lbe.Excess,lbe.SignedLine,lbe.OurShare,lbe.TreatyID,lbe.RiskReference
,ex.RiskCode,ex.SBU,ex.Office,ex.ProductLine,ex.NoBillingOffsetTotalSuretyExposureNetPGE,ex.NetSuretyExposure,case when ex.AssumedLive is Null then 'No' else ex.AssumedLive end as AssumedLive
,SystemTreatyId as 'TreatyReference',lbe.assured,lbe.UploadDate
into #GFR
from #GFRLossByExposure lbe
left join FinancialRisks.Exposures ex on  ex.ExposureId = lbe.ExposureId
left join FinancialRisks.ObligorPseudonym op on op.ObligorPseudonymId = ex.ObligorPseudID
left join FinancialRisks.CountryPseudonym cp on cp.CountryPseudonymId = ex.CountryPseudID

 where lbe.InforceDate = @inforcedate 

/**************************************************************************************************************************************/

drop table if exists #LMIE
select  ex.Source,	 	 
lbe.ExposureId,lbe.ObligorEntityId,
case when  op.ObligorPseudonym is null and lbe.ObligorEntityId in  (select distinct EntityId
						from FinancialRisks.Entities where EntityName like '%obligor name not supplied%' or EntityName = 'No obligor name supplied')
	 then op.ObligorPseudonym 
	 when op.ObligorPseudonym is null
	  then lbe.EntityName
else op.ObligorPseudonym end as 'Original Entity in file'
,lbe.EntityName,
--lbe.CapitalIqId,lbe.Region as 'Entity Region',lbe.SPRating,lbe.GCHPRating,lbe.LibertyRating,lbe.CedantName,'Direct Surety' as ReportingClass,'Direct Surety' as ClassOfBusiness,lbe.CobId,
lbe.CapitalIqId,lbe.Region as 'Entity Region',lbe.SPRating,lbe.GCHPRating,lbe.LibertyRating,lbe.CedantName,case when lbe.ReportingClass = 'LMIE Direct Surety' then 'Direct Surety' else lbe.ReportingClass end as ReportingClass,lbe.ClassOfBusiness,lbe.CobId,

case when  cp.CountryPseudonym is null and ex.countryid in  (select distinct countryid
						from FinancialRisks.Countries where CountryName like '%No country name supplied%' )
then cp.CountryPseudonym
	 when op.ObligorPseudonym is null
	  then lbe.CountryName
else cp.CountryPseudonym end as 'Original Country in file'
,lbe.CountryName,
lbe.ClassLGD,lbe.SovereignRating,lbe.TradeSectorName,lbe.TradeSectorId,lbe.InceptionDate,lbe.ExpiryDate,lbe.RateGroup,lbe.TreatyType,
lbe.CurrencyName,lbe.GrossExposure,lbe.LibertyExposure,lbe.InforceDate,lbe.TreatyLimit,lbe.Rate,lbe.Excess,lbe.SignedLine,lbe.OurShare,lbe.TreatyID,lbe.RiskReference
,ex.RiskCode,ex.SBU,ex.Office,ex.ProductLine,ex.NoBillingOffsetTotalSuretyExposureNetPGE,ex.NetSuretyExposure,case when ex.AssumedLive is Null then 'No' else ex.AssumedLive end as AssumedLive
,SystemTreatyId as 'TreatyReference',lbe.assured,lbe.UploadDate
into #LMIE
from #LMIELossByExposure lbe
left join FinancialRisks.Exposures ex on  ex.ExposureId = lbe.ExposureId
left join FinancialRisks.ObligorPseudonym op on op.ObligorPseudonymId = ex.ObligorPseudID
left join FinancialRisks.CountryPseudonym cp on cp.CountryPseudonymId = ex.CountryPseudID

 where lbe.InforceDate = @inforcedate 

/**************************************************************************************************************************************/
 drop table if exists #PTC
select  ex.Source,	 	 
lbe.ExposureId,lbe.ObligorEntityId,
case when  op.ObligorPseudonym is null and lbe.ObligorEntityId in  (select distinct EntityId
						from FinancialRisks.Entities where EntityName like '%obligor name not supplied%' or EntityName = 'No obligor name supplied')
	 then op.ObligorPseudonym 
	 when op.ObligorPseudonym is null
	  then lbe.EntityName
else op.ObligorPseudonym end as 'Original Entity in file'
,lbe.EntityName,
--lbe.CapitalIqId,lbe.Region as 'Entity Region',lbe.SPRating,lbe.GCHPRating,lbe.LibertyRating,lbe.CedantName,'Direct Surety' as ReportingClass,'Direct Surety' as ClassOfBusiness,lbe.CobId,
lbe.CapitalIqId,lbe.Region as 'Entity Region',lbe.SPRating,lbe.GCHPRating,lbe.LibertyRating,lbe.CedantName,lbe.ReportingClass,lbe.ClassOfBusiness,lbe.CobId,

case when  cp.CountryPseudonym is null and ex.countryid in  (select distinct countryid
						from FinancialRisks.Countries where CountryName like '%No country name supplied%' )
then cp.CountryPseudonym
	 when op.ObligorPseudonym is null
	  then lbe.CountryName
else cp.CountryPseudonym end as 'Original Country in file'
,lbe.CountryName,
lbe.ClassLGD,lbe.SovereignRating,lbe.TradeSectorName,lbe.TradeSectorId,lbe.InceptionDate,lbe.ExpiryDate,lbe.RateGroup,lbe.TreatyType,
lbe.CurrencyName,lbe.GrossExposure,lbe.LibertyExposure,lbe.InforceDate,lbe.TreatyLimit,lbe.Rate,lbe.Excess,lbe.SignedLine,lbe.OurShare,lbe.TreatyID,lbe.RiskReference
,ex.RiskCode,ex.SBU,ex.Office,ex.ProductLine,ex.NoBillingOffsetTotalSuretyExposureNetPGE,ex.NetSuretyExposure,case when ex.AssumedLive is Null then 'No' else ex.AssumedLive end as AssumedLive
,SystemTreatyId as 'TreatyReference',lbe.assured,lbe.UploadDate
into #PTC
from #PTCLossByExposure lbe
left join FinancialRisks.Exposures ex on  ex.ExposureId = lbe.ExposureId
left join FinancialRisks.ObligorPseudonym op on op.ObligorPseudonymId = ex.ObligorPseudID
left join FinancialRisks.CountryPseudonym cp on cp.CountryPseudonymId = ex.CountryPseudID

 where lbe.InforceDate = @inforcedate 

 /**************************************************************************************************************************************/
 drop table if exists #PecLines
select  ex.Source,	 	 
lbe.ExposureId,lbe.ObligorEntityId,
case when  op.ObligorPseudonym is null and lbe.ObligorEntityId in  (select distinct EntityId
						from FinancialRisks.Entities where EntityName like '%obligor name not supplied%' or EntityName = 'No obligor name supplied')
	 then op.ObligorPseudonym 
	 when op.ObligorPseudonym is null
	  then lbe.EntityName
else op.ObligorPseudonym end as 'Original Entity in file'
,lbe.EntityName,
--lbe.CapitalIqId,lbe.Region as 'Entity Region',lbe.SPRating,lbe.GCHPRating,lbe.LibertyRating,lbe.CedantName,'Direct Surety' as ReportingClass,'Direct Surety' as ClassOfBusiness,lbe.CobId,
lbe.CapitalIqId,lbe.Region as 'Entity Region',lbe.SPRating,lbe.GCHPRating,lbe.LibertyRating,lbe.CedantName,lbe.ReportingClass,lbe.ClassOfBusiness,lbe.CobId,

case when  cp.CountryPseudonym is null and ex.countryid in  (select distinct countryid
						from FinancialRisks.Countries where CountryName like '%No country name supplied%' )
then cp.CountryPseudonym
	 when op.ObligorPseudonym is null
	  then lbe.CountryName
else cp.CountryPseudonym end as 'Original Country in file'
,lbe.CountryName,
lbe.ClassLGD,lbe.SovereignRating,lbe.TradeSectorName,lbe.TradeSectorId,lbe.InceptionDate,lbe.ExpiryDate,lbe.RateGroup,lbe.TreatyType,
lbe.CurrencyName,lbe.GrossExposure,lbe.LibertyExposure,lbe.InforceDate,lbe.TreatyLimit,lbe.Rate,lbe.Excess,lbe.SignedLine,lbe.OurShare,lbe.TreatyID,lbe.RiskReference
,ex.RiskCode,ex.SBU,ex.Office,ex.ProductLine,ex.NoBillingOffsetTotalSuretyExposureNetPGE,ex.NetSuretyExposure,case when ex.AssumedLive is Null then 'No' else ex.AssumedLive end as AssumedLive
,SystemTreatyId as 'TreatyReference',lbe.assured,lbe.UploadDate
into #PecLines
from #PecLossByExposure lbe
left join FinancialRisks.Exposures ex on  ex.ExposureId = lbe.ExposureId
left join FinancialRisks.ObligorPseudonym op on op.ObligorPseudonymId = ex.ObligorPseudID
left join FinancialRisks.CountryPseudonym cp on cp.CountryPseudonymId = ex.CountryPseudID

 where lbe.InforceDate = @inforcedate 
 /************************************************************************************/

   drop table if exists #lbeCSM
  select * into #lbeCSM from (
SELECT * from #GFR
 union
   SELECT * from   #LMIE --where  ObligorEntityId = 1469
  union

  SELECT * from   #PTC --where  ObligorEntityId = 1469
  union
 SELECT * from #PecLines-- where  ObligorEntityId = 1469
 )a

/***********************************************************************************
Everything in the above section is to generate exposures.

The below section creates the CSM output
*/


 drop table if exists #UltimateTS
  drop table if exists #ClassAvgPD

SET NOCOUNT OFF

GO
DECLARE @inforcedate datetime
SET @inforcedate = @inforcedate;
WITH RCTE AS
       (
              SELECT  TradeSectorParentID, TradeSectorID, 1 AS Lvl
			  FROM FinancialRisks.TradeSector
                 WHERE TradeSectorParentID <> 0
              UNION ALL
              SELECT rh.TradeSectorParentID, rc.TradeSectorID, Lvl+1 AS Lvl 
              FROM FinancialRisks.TradeSector rh
              INNER JOIN RCTE rc ON rh.TradeSectorID = rc.TradeSectorParentID
                 WHERE rh.TradeSectorParentID <> 0
       )
       ,CTE_RN AS 
       (
              SELECT *, ROW_NUMBER() OVER (PARTITION BY r.TradeSectorID ORDER BY r.Lvl DESC) RN
              FROM RCTE r
       )

       SELECT c.TradeSectorID,ts2.TradeSectorName,c.TradeSectorParentID AS UltimateParentID,ts.TradeSectorName AS UltimateParentName INTO #UltimateTS FROM CTE_RN c
       INNER JOIN FinancialRisks.TradeSector ts ON ts.TradeSectorID = c.TradeSectorParentID
       INNER JOIN FinancialRisks.TradeSector ts2 ON ts2.TradeSectorID = c.TradeSectorID
       WHERE RN=1 

SELECT ClassOfBusinessID,
avg(CAST([1_Yr_PD] as float)) AS [1_Yr_Class_Avg],
avg(CAST([1_Yr_PD] AS float)) AS [2_Yr_Class_Avg],
avg(CAST([1_Yr_PD] AS float)) AS [3_Yr_Class_Avg],
avg(CAST([1_Yr_PD] AS float)) AS [4_Yr_Class_Avg],
avg(CAST([1_Yr_PD] AS float)) AS [5_Yr_Class_Avg],
avg(CAST([1_Yr_PD] AS float)) AS [6_Yr_Class_Avg],
avg(CAST([1_Yr_PD] AS float)) AS [7_Yr_Class_Avg],
avg(CAST([1_Yr_PD] AS float)) AS [8_Yr_Class_Avg],
avg(CAST([1_Yr_PD] AS float)) AS [9_Yr_Class_Avg],
avg(CAST([1_Yr_PD] AS float)) AS [10_Yr_Class_Avg]
INTO #ClassAvgPD
FROM
(
SELECT CASE WHEN CobId IN (1,2) THEN 8 ELSE CobId END AS ClassOfBusinessID, ISNULL(ISNULL(r.RatingType,s.RatingType),t.RatingType) AS FinalRating
from #lbeCSM lbe
LEFT JOIN FinancialRisks.Ratings r on r.RatingType = lbe.SPRating --and r.InforceDate=lbe.InforceDate
LEFT JOIN FinancialRisks.Ratings s on s.RatingType = lbe.GCHPRating-- and s.InforceDate=lbe.InforceDate
LEFT JOIN FinancialRisks.Ratings t on t.RatingType = lbe.LibertyRating --and t.InforceDate=lbe.InforceDate
LEFT JOIN FinancialRisks.RatingDefaultProbability pr ON pr.RatingID = r.RatingID-- and pr.InforceDate=lbe.InforceDate
LEFT JOIN FinancialRisks.RatingDefaultProbability pr2 ON pr2.RatingID = s.RatingID-- and pr2.InforceDate=lbe.InforceDate
LEFT JOIN FinancialRisks.RatingDefaultProbability pr3 ON pr3.RatingID = t.RatingID --and pr3.InforceDate=lbe.InforceDate
WHERE lbe.InforceDate = @inforcedate -- Date of refresh
) p
INNER JOIN FinancialRisks.Industry_PD_Matrix im ON im.Rating = p.FinalRating
WHERE im.IndustryNo = 0 AND FinalRating IS NOT NULL AND FinalRating <> 'NR' --and im.InforceDate = @InforceDate
GROUP BY ClassOfBusinessID
drop table if exists #CSMExtract
--By class
SELECT ObligorEntityID,ClassOfBusiness,CobId,EntityName,CapitalIQID,Region,TradeSectorID,Industry,FinalRating,ClassLGD,NetExposure,
[PD1],[PD2],[PD3],[PD4],[PD5],[PD6],[PD7],[PD8],[PD9],[PD10] 
INTO #CSMExtract
 FROM
(
SELECT ROW_NUMBER() OVER (PARTITION BY x.CobId,x.ObligorEntityID ORDER BY NetExposure DESC) AS Rnk,x.ObligorEntityID,x.ClassOfBusiness,x.CobID,x.EntityName,x.CapitalIQID, x.Region, im.TradeSectorID,im.Industry,x.FinalRating, x.ClassLGD, x.NetExposure,
ISNULL([1_Yr_PD],[1_Yr_Class_Avg]) AS [PD1],
ISNULL([2_Yr_PD],[2_Yr_Class_Avg]) AS [PD2],
ISNULL([3_Yr_PD],[3_Yr_Class_Avg]) AS [PD3],
ISNULL([4_Yr_PD],[4_Yr_Class_Avg]) AS [PD4],
ISNULL([5_Yr_PD],[5_Yr_Class_Avg]) AS [PD5],
ISNULL([6_Yr_PD],[6_Yr_Class_Avg]) AS [PD6],
ISNULL([7_Yr_PD],[7_Yr_Class_Avg]) AS [PD7],
ISNULL([8_Yr_PD],[8_Yr_Class_Avg]) AS [PD8],
ISNULL([9_Yr_PD],[9_Yr_Class_Avg]) AS [PD9],
ISNULL([10_Yr_PD],[10_Yr_Class_Avg]) AS [PD10]
FROM
(
SELECT ObligorEntityId, ClassOfBusiness, CobId, EntityName, CapitalIqId, [Entity Region] as Region,
ISNULL(ISNULL(uts.UltimateParentID,lbe.TradeSectorID),0) UltimateTradeSectorID, lbe.TradeSectorName,
ISNULL(ISNULL(r.RatingType,s.RatingType),t.RatingType) AS FinalRating,
lbe.ClassLGD,
SUM(lbe.LibertyExposure) as NetExposure
from #lbeCSM lbe
LEFT JOIN FinancialRisks.Ratings r on r.RatingType = lbe.SPRating --and r.InforceDate=lbe.InforceDate
LEFT JOIN FinancialRisks.Ratings s on s.RatingType = lbe.GCHPRating --and s.InforceDate=lbe.InforceDate
LEFT JOIN FinancialRisks.Ratings t on t.RatingType = lbe.LibertyRating --and t.InforceDate=lbe.InforceDate
LEFT JOIN FinancialRisks.RatingDefaultProbability pr ON pr.RatingID = r.RatingID --and pr.InforceDate=lbe.InforceDate
LEFT JOIN FinancialRisks.RatingDefaultProbability pr2 ON pr2.RatingID = s.RatingID --and pr2.InforceDate=lbe.InforceDate
LEFT JOIN FinancialRisks.RatingDefaultProbability pr3 ON pr3.RatingID = t.RatingID-- and pr3.InforceDate=lbe.InforceDate
LEFT JOIN #UltimateTS uts ON uts.TradeSectorID = lbe.TradeSectorID
WHERE lbe.InforceDate = @inforcedate
and lbe.LibertyExposure is not null
GROUP BY ObligorEntityID, ClassOfBusiness,cobId,EntityName,CapitalIQID,[Entity Region], ClassLGD,
lbe.TradeSectorID,uts.UltimateParentID,lbe.TradeSectorName,r.RatingType,s.RatingType,t.RatingType
HAVING SUM(lbe.LibertyExposure) > 0
) x
INNER JOIN #ClassAvgPD cpd ON cpd.ClassOfBusinessID = (CASE WHEN x.CobId IN (1,2) THEN 8 ELSE x.CobId END)
LEFT JOIN FinancialRisks.Industry_PD_Matrix im ON im.TradeSectorID = x.UltimateTradeSectorID AND im.Rating = x.FinalRating
) xx
WHERE Rnk = 1
ORDER BY EntityName

/***********************************************************************************
This ends the csm output section

Following r -run and import run the below 

*/

drop table if exists #CSMOUTPUT1

	
	SELECT ClassOfBusinessID,SimNo,SimPeriod,TreatyID,ExposureID,Limit,Excess,SignedLine,OurShare,ExpGR,LossGR,ExpNT,
			--XOL = APPLY XOL TERMS
			CASE WHEN TreatyType = 'XL' THEN
				CASE WHEN LossGR > Excess THEN
					CASE WHEN LossGR > (Limit + Excess) THEN Limit ELSE LossGR - Excess END
				ELSE 0 END
			--QS = LossGR UNLESS LIMIT IS PRESENT THEN APPLY LIMIT + QS TERMS
			WHEN TreatyType  in ('QS', 'BA') THEN
				CASE WHEN LossGR > Limit AND Limit > 0 THEN Limit ELSE LossGR END
				when TreatyID is null then ExpGR
			END 
			--APPLY LINE AND OURSHARE
			* SignedLine * OurShare AS LossNT
	into #CSMOUTPUT1
	FROM	(
		SELECT 
		lbe.CobId as ClassOfBusinessID
		,CSMO.DefaultSimNo as SimNo
		,CSMO.DefaultYear as SimPeriod
		,lbe.TreatyType
		,lbe.TreatyID
		,lbe.ExposureID
		,CSMO.SimLGD
		,ISNULL(lbe.TreatyLimit / lbe.Rate,0) AS Limit
		,ISNULL(lbe.Excess / lbe.Rate,0) AS Excess
		,isnull(lbe.SignedLine,1) as SignedLine
		,isnull(lbe.OurShare,1)as OurShare
		,sum(isnull(lbe.GrossExposure,0)) AS ExpGR
		,sum(csme.NetExposure) AS ExpNT
		,sum(isnull(lbe.GrossExposure,0) * CSMO.SimLGD) AS LossGR
		FROM #lbeCSM lbe
		inner join #CSMExtract CSME on csme.ObligorEntityId = lbe.ObligorEntityId and csme.CobId = lbe.CobId
		inner join FinancialRisks.CSM_Model_OutputV2 CSMO on CSMo.Entity = lbe.ObligorEntityId and CSMo.ClassID = lbe.CobId
		GROUP BY
		lbe.CobId 
		,CSMO.DefaultSimNo 
		,CSMO.DefaultYear
		,lbe.TreatyType
		,lbe.TreatyID
		,lbe.ExposureID
		,CSMO.SimLGD
		,ISNULL(lbe.TreatyLimit / lbe.Rate,0)
		,ISNULL(lbe.Excess / lbe.Rate,0) 
		,isnull(lbe.SignedLine,1) 
		,isnull(lbe.OurShare,1)

		)x

--FUll Curve
SELECT SimNo,SimPeriod,sum(LossNT) Loss 
FROM #CSMOUTPUT1 sr
GROUP BY SimNo,SimPeriod
--CURVEBYCOB

SELECT sr.ClassOfBusinessID,SimNo,SimPeriod,sum(LossNT) Loss --into #cobCurves 
FROM #CSMOUTPUT1 sr
GROUP BY sr.ClassOfBusinessID,SimNo,SimPeriod
--AAL By Cedant
Select 
sr.ClassOfBusinessID,
tr.NewReference as SystemTreatyID
,lbe.CedantName as CedantName
,sum(LossNT) / 25000 LossNT
,sum(CASE WHEN EntityName IN ('No capital IQ ID assigned.') THEN LossNT ELSE 0 END) / 25000 AS LossNT_Unmatched, 
sum(CASE WHEN (lbe.SPRating IS NULL OR lbe.SPRating = '') 
	AND (lbe.GCHPRating IS NULL OR lbe.GCHPRating = '') 
	AND (lbe.LibertyRating IS NULL OR lbe.LibertyRating = '') THEN LossNT ELSE 0 END) / 25000  as LossNT_NotRated
FROM #CSMOUTPUT1 sr
inner join FinancialRisks.Treaties tr on tr.TreatyID = sr.TreatyID
inner join #lbeCSM lbe on lbe.ExposureId = sr.ExposureId and sr.ClassOfBusinessID = lbe.CobId 
GROUP BY sr.ClassOfBusinessID,tr.NewReference
,lbe.CedantName