


-- 1. Utworzy? tabele tak? jaka jest ze skryptu zmieniaj?c nazwy kluczy i indeksow


CREATE TABLE [FinancialRisks].[Entities_test](
	[EntityId] [int] IDENTITY(1,1) NOT NULL,
	[EntityName] [varchar](255) NOT NULL,
	[ParentEntityName] [varchar](255) NULL,
	[CapitalIqId] [varchar](30) NULL,
	[ParentCapitalIqId] [varchar](30) NULL,
	[SPRating] [varchar](30) NULL,
	[GCHPRating] [varchar](30) NULL,
	[LibertyRating] [varchar](30) NULL,
	[TradeSectorId] [int] NULL,
	[ParentSPRating] [varchar](30) NULL,
	[ParentGCHPRating] [varchar](30) NULL,
	[ParentLibertyRating] [varchar](30) NULL,
	[Domicile] [varchar](100) NULL,
	[ParentDomicile] [varchar](100) NULL,
	[DefaultTradeSectorId] [int] NULL,
	[DefaultDomicile] [varchar](100) NULL,
	[DefaultRating] [varchar](30) NULL,
	[OverrideTradeSectorId] [int] NULL,
	[OverrideDomicile] [varchar](100) NULL,
	[OverrideRating] [varchar](30) NULL,
 CONSTRAINT [PK_ENTITY3] PRIMARY KEY CLUSTERED 
(
	[EntityId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [EntityName_Unique3] UNIQUE NONCLUSTERED 
(
	[EntityName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


-- 2. ustawi? 
 set Identity_Insert [FinancialRisks].[Entities_test] ON


 -- 3. Zaladowac dane
 insert into [FinancialRisks].[Entities_test] (EntityId, EntityName, ParentEntityName, CapitalIqId, ParentCapitalIqId, SPRating, GCHPRating, LibertyRating, TradeSectorId, ParentSPRating, ParentGCHPRating, ParentLibertyRating, Domicile, ParentDomicile, DefaultTradeSectorId, DefaultDomicile, DefaultRating, OverrideTradeSectorId, OverrideDomicile, OverrideRating)
 select EntityId, EntityName, ParentEntityName, CapitalIqId, ParentCapitalIqId, SPRating, GCHPRating, LibertyRating, TradeSectorId, ParentSPRating, ParentGCHPRating, ParentLibertyRating, Domicile, ParentDomicile, DefaultTradeSectorId, DefaultDomicile, DefaultRating, OverrideTradeSectorId, OverrideDomicile, OverrideRating
 from [FinancialRisks].[Entities_from_PROD_25_07_2022]

 -- 4. ustawic

   set Identity_Insert [FinancialRisks].[Entities_test] OFF

-- 5 Naprawic Identity
  DBCC CHECKIDENT ('[FinancialRisks].[Entities_test]')

  --6 Mozna wstawiac

  