select * from FinancialRisks.Countries


select t.name Table_Name,
        STUFF ((
            select ',' + c.name
            from sys.columns c
                join sys.tables tt on tt.object_id = t.object_id and t.object_id = c.object_id
                join sys.schemas s on tt.schema_id = s.schema_id
            order by t.name, c.column_id
            for xml path('')), 1, 1, '') as columns
from sys.tables t
            where t.name = 'Entities'