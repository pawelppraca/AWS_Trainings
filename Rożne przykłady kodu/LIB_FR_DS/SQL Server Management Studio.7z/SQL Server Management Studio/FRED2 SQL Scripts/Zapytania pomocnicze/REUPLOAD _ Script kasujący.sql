USE FRED

DECLARE @lastinforecedate datetime
SET @lastinforecedate = (Select distinct [LastRunTime] FROM [FinancialRisks].[AddNewData])

select @lastinforecedate lastinforecedate


/*
truncate table [FinancialRisks].[UnmappedCedants]
truncate table [FinancialRisks].[UnmappedCountries]
truncate table [FinancialRisks].[UnmappedObligors]

truncate table [FinancialRisks].[Ironshore_Data_Queue]
truncate table [FinancialRisks].[ExposuresQueue]
truncate table [FinancialRisks].[TreatiesQueue]
delete from FinancialRisks.Exposures where InforceDate = @lastinforecedate
delete from FinancialRisks.Treaties where InforceDate = @lastinforecedate
delete from FinancialRisks.Ironshore_Data where InforceDate = @lastinforecedate
*/

select distinct UploadDate  from FinancialRisks.Exposures where InforceDate = @lastinforecedate




declare @newinforecedate datetime
SET @newinforecedate = (select Max(InforceDate) from  FinancialRisks.Exposures)

select @newinforecedate newinforecedate

If @newinforecedate is null
Begin 
SET @newinforecedate =  (SELECT DATEADD(qq, DATEDIFF(qq, 0, @lastinforecedate) - 1, 0))
end

select @newinforecedate  newinforecedate

--UPDATE [FinancialRisks].[AddNewData]SET [LastRunTime] = @newinforecedate

--UPDATE [FinancialRisks].[AddNewData]SET AddNewData = 'True'

--UPDATE [FinancialRisks].[MappingsStatus]SET STATUS = 'WAITING'