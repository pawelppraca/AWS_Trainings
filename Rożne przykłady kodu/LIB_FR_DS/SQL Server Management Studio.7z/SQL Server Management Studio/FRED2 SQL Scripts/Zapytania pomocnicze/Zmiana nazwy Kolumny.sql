
--zmiana nazwy kolumny
EXEC sp_rename 'FinancialRisks.LossByExposure.Rate', 'TreatyRate', 'COLUMN';