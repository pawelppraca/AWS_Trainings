EXEC sp_help '[FinancialRisks].[ExposuresQueue]';


EXEC sp_help '[FinancialRisks].[uspCleanupExposureStaging]'