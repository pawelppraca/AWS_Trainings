SELECT top 100 * from  [FinancialRisks].[Exposures] order by exposureid desc

select count(*) from  [FinancialRisks].[Exposures]


SELECT top 100 * from  [FinancialRisks].[Treaties] order by exposureid desc

select count(*) from  [FinancialRisks].[ExposuresQueue]

select * from  [FinancialRisks].[ExposuresStaging]


select * from FinancialRisks.vw_ExposureOverview where CobId=3 and Year=2022

select * from FinancialRisks.vw_ExposureOverview where CobId=5 and Year=2022




select * from [FinancialRisks].[Cedant]
select * from [FinancialRisks].[Entities]

select top 100 * from [FinancialRisks].[Ironshore_Data] order by IronshoreDataId desc


select * from [FinancialRisks].[COB]


select * from FinancialRisks.Exposures where cobid = 3

