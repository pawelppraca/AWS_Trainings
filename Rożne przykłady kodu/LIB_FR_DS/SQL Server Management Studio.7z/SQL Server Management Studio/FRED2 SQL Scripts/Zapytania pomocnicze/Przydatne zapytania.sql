--Insert wielu warto?ci w jednym query

insert into FinancialRisks.test (name) values ('Pawel'), ('Monika'),('Ignacy'),('Mikolaj')


IF OBJECT_ID('tempdb..#Results') IS NOT NULL
    DROP TABLE #Results

	SELECT  PATINDEX('%Indonesia%', 'Ministry of Finance of Indonesia')
