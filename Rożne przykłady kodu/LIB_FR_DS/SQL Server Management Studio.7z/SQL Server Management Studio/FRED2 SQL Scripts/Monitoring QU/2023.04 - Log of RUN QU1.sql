--Start 

exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate] -- 26.04.2023 - 14:35 - end 17:34


--checking 
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_check_job_history] 'FRED_GenerateLossByExposure'


exec useradmin.[dbo].[usp_check_sql_agent_jobs]



select distinct [FinancialRisks].[fn_RemoveBadChar](countryname) Countryname_without_bad_char, countryname
from FinancialRisks.ExposuresQueue where [FinancialRisks].[fn_RemoveBadChar](countryname)<>countryname


select 'Table [Ironshore_Data_Queue]' Table_name, count(*) records from  [FinancialRisks].[Ironshore_Data_Queue]
select 'Table [ExposuresQueue]' Table_name, count(*) records from  [FinancialRisks].[ExposuresQueue]
select 'Table [TreatiesQueue]' Table_name, count(*) records from  [FinancialRisks].[TreatiesQueue]


select * from  [FinancialRisks].[Ironshore_Data_Queue]



select * from FinancialRisks.CountryPseudonym cp
join FinancialRisks.Countries c on c.countryid=cp.countryid
where cp.countrypseudonym in (
'Bulgaria, People`s Republic of',
'Congo, People`s Republic of',
'Cote D`Ivoire, Ivory Coast, Republic of the',
'Lao People`s Democratic Republic of'
)


select * from  FinancialRisks.Countries 
where countryname in (
'Bulgaria, Peoples Republic of',
'Congo, People`s Republic of',
'Cote D`Ivoire, Ivory Coast, Republic of the',
'Lao People`s Democratic Republic of'
)



SELECT CountryID, CountryName,CountryPseudonymId into #country from
(
	SELECT CountryId, CountryName,''as CountryPseudonymId
	FROM FinancialRisks.Countries
	UNION
	SELECT CountryId, CountryPseudonym AS CountryName,CountryPseudonymId
	FROM FinancialRisks.CountryPseudonym
)a

select *
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #country countries on countries.CountryName = eq.CountryName


select * from #country where CountryName like '%`%'



--28.04.2023 - Load Treaty Reassigment

exec useradmin.[dbo].[usp_start_FRED_CSMUpload]


exec useradmin.[dbo].[usp_check_job_history]  'FRED_CSMUpload'

exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_start_FRED_GenerateLossByExposure]

Potem zrobi? GENLBE



DECLARE @inforcedate DATETIME
SELECT @inforcedate = max(InforceDate)  from FinancialRisks.vw_ExposureOverview
SELECT @inforcedate
EXEC [FinancialRisks].[CommonShockModelExtract] @inforcedate
Select * from FinancialRisks.CSMOutput where Inforcedate = @inforcedate