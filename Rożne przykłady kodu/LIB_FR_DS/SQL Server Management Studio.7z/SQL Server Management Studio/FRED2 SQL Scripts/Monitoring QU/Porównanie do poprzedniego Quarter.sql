
select distinct InforceDate  from  FinancialRisks.vw_ExposureOverview order by InforceDate desc



--Lost by exposure Summary by COB and comparison to previous Quarter

select prev.ClassOfBusiness,prev.cobid,prev.LibertyExposure as LibertyExposure0701, ilv_current.LibertyExposure as LibertyExposure1001 ,
(ilv_current.LibertyExposure  - prev.LibertyExposure  ) diff
,((ilv_current.LibertyExposure  - prev.LibertyExposure  )   / prev.LibertyExposure ) * 100   Percentdiff
from (
	select [ReportingClass] , [ClassOfBusiness], cobid, SUM (LibertyExposure) LibertyExposure ,InforceDate
	from  FinancialRisks.vw_ExposureOverview
	where inforcedate in ('2022-07-01 00:00:00.000') -- previous Quarter change as required
	group by [ReportingClass] , [ClassOfBusiness], cobid, InforceDate
) prev
left join  (
	select [ReportingClass] , [ClassOfBusiness], cobid, SUM (LibertyExposure) LibertyExposure, InforceDate
	from  FinancialRisks.vw_ExposureOverview
	where inforcedate in ('2022-04-01 00:00:00.000') -- current Quarter change as required
	group by [ReportingClass] , [ClassOfBusiness], cobid, InforceDate 
) ilv_current on ilv_current.cobid = prev.CobId

