--Sprawdzenie dat


select [FinancialRisks].[fn_GetInforceDate]() InforceDate

SELECT * 
--update d set LastRunTime='20220906'

FROM [FinancialRisks].[AddNewData] d

select * from [FinancialRisks].asatdate

--Last Upload Date

select * from financialrisks.Exposures where inforcedate = (select distinct lastruntime from financialrisks.addnewdata)


--exec [dbo].[usp_enable_FRED_QuarterUpdate]

--exec [dbo].[usp_disable_FRED_QuarterUpdate]

exec useradmin.[dbo].[usp_start_FRED_QuarterUpdate]

exec useradmin.[dbo].[usp_check_sql_agent_jobs]

exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]


exec useradmin.[dbo].[usp_check_job_history] 'FRED_IdentifyMappings'

exec useradmin.[dbo].[usp_check_job_history] 'FRED_UpdateMappings'


select top 100 * from FRED.FinancialRisks.Exposures order by ExposureId


select * from FRED.FinancialRisks.ExposuresQueue 
select * from FRED.FinancialRisks.TreatiesQueue 


select * from FRED.[FinancialRisks].[MappingsStatus]

select * from FRED.[FinancialRisks].Mapping_Errors order by errorid desc

Violation of UNIQUE KEY constraint 'EntityName_Unique'. Cannot insert duplicate key in object 'FinancialRisks.Entities'. The duplicate key value is (KAEFER SE & Co. KG).

/*   */


 IF ((SELECT count(*)  FROM [FinancialRisks].[MappingsStatus] where[Status] = 'Generating')=0
	and (select count(*)FROM  [FinancialRisks].[MappingsStatus] where [Status]='Complete' ) = 0)
Select 'True' as Updated
ELSE 
Select 'False' Updated

select * from  [FinancialRisks].[MappingsStatus]


select * from FinancialRisks.UnmappedCountries

select * from FinancialRisks.CountryPseudonym where CountryPseudonym like 'ta%'
Ta�wan



exec useradmin.[dbo].[usp_start_FRED_CSMUpload]

exec useradmin.[dbo].[usp_check_job_history] 'FRED_CSMUpload'


exec useradmin.[dbo].[usp_start_FRED_GenerateLossByExposure]