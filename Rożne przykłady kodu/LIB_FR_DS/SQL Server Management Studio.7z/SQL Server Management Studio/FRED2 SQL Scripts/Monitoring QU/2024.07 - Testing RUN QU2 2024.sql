select *  FROM [FinancialRisks].[AddNewData]

select * from [FinancialRisks].[MappingsStatus]

--GET AsAt Date
SELECT * FROM FinancialRisks.AsAtDate

--GetInforceDate

	DECLARE @Quarter INT, @Year INT, @InforceDate DATETIME ,@LastInforceDate DATETIME

	Select @LastInforceDate = (SELECT distinct max([LastRunTime])FROM [FinancialRisks].[AddNewData])

	SET @Quarter = DATEPART(QUARTER, @LastInforceDate)
	SET @Year = DATEPART(YEAR, @LastInforceDate) 

	SELECT @InforceDate =  CASE @Quarter
		   WHEN 1 THEN CAST(CONCAT(@Year,'-4','-01') AS DATETIME)

		   WHEN 2 THEN CAST(CONCAT(@Year,'-7','-01') AS DATETIME)

		   WHEN 3 THEN CAST(CONCAT(@Year,'-10','-01') AS DATETIME)

		   WHEN 4 THEN CAST(CONCAT(@Year +1,'-1','-01') AS DATETIME)
		   END

	SELECT  @InforceDate



select * from FinancialRisks.ExposuresStaging

select * from FinancialRisks.ExposuresQueue

select distinct InforceDate from FinancialRisks.IronShore_Data order by InforceDate desc

--SELECT FinancialRisks.fn_GetInforceDate() AS InforceDate

select * from FinancialRisks.IronShore_Data WHERE InforceDate ='20240101'

exec UserAdmin.[dbo].[usp_start_FRED_job] 'FRED_QuarterUpdate'

exec UserAdmin.[dbo].[usp_check_agent_jobs_currently_running]



--IF Reupload = YES


DECLARE @lastinforecedate datetime
SET @lastinforecedate = (Select distinct [LastRunTime] FROM [FinancialRisks].[AddNewData])
select @lastinforecedate lastinforecedate

--truncate table [FinancialRisks].[UnmappedCedants]
--truncate table [FinancialRisks].[UnmappedCountries]
--truncate table [FinancialRisks].[UnmappedObligors]

--truncate table [FinancialRisks].[Ironshore_Data_Queue]
--truncate table [FinancialRisks].[ExposuresQueue]
--truncate table [FinancialRisks].[TreatiesQueue]
--delete from FinancialRisks.Exposures where InforceDate = @lastinforecedate
--delete from FinancialRisks.Treaties where InforceDate = @lastinforecedate
--delete from FinancialRisks.Ironshore_Data where InforceDate = @lastinforecedate

select * from FinancialRisks.Exposures where InforceDate = @lastinforecedate
select * from FinancialRisks.Treaties where InforceDate = @lastinforecedate
select *  from FinancialRisks.Ironshore_Data where InforceDate = @lastinforecedate


declare @newinforecedate datetime
SET @newinforecedate = (select Max(InforceDate) from  FinancialRisks.Exposures)

select @newinforecedate newinforecedate

If @newinforecedate is null
Begin 
SET @newinforecedate =  (SELECT DATEADD(qq, DATEDIFF(qq, 0, @lastinforecedate) - 1, 0))
end

select @newinforecedate

--UPDATE [FinancialRisks].[AddNewData] SET [LastRunTime] = @newinforecedate

--UPDATE [FinancialRisks].[AddNewData] SET AddNewData = 'True'

-- UPDATE [FinancialRisks].[MappingsStatus] SET STATUS = 'WAITING'


