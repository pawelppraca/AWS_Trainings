/*
Plan KT
1. Show the Manual with explanation and show all folders and commands
2. Show architecture of FRED 2 in PROD
a.	Server and Database
b.	Jobs
c.	SSIS Packages
d.	Folders with working files
e.	Power BI Report




*/
