--Start 

exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate] -- 5.06.2023 - 15:45 - end 17:34


--checking 
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_check_job_history] 'FRED_Currencies_Xrate' --FRED_GenerateLossByExposure'


exec useradmin.[dbo].[usp_check_sql_agent_jobs]


select count(*) from financialrisks.exposuresqueue

exec useradmin.[dbo].[usp_check_job_history] 'FRED_CSMUpload'
exec Useradmin.[dbo].[usp_start_FRED_CSMUpload]


exec useradmin.[dbo].[usp_start_FRED_GenerateLossByExposure]


select top 100 * from FinancialRisks.Entities


select * from FinancialRisks.TreatyReassignment where cedantname='AIG_LMIE_WTO' and treatyreference= '126395/01/22'


SELECT DISTINCT LastRunTime AS InforceDate FROM FinancialRisks.AddNewData 


select * from FinancialRisks.vw_ExposureOverview where UploadDate='2023-04-26 00:00:00.000'


select distinct UploadDate from FinancialRisks.lossbyexposure	order by UploadDate desc


select * from FinancialRisks.lossbyexposure where UploadDate='2023-04-26 00:00:00.000'



exec useradmin.[dbo].[usp_check_job_history] 'FRED_GenerateLossByExposure'

exec useradmin.[dbo].[usp_start_FRED_Currencies_Xrate]

exec useradmin.[dbo].[usp_start_FRED_GenerateLossByExposure]


--CSM Output

DECLARE @inforcedate DATETIME
SELECT @inforcedate = max(InforceDate)  from FinancialRisks.vw_ExposureOverview
SELECT @inforcedate
EXEC [FinancialRisks].[CommonShockModelExtract] @inforcedate
Select * from FinancialRisks.CSMOutput where Inforcedate = @inforcedate



exec Useradmin.[dbo].[usp_start_FRED_CSMUpload]


DECLARE @inforcedate DATETIME
SELECT @inforcedate = MAX(LastRunTime) FROM FinancialRisks.AddNewData 
select @inforcedate
SELECT * FROM [FinancialRisks].AALByCedant WHERE InforceDate = @inforcedate
SELECT * FROM [FinancialRisks].CurveByCOB WHERE InforceDate = @inforcedate
SELECT * FROM [FinancialRisks].fullCurve WHERE InforceDate = @inforcedate



--27.06.2023 - Re-Upload
--Start 

exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate] -- 27.06.2023 - 10:40 - duration: 1:30


--checking 
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]
exec useradmin.[dbo].[usp_check_job_history] 'FRED_GenerateLossByExposure'

exec Useradmin.[dbo].[usp_start_FRED_CSMUpload]


exec useradmin.[dbo].[usp_start_FRED_GenerateLossByExposure]




--13.07.2023 - Re-Upload
--Start 

exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate] -- 27.06.2023 - 10:40 - duration: 1:30

exec Useradmin.[dbo].[usp_start_FRED_CSMUpload]

exec useradmin.[dbo].[usp_start_FRED_GenerateLossByExposure]

--Loading R-Files
exec Useradmin.[dbo].[usp_start_FRED_CSMUpload]
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

--Extract from CSM

DECLARE @inforcedate DATETIME
SELECT @inforcedate = MAX(LastRunTime) FROM FinancialRisks.AddNewData
select @inforcedate
SELECT * FROM [FinancialRisks].AALByCedant WHERE InforceDate = @inforcedate
SELECT * FROM [FinancialRisks].CurveByCOB WHERE InforceDate = @inforcedate
SELECT * FROM [FinancialRisks].fullCurve WHERE InforceDate = @inforcedate