--Start 

exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate] -- 9.03.2023 - 11:47 - end 17:34


--checking 
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_check_job_history] 'FRED_GenerateLossByExposure'


exec useradmin.[dbo].[usp_check_sql_agent_jobs]



select * from FinancialRisks.ExposuresQueue


--13.03.2023
--exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate] 13.03.2023 - 09:04 UTC - end 10:33


--14.03.2023
--exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate] 14.03.2023 - 07:37 UTC - end


--Sprawdzanie  danych
select top 10 * from FinancialRisks.Exposures order by exposureid desc

select max(UploadDate) from FinancialRisks.Exposures


select top 10 * from FinancialRisks.ExposuresQueue order by exposureQueueid desc
select top 10 * from FinancialRisks.ExposuresStaging order by exposureQueueid desc



select distinct Source from FinancialRisks.ExposuresStaging

select top 100 * from  FinancialRisks.ExposuresStaging

--truncate table FinancialRisks.ExposuresStaging



select * from [FinancialRisks].[AddNewData]

select MAX(inforceDate) from financialRisks.Exposures�
select MAX(inforceDate) from financialRisks.Exposuresqueue


select count(*) from financialrisks.ExposuresStaging (nolock)



--14.03.2023
--exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate] 14.03.2023 - 11:32 UTC 



--checking 
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_check_job_history] 'FRED_QuarterUpdate'

--14.03.2023
--exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate] 14.03.2023 - 15:34 UTC 



--22.03.2023 - URcuhomienie po poprawce
--------------------------------------------------------


--exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate] 22.03.2023 - 10:37 UTC 


--checking 
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_check_job_history] 'FRED_QuarterUpdate'


exec useradmin.[dbo].[usp_check_job_history]  'FRED_IdentifyMappings'

exec useradmin.[dbo].[usp_check_job_history]  'FRED_UpdateMappings'

exec useradmin.[dbo].[usp_check_job_history]  'FRED_UpdateObligorMappings'

--23.03.2023
--Sprawdzenie dlaczego Kraje Canada, France, Japan are in UnmappedCountries - w komorkach z nazwami krajow byl blad (Byl znak Enter)

--22.03.2023 - URcuhomienie po poprawce Pliku
--------------------------------------------------------


--exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate] 24.03.2023 - 3:35 pm UTC - 4:57 pm UTC

select * from FinancialRisks.ExposuresQueue where isnumeric(CedantName)=0


--exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate] 6.04.2023 - 12:44 am UTC - pm UTC

select * from FinancialRisks.ExposuresQueue where isnumeric(CedantName)=0


select * from FinancialRisks.exposuresqueue


select distinct InforceDate  from FinancialRisks.vw_ExposureOverview order by InforceDate desc



--CSM Extract

DECLARE @inforcedate DATETIME
SET @InforceDate = (select distinct lastruntime from FinancialRisks.AddNewData)
SELECT @inforcedate
--EXEC [FinancialRisks].[CommonShockModelExtract] @inforcedate
Select * from FinancialRisks.CSMOutput where Inforcedate = @inforcedate


--All and GoodOnly CSM Extract should be done .... import R-Files






--13.04.2023 - URuchomienie 
--------------------------------------------------------


--exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate] 13.04.2023 - 2:43 pm UTC - 4:57 pm UTC

select * from FinancialRisks.ExposuresQueue where isnumeric(CedantName)=0
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_check_job_history] 'FRED_QuarterUpdate'


select * from financialrisks.exposuresqueue

--14.04.2023 - Load Treaty Reassigment

exec useradmin.[dbo].[usp_start_FRED_CSMUpload]

exec useradmin.[dbo].[usp_check_job_history]  'FRED_CSMUpload'

exec useradmin.[dbo].[usp_start_FRED_GenerateLossByExposure]



select distinct InforceDate from FinancialRisks.vw_ExposureOverview (nolock)


--20.4.2023 - Uruhcomienie CSM Upload 

exec useradmin.[dbo].[usp_start_FRED_CSMUpload]

exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_check_job_history]  'FRED_CSMUpload'



Potem zrobi? GENLBE




--Sprawdzenie generowanie danych po Imporcie plikow R

declare @InforceDate datetime
SELECT @InforceDate = max(LastRunTime)  FROM FinancialRisks.AddNewData 

select * from [FinancialRisks].AALByCedant where InforceDate = @inforcedate
select * from [FinancialRisks].CurveByCOB where InforceDate = @inforcedate
select * from [FinancialRisks].fullCurve where InforceDate = @inforcedate




select top 10 * from FinancialRisks.vw_ExposureOverview

select * from FinancialRisks.IronShore_data_Queue