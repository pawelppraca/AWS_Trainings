--Weryfikacja daty

	SELECT FinancialRisks.fn_GetInforceDate() AS InforceDate

	select * from [FinancialRisks].[AddNewData]

	Select distinct [LastRunTime] FROM [FinancialRisks].[AddNewData]

	select * from [FinancialRisks].AsAtDate

	select [FinancialRisks].[fn_GetAsAtDateDate]()






--Uruchomienie Quarter Update
exec useradmin.[dbo].[usp_start_FRED_QuarterUpdate]



exec useradmin.[dbo].[usp_check_sql_agent_jobs]




exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

--Identity Mappings
Aby zadzialalo wszystkie rekordy w MappingStatuses musz? mie? WAITING - aby wszystkie mialy to trzeba wrzucic puste pliki je?li nie ma mapowania

exec UserAdmin.[dbo].[usp_start_FRED_IdentifyMappings]

--Update Mappings
exec useradmin.[dbo].[usp_start_FRED_UpdateMappings]

--GenLBE

exec useradmin.[dbo].[usp_start_FRED_GenerateLossByExposure]


--Tu Upload ReassigmentFile
exec useradmin.[dbo].[usp_start_FRED_CSMUpload]


exec useradmin.[dbo].[usp_start_FRED_GenerateLossByExposure]

exec useradmin.[dbo].[usp_check_job_history] 'FRED_IdentifyMappings'

exec useradmin.[dbo].[usp_check_job_history] 'FRED_UpdateMappings'

select getdate()


--sprawdzenie historii
USE [UserAdmin]
GO
DECLARE @return_value int
EXEC    @return_value = [dbo].[usp_check_job_history]
        @JobName = N'FRED_GenerateLossByExposure'--FRED_IdentifyMappings
SELECT  'Return Value' = @return_value
GO



select top 100 * from FRED.FinancialRisks.Exposures order by ExposureId


select * from FRED.FinancialRisks.ExposuresQueue 
select * from FRED.FinancialRisks.TreatiesQueue 
select * from FRED.FinancialRisks.UnmappedObligors
select * from FRED.FinancialRisks.UnmappedCedants

select distinct UnmappedCedantName from FRED.FinancialRisks.UnmappedCedants


select * 
--update ms set status='WAITING'
from FRED.[FinancialRisks].[MappingsStatus] ms where MappingType='Entities'

select * from FRED.[FinancialRisks].Mapping_Errors order by errorid desc


--check if items are still in the queue and how many
select distinct obligorEntityName from FinancialRisks.ExposuresQueue eq 
--check the mapping status
select * from FinancialRisks.MappingsStatus
--check if there was any errors
select * from FinancialRisks.Mapping_Errors order by ErrorDateTime desc
--Check the file location \\vmbip-gsqldb14\FinancialRisk-Upload\Mappings\Input\Obligors to see if the file has been moved to archive or if the file still exists and the file is yet to be processed









	select max (Inforcedate) from FinancialRisks.CSMOutput

Select * from FinancialRisks.CSMOutput where Inforcedate = '2020-04-01T00:00:00.000'


/*   */


 IF ((SELECT count(*)  FROM [FinancialRisks].[MappingsStatus] where[Status] = 'Generating')=0
	and (select count(*)FROM  [FinancialRisks].[MappingsStatus] where [Status]='Complete' ) = 0)
Select 'True' as Updated
ELSE 
Select 'False' Updated



--CSM Extract

DECLARE @inforcedate DATETIME
	SELECT @inforcedate = FinancialRisks.fn_GetInforceDate() 
	SELECT @inforcedate

EXEC  [FinancialRisks].[CommonShockModelExtract] @inforcedate

Select * from FinancialRisks.CSMOutput where Inforcedate = @inforcedate


select max(InforceDate)  from [FinancialRisks].[CSM_Model_OutputV2]

select top 100 * from [FinancialRisks].[CSM_Model_OutputV2] where InforceDate='2022-07-01T00:00:00.000'

1 218 920 186


select count(*) from [FinancialRisks].Entities (nolock)






--Import Plikow R

exec Useradmin.[dbo].[usp_start_FRED_CSMUpload]

exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

--Po Imporcie Plik�w R


DECLARE @inforcedate DATETIME
	SELECT @inforcedate = max(InforceDate) from [FinancialRisks].AALByCedant
	SELECT @inforcedate


select * from [FinancialRisks].AALByCedant where InforceDate = @inforcedate
select * from [FinancialRisks].CurveByCOB where InforceDate = @inforcedate
select * from [FinancialRisks].fullCurve where InforceDate = @inforcedate


select max(InforceDate) from [FinancialRisks].AALByCedant
select max(InforceDate) from [FinancialRisks].CurveByCOB
select max(InforceDate) from [FinancialRisks].fullCurve





select max(inforcedate) from [FinancialRisks].CurveByCOB



