exec useradmin.[dbo].[usp_check_job_history] 'FRED_QuarterUpdate'
exec useradmin.[dbo].[usp_check_agent_job_steps] 'FRED_QuarterUpdate'

exec useradmin.[dbo].[usp_check_agent_jobs]

exec useradmin.[dbo].[usp_check_ssis_packages_currently_executing]
exec useradmin.[dbo].[usp_check_agent_jobs_currently_running]

use fred

select * from FinancialRisks.CountryPseudonym where CountryPseudonym in (
'Finlandia',
'Slovacchia, Repubblica',
'Stati Uniti d''America'

)


select * from FinancialRisks.ExposuresQueue where countryname in (
'Finlandia',
'Slovacchia, Repubblica',
'Stati Uniti d''America'

)



select * from FinancialRisks.Entities where EntityName in (

'5 FAB ENERGY INC',
'A L Schutzman Company, Inc. a/k/a Ashdon Farms',
'AMERICAN EXTRUSION COMP.',
'DARDEN DIRECT DISTRIBUTION, INC.',
'DUKE UNIVERSITY STORES CSC 230',
'FRUIT BASKET FLOWERLAND',
'HEWITTS GARDEN CENTERS INC',
'ILLINI UNION BOOKSTORE',
'INOTAL Alum�nium- �s Salakfeldolgoz� Z�rtk�ruen Muk�do R�szv�nyt�rsas�g',
'M. LAHART & COMPANY, LTD.',
'MAHONEYS TOO, CAPE COD & THE ISLANDS, INC',
'NOVEX PRODUCTS INC.',
'OAKLAND DESIGN & LANDSCAPE',
'READING FEED & GARDEN',
'SKILLINS GREENHOUSES',
'SPARTAN SPIRIT SHOP',
'UNIVERSITY STORE ON FIFTH'
)




select * 
--update en set CapitalIqId ltrim(rtrim(CapitalIqId)) ='' or ltrim(rtrim(ParentEntityName)) = '' or ltrim(rtrim(ParentCapitalIqId)) = ''
from FinancialRisks.Entities en where ltrim(rtrim(CapitalIqId)) ='' or ltrim(rtrim(ParentEntityName)) = '' or ltrim(rtrim(ParentCapitalIqId)) = ''


select count(*), uploaddate from FinancialRisks.Exposures where uploaddate >='20230101' group by uploaddate order by uploaddate desc


	SELECT    									
				DISTINCT    									
				ccyFrom.CurrencyCode  AS 'Name'	,								
				roe.ExchangeRate   AS 'rate',
				YEAR(roe.ExchangeRateDateKey) AS 'year'
	into #CurrencyFXRates2
	FROM    									
				[sources].[vw_dwhr_Currencies] ccyFrom   									
				INNER JOIN sources.vw_dwhr_ISOCurrencies ccyFromISO ON ccyFrom.ISOCurrencyKey = ccyFromISO.ISOCurrencyKey   									
				INNER JOIN sources.vw_dwhr_ExchangeRates roe ON ccyFromISO.ISOCurrencyKey = roe.ISOCurrencyFromKey   									
				INNER JOIN sources.vw_dwhr_ISOCurrencies ccyToISO ON roe.ISOCurrencyToKey = ccyToISO.ISOCurrencyKey   									
	WHERE    									
				ccyToISO.ISOCurrencyCode = N'USD'   									
				AND roe.ExchangeRateTypeCode = N'[GAAP Plan]'
				

select * from #CurrencyFXRates2 where year ='2024'


exec useradmin.dbo.usp_Start_FRED_job  'FRED_CSMUpload'