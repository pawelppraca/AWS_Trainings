select count(*) from [FinancialRisks].[UnmappedObligors_2022_07_21] uo
 left join [FinancialRisks].[Entities_PP_PROD] ep on ep.[EntityName] = uo.[EntityName]
 where ep.entityid is null


 select count(*) from [FinancialRisks].[UnmappedObligors_2022_07_21] uo
 left join [FinancialRisks].[Entities] ep on ep.[EntityName] = uo.[EntityName]
 where ep.entityid is null



--Sprawdzenie.

select 
into _pp_missing_between_Prod_and_excel  
from [FinancialRisks].[UnmappedObligors_2022_07_21] uo
 left join [FinancialRisks].[Entities_PP_PROD] ep on ep.[EntityName] = uo.[EntityName]
 where ep.entityid is null


 select count(*) from [FinancialRisks].[UnmappedObligors_2022_07_21] uo
 left join [FinancialRisks].[Entities] ep on ep.[EntityName] = uo.[EntityName]
 where ep.entityid is null




 select * from FinancialRisks.MappingsStatus


 select count(*) from [FinancialRisks].[Entities]  -- rekord�w przed update 12k 727529

 select count(*) from [FinancialRisks].[ObligorPseudonym]  -- rekord�w przed update 12k 421215
 select * from [FinancialRisks].[ObligorPseudonymsTemp] -- rekord�w przed update 12k 12367


  select top 10 * 
  --update e set Entityname='Kaefer Uab'
  from [FinancialRisks].[Entities] e where EntityName  like 'Kaegi Sarah Christine%'