USE FRED 

--Start UAT Quarter Update 1.11.2023
--Step 1  - Pre run checks


--Step 2
exec useradmin.dbo.usp_Start_FRED_job 'FRED_QuarterUpdate'

exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_check_job_history] 'FRED_QuarterUpdate'


--Optional
--If Job Fail on some step we can start processing from failed step
exec useradmin.dbo.usp_Start_FRED_job 'FRED_QuarterUpdate','LMIEDirectSurety'
exec useradmin.dbo.usp_Start_FRED_job 'FRED_QuarterUpdate','PecLines'

--Check queue
select * from FRED.FinancialRisks.ExposuresQueue

--Step 4 - Mapping
exec useradmin.dbo.usp_Start_FRED_job 'FRED_UpdateMappings'


--Step 6 - GenLBE
exec useradmin.dbo.usp_Start_FRED_job 'FRED_GenerateLossByExposure' -- About 6-7 min

exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_check_job_history] 'FRED_GenerateLossByExposure'


--Step 7 Treaty Reassigment

exec useradmin.dbo.usp_Start_FRED_job 'FRED_CSMUpload'
exec useradmin.[dbo].[usp_check_job_history] 'FRED_CSMUpload'


exec useradmin.dbo.usp_Start_FRED_job 'FRED_GenerateLossByExposure' -- About 6-7 min



select top 10 * from FinancialRisks.vw_ExposureOverview






--Step 10 All and Good Data - Script.sql

--Step 12 - CSM Upload R-Files and Extract

exec useradmin.dbo.usp_Start_FRED_job 'FRED_CSMUpload' -- About 6-7 min

exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

DECLARE @inforcedate DATETIME
SELECT @inforcedate = MAX(LastRunTime) FROM FinancialRisks.AddNewData 
select @inforcedate
SELECT * FROM [FinancialRisks].AALByCedant WHERE InforceDate = @inforcedate
SELECT * FROM [FinancialRisks].CurveByCOB WHERE InforceDate = @inforcedate
SELECT * FROM [FinancialRisks].fullCurve WHERE InforceDate = @inforcedate


--Step 13 - Refresh Power Bi