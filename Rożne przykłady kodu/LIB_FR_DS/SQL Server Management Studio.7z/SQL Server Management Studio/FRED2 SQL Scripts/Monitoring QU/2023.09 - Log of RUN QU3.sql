USE FRED 

--Start Quarter Update 12.09.2023

--Start Processing
exec useradmin.dbo.usp_Start_FRED_job 'FRED_QuarterUpdate' -- 12.09.2023 - 10:30
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]
exec useradmin.[dbo].[usp_check_job_history] 'FRED_QuarterUpdate'


exec useradmin.[dbo].[usp_check_job_history] 'FRED_QuarterUpdate'
exec useradmin.[dbo].[usp_check_job_history] 'FRED_QuarterUpdate'
exec useradmin.[dbo].[usp_check_agent_job_steps] 'FRED_QuarterUpdate'

exec useradmin.[dbo].[usp_check_agent_jobs]

exec useradmin.[dbo].[usp_check_ssis_packages_currently_executing]

exec useradmin.[dbo].[usp_check_agent_jobs]

exec useradmin.[dbo].[usp_check_ssis_packages_currently_executing]

exec useradmin.dbo.usp_Stop_FRED_job 'FRED_QuarterUpdate' -- 12.09.2023 - 10:30



--Optional
exec useradmin.dbo.usp_Start_FRED_job 'FRED_QuarterUpdate','LMIEDirectSurety'
exec useradmin.dbo.usp_Start_FRED_job 'FRED_QuarterUpdate','PecLines'






select * from [FinancialRisks].[Ironshore_Data_Queue]



exec useradmin.dbo.usp_Start_FRED_job 'FRED_GenerateLossByExposure' -- 14:16
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]
exec useradmin.[dbo].[usp_check_job_history] 'FRED_GenerateLossByExposure'


select distinct reportingclass
from [FinancialRisks].vw_ExposureOverview
where inforcedate = (select distinct LastRunTime from [FinancialRisks].AddNewData)


select distinct c.cobid, c.* 
from financialrisks.exposures ex
join financialrisks.cob c on c.cobid=ex.cobid
where inforcedate = (select distinct LastRunTime from [FinancialRisks].AddNewData)




select distinct source
from financialrisks.exposures
where inforcedate = (select distinct LastRunTime from [FinancialRisks].AddNewData)


select distinct inforcedate
from financialrisks.exposures order by inforcedate desc

select distinct uploaddate
from financialrisks.exposures order by uploaddate desc


select distinct c.cobid, c.* 
from financialrisks.exposures ex
join financialrisks.cob c on c.cobid=ex.cobid
where uploaddate = '2023-04-26T00:00:00.000'



select top 1000 *
from financialrisks.exposures ex
join [FinancialRisks].Entities en on en.entityid=ex.obligorEntityid 
where inforcedate = (select distinct LastRunTime from [FinancialRisks].AddNewData)
and entityname in (
'ALEGRE Domingo de las Rosas',
'BANCO DE SERVICIOS Y TRANSACCIONES S.A',
'BAUMEISTER CHODIMAN SOLANGE VALERIA',
'BONNET VICTOR HUGO',
'CABRAS ANZOATEGUI YANINA',
'CACERES ALBERTO',
'CARROCERIAS NAVARRO HNOS SA',
'CASTA�EDA SORIANO WLATER JESUS',
'CASTELLANO MIGUEL ANGEL',
'CHAVEZ SAYAGO DOUGLAS JOSE Y/O',
'CHINELATTO BATTEL MAURICIO GASTON',
'CIMA SOCIEDAD ANONIMA',
'CONSTRUCTORA EL GALPON S.R.L.',
'CONSULTORES DE EMPRESAS SRL',
'CONSULTORES DE EMPRESAS-DIVISION INDUSTRIAL S.R.L.',
'CP BROKER SRL ',
'CR CONSTRUCCIONES S.A.',
'D ONOFRIO RODOLFO',
'DECIDE SRL',
'DEHARBE GREGORIO'
)

and obligorid=3199959

select top 10 * from [FinancialRisks].vw_ExposureOverview


select * from [FinancialRisks].Entities where entityname='AIASSA LUIS EDUARDO'

select distinct source

from [FinancialRisks].vw_ExposureOverview
where 
reportingclass in ('FRRI Single Risk','FRRI Short Term Credit','FRRI Surety')
and inforcedate = '2023-01-01 00:00:00.000'


select * from [FinancialRisks].ExposuresStaging


--19.09.2023

exec useradmin.dbo.usp_Start_FRED_job 'FRED_GenerateLossByExposure' -- 8:15
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]
exec useradmin.[dbo].[usp_check_job_history] 'FRED_GenerateLossByExposure'


--Olivia Query
select CednatName,
sum(LibertyExposure) LibertyExposureUSD,
ClassOfBusiness
from [FinancialRisks].vw_ExposureOverview
where inforcedate = (select distinct LastRunTime from [FinancialRisks].AddNewData)
and reportingclass




exec [useradmin].[dbo].[usp_Start_FRED_job] 'FRED_QuarterUpdate' -- 19.09.2023 - 10:30
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]
exec useradmin.[dbo].[usp_check_job_history] 'FRED_QuarterUpdate'


select * from [FinancialRisks].Exposuresqueue

exec useradmin.dbo.usp_Start_FRED_job 'FRED_GenerateLossByExposure' 
exec useradmin.[dbo].[usp_check_job_history] 'FRED_GenerateLossByExposure'


---Reassigment

exec useradmin.dbo.usp_Start_FRED_job 'FRED_CSMUpload' 


 -- 21.09.2023 - 10:30
exec useradmin.dbo.usp_Start_FRED_job 'FRED_QuarterUpdate'
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]
exec useradmin.[dbo].[usp_check_job_history] 'FRED_QuarterUpdate'


--Check how many records stay in queue
declare @ExposuresQueue_Qty int, @Ironshore_Data_Queue_qty int, @TreatiesQueue_Qty int
select @ExposuresQueue_Qty = count(*) from FinancialRisks.ExposuresQueue
select @Ironshore_Data_Queue_qty = count(*) from [FinancialRisks].[Ironshore_Data_Queue]
select @TreatiesQueue_Qty = count(*) from [FinancialRisks].[TreatiesQueue]
select @ExposuresQueue_Qty ExposuresQueue_Qty, @Ironshore_Data_Queue_qty Ironshore_Data_Queue_qty, @TreatiesQueue_Qty TreatiesQueue_Qty


select * from  FinancialRisks.ExposuresQueue


--Issue with ParentEntityName is null (Sprawdzi? na DEV)

select * 
--into [ObligorPseudonymsTemp_20230921_issue]
from  [FinancialRisks].[ObligorPseudonymsTemp]
where ParentEntityName is null

exec [FinancialRisks].[uspUpdateMappings]


select i.EntityName  from [ObligorPseudonymsTemp_20230921_issue] i
left join  [FinancialRisks].Entities e on e.entityname = i.entityname
where e.entityid is null


 
DROP TABLE IF EXISTS #Obligors

select ObligorID, ltrim(rtrim(ObligorName)) as 'ObligorName',ObligorPseudonymId,CountryName 
into  #Obligors from
(
	SELECT EntityId as ObligorId, rtrim(ltrim(EntityName)) as ObligorName ,'' as ObligorPseudonymId,Domicile as 'CountryName'
	FROM FinancialRisks.Entities (nolock)
	UNION
	SELECT ObligorId, rtrim(ltrim(ObligorPseudonym)) as ObligorName,ObligorPseudonymId,''as 'CountryName'
	FROM FinancialRisks.ObligorPseudonym (nolock)
)b

select * from #Obligors where ObligorName in (
'W. SILVER RECYCLING, INC.',
'WELDFIT CORPORATION',
'WESTERN MIXERS INC',
'WILSON OIL INC',
'WRICLEY NUT PRODUCTS CO.'
)




exec useradmin.dbo.usp_Start_FRED_job 'FRED_UpdateMappings'
exec useradmin.[dbo].[usp_check_job_history] 'FRED_UpdateMappings'

exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

exec useradmin.dbo.usp_Start_FRED_job 'FRED_UpdateMappings'
select * from  [FinancialRisks].[ObligorPseudonymsTemp]

exec useradmin.dbo.usp_Start_FRED_job 'FRED_GenerateLossByExposure' 
exec useradmin.[dbo].[usp_check_job_history] 'FRED_GenerateLossByExposure'


---Reassigment

exec useradmin.dbo.usp_Start_FRED_job 'FRED_CSMUpload' 
exec useradmin.[dbo].[usp_check_agent_job_history] 'FRED_CSMUpload'

exec useradmin.dbo.usp_Start_FRED_job 'FRED_GenerateLossByExposure' 
exec useradmin.[dbo].[usp_check_agent_job_history] 'FRED_GenerateLossByExposure'

exec 

--Extract All and Good 
--Scrypt : All and Good CSM Data.sql


--CSM Upload R-Files

exec useradmin.dbo.usp_Start_FRED_job 'FRED_CSMUpload'
exec useradmin.[dbo].[usp_check_agent_jobs_currently_running]

--CSM Extract

DECLARE @inforcedate DATETIME
SELECT @inforcedate = MAX(LastRunTime) FROM FinancialRisks.AddNewData 
SELECT * FROM [FinancialRisks].AALByCedant WHERE InforceDate = @inforcedate
SELECT * FROM [FinancialRisks].CurveByCOB WHERE InforceDate = @inforcedate
SELECT * FROM [FinancialRisks].fullCurve WHERE InforceDate = @inforcedate




-- New Stored Procedures



