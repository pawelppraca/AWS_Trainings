select prev.ClassOfBusiness,prev.cobid,prev.LibertyExposure as LibertyExposure_20220101, ilv_current.LibertyExposure as LibertyExposure_20220401 ,
(ilv_current.LibertyExposure  - prev.LibertyExposure  ) diff
,((ilv_current.LibertyExposure  - prev.LibertyExposure  )   / prev.LibertyExposure ) * 100   Percentdiff
from
	(select [ReportingClass] , [ClassOfBusiness], cobid, SUM (LibertyExposure) LibertyExposure ,InforceDate
		from  FinancialRisks.vw_ExposureOverview
		where inforcedate in ('2022-01-01 00:00:00.000') -- previous Quarter change as required
		group by [ReportingClass] , [ClassOfBusiness], cobid, InforceDate) prev
left join  
	(
		select [ReportingClass] , [ClassOfBusiness], cobid, SUM (LibertyExposure) LibertyExposure , InforceDate
		from  FinancialRisks.vw_ExposureOverview
		   
where inforcedate in ('2022-04-01 00:00:00.000') -- current Quarter change as required
group by [ReportingClass] , [ClassOfBusiness], cobid, InforceDate ) ilv_current on ilv_current.cobid = prev.CobId



select prev.ClassOfBusiness,prev.cobid,prev.LibertyExposure as LibertyExposure_20220101, ilv_current.LibertyExposure as LibertyExposure_20220401 ,
(ilv_current.LibertyExposure  - prev.LibertyExposure  ) diff, 
((ilv_current.LibertyExposure  - prev.LibertyExposure  )   / prev.LibertyExposure ) * 100   Percentdiff
from
(
		select [ReportingClass] , [ClassOfBusiness], cobid, SUM (LibertyExposure) LibertyExposure ,InforceDate
		from  FinancialRisks.vw_ExposureOverview
		where inforcedate in ('2022-01-01 00:00:00.000') -- previous Quarter change as required
		group by [ReportingClass] , [ClassOfBusiness], cobid, InforceDate
) prev
left join  
	(
		select [ReportingClass] , [ClassOfBusiness], cobid, SUM (LibertyExposure) LibertyExposure , InforceDate
		from  FinancialRisks.vw_ExposureOverview
		where inforcedate in ('2022-04-01 00:00:00.000') -- current Quarter change as required
		group by [ReportingClass] , [ClassOfBusiness], cobid, InforceDate 
) ilv_current on ilv_current.cobid = prev.CobId
order by CobID




--select distinct InforceDate  from financialrisks.vw_exposureoverview order by InforceDate