USE FRED;
GO


DECLARE @MoveFROM DATETIME2,
		@MoveTo DATETIME2;

IF  @@SERVERNAME = 'VMBID-GSQLDB01' 
  BEGIN
		SET @MoveFROM = '2023-01-01 00:00:00.000'
		SET @MoveTo = '2022-10-01 00:00:00.000'
  END

  ELSE IF  @@SERVERNAME = 'VMBIT-GSQLDB01' 
  BEGIN

		SET @MoveFROM = '2023-01-01 00:00:00.000'
		SET @MoveTo = '2022-10-01 00:00:00.000'
  END

  ELSE IF  @@SERVERNAME = 'VMBIS-GSQLDB01' 
  BEGIN

		SET @MoveFROM = '2023-01-01 00:00:00.000'
		SET @MoveTo = '2022-10-01 00:00:00.000'
  END

--	ELSE IF  @@SERVERNAME = 'VMBIP-GSQLDB14' 
--	BEGIN

--		SET @MoveFROM = '2022-04-01 00:00:00.000'
--		SET @MoveTo = '2022-01-01 00:00:00.000'
--	END

BEGIN TRANSACTION [Trans1]

  BEGIN TRY
	IF @@SERVERNAME <> 'VMBIP-GSQLDB14' 
	BEGIN
			-- remove old  DATA FROM previous bad load
			DELETE FROM [FinancialRisks].[Exposures]
			WHERE InforceDate = @MoveFrom
		
			DELETE
			FROM [FinancialRisks].[Treaties]
			WHERE   InforceDate = @MoveFROM


			DELETE FROM FinancialRisks.Ironshore_Data 
			WHERE 
			InforceDate = @MoveFROM

  
			DELETE FROM FinancialRisks.Ironshore_Data_Queue 
			WHERE 
			InforceDate = @MoveFROM

			--UPDATE addNewdate
			UPDATE [FinancialRisks].[AddNewData]
			SET LastRunTime = @MoveTo

                COMMIT TRANSACTION [Trans1]

     END         

  END TRY

  BEGIN CATCH

                                ROLLBACK TRANSACTION [Trans1]

                  --THROW ERROR
                                                INSERT INTO [FinancialRisks].Mapping_Errors
                                VALUES
                                (SUSER_SNAME(),
                                ERROR_NUMBER(),
                                ERROR_STATE(),
                                ERROR_SEVERITY(),
                                ERROR_LINE(),
                                ERROR_PROCEDURE(),
                                ERROR_MESSAGE(),
                                GETDATE());
  END CATCH  

GO
