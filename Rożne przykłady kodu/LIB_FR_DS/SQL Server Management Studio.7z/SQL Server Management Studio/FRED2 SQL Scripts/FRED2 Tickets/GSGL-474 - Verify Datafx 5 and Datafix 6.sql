

--Verify Datafx 5

use FRED 
select *
from FinancialRisks.Countries c 



--TRIM RiskCode

select 'Exposures' [table] ,count(*)  
from [FinancialRisks].Exposures e where RiskCode <> ltrim(rtrim(riskcode))


--Test for rows with EmptyString in RiskCode
select *
from [FinancialRisks].Exposures e where (RiskCode <> ltrim(rtrim(RiskCode)) or  nullif(ltrim(rtrim(RiskCode)),'') is null) and ltrim(rtrim(RiskCode))=''





--Check if Country Pseudonym was fixed - shouldn't
select 'CountryPseudonym' [table] ,count(*)  
from [FinancialRisks].CountryPseudonym e where CountryPseudonym <> ltrim(rtrim(CountryPseudonym))


select 'Exposures' [table] ,count(*)  
from [FinancialRisks].Exposures e where ltrim(rtrim(riskcode)) =''



--Preparowanie danych doi tesu
select top 100 RiskCode , ltrim(rtrim(riskcode)),nullif(ltrim(rtrim(RiskCode)),''),len(RiskCode) , len(ltrim(rtrim(RiskCode))),* 
--update e set riskcode=''
from [FinancialRisks].Exposures e where RiskReference='583751/01/17' and exposureid in (2010059, 2010060)



select len(RiskCode) ,len(ltrim(rtrim(Riskcode))), datalength(Riskcode) ,
* 
from FinancialRisks.Exposures where RiskCode like '% %'

select * from FinancialRisks.Exposures where LeadSyndicate like '% %'

select * from FinancialRisks.Exposures where RiskReference like '% %'

select * from FinancialRisks.Exposures where datalength(RiskCode) <> datalength(ltrim(rtrim(Riskcode)))


select 'UAT' Environment,'Exposures with untrimmed RiskCode', count(*)
from [FinancialRisks].Exposures e where datalength(RiskCode) <> datalength(ltrim(rtrim(Riskcode)))

select 'UAT' Environment,'Exposures with untrimmed LeadSyndicate', count(*)
from [FinancialRisks].Exposures e where (datalength(LeadSyndicate) <> datalength(ltrim(rtrim(LeadSyndicate))) or nullif(ltrim(rtrim(LeadSyndicate)),'') is null ) and ltrim(rtrim(LeadSyndicate)) =''


select 'UAT' Environment,'Exposures with untrimmed RiskReference', count(*)
from [FinancialRisks].Exposures e where (datalength(RiskReference) <> datalength(ltrim(rtrim(RiskReference))) or nullif(ltrim(rtrim(RiskReference)),'') is null ) and ltrim(rtrim(RiskReference)) =''
