--GSGL-790 - SIT Tests

--check before

select top 100 ExposureRate,ExposureCurrency, TreatyRate, TreatyCurrency,Rate, CurrencyName, * from FinancialRisks.LossByExposure

select top 100 ExposureRate,ExposureCurrency, TreatyRate, TreatyCurrency,Rate, CurrencyName, * from FinancialRisks.vw_ExposureOverview


select max(InforceDate) LossByExposure_Max_inforceDate from FinancialRisks.LossByExposure
SELECT FinancialRisks.fn_GetInforceDate() AS InforceDate
	
--Setup 


--Test  - Generate LossBYExposure
exec [FinancialRisks].[GenerateLossByExposure]

--Checking InforceDate

select max(InforceDate) LossByExposure_Max_inforceDate from FinancialRisks.LossByExposure
SELECT FinancialRisks.fn_GetInforceDate() AS InforceDate


--Testing LossByExposure table

select top 1000 TreatyRate, TreatyCurrency, ExposureRate, ExposureCurrency,Rate, CurrencyName,* 
from [FinancialRisks].LossBYExposure 
where (TreatyRate <> ExposureRate or TreatyCurrency<>ExposureCurrency)
and InforceDate='20220401' --This is just to limit rows


--SIT Testing vw_ExposureOverView view

select top 1000 TreatyRate, TreatyCurrency, ExposureRate, ExposureCurrency,Rate, CurrencyName,* 
from [FinancialRisks].vw_ExposureOverview 
where (TreatyRate <> ExposureRate or TreatyCurrency<>ExposureCurrency)
and InforceDate='20220401' --This is just to limit rows

-- SIT test of CommonShockModelFinal

exec [FinancialRisks].[CommonShockModelFinal] '20220401'    --Czas pracy okolo 7:30 min


select count(*)from [FinancialRisks].CSMOutputR where Limit is null or Excess is null



 



select max(InforceDate)  from [FinancialRisks].[CSM_Model_OutputV2]

select top 10 *  from [FinancialRisks].[CSM_Model_OutputV2] order by SimulationID desc

select count(*) from [FinancialRisks].[CSM_Model_OutputV2]




select *
from INFORMATION_SCHEMA.COLUMNS
where TABLE_NAME='LossByExposure'


select name, create_date, modify_date
from sys.procedures
where name = 'GenerateLossByExposure'


select name, create_date, modify_date
from sys.views
where name = 'vw_ExposureOverview'


select name, create_date, modify_date
from sys.procedures
where name = 'CommonShockModelFinal'
