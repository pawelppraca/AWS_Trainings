USE [FRED]
GO

/****** Object:  View [FinancialRisks].[vw_ExposureOverview]    Script Date: 9/21/2022 11:57:14 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*********************************************/
Alter VIEW [FinancialRisks].[vw_ExposureOverview]
AS
SELECT EX.[ExposureId]
        ,lbe.CedantName
        ,lbe.[CobId]
        ,lbe.ReportingClass
        ,lbe.ClassOfBusiness
        ,lbe.ClassLGD
        ,lbe.SovereignRating
        ,EX.[RiskReference]
        ,EX.[CurrencyId]                                                AS 'Exposure_Currency_ID'
        ,lbe.ExposureCurrency												AS 'ExposureCurrency'   -- Column Renamed by PP GSGL-790
        ,lbe.RateGroup
        ,EX.[Year]
        ,EX.[DataQuarter]
        ,EX.[AssuredEntityId]
        ,EX.[RiskCode]
        ,EX.[LeadSyndicate]
        ,EX.[InceptionDate]                                             AS 'Exposure Inception Date'
        ,EX.[ExpiryDate]                                                AS 'Exposure Expiry Date'
        ,EX.[Limit]
        ,EX.[UsdLimit]
        ,EX.[GrossPremium]
        ,EX.GrossExposure                                               AS 'OriginalGrossExposure'
        ,lbe.[GrossExposure]
        ,lbe.LibertyExposure
        ,lbe.[ObligorEntityId]
        ,lbe.EntityName
        ,CASE
        WHEN op.ObligorPseudonym IS NULL
                AND lbe.ObligorEntityId IN (SELECT DISTINCT EntityId
                                            FROM   FinancialRisks.Entities
                                            WHERE  EntityName LIKE '%obligor name not supplied%'
                                                OR EntityName = 'No obligor name supplied') THEN op.ObligorPseudonym
        WHEN op.ObligorPseudonym IS NULL THEN lbe.EntityName
        ELSE op.ObligorPseudonym
        END                                                             AS 'Original Entity in File'
        ,lbe.CapitalIqId
        ,lbe.SPRating
        ,lbe.GCHPRating
        ,lbe.LibertyRating
        ,lbe.DefaultRating
        ,lbe.OverrideRating
        ,lbe.UltimateRating
        ,lbe.TradeSectorId
        ,lbe.DefaultTradeSectorId
        ,lbe.OverrideTradeSectorId
        ,lbe.UltimateTradeSectorId
        ,lbe.TopLevelTradeSectorID
        ,EX.[CountryId]
        ,lbe.CountryName
        ,CASE
        WHEN cp.CountryPseudonym IS NULL
                AND ex.CountryId IN (SELECT DISTINCT CountryId
                                    FROM   FinancialRisks.Countries
                                    WHERE  CountryName LIKE '%No country name supplied%') THEN cp.CountryPseudonym
        WHEN cp.CountryPseudonym IS NULL THEN lbe.CountryName
        ELSE cp.CountryPseudonym
        END                                                             AS 'Original Country in File'
        ,e.[Domicile]
        ,lbe.DefaultDomicile
        ,lbe.OverrideDomicile
        ,lbe.UltimateDomicile
        ,EX.[Region]                                                    AS 'Exposure Region'
        ,lbe.[Region]                                                   AS 'Entity Region' -- vchange order to group types of data
        ,lbe.TradeSectorName
        ,lbe.DefaultTradeSectorName
        ,lbe.OverrideTradeSectorName
        ,lbe.UltimateTradeSectorName
        ,lbe.TopLevelTradeSectorName
        ,EX.[ObligorPseudID]
        ,EX.[CountryPseudID]
        ,EX.[SBU]
        ,EX.[Office]
        ,CASE
        WHEN ex.AssumedLive IS NULL THEN 'No'
        ELSE ex.AssumedLive
        END                                                             AS AssumedLive
        ,EX.[ProductLine]
        ,EX.[NoBillingOffsetTotalSuretyExposureNetPGE]
        ,EX.[NetSuretyExposure]
        ,EX.[Assured]
        ,TR.[TreatyID]
        ,TR.[CedantId]
        ,TR.[NewReference]                                              AS 'TreatyReference'
        ,TR.[Year]                                                      AS 'TreatyYear'
        ,TR.[AuditCode]
        ,TR.[RiskCodeGroupId]
        ,TR.[RetroOnly]
        ,TR.[InceptionDate]                                             AS 'Treaty Inception Date'
        ,TR.[ExpiryDate]                                                AS 'Treaty Expiry Date'
        ,TR.[CurrencyId]
        ,TR.[Limit]                                                     AS 'TreatyLimit'
        ,TR.[Excess]
        ,TR.[OccDeductible]
        ,TR.[AggDeductible]
        ,TR.[NumReinstatements]
        ,TR.[ReinstatementAmount]
        ,TR.[SignedLine]
        ,TR.[OurShare]
        ,CASE
			WHEN lbe.TreatyRate IS NULL OR cast(lbe.TreatyRate as float) = 0 THEN 'NR'
			ELSE Cast(lbe.TreatyRate AS VARCHAR(25))
         END                                                            AS 'TreatyRate'   -- Column Renamed by PP GSGL-790
        ,TR.[ROL]
        ,TR.[CobId]                                                     AS 'TreatyCobiD'
        ,TR.[Paper]
        ,TR.[Source]													AS 'TreatySource'
        ,lbe.TreatyType
        ,EX.[InforceDate]
        ,EX.[Source]
        ,EX.[UploadDate]
        ,e.[ParentEntityName]
        ,e.[ParentCapitalIqId]
        ,e.[ParentSPRating]
        ,e.[ParentGCHPRating]
        ,e.[ParentLibertyRating]
        ,e.[ParentDomicile]
        ,EX.[LocalId]
		,lbe.ExposureRate      -- New Column added by PP GSGL-790
		,lbe.TreatyCurrency    -- New Column added by PP GSGL-790
FROM   FinancialRisks.LossByExposure lbe
        LEFT JOIN FinancialRisks.Exposures ex ON ex.ExposureId = lbe.ExposureId
        LEFT JOIN FinancialRisks.Entities e   ON e.EntityId = ex.ObligorEntityId
        LEFT JOIN FinancialRisks.Treaties tr   ON tr.TreatyID = lbe.TreatyID
        LEFT JOIN FinancialRisks.ObligorPseudonym op ON op.ObligorPseudonymId = ex.ObligorPseudID
        LEFT JOIN FinancialRisks.CountryPseudonym cp ON cp.CountryPseudonymId = ex.CountryPseudID
GO


