
--Zmianie ma podlega? procedura uspCleanupExposureStaging


select * from [FinancialRisks].[ExposuresQueue]
truncate table  [FinancialRisks].[ExposuresQueue]

select * from [FinancialRisks].[Exposures] where 

--przyk?ady
--drop table #Obligors

select ObligorID, ltrim(rtrim(ObligorName)) as 'ObligorName',ObligorPseudonymId,CountryName 
into  #Obligors from
(
	SELECT EntityId as ObligorId, rtrim(ltrim(EntityName)) as ObligorName ,'' as ObligorPseudonymId,Domicile as 'CountryName'
	FROM FinancialRisks.Entities
	UNION
	SELECT ObligorId, rtrim(ltrim(ObligorPseudonym)) as ObligorName,ObligorPseudonymId,''as 'CountryName'
	FROM FinancialRisks.ObligorPseudonym
)b


select * from #Obligors where ObligorName like '%EVGA%'


select * from #Obligors where ObligorName like 'TRAFIGURA %'


select distinct Source,UploadDate from [FinancialRisks].[Exposures] where ObligorEntityId=3157074 order by UploadDate desc

--DEV TEST

exec useradmin.[dbo].[usp_start_FRED_QuarterUpdate]

exec UserAdmin.[dbo].[usp_check_server_agent_jobs_currently_running]

select count(*) ExposuresQueue_Qty from FinancialRisks.ExposuresQueue (nolock)
select count(*) Ironshore_Data_Queue_qty from [FinancialRisks].[Ironshore_Data_Queue] (nolock)
select count(*) TreatiesQueue_Qty from [FinancialRisks].[TreatiesQueue] (nolock)


2022-08-04 00:00:00.000

Data_Atradius_QS_Credit_PriCCY.xlsx

select c.countryname,* from [FinancialRisks].[ExposuresQueue] eq
left join [FinancialRisks].Countries c on c.countryid=eq.countryName
where ObligorEntityName like 'EVGA %'



select * from #Obligors where ObligorName like '%EVGA%'
select * from FinancialRisks.Entities where entityname like '%EVGA%'

--update data from PROD
--insert into FinancialRisks.Entities (EntityName, ParentEntityName, CapitalIqId, ParentCapitalIqId, SPRating, GCHPRating, LibertyRating, TradeSectorId, ParentSPRating, ParentGCHPRating, ParentLibertyRating, Domicile, ParentDomicile, DefaultTradeSectorId, DefaultDomicile, DefaultRating, OverrideTradeSectorId, OverrideDomicile, OverrideRating)
select EntityName + ' [ Taiwan ]', ParentEntityName, CapitalIqId+'_', ParentCapitalIqId, SPRating, GCHPRating, LibertyRating, TradeSectorId, ParentSPRating, ParentGCHPRating, ParentLibertyRating, 'Taiwan', ParentDomicile, DefaultTradeSectorId, DefaultDomicile, DefaultRating, OverrideTradeSectorId, OverrideDomicile, OverrideRating 
from [FinancialRisks].[Entities_GSGL474_PROD] where EntityName like '%EVGA%'


select * from #Obligors where ObligorName like '%EVGA%'



select c.countryname,eq.*
FROM [FinancialRisks].[ExposuresQueue] eq
left join [FinancialRisks].Countries c on c.countryid=eq.countryName
WHERE [Status] = 'NEW'
and ObligorEntityName like 'EVGA %'



--Map those with valid IDS
select obligors.ObligorID, obligors.ObligorPseudonymId, obligors.*, eq.*
--UPDATE [FinancialRisks].[ExposuresQueue] set [ObligorEntityName] =obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
join [FinancialRisks].Countries c on c.countryid=eq.countryName
left JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName)) + ' [ '+c.CountryName + ' ] '
WHERE [Status] = 'NEW'
and ObligorEntityName like 'EVGA %'


--TRAFIGURA
USE FRED

--drop table #Obligors

select ObligorID, ltrim(rtrim(ObligorName)) as 'ObligorName',ObligorPseudonymId,CountryName 
into  #Obligors from
(
	SELECT EntityId as ObligorId, rtrim(ltrim(EntityName)) as ObligorName ,'' as ObligorPseudonymId,Domicile as 'CountryName'
	FROM FinancialRisks.Entities
	UNION
	SELECT ObligorId, rtrim(ltrim(ObligorPseudonym)) as ObligorName,ObligorPseudonymId,''as 'CountryName'
	FROM FinancialRisks.ObligorPseudonym
)b

select * from #Obligors where ObligorName like 'CAYMAN%'

select * from #Obligors where ObligorName like 'EVGA %'


select * from FinancialRisks.ObligorPseudonym where ObligorPseudonym  like 'TRAFIGURA%'


select Domicile, ParentDomicile,* from FinancialRisks.Entities where EntityName like 'TRAFIGURA%'



--Analiza klient�w
select count(*) from [FinancialRisks].[ExposuresQueue]

select distinct obligorentityname from [FinancialRisks].[ExposuresQueue] eq order by obligorentityname

select distinct obligorentityname from [FinancialRisks].[ExposuresQueue] eq where obligorentityname like '%coty%' order by obligorentityname

select  obligorentityname,*  from [FinancialRisks].[ExposuresQueue] eq where obligorentityname like '%amazon%' order by eq.obligorentityname

--Kopiowanie tabel z produkcji

-- Sufix tabeli: _PP_GSGL_1076

select  source, EntityName, Domicile, CountryName, uploaddate,* 
from [FinancialRisks].[Exposures_PP_GSGL_1076] ep
join [FinancialRisks].entities_PP_GSGL_1076 en on en.entityid=ep.obligorentityid
join [FinancialRisks].countries_PP_GSGL_1076 c on c.countryid=ep.countryid
where en.EntityName='Anheuser-Busch InBev SA/NV'
order by en.EntityName

select  distinct source, EntityName, Domicile, CountryName--, uploaddate
from [FinancialRisks].[Exposures_PP_GSGL_1076] ep
join [FinancialRisks].entities_PP_GSGL_1076 en on en.entityid=ep.obligorentityid
join [FinancialRisks].countries_PP_GSGL_1076 c on c.countryid=ep.countryid
where en.EntityName='Anheuser-Busch InBev SA/NV'
order by en.EntityName


--znajdowanie plik�w
select  distinct source, EntityName, Domicile, CountryName, uploaddate
from [FinancialRisks].[Exposures_PP_GSGL_1076] ep
join [FinancialRisks].entities_PP_GSGL_1076 en on en.entityid=ep.obligorentityid
join [FinancialRisks].countries_PP_GSGL_1076 c on c.countryid=ep.countryid
where en.EntityName='VINCI SA'
and source in (
'Data_Greenstarssec1_QS_LMIE_PriCCY.xlsx','Data_ZurichLMBLInternational_Surety_PriCCY.xlsx','Data_INSUR_PERU_QS_CR_PriCcy.xlsx','Data_HCCLMIE_PriCcy.xlsx','Data_GROUPAMA_XL_PriCCY.xlsx'
)
order by uploaddate desc




/*
Przyk?ady obligor�w

Advent International Corporation
AGCO International GmbH - Data_Markel_LMIE_PriCcy.xlsx 2022-05-06
CDW Corporation - Data_Markel_LMIE_PriCcy.xlsx 2022-05-06
Terex GB Limited - Data_Markel_LMIE_PriCcy.xlsx 2022-05-06
Triland Metals Limited - Data_Markel_LMIE_PriCcy.xlsx 2022-05-06

*/
--wyszukiwanie firm z r�znych kraj�w
select top 100 EntityName, count( distinct CountryName)
from [FinancialRisks].[Exposures_PP_GSGL_1076] ep (nolock)
join [FinancialRisks].entities_PP_GSGL_1076 en on en.entityid=ep.obligorentityid
join [FinancialRisks].countries_PP_GSGL_1076 c on c.countryid=ep.countryid
--where EntityName like '%/%'
group by EntityName
having count( distinct CountryName) > 1
order by count( distinct CountryName) desc --en.EntityName




select * FROM [FinancialRisks].[ExposuresQueue] eq WHERE [Status] = 'NEW' and ObligorEntityName like 'TRAFIGURA %'

--Map those with valid IDS
select obligors.ObligorID, obligors.ObligorPseudonymId, obligors.*, eq.*
--select *
--UPDATE [FinancialRisks].[ExposuresQueue] set [ObligorEntityName] =obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
join [FinancialRisks].Countries c on c.countryid=eq.countryName
left JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName)) + ' [ '+c.CountryName + ' ] '
WHERE [Status] = 'NEW'
and ObligorEntityName like 'Triland Metals Limited %'



select * from FinancialRisks.Exposures 


select * FROM [FinancialRisks].[ExposuresQueue] where obligorentityname like '%AGCO%'

select distinct source from [FinancialRisks].[ExposuresStaging]

select * from [FinancialRisks].[ExposuresStaging] where source ='Data_Markel_LMIE_PriCcy.xlsx' and obligorentityname like '%AGCO%'




--Map those with valid IDS
select obligors.ObligorID, obligors.ObligorPseudonymId, obligors.*, eq.*
--select *
--UPDATE [FinancialRisks].[ExposuresQueue] set [ObligorEntityName] =obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
--join [FinancialRisks].Countries c on c.countryid=eq.countryName
left JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName)) + ' [ '+eq.CountryName + ' ] '
WHERE [Status] = 'NEW'  
and ObligorEntityName like 'AGCO %'



--Map those with valid IDS
select obligors.ObligorID, obligors.ObligorPseudonymId, obligors.*, eq.*
--select *
--UPDATE [FinancialRisks].[ExposuresQueue] set [ObligorEntityName] =obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
--join [FinancialRisks].Countries c on c.countryid=eq.countryName
left JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName)) --+ ' [ '+eq.CountryName + ' ] '
WHERE [Status] = 'NEW'  
and ObligorEntityName like 'AGCO %'


select * from #Obligors where ObligorName like '%AGCO International Limited%'


select * from [FinancialRisks].ObligorPseudonym where ObligorPseudonym like '%AGCO International Limited%'
select * from [FinancialRisks].Entities where entityid=2929641

select replace(replace(ObligorPseudonym,' [ ','/'),' ]',''), * 
--update op set ObligorPseudonym = replace(replace(ObligorPseudonym,' [ ','/'),' ]','')
from [FinancialRisks].ObligorPseudonym op where ObligorPseudonym like '%AGCO International Limited%'

insert into [FinancialRisks].ObligorPseudonym (ObligorID,ObligorPseudonym) values (2929641,'AGCO International Limited [ Bulgaria ]')
insert into [FinancialRisks].ObligorPseudonym (ObligorID,ObligorPseudonym) values (2929641,'AGCO International Limited [ Lithuania ]')
insert into [FinancialRisks].ObligorPseudonym (ObligorID,ObligorPseudonym) values (2929641,'AGCO International Limited [ Austria ]')

--update 


-----------------------------------
--Terex GB Limited
------------------------------------

select * from #Obligors where ObligorName like '%Terex GB Limited%'

select * from [FinancialRisks].ObligorPseudonym where ObligorPseudonym like '%Terex GB Limited%'

select * FROM [FinancialRisks].[ExposuresQueue] where obligorentityname like '%Terex GB Limited%'

insert into [FinancialRisks].ObligorPseudonym (ObligorID,ObligorPseudonym) values (3062094,'Terex GB Limited/Germany')
insert into [FinancialRisks].ObligorPseudonym (ObligorID,ObligorPseudonym) values (3062094,'Terex GB Limited/Poland')
insert into [FinancialRisks].ObligorPseudonym (ObligorID,ObligorPseudonym) values (3062094,'Terex GB Limited/Belgium')


--drop table #Obligors

select ObligorID, ltrim(rtrim(ObligorName)) as 'ObligorName',ObligorPseudonymId,CountryName 
into  #Obligors from
(
	SELECT EntityId as ObligorId, rtrim(ltrim(EntityName)) as ObligorName ,'' as ObligorPseudonymId,Domicile as 'CountryName'
	FROM FinancialRisks.Entities
	UNION
	SELECT ObligorId, rtrim(ltrim(ObligorPseudonym)) as ObligorName,ObligorPseudonymId,''as 'CountryName'
	FROM FinancialRisks.ObligorPseudonym
)b




--Map those with valid IDS
select obligors.ObligorID, obligors.ObligorPseudonymId, obligors.*, eq.*
--select *
--UPDATE [FinancialRisks].[ExposuresQueue] set [ObligorEntityName] =obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
--join [FinancialRisks].Countries c on c.countryid=eq.countryName
left JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName)) + '/'+eq.CountryName 
WHERE [Status] = 'NEW'  
and ObligorEntityName like 'Terex %'
order by eq.Exposurequeueid


--Map those with valid IDS
select obligors.ObligorID, obligors.ObligorPseudonymId, obligors.*, eq.*
--select *
--UPDATE [FinancialRisks].[ExposuresQueue] set [ObligorEntityName] =obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
--join [FinancialRisks].Countries c on c.countryid=eq.countryName
left JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName)) --+ ' [ '+eq.CountryName + ' ] '
WHERE [Status] = 'NEW'  
and ObligorEntityName like 'Terex %'
order by eq.Exposurequeueid


-----------------------
--Anheuser-Busch InBev SA/NV
-----------------------


select * from #Obligors where ObligorName like '%Anheuser-Busch InBev%'

select * from [FinancialRisks].ObligorPseudonym where ObligorPseudonym like '%Anheuser-Busch InBev%'

select * FROM [FinancialRisks].[ExposuresQueue] where obligorentityname like '%Anheuser-Busch InBev%'


insert into [FinancialRisks].ObligorPseudonym (ObligorID,ObligorPseudonym) values (2905,'Anheuser-Busch InBev SA/NV/Brazil')
insert into [FinancialRisks].ObligorPseudonym (ObligorID,ObligorPseudonym) values (2905,'Anheuser-Busch InBev SA/NV/Belgium')

--Map those with valid IDS
select obligors.ObligorID, obligors.ObligorPseudonymId, obligors.*, eq.ObligorEntityName, eq.*
--select *
--UPDATE [FinancialRisks].[ExposuresQueue] set [ObligorEntityName] =obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
--join [FinancialRisks].Countries c on c.countryid=eq.countryName
left JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName)) + '/'+eq.CountryName 
WHERE [Status] = 'NEW'  
and ObligorEntityName like 'Anheuser-Busch InBev %'



--Map those with valid IDS
select obligors.ObligorID, obligors.ObligorPseudonymId, obligors.*, eq.ObligorEntityName, eq.*
--select *
--UPDATE [FinancialRisks].[ExposuresQueue] set [ObligorEntityName] =obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
--join [FinancialRisks].Countries c on c.countryid=eq.countryName
left JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName)) --+ ' [ '+eq.CountryName + ' ] '
WHERE [Status] = 'NEW'  
and ObligorEntityName like 'Anheuser-Busch InBev %'



--------------------------------------
-- Bunker Holding A/S
--------------------------------------



select * from #Obligors where ObligorName like '%Bunker Holding%'

select * from [FinancialRisks].ObligorPseudonym where ObligorPseudonym like '%Bunker Holding%'

select * FROM [FinancialRisks].[ExposuresQueue] where obligorentityname like '%Bunker Holding%'


insert into [FinancialRisks].ObligorPseudonym (ObligorID,ObligorPseudonym) values (9934,'Bunker Holding A/S/Denmark')
insert into [FinancialRisks].ObligorPseudonym (ObligorID,ObligorPseudonym) values (9934,'Bunker Holding/India')

--Map those with valid Country
select 'with country', obligors.ObligorID, obligors.ObligorPseudonymId, obligors.*, eq.*
FROM [FinancialRisks].[ExposuresQueue] eq
JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName)) + '/'+eq.CountryName 
WHERE [Status] = 'NEW'  
and ObligorEntityName like 'Bunker Holding%'

--Map those without valid country
select 'without country', obligors.ObligorID, obligors.ObligorPseudonymId, obligors.*, eq.*
FROM [FinancialRisks].[ExposuresQueue] eq
left JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
WHERE [Status] = 'NEW'  
and ObligorEntityName like 'Bunker Holding%'




--testing

--AGCO
--Map those with valid Country
select 'with country', obligors.ObligorID, obligors.ObligorPseudonymId, obligors.*, eq.*
FROM [FinancialRisks].[ExposuresQueue] eq
JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName)) + '/'+eq.CountryName 
WHERE [Status] = 'NEW'  
and ObligorEntityName like 'AGCO %'

--Map those without valid country
select 'without country', obligors.ObligorID, obligors.ObligorPseudonymId, obligors.*, eq.*
FROM [FinancialRisks].[ExposuresQueue] eq
left JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
WHERE [Status] = 'NEW'  
and ObligorEntityName like 'AGCO %'

--Terex
--Map those with valid Country
select 'with country', obligors.ObligorID, obligors.ObligorPseudonymId, obligors.*, eq.*
FROM [FinancialRisks].[ExposuresQueue] eq
JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName)) + '/'+eq.CountryName 
WHERE [Status] = 'NEW'  
and ObligorEntityName like 'Terex %'

--Map those without valid country
select 'without country', obligors.ObligorID, obligors.ObligorPseudonymId, obligors.*, eq.*
FROM [FinancialRisks].[ExposuresQueue] eq
left JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
WHERE [Status] = 'NEW'  
and ObligorEntityName like 'Terex %'

--Anheuser-Busch InBev
--Map those with valid Country
select 'with country', obligors.ObligorID, obligors.ObligorPseudonymId, obligors.*, eq.*
FROM [FinancialRisks].[ExposuresQueue] eq
JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName)) + '/'+eq.CountryName 
WHERE [Status] = 'NEW'  
and ObligorEntityName like 'Anheuser-Busch InBev %'

--Map those without valid country
select 'without country', obligors.ObligorID, obligors.ObligorPseudonymId, obligors.*, eq.*
FROM [FinancialRisks].[ExposuresQueue] eq
left JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
WHERE [Status] = 'NEW'  
and ObligorEntityName like 'Anheuser-Busch InBev %'




select * from [FinancialRisks].[ExposuresStaging] 
select * FROM [FinancialRisks].[ExposuresQueue] eq where  ObligorEntityName like 'CAYMAN%'



--Anheuser-Busch InBev
--Map those with valid Country
select 'with country', obligors.ObligorID, obligors.ObligorPseudonymId, obligors.*, eq.*
FROM [FinancialRisks].[ExposuresQueue] eq
join [FinancialRisks].Countries c on c.countryid=eq.countryName
JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName)) + '/'+c.CountryName 
WHERE [Status] = 'NEW'  
and ObligorEntityName like '%CAYMAN%'

--Map those without valid country
select 'without country', obligors.ObligorID, obligors.ObligorPseudonymId, obligors.*, eq.*
FROM [FinancialRisks].[ExposuresQueue] eq
left JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
WHERE [Status] = 'NEW'  
and ObligorEntityName like '%CAYMAN%'


exec [FinancialRisks].[uspCleanupExposureStaging] 3



select c.countryname,* 
from  [FinancialRisks].[ExposuresQueue] eq 
INNER JOIN [FinancialRisks].Countries c ON c.countryid=eq.countryName and ISNUMERIC(eq.countryName)=1
where  ObligorEntityName like '%CAYMAN%'

select eq.ObligorPseudID,* 
--UPDATE [FinancialRisks].[ExposuresQueue] SET [ObligorEntityName] = obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN [FinancialRisks].Countries c ON c.countryid=eq.countryName and ISNUMERIC(eq.countryName)=1
INNER JOIN #Obligors obligors ON obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName)) + '/' + c.CountryName 
WHERE [Status] = 'NEW'
AND [CobId] = 3
and ObligorEntityName like '%CAYMAN%'


select eq.ObligorPseudID,*
--UPDATE [FinancialRisks].[ExposuresQueue] SET [ObligorEntityName] =obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
 WHERE [Status] = 'NEW'
 AND [CobId] = 3
 and (ISNUMERIC([ObligorEntityName]) = 0  or  ISNUMERIC(ObligorPseudID) = 0)  --Not maped earlier
and ObligorEntityName like '%CAYMAN%'




select * from [FinancialRisks].[ExposuresStaging]