
--'Saras S.p.A.'
'McLaren Automotive Limited'
--,'Triland Metals Limited' 
--,'Total Marine Fuels - Singapore'
--,'Central National Sweden AB'
--,'Terex GB Limited'



--Before Import Files

USE FRED

select c.Countryname, en.entityname, count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'McLaren Automotive Limited%'
and ex.uploaddate='2022-05-06T00:00:00.000'
group by  c.Countryname, en.entityname,uploaddate
order by   en.entityname, c.Countryname

--OBLIGORS

DROP TABLE IF EXISTS #Obligors

select ObligorID, ltrim(rtrim(ObligorName)) as 'ObligorName',ObligorPseudonymId,CountryName 
into  #Obligors from
(
	SELECT EntityId as ObligorId, rtrim(ltrim(EntityName)) as ObligorName ,'' as ObligorPseudonymId,Domicile as 'CountryName'
	FROM FinancialRisks.Entities
	UNION
	SELECT ObligorId, rtrim(ltrim(ObligorPseudonym)) as ObligorName,ObligorPseudonymId,''as 'CountryName'
	FROM FinancialRisks.ObligorPseudonym
)b


select * from #Obligors where ObligorName like 'McLaren Automotive Limited%'

--Sprawdzenie warunk�w do wykonania Update Mappings
 SELECT * FROM [FinancialRisks].[MappingsStatus]

 IF ((SELECT count(*)  FROM [FinancialRisks].[MappingsStatus] where[Status] = 'Generating')=0
	and (select count(*)FROM  [FinancialRisks].[MappingsStatus] where [Status]='Complete' ) = 0)
Select 'True' as Updated
ELSE 
Select 'False' Updated

 SELECT * 
 --update ms set Status='Waiting'
 FROM [FinancialRisks].[MappingsStatus] ms



 --Update Mappings
 exec useradmin.[dbo].[usp_start_FRED_UpdateMappings]
  exec useradmin.[dbo].[usp_stop_FRED_UpdateMappings]

exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]





 DROP TABLE IF EXISTS #Obligors

select ObligorID, ltrim(rtrim(ObligorName)) as 'ObligorName',ObligorPseudonymId,CountryName 
into  #Obligors from
(
	SELECT EntityId as ObligorId, rtrim(ltrim(EntityName)) as ObligorName ,'' as ObligorPseudonymId,Domicile as 'CountryName'
	FROM FinancialRisks.Entities (nolock)
	UNION
	SELECT ObligorId, rtrim(ltrim(ObligorPseudonym)) as ObligorName,ObligorPseudonymId,''as 'CountryName'
	FROM FinancialRisks.ObligorPseudonym  (nolock)
)b


select * from #Obligors where ObligorName like 'McLaren Automotive Limited%'


--RUN UPLOAD
 exec useradmin.[dbo].[usp_start_FRED_QuarterUpdate]

 exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]



select c.Countryname, en.entityname, count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex (nolock)
join FinancialRisks.Entities en (nolock) on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c (nolock) on c.Countryid=ex.Countryid
where Entityname like 'McLaren Automotive Limited%'
and ex.uploaddate='2023-06-01T00:00:00.000'
group by  c.Countryname, en.entityname,uploaddate
order by   en.entityname, c.Countryname



USE fred
GO
SELECT [name], create_date, modify_date
FROM sys.procedures
where NAME in ('uspCleanupExposureStaging' , 'uspCleanupIronshoreQueue' ) ORDER BY 3 DESC;


select * from FinancialRisks.countries where countryname like '%Oman%'