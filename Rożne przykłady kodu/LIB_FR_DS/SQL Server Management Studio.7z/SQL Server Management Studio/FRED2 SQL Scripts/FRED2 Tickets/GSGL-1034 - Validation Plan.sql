USE fred
GO
SELECT [name], create_date, modify_date
FROM sys.procedures
where NAME in ('uspCleanupExposureStaging' , 'uspCleanupIronshoreQueue', 'uspMappingsCleanup' ) ORDER BY 3 DESC;
