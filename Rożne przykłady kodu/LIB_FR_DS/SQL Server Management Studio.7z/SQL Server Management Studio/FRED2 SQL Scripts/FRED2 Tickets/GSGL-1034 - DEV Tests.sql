/*
Testowanie 

*/


--truncate table FinancialRisks.ExposuresQueue

select * from FinancialRisks.ExposuresQueue

select distinct UploadDate  from FinancialRisks.Exposures order by UploadDate desc


select * from FinancialRisks.Exposures 
where UploadDate ='2023-03-17T00:00:00.000'
and LTRIM(RTRIM(RiskCode)) <> RiskCode




exec [FinancialRisks].[uspCleanupIronshoreQueue]




SELECT CountryID, CountryName,CountryPseudonymId into #country from
(
	SELECT CountryId, CountryName,''as CountryPseudonymId
	FROM FinancialRisks.Countries
	UNION
	SELECT CountryId, CountryPseudonym AS CountryName,CountryPseudonymId
	FROM FinancialRisks.CountryPseudonym
)a

select *
--UPDATE [FinancialRisks].[Ironshore_Data_Queue] set [countryId] =countries.CountryID ,CountryPseudID=countries.CountryPseudonymId
FROM [FinancialRisks].[Ironshore_Data_Queue] eq
INNER JOIN #country countries on countries.CountryName = [FinancialRisks].[fn_RemoveBadChar](eq.country)




select 
	case
		when Riskcode like ' %' then 'RiskCode Leading'
		when Riskcode like '% ' then 'RiskCode Trailing'
		when LeadSyndicate like ' %' then 'LeadSyndicate Leading'
		when LeadSyndicate like '% ' then 'LeadSyndicate Trailing'
		when RiskReference like ' %' then 'RiskReference Leading'
		when RiskReference like '% ' then 'RiskReference Trailing'
		
	end  issue
,* 
from FinancialRisks.Exposures where (Riskcode like ' %' or  Riskcode like '% ' or LeadSyndicate like ' %' or LeadSyndicate like '% ' or RiskReference like ' %' or RiskReference like '% ')
and datepart(year,UploadDate)=2023


select 
	case
		when Riskcode like ' %' then 'RiskCode Leading'
		when Riskcode like '% ' then 'RiskCode Trailing'
		when LeadSyndicate like ' %' then 'LeadSyndicate Leading'
		when LeadSyndicate like '% ' then 'LeadSyndicate Trailing'
		when RiskReference like ' %' then 'RiskReference Leading'
		when RiskReference like '% ' then 'RiskReference Trailing'
		
	end  issue
,* 
from FinancialRisks.ExposuresQueue where (Riskcode like ' %' or  Riskcode like '% ' or LeadSyndicate like ' %' or LeadSyndicate like '% ' or RiskReference like ' %' or RiskReference like '% ')





select 
	case
		when Riskcode like ' %' then 'RiskCode Leading'
		when Riskcode like '% ' then 'RiskCode Trailing'
		when LeadSyndicate like ' %' then 'LeadSyndicate Leading'
		when LeadSyndicate like '% ' then 'LeadSyndicate Trailing'
		when RiskReference like ' %' then 'RiskReference Leading'
		when RiskReference like '% ' then 'RiskReference Trailing'
	end  issue
,* 
from FinancialRisks.vw_ExposureOverview where (Riskcode like ' %' or  Riskcode like '% ' or LeadSyndicate like ' %' or LeadSyndicate like '% ' or RiskReference like ' %' or RiskReference like '% ' )
and datepart(year,UploadDate)=2023



select 

* 
from FinancialRisks.Ironshore_Data_Queue where (Riskcode like ' %' or  Riskcode like '% ' or LeadSyndicate like ' %' or LeadSyndicate like '% ' )
and datepart(year,UploadDate)=2023

--Testing after Update

select 
	case
		when Riskcode like ' %' then 'RiskCode Leading'
		when Riskcode like '% ' then 'RiskCode Trailing'

	end  issue,
	Riskcode,
* 
from FinancialRisks.Ironshore_Data 
where riskReference in ('051495E18A', '050419E18A','052984E18A')




select 
	case
		when Riskcode like ' %' then 'RiskCode Leading'
		when Riskcode like '% ' then 'RiskCode Trailing'
		when LeadSyndicate like ' %' then 'LeadSyndicate Leading'
		when LeadSyndicate like '% ' then 'LeadSyndicate Trailing'
	end  issue
,* 
from FinancialRisks.Exposures 
where --(Riskcode like ' %' or  Riskcode like '% ' or LeadSyndicate like ' %' or LeadSyndicate like '% ' )and 
datepart(year,UploadDate)=2023
and LeadSyndicate='Chubb Global Markets 2488'

