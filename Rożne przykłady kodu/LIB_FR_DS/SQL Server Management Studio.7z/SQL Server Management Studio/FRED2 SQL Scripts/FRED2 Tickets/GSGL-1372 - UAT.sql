
--UAT Tests




exec useradmin.dbo.usp_Start_FRED_job 'FRED_QuarterUpdate'


exec useradmin.[dbo].[usp_check_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_check_agent_job_history] 'FRED_QuarterUpdate'




USE FRED


select 'ExposuresQueue' [Table],  count(*) from FinancialRisks.ExposuresQueue where OriginalEntityinFile is not null 
select 'Ironshore_data' [Table], count(*) from FinancialRisks.Ironshore_data where OriginalEntityinFile is not null
select 'Exposures' [Table], count(*) from FinancialRisks.Exposures where OriginalEntityinFile is not null and UploadDate>='20231114'


exec useradmin.dbo.usp_Start_FRED_job 'FRED_GenerateLossByExposure'

exec useradmin.[dbo].[usp_check_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_check_agent_job_history] 'FRED_GenerateLossByExposure'




select top 1000  EntityName, [Original Entity in File], [Original Entity in File - Actual], [Original Entity in File - Derived],* 
from FinancialRisks.vw_ExposureOverview 
where [Original Entity in File - Actual] is not null and UploadDate>='20231116'
and EntityName <> [Original Entity in File]
and [Original Entity in File - Actual] <> [Original Entity in File - Derived]


--FULL Load on UAT

exec useradmin.dbo.usp_Start_FRED_job 'FRED_QuarterUpdate'

exec useradmin.[dbo].[usp_check_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_check_agent_job_history] 'FRED_QuarterUpdate'



--Before Restore DB

--Max ID of Obligors 
select max(entityid) from financialrisks.entities  -- UAT: 3300292 , PROD: 3428855, SIT: 3231929
select max(exposureid) from FinancialRisks.Exposures  -- UAT: 46786026, PROD: 55017501, SIT: 49362660


exec useradmin.[dbo].[usp_check_agent_job_history] 'SQLDBA - DatabaseBackup - USER_DATABASES - FULL'


--Restore DB
exec useradmin.[dbo].[usp_WhoIsActive]

exec useradmin.[dbo].[usp_start_Refresh_FRED_From_Latest_Production_Backup]
exec useradmin.[dbo].[usp_check_agent_job_history] 'Refresh FRED From Latest Production Backup'


--RestoreDB Complete

--After Restore
--Max ID of Obligors 
USE FRED
select max(entityid) from financialrisks.entities  -- UAT: 3428855 , PROD: 3428855, SIT: 3231929
select max(exposureid) from FinancialRisks.Exposures  -- UAT: 55017501, PROD: 55017501, SIT: 49362660



--PO RESTORE
--Redeploy zmian na DB - DONE
--Redeploy zmian na SSIS - DONE
--Uruchomi? Upload danych z ostatniego QU do bazy UAT po restore 

exec useradmin.dbo.usp_Start_FRED_job 'FRED_QuarterUpdate'

exec useradmin.[dbo].[usp_check_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_check_agent_job_history] 'FRED_QuarterUpdate'


select * from FinancialRisks.ExposuresQueue


--Fulfilled FXReates
exec useradmin.dbo.usp_Stop_FRED_job 'FRED_Currencies_Xrate_2'
exec useradmin.[dbo].[usp_check_agent_job_history] 'FRED_Currencies_Xrate_2'

exec useradmin.dbo.usp_Start_FRED_job 'FRED_GenerateLossByExposure'
exec useradmin.[dbo].[usp_check_agent_job_history]  'FRED_GenerateLossByExposure'


use fred

select
	ExposureId, ClassOfBusiness, RiskReference, OriginalGrossExposure, GrossExposure, LibertyExposure, ObligorEntityId, EntityName,
	[Original Entity in File], CountryName, ExposureCurrency, TreatyCurrency
from FinancialRisks.vw_ExposureOverview
where InforceDate = (select max(LastRunTime) From FinancialRisks.AddNewData)
and GrossExposure is null




select
	ExposureId, ClassOfBusiness, RiskReference, OriginalGrossExposure, GrossExposure, LibertyExposure, ObligorEntityId, EntityName,
	[Original Entity in File], [Original Entity in File - Actual], [Original Entity in File - Derived], CountryName
from FinancialRisks.vw_ExposureOverview
where InforceDate = (select max(LastRunTime) From FinancialRisks.AddNewData)
and [Original Entity in File] = 'MoF'


select
	ExposureId, ClassOfBusiness, RiskReference, OriginalGrossExposure, GrossExposure, LibertyExposure, ObligorEntityId, EntityName,
	[Original Entity in File], [Original Entity in File - Actual], [Original Entity in File - Derived], CountryName, UploadDate, Source
select distinct Source
from FinancialRisks.vw_ExposureOverview
where InforceDate = (select max(LastRunTime) From FinancialRisks.AddNewData)
and [Original Entity in File - Actual] is null --and [Original Entity in File - Derived] is not null



select * from FinancialRisks.Exposures 
where InforceDate = (select max(LastRunTime) From FinancialRisks.AddNewData)
and source='Data_IPP_EU_TOFI_PriCCY.xlsx'


exec useradmin.[dbo].[usp_check_agent_job_history]  'FRED_UpdateObligorMappings'



--Veryfying on PROD

--Fulfilled FXReates

--before
Use FRED 

select count(*) from [sources].[dwhr_Currencies_2]
select count(*) from [sources].[dwhr_ExchangeRates_2]
select count(*) from [sources].[dwhr_ISOCurrencies_2]



exec useradmin.dbo.usp_Start_FRED_job 'FRED_Currencies_Xrate_2'
exec useradmin.[dbo].[usp_check_agent_job_history] 'FRED_Currencies_Xrate_2'


USE fred
GO

--Stored Procedures
SELECT [name], create_date, modify_date
FROM sys.procedures
where NAME in  ('Merge_Currencies','Merge_ExchangeRates','Merge_ISOCurrencies','GenerateLossByExposure',
'uspCleanupExposureStaging','uspCleanupIronshoreQueue','uspUpdateCorrectionsMapPseudonym'
) ORDER BY 3 DESC;


--Views
SELECT [name], create_date, modify_date
FROM sys.views
where NAME in  ('vw_ExposureOverview','vw_dwhr_ISOCurrencies','vw_dwhr_ExchangeRates','vw_dwhr_Currencies') ORDER BY 3 DESC


--Tables

SELECT [name], create_date, modify_date
FROM sys.tables
where NAME in  (
'dwhr_Currencies_2',
'dwhr_Currencies_Staging',
'dwhr_Currencies_WORK',
'dwhr_ExchangeRates_2',
'dwhr_ExchangeRates_Staging',
'dwhr_ExchangeRates_WORK',
'dwhr_ISOCurrencies_2',
'dwhr_ISOCurrencies_Staging',
'dwhr_ISOCurrencies_WORK',
'ExposuresStaging','ExposuresQueue','Ironshore_Data_Queue','IronShore_Data','Exposures','LossByExposure','CountryPseudonymsTemp'
) ORDER BY 3 DESC;
