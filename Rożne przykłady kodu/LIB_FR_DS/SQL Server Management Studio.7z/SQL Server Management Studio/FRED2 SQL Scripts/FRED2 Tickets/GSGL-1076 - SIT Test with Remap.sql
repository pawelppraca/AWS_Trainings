USE FRED

--OBLIGORS

DROP TABLE IF EXISTS #Obligors

select ObligorID, ltrim(rtrim(ObligorName)) as 'ObligorName',ObligorPseudonymId,CountryName 
into  #Obligors from
(
	SELECT EntityId as ObligorId, rtrim(ltrim(EntityName)) as ObligorName ,'' as ObligorPseudonymId,Domicile as 'CountryName'
	FROM FinancialRisks.Entities
	UNION
	SELECT ObligorId, rtrim(ltrim(ObligorPseudonym)) as ObligorName,ObligorPseudonymId,''as 'CountryName'
	FROM FinancialRisks.ObligorPseudonym
)b


select * from #Obligors where ObligorName like 'McLaren Automotive Limited%'


select * from #Obligors o
join FinancialRisks.Entities en on en.entityid=o.obligorid
where o. ObligorName like 'VINCI%' order by ObligorName



select * from #Obligors o
join FinancialRisks.Entities en on en.entityid=o.obligorid
where ObligorName like 'McLaren Automotive Limited%'

select c.Countryname Exposure_Country, en.entityname, en.Domicile,  count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'McLaren Automotive Limited%'
--and ex.uploaddate >'2022-01-01T00:00:00.000'
and c.Countryname in ('Australia','Bahrain','Belgium')
group by  c.Countryname, en.entityname,uploaddate, en.Domicile
order by   en.entityname, c.Countryname



select '||', obligors.*, '|| Entities-->', e.entityid, e.entityname, e.Domicile, '|| Exposures-->', c.CountryName EX_Country,  ex.ObligorEntityId Ex_Obligor_id, ex.ObligorPseudID Ex_Obligor_Pseudonim
,ex.source EX_Source, ex.UploadDate
,ex.GrossPremium, ex.GrossExposure, Ex.InforceDate
FROM  [FinancialRisks].exposures ex
INNER JOIN [FinancialRisks].Countries c ON c.countryid = ex.CountryId 
INNER JOIN [FinancialRisks].Entities e on e.entityid=ex.ObligorEntityId
left JOIN #obligors obligors ON obligors.ObligorName = LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName
where e.entityname like 'McLaren%'
and c.countryName in ('Australia','Bahrain','Belgium')
--and c.countryName <> e.Domicile



  exec useradmin.dbo.usp_Start_FRED_job 'FRED_UpdateObligorMappings' 
  exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]



select * from FinancialRisks.Entities where entityname like 'Ministry of Defense%Oman%'
select * from FinancialRisks.Entities where entityname like 'Ministry of Defence%Oman%'
select * from FinancialRisks.Entities where entityid=2470551
select * from FinancialRisks.ObligorPseudonym where ObligorPseudonym like 'Ministry of Defense%Oman%'
select * from FinancialRisks.ObligorPseudonym where ObligorPseudonym like 'Ministry of Defence%Oman%'



select c.Countryname Exposure_Country, en.entityname, en.Domicile,  count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'Ministry of Defense%'
--and ex.uploaddate >='2023-10-24 00:00:00.000'
and c.Countryname in ('Oman')
group by  c.Countryname, en.entityname,uploaddate, en.Domicile
order by  uploaddate desc, en.entityname, c.Countryname


  exec useradmin.dbo.usp_Start_FRED_job 'FRED_UpdateObligorMappings' 




--Ministry of finance Angola

select * from FinancialRisks.Entities where entityname like 'Ministry %Angola' 

select 'ObligorPseudonym --> ', o.*,en.Domicile, en.ParentDomicile, 'Enitties --> ', en.*  
from FinancialRisks.ObligorPseudonym o
join FinancialRisks.Entities en on en.entityid=o.obligorid
where ObligorPseudonym like 'Ministry of finance%Angola'







select 'ObligorPseudonym --> ', o.*,en.Domicile, en.ParentDomicile, 'Enitties --> ', en.*  
from FinancialRisks.ObligorPseudonym o
join FinancialRisks.Entities en on en.entityid=o.obligorid
where ObligorPseudonym like 'vinci%'


