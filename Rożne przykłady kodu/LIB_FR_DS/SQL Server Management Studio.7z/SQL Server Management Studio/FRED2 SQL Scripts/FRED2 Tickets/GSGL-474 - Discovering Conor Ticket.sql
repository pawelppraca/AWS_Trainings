TICKET gsgl-474 - POM�C rozwi?za? Conorowi
Kraj wyci?gn?? z kolumny Exposure dla Poszczeg�lnych ministerstw
Testy po?czenia sprawdzi? na pojedynczych kraj�w
Nie mo?e by? MInisterstwa bez kraju po?czonogego z Konkretnym krajem\\


Mapowanie - [FinancialRisks].[uspUpdateMappings]



USE FRED
select op.*, e.* 
from financialrisks.Entities e
left join FinancialRisks.ObligorPseudonym op on entityid = obligorid
where LOWER(EntityName) like 'MINISTRY OF finance%'
and ObligorPseudonym like '%angola%'





select * from financialrisks.Entities where Domicile like '%Angola%' or ParentDomicile like '%angola%'

select * from financialrisks.Entities where LOWER(EntityName) like 'MINISTRY OF finance%' and LOWER(EntityName) like '%angola%'

select * from FinancialRisks.ObligorPseudonym where obligorid in (select entityid from financialrisks.Entities where LOWER(EntityName) like 'MINISTRY OF finance%' and LOWER(EntityName) like '%angola%')

--Exposure Countries
select * from financialrisks.Entities where entityname = domicile order by entityname

select * from financialrisks.Entities where LOWER(EntityName) like 'MINISTRY OF finance%' and LOWER(EntityName) like '%angola%'

select op.*, e.* from FinancialRisks.Entities e
left join FinancialRisks.ObligorPseudonym op on e.entityid = op.obligorid
where LOWER(EntityName) like 'MINISTRY OF finance%' and LOWER(EntityName) like '%angola%'



select top 1000 * from FinancialRisks.Exposures order by exposureid desc





where
(LOWER(EntityName) like 'MINISTRY OF finance%' ) and (
LOWER(EntityName) LIKE '%finance%' OR
LOWER(EntityName) LIKE '%defence%' OR
LOWER(EntityName) LIKE '%defense%' OR
LOWER(EntityName) LIKE '%national guard%' OR
LOWER(EntityName) LIKE '%economy%'
or
LOWER(ObligorPseudonym) LIKE '%finance%' OR
LOWER(ObligorPseudonym) LIKE '%defence%' OR
LOWER(ObligorPseudonym) LIKE '%defense%' OR
LOWER(ObligorPseudonym) LIKE '%national guard%' OR
LOWER(ObligorPseudonym) LIKE '%economy%'
)

Por�wna? dla pojedynczych krajow, testowc na pojedynczych krajow



select op.*, EntityId,EntityName	,	ParentEntityName	,	Domicile	,	ParentDomicile
 
from financialrisks.Entities_GSGL474_PROD e
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on entityid = obligorid
where LOWER(EntityName) like 'MINISTRY OF finance%'
and ObligorPseudonym like '%slovenia%'




--Example of angola - bledne

select FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) country,
op.*, EntityId,EntityName	,	ParentEntityName	,	Domicile	,	ParentDomicile, e.*
from financialrisks.Entities_GSGL474_PROD e
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on entityid = obligorid
where LOWER(EntityName) LIKE '%ministry%' and
(
	LOWER(EntityName) LIKE '%finance%' OR
	LOWER(EntityName) LIKE '%defence%' OR
	LOWER(EntityName) LIKE '%defense%' OR
	LOWER(EntityName) LIKE '%national guard%' OR
	LOWER(EntityName) LIKE '%economy%'

)

and (LOWER(EntityName) LIKE'%angola%' or LOWER(ObligorPseudonym) LIKE '%angola%')





--Example of Turkey - correct 

select 
FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) country
--lower(ltrim(rtrim(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(ObligorPseudonym,'ministry',''),'finance',''),'defence',''),'defense',''),'national guard',''),'finance',''),' of ',''),'-',''),',',''),')',''),'(',''),'&' ,''),' and ',''),'/',''),'MOF',''),'MOEF',''),'Economy',''),' the ',''),'the ','')))) country
,op.*, EntityId,EntityName	,	ParentEntityName	,	Domicile	,	ParentDomicile, e.*
from financialrisks.Entities_GSGL474_PROD e
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on entityid = obligorid
where LOWER(EntityName) LIKE '%ministry%' and
(
	LOWER(EntityName) LIKE '%finance%' OR
	LOWER(EntityName) LIKE '%defence%' OR
	LOWER(EntityName) LIKE '%defense%' OR
	LOWER(EntityName) LIKE '%national guard%' OR
	LOWER(EntityName) LIKE '%economy%'

)

and (LOWER(EntityName) LIKE'%turkey%' or LOWER(ObligorPseudonym) LIKE '%turkey%')



select 
--lower(ltrim(rtrim(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(ObligorPseudonym,'ministry',''),'finance',''),'defence',''),'defense',''),'national guard',''),'finance',''),' of ',''),'-',''),',',''),')',''),'(',''),'&' ,''),' and ',''),'/',''),'MOF',''),'MOEF',''),'Economy',''),' the ',''),'the ','')))) country
FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) country
,op.*, EntityId,EntityName	,	ParentEntityName	,	Domicile	,	ParentDomicile, e.*
from financialrisks.Entities_GSGL474_PROD e
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on entityid = obligorid
where LOWER(EntityName) LIKE '%ministry%' and
(
	LOWER(EntityName) LIKE '%finance%' OR
	LOWER(EntityName) LIKE '%defence%' OR
	LOWER(EntityName) LIKE '%defense%' OR
	LOWER(EntityName) LIKE '%national guard%' OR
	LOWER(EntityName) LIKE '%economy%'
	--or
	--LOWER(ObligorPseudonym) LIKE '%finance%' OR
	--LOWER(ObligorPseudonym) LIKE '%defence%' OR
	--LOWER(ObligorPseudonym) LIKE '%defense%' OR
	--LOWER(ObligorPseudonym) LIKE '%national guard%' OR
	--LOWER(ObligorPseudonym) LIKE '%economy%'
)
and op.obligorid=2919521 --Ecuador
--and (LOWER(EntityName) LIKE'%Aruba%' or LOWER(ObligorPseudonym) LIKE '%Aruba%')


--Wylistowanie ObligorID z r�?nymi Krajami

DROP TABLE IF EXISTS #pseudonym_obligors_multiple_countries

select 
count(distinct FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym)) countries
,op.obligorid
--,op.*, EntityId,EntityName	,	ParentEntityName	,	Domicile	,	ParentDomicile, e.*
--into #pseudonym_obligors_multiple_countries
from financialrisks.Entities_GSGL474_PROD e
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on entityid = obligorid
where LOWER(EntityName) LIKE '%ministry%' and
(
	LOWER(EntityName) LIKE '%finance%' OR
	LOWER(EntityName) LIKE '%defence%' OR
	LOWER(EntityName) LIKE '%defense%' OR
	LOWER(EntityName) LIKE '%national guard%' OR
	LOWER(EntityName) LIKE '%economy%'
)
group by op.obligorid
having count(distinct FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym)) >1
order by count(distinct FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym)) desc

select * from #pseudonym_obligors_multiple_countries

select 
FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) country
,op.*, EntityId,EntityName	,	ParentEntityName	,	Domicile	,	ParentDomicile, e.*
from financialrisks.Entities_GSGL474_PROD e
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on entityid = obligorid
join #pseudonym_obligors_multiple_countries mc on mc.obligorid = op.obligorid
where LOWER(EntityName) LIKE '%ministry%' and
(
	LOWER(EntityName) LIKE '%finance%' OR
	LOWER(EntityName) LIKE '%defence%' OR
	LOWER(EntityName) LIKE '%defense%' OR
	LOWER(EntityName) LIKE '%national guard%' OR
	LOWER(EntityName) LIKE '%economy%'
)
order by mc.countries




select 
FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) country,
op.*, EntityId,EntityName	,	ParentEntityName	,	Domicile	,	ParentDomicile, e.*
from financialrisks.Entities_GSGL474_PROD e
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on entityid = obligorid
where LOWER(EntityName) LIKE '%ministry%' and
(
	LOWER(EntityName) LIKE '%finance%' OR
	LOWER(EntityName) LIKE '%defence%' OR
	LOWER(EntityName) LIKE '%defense%' OR
	LOWER(EntityName) LIKE '%national guard%' OR
	LOWER(EntityName) LIKE '%economy%'

)
and (LOWER(EntityName) LIKE'%Pakistan%' or LOWER(ObligorPseudonym) LIKE '%Pakistan%')




select 
FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) country
,op.*, EntityId,EntityName	,	ParentEntityName	,	Domicile	,	ParentDomicile, e.*
from financialrisks.Entities_GSGL474_PROD e
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on entityid = obligorid
where LOWER(EntityName) LIKE '%ministry%' and
(
	LOWER(EntityName) LIKE '%finance%' OR
	LOWER(EntityName) LIKE '%defence%' OR
	LOWER(EntityName) LIKE '%defense%' OR
	LOWER(EntityName) LIKE '%national guard%' OR
	LOWER(EntityName) LIKE '%economy%'
)
and op.obligorid=5078


5078 --Cyprus, Cyprus, Pakistan
1228051
2919521

1909782
2105019
2105028
2105030
2152481
2361109




select top 100 FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) OP_country,c.Countryname, Domicile, ParentDomicile,
op.*, e.*, ex.* 
from FinancialRisks.Exposures ex
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on op.ObligorPseudonymId = ex.ObligorPseudID
left join FinancialRisks.Entities_GSGL474_PROD e on e.EntityId = op.ObligorID
left join FinancialRisks.Countries c on c.CountryId=ex.CountryId
where isnull(ex.ObligorPseudID,0)>0
and LOWER(EntityName) LIKE '%ministry%' and
(
	LOWER(EntityName) LIKE '%finance%' OR
	LOWER(EntityName) LIKE '%defence%' OR
	LOWER(EntityName) LIKE '%defense%' OR
	LOWER(EntityName) LIKE '%national guard%' OR
	LOWER(EntityName) LIKE '%economy%'
)  and FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) <> c.Countryname
