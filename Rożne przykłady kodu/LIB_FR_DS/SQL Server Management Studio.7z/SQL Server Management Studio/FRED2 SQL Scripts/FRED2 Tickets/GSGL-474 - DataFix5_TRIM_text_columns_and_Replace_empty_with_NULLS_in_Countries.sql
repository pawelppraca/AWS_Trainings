
--GSGL-474 - DATAFIX #5

--TRIM Text columns and set NULL if empty in Countries Table 

update c set
 CountryName = nullif(ltrim(rtrim(CountryName)),'')
,CountryCapitalIqId = nullif(ltrim(rtrim(CountryCapitalIqId)),'')
,ISOCountryName = nullif(ltrim(rtrim(ISOCountryName)),'')
,Alpha3Code = nullif(ltrim(rtrim(Alpha3Code)),'')
,ISO2Code = nullif(ltrim(rtrim(ISO2Code)),'')
,SovereignRating = nullif(ltrim(rtrim(SovereignRating)),'')
,CountryPseudonym = nullif(ltrim(rtrim(CountryPseudonym)),'')
,Region = nullif(ltrim(rtrim(Region)),'')

from FinancialRisks.Countries c 

