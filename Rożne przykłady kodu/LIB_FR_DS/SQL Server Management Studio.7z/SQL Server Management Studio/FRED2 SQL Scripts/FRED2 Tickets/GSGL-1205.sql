use fred


SELECT reference_id
 FROM SSISDB.[catalog].environment_references er
   JOIN SSISDB.[catalog].projects p ON p.project_id = er.project_id
 WHERE er.environment_name = 'DEV'
 AND p.name     = 'FRED';


--Testing Process
--1 Update
exec useradmin.dbo.usp_Start_FRED_job 'FRED_QuarterUpdate'
exec useradmin.[dbo].[usp_check_agent_job_history] 'FRED_QuarterUpdate'
exec useradmin.[dbo].[usp_check_job_steps]  'FRED_QuarterUpdate'
exec useradmin.[dbo].[usp_check_agent_jobs_currently_running]

--2 Update Mapping
exec useradmin.dbo.usp_Start_FRED_job 'FRED_UpdateMappings'
exec useradmin.[dbo].[usp_check_agent_job_history] 'FRED_UpdateMappings'

--3 GenLBE
 exec useradmin.dbo.usp_Start_FRED_job 'FRED_GenerateLossByExposure'
 exec useradmin.[dbo].[usp_check_agent_job_history]  'FRED_GenerateLossByExposure'
 exec useradmin.[dbo].[usp_check_agent_jobs_currently_running]


exec useradmin.dbo.usp_Start_FRED_job 'FRED_CSMUpload'
exec [FinancialRisks].[GenerateLossByExposure]

 exec useradmin.[dbo].[usp_check_agent_job_history]  'FRED_CSMUpload'



--checkin Connection and transfer data from AALab
select * from [sources].[dwhr_Currencies]
select * from [sources].[dwhr_ExchangeRates]
select * from [sources].[dwhr_ISOCurrencies]

 exec useradmin.dbo.usp_Start_FRED_job 'FRED_Currencies_Xrate'
  exec useradmin.[dbo].[usp_check_job_history] 'FRED_Currencies_Xrate'

  select count(*) from [mi].[FRED_GFR] where riskid='580785/01/09'





select top 1000 * from Financialrisks.Exposuresqueue

--truncate table Financialrisks.Exposuresqueue


SELECT *
--update adn set AddNewData='True'
  FROM [FinancialRisks].[AddNewData] adn



  select accountname, try_convert(varchar(200),accountname), [FinancialRisks].[fn_RemoveBadChar](accountname), 
  * from [dbo].[_imp_LMIE_2023_09_13_01] (nolock)
  where try_convert(varchar(200),accountname) is null


  select count(9) from Financialrisks.Exposuresqueue (nolock)


  select top 10 * from Financialrisks.Exposuresqueue (nolock) order by ExposureQueueId desc

  select * from FRED.FinancialRisks.ExposuresStaging



