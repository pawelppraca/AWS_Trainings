--test Po Imporcie przed zmiana - SIT

--wyczyszczenie tabel 
/*

TRUNCATE TABLE [FinancialRisks].[ExposuresStaging]
TRUNCATE TABLE [FinancialRisks].[Ironshore_Data_Queue]
TRUNCATE TABLE [FinancialRisks].[ExposuresQueue]
TRUNCATE TABLE [FinancialRisks].[TreatiesQueue]

*/

select *  FROM [FinancialRisks].[AddNewData]
SELECT AsAtDate
  FROM [FinancialRisks].[AsAtDate]


declare @InforceDate datetime
select @InforceDate = [FinancialRisks].[fn_GetInforceDate]()


select UploadDate,
	case
		when Riskcode like ' %' then 'RiskCode Leading'
		when Riskcode like '% ' then 'RiskCode Trailing'
		when LeadSyndicate like ' %' then 'LeadSyndicate Leading'
		when LeadSyndicate like '% ' then 'LeadSyndicate Trailing'
		when RiskReference like ' %' then 'RiskReference Leading'
		when RiskReference like '% ' then 'RiskReference Trailing'
		
	end  issue
	
,* 
--update e set Riskcode = LTRIM(RTRIM(Riskcode)), LeadSyndicate = LTRIM(RTRIM(LeadSyndicate)), RiskReference = LTRIM(RTRIM(RiskReference))
from FinancialRisks.Exposures e 
where 
(
	datalength(Riskcode) <> datalength(LTRIM(RTRIM(Riskcode))) 
	or datalength(LeadSyndicate) <> datalength(LTRIM(RTRIM(LeadSyndicate)))
	or datalength(RiskReference) <> datalength(LTRIM(RTRIM(RiskReference))) 
	)
and 
InforceDate=@InforceDate




select 
	case
		when Riskcode like ' %' then 'RiskCode Leading'
		when Riskcode like '% ' then 'RiskCode Trailing'
		when LeadSyndicate like ' %' then 'LeadSyndicate Leading'
		when LeadSyndicate like '% ' then 'LeadSyndicate Trailing'
		when RiskReference like ' %' then 'RiskReference Leading'
		when RiskReference like '% ' then 'RiskReference Trailing'
		
	end  issue
,* 
from FinancialRisks.ExposuresQueue where (Riskcode like ' %' or  Riskcode like '% ' or LeadSyndicate like ' %' or LeadSyndicate like '% ' or RiskReference like ' %' or RiskReference like '% ')



select 
	case
		when Riskcode like ' %' then 'RiskCode Leading'
		when Riskcode like '% ' then 'RiskCode Trailing'

	end  issue,
	Riskcode,
* 
--update id set Riskcode = LTRIM(RTRIM(Riskcode))
from FinancialRisks.Ironshore_Data id
where datalength(Riskcode) <> datalength(LTRIM(RTRIM(Riskcode))) 




select 

* 
from FinancialRisks.Ironshore_Data_Queue


