USE FRED

--RUN Quarter Update (UAT)


exec useradmin.dbo.usp_Start_FRED_job 'FRED_QuarterUpdate'
exec useradmin.[dbo].[usp_check_job_history] 'FRED_QuarterUpdate'
exec useradmin.[dbo].[usp_check_job_steps]  'FRED_QuarterUpdate'
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]


exec useradmin.dbo.usp_Start_FRED_job 'FRED_Currencies_Xrate'
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]
exec useradmin.[dbo].[usp_check_job_history] 'FRED_Currencies_Xrate'

select distinct uploaddate from [sources].[dwhr_Currencies]
select * from [sources].[dwhr_ExchangeRates]
select * from [sources].[dwhr_ISOCurrencies]



--Starting UAT Upload with 527 PecLinesFiles and Small LMIE

--4.09.2023 8:41
--AsAtDate 4.09.2023
exec useradmin.dbo.usp_Start_FRED_job 'FRED_QuarterUpdate'



FRED_CSMUpload  
FRED_Currencies_Xrate  - OK		
FRED_GenerateLossByExposure	- OK
FRED_GFRSource - OK
FRED_IdentifyMappings	- OK
FRED_QuarterUpdate	 - ........ LMIE Failed retest
FRED_UpdateMappings	- OK
FRED_UpdateObligorMappings	



exec useradmin.[dbo].[usp_check_job_history] 'FRED_GenerateLossByExposure'

  select count(*) from [mi].[FRED_GFR] 


use FRED

 select * from FinancialRisks.entities where entityname in (
'100 BISHOPSGATE S.� R.L.','680G 50G BORROWER PTY LTD','ABU DHABI ISLAMIC BANK','ADNOC DRILLING COMPANY P.J.S.C.'
,'AFF PROPERTIES GROUP','ALIGNED DATA CENTERS INTERNATIONAL, LP','ALIMIA SHIPPING LIMITED','APOLLO INVESTMENT FUND X, L.P'

)

exec useradmin.dbo.usp_Start_FRED_job 'FRED_UpdateMappings' --DONE OK
exec useradmin.[dbo].[usp_check_job_history] 'FRED_UpdateMappings'
exec useradmin.dbo.usp_Start_FRED_job 'FRED_CSMUpload'
exec useradmin.[dbo].[usp_check_job_history] 'FRED_CSMUpload'

exec useradmin.dbo.usp_Start_FRED_job 'FRED_GenerateLossByExposure'

exec useradmin.dbo.usp_Start_FRED_job 'FRED_CSMUpload'
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_check_job_history] 'FRED_GenerateLossByExposure'

exec useradmin.dbo.usp_Stop_FRED_job 'FRED_UpdateMappings' --DONE OK


--Checking

  select count(*) from [mi].[FRED_GFR] 




  The job failed.  The Job was invoked by User sa.  The last step to run was step 1 (CheckForFiles).
  Executed as user: LM\sagss-FRED-SSIS. Microsoft (R) SQL Server Execute Package Utility  Version 15.0.4316.3 for 64-bit  Copyright (C) 2019 Microsoft. All rights reserved.    
  Started:  14:18:13  
  Failed to execute IS server package because of error 0x80131904. Server: VMBIS-GSQLDB22, Package path: \SSISDB\FRED\FRED\FileName.dtsx, Environment reference Id: 1.  
  Description: The environment reference '1' is not associated with the project.  
  Source: .Net SqlClient Data Provider  Started:  14:18:13  Finished: 14:18:13  Elapsed:  0.141 seconds.  The package execution failed.  The step failed.



  SELECT
    ER.reference_id AS ReferenceId
,   E.name AS EnvironmentName
,   F.name AS FolderName
,   P.name AS ProjectName
FROM
    SSISDB.catalog.environments AS E
    INNER JOIN
        SSISDB.catalog.folders AS F
        ON F.folder_id = E.folder_id
    INNER JOIN 
        SSISDB.catalog.projects AS P
        ON P.folder_id = F.folder_id
    INNER JOIN
        SSISDB.catalog.environment_references AS ER
        ON ER.project_id = P.project_id
ORDER BY 
    ER.reference_id;



	
  SELECT *
  --update adn set AddNewData='true'
  FROM [FinancialRisks].[AddNewData] adn


  select distinct cedantname from FinancialRisks.ExposuresStaging (nolock)


  select top 10 * from FinancialRisks.ExposuresStaging



