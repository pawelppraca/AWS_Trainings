
-------------------------------------------------------------------------------
-- GSGL-474
-- START DATAFIX #4 - Replace NULLs with '' in FinancialRisks.Countrie table
-------------------------------------------------------------------------------


	update c set 
		CountryCapitalIqId  = IIF( CountryCapitalIqId is not null ,CountryCapitalIqId, ''),
		ISOCountryName = IIF( ISOCountryName is not null ,ISOCountryName, ''),
		Alpha3Code = IIF( Alpha3Code is not null ,Alpha3Code, ''),
		ISO2Code = IIF( ISO2Code is not null ,ISO2Code, ''),
		SovereignRating = IIF( SovereignRating is not null ,SovereignRating, ''),
		CountryPseudonym = IIF( CountryPseudonym is not null ,CountryPseudonym, ''),
		Region = IIF( Region is not null ,Region, '')
from FinancialRisks.Countries c  where 
	(CountryId is null 
	or CountryName is null 
	or CountryCapitalIqId is null 
	or  Alpha3Code is null 
	or ISO2Code is null 
	or SovereignRating is null
	or Region is null 
	or ISOCountryName is null 
	or CountryPseudonym is null
	)

-------------------------------------------------------------------------------
-- GSGL-474
-- END DATAFIX #4 - Replace NULLs with '' in FinancialRisks.Countrie table
-------------------------------------------------------------------------------