use fred


(select max(LastRunTime) from FinancialRisks.AddNewData)

select max(InforceDate) from FinancialRisks.vw_ExposureOverview

declare @inforcedate datetime
set @inforcedate='20220701'

select distinct EntityName, CapitalIqId, Domicile, CountryName, [Original Country in File]
into #obligors_test
from FinancialRisks.vw_ExposureOverview
where InforceDate = @inforcedate --(select max(LastRunTime) from FinancialRisks.AddNewData)
and CapitalIqId in
(
       select CapitalIqId
       from FinancialRisks.vw_ExposureOverview
       where InforceDate = @inforcedate --(select max(LastRunTime) from FinancialRisks.AddNewData)
       and CountryName not in ('WORLDWIDE', 'No country name supplied')
       group by CapitalIqId
       having count(distinct CountryName) > 1
)
and CountryName not in ('WORLDWIDE', 'No country name supplied')
order by EntityName



select * from #obligors_test where entityname like 'VINCI%'



select c.Countryname, en.entityname, count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'VINCI%'
--and ex.uploaddate='2023-05-31T00:00:00.000'
group by  c.Countryname, en.entityname,uploaddate
order by   en.entityname, c.Countryname


--Pliki Testowe
Data_Ergo_Hestia_XL_Surety_PriCCY.xlsx
Data_Credendo_STN_PriCCY.xlsx
Data_Credendo_ECA_XL_PriCCY.xlsx
Data_CONTINENTAL_CHILE_SURETY_PriCcy.xlsx
Data_AxaSpainXLLMIE_Surety_PriCCY.xlsx





--SIT TEST
use FRED


exec useradmin.[dbo].[usp_start_FRED_QuarterUpdate]

exec UserAdmin.[dbo].[usp_check_server_agent_jobs_currently_running]


select * 
from [FinancialRisks].[ExposuresQueue] eq 
left join [FinancialRisks].Countries c on c.countryid=eq.countryName
where ObligorEntityName like 'VINCI%'


select c.Countryname, en.entityname, count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'VINCI SA%'
and ex.uploaddate='2023-06-16T00:00:00.000'
group by  c.Countryname, en.entityname,uploaddate
order by   en.entityname, c.Countryname



select c.Countryname, en.entityname, uploaddate,ex.*
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'VINCI SA%'
and ex.uploaddate='2023-06-16T00:00:00.000'

--group by  c.Countryname, en.entityname,uploaddate
order by   en.entityname, c.Countryname



select EntityName, CapitalIqId, CountryName, [Original Country in File], Domicile, UploadDate
from FinancialRisks.vw_ExposureOverview
where InforceDate = '2022-07-01T00:00:00.000'
and Entityname like 'VINCI SA%' 


select max(UploadDate)
from FinancialRisks.vw_ExposureOverview
where UploadDate





select distinct EntityName, CapitalIqId, Domicile, CountryName, [Original Country in File]
into #tab
from FinancialRisks.vw_ExposureOverview
where InforceDate = (select max(LastRunTime) from FinancialRisks.AddNewData)
and CapitalIqId in
(
       select CapitalIqId
       from FinancialRisks.vw_ExposureOverview
       where InforceDate = (select max(LastRunTime) from FinancialRisks.AddNewData)
       and CountryName not in ('WORLDWIDE', 'No country name supplied')
       group by CapitalIqId
       having count(distinct CountryName) > 1
)
and CountryName not in ('WORLDWIDE', 'No country name supplied')
order by EntityName



select * from #tab where EntityName like 'VINCI%'

select * from #tab order by EntityName




USE FRED

select max(uploaddate)  from FinancialRisks.Exposures ex


select c.Countryname, en.entityname, count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'VINCI%'
and ex.uploaddate='2023-06-16T00:00:00.000'
group by  c.Countryname, en.entityname,uploaddate
order by   en.entityname, c.Countryname

--OBLIGORS

DROP TABLE IF EXISTS #Obligors

select ObligorID, ltrim(rtrim(ObligorName)) as 'ObligorName',ObligorPseudonymId,CountryName 
into  #Obligors from
(
	SELECT EntityId as ObligorId, rtrim(ltrim(EntityName)) as ObligorName ,'' as ObligorPseudonymId,Domicile as 'CountryName'
	FROM FinancialRisks.Entities
	UNION
	SELECT ObligorId, rtrim(ltrim(ObligorPseudonym)) as ObligorName,ObligorPseudonymId,''as 'CountryName'
	FROM FinancialRisks.ObligorPseudonym
)b


select * from #Obligors where ObligorName like 'VINCI%/%' order by ObligorName


 exec useradmin.[dbo].[usp_start_FRED_UpdateMappings]

 exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]


 


DECLARE @InforceDate DATETIME
SELECT @InforceDate = FinancialRisks.fn_GetInforceDate() 

Select (SELECT distinct max([LastRunTime])FROM [FinancialRisks].[AddNewData]) LastInforceDate 

select @InforceDate

--deleting in PecLines.dtsx
select * FROM [FinancialRisks].[Exposures] WHERE CobId = 3 AND [InforceDate] = @InforceDate
select * FROM [FinancialRisks].[ExposuresQueue] WHERE CobId = 3 AND [InforceDate] = @InforceDate
select * FROM [FinancialRisks].[Treaties] WHERE CobId = 3 AND [InforceDate] = @InforceDate
select * FROM [FinancialRisks].[TreatiesQueue] WHERE CobId = 3 AND [InforceDate] = @InforceDate





 DROP TABLE IF EXISTS #Obligors

select ObligorID, ltrim(rtrim(ObligorName)) as 'ObligorName',ObligorPseudonymId,CountryName 
into  #Obligors from
(
	SELECT EntityId as ObligorId, rtrim(ltrim(EntityName)) as ObligorName ,'' as ObligorPseudonymId,Domicile as 'CountryName'
	FROM FinancialRisks.Entities (nolock)
	UNION
	SELECT ObligorId, rtrim(ltrim(ObligorPseudonym)) as ObligorName,ObligorPseudonymId,''as 'CountryName'
	FROM FinancialRisks.ObligorPseudonym (nolock)
)b


select * from #Obligors where ObligorName like 'VINCI SA%'


exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]



exec useradmin.[dbo].[usp_start_FRED_QuarterUpdate]




select c.Countryname, en.entityname, count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'VINCI%'
and ex.uploaddate='2023-06-27T00:00:00.000'
group by  c.Countryname, en.entityname,uploaddate
order by   en.entityname, c.Countryname


select c.Countryname, en.entityname, uploaddate,*
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'VINCI%'
and ex.uploaddate='2023-06-27T00:00:00.000'
order by   en.entityname, c.Countryname

select c.Countryname, en.entityname, uploaddate,*
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'VINCI%'
and ex.uploaddate='2023-06-22T00:00:00.000'
order by   en.entityname, c.Countryname




select * from FinancialRisks.Entities where EntityName like 'Vinci%'
select * from FinancialRisks.ObligorPseudonym where ObligorPseudonym like 'Vinci%'



--Sprawdzenie warunk�w do wykonania Update Mappings
 SELECT * FROM [FinancialRisks].[MappingsStatus]

 IF ((SELECT count(*)  FROM [FinancialRisks].[MappingsStatus] where[Status] = 'Generating')=0
	and (select count(*)FROM  [FinancialRisks].[MappingsStatus] where [Status]='Complete' ) = 0)
Select 'True' as Updated
ELSE 
Select 'False' Updated

 SELECT * 
 --update ms set Status='Waiting'
 FROM [FinancialRisks].[MappingsStatus] ms

 --TESTING 3M Company and MOD

Data_Atradius_QS_Surety_PriCCY.xlsx
Data_Atradius_QS_Surety_Retro_PriCCY.xlsx
Data_EHRE_QS1_PriCCY.xlsx
Data_Nacional_WTO_PriCCY.xlsx


-- MINISTRY 
USE FRED
DROP TABLE IF EXISTS #Obligors

SELECT ObligorID
        ,ltrim(rtrim(ObligorName)) AS 'ObligorName'
        ,ObligorPseudonymId
        ,CountryName
        ,ParentCountryName
INTO  #Obligors FROM
(
	SELECT  EntityId as ObligorId
            ,RTRIM(LTRIM(EntityName)) AS ObligorName 
            ,'' AS ObligorPseudonymId
            ,Domicile AS 'CountryName'
            ,ParentDomicile ParentCountryName
	FROM FinancialRisks.Entities
	UNION
	SELECT  ObligorId
            ,rtrim(ltrim(ObligorPseudonym)) as ObligorName
            ,ObligorPseudonymId,''as 'CountryName'
            ,'' ParentCountryName
	FROM FinancialRisks.ObligorPseudonym
)b


select * from #Obligors where ObligorName like 'Ministry of defence%Qatar%'
select * from #Obligors where ObligorName like 'Ministry of defence/%'


select * from #Obligors where ObligorName like '3M%/%'

select * from #Obligors where ObligorName like 'amazon%'

select * from FinancialRisks.Entities where EntityName like 'Ministry of defence%bang%'
select * from FinancialRisks.ObligorPseudonym where ObligorPseudonym like 'Ministry of defence%bang%'



 exec useradmin.[dbo].[usp_start_FRED_UpdateMappings]

 exec useradmin.[dbo].[usp_start_FRED_QuarterUpdate]

 
 exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]


 select * from FinancialRisks.ExposuresStaging


 select c.Countryname, en.entityname, uploaddate,*
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like '3M%'
and ex.uploaddate='2023-06-29T00:00:00.000'
order by   en.entityname, c.Countryname


 select c.Countryname, en.entityname, uploaddate,*
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'Ministry of Defence%' and 
ex.uploaddate='2023-06-29T00:00:00.000'
order by   en.entityname, c.Countryname


 select * from FinancialRisks.ExposuresQueue where ObligorEntityName like 'Ministry%'