
USE FRED

select * from  FinancialRisks.Countries where CountryName in ('Channel Islands','Guinea-Bissau','Netherlands Antilles','Kosovo')

select * from FinancialRisks.CountryPseudonym cp
join FinancialRisks.Countries c on c.CountryId = cp.CountryID
where cp.CountryPseudonym in ('Channel Islands','Guinea-Bissau','Netherlands Antilles','Kosovo')





select distinct Domicile
into #Domicile2Add
from 
(
	select distinct Domicile from FinancialRisks.Entities where Domicile is not null 
) d
left join FinancialRisks.Countries c on d.Domicile=c.CountryName
where CountryId is null and d.Domicile not in ('(Invalid Identifier)','0','Misc','Other','Reunion')

--CountryNames from Countries which exists in CountryPseudonyms
select c.CountryId , c.CountryName CountryName_in_pseudonyms
into #Countries_in_Pseudonym
from FinancialRisks.Countries c
join FinancialRisks.CountryPseudonym cp on cp.CountryID=c.CountryId and c.CountryName = cp.CountryPseudonym 
order by c.CountryName 

--Add Pseudonyms for this which not exists and which will be amended

select * from #Domicile2Add


--insert into FinancialRisks.CountryPseudonym 
select c.CountryName, c.CountryId, d2a.*, c2.*,cp.*,c.* 
from #Domicile2Add d2a
join FinancialRisks.CountryPseudonym cp on cp.CountryPseudonym = d2a.Domicile
join FinancialRisks.Countries c on c.CountryId=cp.CountryID
left join (
	select * from #Countries_in_Pseudonym
) c2 on c2.CountryName_in_pseudonyms = c.CountryName
where c2.CountryId is null


select d2a.*, c.*
--update c set CountryName = d2a.Domicile
from #Domicile2Add d2a
join FinancialRisks.CountryPseudonym cp on cp.CountryPseudonym = d2a.Domicile
join FinancialRisks.Countries c on c.CountryId=cp.CountryID
left join (
	select * from #Countries_in_Pseudonym
) c2 on c2.CountryName_in_pseudonyms = c.CountryName
where c2.CountryId is null

--
select  d2a.Domicile ,'-->', c.CountryName , c2.*,cp.*,c.* 
--update c set CountryName = d2a.Domicile
from #Domicile2Add d2a
join FinancialRisks.CountryPseudonym cp on cp.CountryPseudonym = d2a.Domicile
join FinancialRisks.Countries c on c.CountryId=cp.CountryID
left join (
	select * from #Countries_in_Pseudonym
) c2 on c2.CountryName_in_pseudonyms = c.CountryName
where c2.CountryId is not null
and d2a.Domicile not in ('Channel Islands','Guinea-Bissau','Netherlands Antilles','Kosovo')

