USE FRED

--RUN Quarter Update (SIT)


exec useradmin.dbo.usp_Start_FRED_job 'FRED_QuarterUpdate'
exec useradmin.[dbo].[usp_check_job_history] 'FRED_QuarterUpdate'
exec useradmin.[dbo].[usp_check_job_steps]
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]


exec useradmin.dbo.usp_Start_FRED_job 'FRED_Currencies_Xrate'
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]
exec useradmin.[dbo].[usp_check_job_history] 'FRED_Currencies_Xrate'

select distinct uploaddate from [sources].[dwhr_Currencies]
select * from [sources].[dwhr_ExchangeRates]
select * from [sources].[dwhr_ISOCurrencies]



FRED_CSMUpload --OK 
FRED_Currencies_Xrate	--OK 	
FRED_GenerateLossByExposure	Not running	
FRED_GFRSource	--OK 
FRED_IdentifyMappings	--OK
FRED_QuarterUpdate	--OK 
FRED_UpdateMappings	--OK 
FRED_UpdateObligorMappings	Not running	



exec useradmin.[dbo].[usp_check_job_history] 'FRED_GenerateLossByExposure'

  select count(*) from [mi].[FRED_GFR] 



 select * from FinancialRisks.entities where entityname in (
	'AVANCE GAS HOLDING LTD','BANCO GANADERO S.A.','BANCO PROMERICA SA','CIDO HOLDING CO.'
   )


exec useradmin.dbo.usp_Start_FRED_job 'FRED_UpdateMappings' --DONE OK

exec useradmin.dbo.usp_Start_FRED_job 'FRED_CSMUpload'
exec useradmin.[dbo].[usp_check_job_history] 'FRED_UpdateMappings'

exec useradmin.dbo.usp_Start_FRED_job 'FRED_GenerateLossByExposure'

exec useradmin.dbo.usp_Start_FRED_job 'FRED_CSMUpload'
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_check_job_history] 'FRED_CSMUpload'

--Checking

  select count(*) from [mi].[FRED_GFR] 



  SELECT *
  --update adn set AddNewData='true'
  FROM [FinancialRisks].[AddNewData] adn


  select * from FinancialRisks.audit_LogSSISPackage order by logid desc




    SELECT
    ER.reference_id AS ReferenceId
,   E.name AS EnvironmentName
,   F.name AS FolderName
,   P.name AS ProjectName
FROM
    SSISDB.catalog.environments AS E
    INNER JOIN
        SSISDB.catalog.folders AS F
        ON F.folder_id = E.folder_id
    INNER JOIN 
        SSISDB.catalog.projects AS P
        ON P.folder_id = F.folder_id
    INNER JOIN
        SSISDB.catalog.environment_references AS ER
        ON ER.project_id = P.project_id
ORDER BY 
    ER.reference_id;



	select * from FinancialRisks.ExposuresQueue


	  SELECT *
  --update adn set AddNewData='true'
  FROM [FinancialRisks].[AddNewData] adn


	--RUN Quarter Update (SIT) - Full Load LMIE (>13MB) and Peclines (527)


exec useradmin.dbo.usp_Start_FRED_job 'FRED_QuarterUpdate'
exec useradmin.[dbo].[usp_check_job_history] 'FRED_QuarterUpdate'
exec useradmin.[dbo].[usp_check_job_steps]
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]


