--List of Country which are in Domicile but which aren't in Countries

-------------------------------------------------------------------------------
-- START DATAFIX #2  - Add new coutries and update names based on Domicile
-------------------------------------------------------------------------------

-- Add new Countries
------------------------------------
/*

Channel Islands : IQ318389235 --Tego nie dodawac
Guinea-Bissau: IQ58105087
Netherlands Antilles: IQ58104720 / ANT / AN / NULL / 'Central, South America and Caribbean'
Kosovo: IQ172885379 / XXK / XK / NULL / 'CEE'

*/


declare @NewCountryID int

--Guinea-Bissau: IQ58105087
insert into FinancialRisks.Countries (CountryName, CountryCapitalIqId, ISOCountryName, Alpha3Code, ISO2Code, SovereignRating, CountryPseudonym, Region)
values ('Guinea-Bissau','IQ58105087',null,'GNB','GW',NULL,NULL,'Africa')
set @NewCountryID = Scope_identity()
update FinancialRisks.CountryPseudonym set CountryID=@NewCountryID where CountryPseudonym='GUINEA-BISSAU'

--Netherlands Antilles: IQ58104720 / ANT / AN / NULL / 'Central, South America and Caribbean'
insert into FinancialRisks.Countries (CountryName, CountryCapitalIqId, ISOCountryName, Alpha3Code, ISO2Code, SovereignRating, CountryPseudonym, Region)
values ('Netherlands Antilles','IQ58104720',null,'ANT','AN',NULL,NULL,'Central, South America and Caribbean')
set @NewCountryID = Scope_identity()
update FinancialRisks.CountryPseudonym set CountryID=@NewCountryID where CountryPseudonym like '%Netherland% Antilles%'

--Kosovo: IQ172885379 / XXK / XK / NULL / 'CEE'
insert into FinancialRisks.Countries (CountryName, CountryCapitalIqId, ISOCountryName, Alpha3Code, ISO2Code, SovereignRating, CountryPseudonym, Region)
values ('Kosovo','IQ172885379',null,'XXK','XK',NULL,NULL,'CEE')
set @NewCountryID = Scope_identity()
update FinancialRisks.CountryPseudonym set CountryID=@NewCountryID where CountryPseudonym='Kosovo'

--Timor
update FinancialRisks.Countries set CountryName='Timor-Leste' where CountryId=203

--Updatting Countries
----------------------------------------------

select distinct Domicile
into #Domicile2Add
from 
(
	select distinct Domicile from FinancialRisks.Entities where Domicile is not null 
) d
left join FinancialRisks.Countries c on d.Domicile=c.CountryName
where CountryId is null and d.Domicile not in ('(Invalid Identifier)','0','Misc','Other','Reunion')

--CountryNames from Countries which exists in CountryPseudonyms
select c.CountryId , c.CountryName CountryName_in_pseudonyms
into #Countries_in_Pseudonym
from FinancialRisks.Countries c
join FinancialRisks.CountryPseudonym cp on cp.CountryID=c.CountryId and c.CountryName = cp.CountryPseudonym 
order by c.CountryName 

--Add Pseudonyms for this which not exists and which will be amended

--insert into FinancialRisks.CountryPseudonym 
select c.CountryName, c.CountryId
--d2a.*, c2.*,cp.*,c.* 
from #Domicile2Add d2a
join FinancialRisks.CountryPseudonym cp on cp.CountryPseudonym = d2a.Domicile
join FinancialRisks.Countries c on c.CountryId=cp.CountryID
left join (
	select * from #Countries_in_Pseudonym
) c2 on c2.CountryName_in_pseudonyms = c.CountryName
where c2.CountryId is null

--Update Domicile --> CountryName for these which not exists in CountryPseudonym
update c set CountryName = d2a.Domicile
from #Domicile2Add d2a
join FinancialRisks.CountryPseudonym cp on cp.CountryPseudonym = d2a.Domicile
join FinancialRisks.Countries c on c.CountryId=cp.CountryID
left join (
	select * from #Countries_in_Pseudonym
) c2 on c2.CountryName_in_pseudonyms = c.CountryName
where c2.CountryId is null

--Update Domicile --> CountryName for these which not exists in CountryPseudonym
-
select d2a.*, c2.*,cp.*,c.* 
--update c set CountryName = d2a.Domicile
from #Domicile2Add d2a
join FinancialRisks.CountryPseudonym cp on cp.CountryPseudonym = d2a.Domicile
join FinancialRisks.Countries c on c.CountryId=cp.CountryID
left join (
	select * from #Countries_in_Pseudonym
) c2 on c2.CountryName_in_pseudonyms = c.CountryName
where c2.CountryId is not null
and d2a.Domicile not in ('Channel Islands','Guinea-Bissau','Netherlands Antilles','Kosovo')




-------------------------------------------------------------------------------
-- END DATAFIX #2  - Add new coutries and update names based on Domicile
-------------------------------------------------------------------------------




select distinct Domicile
into #Domicile2Add
from 
(
	select distinct Domicile from FinancialRisks.Entities where Domicile is not null 
) d
left join FinancialRisks.Countries c on d.Domicile=c.CountryName
where CountryId is null and d.Domicile not in ('(Invalid Identifier)','0','Misc','Other','Reunion')



--CountryNames from Countries which exists in CountryPseudonyms

select c.CountryId , c.CountryName CountryName_in_pseudonyms
into #Countries_in_Pseudonym
from FinancialRisks.Countries c
join FinancialRisks.CountryPseudonym cp on cp.CountryID=c.CountryId
and c.CountryName = cp.CountryPseudonym
order by c.CountryName 


select * from #Domicile2Add
select * from #Countries_in_Pseudonym


select * from FinancialRisks.CountryPseudonym where CountryPseudonym like '%bosnia%'

--add missing Pseudonyms 

--insert into FinancialRisks.CountryPseudonym (CountryID, CountryPseudonym) values (26,'Bosnia-Herzegovina')

--Countries which will be updated

select CountryName, d2a.Domicile, * 
----update c set CountryName = d2a.Domicile
from #Domicile2Add d2a
left join FinancialRisks.Countries c on c.CountryName=d2a.Domicile
left join FinancialRisks.CountryPseudonym cp on cp.CountryID=c.CountryId and d2a.Domicile=cp.CountryPseudonym
left join (
	select * from #Countries_in_Pseudonym
) c2 on c2.CountryId = c.CountryId
join #Domicile2Add d2a2 on d2a.Domicile=cp.CountryPseudonym
where c.CountryId is null


select d2a.*, c2.*,cp.*,c.* 
from #Domicile2Add d2a
join FinancialRisks.CountryPseudonym cp on cp.CountryPseudonym = d2a.Domicile
join FinancialRisks.Countries c on c.CountryId=cp.CountryID
left join (
	select * from #Countries_in_Pseudonym
) c2 on c2.CountryName_in_pseudonyms = c.CountryName
where c2.CountryId is null



select d2a.*,cp.* from #Domicile2Add d2a
left join FinancialRisks.CountryPseudonym cp on cp.CountryPseudonym = d2a.Domicile
where cp.CountryPseudonymId is null


--tym zapytaniem wybierzemy kraje ktore trzeba podmienic, uwzglednic kraje w produkcji
--Podmiane zrobic recznie kraj po kraju
select * from #Domicile2Add d2a
join FinancialRisks.CountryPseudonym cp on cp.CountryPseudonym = d2a.Domicile
join FinancialRisks.Countries c on c.CountryId=cp.CountryID
left join (
	select * from #Countries_in_Pseudonym
) c2 on c2.CountryId = c.CountryId