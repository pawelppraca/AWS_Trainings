--GSGL-896 - Verify Remove Columns Rate and CurrencyName
use fred
------- BEFORE --------
Select top 10 CurrencyName, Rate, * from FinancialRisks.LossByExposure
select top 10 CurrencyName, Rate, * from FinancialRisks.vw_ExposureOverview 
-- Rename Column CurrencyName to ExposureCurrency
select top 10 CurrencyName, * from [FinancialRisks].[fn_LBEByRiskCodeCountry] (
    'United Kingdom',
	'SB',
    '20230101'
)


------- AFTER --------
Select top 10 CurrencyName, Rate,  * from FinancialRisks.LossByExposure
select top 10 CurrencyName, Rate, * from FinancialRisks.vw_ExposureOverview


-- Rename Column CurrencyName to ExposureCurrency
select top 10 ExposureCurrency, * from [FinancialRisks].[fn_LBEByRiskCodeCountry] (
    'United Kingdom',
	'SB',
    '20211001'
)



