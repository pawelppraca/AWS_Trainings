


select *
from INFORMATION_SCHEMA.COLUMNS
where TABLE_NAME='LossByExposure'


select name, create_date, modify_date
from sys.procedures
where name = 'GenerateLossByExposure'


select name, create_date, modify_date
from sys.views
where name = 'vw_ExposureOverview'


select name, create_date, modify_date
from sys.procedures
where name = 'CommonShockModelFinal'
