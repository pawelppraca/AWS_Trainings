
-------------------------------------------------------------------------------
-- START DATAFIX #3  - Add new Ministry to Entities
-------------------------------------------------------------------------------

--Tabelka z Nazwami Ministerstw
create table #Ministry (id int not null identity(1,1), Name nvarchar(100), Done int)
insert into #Ministry (name) values ('Ministry Of Defence'),('Ministry of Finance') --('Ministry of National Guard'),('Ministry of Investments and Foreign Trade'),('Ministry of Oil & Gas'),('MINISTRY OF AGRICULUTURE'),('Ministry of Energy and Water'),('Ministry of Health'),('MINISTRY OF AGRICULUTURE'),('Water Resources and Energy'),('Ministry of Transport and Communications'),('MINISTRY OF PUBLIC WORKS')


--Tworzenie ministerstw krajow
declare @Name_min nvarchar(100), @min_id int, @min_qty int, @new_ent_qty int

select @min_qty = count(*) from #Ministry where Done is  null

while @min_qty > 0
begin
	select top 1 @Name_min = name, @min_id=id from #Ministry where Done is null

	insert into [FinancialRisks].[Entities] (EntityName,ParentEntityName,Domicile,ParentDomicile,DefaultTradeSectorId,OverrideTradeSectorId)
	
	select @Name_min +' ('+CountryName+')', @Name_min +' ('+CountryName+')',CountryName,CountryName,262,262  from [FinancialRisks].Countries where len(CountryCapitalIqId)>0

	set @new_ent_qty = @@ROWCOUNT

	update #Ministry set done=1 where id = @min_id

	select @min_qty = count(*) from #Ministry where Done is null

end



-------------------------------------------------------------------------------
-- END DATAFIX #3   - Add new Ministry to Entities
-------------------------------------------------------------------------------
