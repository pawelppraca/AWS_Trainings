use FRED
/*
--zmiany w tabelach
alter table FinancialRisks.ExposuresStaging add [OriginalEntityinFile] NVARCHAR(250) NULL, [OriginalCountryinFile] NVARCHAR(250) NULL
alter table FinancialRisks.ExposuresQueue add [OriginalEntityinFile] NVARCHAR(250) NULL, [OriginalCountryinFile] NVARCHAR(250) NULL
alter table FinancialRisks.Ironshore_Data_Queue add [OriginalEntityinFile] NVARCHAR(250) NULL, [OriginalCountryinFile] NVARCHAR(250) NULL
alter table FinancialRisks.IronShore_Data add [OriginalEntityinFile] NVARCHAR(250) NULL, [OriginalCountryinFile] NVARCHAR(250) NULL
alter table FinancialRisks.Exposures add [OriginalEntityinFile] NVARCHAR(250) NULL, [OriginalCountryinFile] NVARCHAR(250) NULL
alter table FinancialRisks.LossByExposure add [OriginalEntityinFile] NVARCHAR(250) NULL, [OriginalCountryinFile] NVARCHAR(250) NULL


alter table FinancialRisks.ExposuresStaging drop column [OriginalEntityinFile]
alter table FinancialRisks.ExposuresStaging drop column [OriginalCountryinFile]
alter table FinancialRisks.ExposuresQueue drop column [OriginalEntityinFile] 
alter table FinancialRisks.ExposuresQueue drop column [OriginalCountryinFile]
alter table FinancialRisks.Ironshore_Data_Queue drop column [OriginalEntityinFile]
alter table FinancialRisks.Ironshore_Data_Queue drop column [OriginalCountryinFile]
alter table FinancialRisks.IronShore_Data drop column [OriginalEntityinFile]
alter table FinancialRisks.IronShore_Data drop column [OriginalCountryinFile]
alter table FinancialRisks.Exposures drop column  [OriginalEntityinFile]
alter table FinancialRisks.Exposures drop column [OriginalCountryinFile]
alter table FinancialRisks.LossByExposure drop column [OriginalEntityinFile]
alter table FinancialRisks.LossByExposure drop column [OriginalCountryinFile]

--ZMiana w pakiecie PecLines
SELECT [ExposureQueueId]
	  ,[CedantName]
	  ,[CobId]
	  ,[RiskReference]
	  ,[CurrencyId]
	  ,[Year]
	  ,[DataQuarter]
	  ,[AssuredEntityId]
	  ,[RiskCode]
	  ,[LeadSyndicate]
	  ,[CountryName]
	  ,[InceptionDate]
	  ,[ExpiryDate]
	  ,[Limit]
	  ,[UsdLimit]
	  ,[GrossPremium]
	  ,[GrossExposure]
	  ,SUBSTRING([FinancialRisks].[fn_RemoveBadChar]([ObligorEntityName]),1,100) ObligorEntityName
	  ,[InforceDate]
	  ,[Status]
	  ,[Source]
	  ,[UserNotified]
	  ,[ObligorPseudID]
	  ,[CountryPseudID]
	  ,[SBU]
	  ,[Office]
	  ,[AssumedLive]
	  ,[ProductLine]
	  ,[NoBillingOffsetTotalSuretyExposureNetPGE]
	  ,[NetSuretyExposure]
	  ,[Region]
	  ,SUBSTRING([FinancialRisks].[fn_RemoveBadChar]([Assured]),1,50) Assured
	  ,Industry
	  ,[OriginalEntityinFile]
	  ,[OriginalCountryinFile]
  FROM [FinancialRisks].[ExposuresStaging]




UPDATE  [FinancialRisks].[ExposuresQueue]
SET [ObligorEntityName] = [FinancialRisks].[fn_RemoveBadChar] ([ObligorEntityName])
	,CountryName =  [FinancialRisks].[fn_FixCountryName](CountryName)
	,[OriginalEntityinFile] = [FinancialRisks].[fn_RemoveBadChar] ([OriginalEntityinFile])
	,[OriginalCountryinFile] =  [FinancialRisks].[fn_FixCountryName]([OriginalCountryinFile])



*/


select * from FinancialRisks.ExposuresStaging where OriginalEntityinFile is not null
select * from FinancialRisks.ExposuresQueue where OriginalEntityinFile is not null
select * from FinancialRisks.Ironshore_Data_Queue

select * from FinancialRisks.Ironshore_data where OriginalEntityinFile is not null

select en.EntityName, e.OriginalEntityinFile,* 
from FinancialRisks.Exposures e
join FinancialRisks.Entities en on en.EntityId=e.ObligorEntityId
where OriginalEntityinFile is not null


select top 1000  uploaddate,* from FinancialRisks.Exposures where OriginalEntityinFile is not null

exec FinancialRisks.GenerateLossByExposure

select top 10 * from FinancialRisks.LossByExposure where OriginalEntityinFile is not null


select top 10 entityname, * from FinancialRisks.vw_ExposureOverview where [Original Country in File] is not null
select entityname, * from FinancialRisks.vw_ExposureOverview where UploadDate >='20231107'


--doko?czy? testy na DEV
 --Deploy na SIT - testy
 --Deploy na UAT - Testy

 --Testy DEV

exec useradmin.dbo.usp_Start_FRED_job 'FRED_QuarterUpdate'
exec useradmin.[dbo].[usp_check_agent_job_steps] 'FRED_QuarterUpdate'
exec useradmin.dbo.usp_Start_FRED_job 'FRED_QuarterUpdate' ,'PecLines'



select count(*) from FinancialRisks.ExposuresQueue where OriginalEntityinFile is not null
select count(*) from FinancialRisks.Ironshore_data where OriginalEntityinFile is not null
select count(*) from FinancialRisks.Exposures where OriginalEntityinFile is not null

select en.EntityName, e.OriginalEntityinFile,* 
from FinancialRisks.Exposures e
join FinancialRisks.Entities en on en.EntityId=e.ObligorEntityId
where OriginalEntityinFile is not null

exec FinancialRisks.GenerateLossByExposure

select count(*) from FinancialRisks.LossByExposure where OriginalEntityinFile is not null

select count(*) from FinancialRisks.vw_ExposureOverview where [Original Entity in File] is not null

select [Original Entity in File], EntityName,* from FinancialRisks.vw_ExposureOverview where [Original Entity in File] is not null

SELECT *
  FROM [FinancialRisks].[AddNewData]






