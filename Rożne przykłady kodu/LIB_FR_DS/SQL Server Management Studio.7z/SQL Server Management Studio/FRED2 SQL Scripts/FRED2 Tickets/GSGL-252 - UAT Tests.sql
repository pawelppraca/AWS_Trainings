



--Before Release-41 on DATAFix Pipeline on UAT

select * from financialrisks.COB

select distinct ActualReportingClass from [FinancialRisks].[TreatyReassignment] 



--After Deployemnt of Release-41 of DataFix

select * from financialrisks.COB

select distinct ActualReportingClass from [FinancialRisks].[TreatyReassignment] 


--Before import
DECLARE @MoveFROM DATETIME2,@MoveTo DATETIME2;
SET @MoveFROM = '2022-10-01 00:00:00.000'
SET @MoveTo = '2022-10-01 00:00:00.000'

select '[[Exposures]]',count(*)  FROM [FinancialRisks].[Exposures]	WHERE InforceDate = @MoveFrom
select '[Treaties]',count(*)  FROM [FinancialRisks].[Treaties] WHERE   InforceDate = @MoveFROM
select 'Ironshore_Data',count(*)  FROM FinancialRisks.Ironshore_Data WHERE InforceDate = @MoveFROM
select 'Ironshore_Data_Queue', count(*) FROM FinancialRisks.Ironshore_Data_Queue WHERE InforceDate = @MoveFROM

select * 
--update adn set LastRunTime = '20220701'
from [FinancialRisks].[AddNewData] adn

select [FinancialRisks].[fn_GetInforceDate]() InforceDate


--IMport TreatyRessigment File

----Sprawdzenie tabeli przed Importem

select * from [FinancialRisks].[TreatyReassignment] 

exec UserAdmin.[dbo].[usp_start_FRED_CSMUpload]

exec UserAdmin.[dbo].[usp_check_server_agent_jobs_currently_running]

--Run GenLBE after Treaty Reassigment Import
exec UserAdmin.[dbo].[usp_start_FRED_GenerateLossByExposure]


select top 1000 * from [FinancialRisks].[vw_ExposureOverview] where InforceDate='20221001'


select distinct CobID, ReportingClass, ClassOfBusiness from [FinancialRisks].[vw_ExposureOverview] 


select distinct cobid,ReportingClass,  ClassOfBusiness from [FinancialRisks].[vw_ExposureOverview] where Inforcedate = '20221001'
select distinct ClassOfBusiness from [FinancialRisks].[Pec_Lines_AKE_Data] where Inforcedate = '20221001'


select * from 