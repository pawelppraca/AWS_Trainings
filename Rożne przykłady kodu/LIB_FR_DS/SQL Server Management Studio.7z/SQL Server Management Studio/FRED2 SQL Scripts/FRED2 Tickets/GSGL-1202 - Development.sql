
--Test nowego ?adowania z DWH
--Wykonanie na tabeli testowej  [sources].[dwhr_Currencies_2]


USE [FRED]
GO

DROP Table IF EXISTS [sources].[dwhr_Currencies_2] 
CREATE TABLE [sources].[dwhr_Currencies_2](
	[rid] [int] NOT NULL,
	[CurrencyKey] [int] NULL,
	[CurrencyCode] [nvarchar](50) NULL,
	[CurrencyName] [nvarchar](100) NULL,
	[ISOCurrencyKey] [int] NULL,
	[_DateCreated] [datetime2](7) NULL,
	[_EventExecutionKey] [int] NULL,
	[_LastAction] [nvarchar](1) NULL,
	[_MergeKey] [nvarchar](255) NULL,
	[_SourceSystemCode] [nvarchar](50) NULL,
	[LoadID] [int] NOT NULL,
	[UploadDate] [datetime] NULL,
	[UploadFredDate] [datetime] NULL,
 CONSTRAINT [PK_SrcsDwhrCurrencies_2] PRIMARY KEY CLUSTERED 
(
	[rid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

--Utworzenie tabeli roboczej do por�wnania (Na Sta?e)

DROP Table IF EXISTS [sources].[dwhr_Currencies_WORK] 

CREATE TABLE [sources].[dwhr_Currencies_WORK](
	[rid] [int] NOT NULL,
	[CurrencyKey] [int] NULL,
	[CurrencyCode] [nvarchar](50) NULL,
	[CurrencyName] [nvarchar](100) NULL,
	[ISOCurrencyKey] [int] NULL,
	[LoadID] [int] NOT NULL,
	[UploadDate] [datetime] NULL,
	[UploadFredDate] [datetime] NULL,
	[_DateCreated] [datetime2](7) NULL,
	[_EventExecutionKey] [int] NULL,
	[_LastAction] [nvarchar](1) NULL,
	[_MergeKey] [nvarchar](255) NULL,
	[_SourceSystemCode] [nvarchar](50) NULL,
	[_SourceChecksum] [int] NULL,
	[_TargetChecksum] [int] NULL,

 CONSTRAINT [PK_SrcsDwhrCurrenciesWORK] PRIMARY KEY CLUSTERED 
(
	[CurrencyKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]



--Sprawdzenie czy tabela jest pusta
DECLARE @TargetEmpty BIT = 1;
SELECT TOP 1 @TargetEmpty = 0 FROM [sources].[dwhr_Currencies_2];
SELECT @TargetEmpty;




--Uzywanie Currencies


			SELECT DISTINCT ccyFrom.currencycode          AS 'Name',
							roe.exchangerate              AS 'rate',
							YEAR(roe.exchangeratedatekey) AS 'year'
			 --select '|--> ccyFrom|', ccyFrom.*,'|--> ccyFromISO|',  ccyFromISO.*,'|--> roe|', roe.*, '|--> ccyToISO|',   ccyToISO.*           
			 --select ccyFrom._SourceSystemCode, ccyFrom.currencycode FromCrcy,ccyToISO.isocurrencycode ToCrcy, '|--> roe|', roe.*
			FROM   [sources].[vw_dwhr_currencies] ccyFrom
			INNER JOIN sources.vw_dwhr_isocurrencies ccyFromISO	 ON ccyFrom.isocurrencykey = ccyFromISO.isocurrencykey
			INNER JOIN sources.vw_dwhr_exchangerates roe		 ON ccyFromISO.isocurrencykey = roe.isocurrencyfromkey
			INNER JOIN sources.vw_dwhr_isocurrencies ccyToISO	 ON roe.isocurrencytokey = ccyToISO.isocurrencykey
			WHERE  ccyToISO.isocurrencycode = N'USD'
					AND roe.exchangeratetypecode = N'[GAAP Plan]'
					and CurrencyCode='PLN'
			--and YEAR(roe.exchangeratedatekey) = YEAR(Getdate())
			order by ccyFrom._SourceSystemCode, exchangeratedatekey, roe._DateCreated



--Skopiowanie danych z tabeli obecnej w DEV do Docelowej


--testowe uzupe?nianie i insertowanie.
Tabele na bazie FRED

sources.[dwhr_Currencies_Source_Test]  - zawiera przyk?adowe dane z tabeli [sources].[dwhr_Currencies] aby mo?na by?o to zmienia?
[sources].[dwhr_WORK_Currencies]
sources.[dwhr_Currencies_Destination_Test] - tabela docelowa Testowa 



CREATE TABLE [sources].[dwhr_Currencies_Source_Test](
	[rid] [int] IDENTITY(1,1) NOT NULL,
	[CurrencyKey] [int] NULL,
	[CurrencyCode] [nvarchar](50) NULL,
	[CurrencyName] [nvarchar](100) NULL,
	[ISOCurrencyKey] [int] NULL,
	[_DateCreated] [datetime2](7) NULL,
	[_EventExecutionKey] [int] NULL,
	[_LastAction] [nvarchar](1) NULL,
	[_MergeKey] [nvarchar](255) NULL,
	[_SourceSystemCode] [nvarchar](50) NULL,
	[LoadID] [int] NOT NULL,
	[UploadDate] [datetime] NULL,
 CONSTRAINT [PK_SrcsDwhrCurrenciesSourceTest] PRIMARY KEY CLUSTERED 
(
	[rid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

DROP Table IF EXISTS [sources].[dwhr_Currencies_Destination_Test] 
CREATE TABLE [sources].[dwhr_Currencies_Destination_Test] (
	[rid] [int] NOT NULL,
	[CurrencyKey] [int] NULL,
	[CurrencyCode] [nvarchar](50) NULL,
	[CurrencyName] [nvarchar](100) NULL,
	[ISOCurrencyKey] [int] NULL,
	[_DateCreated] [datetime2](7) NULL,
	[_EventExecutionKey] [int] NULL,
	[_LastAction] [nvarchar](1) NULL,
	[_MergeKey] [nvarchar](255) NULL,
	[_SourceSystemCode] [nvarchar](50) NULL,
	[LoadID] [int] NOT NULL,
	[UploadDate] [datetime] NULL,
	[UploadFredDate] [datetime] NULL,
 CONSTRAINT [PK_SrcsDwhrCurrenciesDestinationTest] PRIMARY KEY CLUSTERED 
(
	[rid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO



--Merged Chnaged Data SQL Code


MERGE sources.[dwhr_Currencies_Destination_Test]  AS t 
USING [sources].[dwhr_WORK_Currencies] AS s 
ON 
(
	t.[CurrencyKey] = s.[CurrencyKey] 
)
WHEN MATCHED AND s.[_LastAction] IN ('I', 'U') 
THEN 
UPDATE 
SET 
	[rid]					= s.[rid]
,	[CurrencyCode]		    = s.[CurrencyCode]		
,	[CurrencyName]		    = s.[CurrencyName]		
,	[ISOCurrencyKey]	    = s.[ISOCurrencyKey]	
,	[_DateCreated]		    = s.[_DateCreated]		
,	[_EventExecutionKey]    = s.[_EventExecutionKey]
,	[_LastAction]		    = s.[_LastAction]		
,	[_MergeKey]			    = s.[_MergeKey]			
,	[_SourceSystemCode]	    = s.[_SourceSystemCode]	
,	[LoadID]			    = s.[LoadID]			
,	[UploadDate]		    = s.[UploadDate]		

WHEN NOT MATCHED BY TARGET AND s.[_LastAction] IN ('I', 'U') THEN 
INSERT 
( 
	[rid]				
,	[CurrencyCode]		
,	[CurrencyName]		
,	[ISOCurrencyKey]	
,	[_DateCreated]		
,	[_EventExecutionKey]
,	[_LastAction]		
,	[_MergeKey]			
,	[_SourceSystemCode]	
,	[LoadID]			
,	[UploadDate]		

)
VALUES
(
	s.[rid]				
,	s.[CurrencyCode]		
,	s.[CurrencyName]		
,	s.[ISOCurrencyKey]	
,	s.[_DateCreated]		
,	s.[_EventExecutionKey]
,	s.[_LastAction]		
,	s.[_MergeKey]			
,	s.[_SourceSystemCode]	
,	s.[LoadID]			
,	s.[UploadDate]		
);



--Zasili? danymi tabel? ?r�d?ow? - DONE OK
--Wytestowa? dodanie nowych rekord�w - DONE OK
-- Sprawdzenie ze jak sie rekordy nie zmienily to sie nie dodaly i nie zaupdateowaly
-- zmieni? rekrod w ?r�d?e - DONE OK
-- Dodac nowe rekordy do tabeli ?r�d?owej sprzwdzi? czy si? dodadz? -
-- skasowa? rekord w ?r�dle

-- Przerobi? na tabel? ?r�d?ow? prawid?ow?
--Zrobi? to samo dla pozosta?ych tabel.


select * from sources.[dwhr_Currencies_Source_Test]
select * from [sources].[dwhr_WORK_Currencies]
Select * from sources.[dwhr_Currencies_Destination_Test]
select * from [sources].[dwhr_Currencies_2]

--Copy Data from Source to Test Source

--INSERT INTO sources.[dwhr_Currencies_Source_Test] (
      [CurrencyKey]
      ,[CurrencyCode]
      ,[CurrencyName]
      ,[ISOCurrencyKey]
      ,[_DateCreated]
      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_SourceSystemCode]
      ,[LoadID]
      ,[UploadDate]
)
SELECT top 10 
	   [CurrencyKey]
      ,[CurrencyCode]
      ,[CurrencyName]
      ,[ISOCurrencyKey]
      ,[_DateCreated]
      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_SourceSystemCode]
      ,[LoadID]
      ,[UploadDate]
  FROM [FRED].[sources].[dwhr_Currencies]


--Sprawdzenie Checksum

SELECT [rid]
      ,[CurrencyKey]
      ,[CurrencyCode]
      ,[CurrencyName]
      ,[ISOCurrencyKey]
      ,[_DateCreated]
      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_SourceSystemCode]
      ,[LoadID]
      ,[UploadDate]
      ,checksum([CurrencyKey],[CurrencyCode],[CurrencyName],[ISOCurrencyKey],[_DateCreated],[_EventExecutionKey],[_MergeKey],[_SourceSystemCode],[LoadID],[UploadDate]) SourceChecksum
FROM [FRED].[sources].[dwhr_Currencies_Source_Test]
order by rid

SELECT [rid]
      ,[CurrencyKey]
      ,[CurrencyCode]
      ,[CurrencyName]
      ,[ISOCurrencyKey]
      ,[_DateCreated]
      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_SourceSystemCode]
      ,[LoadID]
      ,[UploadDate]
       ,checksum([CurrencyKey],[CurrencyCode],[CurrencyName],[ISOCurrencyKey],[_DateCreated],[_EventExecutionKey],[_MergeKey],[_SourceSystemCode],[LoadID],[UploadDate]) TargetChecksum
FROM [FRED].[sources].[dwhr_Currencies_Destination_Test]



select * from sources.[dwhr_Currencies_Source_Test]
select * from [sources].[dwhr_WORK_Currencies]
Select * from sources.[dwhr_Currencies_Destination_Test]

--TEST ZMIANY rekordu

--UPDATE sources.[dwhr_Currencies_Source_Test] set CurrencyName ='Lek - Albania.' where currencykey=4


select * from sources.[dwhr_Currencies_Source_Test]
select * from [sources].[dwhr_WORK_Currencies]
Select * from sources.[dwhr_Currencies_Destination_Test]

--TEST Dodania nowych rekord�w

--INSERT INTO sources.[dwhr_Currencies_Source_Test] (
      [CurrencyKey]
      ,[CurrencyCode]
      ,[CurrencyName]
      ,[ISOCurrencyKey]
      ,[_DateCreated]
      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_SourceSystemCode]
      ,[LoadID]
      ,[UploadDate]
)
SELECT top 5 
	   [CurrencyKey]
      ,[CurrencyCode]
      ,[CurrencyName]
      ,[ISOCurrencyKey]
      ,[_DateCreated]
      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_SourceSystemCode]
      ,[LoadID]
      ,[UploadDate]
  FROM [FRED].[sources].[dwhr_Currencies] where rid>10


  select * from sources.[dwhr_Currencies_Source_Test]
select * from [sources].[dwhr_WORK_Currencies]
Select * from sources.[dwhr_Currencies_Destination_Test]



-- tabele docelowe uzupe?nianie i insertowanie.
--Tabele na bazie FRED

[sources].[dwhr_Currencies_Staging]  - zawiera przyk?adowe dane z tabeli [sources].[dwhr_Currencies] aby mo?na by?o to zmienia?
[sources].[dwhr_Currencies_WORK]
sources.[dwhr_Currencies_2] - tabela docelowa Testowa 


select * from [sources].[dwhr_Currencies_Staging]
select * from [sources].[dwhr_Currencies_WORK]
Select * from [sources].[dwhr_Currencies_2]


--Testing zmiany


--UPDATE sources.[dwhr_Currencies_Staging] set CurrencyName ='Lek - Albania.' where currencykey = 4

exec [Sources].[Merge_Currencies]

select * from [sources].[dwhr_Currencies_Staging] where currencykey = 4
select * from [sources].[dwhr_Currencies_WORK] where currencykey = 4
Select * from [sources].[dwhr_Currencies_2] where currencykey = 4

-- OK Rekord zaktualizowany

--Test usuni?cia rekordu - rekord nie jest usuwany

select * 
--delete
from [sources].[dwhr_Currencies_Staging] where currencykey = 1355

select * from [sources].[dwhr_Currencies_Staging] where currencykey = 1355
select * from [sources].[dwhr_Currencies_WORK] where currencykey = 1355
Select * from [sources].[dwhr_Currencies_2] where currencykey = 1355 --OK rekord istnieje



--Test dodania rekordu - rekord jest dodany

--insert into  [sources].[dwhr_Currencies_Staging]  (CurrencyKey, CurrencyCode, CurrencyName, ISOCurrencyKey, _DateCreated, _EventExecutionKey, _LastAction, _MergeKey, _SourceSystemCode, LoadID, UploadDate)
select 1360, CurrencyCode, CurrencyName, ISOCurrencyKey, _DateCreated, 273590, _LastAction, _MergeKey, _SourceSystemCode, LoadID, UploadDate 
from [sources].[dwhr_Currencies_Staging] where currencykey = 1353


select * from [sources].[dwhr_Currencies_Staging] where currencykey in (1358,1359,1360)
select * from [sources].[dwhr_Currencies_WORK] where currencykey in (1358,1359,1360)
Select * from [sources].[dwhr_Currencies_2] where currencykey in (1358,1359,1360)

exec [Sources].[Merge_Currencies]

--UPDATE sources.[dwhr_Currencies_Staging] set CurrencyName ='<<Unknown>>.' where currencykey = 1359

----------------------------
--FXRates
----------------------------

CREATE TABLE [sources].[dwhr_ExchangeRates_2] (
    [rid]                  INT             NOT NULL,
    [ExchangeRateKey]      INT             NOT NULL,
    [ISOCurrencyFromKey]   INT             NULL,
    [ISOCurrencyToKey]     INT             NULL,
    [ExchangeRateDateKey]  DATE            NULL,
    [ExchangeRateTypeCode] NVARCHAR (255)  NULL,
    [ExchangeRateTypeName] NVARCHAR (255)  NULL,
    [ExchangeRate]         NUMERIC (31, 7) NULL,
    [_DateCreated]         DATETIME2 (7)   NULL,
    [_EventExecutionKey]   INT             NULL,
    [_LastAction]          NVARCHAR (1)    NULL,
    [_MergeKey]            NVARCHAR (255)  NULL,
    [_SourceSystemCode]    NVARCHAR (50)   NULL,
    [LoadID]               INT             NULL,
	[UploadDate]           datetime        NULL,
	[UploadFredDate]       datetime        NULL,
    CONSTRAINT [PK_SrcsDWHRXrates2] PRIMARY KEY CLUSTERED ([ExchangeRateKey] ASC)
);

--Utworzenie tabeli roboczej do por�wnania (Na Sta?e)

DROP Table IF EXISTS [sources].[dwhr_ExchangeRates_WORK] 

CREATE TABLE [sources].[dwhr_ExchangeRates_WORK](
    [rid]                  INT             NOT NULL,
    [ExchangeRateKey]      INT             NOT NULL,
    [ISOCurrencyFromKey]   INT             NULL,
    [ISOCurrencyToKey]     INT             NULL,
    [ExchangeRateDateKey]  DATE            NULL,
    [ExchangeRateTypeCode] NVARCHAR (255)  NULL,
    [ExchangeRateTypeName] NVARCHAR (255)  NULL,
    [ExchangeRate]         NUMERIC (31, 7) NULL,
    [LoadID]               INT             NULL,
	[UploadDate]           datetime        NULL,
	[UploadFredDate]       datetime        NULL,
    [_DateCreated]         DATETIME2 (7)   NULL,
    [_EventExecutionKey]   INT             NULL,
    [_LastAction]          NVARCHAR (1)    NULL,
    [_MergeKey]            NVARCHAR (255)  NULL,
    [_SourceSystemCode]    NVARCHAR (50)   NULL,
	[_SourceChecksum]	   INT			   NULL,
	[_TargetChecksum]	   INT			   NULL,

 CONSTRAINT [PK_SrcsDwhrExchangeRatesWORK] PRIMARY KEY CLUSTERED 
(
	[ExchangeRateKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


-- tabele docelowe uzupe?nianie i insertowanie.
--Tabele na bazie FRED

--[sources].[dwhr_ExchangeRates_Staging]  - zawiera przyk?adowe dane z tabeli [sources].[dwhr_Currencies] aby mo?na by?o to zmienia?
--[sources].[dwhr_ExchangeRates_WORK]
--[sources].[dwhr_ExchangeRates_2] - tabela docelowa Testowa 

select count(*) from [sources].[dwhr_ExchangeRates] (nolock)
select count(*) from [sources].[dwhr_ExchangeRates_Staging] (nolock)
select count(*) from [sources].[dwhr_ExchangeRates_WORK] (nolock)
Select count(*) from [sources].[dwhr_ExchangeRates_2] (nolock)


--BULK LOAD OK

--Testing zmiany
------------------

select top 1000 *  from [sources].[dwhr_ExchangeRates_Staging] (nolock) order by rid desc



select * 
--UPDATE exs set ExchangeRate=1.3278001
from sources.[dwhr_ExchangeRates_Staging] exs where ExchangeRateKey = 1257405


select * from [sources].[dwhr_ExchangeRates_Staging] (nolock) where ExchangeRateKey in (1257405)
select * from [sources].[dwhr_ExchangeRates_WORK] (nolock)  where ExchangeRateKey in (1257405)
Select * from [sources].[dwhr_ExchangeRates_2] (nolock)  where ExchangeRateKey in (1257405)


exec [Sources].[Merge_ExchangeRates]

-- TEST PASS

--Testowanie nowego rekordu
----------------------------


--insert into  [sources].[dwhr_ExchangeRates_Staging]  (ExchangeRateKey, ISOCurrencyFromKey, ISOCurrencyToKey, ExchangeRateDateKey, ExchangeRateTypeCode, ExchangeRateTypeName, ExchangeRate, _DateCreated, _EventExecutionKey, _LastAction, _MergeKey, _SourceSystemCode, LoadID, UploadDate)
select 1257406, ISOCurrencyFromKey, 82, ExchangeRateDateKey, ExchangeRateTypeCode, ExchangeRateTypeName, 1.0000000, _DateCreated, _EventExecutionKey, _LastAction, _MergeKey, _SourceSystemCode, LoadID, UploadDate
from sources.[dwhr_ExchangeRates_Staging] exs where ExchangeRateKey = 1257405


select * from [sources].[dwhr_ExchangeRates_Staging] where ExchangeRateKey in (1257406,1257405)
select * from [sources].[dwhr_ExchangeRates_WORK] where ExchangeRateKey in (1257406,1257405)
Select * from [sources].[dwhr_ExchangeRates_2] where ExchangeRateKey in (1257406,1257405)

exec [Sources].[Merge_ExchangeRates]

--TEST PASS


--Testowanie usuni?cia rekordu


select * 
--delete
from [sources].[dwhr_ExchangeRates_Staging] where ExchangeRateKey = 1257406

select * from [sources].[dwhr_ExchangeRates_Staging] where ExchangeRateKey = 1257406
select * from [sources].[dwhr_ExchangeRates_WORK] where ExchangeRateKey = 1257406
Select * from [sources].[dwhr_ExchangeRates_2] where ExchangeRateKey = 1257406 --


--TEST PASS

--TESTOWANIE UPDATE Zerowej Warto?ci
--------------------------------------------

select * 
--UPDATE exs set ExchangeRate=0
from sources.[dwhr_ExchangeRates_Staging] exs where ExchangeRateKey = 1257405


select * from [sources].[dwhr_ExchangeRates_Staging] (nolock) where ExchangeRateKey in (1257405)
select * from [sources].[dwhr_ExchangeRates_WORK] (nolock)  where ExchangeRateKey in (1257405)
Select * from [sources].[dwhr_ExchangeRates_2] (nolock)  where ExchangeRateKey in (1257405)


--TEST PASS






----------------------------
--ISOCurrencies
----------------------------

CREATE TABLE [sources].[dwhr_ISOCurrencies_2] (
	[rid] 						INT					NOT NULL,
	[ISOCurrencyKey]			INT					NOT NULL,
	[ISOCurrencyCode]			NVARCHAR (255)		NULL,
	[ISOCurrencyName]			NVARCHAR (255)		NULL,
	[SettlementCurrencyFlag]	NVARCHAR (50)		NULL,
	[LoadID]					INT					NULL,
	[UploadDate]				DATETIME			NULL,
	[UploadFredDate]			DATETIME			NULL,
	[_DateCreated]				DATETIME2 (7)		NULL,
	[_EventExecutionKey]		INT					NULL,
	[_LastAction]				NVARCHAR (1)		NULL,
	[_MergeKey]					NVARCHAR (255)		NULL,
	[_SourceSystemCode]			NVARCHAR(50)		NULL,

	CONSTRAINT [PK_SrcsDWHRISOCurrencies2] PRIMARY KEY CLUSTERED 
(
	[ISOCurrencyKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


--Utworzenie tabeli roboczej do por�wnania (Na Sta?e)

DROP Table IF EXISTS [sources].[dwhr_ISOCurrencies_WORK] 

CREATE TABLE [sources].[dwhr_ISOCurrencies_WORK](
	[rid] 						INT					NOT NULL,
	[ISOCurrencyKey]			INT					NOT NULL,
	[ISOCurrencyCode]			NVARCHAR (255)		NULL,
	[ISOCurrencyName]			NVARCHAR (255)		NULL,
	[SettlementCurrencyFlag]	NVARCHAR (50)		NULL,
	[LoadID]					INT					NULL,
	[UploadDate]				DATETIME			NULL,
	[UploadFredDate]			DATETIME			NULL,
	[_DateCreated]				DATETIME2 (7)		NULL,
	[_EventExecutionKey]		INT					NULL,
	[_LastAction]				NVARCHAR (1)		NULL,
	[_MergeKey]					NVARCHAR (255)		NULL,
	[_SourceSystemCode]			NVARCHAR(50)		NULL,
	[_SourceChecksum]			INT					NULL,
	[_TargetChecksum]			INT					NULL,

 CONSTRAINT [PK_SrcsDwhrISOCurrenciesWORK] PRIMARY KEY CLUSTERED 
(
	[ISOCurrencyKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


-- tabele docelowe uzupe?nianie i insertowanie.
-- Tabele na bazie FRED

--[sources].[dwhr_ISOCurrencies_Staging]  - zawiera przyk?adowe dane z tabeli [sources].[dwhr_Currencies] aby mo?na by?o to zmienia?
--[sources].[dwhr_ISOCurrencies_WORK]
--[sources].[dwhr_ISOCurrencies_2] - tabela docelowa Testowa 

select count(*) from [sources].[dwhr_ISOCurrencies] (nolock)
select count(*) from [sources].[dwhr_ISOCurrencies_Staging] (nolock)
select count(*) from [sources].[dwhr_ISOCurrencies_WORK] (nolock)
Select count(*) from [sources].[dwhr_ISOCurrencies_2] (nolock)


--BULK LOAD OK

--Testing zmiany
------------------

select top 1000 *  from [sources].[dwhr_ISOCurrencies_Staging] (nolock) order by rid desc



select * 
--UPDATE exs set ISOCurrencyName = 'Sao Tomean Dobra.'
from sources.[dwhr_ISOCurrencies_Staging] exs where ISOCurrencyKey = 261

select * from [sources].[dwhr_ISOCurrencies_WORK] (nolock) 
select * from [sources].[dwhr_ISOCurrencies_Staging] (nolock) where ISOCurrencyKey in (261)
select * from [sources].[dwhr_ISOCurrencies_WORK] (nolock)  where ISOCurrencyKey in (261)
Select * from [sources].[dwhr_ISOCurrencies_2] (nolock)  where ISOCurrencyKey in (261)

-- TEST PASS



--Testowanie nowego rekordu
----------------------------

--insert into  [sources].[dwhr_ISOCurrencies_Staging]  ([ISOCurrencyKey] ,[ISOCurrencyCode] ,[ISOCurrencyName] ,[SettlementCurrencyFlag] ,[_DateCreated] ,[_EventExecutionKey] ,[_LastAction] ,[_MergeKey] ,[_SourceSystemCode] ,[LoadID] ,[UploadDate])
select 262 ,'AAA' ,'Ala ma kota' ,[SettlementCurrencyFlag] ,[_DateCreated] ,[_EventExecutionKey] ,[_LastAction] ,[_MergeKey] ,[_SourceSystemCode] ,[LoadID] ,[UploadDate]
from sources.[dwhr_ISOCurrencies_Staging] exs where ISOCurrencyKey = 261


select * from [sources].[dwhr_ISOCurrencies_Staging] where ISOCurrencyKey in (261,262)
select * from [sources].[dwhr_ISOCurrencies_WORK] where ISOCurrencyKey in (261,262)
Select * from [sources].[dwhr_ISOCurrencies_2] where ISOCurrencyKey in (261,262)

exec [Sources].[Merge_ExchangeRates]

--TEST PASS


--Testowanie usuni?cia rekordu


select * 
--delete
from [sources].[dwhr_ISOCurrencies_Staging] where ISOCurrencyKey = 262

select * from [sources].[dwhr_ISOCurrencies_Staging] where ISOCurrencyKey = 262
select * from [sources].[dwhr_ISOCurrencies_WORK] where ISOCurrencyKey = 262
Select * from [sources].[dwhr_ISOCurrencies_2] where ISOCurrencyKey = 262 --


--TEST PASS - Record exists


--BULK LOAD

--Befor Start JOB

use FRED

select 'vw_dwhr_Currencies' table_name, count(*) from [sources].[vw_dwhr_Currencies] (nolock) --1038
select 'vw_dwhr_ExchangeRates' table_name, count(*) from [sources].[vw_dwhr_ExchangeRates] (nolock) --1030094
select '[vw_dwhr_ISOCurrencies]' table_name, count(*) from [sources].[vw_dwhr_ISOCurrencies] (nolock) --263


exec useradmin.dbo.usp_Start_FRED_job 'FRED_Currencies_Xrate_2'
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]
exec useradmin.[dbo].[usp_check_job_history] 'FRED_Currencies_Xrate_2'

select top 10 * from [sources].[dwhr_ExchangeRates_2]


--ADD NEW - OK

select top 10 * 
--delete
from [sources].[dwhr_ExchangeRates_2] where rid=2


exec useradmin.dbo.usp_Start_FRED_job 'FRED_Currencies_Xrate_2'

--UPDATE --OK

select top 10 * 
--update ex set exchangerate=1
from [sources].[dwhr_ExchangeRates_2] ex where rid=3

exec useradmin.dbo.usp_Start_FRED_job 'FRED_Currencies_Xrate_2'
