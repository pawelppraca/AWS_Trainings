--GSGL-1034 - Testy UAT 31.03.2023 -----

--Deploymen GSGL-1034 Datafix#1 to clean columns Riskcode, LeadSyndicate, RiskReference

select UploadDate,
	case
		when Riskcode like ' %' then 'RiskCode Leading'
		when Riskcode like '% ' then 'RiskCode Trailing'
		when LeadSyndicate like ' %' then 'LeadSyndicate Leading'
		when LeadSyndicate like '% ' then 'LeadSyndicate Trailing'
		when RiskReference like ' %' then 'RiskReference Leading'
		when RiskReference like '% ' then 'RiskReference Trailing'
	end  issue
,* 
from FinancialRisks.Exposures e 
where 
(	datalength(Riskcode) <> datalength(LTRIM(RTRIM(Riskcode))) 
	or datalength(LeadSyndicate) <> datalength(LTRIM(RTRIM(LeadSyndicate))) 
	or datalength(RiskReference) <> datalength(LTRIM(RTRIM(RiskReference))) 
	)


--quantity of entities  with not trimmed columns in Exposures
select 'FinancialRisks.Exposures on UAT' as [TableName], 'Not Trimmed ' status,  count(*) quantity_of_records
from FinancialRisks.Exposures e 
where 
(
	datalength(Riskcode) <> datalength(LTRIM(RTRIM(Riskcode))) 
	or datalength(LeadSyndicate) <> datalength(LTRIM(RTRIM(LeadSyndicate)))
	or datalength(RiskReference) <> datalength(LTRIM(RTRIM(RiskReference))) 
	)

--total entities in Exposures
select 'FinancialRisks.Exposures on UAT' as [TableName], 'Total entities' status,  count(*) quantity_of_records
from FinancialRisks.Exposures e 

--quantity of entities  with not trimmed columns in Ironshore_Data
select 'FinancialRisks.Ironshore_Data' as [TableName], 'Not Trimmed' status,  count(*) quantity_of_records
from FinancialRisks.Ironshore_Data id
where datalength(Riskcode) <> datalength(LTRIM(RTRIM(Riskcode))) 

--total entities in Ironshore_Data
select 'FinancialRisks.Ironshore_Data' as [TableName], 'Total entities' status,  count(*) quantity_of_records
from FinancialRisks.Ironshore_Data id


--Checking before Upload on UAT
------------------------------------
--Records not trimmed in Exposures 
select 'FinancialRisks.Exposures' as [TableName], 'Not Trimmed - upload on April 2023' status,  count(*) quantity_of_records
from FinancialRisks.Exposures e 
where 
(
	datalength(Riskcode) <> datalength(LTRIM(RTRIM(Riskcode))) --if RiskCode is not trimmed then datalength are different
	or datalength(LeadSyndicate) <> datalength(LTRIM(RTRIM(LeadSyndicate))) --if LeadSyndicate is not trimmed then datalength are different
	or datalength(RiskReference) <> datalength(LTRIM(RTRIM(RiskReference))) --if RiskReference is not trimmed then datalength are different
	)
and 
UploadDate >='20230401'

--Records not trimmed in  Ironshore_Data
select 'FinancialRisks.Ironshore_Data' as [TableName], 'Not Trimmed - upload on April 2023' status,  count(*) quantity_of_records
from FinancialRisks.Ironshore_Data id
where datalength(Riskcode) <> datalength(LTRIM(RTRIM(Riskcode)))

--Records not trimmed in  ExposuresQueue
select 'FinancialRisks.ExposuresQueue' as [TableName], 'Not Trimmed - upload on April 2023' status,  count(*) quantity_of_records
from FinancialRisks.ExposuresQueue e 
where 
(
	datalength(Riskcode) <> datalength(LTRIM(RTRIM(Riskcode))) 
	or datalength(LeadSyndicate) <> datalength(LTRIM(RTRIM(LeadSyndicate)))
	or datalength(RiskReference) <> datalength(LTRIM(RTRIM(RiskReference))) 
	)




--Uruchomienie Uploadu - UAT
exec UserAdmin.[dbo].[usp_check_server_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_check_job_history] 'FRED_QuarterUpdate'

exec UserAdmin.[dbo].[usp_start_FRED_QuarterUpdate]


select max(uploaddate) from FinancialRisks.Exposures

select * from FinancialRisks.ExposuresQueue



--Checking After Upload on UAT

--Records not trimmed in Exposures 
select 'FinancialRisks.Exposures' as [TableName], 'Not Trimmed - upload on April 2023' status,  count(*) quantity_of_records
from FinancialRisks.Exposures e 
where 
(
	datalength(Riskcode) <> datalength(LTRIM(RTRIM(Riskcode))) --if RiskCode is not trimmed then datalength are different
	or datalength(LeadSyndicate) <> datalength(LTRIM(RTRIM(LeadSyndicate))) --if LeadSyndicate is not trimmed then datalength are different
	or datalength(RiskReference) <> datalength(LTRIM(RTRIM(RiskReference))) --if RiskReference is not trimmed then datalength are different
	)
and 
UploadDate >='20230401'

--Records not trimmed in  Ironshore_Data
select 'FinancialRisks.Ironshore_Data' as [TableName], 'Not Trimmed - upload on April 2023' status,  count(*) quantity_of_records
from FinancialRisks.Ironshore_Data id
where datalength(Riskcode) <> datalength(LTRIM(RTRIM(Riskcode)))

--Records not trimmed in  ExposuresQueue
select 'FinancialRisks.ExposuresQueue' as [TableName], 'Not Trimmed - upload on April 2023' status,  count(*) quantity_of_records
from FinancialRisks.ExposuresQueue e 
where 
(
	datalength(Riskcode) <> datalength(LTRIM(RTRIM(Riskcode))) 
	or datalength(LeadSyndicate) <> datalength(LTRIM(RTRIM(LeadSyndicate)))
	or datalength(RiskReference) <> datalength(LTRIM(RTRIM(RiskReference))) 
	)


--Update mamppings

exec UserAdmin.[dbo].[usp_start_FRED_UpdateMappings]

exec UserAdmin.[dbo].[usp_check_server_agent_jobs_currently_running]
exec useradmin.[dbo].[usp_check_job_history] 'FRED_UpdateMappings'



select count(*) from FinancialRisks.ExposuresQueue


exec useradmin.[dbo].[usp_stop_FRED_UpdateMappings]