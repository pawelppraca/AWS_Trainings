USE [FRED]
GO
/****** Object:  StoredProcedure [FinancialRisks].[CommonShockModelFinal]    Script Date: 9/26/2022 3:40:55 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER  PROC [FinancialRisks].[CommonShockModelFinal] @InforceDate DATETIME2
AS



drop table if exists [FinancialRisks].[CSM_Model_OutputV2_TMP2]
DROP TABLE IF EXISTS [FinancialRisks].[CSMOutputR]
DROP TABLE IF EXISTS [FinancialRisks].CSMOutputR_RC_byTreaty

select 'table create started ', getdate()



SELECT  cast([SimulationID] AS INt) [SimulationID]
      ,[DefaultSimNo]
      ,cast([Entity] AS INt) Entity
      ,cast([ClassID] AS INt) [ClassID]
      ,[DefaultYear]
      ,[SimLGD]
      ,Cast ([InforceDate] AS datetime) [InforceDate]
into
[FinancialRisks].[CSM_Model_OutputV2_TMP2]
from [FinancialRisks].[CSM_Model_OutputV2]
where InforceDate = @InforceDate

CREATE CLUSTERED INDEX IX_CSM_Model_OutputV2_TMP2  ON [FinancialRisks].[CSM_Model_OutputV2_TMP2] (Entity, Classid)

SET NOCOUNT ON

DROP TABLE IF EXISTS #lbeCSM
DROP TABLE IF EXISTS #InforceDate
SELECT LastRunTime = @InforceDate
INTO #InforceDate

SELECT          
		CASE WHEN eo.EntityName = 'No obligor name supplied'
	    THEN
			 eo.exposureid * -1
			 ELSE
			eo.ObligorEntityId
		END ObligorEntityId ,
		eo.CobId ,
		eo.ClassOfBusiness,
		eo.ReportingClass, 
		eo.CedantName,
		eo.EntityName,
		eo.GCHPRating,
		eo.LibertyRating,
		eo.SPRating,
		eo.TreatyType,
		eo.TreatyID,
		eo.TreatyReference,
		eo.RiskReference,
		eo.ExposureID,
		eo.TreatyLimit,
		eo.TreatyRate, 
		eo.Excess, 
		eo.NumReinstatements,
		eo.SignedLine,
		eo.OurShare,
		eo.GrossExposure,
		eo.LibertyExposure,
		eo.InforceDate
INTO #lbeCSM
FROM FinancialRisks.vw_ExposureOverview eo
WHERE EXISTS (SELECT 1 FROM #InforceDate id WHERE eo.InforceDate = id.LastRunTime)
	AND RiskCode IN  ('CF','CR', 'SB', 'SU', 'FG','PB','PQ')

SELECT  
		ClassOfBusinessID,
		ClassOfBusiness,
		SimNo,
		SimPeriod,
		SimLGD,
		ReportingClass,
		TreatyID,
		TreatyType,
		TreatyReference,
		RiskReference,
		ExposureID,
		Limit,
		Excess,
		[NumReinstatements],
		SignedLine,
		OurShare,
		ExpGR,
		LossGR,
		ExpNT,
        --XOL = APPLY XOL TERMS
        CASE WHEN TreatyType = 'XL' THEN
                CASE WHEN LossGR > Excess THEN
                    CASE WHEN LossGR > (Limit + Excess) THEN Limit ELSE LossGR - Excess END
                ELSE 0 END
        --QS = LossGR UNLESS LIMIT IS PRESENT THEN APPLY LIMIT + QS TERMS
        WHEN TreatyType  in ('QS', 'BA') THEN
                CASE WHEN LossGR > Limit AND Limit > 0 THEN Limit ELSE LossGR END
                WHEN TreatyID IS NULL THEN ExpGR
        END 
        --APPLY LINE AND OURSHARE
        * SignedLine * OurShare AS LossNT
		,CedantName
		,GCHPRating
		,LibertyRating
		,SPRating
		,EntityName
	INTO  [FinancialRisks].CSMOutputR
       FROM (
			SELECT 
			lbe.CobId as ClassOfBusinessID,
			lbe.ClassOfBusiness,
			lbe.ReportingClass, 
			lbe.CedantName,
			lbe.EntityName + CAST(lbe.ObligorEntityId AS Varchar(50)) EntityName,
			lbe.GCHPRating,
			lbe.LibertyRating,
			lbe.SPRating
			,cast(CSMO.DefaultSimNo AS int) AS SimNo
			,CSMO.DefaultYear AS SimPeriod
			,lbe.TreatyType
			,lbe.TreatyID
			,lbe.TreatyReference
			,lbe.RiskReference
			,lbe.ExposureID
			,cast(CSMO.SimLGD AS float) AS SimLGD
			,ISNULL(lbe.TreatyLimit / (CASE WHEN lbe.TreatyRate = 'NR' THEN 0 ELSE cast(lbe.TreatyRate AS float) END),0) AS Limit
			,ISNULL(lbe.Excess / (CASE WHEN lbe.TreatyRate = 'NR' THEN 0 ELSE cast(lbe.TreatyRate AS float) END),0) AS Excess
			,lbe.[NumReinstatements]
			,isnull(lbe.SignedLine,1) AS SignedLine
			,isnull(lbe.OurShare,1)AS OurShare
			,isnull(lbe.GrossExposure,0) AS ExpGR
			,lbe.LibertyExposure AS ExpNT
			,isnull(lbe.GrossExposure,0) * cast(CSMO.SimLGD AS float) AS LossGR
			FROM #lbeCSM lbe
            inner join FinancialRisks.[CSM_Model_OutputV2_TMP2] CSMO on CSMo.Entity = lbe.ObligorEntityId and CSMo.ClassID = lbe.CobId and  CSMO.inforcedate = lbe.InforceDate
            where  csmo.InforceDate = @InforceDate

              )x  
			  
SELECT 
	SimNo, 
	SimPeriod,
	ClassOfBusiness,
	ClassOfBusinessID,
	TreatyID, TreatyReference, TreatyType, 
	treatylimit,
	excess AS excess,
	NumReinstatements,
	MaxLimit,
	Loss_NT_Current,
	CASE 
		WHEN Loss_NT_Current > treatylimit * (1+NumReinstatements) THEN MaxLimit
		ELSE Loss_NT_Current
	END AS Loss_NT_Corrected

INTO [FinancialRisks].CSMOutputR_RC_byTreaty

FROM (
		SELECT 
			ClassOfBusinessID,
			SimNo, 
			SimPeriod,
			ClassOfBusiness,
			TreatyID, TreatyReference, TreatyType, 
			NumReinstatements,
			Limit AS treatylimit,
			excess AS excess,
			limit * (1+isnull(NumReinstatements,0)) AS MaxLimit,
			sum(isnull(LossNT,0)) AS Loss_NT_Current
		FROM [FinancialRisks].CSMOutputR
		GROUP BY 
			SimNo, 
			SimPeriod,
			ClassOfBusinessID,
			ClassOfBusiness,
			NumReinstatements,
			TreatyID, TreatyReference, TreatyType, 
			Limit,
			excess,
			limit * (1+isnull(NumReinstatements,0))
		) y
ORDER BY 
	SimNo, 
	SimPeriod,
	ClassOfBusiness,
	ClassOfBusinessID,
	TreatyID,
	TreatyReference,
	TreatyType;

drop table if exists [FinancialRisks].[CSM_Model_OutputV2_TMP2]