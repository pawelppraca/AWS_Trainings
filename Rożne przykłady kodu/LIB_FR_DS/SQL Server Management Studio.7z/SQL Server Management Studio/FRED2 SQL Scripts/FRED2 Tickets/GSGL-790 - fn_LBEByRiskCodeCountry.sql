USE [FRED]
GO
/****** Object:  UserDefinedFunction [FinancialRisks].[fn_LBEByRiskCodeCountry]    Script Date: 9/23/2022 10:00:59 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION [FinancialRisks].[fn_LBEByRiskCodeCountry] (
    @CountryName Varchar(4000),
	@RiskCode Varchar(1000),
    @InforceDate Varchar(100)
)
RETURNS @exposures TABLE
(
   Exposureid   INT, 
   Treatyid  INT, 
   ObligorEntityId  INT,
   EntityName  Varchar(350),
   CapitalIqId Varchar(30),
   [Entity Region] Varchar(255),
   [Exposure Region] Varchar(255),
   SPRating Varchar(30),
   GCHPRating Varchar(30),
   LibertyRating Varchar(30),
   CedantName Varchar(150),
   ReportingClass Varchar(50),
   ClassOfBusiness Varchar(50),
   CobId INT,
   ClassLGD FLOAT,
   SovereignRating Varchar(50),
   TradeSectorName  Varchar(100),
   TradeSectorId  INT,
   InceptionDate DateTime,
   ExpiryDate DateTime,
   RateGroup INT,
   TreatyType Varchar(2),
   --CurrencyName  Varchar(3),
   ExposureCurrency Varchar(3),
   InforceDate DateTime,
   Limit    Numeric(18,0), 
   RiskReference Varchar(255),
   Assured Varchar(50),
   LibertyExposureByRisk Numeric(38,7),
   LibertyExposureByCountryAndRiskcode Numeric(38,7),
   GrossExposureByRisk Numeric(38,13),
   RiskCode  Varchar(5),
   CountryName Varchar(100),
   CntTreaty INT,
   CntCountry INT,
   CntRiskCode INT

  )
 AS
BEGIN


  IF   @RiskCode is null  
  BEGIN
   SELECT @RiskCode =  (STUFF((
	  SELECT  DISTINCT CAST(',' + RiskCode AS VARCHAR(MAX)) 
          FROM [FinancialRisks].[RiskCodeMappings]
          FOR XML PATH ('')
		  
		  
		  ), 1, 2, '')) 
  END


-- not the most elegant but creating string for countries when the input is null is causing performance problems
-- so just have seperate query and do not filter on country name if the parameter is NULL
-- although multiple statements in the UDF impacts performance also but this sees to be best compromise for now for ad-hoc queries

IF   @CountryName is null  
BEGIN
  INSERT @exposures
  SELECT  
   v.Exposureid, 
   v.Treatyid, 
   v.ObligorEntityId  ,
   v.EntityName  ,
   v.CapitalIqId ,
   v.[Exposure Region] ,
   v.[Entity Region] ,
   v.SPRating ,
   v.GCHPRating ,
   v.LibertyRating ,
   v.CedantName ,
   v.ReportingClass ,
   v.ClassOfBusiness ,
   v.CobId ,
   v.ClassLGD ,
   v.SovereignRating ,
   v.TradeSectorName  ,
   v.TradeSectorId  ,
   v.[Exposure Inception Date] ,
   v.[Exposure Expiry Date] ,
   v.RateGroup ,
   v.TreatyType ,
   --v.CurrencyName ,
   v.ExposureCurrency,
   v.InforceDate ,
   v.Limit, 
   v.RiskReference,
   v.Assured,
   v.LibertyExposure ,
   v.LibertyExposure / COUNT(TreatyId) OVER (PARTITION BY v.Treatyid,v.RiskReference, obligorentityID, v.[Exposure Inception Date],v.[Exposure Expiry Date],ExposureCurrency, LibertyExposure ) AS LibertyExposureByCountryAndRiskcode,
   v.GrossExposure GrossExposureByRisk,
   v.RiskCode, 
   v.CountryName,
   COUNT(TreatyID) OVER (PARTITION BY Treatyid,v.RiskReference, obligorentityID, v.[Exposure Inception Date],v.[Exposure Expiry Date],ExposureCurrency, LibertyExposure) AS CntTreaty,
   COUNT(CountryName) OVER (partition by v.Treatyid,v.RiskReference, obligorentityID, v.[Exposure Inception Date],v.[Exposure Expiry Date],ExposureCurrency, LibertyExposure,CountryName) AS CntCountry,
   COUNT(RiskCode) OVER (partition by v.Treatyid,v.RiskReference, obligorentityID, v.[Exposure Inception Date],v.[Exposure Expiry Date],ExposureCurrency, LibertyExposure,RiskCode) AS CntRiskCode
   
  FROM   [FinancialRisks].[vw_ExposureOverview] v 
  WHERE  InforceDate =  @InforceDate
  AND RiskCode in ( SELECT VALUE FROM STRING_SPLIT  (@RisKcode, ',')    ) 
  GROUP BY v.Exposureid, 
  v.ObligorEntityId  ,
  v.EntityName  ,
  v.CapitalIqId ,
  v.[Exposure Region] ,
  v.[Entity Region] ,
  v.SPRating ,
  v.GCHPRating ,
  v.LibertyRating ,
  v.CedantName ,
  v.ReportingClass ,
  v.ClassOfBusiness ,
  v.CobId ,
  v.ClassLGD ,
  v.SovereignRating ,
  v.TradeSectorName  ,
  v.TradeSectorId  ,
  v.[Exposure Inception Date] ,
  v.[Exposure Expiry Date] ,
  v.RateGroup ,
  v.TreatyType ,
  v.ExposureCurrency ,
  v.InforceDate ,
  v.RiskReference,
  v.Assured, 
  v.LibertyExposure,
  v.Limit,
  v.GrossExposure,
  v.RiskCode,
  v.CountryName,
  v.TreatyID
END
ELSE
BEGIN
  INSERT @exposures
  SELECT
  v.Exposureid, 
  v.Treatyid, 
  v.ObligorEntityId  ,
  v.EntityName  ,
  v.CapitalIqId ,
  v.[Exposure Region] ,
  v.[Entity Region] ,
  v.SPRating ,
  v.GCHPRating ,
  v.LibertyRating ,
  v.CedantName ,
  v.ReportingClass ,
  v.ClassOfBusiness ,
  v.CobId ,
  v.ClassLGD ,
  v.SovereignRating ,
  v.TradeSectorName  ,
  v.TradeSectorId  ,
  v.[Exposure Inception Date] ,
  v.[Exposure Expiry Date] ,
  v.RateGroup ,
  v.TreatyType ,
  v.ExposureCurrency ,
  v.InforceDate ,
  v.Limit, 
  v.RiskReference,
  v.Assured,
  v.LibertyExposure ,
  v.LibertyExposure / COUNT(TreatyId) OVER (PARTITION BY v.Treatyid,v.RiskReference, obligorentityID, v.[Exposure Inception Date],v.[Exposure Expiry Date],ExposureCurrency, LibertyExposure ) AS LibertyExposureByCountryAndRiskcode,
  v.GrossExposure GrossExposureByRisk,
  v.RiskCode, 
  v.CountryName ,
  COUNT(TreatyID) OVER (PARTITION BY Treatyid,v.RiskReference, obligorentityID, v.[Exposure Inception Date],v.[Exposure Expiry Date],ExposureCurrency, LibertyExposure) AS CntTreaty,
  COUNT(CountryName) OVER (partition by v.Treatyid,v.RiskReference, obligorentityID, v.[Exposure Inception Date],v.[Exposure Expiry Date],ExposureCurrency, LibertyExposure,CountryName) AS CntCountry,
  COUNT(RiskCode) OVER (partition by v.Treatyid,v.RiskReference, obligorentityID, v.[Exposure Inception Date],v.[Exposure Expiry Date],ExposureCurrency, LibertyExposure,RiskCode) AS CntRiskCode
   
  FROM   [FinancialRisks].[vw_ExposureOverview] v 
  WHERE  InforceDate =  @InforceDate
  AND RiskCode in ( SELECT VALUE FROM STRING_SPLIT  (@RisKcode, ',')    ) 
  AND CountryName in ( SELECT VALUE FROM STRING_SPLIT  (@CountryName, ',')) 
  GROUP BY v.Exposureid, 
  v.treatyid,
  v.ObligorEntityId  ,
  v.EntityName  ,
  v.CapitalIqId ,
  v.[Exposure Region] ,
  v.[Entity Region] ,
  v.SPRating ,
  v.GCHPRating ,
  v.LibertyRating ,
  v.CedantName ,
  v.ReportingClass ,
  v.ClassOfBusiness ,
  v.CobId ,
  v.ClassLGD ,
  v.SovereignRating ,
  v.TradeSectorName  ,
  v.TradeSectorId  ,
  v.[Exposure Inception Date] ,
  v.[Exposure Expiry Date] ,
  v.RateGroup ,
  v.TreatyType ,
  v.ExposureCurrency ,
  v.InforceDate ,
  v.RiskReference,
  v.Assured, 
  v.LibertyExposure,
  v.Limit,
  v.GrossExposure,
  v.RiskCode,
  v.CountryName
END
RETURN
END