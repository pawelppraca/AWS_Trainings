use fred

select * from FinancialRisks.ExposuresQueue


exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate] 

exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]
exec useradmin.[dbo].[usp_check_job_history] 'FRED_QuarterUpdate' 



--Sprawdzenie warunk�w do wykonania Update Mappings
 SELECT * FROM [FinancialRisks].[MappingsStatus]

 IF ((SELECT count(*)  FROM [FinancialRisks].[MappingsStatus] where[Status] = 'Generating')=0
	and (select count(*)FROM  [FinancialRisks].[MappingsStatus] where [Status]='Complete' ) = 0)
Select 'True' as Updated
ELSE 
Select 'False' Updated

 SELECT * 
 --update ms set Status='Waiting'
 FROM [FinancialRisks].[MappingsStatus] ms



 
DROP TABLE IF EXISTS #Obligors

select ObligorID, ltrim(rtrim(ObligorName)) as 'ObligorName',ObligorPseudonymId,CountryName 
into  #Obligors from
(
	SELECT EntityId as ObligorId, rtrim(ltrim(EntityName)) as ObligorName ,'' as ObligorPseudonymId,Domicile as 'CountryName'
	FROM FinancialRisks.Entities (nolock)
	UNION
	SELECT ObligorId, rtrim(ltrim(ObligorPseudonym)) as ObligorName,ObligorPseudonymId,''as 'CountryName'
	FROM FinancialRisks.ObligorPseudonym (nolock)
)b


select * from #Obligors where ObligorName like 'VINCI SA%' order by ObligorName
select * from #Obligors where ObligorName like 'VINCI%' order by ObligorName



select * from 	 FinancialRisks.Entities (nolock )where EntityName like 'VINCI%'
select * from 	 FinancialRisks.ObligorPseudonym (nolock )where ObligorPseudonym like 'VINCI/%'
select * from 	 #Obligors (nolock )where ObligorName like 'VINCI%'

select * from #Obligors where ObligorName like 'Ministry of Defence%Egy%'
select * from #Obligors where ObligorName like 'Ministry of Defence%Qa%'
select * from #Obligors where ObligorName like 'Ministry of Defence%Cy%'
select * from #Obligors where ObligorName like 'Ministry of Defence%India%'
select * from #Obligors where ObligorName like 'Ministry of Defence%Kuw%'

select * from #Obligors where ObligorName like 'Ministry of Defence%/%'


select * from #Obligors where ObligorName like '3M Company%'



select * from FinancialRisks.Entities (nolock) 
where entityname like 'Ministry of Defence%Cy%'
or entityname like 'Ministry of Defence%Bang%'
or entityname like 'Ministry of Defence%egy%'
or entityname like 'Ministry of Defence%qa%'


select * from FinancialRisks.ObligorPseudonym (nolock) where ObligorPseudonym like 'VINCI%'

 --Update Mappings
 exec useradmin.[dbo].[usp_start_FRED_UpdateMappings]

 exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

 exec useradmin.[dbo].[usp_check_job_history] 'FRED_UpdateMappings' 
 
exec useradmin.[dbo].[usp_start_FRED_UpdateMappings]

exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate] 




select c.Countryname, en.entityname, uploaddate,source, Industry, ex.*
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'VINCI SA%'
and ex.uploaddate='2023-06-30T00:00:00.000'
order by Entityname



select c.Countryname, en.entityname, uploaddate,source, Industry, ex.*
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like '3M Company%'
and ex.uploaddate='2023-06-30T00:00:00.000'
order by Entityname



select c.Countryname, en.entityname, uploaddate,source, Industry, ex.*
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'Ministry of Defence%/%'
and ex.uploaddate='2023-06-30T00:00:00.000'
order by Entityname


--Generating GenLBE

exec useradmin.[dbo].[usp_start_FRED_GenerateLossByExposure]


--Checking Data in Exposure OverView


select ex.Countryname, ex.entityname, uploaddate,source, Industry, ex.*
from FinancialRisks.vw_ExposureOverview ex
--join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
--join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where ex.EntityName like 'Vinci%'
and ex.uploaddate='2023-06-30T00:00:00.000'
order by ex.Entityname


select entityname, countryname, cobid,  *
from FinancialRisks.LossByExposure lbe
--join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
--join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where lbe.EntityName like 'Vinci%'
and ex.uploaddate='2023-06-30T00:00:00.000'
order by ex.Entityname




select c.Countryname, en.entityname, uploaddate,source, Industry, ex.*
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'Ministry of Defence%/%'



select ex.Countryname, ex.entityname, uploaddate,source, Industry, ex.*
from FinancialRisks.vw_ExposureOverview ex
--join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
--join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where ex.EntityName like 'Ministry of Defence%/%%'
and ex.uploaddate='2023-06-30T00:00:00.000'
order by ex.Entityname



--Fragment GenLBE

	SELECT DISTINCT tr.NewReference AS SystemTreatyId, e.ExposureId,
	c.[Name] AS CedantName,cob.ReportingClass,e.RiskReference,e.InceptionDate,e.ExpiryDate, tr.Limit AS TreatyLimit, ecr.[Name] AS CurrencyName, cr.RateGroup,
	 ttcr.Rate, e.CurrencyId, cob.CobId, cob.[Name] AS ClassOfBusiness,
	 tr.AuditCode AS TreatyType, tr.Excess, tr.SignedLine, tr.OurShare,
	CASE WHEN e.cobid NOT IN (1, 2, 5) THEN --COB IDs for GFR AND PTC which allready have their Currencies FX rates applied
		CASE WHEN e.GrossExposure / ecr.Rate > ISNULL(e.Limit / ecr.Rate,0) AND ISNULL(e.Limit / ecr.Rate,0) > 0 
		THEN ISNULL(e.Limit / ecr.Rate,0) 
		ELSE e.GrossExposure / ecr.Rate END
	ELSE e.GrossExposure END AS GrossExposure, 
	 
	 CASE WHEN en.EntityName LIKE  '%Ministry%' OR en.EntityName LIKE  '%Confiscation%' 
		  THEN CASE WHEN  en.EntityName  LIKE  '%'+co.CountryName+'%'
					THEN en.EntityName
					ELSE en.EntityName +' - ' + co.CountryName  
				END
		  ELSE en.EntityName
		END AS EntityName,
	 en.EntityId AS ObligorEntityId,
	 co.CountryName,
	 co.Region,
	 ts.TradeSectorName,
	 ISNULL(ISNULL(OverrideTradeSectorId,ts.TradeSectorid),DefaultTradeSectorId) AS TradeSectorId,
	 CASE WHEN tso.TradeSectorName = 'Sovereign' THEN
	 -- Override > Sovereign > ->  GCHPRating -> LibertyRating -> Default
	       ISNULL(ISNULL(OverrideRating,ISNULL(NUllIF(co.SovereignRating,''),ISNULL(SPRating,(ISNULL(GCHPRating,LibertyRating))))),DefaultRating)
	    ELSE
	 -- Override-> S&P ->  GCHPRating -> LibertyRating -> Default 
           ISNULL(ISNULL(OverrideRating,ISNULL(SPRating,ISNULL(GCHPRating,LibertyRating))),DefaultRating)
     END AS UltimateRating,
	 ISNULL(ISNULL(OverrideDomicile,Domicile),DefaultDomicile) AS UltimateDomicile,
	 ISNULL(ISNULL(ISNULL(OverrideDomicile,Domicile),DefaultDomicile),Co.CountryName) AS UltimateCountry,
	 cob.ClassLGD,
	 en.SPRating,
	 en.GCHPRating,
	 en.LibertyRating,
	 en.CapitalIqId,
	 co.SovereignRating,
	 e.InforceDate,TreatyID,assured,UploadDate,
	 ecr.Rate AS ExposureRate,		-- GSGL-790 - New columns added by PP 
	 ttcr.Name AS TreatyCurrency	-- GSGL-790 - New columns added by PP
	
	select en.EntityName,e.InceptionDate e_InceptionDate , tr.InceptionDate tr_InceptionDate,tr.ExpiryDate,* 
	FROM FinancialRisks.Exposures e
	--cedants
	LEFT JOIN FinancialRisks.Cedant c ON c.CedantID = e.CedantId
	--exposure riskcode mappings
	LEFT JOIN FinancialRisks.RiskCodeMappings riskCodeMappings ON riskCodeMappings.riskCode = ltrim(rtrim(e.RiskCode)) 
	--join treaties to exposures ON cedant, risk code group AND inforcedate
	LEFT JOIN FinancialRisks.Treaties tr ON tr.CedantId = c.CedantID  AND tr.InforceDate = e.InforceDate AND riskCodeMappings.RiskCodeGroupId = tr.RiskCodeGroupId
	--exposure currency data
	LEFT JOIN FinancialRisks.Currencies cr ON cr.CurrencyID = e.CurrencyID
	--2019 Currency Exchange Rates for Exposures
	--LEFT JOIN CurrencyFXRates ecr ON cr.CurrencyName = ecr.[Name] AND ecr.[year] = YEAR(UploadDate)
	--treaties currency data
	LEFT JOIN FinancialRisks.Currencies tcr ON tcr.CurrencyID = tr.CurrencyID
	--2019 Currency Exchange Rates for Treaties
	--LEFT JOIN CurrencyFXRates ttcr ON tcr.CurrencyName = ttcr.[Name] AND ttcr.[year] = YEAR(UploadDate)
	--reporting classes data
	LEFT JOIN FinancialRisks.COB cob ON cob.CobId = e.CobId
	--obligor data
	LEFT JOIN FinancialRisks.Entities en ON en.EntityId = e.ObligorEntityId
	--country data
	LEFT JOIN FinancialRisks.Countries co ON co.CountryId = e.CountryId
	--trade sector data
	LEFT JOIN FinancialRisks.TradeSector ts ON ts.TradeSectorID = en.TradeSectorId
	LEFT JOIN FinancialRisks.TradeSector tso ON tso.TradeSectorID = en.OverrideTradeSectorId
	
	WHERE 
	(en.EntityName like 'Vinci SA/%%' or en.EntityName like '3M Company/%%' or en.EntityName like 'Ministry of Defence%/%')
	and e.uploaddate='2023-06-30T00:00:00.000'	
	AND en.EntityName != 'No capital IQ ID Assigned.'
	AND (e.RiskReference IS NULL OR e.RiskReference <> '584110/01/18')
	AND e.Source NOT IN ('PTC','LMIE','GFR')
	order by en.EntityName
	and ((e.InceptionDate >= tr.InceptionDate AND e.InceptionDate <= tr.ExpiryDate) OR c.[Name] = 'LIB')


-------------------------------------------------------------------------
--Testowanie AMAZON
-------------------------------------------------------------------------



Select entityname, countryname, cobid,  *
from FinancialRisks.LossByExposure lbe
--join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
--join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where lbe.EntityName like 'Amazon%'
and ex.uploaddate='2023-06-30T00:00:00.000'
order by ex.Entityname



--Sprawdzenie warunk�w do wykonania Update Mappings
 SELECT * FROM [FinancialRisks].[MappingsStatus]

 IF ((SELECT count(*)  FROM [FinancialRisks].[MappingsStatus] where[Status] = 'Generating')=0
	and (select count(*)FROM  [FinancialRisks].[MappingsStatus] where [Status]='Complete' ) = 0)
Select 'True' as Updated
ELSE 
Select 'False' Updated

 SELECT * 
 --update ms set Status='Waiting'
 FROM [FinancialRisks].[MappingsStatus] ms



 
DROP TABLE IF EXISTS #Obligors

select ObligorID, ltrim(rtrim(ObligorName)) as 'ObligorName',ObligorPseudonymId,CountryName 
into  #Obligors from
(
	SELECT EntityId as ObligorId, rtrim(ltrim(EntityName)) as ObligorName ,'' as ObligorPseudonymId,Domicile as 'CountryName'
	FROM FinancialRisks.Entities (nolock)
	UNION
	SELECT ObligorId, rtrim(ltrim(ObligorPseudonym)) as ObligorName,ObligorPseudonymId,''as 'CountryName'
	FROM FinancialRisks.ObligorPseudonym (nolock)
)b


select * from #Obligors where ObligorName like 'Amazon/%' order by ObligorName

select * from FinancialRisks.Entities (nolock) 
where entityname like 'AMAZON.COM%'

select * from FinancialRisks.Entities (nolock) 
where entityname like 'AMAZON.COM%'


select upper(entityname),* from FinancialRisks.Entities (nolock)  where CapitalIqId in ('IQ18749','IQ24971234','IQ47949690') or entityid=3155737
select * from #Obligors where ObligorName like 'Amazon EU%' order by ObligorName


select * from FinancialRisks.Entities (nolock) where EntityName like 'Amazon eU%' 

 --Update Mappings
 exec useradmin.[dbo].[usp_start_FRED_UpdateMappings]

 exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

 exec useradmin.[dbo].[usp_check_job_history] 'FRED_UpdateMappings' 
 
exec useradmin.[dbo].[usp_start_FRED_UpdateMappings]

exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate] 





-------------------------------------------------------------------------
-- Testowanie AMAZON po upgrade Serwer�w Wrzesie? 2023
-------------------------------------------------------------------------

USE FRED

 
DROP TABLE IF EXISTS #Obligors


-- Get distinct list of all possible obligor names and their ids
SELECT ObligorID, ltrim(rtrim(ObligorName)) AS 'ObligorName', ObligorPseudonymId, CountryName, ParentCountryName
INTO  #Obligors FROM
(
	SELECT EntityId as ObligorId, RTRIM(LTRIM(EntityName)) AS ObligorName ,'' AS ObligorPseudonymId,Domicile AS 'CountryName', ParentDomicile ParentCountryName
	FROM FinancialRisks.Entities
	UNION
	SELECT ObligorId, rtrim(ltrim(ObligorPseudonym)) as ObligorName,ObligorPseudonymId,''as 'CountryName', '' ParentCountryName
	FROM FinancialRisks.ObligorPseudonym
)b


select * from #Obligors where ObligorName like 'AMAZON.com%' and (len(isnull(countryname,''))>0 or len(isnull(parentcountryname,''))>0) order by ObligorName

select * from #Obligors where ObligorName like 'Amazon %' and CountryName in ('Brasil', 'United Kingdom','Germany','Unite States','Italy','Luxembourg')

select * from FinancialRisks.Entities (nolock) 
where entityname like 'AMAZON %' and domicile in ('Brasil', 'United Kingdom','Germany','Unite States','Italy','Luxembourg')

select * from FinancialRisks.Entities (nolock) where entityid=2907345

select * from FinancialRisks.Entities (nolock) where entityname like 'AMAZON%'


select * from #Obligors where ObligorName like 'TRAFIGURA %' and (len(isnull(countryname,''))>0 or len(isnull(parentcountryname,''))>0) order by ObligorName

select * from #Obligors where ObligorName like 'Amazon %' and CountryName in ('Brasil', 'United Kingdom','Germany','Unite States','Italy','Luxembourg')

select * from #Obligors where ObligorName like 'Amazon.com/%' and CountryName in ('Germany')


exec useradmin.dbo.usp_Start_FRED_job 'FRED_UpdateMappings' 
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_check_job_history] 'FRED_UpdateMappings'

select * from FinancialRisks.ObligorPseudonym where  ObligorPseudonym like 'Amazon%'

select * from FinancialRisks.ExposuresQueue where obligorentityname like 'Amazon%'

DROP TABLE IF EXISTS #ExposuresQueue

select * 
from FinancialRisks.ExposuresQueue where CountryName='Germany'

select * from #Obligors where ObligorName like 'AMAZON.com%'




Select obligors.*, c.CountryName CountryName_Countries, eq.*
FROM   [FinancialRisks].[ExposuresQueue] eq
INNER JOIN [FinancialRisks].Countries c
    ON c.countryid = eq.countryName
    AND ISNUMERIC(eq.countryName) = 1
INNER JOIN #obligors obligors
    ON obligors.ObligorName = LTRIM(RTRIM(eq.ObligorEntityName)) + '/' + c.CountryName
WHERE  eq.[Status] = 'NEW'


Select obligors.*, c.CountryName CountryName_Countries, eq.*
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
INNER JOIN [FinancialRisks].Countries c ON c.CountryName=obligors.countryName and c.countryid=eq.countryName AND ISNUMERIC(eq.countryName) = 1 
  WHERE [Status] = 'NEW'
  and ISNUMERIC([ObligorEntityName]) = 0 --Not maped earlier



--Map those with valid IDS  and without the country but with ParentCountry
Select obligors.*, eq.*
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
  WHERE [Status] = 'NEW'
  and ISNUMERIC([ObligorEntityName]) = 0 --Not maped earlier
  and obligors.CountryName = obligors.ParentCountryName



--Map those with valid IDS  and without the country
Select obligors.*, eq.*
FROM   [FinancialRisks].[ExposuresQueue] eq
       INNER JOIN #obligors obligors
               ON obligors.ObligorName = LTRIM(RTRIM(eq.ObligorEntityName))
WHERE  [Status] = 'NEW'
       AND ISNUMERIC([ObligorEntityName]) = 0 --Not maped earlier


select *
--UPDATE [FinancialRisks].[ExposuresQueue] SET [ObligorEntityName] = obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM #ExposuresQueue eq --[FinancialRisks].[ExposuresQueue] eq
INNER JOIN [FinancialRisks].Countries c ON c.countryid=eq.countryName AND ISNUMERIC(eq.countryName) = 1
INNER JOIN #Obligors obligors ON obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName)) + '/' + c.CountryName 
WHERE [Status] = 'NEW'
--AND [CobId] = @CobId
and obligorentityname like 'Amazon%'


select *
--UPDATE [FinancialRisks].[ExposuresQueue] SET [ObligorEntityName] =obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM #ExposuresQueue eq --[FinancialRisks].[ExposuresQueue] eq
INNER JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
INNER JOIN [FinancialRisks].Countries c ON c.CountryName=obligors.countryName and c.countryid=eq.countryName AND ISNUMERIC(eq.countryName) = 1 
  WHERE [Status] = 'NEW'
  --AND [CobId] = @CobId
  and ISNUMERIC([ObligorEntityName]) = 0 --Not maped earlier
and obligorentityname like 'Amazon%'


--Map those with valid IDS  and without the country but with ParentCountry
select obligors.*, eq.*
--UPDATE [FinancialRisks].[ExposuresQueue] SET [ObligorEntityName] =obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM #ExposuresQueue eq --[FinancialRisks].[ExposuresQueue] eq
INNER JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
  WHERE [Status] = 'NEW'
  --AND [CobId] = @CobId
  and ISNUMERIC([ObligorEntityName]) = 0 --Not maped earlier
  and obligors.CountryName = obligors.ParentCountryName
  and obligorentityname like 'Amazon%'



select * from FinancialRisks.Entities (nolock) where entityname like 'AMAZON%' and Domicile='Germany'

  --Insert into FinancialRisks.ObligorPseudonym  (ObligorID,	ObligorPseudonym)  values (2741604,'Amazon.com/Germany')



  select * from FinancialRisks.Exposures where UploadDate >'20231005'



  --Update MAP Correction


  exec useradmin.dbo.usp_Start_FRED_job 'FRED_UpdateObligorMappings' 
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_check_job_history] 'FRED_UpdateObligorMappings'


 select * from [FinancialRisks].Entities where entityname like 'Vinci%'

  select op.*, e.EntityName, e.Domicile, e.ParentDomicile from [FinancialRisks].[ObligorPseudonym] op
  left join [FinancialRisks].Entities e on e.EntityId = op.ObligorID
  where [ObligorPseudonym] like 'Vinci/%'



  select top 1000 c.CountryName EX_Country, e.entityname, e.Domicile, op.*, ex.*
  from [FinancialRisks].exposures ex
  join [FinancialRisks].Entities e on e.entityid=ex.ObligorEntityId
  left join [FinancialRisks].ObligorPseudonym op on op.ObligorPseudonymId = ex.ObligorPseudID
  join [FinancialRisks].Countries c on c.CountryId = ex.CountryId
 where e.entityname like 'vinci%'
 and c.CountryName <> e.Domicile




 SELECT ObligorID
        ,ltrim(rtrim(ObligorName)) AS 'ObligorName'
        ,ObligorPseudonymId
        ,CountryName
        ,ParentCountryName
INTO  #Obligors FROM
(
	SELECT  EntityId as ObligorId
            ,RTRIM(LTRIM(EntityName)) AS ObligorName 
            ,'' AS ObligorPseudonymId
            ,Domicile AS 'CountryName'
            ,ParentDomicile ParentCountryName
	FROM FinancialRisks.Entities
	UNION
	SELECT  ObligorId
            ,rtrim(ltrim(ObligorPseudonym)) as ObligorName
            ,ObligorPseudonymId,''as 'CountryName'
            ,'' ParentCountryName
	FROM FinancialRisks.ObligorPseudonym
)b


select * from #Obligors where ObligorName like 'VINCI%/%'

select top 1000 c.CountryName EX_Country, e.entityid, e.entityname, e.Domicile, '||', obligors.*, '||', LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName, ex.ObligorEntityId, ex.ObligorPseudID, e2.EntityName, e2.Domicile

FROM  [FinancialRisks].exposures ex
INNER JOIN [FinancialRisks].Countries c ON c.countryid = ex.CountryId 
INNER JOIN [FinancialRisks].Entities e on e.entityid=ex.ObligorEntityId
INNER JOIN #obligors obligors ON obligors.ObligorName = LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName
INNER JOIN [FinancialRisks].Entities e2 on e2.entityid=obligors.ObligorId
where Obligors.ObligorName = 'VINCI SA/Poland'


select top 1000 c.CountryName EX_Country, e.entityid, e.entityname, e.Domicile, '||', obligors.*, '||', LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName, ex.ObligorEntityId, ex.ObligorPseudID, e2.EntityName, e2.Domicile

FROM  [FinancialRisks].exposures ex
INNER JOIN [FinancialRisks].Countries c ON c.countryid = ex.CountryId 
INNER JOIN [FinancialRisks].Entities e on e.entityid=ex.ObligorEntityId
left JOIN #obligors obligors ON obligors.ObligorName = LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName
LEFT JOIN [FinancialRisks].Entities e2 on e2.entityid=obligors.ObligorId
where e.EntityName like '3M%'
and c.countryName <> e.Domicile


select top 1000 c.CountryName EX_Country, e.entityid, e.entityname, e.Domicile, '||', obligors.*, '||', LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName, ex.ObligorEntityId, ex.ObligorPseudID, e2.EntityName, e2.Domicile
FROM  [FinancialRisks].exposures ex
INNER JOIN [FinancialRisks].Countries c ON c.countryid = ex.CountryId 
INNER JOIN [FinancialRisks].Entities e on e.entityid=ex.ObligorEntityId
LEFT JOIN #obligors obligors ON obligors.ObligorName = LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName
LEFT JOIN [FinancialRisks].Entities e2 on e2.entityid=obligors.ObligorId
where Obligors.ObligorName = '3M Company/Italy'




select top 1000 c.CountryName EX_Country, e.entityid, e.entityname, e.Domicile, '||', obligors.*, '||', LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName, ex.ObligorEntityId, ex.ObligorPseudID, e2.EntityName, e2.Domicile

FROM  [FinancialRisks].exposures ex
INNER JOIN [FinancialRisks].Countries c ON c.countryid = ex.CountryId 
INNER JOIN [FinancialRisks].Entities e on e.entityid=ex.ObligorEntityId
left JOIN #obligors obligors ON obligors.ObligorName = LTRIM(RTRIM(e.EntityName)) 
LEFT JOIN [FinancialRisks].Entities e2 on e2.entityid=obligors.ObligorId
where e.EntityName like  '3M%'
and c.countryName <> e.Domicile





select top 1000 c.CountryName EX_Country, e.entityid, e.entityname, e.Domicile, '||', obligors.*, '||', LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName, ex.ObligorEntityId, ex.ObligorPseudID
--update ex SET ObligorEntityId = obligors.ObligorID, ex.ObligorPseudID = obligors.ObligorPseudonymId
FROM  [FinancialRisks].exposures ex
INNER JOIN [FinancialRisks].Countries c ON c.countryid = ex.CountryId 
INNER JOIN [FinancialRisks].Entities e on e.entityid=ex.ObligorEntityId
INNER JOIN #obligors obligors ON obligors.ObligorName = LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName
where Obligors.ObligorName like 'Trafigura%'
and c.countryName <> e.Domicile


--Znajdownie przypadk�w do test�w
--Exposures
select top 1000 c.CountryName EX_Country, e.entityid, e.entityname, e.Domicile, '||', obligors.*, '||', LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName, ex.ObligorEntityId, ex.ObligorPseudID
,ex.source, ex.UploadDate
,ex.*
FROM  [FinancialRisks].exposures ex
INNER JOIN [FinancialRisks].Countries c ON c.countryid = ex.CountryId 
INNER JOIN [FinancialRisks].Entities e on e.entityid=ex.ObligorEntityId
left JOIN #obligors obligors ON obligors.ObligorName = LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName
where e.entityname like 'Trafigura%'
--and c.countryName <> e.Domicile
and c.countryName='United States'
--and ExpiryDate> getdate()
--and UploadDate='2022-09-07T00:00:00.000'
and source = 'Data_HCCUS_Surety_PriCCY.xlsx'


--ironshore
select top 1000 c.CountryName EX_Country, e.entityid, e.entityname, e.Domicile,  LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName, id.EntityId, id.ObligorPseudID
	,'||', obligors.*, '||'	
	,id.*
	--UPDATE id  SET EntityId = obligors.ObligorID,  id.ObligorPseudID = obligors.ObligorPseudonymId
    FROM FinancialRisks.Ironshore_Data id 
    INNER JOIN [FinancialRisks].Countries c ON c.countryid = id.CountryId 
    INNER JOIN [FinancialRisks].Entities e on e.entityid=id.entityid
    Left JOIN #obligors obligors ON obligors.ObligorName = LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName
    where e.entityname like 'Trafigura%'
    and 
	c.countryName <> e.Domicile
	


--McLaren

select top 1000 c.CountryName EX_Country, e.entityid, e.entityname, e.Domicile, '||', obligors.*, '||', LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName, ex.ObligorEntityId, ex.ObligorPseudID
,ex.source, ex.UploadDate
,ex.*
FROM  [FinancialRisks].exposures ex
INNER JOIN [FinancialRisks].Countries c ON c.countryid = ex.CountryId 
INNER JOIN [FinancialRisks].Entities e on e.entityid=ex.ObligorEntityId
left JOIN #obligors obligors ON obligors.ObligorName = LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName
where e.entityname like 'McLaren%'
--and c.countryName <> e.Domicile
and c.countryName='United States'
--and ExpiryDate> getdate()
--and UploadDate='2022-09-07T00:00:00.000'
and source = 'Data_HCCUS_Surety_PriCCY.xlsx'




select top 1000 c.CountryName EX_Country, e.entityid, e.entityname, e.Domicile, '||', obligors.*, '||', LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName, ex.ObligorEntityId, ex.ObligorPseudID
,ex.source, ex.UploadDate
,ex.*
FROM  [FinancialRisks].exposures ex
INNER JOIN [FinancialRisks].Countries c ON c.countryid = ex.CountryId 
INNER JOIN [FinancialRisks].Entities e on e.entityid=ex.ObligorEntityId
left JOIN #obligors obligors ON obligors.ObligorName = LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName
where e.entityname like 'McLaren%'
--and c.countryName <> e.Domicile
and c.countryName in ('Bahrain', 'Brazil')
--and ExpiryDate> getdate()