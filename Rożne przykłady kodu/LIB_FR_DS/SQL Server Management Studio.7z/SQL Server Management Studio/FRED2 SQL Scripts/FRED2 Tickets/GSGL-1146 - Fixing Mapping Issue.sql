--Testing on UAT

use FRED



select * from FinancialRisks.ExposuresQueue -- empty

exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate]

--checking 
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_check_job_history] 'FRED_QuarterUpdate'





select * from FinancialRisks.ExposuresQueue


select * from FinancialRisks.CountryPseudonym cp
join FinancialRisks.Countries c on c.countryid=cp.countryid
where cp.countrypseudonym in (
'Bulgaria, People`s Republic of',
'Congo, People`s Republic of',
'Cote D`Ivoire, Ivory Coast, Republic of the',
'Lao People`s Democratic Republic of'
)

select * from FinancialRisks.CountryPseudonym cp
join FinancialRisks.Countries c on c.countryid=cp.countryid
where cp.countrypseudonym in (
'Bulgaria, Peoples Republic of',
'Congo, Peoples Republic of',
'Cote DIvoire, Ivory Coast, Republic of the',
'Lao Peoples Democratic Republic of'
)

--Wrzucenie plik�w i Mapuj?cych i 

exec useradmin.[dbo].[usp_start_FRED_UpdateMappings]

exec useradmin.[dbo].[usp_check_job_history] 'FRED_UpdateMappings'

exec useradmin.[dbo].[usp_Start_FRED_IdentifyMappings]

select * from  [FinancialRisks].[MappingsStatus] 

IF ((SELECT count(*)  FROM [FinancialRisks].[MappingsStatus] where[Status] = 'Generating')=0
	and (select count(*)FROM  [FinancialRisks].[MappingsStatus] where [Status]='Complete' ) = 0)
Select 'True' as Updated
ELSE 
Select 'False' Updated



	IF ((SELECT Count(*) FROM  [FinancialRisks].[MappingsStatus] WHERE [Status] = 'Generating') = 0
		AND	 (SELECT DISTINCT [Status] FROM  [FinancialRisks].[MappingsStatus] WHERE [MappingType] ='Entities' ) = 'WAITING'
	   )
	
	select 'IdentityMapping'
	else 

	select 'kupa'




SELECT CountryID, CountryName,CountryPseudonymId into #country from
(
	SELECT CountryId, CountryName,''as CountryPseudonymId
	FROM FinancialRisks.Countries
	UNION
	SELECT CountryId, CountryPseudonym AS CountryName,CountryPseudonymId
	FROM FinancialRisks.CountryPseudonym
)a

select * 
--UPDATE [FinancialRisks].[ExposuresQueue]
--set [CountryName] =countries.CountryID ,CountryPseudID=countries.CountryPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #country countries on countries.CountryName = [FinancialRisks].[fn_RemoveBadChar](eq.CountryName)
  WHERE [Status] = 'NEW'
  AND [CobId] = @CobId



  select * from [FinancialRisks].Cedant where name='AXA COLOMBIA SURETY XL'