select * from [FinancialRisks].[TradeSector] where TradeSectorName like '%State%'

select * from FinancialRisks.Entities e
join  [FinancialRisks].[TradeSector] ts on ts.TradeSectorID=e.TradeSectorId
where ts.TradeSectorName='State Owned Entity'


select * from FinancialRisks.Entities e where  TradeSectorID=261


