--Przed Odtworzeniem bazy danych PROD na UAT
-Draft Dokumentacji

https://libertymutual.atlassian.net/wiki/pages/resumedraft.action?draftId=1033104625&draftShareId=29a2e019-bc01-4cb9-88b9-6431d1a4b77d

USE FRED

select c.Countryname Exposure_Country, en.entityname, en.Domicile,  count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where en.Entityname like 'Ministry of Defence%'
and ex.uploaddate >='2023-09-01T00:00:00.000'
and c.Countryname in ('Singapore')
--and c.Countryname <> isnull(en.Domicile,'')
group by  c.Countryname, en.entityname,uploaddate, en.Domicile
order by  uploaddate desc, en.entityname, c.Countryname


--Singapore Defence

select obligorentityid,c.Countryname Exposure_Country, en.entityname, en.Domicile,  ex.uploaddate, 
[Original Entity in File],
[Original Entity in File - Actual],
[Original Entity in File - Derived],
ex.CapitalIqId, 
ex.Source
from FinancialRisks.vw_ExposureOverview ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where en.Entityname like 'Ministry of Defence%'
and c.Countryname in ('Singapore')
--and c.Countryname <> isnull(en.Domicile,'')
order by  ex.uploaddate desc, en.entityname, c.Countryname




select * from  FinancialRisks.Entities where entityname like 'Ministry of Defence%Singapore'



select * from  FinancialRisks.ObligorPseudonym where ObligorPseudonym like 'Ministry%Defence%Singapore%'


exec UserAdmin.dbo.[usp_start_FRED_job] 'FRED_UpdateObligorMappings'
exec UserAdmin.[dbo].[usp_check_agent_jobs_currently_running]
exec UserAdmin.dbo.[usp_start_FRED_job] 'FRED_GenerateLossByExposure'



--Singapore Cyprus



select obligorentityid, c.Countryname Exposure_Country, en.entityname, en.Domicile, 
[Original Entity in File],
[Original Entity in File - Actual],
[Original Entity in File - Derived],
ex.CapitalIqId, 
count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate

from FinancialRisks.vw_ExposureOverview ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where en.Entityname like 'Ministry of Defence%'
and c.Countryname in ('Cyprus')
--and c.Countryname <> isnull(en.Domicile,'')
group by  c.Countryname, en.entityname,uploaddate, en.Domicile, obligorentityid,[Original Entity in File],[Original Entity in File - Actual],[Original Entity in File - Derived],ex.CapitalIqId
order by  uploaddate desc, en.entityname, c.Countryname



select obligorentityid,c.Countryname Exposure_Country, en.entityname, en.Domicile,  ex.uploaddate, 
[Original Entity in File],
[Original Entity in File - Actual],
[Original Entity in File - Derived],
ex.CapitalIqId, 
ex.Source

from FinancialRisks.vw_ExposureOverview ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where en.Entityname like 'Ministry of Defence%'
and c.Countryname in ('Cyprus')
--and c.Countryname <> isnull(en.Domicile,'')
order by  ex.uploaddate desc, en.entityname, c.Countryname

select * from  FinancialRisks.Entities where entityname like 'Ministry of Defence'

select * from  FinancialRisks.Entities where entityname like 'Ministry of Defence%Cyprus'

select * from  FinancialRisks.ObligorPseudonym where ObligorPseudonym like 'Ministry%Defence%Cyprus%'


exec UserAdmin.dbo.[usp_start_FRED_job] 'FRED_UpdateObligorMappings'
exec UserAdmin.[dbo].[usp_check_agent_jobs_currently_running]
exec UserAdmin.dbo.[usp_start_FRED_job] 'FRED_GenerateLossByExposure'
