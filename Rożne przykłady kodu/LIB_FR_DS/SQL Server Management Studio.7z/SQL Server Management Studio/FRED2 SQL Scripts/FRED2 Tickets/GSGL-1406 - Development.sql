--select * from FinancialRisks.ExposuresQueue where ObligorEntityName in (

select * from FinancialRisks.Entities where EntityName in (
'A & M Fire Protection Inc.',
'Alexandra R. Kingzett',
'All in 1 Home Improvement , Inc. Dba All in 1 Commercial Roofs',
'Allen W Cochran, Jr.',
'American Mini Market Inc. dba American Mini Market',
'Amy Cavallo',
'Andrea R Nilsen',
'Angela J. Monk',
'ANGELA JEAN WALKER DIXON',
'Anne Hollis Bass',
'Anthony''s Exotics KC, LLC',
'Apexx Builders, LLC dba Apexx Homes',
'AT Speed Motorsports Inc',
'Austin Powersports Inc. dba Family Powersports Austin',
'Baum, Avrohom Yeshaya',
'Big Mick''s Mobile Wash and Detail Center dba Big Mick''s Complete Remodeling',
'Bilal Muhammad',
'Bogdana Burlacu',
'BRANDY WOZNIAK'
)


select * from FinancialRisks.ObligorPseudonym where ObligorPseudonym in (
'A & M Fire Protection Inc.',
'Alexandra R. Kingzett',
'All in 1 Home Improvement , Inc. Dba All in 1 Commercial Roofs',
'Allen W Cochran, Jr.',
'American Mini Market Inc. dba American Mini Market',
'Amy Cavallo',
'Andrea R Nilsen',
'Angela J. Monk',
'ANGELA JEAN WALKER DIXON',
'Anne Hollis Bass',
'Anthony''s Exotics KC, LLC',
'Apexx Builders, LLC dba Apexx Homes',
'AT Speed Motorsports Inc',
'Austin Powersports Inc. dba Family Powersports Austin',
'Baum, Avrohom Yeshaya',
'Big Mick''s Mobile Wash and Detail Center dba Big Mick''s Complete Remodeling',
'Bilal Muhammad',
'Bogdana Burlacu',
'BRANDY WOZNIAK'
)


exec UserAdmin.dbo.[usp_start_FRED_job] 'FRED_UpdateMappings'



select * from FinancialRisks.Entities where entityid=3146080

select * from FinancialRisks.Entities where CapitalIqId=''

select * 
--delete
from FinancialRisks.ObligorPseudonym where ObligorID=3146080



select nullif(ltrim(rtrim(CapitalIqId)),'') , *
--update e set CapitalIqId = null
--delete from e 
from FinancialRisks.Entities e where ltrim(rtrim(CapitalIqId)) =''


select * 
--delete
from FinancialRisks.ObligorPseudonym where ObligorID in (
	select e.EntityId
	from FinancialRisks.Entities e where ltrim(rtrim(CapitalIqId)) =''

)


CREATE TABLE [FinancialRisks].[ObligorPseudonymsTemp](
	[UnmappedObligorName] [varchar](255) NULL,
	[ObligorID] int NULL,
	[PesudonymOrNew] [varchar](9)  NULL,
	[MappedObligorName] [varchar](255) NULL,
	[EntityName] [varchar](255) NULL,
	[ParentEntityName] [varchar](255) NULL,
	[CapitalIqId] [varchar](30) NULL,
	[ParentCapitalIqId] [varchar](30) NULL,
	[SPRating] [varchar](30) NULL,
	[GCHPRating] [varchar](30) NULL,
	[LibertyRating] [varchar](30) NULL,
	[TradeSectorName] [varchar](100) NULL,
	[ParentSPRating] [varchar](30) NULL,
	[ParentGCHPRating] [varchar](30) NULL,
	[ParentLibertyRating] [varchar](30) NULL,
	[Domicile] [varchar](100) NULL,
	[ParentDomicile] [varchar](100) NULL,
	[DefaultTradeSectorName] [varchar](100) NULL,
	[DefaultDomicile]	[varchar](100) NULL,
	[DefaultRating]	[varchar](30) NULL,
	[OverrideTradeSectorName] [varchar](100) NULL,
	[OverrideDomicile]	[varchar](100) NULL,
	[OverrideRating]	[varchar](30) NULL
) ON [PRIMARY]
GO

insert into [FinancialRisks].[ObligorPseudonymsTemp]([UnmappedObligorName], [GCHPRating], [ParentSPRating]) values('empty', '', '1')


select * from [FinancialRisks].[ObligorPseudonymsTemp]

UPDATE  [FinancialRisks].[ObligorPseudonymsTemp]
SET		ObligorID				=nullif(ltrim(rtrim(ObligorID)),''),
		PesudonymOrNew			=nullif(ltrim(rtrim(PesudonymOrNew)),''),
		MappedObligorName		=nullif(ltrim(rtrim(MappedObligorName)),''),
		EntityName				=nullif(ltrim(rtrim(EntityName)),''),
		ParentEntityName		=nullif(ltrim(rtrim(ParentEntityName)),''),
		CapitalIqId				=nullif(ltrim(rtrim(CapitalIqId)),''),
		ParentCapitalIqId		=nullif(ltrim(rtrim(ParentCapitalIqId)),''),
		SPRating				=nullif(ltrim(rtrim(SPRating)),''),
		GCHPRating				=nullif(ltrim(rtrim(GCHPRating)),''),
		LibertyRating			=nullif(ltrim(rtrim(LibertyRating)),''),
		TradeSectorName			=nullif(ltrim(rtrim(TradeSectorName)),''),
		ParentSPRating			=nullif(ltrim(rtrim(ParentSPRating)),''),
		ParentGCHPRating		=nullif(ltrim(rtrim(ParentGCHPRating)),''),
		ParentLibertyRating		=nullif(ltrim(rtrim(ParentLibertyRating)),''),
		Domicile				=nullif(ltrim(rtrim(Domicile)),''),
		ParentDomicile			=nullif(ltrim(rtrim(ParentDomicile)),''),
		DefaultTradeSectorName	=nullif(ltrim(rtrim(DefaultTradeSectorName)),''),
		DefaultDomicile			=nullif(ltrim(rtrim(DefaultDomicile)),''),
		DefaultRating			=nullif(ltrim(rtrim(DefaultRating)),''),
		OverrideTradeSectorName =nullif(ltrim(rtrim(OverrideTradeSectorName)),''),
		OverrideDomicile		=nullif(ltrim(rtrim(OverrideDomicile)),''),
		OverrideRating			=nullif(ltrim(rtrim(OverrideRating)),'')


--DataFIX

--UPDATE en 
	SET CapitalIqId = NULLIF(LTRIM(RTRIM(CapitalIqId)),'')
	, ParentEntityName = NULLIF(LTRIM(RTRIM(ParentEntityName)),'')
	, ParentCapitalIqId = NULLIF(LTRIM(RTRIM(ParentEntityName)),'')
FROM FinancialRisks.Entities en 
WHERE LTRIM(RTRIM(CapitalIqId)) ='' or LTRIM(RTRIM(ParentEntityName)) = '' or LTRIM(RTRIM(ParentCapitalIqId)) = ''
