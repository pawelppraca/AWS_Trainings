--GSGL-779


select  riskCodeMappings.*, e.*
	FROM FinancialRisks.Exposures e
	--exposure riskcode mappings
	LEFT JOIN FinancialRisks.RiskCodeMappings riskCodeMappings ON riskCodeMappings.riskCode = e.RiskCode 
where len(ltrim(rtrim(e.RiskCode))) <> len(e.RiskCode) 



select  riskCodeMappings.*, e.*
	FROM FinancialRisks.Exposures e
	--exposure riskcode mappings
	LEFT JOIN FinancialRisks.RiskCodeMappings riskCodeMappings ON riskCodeMappings.riskCode = ltrim(rtrim(e.RiskCode))
where len(ltrim(rtrim(e.RiskCode))) <> len(e.RiskCode) 
order by UploadDate desc

select * from  FinancialRisks.Exposures e where e.RiskCode is null


select count(*) from FinancialRisks.LossByExposure



--W Piatek 15.07 9:40
--Execute Procedure [GenerateLossByExposure_byPP] ...DONE  czas trwania 34:22 
exec [FinancialRisks].[GenerateLossByExposure_byPP] 

--Export Danych Zapisac wyniki do tabeli... DONE


--Execute Procedure [GenerateLossByExposure]  Friday 15.07.2022 10:35 .... working_time 1:25:53
exec [FinancialRisks].[GenerateLossByExposure] 

--Export Danych Zapisac wyniki do tabeli ....
select * 
from [FinancialRisks].[vw_ExposureOverview]

select * 
from [FinancialRisks].[Exposures]


