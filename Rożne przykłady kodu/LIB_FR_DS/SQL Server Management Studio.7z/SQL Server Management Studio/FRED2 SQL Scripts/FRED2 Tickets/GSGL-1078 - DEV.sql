--Alter Tables in DEV

alter table FinancialRisks.ExposuresQueue alter column [RiskReference] varchar(2048)
alter table FinancialRisks.Exposures alter column [RiskReference] varchar(2048)
alter table FinancialRisks.ExposuresQueue alter column [ObligorEntityName] varchar(255)

alter table FinancialRisks.ExposuresQueue alter column LocalId varchar(2048)
alter table FinancialRisks.Exposures alter column LocalId varchar(2048)



select * from FinancialRisks.Exposures where Source='LMIE' and len(localid) > 20


select localid, [RiskReference], * from FinancialRisks.ExposuresQueue (nolock) where len(localid) > 20 or len([RiskReference])>10

--truncate table FinancialRisks.ExposuresQueue


alter table FinancialRisks.ExposuresQueue drop column [LocalID_txt]
alter table FinancialRisks.Exposures drop column [LocalID_txt]



select distinct localid, [LocalID_txt] from FinancialRisks.Exposures (nolock) where len([LocalID_txt])>8





--NA SIT

select localid, [RiskReference], * from FinancialRisks.ExposuresQueue (nolock) where len(localid) > 20 or len([RiskReference])>10


--On UAT

select localid, [RiskReference], * from FinancialRisks.ExposuresQueue (nolock) where len(localid) > 20 or len([RiskReference])>10