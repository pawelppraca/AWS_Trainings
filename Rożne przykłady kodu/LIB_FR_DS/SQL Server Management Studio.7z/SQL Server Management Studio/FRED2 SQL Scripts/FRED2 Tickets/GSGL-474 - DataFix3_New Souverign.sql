--DataFix3

--KOPIA Zapasowa tabel
--select * into [FinancialRisks].[Exposures_2021_2022_GSGL474_PROD_BAK] from [FinancialRisks].[Exposures_2021_2022_GSGL474_PROD]
--select * into [FinancialRisks].[Entities_GSGL474_PROD_BAK] from [FinancialRisks].[Entities_GSGL474_PROD]
--select * into [FinancialRisks].[ObligorPseudonym_GSGL474_PROD_BAK] from [FinancialRisks].[ObligorPseudonym_GSGL474_PROD]

--Ministry Obligors without Country Name

select distinct replace(EntityName,FinancialRisks.fn_CountryName_in_Input(EntityName),'') ,count(9)
from financialrisks.Entities_GSGL474_PROD e where LOWER(EntityName) LIKE '%ministry%'  
group by replace(EntityName,FinancialRisks.fn_CountryName_in_Input(EntityName),'')
order by replace(EntityName,FinancialRisks.fn_CountryName_in_Input(EntityName),'')



select FinancialRisks.fn_CountryName_in_Input(EntityName)  Country,* 
from financialrisks.Entities_GSGL474_PROD e
where LOWER(EntityName) LIKE '%ministry%' 
	--and (LOWER(EntityName) LIKE '%finance%' OR LOWER(EntityName) LIKE '%defence%' OR	LOWER(EntityName) LIKE '%defense%' OR LOWER(EntityName) LIKE '%national guard%' OR	LOWER(EntityName) LIKE '%economy%')
--and FinancialRisks.fn_CountryName_in_Input(EntityName) is null
and replace(EntityName,FinancialRisks.fn_CountryName_in_Input(EntityName),'')='GOVT OF  MINISTRY OF'


--Tabelka z Nazwami Ministerstw
--drop table #Ministry
--drop table #Entities


create table #Ministry (id int not null Identity(1,1),Name nvarchar(100), quantity int, done int)
insert into #Ministry (Name) values ('Ministry Of Defence'),('Ministry of Finance'),('Ministry of Economy'),('Ministry of National Guard'),('Ministry of Investments and Foreign Trade'),('Ministry of Oil & Gas'),('MINISTRY OF AGRICULUTURE'),('Ministry of Energy and Water'),('Ministry of Health'),('MINISTRY OF AGRICULUTURE'),('Water Resources and Energy'),('Ministry of Transport and Communications'),('MINISTRY OF PUBLIC WORKS')

select * from #Ministry

--update #Ministry set quantity=null, done = null

--Tabelka robocza
CREATE TABLE #Entities(
	[EntityId] [int] NOT NULL identity(1,1),
	[EntityName] [varchar](255) NOT NULL,
	[ParentEntityName] [varchar](255) NULL,
	[CapitalIqId] [varchar](30) NULL,
	[ParentCapitalIqId] [varchar](30) NULL,
	[SPRating] [varchar](30) NULL,
	[GCHPRating] [varchar](30) NULL,
	[LibertyRating] [varchar](30) NULL,
	[TradeSectorId] [int] NULL,
	[ParentSPRating] [varchar](30) NULL,
	[ParentGCHPRating] [varchar](30) NULL,
	[ParentLibertyRating] [varchar](30) NULL,
	[Domicile] [varchar](100) NULL,
	[ParentDomicile] [varchar](100) NULL,
	[DefaultTradeSectorId] [int] NULL,
	[DefaultDomicile] [varchar](100) NULL,
	[DefaultRating] [varchar](30) NULL,
	[OverrideTradeSectorId] [int] NULL,
	[OverrideDomicile] [varchar](100) NULL,
	[OverrideRating] [varchar](30) NULL
) ON [PRIMARY]
GO





select * from [FinancialRisks].Countries where len(CountryCapitalIqId)>0

--Tworzenie ministerstw krajow
declare @Name_min nvarchar(100), @min_id int, @min_qty int, @new_ent_qty int

select @min_qty = count(*) from #Ministry where Done is  null

while @min_qty > 0
begin
	select top 1 @Name_min = name, @min_id=id from #Ministry where Done is null

	--insert into [FinancialRisks].[Entities_GSGL474_PROD] (EntityName,ParentEntityName,Domicile,ParentDomicile,DefaultTradeSectorId,OverrideTradeSectorId)
	insert into #Entities (EntityName,ParentEntityName,Domicile,ParentDomicile,DefaultTradeSectorId,OverrideTradeSectorId)
	select @Name_min +' ('+CountryName+')', @Name_min +' ('+CountryName+')',CountryName,CountryName,262,262  from [FinancialRisks].Countries where len(CountryCapitalIqId)>0

	set @new_ent_qty = @@ROWCOUNT

	update #Ministry set quantity = @new_ent_qty, done=1 where id = @min_id

	select @min_qty = count(*) from #Ministry where Done is null

end


select * from #Ministry
select * from #Entities order by EntityId 

--Tabela konwersji

select * from #Entities e 
join [FinancialRisks].Countries c on c.CountryName = e.Domicile
where e.DefaultTradeSectorId =262 and  e.OverrideTradeSectorId=262
and LOWER(EntityName) LIKE '%defence%'
and e.Domicile='Bangladesh'

	select FinancialRisks.fn_CountryName_in_Input(EntityName)  Country,*
	from financialrisks.Entities_GSGL474_PROD e
	where LOWER(EntityName) LIKE '%ministry%' and LOWER(EntityName) LIKE '%defence%'
	and FinancialRisks.fn_CountryName_in_Input(EntityName) is not null
	and FinancialRisks.fn_CountryName_in_Input(EntityName) ='Bangladesh'
	order by FinancialRisks.fn_CountryName_in_Input(EntityName) 


--POPRZEDNIA WERSJA
--select e.country CountryName_from_Entity, e.EntityName, m.EntityName MinistryName, m.Domicile Ministry_Domicile, m.countryid, e.EntityId Old_EntityID, m.EntityId NEW_EntityID
--into #Defence_Ministry_convert
--from (
--	select FinancialRisks.fn_CountryName_in_Input(EntityName)  Country,*
--	from financialrisks.Entities_GSGL474_PROD e
--	where LOWER(EntityName) LIKE '%ministry%' and LOWER(EntityName) LIKE '%defence%'
--	and FinancialRisks.fn_CountryName_in_Input(EntityName) is not null
--) e
--join (
--	select c.CountryId, e.* 
--	from #Entities e 
--	join [FinancialRisks].Countries c on c.CountryName = e.Domicile
--	where e.DefaultTradeSectorId =262 and  e.OverrideTradeSectorId=262
--	and LOWER(EntityName) LIKE '%defence%'
--) m on e.Country = m.domicile

--select *  from #Defence_Ministry_convert

--drop table #Defence_Ministry_convert_Ex

--NOWA WERJSA TABELI KONWERSJI - DEFENCE
--rozszerzona lista Conwert zawierajaca dane z ObligorPseudonym
select e.country CountryName_from_Old_EntityName, e.EntityName OLD_EntityName, m.EntityName MinistryName, m.Domicile Ministry_Domicile, m.countryid, e.EntityId Old_EntityID, m.EntityId NEW_EntityID, e.Parent_ObligorId
into #Defence_Ministry_convert_Ex
from ( --Table with Old Ministry 
	select distinct FinancialRisks.fn_CountryName_in_Input(EntityName) Country, e.EntityId, Entityname, null Parent_ObligorId
	from financialrisks.Entities_GSGL474_PROD e
	where LOWER(EntityName) LIKE '%ministry%' and LOWER(EntityName) LIKE '%defence%'
	and FinancialRisks.fn_CountryName_in_Input(EntityName) is not null --only with country name in EntityName

	UNION 
	
	select FinancialRisks.fn_CountryName_in_Input(EntityName) Country, op.ObligorPseudonymId, ObligorPseudonym, ObligorId Parent_ObligorId
	from financialrisks.Entities_GSGL474_PROD e
	join  [FinancialRisks].[ObligorPseudonym_GSGL474_PROD] op on op.obligorid=e.entityid
	where LOWER(EntityName) LIKE '%ministry%' and LOWER(EntityName) LIKE '%defence%'
	and FinancialRisks.fn_CountryName_in_Input(EntityName) is not null --only with country name in EntityName

) e
join ( --Table with new Ministry (Country)
	select c.CountryId, e.* 
	from #Entities e 
	join [FinancialRisks].Countries c on c.CountryName = e.Domicile
	where e.DefaultTradeSectorId =262 and  e.OverrideTradeSectorId=262
	and LOWER(EntityName) LIKE '%defence%'
) m on e.Country = m.domicile


select * from #Defence_Ministry_convert_Ex  order by CountryName_from_Old_EntityName




select * from financialrisks.Entities_GSGL474_PROD e
join [FinancialRisks].[ObligorPseudonym_GSGL474_PROD] op on op.ObligorID=e.EntityId
where op.Obligorid in (3047510)

select * from [FinancialRisks].[ObligorPseudonym_GSGL474_PROD] where obligorid in (763272,2105019,2152481,2869297)

select * from financialrisks.Entities_GSGL474_PROD e where EntityId in (763272,2105019,2152481,2869297)

---------------------------------------------------------
--sprawdzenie Exposure dla Min of Def Sudi Arabia
---------------------------------------------------------

select * from #Defence_Ministry_convert_Ex mod_ex
join financialrisks.Entities_GSGL474_PROD e on e.EntityId=mod_ex.Old_EntityId
left join financialrisks.ObligorPseudonym_GSGL474_PROD op on e.EntityId=mod_ex.Parent_ObligorId
where CountryId=179

--Plan zmian dla przypadku gdy Kraj nowego Ministry jest z godny z krajem Exposure
select c.CountryName ExposureCountry, e.EntityName Exposure_Obligor_name, parent.EntityName Parent_ObligorName, '|***|', mod_ex.*,  '|***|', ex.* 
from [FinancialRisks].[Exposures_2021_2022_GSGL474_PROD] ex
join [FinancialRisks].Countries_GSGL474_PROD c on c.CountryId=ex.CountryId
join financialrisks.Entities_GSGL474_PROD e on e.EntityId=ex.ObligorEntityId
join #Defence_Ministry_convert_Ex mod_ex on  mod_ex.Old_EntityID = ex.ObligorEntityId  and ex.CountryId = mod_ex.CountryId
left join financialrisks.Entities_GSGL474_PROD parent on parent.EntityId=mod_ex.Parent_ObligorId
--left join [FinancialRisks].[ObligorPseudonym_GSGL474_PROD] op on op.ObligorPseudonymId = ex.ObligorPseudID
--where mod_ex.CountryId=176
order by Ministry_Domicile


--Plan zmian dla przypadku gdy Kraj nowego Ministry NIE jest z godny z krajem Exposure
select c.CountryName ExposureCountry, e.EntityName Exposure_Obligor_name, parent.EntityName Parent_ObligorName, '|***|', mod_ex.*,  '|***|', ex.* 
from [FinancialRisks].[Exposures_2021_2022_GSGL474_PROD] ex
join [FinancialRisks].Countries_GSGL474_PROD c on c.CountryId=ex.CountryId
join financialrisks.Entities_GSGL474_PROD e on e.EntityId=ex.ObligorEntityId
join #Defence_Ministry_convert_Ex mod_ex on  mod_ex.Old_EntityID = ex.ObligorEntityId and ex.CountryId <> mod_ex.CountryId
left join financialrisks.Entities_GSGL474_PROD parent on parent.EntityId=mod_ex.Parent_ObligorId
--left join [FinancialRisks].[ObligorPseudonym_GSGL474_PROD] op on op.ObligorPseudonymId = ex.ObligorPseudID
--where mod_ex.CountryId=176
where Parent_ObligorId = 2362998
order by Ministry_Domicile


select * from #Defence_Ministry_convert_Ex where Parent_ObligorId = 2362998

select * from #Defence_Ministry_convert_Ex where Old_EntityID = 2362998




-----------------------------------------------------------
--NOWA WERJSA TABELI KONWERSJI - FINANCE
-----------------------------------------------------------

--drop table #Finance_Ministry_convert_Ex

--rozszerzona lista Conwert zawierajaca dane z ObligorPseudonym
select e.country CountryName_from_Old_EntityName, e.EntityName OLD_EntityName, m.EntityName MinistryName, m.Domicile Ministry_Domicile, m.countryid, e.EntityId Old_EntityID, m.EntityId NEW_EntityID, e.Parent_ObligorId
into #Finance_Ministry_convert_Ex
from ( --Table with Old Ministry 
	select distinct FinancialRisks.fn_CountryName_in_Input(EntityName) Country, e.EntityId, Entityname, null Parent_ObligorId
	from financialrisks.Entities_GSGL474_PROD e
	where LOWER(EntityName) LIKE '%ministry%' and LOWER(EntityName) LIKE '%finance%'
	and FinancialRisks.fn_CountryName_in_Input(EntityName) is not null --only with country name in EntityName

	UNION 
	
	select FinancialRisks.fn_CountryName_in_Input(EntityName) Country, op.ObligorPseudonymId, ObligorPseudonym, ObligorId Parent_ObligorId
	from financialrisks.Entities_GSGL474_PROD e
	join  [FinancialRisks].[ObligorPseudonym_GSGL474_PROD] op on op.obligorid=e.entityid
	where LOWER(EntityName) LIKE '%ministry%' and LOWER(EntityName) LIKE '%finance%'
	and FinancialRisks.fn_CountryName_in_Input(EntityName) is not null --only with country name in EntityName

) e
join ( --Table with new Ministry (Country)
	select c.CountryId, e.* 
	from #Entities e 
	join [FinancialRisks].Countries c on c.CountryName = e.Domicile
	where e.DefaultTradeSectorId =262 and  e.OverrideTradeSectorId=262
	and LOWER(EntityName) LIKE '%finance%'
) m on e.Country = m.domicile



--Plan zmian dla przypadku gdy Kraj nowego Ministry jest z godny z krajem Exposure
select  c.CountryName ExposureCountry, e.EntityName Exposure_Obligor_name, parent.EntityName Parent_ObligorName, '|***|', mof_ex.*,  '|***|', ex.* 
from [FinancialRisks].[Exposures_2021_2022_GSGL474_PROD] ex
join [FinancialRisks].Countries_GSGL474_PROD c on c.CountryId=ex.CountryId
join financialrisks.Entities_GSGL474_PROD e on e.EntityId=ex.ObligorEntityId
join #Finance_Ministry_convert_Ex mof_ex on  mof_ex.Old_EntityID = ex.ObligorEntityId and ex.CountryId = mof_ex.CountryId --the same countries
left join financialrisks.Entities_GSGL474_PROD parent on parent.EntityId=mof_ex.Parent_ObligorId
--left join [FinancialRisks].[ObligorPseudonym_GSGL474_PROD] op on op.ObligorPseudonymId = ex.ObligorPseudID
--where mod_ex.CountryId=176
order by Ministry_Domicile


select distinct Parent_ObligorId , e.EntityName
from #Finance_Ministry_convert_Ex ex
join financialrisks.Entities_GSGL474_PROD e on e.EntityId = ex.Parent_ObligorId


select c.CountryName ExposureCountry, e.EntityName Exposure_Obligor_name, parent.EntityName Parent_ObligorName, '|***|', mof_ex.*,  '|***|', ex.* 
--select distinct mof_ex.Parent_ObligorId
from [FinancialRisks].[Exposures_2021_2022_GSGL474_PROD] ex
join [FinancialRisks].Countries_GSGL474_PROD c on c.CountryId=ex.CountryId
join financialrisks.Entities_GSGL474_PROD e on e.EntityId=ex.ObligorEntityId
join #Finance_Ministry_convert_Ex mof_ex on  mof_ex.Old_EntityID = ex.ObligorEntityId and ex.CountryId <> mof_ex.CountryId --different countries
left join financialrisks.Entities_GSGL474_PROD parent on parent.EntityId=mof_ex.Parent_ObligorId
--left join [FinancialRisks].[ObligorPseudonym_GSGL474_PROD] op on op.ObligorPseudonymId = ex.ObligorPseudID
--where mod_ex.CountryId=176
where mof_ex.Parent_ObligorId is not null
order by Ministry_Domicile


--Wrong Pseudonym Mampping - example
select op.*, e1.EntityId, e1.EntityName,  e2.EntityId, e2.EntityName
from [FinancialRisks].[ObligorPseudonym_GSGL474_PROD] op
join financialrisks.Entities_GSGL474_PROD e1 on e1.EntityId = op.ObligorID
join financialrisks.Entities_GSGL474_PROD e2 on e2.EntityId = op.ObligorPseudonymId
where op.ObligorID in (2919521, 8234)
order by op.ObligorID

--Wrong Pseudonym Mampping - examples
select op.*, e1.EntityId, e1.EntityName,  e2.EntityId Pseudonym, e2.EntityName PseudonymName
from [FinancialRisks].[ObligorPseudonym_GSGL474_PROD] op
join financialrisks.Entities_GSGL474_PROD e1 on e1.EntityId = op.ObligorID
join financialrisks.Entities_GSGL474_PROD e2 on e2.EntityId = op.ObligorPseudonymId
where op.ObligorID in (6850,7082,7109,10428,10429,15612,1739615)
order by op.ObligorID


select op.*, e1.EntityId, e1.EntityName,  e2.EntityId Pseudonym, e2.EntityName PseudonymName
from [FinancialRisks].[ObligorPseudonym_GSGL474_PROD] op
left join financialrisks.Entities_GSGL474_PROD e1 on e1.EntityId = op.ObligorID
left join financialrisks.Entities_GSGL474_PROD e2 on e2.EntityId = op.ObligorPseudonymId
where op.ObligorPseudonymId in (36945, 36969, 36945)
order by op.ObligorID



-----------------------------------------------------------
--NOWA WERJSA TABELI KONWERSJI - ECONOMY
-----------------------------------------------------------

--drop table #Finance_Ministry_convert_Ex

--rozszerzona lista Conwert zawierajaca dane z ObligorPseudonym
select e.country CountryName_from_Old_EntityName, e.EntityName OLD_EntityName, m.EntityName MinistryName, m.Domicile Ministry_Domicile, m.countryid, e.EntityId Old_EntityID, m.EntityId NEW_EntityID, e.Parent_ObligorId
into #Economy_Ministry_convert_Ex
from ( --Table with Old Ministry 
	select distinct FinancialRisks.fn_CountryName_in_Input(EntityName) Country, e.EntityId, Entityname, null Parent_ObligorId
	from financialrisks.Entities_GSGL474_PROD e
	where LOWER(EntityName) LIKE '%ministry%' and LOWER(EntityName) LIKE '%economy%'
	and FinancialRisks.fn_CountryName_in_Input(EntityName) is not null --only with country name in EntityName

	UNION 
	
	select FinancialRisks.fn_CountryName_in_Input(EntityName) Country, op.ObligorPseudonymId, ObligorPseudonym, ObligorId Parent_ObligorId
	from financialrisks.Entities_GSGL474_PROD e
	join  [FinancialRisks].[ObligorPseudonym_GSGL474_PROD] op on op.obligorid=e.entityid
	where LOWER(EntityName) LIKE '%ministry%' and LOWER(EntityName) LIKE '%economy%'
	and FinancialRisks.fn_CountryName_in_Input(EntityName) is not null --only with country name in EntityName

) e
join ( --Table with new Ministry (Country)
	select c.CountryId, e.* 
	from #Entities e 
	join [FinancialRisks].Countries c on c.CountryName = e.Domicile
	where e.DefaultTradeSectorId =262 and  e.OverrideTradeSectorId=262
	and LOWER(EntityName) LIKE '%economy%'
) m on e.Country = m.domicile


select * from  #Economy_Ministry_convert_Ex

select * from [FinancialRisks].[ObligorPseudonym_GSGL474_PROD] where ObligorID=2105019
select * from [FinancialRisks].[Exposures_2021_2022_GSGL474_PROD] where ObligorEntityId=2105019 or ObligorEntityId in (select ObligorPseudonymId from [FinancialRisks].[ObligorPseudonym_GSGL474_PROD] where ObligorID=2105019)
select * from [FinancialRisks].Countries_GSGL474_PROD where CountryId=176


select FinancialRisks.fn_CountryName_in_Input(EntityName)  Country,* 
from financialrisks.Entities_GSGL474_PROD e
where LOWER(EntityName) LIKE '%ministry%' and LOWER(EntityName) LIKE '%defence%'
and FinancialRisks.fn_CountryName_in_Input(EntityName) is  null
order by FinancialRisks.fn_CountryName_in_Input(EntityName) 


select top 100 * from [FinancialRisks].[Exposures_2021_2022_GSGL474_PROD] order by ExposureId desc
select top 100 * from [FinancialRisks].[Entities_GSGL474_PROD] order by EntityId desc

select top 100 * from [FinancialRisks].[ObligorPseudonym_GSGL474_PROD] where ObligorID=8021

select * from [FinancialRisks].[Entities_GSGL474_PROD] where EntityId=8021
select top 100 * from [FinancialRisks].[Exposures_2021_2022_GSGL474_PROD] 
where ObligorEntityId=8021 
	or (ObligorEntityId in (select ObligorPseudonymId from [FinancialRisks].[ObligorPseudonym_GSGL474_PROD] where ObligorID=8021 ))

select * from [FinancialRisks].[TradeSector]

select *
from financialrisks.Entities_GSGL474_PROD e
where LOWER(EntityName) LIKE '%ministry%defence%' and DefaultTradeSectorId in (116,147)


select * from [FinancialRisks].[Exposures_2021_2022_GSGL474_PROD] where ObligorEntityId in (
	5078
)




-------------------------------------------------------------------------------
-- START DATAFIX #3  - Add new Ministry of and remap
-------------------------------------------------------------------------------

--Tabelka z Nazwami Ministerstw
create table #Ministry (Name nvarchar(100))
insert into #Ministry values ('Ministry Of Defence'),('Ministry of Finance'),('Ministry of Economy'),('Ministry of National Guard'),('Ministry of Investments and Foreign Trade'),('Ministry of Oil & Gas'),('MINISTRY OF AGRICULUTURE'),('Ministry of Energy and Water'),('Ministry of Health'),('MINISTRY OF AGRICULUTURE'),('Water Resources and Energy'),('Ministry of Transport and Communications'),('MINISTRY OF PUBLIC WORKS')

--Tworzenie ministerstw krajow
declare @Name_min nvarchar(100), @min_id int, @min_qty int, @new_ent_qty int

select @min_qty = count(*) from #Ministry where Done is  null

while @min_qty > 0
begin
	select top 1 @Name_min = name, @min_id=id from #Ministry where Done is null

	insert into [FinancialRisks].[Entities] (EntityName,ParentEntityName,Domicile,ParentDomicile,DefaultTradeSectorId,OverrideTradeSectorId)
	
	select @Name_min +' ('+CountryName+')', @Name_min +' ('+CountryName+')',CountryName,CountryName,262,262  from [FinancialRisks].Countries where len(CountryCapitalIqId)>0

	set @new_ent_qty = @@ROWCOUNT

	update #Ministry set quantity = @new_ent_qty, done=1 where id = @min_id

	select @min_qty = count(*) from #Ministry where Done is null

end


--Conversion Table - DEFENCE

select e.country CountryName_from_Old_EntityName, e.EntityName OLD_EntityName, m.EntityName MinistryName, m.Domicile Ministry_Domicile, m.countryid, e.EntityId Old_EntityID, m.EntityId NEW_EntityID, e.ParentId
into #Defence_Ministry_convert_Ex
from ( --Table with Old Ministry 
	select distinct FinancialRisks.fn_CountryName_in_Input(EntityName) Country, e.EntityId, Entityname, null ParentId
	from financialrisks.Entities e
	where LOWER(EntityName) LIKE '%ministry%' and LOWER(EntityName) LIKE '%defence%'
	and FinancialRisks.fn_CountryName_in_Input(EntityName) is not null --only with country name in EntityName

	UNION 
	
	select FinancialRisks.fn_CountryName_in_Input(EntityName) Country, op.ObligorPseudonymId, ObligorPseudonym, ObligorId ParentId
	from financialrisks.Entities e
	join  [FinancialRisks].[ObligorPseudonym] op on op.obligorid=e.entityid
	where LOWER(EntityName) LIKE '%ministry%' and LOWER(EntityName) LIKE '%defence%'
	and FinancialRisks.fn_CountryName_in_Input(EntityName) is not null --only with country name in EntityName

) e
join ( --Table with new Ministry (Country)
	select c.CountryId, e.* 
	from #Entities e 
	join [FinancialRisks].Countries c on c.CountryName = e.Domicile
	where e.DefaultTradeSectorId =262 and  e.OverrideTradeSectorId=262
	and LOWER(EntityName) LIKE '%defence%'
) m on e.Country = m.domicile





-------------------------------------------------------------------------------
-- END DATAFIX #2   - Add new Ministry of and remap
-------------------------------------------------------------------------------



-- UWAGA!!!!!!
/*
PO wykonaniu Datafixa trzeba zmodyfikowac procedure 
[FinancialRisks].[uspCleanupExposureStaging]
aby dla mapowania Obligorow Ministry uzywala dodatkowo pola Country z ExposureQueue


*/