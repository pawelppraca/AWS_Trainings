--Przed testem sprawdzenie tabel

USE FRED

select 'Table [ExposuresStaging]' Table_name, count(*) records from  [FinancialRisks].[ExposuresStaging]
select 'Table [Ironshore_Data_Queue]' Table_name, count(*) records from  [FinancialRisks].[Ironshore_Data_Queue]
select 'Table [ExposuresQueue]' Table_name, count(*) records from  [FinancialRisks].[ExposuresQueue]
select 'Table [TreatiesQueue]' Table_name, count(*) records from  [FinancialRisks].[TreatiesQueue]




-- SIT Testing

USE FRED

select 'Table [ExposuresStaging]' Table_name, count(*) records from  [FinancialRisks].[ExposuresStaging]
select 'Table [Ironshore_Data_Queue]' Table_name, count(*) records from  [FinancialRisks].[Ironshore_Data_Queue]
select 'Table [ExposuresQueue]' Table_name, count(*) records from  [FinancialRisks].[ExposuresQueue]
select 'Table [TreatiesQueue]' Table_name, count(*) records from  [FinancialRisks].[TreatiesQueue]


exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate]

exec Useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]


select 'Table [ExposuresStaging]' Table_name, count(*) records from  [FinancialRisks].[ExposuresStaging]
select 'Table [Ironshore_Data_Queue]' Table_name, count(*) records from  [FinancialRisks].[Ironshore_Data_Queue]
select 'Table [ExposuresQueue]' Table_name, count(*) records from  [FinancialRisks].[ExposuresQueue]
select 'Table [TreatiesQueue]' Table_name, count(*) records from  [FinancialRisks].[TreatiesQueue]


exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate]

exec Useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

exec Useradmin.[dbo].[usp_check_job_history] 'FRED_QuarterUpdate'


select 'Table [ExposuresStaging]' Table_name, count(*) records from  [FinancialRisks].[ExposuresStaging]
select 'Table [Ironshore_Data_Queue]' Table_name, count(*) records from  [FinancialRisks].[Ironshore_Data_Queue]
select 'Table [ExposuresQueue]' Table_name, count(*) records from  [FinancialRisks].[ExposuresQueue]
select 'Table [TreatiesQueue]' Table_name, count(*) records from  [FinancialRisks].[TreatiesQueue]


exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate]



select 'Table [ExposuresStaging]' Table_name, count(*) records from  [FinancialRisks].[ExposuresStaging]
select 'Table [Ironshore_Data_Queue]' Table_name, count(*) records from  [FinancialRisks].[Ironshore_Data_Queue]
select 'Table [ExposuresQueue]' Table_name, count(*) records from  [FinancialRisks].[ExposuresQueue]
select 'Table [TreatiesQueue]' Table_name, count(*) records from  [FinancialRisks].[TreatiesQueue]




-- UAT Testing

USE FRED

select 'Table [ExposuresStaging]' Table_name, count(*) records from  [FinancialRisks].[ExposuresStaging]
select 'Table [Ironshore_Data_Queue]' Table_name, count(*) records from  [FinancialRisks].[Ironshore_Data_Queue]
select 'Table [ExposuresQueue]' Table_name, count(*) records from  [FinancialRisks].[ExposuresQueue]
select 'Table [TreatiesQueue]' Table_name, count(*) records from  [FinancialRisks].[TreatiesQueue]

--UAT RUN without required files
exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate]

exec Useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

--UAT Check after Run Update withpout required files

select 'Table [ExposuresStaging]' Table_name, count(*) records from  [FinancialRisks].[ExposuresStaging]
select 'Table [Ironshore_Data_Queue]' Table_name, count(*) records from  [FinancialRisks].[Ironshore_Data_Queue]
select 'Table [ExposuresQueue]' Table_name, count(*) records from  [FinancialRisks].[ExposuresQueue]
select 'Table [TreatiesQueue]' Table_name, count(*) records from  [FinancialRisks].[TreatiesQueue]



--UAT RUN with  files with errors
exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate]

exec Useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]


--UAT Check after Run Update with files with errors

select 'Table [ExposuresStaging]' Table_name, count(*) records from  [FinancialRisks].[ExposuresStaging]
select 'Table [Ironshore_Data_Queue]' Table_name, count(*) records from  [FinancialRisks].[Ironshore_Data_Queue]
select 'Table [ExposuresQueue]' Table_name, count(*) records from  [FinancialRisks].[ExposuresQueue]
select 'Table [TreatiesQueue]' Table_name, count(*) records from  [FinancialRisks].[TreatiesQueue]



--UAT RUN without required files
exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate]

exec Useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

--UAT Check after Run Update withpout required files

select 'Table [ExposuresStaging]' Table_name, count(*) records from  [FinancialRisks].[ExposuresStaging]
select 'Table [Ironshore_Data_Queue]' Table_name, count(*) records from  [FinancialRisks].[Ironshore_Data_Queue]
select 'Table [ExposuresQueue]' Table_name, count(*) records from  [FinancialRisks].[ExposuresQueue]
select 'Table [TreatiesQueue]' Table_name, count(*) records from  [FinancialRisks].[TreatiesQueue]
