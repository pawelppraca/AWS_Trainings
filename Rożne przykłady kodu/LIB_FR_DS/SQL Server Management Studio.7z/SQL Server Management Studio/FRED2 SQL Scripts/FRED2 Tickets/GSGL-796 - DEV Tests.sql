--Copy Data for tests from UAT to DEV to test table

[FinancialRisks].[ExposuresQueue_GSGL_796_UAT]

--Preparing TEST DATA


update eq set countryname= null
from  [FinancialRisks].[ExposuresQueue_GSGL_796_UAT] eq
where [CobId] = 6
and [Status] = 'NEW'
and [ObligorEntityName] like '1%' --Instead of ISNUMERIC([ObligorEntityName]) = 1	



update eq set countryname= null
from  [FinancialRisks].[ExposuresQueue_GSGL_796_UAT] eq
where [CobId] = 6
and [Status] = 'NEW'
and [ObligorEntityName] like 'ATI CONSORZIO%' --Instead of ISNUMERIC([ObligorEntityName]) = 1	


-- declare @CobId int
 --set @CobId = 6
 
 select * from  [FinancialRisks].[ExposuresQueue_GSGL_796_UAT]
    where [CountryName] is null or [CountryName] =''
	and [Status] = 'NEW'
	AND [CobId] = @CobId
	and [ObligorEntityName] like 'ATI%' --ISNUMERIC([ObligorEntityName]) =1


declare @CobId int
 set @CobId = 6
 

 select * from  [FinancialRisks].[ExposuresQueue_GSGL_796_UAT]
    where ([CountryName] is null or [CountryName] ='')
	and [Status] = 'NEW'
	AND [CobId] = @CobId
	and [ObligorEntityName] like 'ATI%' --ISNUMERIC([ObligorEntityName]) =1







	create table #tab (Name varchar(30), surname varchar(30), stanowsko varchar(30))

	insert into #tab (name, surname, stanowsko) values ('Pawel','Parasyn', 'Developer')
	insert into #tab (name, surname, stanowsko) values ('Patryk','Kiepel', 'Developer')
	insert into #tab (name, surname, stanowsko) values ('Adam','Michalak', 'BI Developer')
	insert into #tab (name, surname, stanowsko) values ('Agnieszka','Koziarz', 'Leader')
	insert into #tab (name, surname, stanowsko) values ('Wojciech','Szczypka', 'Leader')


	select * from #tab 
	where name ='Agnieszka' or  name ='Adam' 
	and  stanowsko='Developer'


		select * from #tab 
	where (name ='Agnieszka' or  name ='Adam' )
	and  stanowsko='Developer'




	--Testy DEV z wykorzystaniem pliku LMIE.xlsx

	select *   --
	--delete
	from [FinancialRisks].[ExposuresQueue] where CobId=6

--part of procedure [FinancialRisks].[uspCleanupExposureStaging]

	SELECT CountryID, CountryName,CountryPseudonymId into #country from
(
	SELECT CountryId, CountryName,''as CountryPseudonymId
	FROM FinancialRisks.Countries
	UNION
	SELECT CountryId, CountryPseudonym AS CountryName,CountryPseudonymId
	FROM FinancialRisks.CountryPseudonym
)a


UPDATE [FinancialRisks].[ExposuresQueue] set [CountryName] =countries.CountryID ,CountryPseudID=countries.CountryPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #country countries on countries.CountryName = ltrim(rtrim(eq.CountryName))
  WHERE [Status] = 'NEW'
  AND [CobId] = 6

Declare @countryid int 
SET @countryid = (Select CountryID from  [FinancialRisks].[Countries]
where CountryName = 'No country name supplied')
select @countryid  -- = 230


-- Get distinct list of all possible obligor names and their ids
select ObligorID, ltrim(rtrim(ObligorName)) as 'ObligorName',ObligorPseudonymId,CountryName into  #Obligors from
(
	SELECT EntityId as ObligorId, rtrim(ltrim(EntityName)) as ObligorName ,'' as ObligorPseudonymId,Domicile as 'CountryName'
	FROM FinancialRisks.Entities
	UNION
	SELECT ObligorId, rtrim(ltrim(ObligorPseudonym)) as ObligorName,ObligorPseudonymId,''as 'CountryName'
	FROM FinancialRisks.ObligorPseudonym
)b


select * from #Obligors

--Map those with valid IDS  

UPDATE [FinancialRisks].[ExposuresQueue] set [ObligorEntityName] =obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
  WHERE [Status] = 'NEW'
  AND [CobId] = 6

  --239261

---- Map Countries based on domicile

IF @CobId = 6
begin
	select *
	--UPDATE [FinancialRisks].[ExposuresQueue] set [CountryName] =countries.CountryID
	FROM [FinancialRisks].[ExposuresQueue] eq
	inner join FinancialRisks.Entities ent on ent.EntityId = eq.ObligorEntityName
	INNER JOIN #country countries on countries.CountryName = ltrim(rtrim(ent.Domicile))
	  WHERE [Status] = 'NEW'
	  AND [CobId] = 6
	    and ISNUMERIC([ObligorEntityName]) =1

	select count(*) 
	--UPDATE eq   SET [CountryName] = 230
    from [FinancialRisks].[ExposuresQueue] eq
	where ([CountryName] is null  or [CountryName] ='')
	and [Status] = 'NEW'
	AND [CobId] = 6
	and ISNUMERIC([ObligorEntityName]) =1


		select *
	--UPDATE eq   SET [CountryName] = @countryid
    from [FinancialRisks].[ExposuresQueue] eq
	where [CountryName] is null  or [CountryName] =''
	and [Status] = 'NEW'
	AND [CobId] = 6
	and ISNUMERIC([ObligorEntityName]) =1

	--Por�wnanie



	select status, cobid, [ObligorEntityName], ISNUMERIC([ObligorEntityName]), *
	from [FinancialRisks].[ExposuresQueue] eq
	where [CountryName] is null or [CountryName] =''
	and [Status] = 'NEW'
	AND [CobId] = 6
	and ISNUMERIC([ObligorEntityName]) = 1 