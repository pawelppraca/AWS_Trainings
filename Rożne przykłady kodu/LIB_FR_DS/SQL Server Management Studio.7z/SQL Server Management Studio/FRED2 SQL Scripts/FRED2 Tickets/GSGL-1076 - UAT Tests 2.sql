USE FRED

--OBLIGORS

DROP TABLE IF EXISTS #Obligors

SELECT ObligorID
        ,ltrim(rtrim(ObligorName)) AS 'ObligorName'
        ,ObligorPseudonymId
        ,CountryName
        ,ParentCountryName
INTO  #Obligors FROM
(
	SELECT  EntityId as ObligorId
            ,RTRIM(LTRIM(EntityName)) AS ObligorName 
            ,'' AS ObligorPseudonymId
            ,Domicile AS 'CountryName'
            ,ParentDomicile ParentCountryName
	FROM FinancialRisks.Entities
	UNION
	SELECT  ObligorId
            ,rtrim(ltrim(ObligorPseudonym)) as ObligorName
            ,ObligorPseudonymId,''as 'CountryName'
            ,'' ParentCountryName
	FROM FinancialRisks.ObligorPseudonym
)b




select * from #Obligors o
join FinancialRisks.Entities en on en.entityid=o.obligorid
where o.ObligorName like '3M Company%'  order by ObligorName


select * from FinancialRisks.Entities where entityname like '3M Company%'

select * from FinancialRisks.ObligorPseudonym where ObligorPseudonym like '3M Company%'

select * from FinancialRisks.Entities where entityname like '680G 50G BORROWER PTY LTD'

select * from FinancialRisks.Entities where CapitalIqId='IQ1112233'


select c.Countryname Exposure_Country, en.entityname, en.Domicile,  count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like '3M Company%'
--and ex.uploaddate >'2022-01-01T00:00:00.000'
and c.Countryname in ('United States','Germany','Poland','Chile','Colombia')
group by  c.Countryname, en.entityname,uploaddate, en.Domicile
order by  uploaddate desc, en.entityname, c.Countryname



--Update Data


  exec useradmin.dbo.usp_Start_FRED_job 'FRED_QuarterUpdate' 


select c.Countryname Exposure_Country, en.entityname, en.Domicile,  count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like '3M Company%'
and c.Countryname in ('United States','Germany','Poland','Chile','Colombia')
group by  c.Countryname, en.entityname,uploaddate, en.Domicile
order by  uploaddate desc, en.entityname, c.Countryname


select c.Countryname Exposure_Country, en.entityname, en.Domicile,  count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like '3M Company%'
and ex.uploaddate >='2023-10-24 00:00:00.000'
and c.Countryname in ('United States','Germany','Poland','Chile','Colombia')
group by  c.Countryname, en.entityname,uploaddate, en.Domicile
order by  uploaddate desc, en.entityname, c.Countryname

exec useradmin.dbo.usp_Start_FRED_job 'FRED_UpdateMappings' 
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]


select * from FinancialRisks.Entities e
INNER JOIN FinancialRisks.ObligorPseudonymsTemp tmou ON tmou.[ObligorID] = e.EntityID



exec useradmin.dbo.usp_Start_FRED_job 'FRED_UpdateObligorMappings' 
exec useradmin.[dbo].[usp_check_job_history] 'FRED_UpdateObligorMappings' 

select * from [FinancialRisks].Mapping_Errors order by errorid desc

select '||', obligors.*, '|| Entities-->', e.entityid, e.entityname, e.Domicile, '|| Exposures-->', c.CountryName EX_Country,  ex.ObligorEntityId Ex_Obligor_id, ex.ObligorPseudID Ex_Obligor_Pseudonim
,ex.source EX_Source, ex.UploadDate
,ex.GrossPremium, ex.GrossExposure, Ex.InforceDate
FROM  [FinancialRisks].exposures ex
INNER JOIN [FinancialRisks].Countries c ON c.countryid = ex.CountryId 
INNER JOIN [FinancialRisks].Entities e on e.entityid=ex.ObligorEntityId
left JOIN #obligors obligors ON obligors.ObligorName = LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName
where e.entityname like 'Ministry of Defence%'
and c.countryName in  ('Oman')
and c.countryName <> e.Domicile


--UAT MInistry



select * from #Obligors where ObligorName like 'Ministry of defence%Qatar%'
select * from #Obligors where ObligorName like 'Ministry of defence/%'

select * from FinancialRisks.Entities where EntityName like 'Ministry of defence%' 


select * from #Obligors o
join FinancialRisks.Entities en on en.entityid=o.obligorid
where o. ObligorName like 'Ministry of Defence%Oman' order by ObligorName


select * from #Obligors o
join FinancialRisks.Entities en on en.entityid=o.obligorid
where o.ObligorName like 'Ministry of Defence%Oman%'  order by ObligorName


select * from FinancialRisks.Entities where entityname like 'Ministry of Defence%Oman%'
select * from FinancialRisks.ObligorPseudonym where ObligorPseudonym like 'Ministry of Defence%Oman%'

select * from FinancialRisks.Entities where entityname like 'Ministry of Defense%Oman%'
select * from FinancialRisks.ObligorPseudonym where ObligorPseudonym like 'Ministry of Defense%Oman%'



select c.Countryname Exposure_Country, en.entityname, en.Domicile,  count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'Ministry of Defense%'
--and ex.uploaddate >='2023-10-24 00:00:00.000'
and c.Countryname in ('Oman')
group by  c.Countryname, en.entityname,uploaddate, en.Domicile
order by  uploaddate desc, en.entityname, c.Countryname



select c.Countryname Exposure_Country, en.entityname, en.Domicile,  count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'Ministry of Defence%'
--and ex.uploaddate >='2023-10-24 00:00:00.000'
and c.Countryname in ('Oman')
group by  c.Countryname, en.entityname,uploaddate, en.Domicile
order by  uploaddate desc, en.entityname, c.Countryname





select '||', obligors.*, '|| Entities-->', e.entityid, e.entityname, e.Domicile, '|| Exposures-->', c.CountryName EX_Country,  ex.ObligorEntityId Ex_Obligor_id, ex.ObligorPseudID Ex_Obligor_Pseudonim
,ex.source EX_Source, ex.UploadDate
,ex.GrossPremium, ex.GrossExposure, Ex.InforceDate
FROM  [FinancialRisks].exposures ex
INNER JOIN [FinancialRisks].Countries c ON c.countryid = ex.CountryId 
INNER JOIN [FinancialRisks].Entities e on e.entityid=ex.ObligorEntityId
left JOIN #obligors obligors ON obligors.ObligorName = LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName
where e.entityname like 'Ministry of Defence%'
and c.countryName in  ('Oman')
and c.countryName <> e.Domicile


  exec useradmin.dbo.usp_Start_FRED_job 'FRED_UpdateObligorMappings' 
  exec useradmin.[dbo].[usp_check_job_history] 'FRED_UpdateObligorMappings' 

  select * from FinancialRisks.Entities where entityname like 'Ministry of Defense%'
  select * from FinancialRisks.Entities where entityname like 'Ministry of Defence%'



--Ministry of Defence of Indonesia

select * from FinancialRisks.Entities where entityname like 'Ministry of Defence%Indonesia%'
select 'ObligorPseudonym --> ', o.*, 'Enitties --> ',en.*  
from FinancialRisks.ObligorPseudonym o
join FinancialRisks.Entities en on en.entityid=o.obligorid
where ObligorPseudonym like 'Ministry of Defen[cs]e%Indonesia%'




select c.Countryname Exposure_Country, en.entityname, en.Domicile,  count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'Ministry of Defence%'
--and ex.uploaddate >='2023-10-24 00:00:00.000'
and c.Countryname in ('Indonesia')
group by  c.Countryname, en.entityname,uploaddate, en.Domicile
order by  uploaddate desc, en.entityname, c.Countryname


  exec useradmin.dbo.usp_Start_FRED_job 'FRED_UpdateObligorMappings' 




  exec useradmin.[dbo].[usp_check_job_history] 'FRED_UpdateObligorMappings' 

  select * from FinancialRisks.Entities where entityname like 'Ministry of Defense%'
  select * from FinancialRisks.Entities where entityname like 'Ministry of Defence%'


  

--3M Company

select * from FinancialRisks.Entities where entityname like '3M Company%'

select 'ObligorPseudonym --> ', o.*, 'Enitties --> ',en.*  
from FinancialRisks.ObligorPseudonym o
join FinancialRisks.Entities en on en.entityid=o.obligorid
where ObligorPseudonym like '3M Company%'




select c.Countryname Exposure_Country, en.entityname, en.Domicile,  count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like '3M Company%'
and ex.uploaddate >='2023-10-24 00:00:00.000'
group by  c.Countryname, en.entityname,uploaddate, en.Domicile
order by  uploaddate desc, en.entityname, c.Countryname


  exec useradmin.dbo.usp_Start_FRED_job 'FRED_UpdateObligorMappings' 



  --Ministry of finance

select * from FinancialRisks.Entities where entityname like 'Ministry of economy%'

select 'ObligorPseudonym --> ', o.*, 'Enitties --> ',en.*  
from FinancialRisks.ObligorPseudonym o
join FinancialRisks.Entities en on en.entityid=o.obligorid
where ObligorPseudonym like 'Ministry of economy%'




select c.Countryname Exposure_Country, en.entityname, en.Domicile,  count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'Ministry of economy%'
and ex.uploaddate >='2023-10-24 00:00:00.000'
and c.Countryname in ('Egypt')
group by  c.Countryname, en.entityname,uploaddate, en.Domicile
order by  uploaddate desc, en.entityname, c.Countryname


exec useradmin.dbo.usp_Start_FRED_job 'FRED_GenerateLossByExposure' 

exec useradmin.[dbo].[usp_check_job_history] 'FRED_GenerateLossByExposure' 


  exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]



--Ministry of finance Angola

select * from FinancialRisks.Entities where entityname like 'Ministry of finance%Angola' 

select 'ObligorPseudonym --> ', o.*, 'Enitties --> ',en.*  
from FinancialRisks.ObligorPseudonym o
join FinancialRisks.Entities en on en.entityid=o.obligorid
where ObligorPseudonym like 'Ministry of finance%Angola'




select c.Countryname Exposure_Country, en.entityname, en.Domicile,  count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'Ministry of finance%'
--and ex.uploaddate >='2023-10-24 00:00:00.000'
and c.Countryname in ('Angola')
group by  c.Countryname, en.entityname,uploaddate, en.Domicile
order by  uploaddate desc, en.entityname, c.Countryname





select distinct ExposureId, [Original Entity in File], EntityName, ObligorEntityId, CountryName, Domicile, *
from FinancialRisks.vw_ExposureOverview
where InforceDate = (select max(LastRunTime) from FinancialRisks.AddNewData)
and [Original Entity in File] like 'Ministry of Finance%Angola%'
 




select * from FinancialRisks.ObligorPseudonym
where ObligorPseudonym like 'Ministry of Finance%Angola%'

select * from #obligors where ObligorName like 'Ministry of Finance, Angola%'



select e.entityname, c.CountryName, obligors.* 
    FROM  [FinancialRisks].exposures ex
    INNER JOIN [FinancialRisks].Countries c ON c.countryid = ex.CountryId 
    INNER JOIN [FinancialRisks].Entities e on e.entityid=ex.ObligorEntityId
    left  JOIN #obligors obligors ON obligors.ObligorName = LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName
    where ex.exposureid in (46362387,46362292,46362241,46361730,46362460,46362459)
	--Obligors.ObligorName = 'Ministry of Finance, Angola/Angola'
    and c.countryName <> e.Domicile



select '||', obligors.*, '|| Entities-->', e.entityid, e.entityname, e.Domicile, '|| Exposures-->', c.CountryName EX_Country,  ex.ObligorEntityId Ex_Obligor_id, ex.ObligorPseudID Ex_Obligor_Pseudonim
,ex.source EX_Source, ex.UploadDate
,ex.GrossPremium, ex.GrossExposure, Ex.InforceDate
FROM  [FinancialRisks].exposures ex
INNER JOIN [FinancialRisks].Countries c ON c.countryid = ex.CountryId 
INNER JOIN [FinancialRisks].Entities e on e.entityid=ex.ObligorEntityId
left JOIN #obligors obligors ON obligors.ObligorName = LTRIM(RTRIM(e.EntityName)) + '/' + c.CountryName
where e.entityname like 'Ministry of Finance%'
and c.countryName in  ('Angola')
and c.countryName <> isnull(e.Domicile,'')



--Testing re-Mapping:  "Ministry of Finance - Angola/Angola" insead of "Ministry of Finance, Angola/Angola"


exec useradmin.dbo.usp_Start_FRED_job 'FRED_UpdateObligorMappings' 

exec useradmin.dbo.usp_Start_FRED_job 'FRED_GenerateLossByExposure' 
exec useradmin.[dbo].[usp_check_job_history] 'FRED_GenerateLossByExposure' 
  exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]


select distinct ExposureId, [Original Entity in File], EntityName, ObligorEntityId, CountryName, Domicile
from FinancialRisks.vw_ExposureOverview
where InforceDate = (select max(LastRunTime) from FinancialRisks.AddNewData)
and [Original Entity in File] like 'Ministry of Finance%Angola%'
 

 select top 10 * from FinancialRisks.Exposures

 select distinct ExposureId, c.CountryName, en.EntityName, ObligorEntityId, en.Domicile,e.*
from FinancialRisks.Exposures e
join FinancialRisks.Entities en on en.EntityID=e.ObligorEntityId
join FinancialRisks.countries c on c.countryid=e.countryid
where InforceDate = (select max(LastRunTime) from FinancialRisks.AddNewData)
and e.exposureid in (
		select distinct ExposureId
		from FinancialRisks.vw_ExposureOverview
		where InforceDate = (select max(LastRunTime) from FinancialRisks.AddNewData)
		and [Original Entity in File] like 'Ministry of Finance%Angola%'
)



select * from mi.fred_gfr where obligor like 'Ministry of Finance%Angola%'

 













select o.ObligorPseudonym,en.EntityName, en.Domicile, en.ParentDomicile,'ObligorPseudonym --> ', o.*, 'Enitties --> ', en.*  
from FinancialRisks.ObligorPseudonym o
join FinancialRisks.Entities en on en.entityid=o.obligorid
where ObligorPseudonym like 'vinci[/ ]%'


select * from #obligors where obligorname like 'vinci[/ ]%' order by ObligorName
