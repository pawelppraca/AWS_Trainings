 --Testy SIT

 SELECT *
 --update a set [AddNewData]=true
  FROM [FinancialRisks].[AddNewData] a



exec useradmin.dbo.usp_Start_FRED_job 'FRED_QuarterUpdate'

exec useradmin.[dbo].[usp_check_agent_jobs_currently_running]


exec useradmin.[dbo].[usp_check_agent_job_history] 'FRED_QuarterUpdate'



exec useradmin.dbo.usp_Start_FRED_job 'FRED_GenerateLossByExposure'


select count(*) from FinancialRisks.LossByExposure where OriginalEntityinFile is not null

select [Original Entity in File], * from FinancialRisks.vw_ExposureOverview where [Original Entity in File] is not null









use FRED



select 'ExposuresQueue' [Table],  count(*) from FinancialRisks.ExposuresQueue where OriginalEntityinFile is not null 
select 'Ironshore_data' [Table], count(*) from FinancialRisks.Ironshore_data where OriginalEntityinFile is not null
select 'Exposures' [Table], count(*) from FinancialRisks.Exposures where OriginalEntityinFile is not null and UploadDate>='20231114'


select OriginalEntityinFile,* from  FinancialRisks.ExposuresQueue where OriginalEntityinFile is not null
select distinct Source from FinancialRisks.ExposuresStaging where OriginalEntityinFile is not null



select count(*) from FinancialRisks.LossByExposure where OriginalEntityinFile is not null and UploadDate>='20231114'

select count(*) from FinancialRisks.vw_ExposureOverview where [Original Entity in File] is not null

select [Original Entity in File], EntityName,* from FinancialRisks.vw_ExposureOverview where [Original Entity in File - Actual] is not null and UploadDate>='20231114'



select EntityName, [Original Entity in File], [Original Entity in File - Actual], [Original Entity in File - Derived],* 
from FinancialRisks.vw_ExposureOverview where [Original Entity in File - Actual] is not null and UploadDate<'20231114'




select max(entityid) from financialrisks.entities  -- UAT: 3300292 , PROD: 3428855, SIT: 3231929
select max(exposureid) from FinancialRisks.Exposures 