--SIT

DECLARE @var sql_variant = N'\\VMBIT-GSQLDB22\FinancialRisk-Upload\LMIE'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'LMIEConversionErrorFileLocation_Excel', @sensitive=False, @description=N'', @environment_name=N'SIT', @folder_name=N'FRED', @value=@var, @data_type=N'String'
GO
DECLARE @var sql_variant = N'\\VMBIT-GSQLDB22\FinancialRisk-Upload\Mappings\Input'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'UnmappedCedantsConversionErrorFileLocation', @sensitive=False, @description=N'', @environment_name=N'SIT', @folder_name=N'FRED', @value=@var, @data_type=N'String'
GO
DECLARE @var sql_variant = N'\\VMBIT-GSQLDB22\FinancialRisk-Upload\Mappings\Input'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'UnmappedCountriesConversionErrorFileLocation', @sensitive=False, @description=N'', @environment_name=N'SIT', @folder_name=N'FRED', @value=@var, @data_type=N'String'
GO
DECLARE @var sql_variant = N'\\VMBIT-GSQLDB22\FinancialRisk-Upload\Mappings\Input'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'UnmappedObligorsConversionErrorFileLocation', @sensitive=False, @description=N'', @environment_name=N'SIT', @folder_name=N'FRED', @value=@var, @data_type=N'String'
GO



--UAT

DECLARE @var sql_variant = N'\\VMBIS-GSQLDB22\FinancialRisk-Upload\LMIE'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'LMIEConversionErrorFileLocation_Excel', @sensitive=False, @description=N'', @environment_name=N'UAT', @folder_name=N'FRED', @value=@var, @data_type=N'String'
GO
DECLARE @var sql_variant = N'\\VMBIS-GSQLDB22\FinancialRisk-Upload\Mappings\Input'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'UnmappedCedantsConversionErrorFileLocation', @sensitive=False, @description=N'', @environment_name=N'UAT', @folder_name=N'FRED', @value=@var, @data_type=N'String'
GO
DECLARE @var sql_variant = N'\\VMBIS-GSQLDB22\FinancialRisk-Upload\Mappings\Input'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'UnmappedCountriesConversionErrorFileLocation', @sensitive=False, @description=N'', @environment_name=N'UAT', @folder_name=N'FRED', @value=@var, @data_type=N'String'
GO
DECLARE @var sql_variant = N'\\VMBIS-GSQLDB22\FinancialRisk-Upload\Mappings\Input'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'UnmappedObligorsConversionErrorFileLocation', @sensitive=False, @description=N'', @environment_name=N'UAT', @folder_name=N'FRED', @value=@var, @data_type=N'String'
GO



--PROD

DECLARE @var sql_variant = N'\\VMBIP-GSQLDB22\FinancialRisk-Upload\LMIE'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'LMIEConversionErrorFileLocation_Excel', @sensitive=False, @description=N'', @environment_name=N'PRD', @folder_name=N'FRED', @value=@var, @data_type=N'String'
GO
DECLARE @var sql_variant = N'\\VMBIP-GSQLDB22\FinancialRisk-Upload\Mappings\Input'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'UnmappedCedantsConversionErrorFileLocation', @sensitive=False, @description=N'', @environment_name=N'PRD', @folder_name=N'FRED', @value=@var, @data_type=N'String'
GO
DECLARE @var sql_variant = N'\\VMBIP-GSQLDB22\FinancialRisk-Upload\Mappings\Input'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'UnmappedCountriesConversionErrorFileLocation', @sensitive=False, @description=N'', @environment_name=N'PRD', @folder_name=N'FRED', @value=@var, @data_type=N'String'
GO
DECLARE @var sql_variant = N'\\VMBIP-GSQLDB22\FinancialRisk-Upload\Mappings\Input'
EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=N'UnmappedObligorsConversionErrorFileLocation', @sensitive=False, @description=N'', @environment_name=N'PRD', @folder_name=N'FRED', @value=@var, @data_type=N'String'
GO
