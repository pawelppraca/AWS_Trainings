--DATAFIX for Table with Numerical SP_Ratings

USE FRED

--Export Data 

DECLARE @inforcedate DATETIME, @inforcedate_str varchar(30)
SET @InforceDate = (select distinct lastruntime from FinancialRisks.AddNewData)
--set @inforcedate ='20230101'
set @inforcedate_str =  convert(varchar, @inforcedate, 23)

--select @inforcedate, @inforcedate_str

DECLARE @cols AS NVARCHAR(MAX), @query  AS NVARCHAR(MAX), @cols_plus NVARCHAR(MAX)

select @cols = STUFF((SELECT distinct ',' + QUOTENAME(ReportingClass) 
            FROM  FinancialRisks.vw_ExposureOverview where InforceDate = @inforcedate
            FOR XML PATH(''), TYPE
            ).value('.', 'NVARCHAR(MAX)') 
        ,1,1,'')

set @cols_plus = replace(replace(replace(@cols, ',','+'),'[','isnull(['),']','],0)')
--select @cols_plus



set @query = 'SELECT InforceDate, EntityName, SPRating, ' + @cols +','+ @cols_plus +' [Total] from 
            (
				SELECT InforceDate, EntityName, SPRating, ReportingClass, LibertyExposure 
				from FinancialRisks.vw_ExposureOverview 
				where InforceDate = ''' + @inforcedate_str + '''
           ) x
            pivot 
            (
                 Sum(LibertyExposure)
                for ReportingClass in (' + @cols + ')
            ) p
			order by [Total] desc
			' 




execute(@query)





