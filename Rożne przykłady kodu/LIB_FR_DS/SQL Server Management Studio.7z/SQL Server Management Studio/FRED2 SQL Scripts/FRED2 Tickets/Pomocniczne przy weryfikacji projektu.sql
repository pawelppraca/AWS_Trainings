USE fred
GO
SELECT [name], create_date, modify_date
FROM sys.procedures
where NAME in  ('CommonShockModelExtract' , 'CommonShockModelFinal' ) ORDER BY 3 DESC;
