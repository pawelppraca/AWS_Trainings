
USE FRED

declare @ExposuresQueue_Qty int, @Ironshore_Data_Queue_qty int, @TreatiesQueue_Qty int
 
select @ExposuresQueue_Qty = count(*) from FinancialRisks.ExposuresQueue

select @Ironshore_Data_Queue_qty = count(*) from [FinancialRisks].[Ironshore_Data_Queue]

select @TreatiesQueue_Qty = count(*) from [FinancialRisks].[TreatiesQueue]

select @ExposuresQueue_Qty ExposuresQueue_Qty, @Ironshore_Data_Queue_qty Ironshore_Data_Queue_qty, @TreatiesQueue_Qty TreatiesQueue_Qty


--DEV TEsting

select * from financialrisks.ExposuresQueue

--start Update to fulfill queue

exec useradmin.[dbo].[usp_start_FRED_QuarterUpdate]

exec UserAdmin.[dbo].[usp_check_server_agent_jobs_currently_running]

select count(*) ExposuresQueue_Qty from FinancialRisks.ExposuresQueue (nolock)
select count(*) Ironshore_Data_Queue_qty from [FinancialRisks].[Ironshore_Data_Queue] (nolock)
select count(*) TreatiesQueue_Qty from [FinancialRisks].[TreatiesQueue] (nolock)



select * from FinancialRisks.ExposuresQueue (nolock) where ObligorEntityName
 in (
'1827 Westridge LLC',
'190 union Redevelopment Urban Renewal LLC',
'1974 BC LLC',
'1st Choice Mulching LLC',
'1st Choice Roofing Company',
'1ST CITY AUTO GROUP P 163436',
'1st Priority Vehicle Finance LLC',
'2 Dipshits Brewing Co LLC',
'2 Vets Plumbing LLC',
'200 New Castle Avenue, LLC',
'20038793196-ACOSTA LUCIANO',
'20042949389-LADINO, RUBEN',
'20042977226-HERNANDEZ RAIMUNDO JORGE',
'20043761286-BRAGAGNOLO JULIO ALFREDO',
'20043822137-AGOSTINI ROBERTO R. Y OTROS',
'20044899532-SUCESION DE DI PIETRO PAOLO RUBENS ERNESTO',
'20045393314-CAZES CAMARERO, PEDRO LUIS',
'20045632092-ORDOEZ, NAURO ESTEBAN',
'20045662757-RITORTO VICENTE ABEL',
'20047037701-LOPEZ EDUARDO MARIO' 
 )



exec UserAdmin.[dbo].[usp_check_server_agent_jobs_currently_running]

