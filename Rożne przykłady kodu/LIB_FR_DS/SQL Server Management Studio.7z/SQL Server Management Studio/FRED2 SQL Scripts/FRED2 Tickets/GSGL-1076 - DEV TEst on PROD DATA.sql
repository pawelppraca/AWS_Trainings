USE FRED

select Domicile, ParentDomicile, e.entityname, e.parententityname, * from [FinancialRisks].[Exposures] ex
join [FinancialRisks].Entities e on e.entityid=ex.ObligorEntityId
where e.entityname like 'TRAFIGURA%'




select ObligorID, ltrim(rtrim(ObligorName)) as 'ObligorName',ObligorPseudonymId,CountryName 
into  #Obligors from
(
	SELECT EntityId as ObligorId, rtrim(ltrim(EntityName)) as ObligorName ,'' as ObligorPseudonymId,Domicile as 'CountryName'
	FROM FinancialRisks.Entities
	UNION
	SELECT ObligorId, rtrim(ltrim(ObligorPseudonym)) as ObligorName,ObligorPseudonymId,''as 'CountryName'
	FROM FinancialRisks.ObligorPseudonym
)b



select * from #Obligors where ObligorName like 'TRAFIGURA%'

select Domicile, ParentDomicile,* from FinancialRisks.Entities where EntityName like 'TRAFIGURA%'




--Map those with valid IDS
select obligors.ObligorID, obligors.ObligorPseudonymId, obligors.*, eq.*
--UPDATE [FinancialRisks].[ExposuresQueue] set [ObligorEntityName] =obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
join [FinancialRisks].Countries c on c.countryid=eq.countryName
left JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName)) + ' [ '+c.CountryName + ' ] '
WHERE [Status] = 'NEW'
and ObligorEntityName like 'TRAFIGURA %'


--TESTY DEV I SIT

--PLIKI
--Data_Markel_LMIE_PriCcy.xlsx 2022-05-06
--Saras S.p.A.
--AGCO International GmbH
--McLaren Automotive Limited
--Triland Metals Limited 
--Total Marine Fuels - Singapore  !!!!!
--Central National Sweden AB
--Terex GB Limited 

--Data_HamiltonLMIE_PriCcy.xlsx - 2023-04-26 00:00:00.000
--CEN (FIXED)


--znajdowanie plik�w
select  distinct source, EntityName, Domicile, CountryName, uploaddate
from [FinancialRisks].[Exposures_PP_GSGL_1076] ep
left join [FinancialRisks].entities_PP_GSGL_1076 en on en.entityid=ep.obligorentityid
left join [FinancialRisks].countries_PP_GSGL_1076 c on c.countryid=ep.countryid
where en.EntityName like 'AMAZON%'
and uploaddate ='20230426'
and source in (
'Data_Greenstarssec1_QS_LMIE_PriCCY.xlsx','Data_ZurichLMBLInternational_Surety_PriCCY.xlsx','Data_INSUR_PERU_QS_CR_PriCcy.xlsx','Data_HCCLMIE_PriCcy.xlsx','Data_GROUPAMA_XL_PriCCY.xlsx'
)
order by uploaddate desc

--TESTY DEV
-----------------------
---Import Danych - DONE

select distinct es.ObligorEntityName, CountryName
from [FinancialRisks].ExposuresStaging es
where ObligorEntityName in (
'Saras S.p.A.'
,'McLaren Automotive Limited'
,'Triland Metals Limited' 
,'Total Marine Fuels - Singapore'
,'Central National Sweden AB'
,'Terex GB Limited'
)



select * from [FinancialRisks].[ExposuresQueue] e
where ObligorEntityName in (
'Saras S.p.A.'
,'McLaren Automotive Limited'
,'Triland Metals Limited' 
,'Total Marine Fuels - Singapore'
,'Central National Sweden AB'
,'Terex GB Limited'
)


DROP TABLE IF EXISTS #Obligors

select ObligorID, ltrim(rtrim(ObligorName)) as 'ObligorName',ObligorPseudonymId,CountryName 
into  #Obligors from
(
	SELECT EntityId as ObligorId, rtrim(ltrim(EntityName)) as ObligorName ,'' as ObligorPseudonymId,Domicile as 'CountryName'
	FROM FinancialRisks.Entities
	UNION
	SELECT ObligorId, rtrim(ltrim(ObligorPseudonym)) as ObligorName,ObligorPseudonymId,''as 'CountryName'
	FROM FinancialRisks.ObligorPseudonym
)b


select * from #Obligors where ObligorName like 'McLaren Automotive Limited%'


select * from #Obligors
where ObligorName in (
'Saras S.p.A.'
,'McLaren Automotive Limited'
,'Triland Metals Limited' 
,'Total Marine Fuels - Singapore'
,'Central National Sweden AB'
,'Terex GB Limited'
)


select c.Countryname, en.entityname,* --, sum(GrossExposure) 
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname in (
--'Saras S.p.A.'
'McLaren Automotive Limited'
--,'Triland Metals Limited' 
--,'Total Marine Fuels - Singapore'
--,'Central National Sweden AB'
--,'Terex GB Limited'
)
and ex.uploaddate='2023-05-31T00:00:00.000'
--group by  c.Countryname, en.entityname
order by   en.entityname, c.Countryname



select c.Countryname, en.entityname, count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname in (
'Saras S.p.A.'
,'McLaren Automotive Limited'
,'Triland Metals Limited' 
,'Total Marine Fuels - Singapore'
,'Central National Sweden AB'
,'Terex GB Limited'
)
and ex.uploaddate='2023-05-31T00:00:00.000'
group by  c.Countryname, en.entityname,uploaddate
order by   en.entityname, c.Countryname


select c.Countryname, en.entityname, count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname in (
'Saras S.p.A.'
--,'McLaren Automotive Limited'
--,'Triland Metals Limited' 
--,'Total Marine Fuels - Singapore'
--,'Central National Sweden AB'
--,'Terex GB Limited'
)
and ex.uploaddate='2023-05-31T00:00:00.000'
group by  c.Countryname, en.entityname,uploaddate
order by   en.entityname, c.Countryname



select c.Countryname, en.entityname, count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'Saras S.p.A.%'
and ex.uploaddate='2023-05-31T00:00:00.000'
group by  c.Countryname, en.entityname,uploaddate
order by   en.entityname, c.Countryname


select * from FinancialRisks.ExposuresQueue where ObligorPseudID in (2392007,2392008,2392009)

select * from FinancialRisks.Exposures where ObligorPseudID in (2392007,2392008,2392009)


select * from #Obligors where obligorname like 'Terex GB Limited%'

--wstawienie 
--Saras S.p.A. Cayman Islands
Cyprus
Bermuda

insert into [FinancialRisks].ObligorPseudonym (ObligorID,ObligorPseudonym) values (3062094,'Terex GB Limited/Poland')
insert into [FinancialRisks].ObligorPseudonym (ObligorID,ObligorPseudonym) values (3062094,'Terex GB Limited/Belgium')


 SELECT * FROM [FinancialRisks].[MappingsStatus]

 IF ((SELECT count(*)  FROM [FinancialRisks].[MappingsStatus] where[Status] = 'Generating')=0
	and (select count(*)FROM  [FinancialRisks].[MappingsStatus] where [Status]='Complete' ) = 0)
Select 'True' as Updated
ELSE 
Select 'False' Updated


exec USERADMIN.dbo.[usp_start_FRED_UpdateMappings]



select * from [FinancialRisks].ObligorPseudonym where ObligorPseudonym like 'McLaren Automotive Limited%'
select * 
--update e set TradeSectorId = 118, DefaultTradeSectorId=118, DefaultDomicile='United Kingdom'
from [FinancialRisks].Entities e where Entityname like 'McLaren Automotive Limited%'

select * 
--update op set PesudonymOrNew='Pseudonym'
from [FinancialRisks].[ObligorPseudonymsTemp] op





select  en.entityname, count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
--join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'Triland Metals Limited%' --'McLaren Automotive Limited%'
and ex.uploaddate='2023-05-31T00:00:00.000'
group by  en.entityname,uploaddate
order by  en.entityname


SELECT FinancialRisks.fn_GetInforceDate() AS InforceDate

select distinct InforceDate from FinancialRisks.Exposures ex order by InforceDate desc

select distinct InforceDate, uploaddate 
--delete from ex
from FinancialRisks.Exposures ex where uploaddate='2023-05-31T00:00:00.000'


select * from FinancialRisks.ExposuresStaging


EXEC [FinancialRisks].[uspCleanupExposureStaging] @CobId = 3


select  en.entityname, count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
--join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'McLaren Automotive Limited%'
and ex.uploaddate='2023-05-31T00:00:00.000'
group by  en.entityname,uploaddate
order by   en.entityname



select  ex.*
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
--join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'McLaren Automotive Limited%'
and ex.uploaddate='2023-05-31T00:00:00.000'
order by   en.entityname



exec [FinancialRisks].[GenerateLossByExposure]



select * from [FinancialRisks].[vw_ExposureOverview] 
where entityname like 'McLaren Automotive Limited%' 
and  uploaddate='2023-05-31T00:00:00.000'

select * from [FinancialRisks].LossByExposure where uploaddate='2023-05-31T00:00:00.000'



select * from FinancialRisks.Entities where entityid in (89,2517242)

select * from FinancialRisks.ObligorPseudonym where obligorPseudonymid in (160557, 40520)
select * from FinancialRisks.ObligorPseudonym where obligorPseudonym like 'AMAZON%'

select * from FinancialRisks.Entities where entityname like 'Trafigura%'
select * from FinancialRisks.ObligorPseudonym where obligorPseudonym like 'Trafigura%'




 IF ((SELECT count(*)  FROM [FinancialRisks].[MappingsStatus] where[Status] = 'Generating')=0
	and (select count(*)FROM  [FinancialRisks].[MappingsStatus] where [Status]='Complete' ) = 0)
Select 'True' as Updated
ELSE 
Select 'False' Updated




 DROP TABLE IF EXISTS #Obligors

select ObligorID, ltrim(rtrim(ObligorName)) as 'ObligorName',ObligorPseudonymId,CountryName 
into  #Obligors from
(
	SELECT EntityId as ObligorId, rtrim(ltrim(EntityName)) as ObligorName ,'' as ObligorPseudonymId,Domicile as 'CountryName'
	FROM FinancialRisks.Entities (nolock)
	UNION
	SELECT ObligorId, rtrim(ltrim(ObligorPseudonym)) as ObligorName,ObligorPseudonymId,''as 'CountryName'
	FROM FinancialRisks.ObligorPseudonym (nolock)
)b


select * from #Obligors where ObligorName like 'VINCI%'

select * 
--delete
from FinancialRisks.Entities where EntityName like 'Vinci SA/%'

select * 
--delete
from FinancialRisks.ObligorPseudonym where ObligorPseudonym like 'Vinci/%'

select * from FinancialRisks.ExposuresStaging where ObligorEntityName like 'Vinci%'

select * from [FinancialRisks].[ExposuresQueue] eq where ObligorEntityName like 'Vinci%'


/********************************************************************************************/
-- Get distinct list of all possible country names and their ids
SELECT CountryID, CountryName,CountryPseudonymId into #country from
(
	SELECT CountryId, CountryName,''as CountryPseudonymId
	FROM FinancialRisks.Countries
	UNION
	SELECT CountryId, CountryPseudonym AS CountryName,CountryPseudonymId
	FROM FinancialRisks.CountryPseudonym
)a

UPDATE [FinancialRisks].[ExposuresQueue]
set [CountryName] =countries.CountryID
,CountryPseudID=countries.CountryPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #country countries on countries.CountryName = [FinancialRisks].[fn_RemoveBadChar](eq.CountryName)
  WHERE [Status] = 'NEW'


Declare @countryid int 
SET @countryid = (Select CountryID from  [FinancialRisks].[Countries]
where CountryName = 'No country name supplied')


UPDATE [FinancialRisks].[ExposuresQueue]
   SET [CountryName] = @countryid
  where
  [CountryName] is null  or [CountryName] =''


select ObligorEntityName, obligors.ObligorName, c.CountryName ,*
--UPDATE [FinancialRisks].[ExposuresQueue]
--SET [ObligorEntityName] = obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN [FinancialRisks].Countries c ON c.countryid=eq.countryName
left  JOIN #Obligors obligors ON obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName)) + '/' + c.CountryName 
WHERE ObligorEntityName like 'Vinci%'


select * from #Obligors where ObligorName like 'VINCI SA%'

select ObligorEntityName, obligors.ObligorName, * 
--UPDATE [FinancialRisks].[ExposuresQueue] SET [ObligorEntityName] =obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
INNER JOIN [FinancialRisks].Countries c ON c.countryid=eq.countryName
WHERE ObligorEntityName like 'Vinci%'
  --AND [CobId] = @CobId
  --and ISNUMERIC([ObligorEntityName]) = 0 --Not maped earlier






select c.Countryname, en.entityname, count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'VINCI%'
and ex.uploaddate='2023-06-16T00:00:00.000'
group by  c.Countryname, en.entityname,uploaddate
order by   en.entityname, c.Countryname



select Domicile, ParentDomicile,* from FinancialRisks.Entities where EntityName like 'VINCI%'

--drop table FinancialRisks.ObligorPseudonymsTemp 

select * from FinancialRisks.ObligorPseudonymsTemp 



                DROP TABLE IF EXISTS #tempCapIQMatches
                DROP TABLE IF EXISTS #tempMatchesNames
                DROP TABLE IF EXISTS #tempNoMatches
                DROP TABLE IF EXISTS #matches
                DROP TABLE IF EXISTS #pseudonyms
                DROP TABLE IF EXISTS #Duplicates
                DROP TABLE IF EXISTS #keepDelete
                DROP TABLE IF EXISTS #fix
                DROP TABLE IF EXISTS #InvalidMultiCapIQ
                DROP TABLE IF EXISTS #matchAlreadyExists
                DROP TABLE IF EXISTS #ObligorPseudonymsTempMatch
				DROP TABLE IF EXISTS #tempNamesChanges


       select EntityName 
                into #InvalidMultiCapIQ 
                from FinancialRisks.ObligorPseudonymsTemp 
                where EntityName  in 
                (select EntityName from  (
                select *
                , DENSE_RANK() OVER (PARTITION BY entityname ORDER BY [CapitalIqId] DESC ) AS ranking
                                from FinancialRisks.ObligorPseudonymsTemp 
                where EntityName in  
                ( select EntityName
                  from FinancialRisks.ObligorPseudonymsTemp 
                  group by EntityName
                  having count (EntityName) >1)
                  )a
                where ranking <>1)


                /*CapIQ Matches*/
                select  temp.UnmappedObligorName,temp.CapitalIqId,temp.EntityName as 'NewEntityName',en.EntityName as 'OldName',en.CapitalIqId as 'OldCapitalIQID',
                en.EntityId, temp.[EntityName],temp.ParentEntityName,temp.ParentCapitalIqId,temp.SPRating, temp.GCHPRating, temp.LibertyRating,temp.TradeSectorName,
                temp.ParentSPRating, temp.ParentGCHPRating,temp.Domicile,temp.ParentDomicile ,
				temp.DefaultTradeSectorName,	temp.DefaultDomicile, temp.DefaultRating,	
				temp.OverrideTradeSectorName, temp.OverrideDomicile, temp.OverrideRating
                into #tempCapIQMatches
                FROM [FinancialRisks].[ObligorPseudonymsTemp] temp
                inner join FinancialRisks.Entities en on temp.CapitalIqId = en.CapitalIqId
                where [PesudonymOrNew] = 'New' and temp.entityName not in (select EntityName  from  #InvalidMultiCapIQ )

                /*Name Matches*/
                select  temp.UnmappedObligorName,temp.CapitalIqId,temp.EntityName as 'NewEntityName',en.EntityName as 'OldName',en.CapitalIqId as 'OldCapitalIQID',
                en.EntityId, temp.[EntityName],temp.ParentEntityName,temp.ParentCapitalIqId,temp.SPRating, temp.GCHPRating, temp.LibertyRating,temp.TradeSectorName,
                temp.ParentSPRating, temp.ParentGCHPRating,temp.Domicile,temp.ParentDomicile ,
				temp.DefaultTradeSectorName,	temp.DefaultDomicile, temp.DefaultRating,	temp.OverrideTradeSectorName, temp.OverrideDomicile, temp.OverrideRating
                into #tempMatchesNames
                FROM [FinancialRisks].[ObligorPseudonymsTemp]  temp
                inner join FinancialRisks.Entities en on   RTRIM(LTRIM(temp.EntityName)) = en.EntityName
                where  temp.EntityName not in (select NewEntityName from #tempCapIQMatches)
                and [PesudonymOrNew] = 'New' and temp.entityName not in (select EntityName  from  #InvalidMultiCapIQ )


                /*No Matches*/
                select  *
                into #tempNoMatches
                FROM [FinancialRisks].[ObligorPseudonymsTemp] temp
                where UnmappedObligorName not in (
                select UnmappedObligorName from #tempCapIQMatches
                union
                select UnmappedObligorName from #tempMatchesNames 
                )and [PesudonymOrNew] = 'New' and temp.entityName not in (select EntityName  from  #InvalidMultiCapIQ )


                /*Name Matches - Update All, Update Name*/
                select  temp.UnmappedObligorName as UnmappedObligorName,temp.CapitalIqId,temp.EntityName as 'NewEntityName',en.EntityName as 'OldName',en.CapitalIqId as 'OldCapitalIQID',
                en.EntityId, temp.[EntityName],temp.ParentEntityName,temp.ParentCapitalIqId,temp.SPRating, temp.GCHPRating, temp.LibertyRating,temp.TradeSectorName,
                temp.ParentSPRating, temp.ParentGCHPRating,temp.Domicile,temp.ParentDomicile ,
				temp.DefaultTradeSectorName,	temp.DefaultDomicile, temp.DefaultRating,	temp.OverrideTradeSectorName, temp.OverrideDomicile, temp.OverrideRating
                into #tempNamesChanges
                FROM [FinancialRisks].[ObligorPseudonymsTemp]  temp
                inner join FinancialRisks.Entities en on   RTRIM(LTRIM(temp.EntityName)) <> en.EntityName and temp.ObligorID = en.EntityId
                where  temp.EntityName not in (select ObligorPseudonym from FinancialRisks.ObligorPseudonym)
                and [PesudonymOrNew] in ( 'Update Al','Update Na') and temp.entityName not in (select EntityName from  #InvalidMultiCapIQ)

                /* Find Unmapped obligors which has an EntityName whichalready exists and add as pseduonym not update entity then update entity information */
                select entityname, EntityId  into #matchAlreadyExists from FinancialRisks.Entities e
                where entityname in (select temp.entityname from  [FinancialRisks].[ObligorPseudonymsTemp] temp)

                select op.*, m.EntityId into #ObligorPseudonymsTempMatch from FinancialRisks.ObligorPseudonymsTemp op
                inner join #matchAlreadyExists m on m.EntityName = op.EntityName

				select * from #matchAlreadyExists

				select * from #ObligorPseudonymsTempMatch

                --INSERT INTO FinancialRisks.ObligorPseudonym(ObligorID, ObligorPseudonym)
                select distinct EntityId,UnmappedObligorName from #ObligorPseudonymsTempMatch where UnmappedObligorName not in (select ObligorPseudonym from FinancialRisks.ObligorPseudonym)



				select distinct ObligorID,ObligorPseudonym
                into #pseudonyms
                from
                (select DISTINCT EntityId AS 'ObligorID',OldName AS 'ObligorPseudonym' 
                from #tempCapIQMatches
                where NewEntityName <> oldname and EntityName not in (select entityname from #matchAlreadyExists) 
                UNION 
                select DISTINCT EntityId AS 'ObligorID',UnmappedObligorName AS 'ObligorPseudonym' from #tempCapIQMatches
                where NewEntityName <> oldname and EntityName not in (select entityname from #matchAlreadyExists) 
                UNION
                select DISTINCT EntityId AS 'ObligorID',UnmappedObligorName AS 'ObligorPseudonym' from #tempCapIQMatches
                where NewEntityName = oldname and EntityName not in (select entityname from #matchAlreadyExists) 
                union
                select DISTINCT EntityId AS 'ObligorID',UnmappedObligorName AS 'ObligorPseudonym' from #tempMatchesNames where EntityName not in (select entityname from #matchAlreadyExists) 
                union
                Select DISTINCT ent.EntityId AS 'ObligorID',temp.UnmappedObligorName AS 'ObligorPseudonym' 
                from #tempNoMatches temp
                inner join FinancialRisks.Entities ent on ent.EntityName = RTRIM(LTRIM(temp.EntityName))
                where temp.UnmappedObligorName <> temp.EntityName and temp.EntityName not in (select entityname from #matchAlreadyExists) 
                union
                select DISTINCT EntityId AS 'ObligorID',OldName AS 'ObligorPseudonym' from #tempNamesChanges where EntityName not in (select entityname from #matchAlreadyExists) 

                )a
                where ObligorPseudonym not in (select ObligorPseudonym from financialrisks.ObligorPseudonym)

                --INSERT INTO FinancialRisks.ObligorPseudonym(ObligorID, ObligorPseudonym)
                select distinct ObligorID,ObligorPseudonym
                from  #pseudonyms




exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]


 exec useradmin.[dbo].[usp_start_FRED_UpdateMappings]

exec useradmin.[dbo].[usp_start_FRED_QuarterUpdate]





 DROP TABLE IF EXISTS #Obligors

select ObligorID, ltrim(rtrim(ObligorName)) as 'ObligorName',ObligorPseudonymId,CountryName 
into  #Obligors from
(
	SELECT EntityId as ObligorId, rtrim(ltrim(EntityName)) as ObligorName ,'' as ObligorPseudonymId,Domicile as 'CountryName'
	FROM FinancialRisks.Entities (nolock)
	UNION
	SELECT ObligorId, rtrim(ltrim(ObligorPseudonym)) as ObligorName,ObligorPseudonymId,''as 'CountryName'
	FROM FinancialRisks.ObligorPseudonym (nolock)
)b


select * from #Obligors where ObligorName like 'Ministry of Defence%bang%'
select * from #Obligors where ObligorName like 'Ministry of Defence%egy%'
select * from #Obligors where ObligorName like 'Ministry of Defence/%'
select * from #Obligors where ObligorName like '3m Company/%'

select * from  FinancialRisks.Entities (nolock) order by Entityid desc 

select * 
--delete
from FinancialRisks.Entities where entityid in (2538)

select * 
--delete
from FinancialRisks.ObligorPseudonym where ObligorPseudonym like 'Ministry of Defence%egy%'



select  ex.*
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
--join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'Ministry of Defence%'
and ex.uploaddate='2023-06-28T00:00:00.000'
order by   en.entityname


select source,c.Countryname, en.entityname, *
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'Ministry of Defence%'
and ex.uploaddate='2023-06-28T00:00:00.000'
order by   en.entityname, c.Countryname

select c.Countryname, en.entityname, count(*) records, sum(GrossExposure) [Summary GROSSExposure] , uploaddate
from FinancialRisks.Exposures ex (nolock)
join FinancialRisks.Entities en (nolock) on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c (nolock) on c.Countryid=ex.Countryid
where Entityname like 'Ministry of Defence%'
and ex.uploaddate='2023-06-28T00:00:00.000'
group by  c.Countryname, en.entityname,uploaddate
order by   en.entityname, c.Countryname

