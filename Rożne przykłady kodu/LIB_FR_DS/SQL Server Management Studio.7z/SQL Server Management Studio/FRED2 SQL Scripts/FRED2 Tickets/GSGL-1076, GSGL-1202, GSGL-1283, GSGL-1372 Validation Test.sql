USE fred
GO
SELECT [name], create_date, modify_date
FROM sys.procedures
where NAME in  (
'Merge_Currencies',
'Merge_ExchangeRates',
'Merge_ISOCurrencies',
'GenerateLossByExposure',
'uspCleanupExposureStaging',
'uspCleanupIronshoreQueue',
'uspUpdateCorrectionsMapPseudonym'
) ORDER BY 3 DESC;


SELECT [name], create_date, modify_date
FROM sys.views
where NAME in  ('vw_ExposureOverview') ORDER BY 3 DESC;


SELECT [name], create_date, modify_date
FROM sys.tables
where NAME in  (
'dwhr_Currencies_2',
'dwhr_Currencies_Staging',
'dwhr_Currencies_WORK',
'dwhr_ExchangeRates_2',
'dwhr_ExchangeRates _Staging',
'dwhr_ExchangeRates _WORK',
'dwhr_ISOCurrencies_2',
'dwhr_ISOCurrencies_Staging',
'dwhr_ISOCurrencies_WORK',
'ExposuresStaging','ExposuresQueue','Ironshore_Data_Queue','IronShore_Data','Exposures','LossByExposure'
) ORDER BY 3 DESC;
