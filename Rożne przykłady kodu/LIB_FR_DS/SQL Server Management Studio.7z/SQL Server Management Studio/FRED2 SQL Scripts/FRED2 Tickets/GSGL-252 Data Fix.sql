-- GSGL-252 - Chnage name fo Class of Bussines
-- Changes updated 1.09.2022 by Pawel P. from FP



update cob set Name='FRS Lloyds', 	ReportingClass='FRS Lloyds' from FinancialRisks.COB cob where CobID=1
update cob set Name='FRS Company', 	ReportingClass='FRS Company' from FinancialRisks.COB cob where CobID=2
update cob set Name='FRRI Single Risk', 	ReportingClass='FRRI Single Risk' from FinancialRisks.COB cob where CobID=3
update cob set Name='FRRI Surety', 	ReportingClass='FRRI Surety' from FinancialRisks.COB cob where CobID=4
update cob set Name='FRRI Short Term Credit', 	ReportingClass='FRRI Short Term Credit' from FinancialRisks.COB cob where CobID=5
update cob set Name='Direct Surety', 	ReportingClass='Direct Surety' from FinancialRisks.COB cob where CobID=6
