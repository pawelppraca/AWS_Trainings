--GSGL-779
--Export Data on SIT before Deploying Release


--W Execute Friday 15.07.2022  9:51 - time executing 41:47
exec FRED.[FinancialRisks].[GenerateLossByExposure] 

--export Data before GSGL-779 Deploy
select * 
into vw_ExposureOverview_data_before_GSGL779
from [FinancialRisks].[vw_ExposureOverview]




select  riskCodeMappings.*, e.*
	FROM FinancialRisks.Exposures e
	--exposure riskcode mappings
	LEFT JOIN FinancialRisks.RiskCodeMappings riskCodeMappings ON riskCodeMappings.riskCode = e.RiskCode 
where len(ltrim(rtrim(e.RiskCode))) <> len(e.RiskCode) 



select  riskCodeMappings.*, e.*
	FROM FinancialRisks.Exposures e
	--exposure riskcode mappings
	LEFT JOIN FinancialRisks.RiskCodeMappings riskCodeMappings ON riskCodeMappings.riskCode = ltrim(rtrim(e.RiskCode))
where len(ltrim(rtrim(e.RiskCode))) <> len(e.RiskCode) 
order by UploadDate desc
