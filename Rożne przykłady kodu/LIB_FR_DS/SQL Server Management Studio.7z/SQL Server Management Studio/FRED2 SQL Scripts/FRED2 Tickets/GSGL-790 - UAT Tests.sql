--GSGL-790 - UAT Tests

--check before

select top 100 ExposureRate,ExposureCurrency, TreatyRate, TreatyCurrency,Rate, CurrencyName, * from FinancialRisks.LossByExposure

select top 100 ExposureRate,ExposureCurrency, TreatyRate, TreatyCurrency,Rate, CurrencyName, * from FinancialRisks.vw_ExposureOverview


select max(InforceDate) LossByExposure_Max_inforceDate from FinancialRisks.LossByExposure

SELECT * from  [FinancialRisks].[AddNewData]

--TEST - Import Data 
exec UserAdmin.[dbo].[usp_start_FRED_QuarterUpdate]


exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

--Mapping
select * from FinancialRisks.CountryPseudonym cp
join FinancialRisks.Countries c on c.CountryId=cp.CountryID
where cp.CountryPseudonym like '%uk%'






--Test  - Generate LossBYExposure
exec UserAdmin.[dbo].[usp_start_FRED_GenerateLossByExposure]

exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

--Checking InforceDate

select max(InforceDate) LossByExposure_Max_inforceDate from FinancialRisks.LossByExposure
SELECT FinancialRisks.fn_GetInforceDate() AS InforceDate



--Testing LossByExposure table

select top 1000 TreatyRate, TreatyCurrency, ExposureRate, ExposureCurrency,Rate, CurrencyName,* 
from [FinancialRisks].LossBYExposure 
where (TreatyRate <> ExposureRate or TreatyCurrency<>ExposureCurrency)
and 
InforceDate='20220701' --This is just to limit rows



--UAT Testing vw_ExposureOverView view

select top 1000 TreatyRate, TreatyCurrency, ExposureRate, ExposureCurrency,Rate, CurrencyName,* 
from [FinancialRisks].vw_ExposureOverview 
where (TreatyRate <> ExposureRate or TreatyCurrency<>ExposureCurrency)
and InforceDate='20220701' --This is just to limit rows

-- UAT test of CommonShockModelFinal


exec useradmin.[dbo].[usp_start_FRED_CSMUpload]
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]


exec useradmin.[dbo].[usp_check_job_history] 'FRED_CSMUpload'


select * from [FinancialRisks].[fullCurve] where InforceDate='20220701' and ( isnumeric(Loss) = 0 or Loss is null)

select * from [FinancialRisks].[CurveByCOB] where InforceDate='20220701' and ( isnumeric(Loss) = 0 or Loss is null)
select * from [FinancialRisks].[CurveByCOB] where InforceDate='20220701' and ( isnumeric(ReinstatedLoss) = 0 or ReinstatedLoss is null)


select * from [FinancialRisks].[AALByCedant]  where InforceDate='20220701' and ( isnumeric(LossNT) = 0 or LossNT is null)
select * from [FinancialRisks].[AALByCedant]  where InforceDate='20220701' and ( isnumeric(LossNT_Unmatched) = 0 or LossNT_Unmatched is null) 
select * from [FinancialRisks].[AALByCedant]   where InforceDate='20220701' and ( isnumeric(LossNT_NotRated) = 0 or LossNT_NotRated is null)  


