--GSGL-779
--Export Data on UAT before Deploying Release


--W Execute Friday 15.07.2022  10:24
exec [UserAdmin].dbo.[usp_start_FRED_GenerateLossByExposure]

exec [dbo].[usp_check_server_agent_jobs_currently_running]


--export Data before GSGL-779 Deploy
select top 100* 
--into #vw_ExposureOverview_data_before_GSGL779
from [FinancialRisks].[vw_ExposureOverview]


select top 10 *from [FinancialRisks].[Exposures] order by ExposureId



select  riskCodeMappings.*, e.*
	FROM FinancialRisks.Exposures e
	--exposure riskcode mappings
	LEFT JOIN FinancialRisks.RiskCodeMappings riskCodeMappings ON riskCodeMappings.riskCode = e.RiskCode 
where len(ltrim(rtrim(e.RiskCode))) <> len(e.RiskCode) 



select  riskCodeMappings.*, e.*
	FROM FinancialRisks.Exposures e
	--exposure riskcode mappings
	LEFT JOIN FinancialRisks.RiskCodeMappings riskCodeMappings ON riskCodeMappings.riskCode = ltrim(rtrim(e.RiskCode))
where len(ltrim(rtrim(e.RiskCode))) <> len(e.RiskCode) 
order by UploadDate desc





USE fred
GO
SELECT [name], create_date, modify_date
FROM sys.procedures
where NAME in  ('GenerateLossByExposure') ORDER BY 3 DESC;
