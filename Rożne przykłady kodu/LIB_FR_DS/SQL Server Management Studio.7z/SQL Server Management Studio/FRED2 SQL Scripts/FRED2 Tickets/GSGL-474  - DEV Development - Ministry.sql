--kopia tabel Entities i ObligorPseudonym z produkcji 

select top 10 * from FinancialRisks.Entities_GSGL474_PROD
select top 10 * from FinancialRisks.ObligorPseudonym_GSGL474_PROD 

select EntityId,EntityName,ParentEntityName,Domicile,ParentDomicile,ObligorPseudonym,ObligorID,*
 from FinancialRisks.Entities_GSGL474_PROD e
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on op.obligorID=e.entityID
where LOWER(EntityName) LIKE '%ministry%finance%'


select top 10 * from FinancialRisks.ObligorPseudonym_GSGL474_PROD 

select * from FinancialRisks.Countries
select * from FinancialRisks.Countries


--Wygenerowanie Krajow
select distinct --ltrim(rtrim(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(entityname,'ministry',''),'finance',''),' of ',''),'-',''),',',''),')',''),'(',''),'&' ,''),' and ',''),'/',''),'MOF',''),'MOEF',''),'Economy',''),' the ',''),'the ','')))
FinancialRisks.fn_CountryName_in_Input(entityname)
from FinancialRisks.Entities_GSGL474_PROD
where LOWER(EntityName) LIKE '%ministry%' 
order by FinancialRisks.fn_CountryName_in_Input(entityname)


select distinct ltrim(rtrim(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(ObligorPseudonym,'ministry',''),'finance',''),' of ',''),'-',''),',',''),')',''),'(',''),'&' ,''),' and ',''),'/',''),'MOF',''),'MOEF',''),'Economy',''),' the ',''),'the ','')))
from FinancialRisks.ObligorPseudonym_GSGL474_PROD
where LOWER(ObligorPseudonym) LIKE '%ministry%' 
order by ltrim(rtrim(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(ObligorPseudonym,'ministry',''),'finance',''),' of ',''),'-',''),',',''),')',''),'(',''),'&' ,''),' and ',''),'/',''),'MOF',''),'MOEF',''),'Economy',''),' the ',''),'the ','')))




select * from  FinancialRisks.Entities_GSGL474_PROD where 




select 
FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) country,
op.*, e.* 
from financialrisks.Entities e
left join FinancialRisks.ObligorPseudonym op on entityid = obligorid
where LOWER(EntityName) like 'MINISTRY OF finance%'
or ObligorPseudonym like '%Slovenia%'


select top 1000 
FinancialRisks.fn_CountryName_in_Input(EntityName) country,
c.CountryName, ob.*  
from FinancialRisks.Exposures e
join [FinancialRisks].[Countries] c on c.CountryId = e.CountryId
join FinancialRisks.Entities_GSGL474_PROD ob on ob.EntityId = e.ObligorEntityId
where LOWER(EntityName) LIKE '%ministry%' and
(
	LOWER(EntityName) LIKE '%finance%' OR
	LOWER(EntityName) LIKE '%defence%' OR
	LOWER(EntityName) LIKE '%defense%' OR
	LOWER(EntityName) LIKE '%national guard%' OR
	LOWER(EntityName) LIKE '%economy%'
	)
order by ExposureId desc