
--GSGL-1034 - DATAFIX #1

--TRIM RiskCode

--checking AFTER dataFIX on UAT
--RiskCode
select count(*) from [FinancialRisks].Exposures e where (datalength(RiskCode) <> datalength(ltrim(rtrim(Riskcode))))
select count(*) from [FinancialRisks].Exposures e where nullif(ltrim(rtrim(RiskCode)),'') = null

--RiskReference 
select count(*) from [FinancialRisks].Exposures e where (datalength(RiskReference) <> datalength(ltrim(rtrim(RiskReference))))
select count(*) from [FinancialRisks].Exposures e where nullif(ltrim(rtrim(RiskReference)),'') = null

--LeadSyndicate
select count(*) from [FinancialRisks].Exposures e where (datalength(LeadSyndicate) <> datalength(ltrim(rtrim(LeadSyndicate))))
select count(*) from [FinancialRisks].Exposures e where nullif(ltrim(rtrim(LeadSyndicate)),'') = null



--RiskCode Clean
select count(*)
--update e set RiskCode = ltrim(rtrim(RiskCode))
from [FinancialRisks].Exposures e where (datalength(RiskCode) <> datalength(ltrim(rtrim(Riskcode))))

select count(*)
--update e set RiskCode = nullif(ltrim(rtrim(RiskCode)),'')
from [FinancialRisks].Exposures e where nullif(ltrim(rtrim(RiskCode)),'') = null

--RiskReference Clean
select count(*)
--update e set RiskReference = nullif(ltrim(rtrim(RiskReference)),'')
from [FinancialRisks].Exposures e where (datalength(RiskReference) <> datalength(ltrim(rtrim(RiskReference))))

select count(*)
--update e set RiskReference = nullif(ltrim(rtrim(RiskReference)),'')
from [FinancialRisks].Exposures e where nullif(ltrim(rtrim(RiskReference)),'') = null

--LeadSyndicate Clean
select count(*)
--update e set LeadSyndicate = nullif(ltrim(rtrim(LeadSyndicate)),'')
from [FinancialRisks].Exposures e where (datalength(LeadSyndicate) <> datalength(ltrim(rtrim(LeadSyndicate))))

select count(*)
--update e set LeadSyndicate = nullif(ltrim(rtrim(LeadSyndicate)),'')
from [FinancialRisks].Exposures e where nullif(ltrim(rtrim(LeadSyndicate)),'') = null