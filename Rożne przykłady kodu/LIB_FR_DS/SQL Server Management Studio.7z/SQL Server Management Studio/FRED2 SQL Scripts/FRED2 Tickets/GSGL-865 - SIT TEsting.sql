

--SIT Testing

USE FRED

--start Update to fulfill queue

exec useradmin.[dbo].[usp_start_FRED_QuarterUpdate]

exec UserAdmin.[dbo].[usp_check_server_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_check_job_history] 'FRED_QuarterUpdate'


select count(*) ExposuresQueue_Qty from FinancialRisks.ExposuresQueue (nolock)
select count(*) Ironshore_Data_Queue_qty from [FinancialRisks].[Ironshore_Data_Queue] (nolock)
select count(*) TreatiesQueue_Qty from [FinancialRisks].[TreatiesQueue] (nolock)




declare @ExposuresQueue_Qty int, @Ironshore_Data_Queue_qty int, @TreatiesQueue_Qty int
 
select @ExposuresQueue_Qty = count(*) from FinancialRisks.ExposuresQueue

select @Ironshore_Data_Queue_qty = count(*) from [FinancialRisks].[Ironshore_Data_Queue]

select @TreatiesQueue_Qty = count(*) from [FinancialRisks].[TreatiesQueue]

select @ExposuresQueue_Qty ExposuresQueue_Qty, @Ironshore_Data_Queue_qty Ironshore_Data_Queue_qty, @TreatiesQueue_Qty TreatiesQueue_Qty


ExposuresQueue_Qty	Ironshore_Data_Queue_qty	TreatiesQueue_Qty
18592	13	0


exec useradmin.[dbo].[usp_start_FRED_UpdateMappings]



exec UserAdmin.[dbo].[usp_check_server_agent_jobs_currently_running]

Podczas uruchomienia wywalil sie proces s powodu braku uprawnien do uruchomienia procedury - Ticket INC000012543065

exec Useradmin.[dbo].[usp_start_FRED_IdentifyMappings]




select count(*) ExposuresQueue_Qty from FinancialRisks.ExposuresQueue (nolock)
select count(*) Ironshore_Data_Queue_qty from [FinancialRisks].[Ironshore_Data_Queue] (nolock)
select count(*) TreatiesQueue_Qty from [FinancialRisks].[TreatiesQueue] (nolock)