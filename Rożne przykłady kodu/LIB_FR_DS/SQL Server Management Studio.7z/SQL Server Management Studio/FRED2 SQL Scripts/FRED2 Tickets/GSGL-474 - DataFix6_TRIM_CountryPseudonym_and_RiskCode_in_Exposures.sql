
--GSGL-474 - DATAFIX #6



--TRIM RiskCode
update e set RiskCode = nullif(ltrim(rtrim(RiskCode)),'')
from [FinancialRisks].Exposures e where datalength(RiskCode) <> datalength(ltrim(rtrim(Riskcode)))

update e set RiskCode = nullif(ltrim(rtrim(RiskCode)),'')
from [FinancialRisks].Exposures e where ( RiskCode <> ltrim(rtrim(RiskCode)) or  nullif(ltrim(rtrim(RiskCode)),'') is null )


select datalength(RiskReference) , datalength(ltrim(rtrim(RiskReference))), nullif(ltrim(rtrim(RiskReference)),''),*
--update e set RiskReference = nullif(ltrim(rtrim(RiskReference)),'')
from [FinancialRisks].Exposures e where (datalength(RiskReference) <> datalength(ltrim(rtrim(RiskReference))) or nullif(ltrim(rtrim(RiskReference)),'') is null ) and ltrim(rtrim(RiskReference)) =''

select datalength(LeadSyndicate) , datalength(ltrim(rtrim(LeadSyndicate))), nullif(ltrim(rtrim(LeadSyndicate)),''),*
--update e set LeadSyndicate = nullif(ltrim(rtrim(LeadSyndicate)),'')
from [FinancialRisks].Exposures e where (datalength(LeadSyndicate) <> datalength(ltrim(rtrim(LeadSyndicate))) or nullif(ltrim(rtrim(LeadSyndicate)),'') is null ) and ltrim(rtrim(LeadSyndicate)) =''



