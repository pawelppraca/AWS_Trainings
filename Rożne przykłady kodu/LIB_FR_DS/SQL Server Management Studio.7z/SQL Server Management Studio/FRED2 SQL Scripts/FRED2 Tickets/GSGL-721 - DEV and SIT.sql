
DECLARE @InforceDate DATETIME 
SELECT @InforceDate = FinancialRisks.fn_GetInforceDate() 
select @InforceDate

Select InforceDate, CobId, count(*)  
--delete
FROM [FinancialRisks].[Exposures]
WHERE CobId in ( 1,2 ) and [InforceDate] = '2022-01-01T00:00:00.000'
group by  InforceDate, CobId

select InforceDate, CobId, count(*) 
--delete
FROM [FinancialRisks].[ExposuresQueue]
WHERE CobId in ( 1,2 ) and [InforceDate] = '2022-01-01T00:00:00.000'
group by  InforceDate, CobId

-- Sztuczne dodanie rekord�w w celu sprawdzenia usuniecia.
-- Intensional adding records

-- Table Exposures
--Records with COBid = 2
insert into [FinancialRisks].[Exposures] (CedantId,CobId,RiskReference,CurrencyId,Year,DataQuarter,AssuredEntityId,RiskCode,LeadSyndicate,CountryId,InceptionDate,ExpiryDate,Limit,UsdLimit,GrossPremium,GrossExposure,ObligorEntityId,InforceDate,Source,ObligorPseudID,CountryPseudID,SBU,Office,AssumedLive,ProductLine,NoBillingOffsetTotalSuretyExposureNetPGE,NetSuretyExposure,Region,Assured,LGDSD_Surety,Max_Cap,Collateral,UploadDate)
Select top 3 CedantId,2,RiskReference,CurrencyId,Year,DataQuarter,AssuredEntityId,RiskCode,LeadSyndicate,CountryId,InceptionDate,ExpiryDate,Limit,UsdLimit,GrossPremium,GrossExposure,ObligorEntityId,'2022-01-01T00:00:00.000',Source,ObligorPseudID,CountryPseudID,SBU,'Pawel_P',AssumedLive,ProductLine,NoBillingOffsetTotalSuretyExposureNetPGE,NetSuretyExposure,Region,Assured,LGDSD_Surety,Max_Cap,Collateral,UploadDate
FROM [FinancialRisks].[Exposures] order by exposureid desc

--Records with COBid = 1
insert into [FinancialRisks].[Exposures] (CedantId,CobId,RiskReference,CurrencyId,Year,DataQuarter,AssuredEntityId,RiskCode,LeadSyndicate,CountryId,InceptionDate,ExpiryDate,Limit,UsdLimit,GrossPremium,GrossExposure,ObligorEntityId,InforceDate,Source,ObligorPseudID,CountryPseudID,SBU,Office,AssumedLive,ProductLine,NoBillingOffsetTotalSuretyExposureNetPGE,NetSuretyExposure,Region,Assured,LGDSD_Surety,Max_Cap,Collateral,UploadDate)
Select top 6 CedantId,1,RiskReference,CurrencyId,Year,DataQuarter,AssuredEntityId,RiskCode,LeadSyndicate,CountryId,InceptionDate,ExpiryDate,Limit,UsdLimit,GrossPremium,GrossExposure,ObligorEntityId,'2022-01-01T00:00:00.000',Source,ObligorPseudID,CountryPseudID,SBU,'Pawel_P',AssumedLive,ProductLine,NoBillingOffsetTotalSuretyExposureNetPGE,NetSuretyExposure,Region,Assured,LGDSD_Surety,Max_Cap,Collateral,UploadDate
FROM [FinancialRisks].[Exposures] order by exposureid desc

--ExposuresQueue
--Records with COBid = 1
insert into  [FinancialRisks].[ExposuresQueue] (CedantName,CobId,RiskReference,CurrencyId,Year,DataQuarter,AssuredEntityId,RiskCode,LeadSyndicate,CountryName,InceptionDate,ExpiryDate,Limit,UsdLimit,GrossPremium,GrossExposure,ObligorEntityName,InforceDate,Status,Source,UserNotified,ObligorPseudID,CountryPseudID,SBU,Office,AssumedLive,ProductLine,NoBillingOffsetTotalSuretyExposureNetPGE,NetSuretyExposure,Region,Assured,LGDSD_Surety,Max_Cap,Collateral,LocalId)
select top 3 
	CedantName,1,RiskReference,CurrencyId,Year,DataQuarter,AssuredEntityId,RiskCode,LeadSyndicate,CountryName,InceptionDate,ExpiryDate,Limit,UsdLimit,GrossPremium,GrossExposure,ObligorEntityName,'2022-01-01T00:00:00.000',Status,Source,UserNotified,ObligorPseudID,CountryPseudID,SBU,'Pawel_P',AssumedLive,ProductLine,NoBillingOffsetTotalSuretyExposureNetPGE,NetSuretyExposure,Region,Assured,LGDSD_Surety,Max_Cap,Collateral,LocalId
from [FinancialRisks].[ExposuresQueue_temp_PP]

--Records with COBid = 2
insert into  [FinancialRisks].[ExposuresQueue] (CedantName,CobId,RiskReference,CurrencyId,Year,DataQuarter,AssuredEntityId,RiskCode,LeadSyndicate,CountryName,InceptionDate,ExpiryDate,Limit,UsdLimit,GrossPremium,GrossExposure,ObligorEntityName,InforceDate,Status,Source,UserNotified,ObligorPseudID,CountryPseudID,SBU,Office,AssumedLive,ProductLine,NoBillingOffsetTotalSuretyExposureNetPGE,NetSuretyExposure,Region,Assured,LGDSD_Surety,Max_Cap,Collateral,LocalId)
select top 3 
	CedantName,2 CobId,RiskReference,CurrencyId,Year,DataQuarter,AssuredEntityId,RiskCode,LeadSyndicate,CountryName,InceptionDate,ExpiryDate,Limit,UsdLimit,GrossPremium,GrossExposure,ObligorEntityName,'2022-01-01T00:00:00.000' InforceDate,Status,Source,UserNotified,ObligorPseudID,CountryPseudID,SBU,'Pawel_P' Office,AssumedLive,ProductLine,NoBillingOffsetTotalSuretyExposureNetPGE,NetSuretyExposure,Region,Assured,LGDSD_Surety,Max_Cap,Collateral,LocalId
from [FinancialRisks].[ExposuresQueue_temp_PP]


SELECT *
--update ad set AddNewData='False'
FROM [FinancialRisks].[AddNewData] ad 

  select * from mi.fred_GFR



Select 'Exposures' TableName, InforceDate, CobId, count(*) RecordsCount
FROM [FinancialRisks].[Exposures]
WHERE CobId in ( 1,2 ) 
and Office='Pawel_P'
group by  InforceDate, CobId

select 'ExposuresQueue' Tablename, InforceDate, CobId, count(*) RecordsCount
FROM [FinancialRisks].[ExposuresQueue]
WHERE CobId in ( 1,2 ) 
and Office='Pawel_P'
group by  InforceDate, CobId



Select 'Exposures' TableName, InforceDate, CobId, count(*) RecordsCount
FROM [FinancialRisks].[Exposures]
WHERE CobId in ( 1,2 )
group by  InforceDate, CobId

select 'ExposuresQueue' Tablename, InforceDate, CobId, count(*) RecordsCount
FROM [FinancialRisks].[ExposuresQueue]
WHERE CobId in ( 1,2 ) 
group by  InforceDate, CobId






