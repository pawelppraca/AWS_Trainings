
--Ministry Obligors without Country Name

select FinancialRisks.fn_CountryName_in_Input(EntityName)  Country,Domicile,* 
from financialrisks.Entities_GSGL474_PROD e
where LOWER(EntityName) LIKE '%ministry%' 
	and (LOWER(EntityName) LIKE '%finance%' OR LOWER(EntityName) LIKE '%defence%' OR	LOWER(EntityName) LIKE '%defense%' OR LOWER(EntityName) LIKE '%national guard%' OR	LOWER(EntityName) LIKE '%economy%')
and FinancialRisks.fn_CountryName_in_Input(EntityName) is null


--Ministry Obligors with Country Name

select FinancialRisks.fn_CountryName_in_Input(EntityName)  Country_substring, Domicile,* 
from financialrisks.Entities_GSGL474_PROD e
where LOWER(EntityName) LIKE '%ministry%' 
	and (LOWER(EntityName) LIKE '%finance%' OR LOWER(EntityName) LIKE '%defence%' OR	LOWER(EntityName) LIKE '%defense%' OR LOWER(EntityName) LIKE '%national guard%' OR	LOWER(EntityName) LIKE '%economy%')
and FinancialRisks.fn_CountryName_in_Input(EntityName) is not null
and FinancialRisks.fn_CountryName_in_Input(EntityName) <> Domicile

--Ministry Pseudonyms for more than 1 country
select 
count(distinct FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym)) countries
,op.obligorid, e.EntityName
into #pseudonym_obligors_multiple_countries
from financialrisks.Entities_GSGL474_PROD e
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on entityid = obligorid
where LOWER(EntityName) LIKE '%ministry%' 
	and (LOWER(EntityName) LIKE '%finance%' OR LOWER(EntityName) LIKE '%defence%' OR	LOWER(EntityName) LIKE '%defense%' OR LOWER(EntityName) LIKE '%national guard%' OR	LOWER(EntityName) LIKE '%economy%')
group by op.obligorid, e.EntityName
having count(distinct FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym)) > 1 -- diff than one country
order by count(distinct FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym)) desc

select * from #pseudonym_obligors_multiple_countries 

--List of Ministry for more than 1 country


--5078 --Cyprus, Cyprus, Pakistan
--1228051 --Angola, Seychelles, Bahamas
--2919521 -- United Arab Emirates, Turkey, India, Israel, Nigeria, WORLDWIDE

--List of Ministry
select 
FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) country, e.Domicile
,op.*, EntityId,EntityName	,	ParentEntityName	,	Domicile	,	ParentDomicile, e.*
from financialrisks.Entities_GSGL474_PROD e
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on entityid = obligorid

where LOWER(EntityName) LIKE '%ministry%' 
	and (LOWER(EntityName) LIKE '%finance%' OR LOWER(EntityName) LIKE '%defence%' OR	LOWER(EntityName) LIKE '%defense%' OR LOWER(EntityName) LIKE '%national guard%' OR	LOWER(EntityName) LIKE '%economy%')
and op.obligorid in (2919521)--,1228051,2919521)
order by op.ObligorID


--Exposures 

select c.CountryName,  ob.EntityId, ob.EntityName, obp.ObligorPseudonym, FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) Ministry_country, ex.*, ob.*, obp.*
--select distinct ObligorPseudID

from [FinancialRisks].[Exposures_2021_2022_GSGL474_PROD] ex
join [FinancialRisks].[Countries_GSGL474_PROD] c on c.CountryId=ex.CountryId
join financialrisks.Entities_GSGL474_PROD ob on ob.EntityId = ex.ObligorEntityId
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD obp on obp.ObligorPseudonymId=ex.ObligorPseudID --and ex.ObligorEntityId<> obp.ObligorID
where --ex.ObligorEntityId=5078
 ObligorPseudID in (5078) --(16677, 16678, 16679, 16680, 16681, 60182, 302432)
and 
isnull(FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym),'') <> c.CountryName
and ex.source='Data_Atradius_QS_Credit_Retro_PriCCY.xlsx'


select c.CountryName,  ob.EntityId, ob.EntityName, obp.ObligorPseudonym, FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) Ministry_country, ex.*, ob.*, obp.*
--select distinct ObligorPseudID

from [FinancialRisks].[Exposures_2021_2022_GSGL474_PROD] ex
join [FinancialRisks].[Countries_GSGL474_PROD] c on c.CountryId=ex.CountryId
join financialrisks.Entities_GSGL474_PROD ob on ob.EntityId = ex.ObligorEntityId
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD obp on obp.ObligorPseudonymId=ex.ObligorPseudID --and ex.ObligorEntityId<> obp.ObligorID
where ob.EntityName='MINISTRY OF DEFENCE AND MILITARY'
-- ObligorPseudID in (16677, 16678, 16679, 16680, 16681, 60182, 302432)
--and 
--isnull(FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym),'') <> c.CountryName
and ex.source='Data_Atradius_QS_Credit_Retro_PriCCY.xlsx'


MINISTRY OF DEFENCE AND MILITARY
/*
Questions:
1. For what countries should be created Ministry (defence,finance,national guard, economy) + Country ? Only for this which are wrong mapped?
2. What about of Ministry without country name - should be created as well


*/