/* Opis zdania (1 krok z GSGL-677)


Porownac liste krajow  z Countries  i z PDF
Jesli kraje roznia sie nazwa to utworzyc nowy rekord w CountryPseudonym dla starej nazwy 
i powiazac go z nowa nazwa

Porownanie zrobic po CapitalIqId

*/


select * from FinancialRisks.Countries

select * from FinancialRisks.CountryPseudonym cp
join FinancialRisks.Countries c on c.CountryId=cp.CountryID 
where c.CountryName like '%United States%'

select * from FinancialRisks.CountryPseudonym cp
join FinancialRisks.Countries c on c.CountryId=cp.CountryID 
where c.CountryName like '%United K%'


select top 100 * from FinancialRisks.LossbyExposure where country


--Nowa tabela
create table FinancialRisks.SP_Countries (CountryName varchar(100), ISO varchar(10),CountryCapitalIqId varchar(100))


select spc.* from SP_Countries spc
join FinancialRisks.Countries c on c.CountryCapitalIqId=spc.CountryCapitalIqId
where spc.CountryName<> c.CountryName
and len(c.CountryCapitalIqId) > 0


select * from SP_Countries spc where len(spc.CountryCapitalIqId) = 0

select * from FinancialRisks.Countries c where len(c.CountryCapitalIqId) = 0

select * from  SP_Countries where countryname like 'C%'


select * from FinancialRisks.Countries where CountryCapitalIqId='IQ32584608'


--DataFIx na kraje

-- Add pseudonym for countries which will be updated which don't exists

--insert into FinancialRisks.CountryPseudonym(countryID,countrypseudonym)
select c.countryID, c.CountryName 
from SP_Countries spc
join FinancialRisks.Countries c on c.CountryCapitalIqId=spc.CountryCapitalIqId
left join FinancialRisks.CountryPseudonym cp on cp.countrypseudonym=c.CountryName
where spc.CountryName<> c.CountryName
and len(c.CountryCapitalIqId) > 0
and cp.CountryPseudonymId is null --only this pseudonyms which don't exists


--Update CountryName
select c.countryID, c.CountryName , spc.*, c.*
--update c set CountryName = spc.CountryName
from SP_Countries spc
join FinancialRisks.Countries c on c.CountryCapitalIqId=spc.CountryCapitalIqId --teh same CapitalCapIq
--left join FinancialRisks.CountryPseudonym cp on cp.countrypseudonym=c.CountryName
where spc.CountryName <> c.CountryName --different names
and len(c.CountryCapitalIqId) > 0  


--Backup danych

--backup tabeli Countries
select * 
--into FinancialRisks.Countries_before_GSGL_677
from FinancialRisks.Countries

select * 
--into FinancialRisks.CountryPseudonym_before_GSGL_677
from FinancialRisks.CountryPseudonym

--dane do usuniecia z Pseudonyms
select * 
--delete from cp
from  FinancialRisks.CountryPseudonym cp
left join FinancialRisks.CountryPseudonym_before_GSGL_677 cp_bkp on cp_bkp.CountryPseudonymId = cp.CountryPseudonymId
where cp_bkp.CountryPseudonymId is null


--przywrocenie update
 select * 
 --update c set countryname=bkp.countryname
 from FinancialRisks.Countries_before_GSGL_677 bkp
join  FinancialRisks.Countries c on c.CountryId=bkp.countryid
where bkp.countryname<>c.CountryName




--Przygotowac Skrypt do update i wrzucic na DEV i SIT

--DEV Update - DONE

--Sprawdzenie

select c.countryID, c.CountryName, spc.*, c.*
from SP_Countries spc
join FinancialRisks.Countries c on c.CountryCapitalIqId=spc.CountryCapitalIqId
left join FinancialRisks.CountryPseudonym cp on cp.countrypseudonym=c.CountryName
where spc.CountryName<> c.CountryName
and len(c.CountryCapitalIqId) > 0


--Sprawdzenie County ISOCode

select * 
from SP_Countries spc
join FinancialRisks.Countries c on c.CountryCapitalIqId=spc.CountryCapitalIqId
and ISO2Code <> ISO
and len(c.CountryCapitalIqId) > 0







--SIT Deploy done
--But I found, that in Country List there are two countries with the same CapId Iq IQ20530761 i IQ28321656

select * from FinancialRisks.Countries where CountryCapitalIqId='IQ20530761'

select * from  SP_Countries where CountryCapitalIqId='IQ20530761'


select * from FinancialRisks.Countries where CountryCapitalIqId='IQ28321656'

select * from  SP_Countries where CountryCapitalIqId='IQ28321656'

select * from FinancialRisks.Countries_before_GSGL_677 where CountryCapitalIqId='IQ20530761'
select * from FinancialRisks.Countries_before_GSGL_677 where CountryCapitalIqId='IQ28321656'


select * from FinancialRisks.CountryPseudonym where CountryPseudonym='Russian Federation'

select * from FinancialRisks.CountryPseudonym where Countryid=174

select * from FinancialRisks.Countries where Countryid=174


--POprawka na na DEV and SIT - korekta podw�jnych CapIqID
Romania - IQ20530761
Oman - IQ24844183
Guinea - IQ38574382
Papua New Guinea - IQ28321656

select * from SP_Countries where countryname in ('Romania','Oman','Guinea','Papua New Guinea') or CountryName like '%Ivoire'
/*
UPDATE SP_Countries SET CountryCapitalIqId = 'IQ20530761' WHERE countryname = 'Romania'
UPDATE SP_Countries SET CountryCapitalIqId = 'IQ24844183' WHERE countryname = 'Oman'
UPDATE SP_Countries SET CountryCapitalIqId = 'IQ38574382' WHERE countryname = 'Guinea'
UPDATE SP_Countries SET CountryCapitalIqId = 'IQ28321656' WHERE countryname = 'Papua New Guinea'
*/



select c.countryID, c.CountryName , spc.*, c.*
--update c set CountryName = spc.CountryName
from SP_Countries spc
left join FinancialRisks.Countries c on  c.CountryName=spc.CountryName
where spc.CountryName in ('Romania','Oman','Guinea','Papua New Guinea')
--c.CountryCapitalIqId=spc.CountryCapitalIqId --teh same CapitalCapIq
left join FinancialRisks.CountryPseudonym cp on cp.countrypseudonym=c.CountryName
where spc.CountryName <> c.CountryName --different names
and len(c.CountryCapitalIqId) > 0  



select * from SP_Countries spc where CountryName in ('Romania','Oman','Guinea','Papua New Guinea') or CountryName like '%Ivoire'


select * from FinancialRisks.Countries c where CountryName in ('Romania','Oman','Guinea','Papua New Guinea') or CountryName like '%Ivoire'
select * from FinancialRisks.CountryPseudonym cp where CountryPseudonym in ('Romania','Oman','Guinea','Papua New Guinea') or CountryPseudonym like '%Ivoire'