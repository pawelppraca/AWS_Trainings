use fred

SELECT    									
                        DISTINCT    									
                        ccyFrom.CurrencyCode  AS 'Name'	,								
                        roe.ExchangeRate   AS 'rate',
						YEAR(roe.ExchangeRateDateKey) AS 'year'
					--into #CurrencyFXRates	 									
            FROM    									
                        [sources].[vw_dwhr_Currencies] ccyFrom   									
                        INNER JOIN sources.vw_dwhr_ISOCurrencies ccyFromISO ON ccyFrom.ISOCurrencyKey = ccyFromISO.ISOCurrencyKey   									
                        INNER JOIN sources.vw_dwhr_ExchangeRates roe ON ccyFromISO.ISOCurrencyKey = roe.ISOCurrencyFromKey   									
                        INNER JOIN sources.vw_dwhr_ISOCurrencies ccyToISO ON roe.ISOCurrencyToKey = ccyToISO.ISOCurrencyKey   									
            WHERE    									
                        ccyToISO.ISOCurrencyCode = N'USD'   									
                      --  AND roe.ExchangeRateTypeCode = N'[Lloyd''s PIM]'  									
						AND roe.ExchangeRateTypeCode = N'[GAAP Plan]' 			
						AND YEAR(roe.ExchangeRateDateKey) = year(getdate()) 



USE Warehouse_Repository

/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [ExchangeRateKey]
      ,[ISOCurrencyFromKey]
      ,[ISOCurrencyToKey]
      ,[ExchangeRateDateKey]
      ,[ExchangeRateTypeCode]
      ,[ExchangeRateTypeName]
      ,[ExchangeRate]
      ,[_DateCreated]
      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_SourceSystemCode]
  FROM [Warehouse_Repository].[mi].[ExchangeRates]
  where ExchangeRateTypeCode = N'[GAAP Plan]' 


  exec useradmin.[dbo].[usp_check_job_history] 'FRED_GFRSource'