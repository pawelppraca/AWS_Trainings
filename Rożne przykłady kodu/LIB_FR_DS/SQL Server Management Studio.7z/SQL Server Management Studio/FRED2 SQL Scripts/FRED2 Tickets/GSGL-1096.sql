alter table [FinancialRisks].[ExposuresStaging] add [Industry] VARCHAR(250) NULL
alter table [FinancialRisks].[ExposuresQueue] add [Industry] VARCHAR(250) NULL
alter table [FinancialRisks].[Exposures] add [Industry] VARCHAR(250) NULL



alter table [FinancialRisks].[ExposuresStaging] drop column [Industry]
alter table [FinancialRisks].[ExposuresQueue] drop column [Industry]
alter table [FinancialRisks].[Exposures] drop column [Industry]


select top 10 * from [FinancialRisks].[ExposuresStaging]
select top 10 * from [FinancialRisks].[ExposuresQueue]
select top 10 * from [FinancialRisks].[Exposures]


-- GSGL-1096 DEV TESTS

exec useradmin.[dbo].[usp_start_FRED_QuarterUpdate]

 exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]




select Industry, * from [FinancialRisks].[ExposuresQueue] where Industry is not null
select Industry, * from [FinancialRisks].[Exposures]  where Industry is not null

exec useradmin.[dbo].[usp_start_FRED_GenerateLossByExposure]



select * from [FinancialRisks].vw_ExposureOverview  where Industry is not null






-- GSGL-1096 SIT TESTS

use FRED


select  Industry,* from [FinancialRisks].[ExposuresStaging]
select Industry,* from [FinancialRisks].[ExposuresQueue]
select top 10 Industry,* from [FinancialRisks].[Exposures] where Industry is not null




exec useradmin.[dbo].[usp_start_FRED_QuarterUpdate]



 exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

 select top 10 Industry,* from [FinancialRisks].[Exposures] where Industry is not null


 select * from [FinancialRisks].vw_ExposureOverview  where Industry is not null



 

-- GSGL-1096 UAT TESTS

use FRED


select  Industry,* from [FinancialRisks].[ExposuresStaging]
select Industry,* from [FinancialRisks].[ExposuresQueue]
select top 10 Industry,* from [FinancialRisks].[Exposures] where Industry is not null




exec useradmin.[dbo].[usp_start_FRED_QuarterUpdate]



 exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

 select top 10 Industry,* from [FinancialRisks].[Exposures] where Industry is not null


 select Industry, * from [FinancialRisks].vw_ExposureOverview  where Industry is not null and uploaddate='2023-06-30T00:00:00.000'