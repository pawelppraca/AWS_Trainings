Sprawdzenie danych przed importem GSGL-788


--Dev Env before test
select cobid, count(*) from FinancialRisks.Exposures group by cobid order by cobid


select * from FinancialRisks.ExposuresStaging


select top 1000 * from FinancialRisks.Exposures


select * from FinancialRisks.Exposures where cobid = 3

select * from FinancialRisks.Exposures where Source like 'Data_CGIC_QS_Credit_PriCCY.xlsx' or Source ='Data_CGIC_XL_Credit_PriCCY.xlsx'

SELECT FinancialRisks.fn_GetInforceDate() AS InforceDate


select * from [mi].[FRED_GFR]


select *  from FinancialRisks.ExposuresQueue

select max(InforceDate)  from FinancialRisks.Exposures where COBId=2

	SELECT CedantId, Name
	FROM FinancialRisks.Cedant
	where name in ('CGIC_QS_Credit','CGIC_XL_Credit')


select * from FinancialRisks.IronShore_data_Queue




Testowanie PTC

select * from FinancialRisks.ExposuresQueue

select * from FinancialRisks.TreatiesQueue

------------------------------
Testing PecLines.dtsx
-----------------------------

--Dev Env before test
select cobid, count(*) from FinancialRisks.Exposures group by cobid order by cobid

select * from FinancialRisks.Exposures where cobid  in (4,5)


select * from FinancialRisks.Exposures where Source like 'Data_CGIC_QS_Credit_PriCCY.xlsx' or Source ='Data_CGIC_XL_Credit_PriCCY.xlsx'

select * from FinancialRisks.Exposures



select * from FinancialRisks.TreatiesQueue

--Dev Env After test
select cobid, count(*) from FinancialRisks.Exposures group by cobid order by cobid


select * from FinancialRisks.Exposures where Source like 'Data_CGIC_QS_Credit_PriCCY.xlsx' or Source ='Data_CGIC_XL_Credit_PriCCY.xlsx'






--2 try before Test PecLines

SELECT [ExposureQueueId]
           ,[CedantName]
      ,[CobId]
      ,[RiskReference]
      ,[CurrencyId]
      ,[Year]
      ,[DataQuarter]
      ,[AssuredEntityId]
      ,[RiskCode]
      ,[LeadSyndicate]
      ,[CountryName]
      ,[InceptionDate]
      ,[ExpiryDate]
      ,[Limit]
      ,[UsdLimit]
      ,[GrossPremium]
      ,[GrossExposure]
      ,SUBSTRING([FinancialRisks].[fn_RemoveBadChar]([ObligorEntityName]),1,100) ObligorEntityName
      ,[InforceDate]
      ,[Status]
      ,[Source]
      ,[UserNotified]
      ,[ObligorPseudID]
      ,[CountryPseudID]
      ,[SBU]
      ,[Office]
      ,[AssumedLive]
      ,[ProductLine]
      ,[NoBillingOffsetTotalSuretyExposureNetPGE]
      ,[NetSuretyExposure]
      ,[Region]
      ,SUBSTRING([FinancialRisks].[fn_RemoveBadChar]([Assured]),1,50) Assured
  FROM [FinancialRisks].[ExposuresStaging]



  select * from FinancialRisks.ExposuresQueue




  
SELECT 
	   eq.ExposureQueueId,
	   [CedantName]as [CedantId]
      ,[CobId]
      ,[RiskReference]
      ,[CurrencyId]
      ,[Year]
      ,[DataQuarter]
      ,[AssuredEntityId]
      ,[RiskCode]
      ,[LeadSyndicate]
      ,[CountryName]as CountryID
      ,[InceptionDate]
      ,[ExpiryDate]
      ,[Limit]
      ,[UsdLimit]
      ,[GrossPremium]
      ,[GrossExposure]
      ,[ObligorEntityName] AS EntityId
      ,[InforceDate],[source],ObligorPseudID,CountryPseudID,SBU,Office,
	  AssumedLive,NoBillingOffsetTotalSuretyExposureNetPGE,NetSuretyExposure,ProductLine,region,assured,LGDSD_Surety,Max_Cap,Collateral,LocalId
select *	    
  FROM [FinancialRisks].[ExposuresQueue] eq
  where ISNUMERIC([CedantName]) = 1 
  and  ISNUMERIC([CountryName]) =1 
  and ISNUMERIC([ObligorEntityName]) =1
  and    [Status] = 'NEW'
  AND [CobId] = 3