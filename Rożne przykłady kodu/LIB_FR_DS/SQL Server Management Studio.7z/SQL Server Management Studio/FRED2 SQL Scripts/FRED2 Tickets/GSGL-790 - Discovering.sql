
--Changes related to GSGL-790

--Change column names in LosByExposure

--EXEC sp_rename 'FinancialRisks.LossByExposure.Rate', 'TreatyRate', 'COLUMN';
--EXEC sp_rename 'FinancialRisks.LossByExposure.CurrencyName', 'ExposureCurrency', 'COLUMN';

--usuni?cie kolumn
alter table FinancialRisks.LossByExposure drop column Rate
alter table FinancialRisks.LossByExposure drop column CurrencyName

--add new columns
alter table FinancialRisks.LossByExposure add TreatyRate numeric(18,7)
alter table FinancialRisks.LossByExposure add ExposureCurrency nvarchar(50)
alter table FinancialRisks.LossByExposure add ExposureRate numeric(18,7)
alter table FinancialRisks.LossByExposure add TreatyCurrency nvarchar(50)

--Modification of LossbyExposure Table
	[LocalId] INT NULL,
	TreatyRate numeric(18,7) NULL,
	ExposureCurrency nvarchar(50) NULL,
	ExposureRate numeric(18,7) NULL,
	TreatyCurrency nvarchar(50) NULL


--Revoke Changes related to GSGL-790

EXEC sp_rename 'FinancialRisks.LossByExposure.TreatyRate', 'Rate', 'COLUMN';
EXEC sp_rename 'FinancialRisks.LossByExposure.ExposureCurrency', 'CurrencyName', 'COLUMN';

alter table FinancialRisks.LossByExposure drop column TreatyCurrency
alter table FinancialRisks.LossByExposure drop column ExposureRate


select top 100 * from [FinancialRisks].[LossByExposure]

--Test  - Generate LossBYExposure
exec [FinancialRisks].[GenerateLossByExposure]


select top 1000 TreatyRate, TreatyCurrency, ExposureRate, ExposureCurrency,* 
from [FinancialRisks].LossBYExposure 
where TreatyRate <> ExposureRate or TreatyCurrency<>ExposureCurrency
and InforceDate='20230101' --This is just to limit rows

--Testing Exposure Overview
select top 1000 TreatyRate, TreatyCurrency, ExposureRate, ExposureCurrency,* 
from [FinancialRisks].vw_ExposureOverview_v2 
where TreatyRate <> cast(ExposureRate as varchar) or TreatyCurrency<>ExposureCurrency
and InforceDate='20230101' --This is just to limit rows



--Zmiany wymagaj?
fn_LBEByRiskCodeCountry.sql
Stored Procedures\CommonShockModelFinal.sql
