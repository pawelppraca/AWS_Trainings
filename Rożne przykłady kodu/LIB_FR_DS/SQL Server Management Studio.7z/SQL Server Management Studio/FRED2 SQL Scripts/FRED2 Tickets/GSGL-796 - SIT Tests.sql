-------- GSGL-796 - SIT TESTS  --------------------------

-- Put the files to propoer folders and Run Quarter Update JOB


  select * from [FinancialRisks].[ExposuresQueue] 
  WHERE  ([CountryName] is null or [CountryName] ='')
  and [Status] = 'NEW'
  AND [CobId] = 6
  and ISNUMERIC([ObligorEntityName]) = 1

  select * from [FinancialRisks].[ExposuresQueue] 
  WHERE 
  [Status] = 'NEW'
  AND [CobId] = 6
  and ISNUMERIC([ObligorEntityName]) = 0
  and isnull(CountryName,0) <> 230


  



select name, create_date, modify_date
from sys.procedures
where name = 'uspCleanupExposureStaging'
