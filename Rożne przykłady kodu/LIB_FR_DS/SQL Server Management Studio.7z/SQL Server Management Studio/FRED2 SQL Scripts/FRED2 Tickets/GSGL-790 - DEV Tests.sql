--check before

select top 100 ExposureRate,ExposureCurrency, TreatyRate, TreatyCurrency,Rate, CurrencyName, * from FinancialRisks.LossByExposure

select top 100 ExposureRate,ExposureCurrency, TreatyRate, TreatyCurrency,Rate, CurrencyName, * from FinancialRisks.vw_ExposureOverview

SELECT * from  [FinancialRisks].[AddNewData]


SELECT FinancialRisks.fn_GetInforceDate() AS InforceDate
--Test  - Generate LossBYExposure
exec [FinancialRisks].[GenerateLossByExposure]


select top 1000 TreatyRate, TreatyCurrency, ExposureRate, ExposureCurrency,Rate, CurrencyName,* 
from [FinancialRisks].LossBYExposure 
where (TreatyRate <> ExposureRate or TreatyCurrency<>ExposureCurrency)
and InforceDate='20230101' --This is just to limit rows

select top 1000 TreatyRate, TreatyCurrency, ExposureRate, ExposureCurrency,Rate, CurrencyName,* 
from [FinancialRisks].vw_ExposureOverview
where TreatyRate <> ExposureRate or TreatyCurrency<>ExposureCurrency
and InforceDate='20230101' --This is just to limit rows




exec [FinancialRisks].[CommonShockModelFinal] '20230101' 

select * from [FinancialRisks].CSMOutputR