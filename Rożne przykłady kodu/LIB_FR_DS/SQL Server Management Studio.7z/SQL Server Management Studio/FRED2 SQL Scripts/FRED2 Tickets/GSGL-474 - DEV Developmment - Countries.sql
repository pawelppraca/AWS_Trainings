
--Wyszukanie kraj�w kt�rych Brakuje a kt�re s? w Domicle dla OverrideTradeSectorId=262 

select Domicile,* from FinancialRisks.Countries c
right join 
(
	select distinct Domicile  
	from FinancialRisks.Entities where Domicile is not null and OverrideTradeSectorId=262 
) d on d.Domicile=c.CountryName
where CountryId is null

--OK = Nie ma Krajow ktore sa w Domicile a nie ma ich w Countries

--Wyszukanie kraj�w kt�rych Brakuje a kt�re s? w Domicle dla wszystkich, nie tylko dla 262

select Domicile,* from FinancialRisks.Countries c
right join 
(
	select distinct Domicile  
	from FinancialRisks.Entities where Domicile is not null 
) d on d.Domicile=c.CountryName
where CountryId is null


--Poprawka dla kraj�w - wielokrotnosc kraj�w z tym samym CAPIQ
select count(*), CountryCapitalIqId
from FinancialRisks.Countries 
group by CountryCapitalIqId
having count(*)>1

--DATAFIX Correct CAPIQ - START

--Tu Doda? tabel? #SP_Countries

--Update only for Armienia base ond SP_Countries
update c set CountryName='Armenia', CountryCapitalIqId='IQ34120383' from FinancialRisks.Countries c where CountryCapitalIqId = 'IQ30189743' and Alpha3Code='ARM'

--Correct CapitalIQ related to SP_Countries
update c set CountryCapitalIqId = spc.CountryCapitalIqId 
from SP_Countries spc
join FinancialRisks.Countries c on  c.CountryName=spc.CountryName and c.CountryCapitalIqId <> spc.CountryCapitalIqId

--DATAFIX Correct CAPIQ - END


--R?czna modyfikacja 
--update c set CountryName='Armenia', CountryCapitalIqId='IQ34120383' from FinancialRisks.Countries c where CountryCapitalIqId = 'IQ30189743' and Alpha3Code='ARM'

select *
--update c set CountryCapitalIqId = spc.CountryCapitalIqId 
from SP_Countries spc
join FinancialRisks.Countries c on  c.CountryName=spc.CountryName and c.CountryCapitalIqId <> spc.CountryCapitalIqId
where c.CountryName='Tuvalu'

/*


Countries to explain:
--------------------
(Invalid Identifier)
0
Misc
Other
Reunion


Countries to Update:
-----------------------
Antigua & Barbuda
Armenia
Bosnia-Herzegovina
British Virgin Islands
Channel Islands
Democratic Republic of the Congo
Guinea-Bissau
Ivory Coast
Kosovo
Netherlands Antilles
Saint Kitts & Nevis
Saint Vincent & Grenadines
Timor-Leste
Trinidad & Tobago
Turks & Caicos Islands



*/


select d.Domicile,* 
from 
(
	select distinct Domicile  
	from FinancialRisks.Entities where Domicile is not null 
) d
left join FinancialRisks.Countries c on d.Domicile=c.CountryName
where CountryId is null
and d.Domicile not in ('(Invalid Identifier)','0','Misc','Other','Reunion')
order by d.Domicile


--Antigua & Barbuda

select * from FinancialRisks.Countries c where CountryName like '%Antigua%' or CountryName like '%Barbuda%'
select * from FinancialRisks.CountryPseudonym c where CountryPseudonym like '%Antigua%' or CountryPseudonym like '%Barbuda%'

select * from FinancialRisks.Countries c where CountryName like '%Argentina%' 
select * from FinancialRisks.CountryPseudonym c where CountryPseudonym like '%Argentina%' 
select * from FinancialRisks.Countries c where CountryId=12



--kraje ktore istnieja w CountryPseudonym i w Countries

--Lista krajow ktore sa w Domicile ale nie ma ich w Countries

select distinct Domicile
into #Domicile2Add
from 
(
	select distinct Domicile from FinancialRisks.Entities where Domicile is not null 
) d
left join FinancialRisks.Countries c on d.Domicile=c.CountryName
where CountryId is null and d.Domicile not in ('(Invalid Identifier)','0','Misc','Other','Reunion')


--kraje ktore istnieja w Pseudonym i w Countries
--drop table #Countries_in_Pseudonym

select c.CountryId , c.CountryName CountryName_in_pseudonyms
into #Countries_in_Pseudonym
from FinancialRisks.Countries c
join FinancialRisks.CountryPseudonym cp on cp.CountryID=c.CountryId
and c.CountryName = cp.CountryPseudonym
order by c.CountryName 

select * from #Countries_in_Pseudonym
select * from #Domicile2Add

 

--Dodanie do CountryPseudonym brakujacych  (Bosnia-Herzegovina  )
select CountryName, d2a.Domicile, * 
from FinancialRisks.Countries c
join FinancialRisks.CountryPseudonym cp on cp.CountryID=c.CountryId
join (
	select * from #Countries_in_Pseudonym
) c2 on c2.CountryId = c.CountryId
right join #Domicile2Add d2a on d2a.Domicile=cp.CountryPseudonym
where c.CountryId is null

--Dodanie do CountryPseudonym brakujacych  (Bosnia-Herzegovina  )
select d2a.Domicile
into #Domicile2Add_as_Pseudonym
from FinancialRisks.Countries c
join FinancialRisks.CountryPseudonym cp on cp.CountryID=c.CountryId
join (
	select * from #Countries_in_Pseudonym
) c2 on c2.CountryId = c.CountryId
right join #Domicile2Add d2a on d2a.Domicile=cp.CountryPseudonym
where c.CountryId is null

select * from #Domicile2Add_as_Pseudonym dp
left join ( 
	select * from FinancialRisks.countries 
	) c on CHARINDEX (dp.Domicile, c.CountryName) > 0


-- W Produkcji 

/*
Bolivia
Democratic Republic of the Congo
Macedonia
South Korea
Syria
Cape Verde
Falkland Islands
Moldova
Palestinian Authority
Taiwan
Venezuela
*/



insert into FinancialRisks.CountryPseudonym (CountryID, CountryPseudonym) values (26,'Bosnia-Herzegovina')




--Lista krajow, ktore mozna updaetowac

--Kraje kt�re trzeba wpisa? od nowa

Channel Islands : IQ318389235
Guinea-Bissau: IQ58105087
Netherlands Antilles: IQ58104720
Kosovo: IQ172885379


--insert into  FinancialRisks.Countries(CountryName, CountryCapitalIqId, Alpha3Code, ISO2Code, SovereignRating, Region) values ('




select CountryName, d2a.Domicile, * 
--update c set CountryName = d2a.Domicile
from FinancialRisks.Countries c
join FinancialRisks.CountryPseudonym cp on cp.CountryID=c.CountryId
join (
	select * from #Countries_in_Pseudonym
) c2 on c2.CountryId = c.CountryId
join #Domicile2Add d2a on d2a.Domicile=cp.CountryPseudonym




select * from FinancialRisks.Countries c where CountryName like '%Tuvalu%' or CountryName like '%Bosnia%'
select * from FinancialRisks.CountryPseudonym c where CountryPseudonym like '%Bosnia%' or CountryPseudonym like '%Bosnia%'

select * from #Countries_in_Pseudonym where CountryName_in_pseudonyms like '%Bosnia%'
select  Domicile from #Domicile2Add


select FinancialRisks.fn_CountryName_in_Input(EntityName) country,Domicile,*  
from FinancialRisks.Entities where OverrideTradeSectorId=262 and Domicile is not null
and FinancialRisks.fn_CountryName_in_Input(EntityName) <> Domicile




--Wyszukanie innych krajow
select *
from 
(
	select distinct Domicile from FinancialRisks.Entities where Domicile is not null 
) d
left join FinancialRisks.Countries c on d.Domicile=c.CountryName
where CountryId is null and d.Domicile  in ('(Invalid Identifier)','0','Misc','Other','Reunion')


 select * from FinancialRisks.Entities where Domicile in ('(Invalid Identifier)','0','Misc','Other','Reunion')
 
 select * from FinancialRisks.Entities where Domicile = 'Other'
 
 select * from FinancialRisks.Entities where Domicile = 'Misc'
 
 select * from FinancialRisks.Entities where Domicile = '0'



 select * from FinancialRisks.CountryPseudonym where CountryPseudonym like '%Timor%'

select * from FinancialRisks.Countries where CountryName like  '%timor%' 