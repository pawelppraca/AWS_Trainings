/* 
		TICKET gsgl-474 - POM�C rozwi?za? Conorowi
		Kraj wyci?gn?? z kolumny Exposure dla Poszczeg�lnych ministerstw
		Testy po?czenia sprawdzi? na pojedynczych kraj�w
		Nie mo?e by? MInisterstwa bez kraju po?czonogego z Konkretnym krajem\\

		USE FRED
		select op.ObligorPseudonym, * from financialrisks.Entities
		left join FinancialRisks.ObligorPseudonym op on entityid = obligorid
		where
		( LOWER(EntityName) like 'MINISTRY OF finance%' ) and
�			(LOWER(EntityName) LIKE '%finance%' OR LOWER(EntityName) LIKE '%defence%' OR�LOWER(EntityName) LIKE '%defense%' OR LOWER(EntityName) LIKE '%national guard%' OR LOWER(EntityName) LIKE '%economy%')
		or (LOWER(ObligorPseudonym) LIKE '%finance%' OR LOWER(ObligorPseudonym) LIKE '%defence%' OR LOWER(ObligorPseudonym) LIKE '%defense%' OR LOWER(ObligorPseudonym) LIKE '%national guard%' OR LOWER(ObligorPseudonym) LIKE '%economy%')
		)

		Por�wna? dla pojedynczych krajow, testowc na pojedynczych krajow

*/


--Tables with Prod DATA

select top 100  * from financialrisks.Entities_GSGL474_PROD e
select top 100 * from FinancialRisks.ObligorPseudonym_GSGL474_PROD 



--Example of angola - bledne

select FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) country,
op.*, EntityId,EntityName	,	ParentEntityName	,	Domicile	,	ParentDomicile, e.*
from financialrisks.Entities_GSGL474_PROD e
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on entityid = obligorid
where LOWER(EntityName) LIKE '%ministry%' and
(
	LOWER(EntityName) LIKE '%finance%' OR
	LOWER(EntityName) LIKE '%defence%' OR
	LOWER(EntityName) LIKE '%defense%' OR
	LOWER(EntityName) LIKE '%national guard%' OR
	LOWER(EntityName) LIKE '%economy%'

)

and (LOWER(EntityName) LIKE'%angola%' or LOWER(ObligorPseudonym) LIKE '%angola%')






--Example of Turkey - correct 

select 
FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) country
,op.*, EntityId,EntityName	,	ParentEntityName	,	Domicile	,	ParentDomicile, e.*
from financialrisks.Entities_GSGL474_PROD e
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on entityid = obligorid
where LOWER(EntityName) LIKE '%ministry%' and
(
	LOWER(EntityName) LIKE '%finance%' OR
	LOWER(EntityName) LIKE '%defence%' OR
	LOWER(EntityName) LIKE '%defense%' OR
	LOWER(EntityName) LIKE '%national guard%' OR
	LOWER(EntityName) LIKE '%economy%'

)
and (LOWER(EntityName) LIKE'%turkey%' or LOWER(ObligorPseudonym) LIKE '%turkey%')




--PseudonymObligors with different countries

DROP TABLE IF EXISTS #pseudonym_obligors_multiple_countries

select 
count(distinct FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym)) countries
,op.obligorid

into #pseudonym_obligors_multiple_countries

from financialrisks.Entities_GSGL474_PROD e
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on entityid = obligorid
where LOWER(EntityName) LIKE '%ministry%' and
(
	LOWER(EntityName) LIKE '%finance%' OR
	LOWER(EntityName) LIKE '%defence%' OR
	LOWER(EntityName) LIKE '%defense%' OR
	LOWER(EntityName) LIKE '%national guard%' OR
	LOWER(EntityName) LIKE '%economy%'
)
group by op.obligorid
having count(distinct FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym)) >1
order by count(distinct FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym)) desc


select * from #pseudonym_obligors_multiple_countries


--5078 --Cyprus, Cyprus, Pakistan
--1228051 --Angola, Seychelles, Bahamas
--2919521 -- United Arab Emirates, Turkey, India, Israel, Nigeria, WORLDWIDE


select 
FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) country
,op.*, EntityId,EntityName	,	ParentEntityName	,	Domicile	,	ParentDomicile, e.*
from financialrisks.Entities_GSGL474_PROD e
join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on entityid = obligorid
join #pseudonym_obligors_multiple_countries mc on mc.obligorid = op.obligorid
order by mc.countries

select 
FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) country
,op.*, EntityId,EntityName	,	ParentEntityName	,	Domicile	,	ParentDomicile, e.*
from financialrisks.Entities_GSGL474_PROD e
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on entityid = obligorid
where LOWER(EntityName) LIKE '%ministry%' and
(
	LOWER(EntityName) LIKE '%finance%' OR
	LOWER(EntityName) LIKE '%defence%' OR
	LOWER(EntityName) LIKE '%defense%' OR
	LOWER(EntityName) LIKE '%national guard%' OR
	LOWER(EntityName) LIKE '%economy%'
)
and op.obligorid=5078


--5078 --Qatar, Cyprus, Pakistan
--1228051 --Angola, Seychelles, Bahamas
--2919521 -- United Arab Emirates, Turkey, India, Israel, Nigeria, WORLDWIDE



select FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) country,
op.*, EntityId,EntityName	,	ParentEntityName	,	Domicile	,	ParentDomicile, e.*
from financialrisks.Entities_GSGL474_PROD e
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on entityid = obligorid
where LOWER(EntityName) LIKE '%ministry%' and
(
	LOWER(EntityName) LIKE '%finance%' OR
	LOWER(EntityName) LIKE '%defence%' OR
	LOWER(EntityName) LIKE '%defense%' OR
	LOWER(EntityName) LIKE '%national guard%' OR
	LOWER(EntityName) LIKE '%economy%'

)

and (LOWER(EntityName) LIKE'%Seychelles%' or LOWER(ObligorPseudonym) LIKE '%Seychelles%')
and FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) is null



--Questions
/*
1. What should be on fix?
	a. DataFix on current Data?
	b. 

	Solution
	1. Create new Entity in Entities for every Ministry and Country
	2. Remap in ObligorPseudonym table Ministry % of Country to new created Entities
	3. Remap in Exposures All Exposures related to Ministry %  - for Ex ObligorID=5078 to New Entity Ministry Of % + Country

	4. Create Script for remap in the Future after Upload Data during Quartely Upload
	Dodatkowo  Script or Procedure to remap EXposures do wlasciwych ministerstw
	5. ten Remaping powini byc robiony po kazdym Quarter Update
	6. uwaga na Kraje ktore maja rozne nazwy: US, United States of America, United States, America ipt - one pownny wskazywac do jednego Obligora
	Kraje 

	Mozna zapytac rowniez Stuarta Czy to co jest zrobione jest OK


	My Plan
	1. Find what Entities are relating to different countries 
	2. Check if every country from founded have its own Ministry
	3. Remap for proper country
	4. Create Minstry for country which doesn't exists
	5. Remap for new created Ministry
	6. Remap Exposures for New maped Ministry


*/

--1. Ministry related for multiply countries

select FinancialRisks.fn_CountryName_in_Input(EntityName)  Country,* 
from financialrisks.Entities_GSGL474_PROD e
where LOWER(EntityName) LIKE '%ministry%' 
	and (LOWER(EntityName) LIKE '%finance%' OR LOWER(EntityName) LIKE '%defence%' OR	LOWER(EntityName) LIKE '%defense%' OR LOWER(EntityName) LIKE '%national guard%' OR	LOWER(EntityName) LIKE '%economy%')
and FinancialRisks.fn_CountryName_in_Input(EntityName) is null


--PseudonymObligors with different countries

DROP TABLE IF EXISTS #pseudonym_obligors_multiple_zero_countries

select 
count(distinct FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym)) countries
,op.obligorid, e.EntityName

--into #pseudonym_obligors_multiple_countries

from financialrisks.Entities_GSGL474_PROD e
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on entityid = obligorid
where LOWER(EntityName) LIKE '%ministry%' 
	and (LOWER(EntityName) LIKE '%finance%' OR LOWER(EntityName) LIKE '%defence%' OR	LOWER(EntityName) LIKE '%defense%' OR LOWER(EntityName) LIKE '%national guard%' OR	LOWER(EntityName) LIKE '%economy%')
group by op.obligorid, e.EntityName
having count(distinct FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym)) > 1 -- diff than one country
order by count(distinct FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym)) desc

select * from #pseudonym_obligors_multiple_zero_countries where countries>0



--PseudonymObligors with one country (for checking)

DROP TABLE IF EXISTS #pseudonym_obligors_one_country

select 
count(distinct FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym)) countries
,op.obligorid, op.ObligorPseudonym

into #pseudonym_obligors_one_country

from financialrisks.Entities_GSGL474_PROD e
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on entityid = obligorid
where LOWER(EntityName) LIKE '%ministry%' 
	and (LOWER(EntityName) LIKE '%finance%' OR LOWER(EntityName) LIKE '%defence%' OR	LOWER(EntityName) LIKE '%defense%' OR LOWER(EntityName) LIKE '%national guard%' OR	LOWER(EntityName) LIKE '%economy%')
group by op.obligorid, op.ObligorPseudonym
having count(distinct FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym)) = 1
order by count(distinct FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym)) desc

select * from #pseudonym_obligors_one_country


--5078 --Cyprus, Cyprus, Pakistan
--1228051 --Angola, Seychelles, Bahamas
--2919521 -- United Arab Emirates, Turkey, India, Israel, Nigeria, WORLDWIDE

--List of Ministry
select 
FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) country
,op.*, EntityId,EntityName	,	ParentEntityName	,	Domicile	,	ParentDomicile, e.*
from financialrisks.Entities_GSGL474_PROD e
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on entityid = obligorid
where LOWER(EntityName) LIKE '%ministry%' 
	and (LOWER(EntityName) LIKE '%finance%' OR LOWER(EntityName) LIKE '%defence%' OR	LOWER(EntityName) LIKE '%defense%' OR LOWER(EntityName) LIKE '%national guard%' OR	LOWER(EntityName) LIKE '%economy%')
and op.obligorid=1228051


select 
FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) country
,op.*, EntityId,EntityName	,	ParentEntityName	,	Domicile	,	ParentDomicile, e.*
from financialrisks.Entities_GSGL474_PROD e
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on entityid = obligorid
where --LOWER(EntityName) LIKE '%ministry%' 
	--and (LOWER(EntityName) LIKE '%finance%' OR LOWER(EntityName) LIKE '%defence%' OR	LOWER(EntityName) LIKE '%defense%' OR LOWER(EntityName) LIKE '%national guard%' OR	LOWER(EntityName) LIKE '%economy%')
--and 
op.obligorid=1228051 and FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) is null
-- obligor pseudonym for Obligor:5078    16677, 16678 (non country), 16679, 16680, 16681(non country), 60182, 302432
-- obligor pseudonym for Obligor:1228051 with country   


select c.CountryName,  ob.EntityId, ob.EntityName, obp.ObligorPseudonym, FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym), ex.*
--select distinct ObligorPseudID

from [FinancialRisks].[Exposures_2021_2022_GSGL474_PROD] ex
join [FinancialRisks].[Countries_GSGL474_PROD] c on c.CountryId=ex.CountryId
join financialrisks.Entities_GSGL474_PROD ob on ob.EntityId = ex.ObligorEntityId
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD obp on obp.ObligorPseudonymId=ex.ObligorPseudID --and ex.ObligorEntityId<> obp.ObligorID
where --ex.ObligorEntityId=1228051
--and ObligorPseudID in (18694, 18695, 18696, 18697, 18698, 18700, 18703, 18704, 18706, 18708, 34812, 34813, 34814, 2388671)
--and 
isnull(FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym),'') = c.CountryName
and ex.InforceDate > '20220101'


5318, 18699, 18701, 18705, 2373089




ObligorEntityId
3006269
ObligorPseudID
0


select 
FinancialRisks.fn_CountryName_in_Input(ObligorPseudonym) country
,op.*, EntityId,EntityName	,	ParentEntityName	,	Domicile	,	ParentDomicile, e.*
from financialrisks.Entities_GSGL474_PROD e
join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on entityid = obligorid
join #pseudonym_obligors_multiple_countries mc on mc.obligorid = op.obligorid
order by mc.countries





-------------------------------------------
-- Poni?eszego na razie nie ROBIE
------------------------------------
--Tworzenie Nowych Ministerst dla kazdego kraju - docelowo procedura

--lista ministerstw ktore juz istnieja

select distinct EntityName, FinancialRisks.fn_CountryName_in_Input(EntityName) country 

from FinancialRisks.Entities_GSGL474_PROD
where LOWER(EntityName) LIKE '%ministry%' 
	and (LOWER(EntityName) LIKE '%finance%' OR LOWER(EntityName) LIKE '%defence%' OR	LOWER(EntityName) LIKE '%defense%' OR LOWER(EntityName) LIKE '%national guard%' OR LOWER(EntityName) LIKE '%economy%') 
order  by FinancialRisks.fn_CountryName_in_Input(EntityName)


----Przyklad kraju Cameroon

select FinancialRisks.fn_CountryName_in_Input(EntityName) country, op.*, e.*
from FinancialRisks.Entities_GSGL474_PROD e
left join FinancialRisks.ObligorPseudonym_GSGL474_PROD op on op.ObligorID=e.EntityId
where LOWER(EntityName) LIKE '%ministry%' 
	and (LOWER(EntityName) LIKE '%finance%' OR LOWER(EntityName) LIKE '%defence%' OR	LOWER(EntityName) LIKE '%defense%' OR LOWER(EntityName) LIKE '%national guard%' OR LOWER(EntityName) LIKE '%economy%') 
	and FinancialRisks.fn_CountryName_in_Input(EntityName) = 'Cameroon'
order  by FinancialRisks.fn_CountryName_in_Input(EntityName)


-- Utworzenie Ministerstw dla kazdego Kraju
-- 1. Wyciagnac Unikalne kraje z Entities

select distinct countryname from FinancialRisks.countries where len(ltrim(rtrim(CountryCapitalIqId))) > 0 or (len(ltrim(rtrim(CountryCapitalIqId))) = 0 and len(alpha3code)>0)

create table #MinistryType (name varchar (255))
insert into #MinistryType (name) values ('!Ministry of Defence - ')
insert into #MinistryType (name) values ('!Ministry of National Guard - ')
insert into #MinistryType (name) values ('!Ministry of Finance - ')


-- 2. Utworzyc dla kazdego kraju po jednym ministrstwie z kazdego rodzaju
declare @Country varchar(100)
set @Country='Cameroon'

select name+@Country from #MinistryType

select * from FinancialRisks.Entities_GSGL474_PROD

