

--Before Release-41 on DATAFix Pipeline on SIT

select * from financialrisks.COB

select distinct ActualReportingClass from [FinancialRisks].[TreatyReassignment] 


--After Deployemnt of Release-41 of DataFix

select * from financialrisks.COB

select distinct ActualReportingClass from [FinancialRisks].[TreatyReassignment] 

--Before import
DECLARE @MoveFROM DATETIME2,@MoveTo DATETIME2;
SET @MoveFROM = '2023-01-01 00:00:00.000'
SET @MoveTo = '2022-10-01 00:00:00.000'

select '[[Exposures]]',count(*)  FROM [FinancialRisks].[Exposures]	WHERE InforceDate = @MoveFrom
select '[Treaties]',count(*)  FROM [FinancialRisks].[Treaties] WHERE   InforceDate = @MoveFROM
select 'Ironshore_Data',count(*)  FROM FinancialRisks.Ironshore_Data WHERE InforceDate = @MoveFROM
select 'Ironshore_Data_Queue', count(*) FROM FinancialRisks.Ironshore_Data_Queue WHERE InforceDate = @MoveFROM

select * 
--update adn set LastRunTime = '20220701' -- T adata byla po 2023-01-01 00:00:00.000
from [FinancialRisks].[AddNewData] adn

select [FinancialRisks].[fn_GetInforceDate]() InforceDate


--Importing on SIT run on Monday 21.11.2022

 IF ((SELECT count(*)  FROM [FinancialRisks].[MappingsStatus] where[Status] = 'Generating')=0
	and (select count(*)FROM  [FinancialRisks].[MappingsStatus] where [Status]='Complete' ) = 0)
Select 'True' as Updated
ELSE 
Select 'False' Updated



--After Import data - checking a queue

select * from financialrisks.ExposuresQueue

--Update Mapoing status to Update Mappings

select * 
--update ms set [Status]='WAITING'
from FinancialRisks.MappingsStatus ms

--RUN UpdateMappings JOB - Finished

--RUN [FRED_GenerateLossByExposure] JOB


select * from [FinancialRisks].[vw_ExposureOverview] where Inforcedate='20230101'
select * from [FinancialRisks].[Pec_Lines_AKE_Data] where Inforcedate='20230101'


select distinct cobid,  ClassOfBusiness from [FinancialRisks].[vw_ExposureOverview] where Inforcedate = '20230101' order by cobid
select distinct ClassOfBusiness from [FinancialRisks].[Pec_Lines_AKE_Data] where Inforcedate = '20230101' order by ClassOfBusiness 



