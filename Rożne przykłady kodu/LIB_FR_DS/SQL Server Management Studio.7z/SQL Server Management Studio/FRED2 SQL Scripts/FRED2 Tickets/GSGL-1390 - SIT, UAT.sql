USE FRED

--SIT TESTS
exec UserAdmin.dbo.[usp_start_FRED_job] 'FRED_QuarterUpdate'

exec UserAdmin.dbo.[usp_start_FRED_job] 'FRED_QuarterUpdate'

exec UserAdmin.[dbo].[usp_check_ssis_packages_currently_executing]

select * from FinancialRisks.ExposuresQueue


exec UserAdmin.dbo.[usp_start_FRED_job] 'FRED_UpdateMappings'
exec UserAdmin.dbo.[usp_stop_FRED_job] 'FRED_UpdateMappings'

exec UserAdmin.dbo.usp_check_agent_jobs_currently_running
exec useradmin.[dbo].[usp_check_agent_job_history] 'FRED_QuarterUpdate'



select * from FinancialRisks.vw_FXRates where [year] = datepart(year,getdate()) order by rate


--UAT TESTS
exec UserAdmin.dbo.[usp_start_FRED_job] 'FRED_QuarterUpdate'

exec UserAdmin.dbo.[usp_start_FRED_job] 'FRED_QuarterUpdate'

exec UserAdmin.[dbo].[usp_check_ssis_packages_currently_executing]

select * from FinancialRisks.ExposuresQueue


exec UserAdmin.dbo.[usp_start_FRED_job] 'FRED_UpdateMappings'
exec UserAdmin.dbo.[usp_stop_FRED_job] 'FRED_UpdateMappings'

exec UserAdmin.dbo.usp_check_agent_jobs_currently_running
exec useradmin.[dbo].[usp_check_agent_job_history] 'FRED_QuarterUpdate'




SELECT *
  FROM [FinancialRisks].[AddNewData]