select * from FinancialRisks.ExposuresStaging
select * from FinancialRisks.ExposuresQueue

--truncate table FinancialRisks.ExposuresQueue


declare @CobId int
set @CobId = 3

DROP TABLE IF EXISTS #country
DROP TABLE IF EXISTS #Obligors

SELECT CountryID
       ,CountryName
       ,CountryPseudonymId
       ,Region
INTO   #country
FROM   (SELECT CountryId
               ,CountryName
               ,null AS CountryPseudonymId
               ,Region
        FROM   financialrisks.Countries
        UNION
        SELECT cpp.CountryId
               ,cpp.CountryPseudonym AS CountryName
               ,cpp.CountryPseudonymId
               ,ccc.Region 
        FROM   financialrisks.CountryPseudonym AS cpp
        INNER JOIN financialrisks.Countries ccc
        ON cpp.CountryID = ccc.CountryId
        )a

UPDATE [FinancialRisks].[ExposuresQueue]
SET    [CountryName] = countries.CountryID
       ,CountryPseudID = countries.CountryPseudonymId
       ,Region = countries.Region
FROM [FinancialRisks].[ExposuresQueue] AS eq
INNER JOIN #country countries
   ON countries.CountryName = [FinancialRisks].[fn_RemoveBadChar](eq.CountryName)
WHERE [Status] = 'NEW'
  AND [CobId] = @CobId

DECLARE @noCountryid INT

SELECT TOP(1) @noCountryid =  CountryID
FROM   [FinancialRisks].[Countries]
WHERE  CountryName = 'No country name supplied'

IF @CobId <> 6
BEGIN
    UPDATE [FinancialRisks].[ExposuresQueue]
    SET    [CountryName] = @noCountryid
           ,Region = null
    WHERE  [CountryName] IS NULL
        OR [CountryName] = ''
END 

/********************************************************************************************/


-- Get distinct list of all possible obligor names and their ids
SELECT ObligorID
        ,ltrim(rtrim(ObligorName)) AS 'ObligorName'
        ,ObligorPseudonymId
        ,CountryName
        ,ParentCountryName
INTO  #Obligors FROM
(
	SELECT  EntityId as ObligorId
            ,RTRIM(LTRIM(EntityName)) AS ObligorName 
            ,'' AS ObligorPseudonymId
            ,Domicile AS 'CountryName'
            ,ParentDomicile ParentCountryName
	FROM FinancialRisks.Entities
	UNION
	SELECT  ObligorId
            ,rtrim(ltrim(ObligorPseudonym)) as ObligorName
            ,ObligorPseudonymId,''as 'CountryName'
            ,'' ParentCountryName
	FROM FinancialRisks.ObligorPseudonym
)b


--Update Empty Obligors 
update eq set ObligorEntityName = 'No obligor name supplied'
from  [FinancialRisks].[ExposuresQueue] eq where ltrim(rtrim(eq.ObligorEntityName)) is null or ltrim(rtrim(eq.ObligorEntityName))='0'

--Update Empty Obligors 
update eq set ObligorEntityName = '_' + ObligorEntityName + '_'
from  [FinancialRisks].[ExposuresQueue] eq where ISNUMERIC([ObligorEntityName]) = 1


--Map those with valid IDS and with the country
--GSGL-1076 - 
UPDATE [FinancialRisks].[ExposuresQueue]
SET    [ObligorEntityName] = obligors.ObligorID
       ,ObligorPseudID     = obligors.ObligorPseudonymId
--Select *
FROM   [FinancialRisks].[ExposuresQueue] eq
INNER JOIN [FinancialRisks].Countries c
    ON c.countryid = eq.countryName
    AND ISNUMERIC(eq.countryName) = 1
INNER JOIN #obligors obligors
    ON obligors.ObligorName = LTRIM(RTRIM(eq.ObligorEntityName)) + '/' + c.CountryName
WHERE  eq.[Status] = 'NEW'
   --AND eq.[CobId] = @CobId


--select obligors.*,ObligorEntityName, OriginalEntityinFile
UPDATE [FinancialRisks].[ExposuresQueue] 
    SET [ObligorEntityName] = obligors.ObligorID 
    ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
INNER JOIN [FinancialRisks].Countries c ON c.CountryName=obligors.countryName and c.countryid=eq.countryName AND ISNUMERIC(eq.countryName) = 1 
  WHERE [Status] = 'NEW'
  --AND [CobId] = @CobId
  and ISNUMERIC([ObligorEntityName]) = 0 --Not maped earlier



--Map those with valid IDS  and without the country but with ParentCountry
select obligors.*,ObligorEntityName, OriginalEntityinFile,eq.*
--UPDATE [FinancialRisks].[ExposuresQueue]
--    SET [ObligorEntityName] =obligors.ObligorID 
--    ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
  WHERE [Status] = 'NEW'
  --AND [CobId] = @CobId
  and ISNUMERIC([ObligorEntityName]) = 0 --Not maped earlier
  and obligors.CountryName = obligors.ParentCountryName order by eq.ObligorEntityName

  and ObligorEntityName in (

	  select distinct ObligorEntityName
	FROM [FinancialRisks].[ExposuresQueue] eq
	INNER JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
	  WHERE [Status] = 'NEW'
	  --AND [CobId] = @CobId
	  and ISNUMERIC([ObligorEntityName]) = 0 --Not maped earlier
	  and obligors.CountryName = obligors.ParentCountryName


)
order by eq.ObligorEntityName


ExposureQueueId
618
40


--Map those with valid IDS  and without the country
--select obligors.*,ObligorEntityName, OriginalEntityinFile, eq.*
UPDATE [FinancialRisks].[ExposuresQueue]
SET    [ObligorEntityName] = obligors.ObligorID
       ,ObligorPseudID     = obligors.ObligorPseudonymId
FROM   [FinancialRisks].[ExposuresQueue] eq
        JOIN #obligors obligors
               ON obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName)) --replace(LTRIM(RTRIM(isnull(eq.ObligorEntityName,'No obligor name supplied'))),'0','No obligor name supplied')
WHERE  [Status] = 'NEW'
       --AND [CobId] = @CobId
       AND ISNUMERIC(ObligorEntityName) = 0  --Not maped earlier
		


select * from #obligors where Obligorname like '%no obligor%'


select [ObligorEntityName], replace(LTRIM(RTRIM(isnull(eq.ObligorEntityName,'No obligor name supplied'))),'0','No obligor name supplied'), * 
from [FinancialRisks].[ExposuresQueue] eq
where  [ObligorEntityName] is not null


select [ObligorEntityName],* 
from [FinancialRisks].[ExposuresQueue] eq
where ISNUMERIC(ObligorEntityName) = 0  --Not maped earlier




--FROM OLIVIA

USE FRED
 
declare @currentInforceDate datetime, @previousInforceDate datetime
select @currentInforceDate = max(LastRunTime) from FRED.FinancialRisks.AddNewData
set @previousInforceDate = dateadd(month,-3, @currentInforceDate)
select @currentInforceDate currentInforceDate, @previousInforceDate previousInforceDate
 
DROP TABLE IF EXISTS #prev
DROP TABLE IF EXISTS #curr

 --previous data
select
CedantName,
--CountryName,
--EntityName,
--[Original Entity in file],
--Assured,
--TreatyYear,
InforceDate,
sum(LibertyExposure) as LibExposureUSD,
--paper,
--CurrencyName,
ClassOfBusiness
--RiskCode,
--TreatyLimit,
--Excess,
--TreatyReference,
--RiskCode
--TreatyType,
--UploadDate
--into #prev
from FinancialRisks.vw_ExposureOverview 
where ReportingClass in ('FRRI Single Risk', 'FRRI Surety','FRRI Short Term Credit' )
--and InforceDate = (select Distinct LastRunTime from FRED.FinancialRisks.AddNewData)
--and InforceDate = @previousInforceDate
and InforceDate in ('2023-04-01 00:00:00.000','2023-07-01 00:00:00.000')
--and LibertyExposure > 0
--and RiskCode in ('CR','CF','SU','SB','FG','PB','PQ')
and CedantName = 'KILN_LMBL_MICROSOFT'
--and entityname = 'Amazon.com, Inc.'
--and CountryName like '%Russia%'
--and treatyreference = '770128/01/20'
 
group by
InforceDate,
ClassOfBusiness,
CedantName
--TreatyReference




select
CedantName,
--CountryName,
EntityName,
--[Original Entity in file],
--Assured,
--TreatyYear,
InforceDate,
sum(LibertyExposure) as LibExposureUSD,
--paper,
--CurrencyName,
ClassOfBusiness
--RiskCode,
--TreatyLimit,
--Excess,
--TreatyReference,
--RiskCode
--TreatyType,
--UploadDate
into #curr
from FinancialRisks.vw_ExposureOverview 
where ReportingClass in ('FRRI Single Risk', 'FRRI Surety','FRRI Short Term Credit' )
--and InforceDate = (select Distinct LastRunTime from FRED.FinancialRisks.AddNewData)
and InforceDate = @currentInforceDate
--and InforceDate in ('2023-04-01 00:00:00.000','2023-07-01 00:00:00.000')
--and LibertyExposure > 0
--and RiskCode in ('CR','CF','SU','SB','FG','PB','PQ')
--and CedantName = 'KILN_LMBL_MICROSOFT'
--and entityname = 'Amazon.com, Inc.'
--and CountryName like '%Russia%'
--and treatyreference = '770128/01/20'
 
group by
InforceDate,
ClassOfBusiness,
CedantName
--TreatyReference



select * from #prev p
left join #curr c on c.CedantName = p.CedantName and p.ClassOfBusiness = c.ClassOfBusiness
where c.CedantName is null


select * from #curr c
left join #prev p on c.CedantName = p.CedantName and p.ClassOfBusiness = c.ClassOfBusiness
where p.CedantName is null




select top 10 * from FinancialRisks.vw_ExposureOverview 

Original Entity in File
TANYA ENGINEERING, S.A.
Original Entity in File - Actual
TANYA ENGINEERING, S.A.