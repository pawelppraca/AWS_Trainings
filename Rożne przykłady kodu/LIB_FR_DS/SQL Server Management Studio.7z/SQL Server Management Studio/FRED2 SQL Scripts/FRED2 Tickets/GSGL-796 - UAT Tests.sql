-------- GSGL-796 - UAT TESTS  --------------------------

-- Put the files to propoer folders and Run Quarter Update JOB

exec UserAdmin.[dbo].[usp_start_FRED_QuarterUpdate]

exec UserAdmin.[dbo].[usp_check_server_agent_jobs_currently_running]

exec UserAdmin.[dbo].[usp_start_FRED_UpdateMappings] --Uruchomi? we Wtorek 22.11.2022



  select * from [FinancialRisks].[ExposuresQueue] 
  WHERE  ([CountryName] is null or [CountryName] ='')
  and [Status] = 'NEW'
  AND [CobId] = 6
  and ISNUMERIC([ObligorEntityName]) = 1

  select * from [FinancialRisks].[ExposuresQueue] 
  WHERE 
  [Status] = 'NEW'
  AND [CobId] = 6
  and ISNUMERIC([ObligorEntityName]) = 0
  and isnull(CountryName,0) <> 230