
	DECLARE @Quarter INT, @Year INT, @InforceDate DATETIME ,@LastInforceDate DATETIME

	Select @LastInforceDate = (SELECT distinct max([LastRunTime])FROM [FinancialRisks].[AddNewData])

	SET @Quarter = DATEPART(QUARTER, @LastInforceDate)
	SET @Year = DATEPART(YEAR, @LastInforceDate) 

	SELECT @InforceDate =  CASE @Quarter
		   WHEN 1 THEN CAST(CONCAT(@Year,'-4','-01') AS DATETIME)

		   WHEN 2 THEN CAST(CONCAT(@Year,'-7','-01') AS DATETIME)

		   WHEN 3 THEN CAST(CONCAT(@Year,'-10','-01') AS DATETIME)

		   WHEN 4 THEN CAST(CONCAT(@Year +1,'-1','-01') AS DATETIME)
		   END

select @InforceDate



Select InforceDate, CobId, count(*)  
FROM [FinancialRisks].[Exposures]
WHERE CobId in ( 1,2 ) and [InforceDate] = '2022-07-01T00:00:00.000'
group by  InforceDate, CobId

select InforceDate, CobId, count(*) 
FROM [FinancialRisks].[ExposuresQueue]
WHERE CobId in ( 1,2 ) and [InforceDate] = '2022-07-01T00:00:00.000'
group by  InforceDate, CobId



-- Sztuczne dodanie rekord�w w celu sprawdzenia usuniecia.
-- Intensional adding records

-- Table Exposures
--Records with COBid = 2
insert into [FinancialRisks].[Exposures] (CedantId,CobId,RiskReference,CurrencyId,Year,DataQuarter,AssuredEntityId,RiskCode,LeadSyndicate,CountryId,InceptionDate,ExpiryDate,Limit,UsdLimit,GrossPremium,GrossExposure,ObligorEntityId,InforceDate,Source,ObligorPseudID,CountryPseudID,SBU,Office,AssumedLive,ProductLine,NoBillingOffsetTotalSuretyExposureNetPGE,NetSuretyExposure,Region,Assured,LGDSD_Surety,Max_Cap,Collateral,UploadDate)
Select top 3 CedantId,2,RiskReference,CurrencyId,Year,DataQuarter,AssuredEntityId,RiskCode,LeadSyndicate,CountryId,InceptionDate,ExpiryDate,Limit,UsdLimit,GrossPremium,GrossExposure,ObligorEntityId,'2022-07-01T00:00:00.000',Source,ObligorPseudID,CountryPseudID,SBU,'Pawel_P',AssumedLive,ProductLine,NoBillingOffsetTotalSuretyExposureNetPGE,NetSuretyExposure,Region,Assured,LGDSD_Surety,Max_Cap,Collateral,UploadDate
FROM [FinancialRisks].[Exposures] order by exposureid desc

--Records with COBid = 1
insert into [FinancialRisks].[Exposures] (CedantId,CobId,RiskReference,CurrencyId,Year,DataQuarter,AssuredEntityId,RiskCode,LeadSyndicate,CountryId,InceptionDate,ExpiryDate,Limit,UsdLimit,GrossPremium,GrossExposure,ObligorEntityId,InforceDate,Source,ObligorPseudID,CountryPseudID,SBU,Office,AssumedLive,ProductLine,NoBillingOffsetTotalSuretyExposureNetPGE,NetSuretyExposure,Region,Assured,LGDSD_Surety,Max_Cap,Collateral,UploadDate)
Select top 6 CedantId,1,RiskReference,CurrencyId,Year,DataQuarter,AssuredEntityId,RiskCode,LeadSyndicate,CountryId,InceptionDate,ExpiryDate,Limit,UsdLimit,GrossPremium,GrossExposure,ObligorEntityId,'2022-07-01T00:00:00.000',Source,ObligorPseudID,CountryPseudID,SBU,'Pawel_P',AssumedLive,ProductLine,NoBillingOffsetTotalSuretyExposureNetPGE,NetSuretyExposure,Region,Assured,LGDSD_Surety,Max_Cap,Collateral,UploadDate
FROM [FinancialRisks].[Exposures] order by exposureid desc

--ExposuresQueue
--Records with COBid = 1
insert into  [FinancialRisks].[ExposuresQueue] (CedantName,CobId,RiskReference,CurrencyId,Year,DataQuarter,AssuredEntityId,RiskCode,LeadSyndicate,CountryName,InceptionDate,ExpiryDate,Limit,UsdLimit,GrossPremium,GrossExposure,ObligorEntityName,InforceDate,Status,Source,UserNotified,ObligorPseudID,CountryPseudID,SBU,Office,AssumedLive,ProductLine,NoBillingOffsetTotalSuretyExposureNetPGE,NetSuretyExposure,Region,Assured,LGDSD_Surety,Max_Cap,Collateral,LocalId)
select top 3 
	CedantName,1,RiskReference,CurrencyId,Year,DataQuarter,AssuredEntityId,RiskCode,LeadSyndicate,CountryName,InceptionDate,ExpiryDate,Limit,UsdLimit,GrossPremium,GrossExposure,ObligorEntityName,'2022-01-07T00:00:00.000',Status,Source,UserNotified,ObligorPseudID,CountryPseudID,SBU,'Pawel_P',AssumedLive,ProductLine,NoBillingOffsetTotalSuretyExposureNetPGE,NetSuretyExposure,Region,Assured,LGDSD_Surety,Max_Cap,Collateral,LocalId
from [FinancialRisks].[ExposuresQueue]

--Records with COBid = 2
insert into  [FinancialRisks].[ExposuresQueue] (CedantName,CobId,RiskReference,CurrencyId,Year,DataQuarter,AssuredEntityId,RiskCode,LeadSyndicate,CountryName,InceptionDate,ExpiryDate,Limit,UsdLimit,GrossPremium,GrossExposure,ObligorEntityName,InforceDate,Status,Source,UserNotified,ObligorPseudID,CountryPseudID,SBU,Office,AssumedLive,ProductLine,NoBillingOffsetTotalSuretyExposureNetPGE,NetSuretyExposure,Region,Assured,LGDSD_Surety,Max_Cap,Collateral,LocalId)
select top 3 
	CedantName,2 CobId,RiskReference,CurrencyId,Year,DataQuarter,AssuredEntityId,RiskCode,LeadSyndicate,CountryName,InceptionDate,ExpiryDate,Limit,UsdLimit,GrossPremium,GrossExposure,ObligorEntityName,'2022-07-01T00:00:00.000' InforceDate,Status,Source,UserNotified,ObligorPseudID,CountryPseudID,SBU,'Pawel_P' Office,AssumedLive,ProductLine,NoBillingOffsetTotalSuretyExposureNetPGE,NetSuretyExposure,Region,Assured,LGDSD_Surety,Max_Cap,Collateral,LocalId
from [FinancialRisks].[ExposuresQueue]



exec useradmin.[dbo].[usp_start_FRED_QuarterUpdate]

exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

exec useradmin.[dbo].[usp_check_job_history] 'FRED_QuarterUpdate'



Select InforceDate, CobId, count(*)  
FROM [FinancialRisks].[Exposures]
WHERE CobId in ( 1,2 ) and [InforceDate] = '2022-07-01T00:00:00.000'
group by  InforceDate, CobId

select InforceDate, CobId, count(*) 
FROM [FinancialRisks].[ExposuresQueue]
WHERE CobId in ( 1,2 ) and [InforceDate] = '2022-07-01T00:00:00.000'
group by  InforceDate, CobId
