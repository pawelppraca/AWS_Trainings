

--BULK LOAD
use FRED


--Befor Start JOB
select 'vw_dwhr_Currencies' table_name, count(*) from [sources].[vw_dwhr_Currencies] (nolock)
select 'vw_dwhr_ExchangeRates' table_name, count(*) from [sources].[vw_dwhr_ExchangeRates] (nolock)
select '[vw_dwhr_ISOCurrencies]' table_name, count(*) from [sources].[vw_dwhr_ISOCurrencies] (nolock)


exec useradmin.dbo.usp_Start_FRED_job 'FRED_Currencies_Xrate_2'
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]
exec useradmin.[dbo].[usp_check_job_history] 'FRED_Currencies_Xrate_2'

--After Start JOB
select 'vw_dwhr_Currencies' table_name, count(*) from [sources].[vw_dwhr_Currencies] (nolock)
select 'vw_dwhr_ExchangeRates' table_name, count(*) from [sources].[vw_dwhr_ExchangeRates] (nolock)
select '[vw_dwhr_ISOCurrencies]' table_name, count(*) from [sources].[vw_dwhr_ISOCurrencies] (nolock)








--Wykonac por�wnanie  CTX z starych tabel i z nowych
--CTX znajdzie w GENLBE


SELECT    									
	DISTINCT    									
	ccyFrom.CurrencyCode  AS 'Name'	,								
	roe.ExchangeRate   AS 'rate',
	YEAR(roe.ExchangeRateDateKey) AS 'year'
into #CurrencyFXRates
FROM    									
	[sources].[vw_dwhr_Currencies] ccyFrom   									
	INNER JOIN sources.vw_dwhr_ISOCurrencies ccyFromISO ON ccyFrom.ISOCurrencyKey = ccyFromISO.ISOCurrencyKey   									
	INNER JOIN sources.vw_dwhr_ExchangeRates roe ON ccyFromISO.ISOCurrencyKey = roe.ISOCurrencyFromKey   									
	INNER JOIN sources.vw_dwhr_ISOCurrencies ccyToISO ON roe.ISOCurrencyToKey = ccyToISO.ISOCurrencyKey   									
WHERE    									
	ccyToISO.ISOCurrencyCode = N'USD'   									
	AND roe.ExchangeRateTypeCode = N'[GAAP Plan]' 			



--Old
;WITH dwhr_Currencies_old AS (
SELECT
   [rid]
    , [CurrencyKey]
    ,[CurrencyCode]
    ,[CurrencyName] 
    ,[ISOCurrencyKey]
    ,[_DateCreated] 
    ,[_EventExecutionKey] 
    ,[_LastAction] 
    ,[_MergeKey] 
    ,[_SourceSystemCode] 
    ,[LoadID] 
FROM  [sources].[dwhr_Currencies]
), 

dwhr_ISOCurrencies_old AS
(
SELECT
   rid
   ,ISOCurrencyKey
   ,ISOCurrencyCode
   ,ISOCurrencyName
   ,SettlementCurrencyFlag
   ,_DateCreated
   , _EventExecutionKey
   ,_LastAction
   ,_MergeKey
   ,_SourceSystemCode
   ,LoadID
FROM   sources.dwhr_ISOCurrencies
),
dwhr_ExchangeRates_old AS
(
SELECT
    rid
   ,ExchangeRateKey
   ,ISOCurrencyFromKey
   ,ISOCurrencyToKey
   ,ExchangeRateDateKey
   ,ExchangeRateTypeCode
   ,ExchangeRateTypeName
   ,ExchangeRate
   ,_DateCreated
   ,_EventExecutionKey
   ,_LastAction
   ,_MergeKey
   ,_SourceSystemCode
   , LoadID
   FROM 
[sources].[dwhr_ExchangeRates]
)


				
	SELECT    									
				DISTINCT    									
				ccyFrom.CurrencyCode  AS 'Name'	,								
				roe.ExchangeRate   AS 'rate',
				YEAR(roe.ExchangeRateDateKey) AS 'year'
	into #CurrencyFXRates_old
	FROM    									
				dwhr_Currencies_old ccyFrom   									
				INNER JOIN dwhr_ISOCurrencies_old ccyFromISO ON ccyFrom.ISOCurrencyKey = ccyFromISO.ISOCurrencyKey   									
				INNER JOIN dwhr_ExchangeRates_old roe ON ccyFromISO.ISOCurrencyKey = roe.ISOCurrencyFromKey   									
				INNER JOIN dwhr_ISOCurrencies_old ccyToISO ON roe.ISOCurrencyToKey = ccyToISO.ISOCurrencyKey   									
	WHERE    									
				ccyToISO.ISOCurrencyCode = N'USD'   									
				AND roe.ExchangeRateTypeCode = N'[GAAP Plan]' 			


select * from #CurrencyFXRates fx
join #CurrencyFXRates_old fxo on fxo.Name=fx.Name and fxo.year=fx.year
where fx.rate <> fxo.rate
