use fred

select max(uploaddate) from FinancialRisks.vw_ExposureOverview
select max(exposureid) from FinancialRisks.vw_ExposureOverview

select top 10 * from FinancialRisks.vw_ExposureOverview



--NEW PROD Referenc_ID for Environment is 1 (at 7.09.2023 )
  SELECT
    ER.reference_id AS ReferenceId
,   E.name AS EnvironmentName
,   F.name AS FolderName
,   P.name AS ProjectName
FROM
    SSISDB.catalog.environments AS E
    INNER JOIN
        SSISDB.catalog.folders AS F
        ON F.folder_id = E.folder_id
    INNER JOIN 
        SSISDB.catalog.projects AS P
        ON P.folder_id = F.folder_id
    INNER JOIN
        SSISDB.catalog.environment_references AS ER
        ON ER.project_id = P.project_id
ORDER BY 
    ER.reference_id;



--Compare Data on PROD

select count(*) from FinancialRisks.vw_ExposureOverview where InforceDate = '2023-01-01 00:00:00'

-- TEST on PROD - Reupload
FRED_Currencies_Xrate		--	OK
FRED_QuarterUpdate			--	OK
FRED_IdentifyMappings		--	OK
FRED_UpdateMappings			--  OK
FRED_GenerateLossByExposure	--	
FRED_CSMUpload				--	OK (Rea) 
FRED_GFRSource				--	OK

exec useradmin.dbo.usp_Stop_FRED_job 'FRED_Currencies_Xrate' -- Done
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]
exec useradmin.[dbo].[usp_check_job_history] 'FRED_Currencies_Xrate'




exec useradmin.dbo.usp_Start_FRED_job 'FRED_QuarterUpdate', 'PTC'

exec useradmin.[dbo].[usp_check_job_history] 'FRED_QuarterUpdate'
exec useradmin.[dbo].[usp_check_job_steps]  'FRED_QuarterUpdate'
exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]

  select  * from FinancialRisks.ExposuresQueue (nolock)
  select  * from [FinancialRisks].[Ironshore_Data_Queue]

  --Mappings

  select * from FinancialRisks.Countries where CountryName like '%Colombia%'  
  select * from FinancialRisks.CountryPseudonym where CountryPseudonym like '%Columbia%'


exec useradmin.dbo.usp_Start_FRED_job 'FRED_UpdateMappings'
exec useradmin.[dbo].[usp_check_job_history] 'FRED_UpdateMappings'

--Treaty Reassigment
exec useradmin.dbo.usp_Start_FRED_job 'FRED_CSMUpload'
exec useradmin.[dbo].[usp_check_job_history] 'FRED_CSMUpload'

--generateLossByExposure
exec useradmin.dbo.usp_Start_FRED_job 'FRED_GenerateLossByExposure'
exec useradmin.[dbo].[usp_check_job_history] 'FRED_GenerateLossByExposure'

--CSM Upload
exec useradmin.dbo.usp_Start_FRED_job 'FRED_CSMUpload'
exec useradmin.[dbo].[usp_check_job_history] 'FRED_CSMUpload'
