--Rozpoznanie

--Tabele
[FinancialRisks].[CSMOutput] - column ClassOfBusiness


select distinct ClassOfBusiness from [FinancialRisks].[CSMOutput] 





select * from FinancialRisks.COB

select top 10 * from [FinancialRisks].[vw_ExposureOverview]

select top 10 * from [FinancialRisks].[Pec_Lines_AKE_Data]



select * from FinancialRisks.[CSM_Model_Output]


select top 100 * from [FinancialRisks].LossByExposure



--Zmiany

-- Aktualizacja danych w tabeli COB

/*

GFR -> FRS
Pecuniary Lines � FRRI Single Risk
Paris Trade Credit � FRRI Short Term Credit
Pecuniary Lines Surety � FRRI Surety
LMIE Surety -> GRS Surety or Direct Surety
*/


update cob set Name='FRS Lloyds', 	ReportingClass='FRS' from FinancialRisks.COB cob where CobID=1
update cob set Name='FRS Company', 	ReportingClass='FRS' from FinancialRisks.COB cob where CobID=2
update cob set Name='FRRI Single Risk', 	ReportingClass='FRRI Single Risk' from FinancialRisks.COB cob where CobID=3
update cob set Name='FRRI Surety', 	ReportingClass='FRRI Surety' from FinancialRisks.COB cob where CobID=4
update cob set Name='FRRI Short Term Credit', 	ReportingClass='FRRI Short Term Credit' from FinancialRisks.COB cob where CobID=5
update cob set Name='GRS Surety', 	ReportingClass='GRS Surety' from FinancialRisks.COB cob where CobID=6



--Update old data in [FinancialRisks].[TreatyReassignment]

update tr set ActualReportingClass='FRRI Surety' from [FinancialRisks].[TreatyReassignment] tr where ActualReportingClass ='Pecuniary Lines Surety'
update tr set ActualReportingClass='FRRI Short Term Credit' from [FinancialRisks].[TreatyReassignment] tr where ActualReportingClass ='Paris Trade Credit'
update tr set ActualReportingClass='FRRI Single Risk' from [FinancialRisks].[TreatyReassignment] tr where ActualReportingClass ='Pecuniary Lines'

--Return old Names
--revoke update of [FinancialRisks].COB
update cob set Name='Global Financial Risks Lloyds', 	ReportingClass='Global Financial Risks' from FinancialRisks.COB cob where CobID=1
update cob set Name='Global Financial Risks Company', 	ReportingClass='Global Financial Risks' from FinancialRisks.COB cob where CobID=2
update cob set Name='Pecuniary Lines', 	ReportingClass='Pecuniary Lines' from FinancialRisks.COB cob where CobID=3
update cob set Name='Pecuniary Lines Surety', 	ReportingClass='Pecuniary Lines' from FinancialRisks.COB cob where CobID=4
update cob set Name='Paris Trade Credit', 	ReportingClass='Paris Trade Credit' from FinancialRisks.COB cob where CobID=5
update cob set Name='LMIE Direct Surety', 	ReportingClass='LMIE Direct Surety' from FinancialRisks.COB cob where CobID=6

--revoke update of [FinancialRisks].[TreatyReassignment]
update tr set ActualReportingClass=' Pecuniary Lines Surety' from [FinancialRisks].[TreatyReassignment] tr where ActualReportingClass ='FRRI Surety'
update tr set ActualReportingClass='Paris Trade Credit' from [FinancialRisks].[TreatyReassignment] tr where ActualReportingClass ='FRRI Short Term Credit'
update tr set ActualReportingClass=' Pecuniary Lines' from [FinancialRisks].[TreatyReassignment] tr where ActualReportingClass ='FRRI Single Risk'



--Sprawdzenie widoku  - czy zmienily sie dane po update w COB
select * from [FinancialRisks].[AKE_Data]
select * from [FinancialRisks].[Pec_Lines_AKE_Data]
select * from [FinancialRisks].[Pec_Lines_AKE_Data_Archive]

--Testowanie nowej wersji Widoku
select distinct inforcedate from [FinancialRisks].[Pec_Lines_AKE_Data_v2]


[FinancialRisks].[Pec_Lines_AKE_Data]
[FinancialRisks].[Pec_Lines_AKE_Data_Archive]




--Testing on DEV
--------------------------
--Import danych
--Update Mappings
--GenLosExposure

--------------------------------------
--Testy zapyta?
----------------------------------------
select distinct InforceDate, count(*) fROM [FinancialRisks].[Exposures]
			group by  InforceDate


select * from  [FinancialRisks].[Exposures] where INforcedate='2022-07-01 00:00:00.000'


select top 10 * from [FinancialRisks].[vw_ExposureOverview] where INforcedate='2022-07-01 00:00:00.000'



select distinct inforcedate from [FinancialRisks].[Exposures] order by inforcedate



SELECT distinct max([LastRunTime])FROM [FinancialRisks].[AddNewData]
SELECT * FROM [FinancialRisks].[AddNewData]

select [FinancialRisks].[fn_GetInforceDate]()


		select 'Exposures', inforcedate, count(*) FROM [FinancialRisks].[Exposures] group by inforcedate	order by inforcedate desc
		select '[Treaties]', inforcedate, count(*) FROM [FinancialRisks].[Treaties] group by inforcedate	order by inforcedate desc
		select 'Ironshore_Data', inforcedate, count(*) FROM [FinancialRisks].Ironshore_Data group by inforcedate	order by inforcedate desc
		select 'Ironshore_Data_Queue', inforcedate, count(*) FROM [FinancialRisks].Ironshore_Data_Queue group by inforcedate	order by inforcedate desc




DECLARE @MoveFROM DATETIME2,@MoveTo DATETIME2;
SET @MoveFROM = '2023-01-01 00:00:00.000'
SET @MoveTo = '2022-10-01 00:00:00.000'

select '[[Exposures]]',count(*)  FROM [FinancialRisks].[Exposures]	WHERE InforceDate = @MoveFrom
select '[Treaties]',count(*)  FROM [FinancialRisks].[Treaties] WHERE   InforceDate = @MoveFROM
select 'Ironshore_Data',count(*)  FROM FinancialRisks.Ironshore_Data WHERE InforceDate = @MoveFROM
select 'Ironshore_Data_Queue', count(*) FROM FinancialRisks.Ironshore_Data_Queue WHERE InforceDate = @MoveFROM

select * from [FinancialRisks].[AddNewData]



select * from FinancialRisks.COB



			select top 10 * from [FinancialRisks].[Pec_Lines_AKE_Data]


			select * from [FinancialRisks].[vw_ExposureOverview] where Inforcedate = '20230101'
			select * from [FinancialRisks].[Pec_Lines_AKE_Data] where Inforcedate = '20230101'

select distinct cobid,  ClassOfBusiness from [FinancialRisks].[vw_ExposureOverview] where Inforcedate = '20230101' order by cobid
select distinct ClassOfBusiness from [FinancialRisks].[Pec_Lines_AKE_Data] where Inforcedate = '20230101' order by ClassOfBusiness


select distinct  inforcedate
--delete
from financialrisks.ExposuresQueue where inforcedate='2022-10-01T00:00:00.000'

select distinct UnmappedCedantName from [FinancialRisks].[UnmappedCedants]

select distinct UnmappedCountryName from  [FinancialRisks].[UnmappedCountries]

select distinct unmappedobligorname from [FinancialRisks].[UnmappedObligors]


select * from [FinancialRisks].[TreatyReassignment] where TreatyReference='710177/01/21'

select  * from  [FinancialRisks].vw_ExposureOverview where TreatyReference='710177/01/21'

Entities	Complete
Countries	Complete
Cedants	WAITING

select * 
--update mp set [Status]='Updated'
from [FinancialRisks].[MappingsStatus] mp

 IF ((SELECT count(*)  FROM [FinancialRisks].[MappingsStatus] where[Status] = 'Generating')=0
	and (select count(*)FROM  [FinancialRisks].[MappingsStatus] where [Status]='Complete' ) = 0)
Select 'True' as Updated
ELSE 
Select 'False' Updated



select * from [FinancialRisks].Mapping_Errors order by ErrorDateTime desc


select distinct Inforcedate from [FinancialRisks].[vw_ExposureOverview] order by Inforcedate desc

select distinct cobid,  ClassOfBusiness from [FinancialRisks].[vw_ExposureOverview] where Inforcedate = '20230101' order by cobid

select distinct cobid,  ClassOfBusiness from [FinancialRisks].[vw_ExposureOverview] where Inforcedate = '20211001' order by cobid


select distinct  eov.cobid,eov.ReportingClass,ClassOfBusiness,ClassLGD, tr.ReportingClass, tr.Class, tr.ActualReportingClass
from  [FinancialRisks].vw_ExposureOverview eov
left join [FinancialRisks].[TreatyReassignment] tr on tr.TreatyReference = eov.TreatyReference
AND eov.CedantName = tr.CedantName --AND eov.InforceDate = tr.InforceDate 
and tr.Changing = 'YES'
where  eov.InforceDate='20230101' order by CobId







select * from FinancialRisks.COB

select eov.TreatyReference, * from  [FinancialRisks].vw_ExposureOverview eov
left join [FinancialRisks].[TreatyReassignment] tr on tr.TreatyReference = eov.TreatyReference

where  eov.InforceDate='20230101'

select * from [FinancialRisks].[TreatyReassignment] where TreatyReference='770214/02/21'

select TreatyReference, * from  [FinancialRisks].vw_ExposureOverview where TreatyReference='770214/02/21' and InforceDate='20230101'

select * from [FinancialRisks].Exposures where InforceDate='20230101'


select ActualReportingClass, count(*) from [FinancialRisks].[TreatyReassignment] group by ActualReportingClass