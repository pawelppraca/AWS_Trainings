--Update Index on Entities

USE [FRED]
GO

/****** Object:  Index [EntityName_Unique]    Script Date: 7/5/2023 2:40:19 PM ******/
ALTER TABLE [FinancialRisks].[Entities] DROP CONSTRAINT [EntityName_Unique]
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [EntityName_Unique]    Script Date: 7/5/2023 2:40:20 PM ******/
ALTER TABLE [FinancialRisks].[Entities] ADD  CONSTRAINT [EntityName_Cou_Unique] UNIQUE NONCLUSTERED 
(
	[EntityName], [Domicile] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO








DROP TABLE IF EXISTS #Obligors

SELECT ObligorID
        ,ltrim(rtrim(ObligorName)) AS 'ObligorName'
        ,ObligorPseudonymId
        ,CountryName
        ,ParentCountryName
INTO  #Obligors FROM
(
	SELECT  EntityId as ObligorId
            ,RTRIM(LTRIM(EntityName)) AS ObligorName 
            ,'' AS ObligorPseudonymId
            ,Domicile AS 'CountryName'
            ,ParentDomicile ParentCountryName
	FROM FinancialRisks.Entities
	UNION
	SELECT  ObligorId
            ,rtrim(ltrim(ObligorPseudonym)) as ObligorName
            ,ObligorPseudonymId,''as 'CountryName'
            ,'' ParentCountryName
	FROM FinancialRisks.ObligorPseudonym
)b


select * from #Obligors o
join FinancialRisks.Entities en on en.entityid=o.obligorid
where o.ObligorName like 'VINCI S%'  order by ObligorName

select * from FinancialRisks.Entities where EntityName like 'VINCI S%' 



select * 
--update ms set status='Complete'
FROM [FinancialRisks].[MappingsStatus] ms


  exec useradmin.dbo.usp_Start_FRED_job 'FRED_UpdateMappings' 


 IF ((SELECT count(*)  FROM [FinancialRisks].[MappingsStatus] where[Status] = 'Generating')=0
	and (select count(*)FROM  [FinancialRisks].[MappingsStatus] where [Status]='Complete' ) = 0)
Select 'True' as Updated
ELSE 
Select 'False' Updated






select * from FinancialRisks.Countries where CountryName like 'czech%'


select Domicile,* from FinancialRisks.Entities where EntityName like 'VINCI S%' or EntityName like 'VINCI G%' order by entityid desc
select * from FinancialRisks.ObligorPseudonym where ObligorPseudonym like 'VINCI/%' order by ObligorPseudonymID desc

--delete from FinancialRisks.Entities where id in (3179568,3179569,3179570,3179571,3179572,3179588)
--update FinancialRisks.Entities set EntityName='VINCI SA' where entityid=3179589


--Dodanie nowych Obligor�w
--insert into FinancialRisks.Entities (EntityName, ParentEntityName, CapitalIqId, ParentCapitalIqId, SPRating, GCHPRating, LibertyRating, TradeSectorId, ParentSPRating, ParentGCHPRating, ParentLibertyRating, Domicile, ParentDomicile, DefaultTradeSectorId, DefaultDomicile, DefaultRating)
select 'VINCI SA', ParentEntityName, CapitalIqId+'_1', ParentCapitalIqId+'_1', SPRating, GCHPRating, LibertyRating, TradeSectorId, ParentSPRating, ParentGCHPRating, ParentLibertyRating, 'Spain', ParentDomicile, DefaultTradeSectorId, 'Spain', DefaultRating
from FinancialRisks.Entities where entityid=8694


--insert into FinancialRisks.Entities (EntityName, ParentEntityName, CapitalIqId, ParentCapitalIqId, SPRating, GCHPRating, LibertyRating, TradeSectorId, ParentSPRating, ParentGCHPRating, ParentLibertyRating, Domicile, ParentDomicile, DefaultTradeSectorId, DefaultDomicile, DefaultRating)
select 'VINCI GmbH', ParentEntityName, CapitalIqId+'_2', ParentCapitalIqId+'_2', SPRating, GCHPRating, LibertyRating, TradeSectorId, ParentSPRating, ParentGCHPRating, ParentLibertyRating, 'Germany', ParentDomicile, DefaultTradeSectorId, 'Germany', DefaultRating
from FinancialRisks.Entities where entityid=8694


--insert into FinancialRisks.Entities (EntityName, ParentEntityName, CapitalIqId, ParentCapitalIqId, SPRating, GCHPRating, LibertyRating, TradeSectorId, ParentSPRating, ParentGCHPRating, ParentLibertyRating, Domicile, ParentDomicile, DefaultTradeSectorId, DefaultDomicile, DefaultRating)
select 'VINCI SA', ParentEntityName, CapitalIqId+'_3', ParentCapitalIqId+'_3', SPRating, GCHPRating, LibertyRating, TradeSectorId, ParentSPRating, ParentGCHPRating, ParentLibertyRating, 'Czech Republic', ParentDomicile, DefaultTradeSectorId, 'Spain', DefaultRating
from FinancialRisks.Entities where entityid=8694

--insert into FinancialRisks.Entities (EntityName, ParentEntityName, CapitalIqId, ParentCapitalIqId, SPRating, GCHPRating, LibertyRating, TradeSectorId, ParentSPRating, ParentGCHPRating, ParentLibertyRating, Domicile, ParentDomicile, DefaultTradeSectorId, DefaultDomicile, DefaultRating)
select 'VINCI SA', ParentEntityName, CapitalIqId+'_4', ParentCapitalIqId+'_4', SPRating, GCHPRating, LibertyRating, TradeSectorId, ParentSPRating, ParentGCHPRating, ParentLibertyRating, 'Poland', ParentDomicile, DefaultTradeSectorId, 'Spain', DefaultRating
from FinancialRisks.Entities where entityid=8694


--Dodanie Pseudonym�w
insert into FinancialRisks.ObligorPseudonym (ObligorID,ObligorPseudonym)
values (3179590, 'Vinci/Germany'),(3179590, 'Vinci/Austria'), (3179589, 'Vinci/Spain'),  (8694, 'Vinci/France')

insert into FinancialRisks.ObligorPseudonym (ObligorID,ObligorPseudonym)
values (3179591, 'Vinci/Poland'),(3179592, 'Vinci/Czech Republic'), (3179591, 'Vinci Group/Poland')


insert into FinancialRisks.ObligorPseudonym (ObligorID,ObligorPseudonym)
values (3179589, 'Vinci SA/Spain')

insert into FinancialRisks.ObligorPseudonym (ObligorID,ObligorPseudonym)
values  (3179591, 'Grupa Vinci/Poland')



--IMport BDX file

SELECT *
--update [FinancialRisks].[AddNewData] set AddNewData = 'True'


SELECT *  FROM [FinancialRisks].[AddNewData]

SELECT *  FROM [FinancialRisks].ExposuresStaging

SELECT *  FROM [FinancialRisks].ExposuresQueue




/********************************************************************************************/
-- Get distinct list of all possible country names and their ids
SELECT CountryID, CountryName,CountryPseudonymId into #country from
(
	SELECT CountryId, CountryName,''as CountryPseudonymId
	FROM FinancialRisks.Countries
	UNION
	SELECT CountryId, CountryPseudonym AS CountryName,CountryPseudonymId
	FROM FinancialRisks.CountryPseudonym
)a

UPDATE [FinancialRisks].[ExposuresQueue]
set [CountryName] =countries.CountryID
,CountryPseudID=countries.CountryPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #country countries on countries.CountryName = [FinancialRisks].[fn_RemoveBadChar](eq.CountryName)
  WHERE [Status] = 'NEW'
  --AND [CobId] = @CobId

Declare @countryid int 
SET @countryid = (Select CountryID from  [FinancialRisks].[Countries]
where CountryName = 'No country name supplied')




UPDATE [FinancialRisks].[ExposuresQueue]
   SET [CountryName] = @countryid
  where
  [CountryName] is null  or [CountryName] =''

/********************************************************************************************/


SELECT *  FROM [FinancialRisks].ExposuresStaging

SELECT *  FROM [FinancialRisks].ExposuresQueue




DROP TABLE IF EXISTS #Obligors


-- Get distinct list of all possible obligor names and their ids
select ObligorID, ltrim(rtrim(ObligorName)) as 'ObligorName',ObligorPseudonymId,CountryName, ParentCountryName 
into  #Obligors from
(
	SELECT EntityId as ObligorId, rtrim(ltrim(EntityName)) as ObligorName ,'' as ObligorPseudonymId,Domicile as 'CountryName', ParentDomicile ParentCountryName
	FROM FinancialRisks.Entities
	UNION
	SELECT ObligorId, rtrim(ltrim(ObligorPseudonym)) as ObligorName,ObligorPseudonymId,''as 'CountryName', '' ParentCountryName
	FROM FinancialRisks.ObligorPseudonym
)b


select * from #Obligors where ObligorName like 'VINCI%' and ObligorPseudonymId=0 order by ObligorId

select * from FinancialRisks.Entities where EntityName like 'VINCI SA%' order by EntityId


SELECT ObligorEntityName , c.countryname, eq.GrossExposure,*  
FROM [FinancialRisks].ExposuresQueue eq
INNER JOIN [FinancialRisks].Countries c ON c.countryid=eq.countryName AND ISNUMERIC(eq.countryName) = 1
order by ExposureQueueId

--Map those with valid IDS and with the country
--GSGL-1076 - 
--UPDATE [FinancialRisks].[ExposuresQueue] SET [ObligorEntityName] = obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId


select obligors.ObligorID ,obligors.ObligorPseudonymId, obligors.*, eq.GrossExposure
,*
--UPDATE [FinancialRisks].[ExposuresQueue] SET industry='1'
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN [FinancialRisks].Countries c ON c.countryid=eq.countryName AND ISNUMERIC(eq.countryName) = 1
INNER JOIN #Obligors obligors ON obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName)) + '/' + c.CountryName 
WHERE [Status] = 'NEW'
order by ExposureQueueId
--AND [CobId] = @CobId

select obligors.ObligorID ,obligors.ObligorPseudonymId, obligors.*, eq.GrossExposure
,*
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
INNER JOIN [FinancialRisks].Countries c ON c.CountryName=obligors.countryName and c.countryid=eq.countryName AND ISNUMERIC(eq.countryName) = 1
WHERE [Status] = 'NEW'
--  AND [CobId] = @CobId
 -- and ISNUMERIC([ObligorEntityName]) = 0 --Not maped earlier
 and Industry is null
order by ExposureQueueId



--Map those with valid IDS  and without the country
--UPDATE [FinancialRisks].[ExposuresQueue] SET [ObligorEntityName] =obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
select obligors.ObligorID ,obligors.ObligorPseudonymId, obligors.*, eq.GrossExposure
,*
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
  WHERE [Status] = 'NEW'
--  AND [CobId] = @CobId
 -- and ISNUMERIC([ObligorEntityName]) = 0 --Not maped earlier
 and Industry is null 
 and obligors.CountryName = obligors.ParentCountryName
order by ExposureQueueId




select c.Countryname, ex.ObligorEntityID, en.entityname, uploaddate,source, GrossExposure, ex.*
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'VINCI%'
and ex.uploaddate='2023-07-05T00:00:00.000'
order by Entityname



select Domicile, ParentDomicile, * from FinancialRisks.Entities where EntityName like 'VINCI S%' or EntityName like 'VINCI G%' order by EntityId

select * from FinancialRisks.ObligorPseudonym where ObligorPseudonym like 'VINCI/%' or ObligorPseudonym like 'VINCI S%'



--TESTING AMAZON

use fred

select * from FinancialRisks.ExposuresQueue


exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate] 

exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]
exec useradmin.[dbo].[usp_check_job_history] 'FRED_QuarterUpdate' 



--Sprawdzenie warunk�w do wykonania Update Mappings
 SELECT * FROM [FinancialRisks].[MappingsStatus]

 IF ((SELECT count(*)  FROM [FinancialRisks].[MappingsStatus] where[Status] = 'Generating')=0
	and (select count(*)FROM  [FinancialRisks].[MappingsStatus] where [Status]='Complete' ) = 0)
Select 'True' as Updated
ELSE 
Select 'False' Updated

 SELECT * 
 --update ms set Status='Waiting'
 FROM [FinancialRisks].[MappingsStatus] ms



 
DROP TABLE IF EXISTS #Obligors

SELECT ObligorID, ltrim(rtrim(ObligorName)) AS 'ObligorName', ObligorPseudonymId, CountryName, ParentCountryName
INTO  #Obligors FROM
(
	SELECT EntityId as ObligorId, RTRIM(LTRIM(EntityName)) AS ObligorName ,'' AS ObligorPseudonymId,Domicile AS 'CountryName', ParentDomicile ParentCountryName
	FROM FinancialRisks.Entities
	UNION
	SELECT ObligorId, rtrim(ltrim(ObligorPseudonym)) as ObligorName,ObligorPseudonymId,''as 'CountryName', '' ParentCountryName
	FROM FinancialRisks.ObligorPseudonym
)b


select * from #Obligors where ObligorName like 'Amazon %' and CountryName in ('Brasil', 'United Kingdom','Germany','Unite States','Italy','Luxembourg')

select Domicile,* from FinancialRisks.Entities (nolock) 
where entityname like 'AMAZON  %' and Domicile  in ('Brasil', 'France','Germany','United States','Italy','Luxembourg')

select * from FinancialRisks.Entities (nolock) 
where entityname like 'AMAZON.COM%'

select * from FinancialRisks.obligorpseudonym where obligorpseudonym like 'Amazon/%' 


select upper(entityname),* from FinancialRisks.Entities (nolock)  where CapitalIqId in ('IQ18749','IQ24971234','IQ47949690','IQ427340332') or entityid=3155737
select * from #Obligors where ObligorName like 'Amazon EU%' order by ObligorName


--Dodanie AMAZONa
exec useradmin.[dbo].[usp_start_FRED_UpdateMappings]
 
 exec useradmin.[dbo].[usp_check_server_agent_jobs_currently_running]


 exec Useradmin.[dbo].[usp_start_FRED_QuarterUpdate] 





select c.Countryname, ex.ObligorEntityID, en.entityname, uploaddate,source, GrossExposure, ex.*
from FinancialRisks.Exposures ex
join FinancialRisks.Entities en on en.entityid=ex.obligorentityid
join FinancialRisks.Countries c on c.Countryid=ex.Countryid
where Entityname like 'Amazon%'
and ex.uploaddate='2023-07-13T00:00:00.000'
order by Entityname



--Sprawdzanie Mapowania

select ObligorEntityName,obligors.ObligorName,c.CountryName,*
--UPDATE [FinancialRisks].[ExposuresQueue] SET [ObligorEntityName] = obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN [FinancialRisks].Countries c ON c.countryid=eq.countryName AND ISNUMERIC(eq.countryName) = 1
left JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
where ObligorEntityName like 'Amazon%'

select * from #Obligors where ObligorName like 'Amazon EU%' order by ObligorName

--Map those with valid IDS and with the country
--GSGL-1076 - 
select *
--UPDATE [FinancialRisks].[ExposuresQueue] SET [ObligorEntityName] = obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN [FinancialRisks].Countries c ON c.countryid=eq.countryName AND ISNUMERIC(eq.countryName) = 1
JOIN #Obligors obligors ON obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName)) + '/' + c.CountryName 
WHERE [Status] = 'NEW'
--AND [CobId] = @CobId
and ObligorEntityName like 'Amazon%'

select * 
--UPDATE [FinancialRisks].[ExposuresQueue] SET [ObligorEntityName] =obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
 JOIN [FinancialRisks].Countries c ON c.CountryName=obligors.countryName and c.countryid=eq.countryName AND ISNUMERIC(eq.countryName) = 1 
  WHERE [Status] = 'NEW'
  and ISNUMERIC([ObligorEntityName]) = 0 --Not maped earlier
--AND [CobId] = @CobId
and ObligorEntityName like 'Amazon%'

--Map those with valid IDS  and without the country but with ParentCountry
select * 
--UPDATE [FinancialRisks].[ExposuresQueue] SET [ObligorEntityName] =obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
  WHERE [Status] = 'NEW'
  and ISNUMERIC([ObligorEntityName]) = 0 --Not maped earlier
  and obligors.CountryName = obligors.ParentCountryName
--AND [CobId] = @CobId
	and ObligorEntityName like 'Amazon%'
	
--Map those with valid IDS  and without the country
select *
--UPDATE [FinancialRisks].[ExposuresQueue] SET [ObligorEntityName] =obligors.ObligorID ,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
  WHERE [Status] = 'NEW'
  and ISNUMERIC([ObligorEntityName]) = 0 --Not maped earlier
--AND [CobId] = @CobId
and ObligorEntityName like 'Amazon%'

