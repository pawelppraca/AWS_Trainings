
;WITH RCTE AS
       (
              SELECT  TradeSectorParentID, TradeSectorID, 1 AS Lvl
			  FROM FinancialRisks.TradeSector
                 WHERE TradeSectorParentID <> 0
              UNION ALL
              SELECT rh.TradeSectorParentID, rc.TradeSectorID, Lvl+1 AS Lvl 
              FROM FinancialRisks.TradeSector rh
              INNER JOIN RCTE rc ON rh.TradeSectorID = rc.TradeSectorParentID
                 WHERE rh.TradeSectorParentID <> 0
       )
,CTE_RN AS 
       (
              SELECT *, ROW_NUMBER() OVER (PARTITION BY r.TradeSectorID ORDER BY r.Lvl DESC) RN
              FROM RCTE r
       )

select *
into #CTE_RN
from CTE_RN

;WITH CurrencyFXRates AS 
(            SELECT    									
                        DISTINCT    									
                        ccyFrom.CurrencyCode  AS 'Name'	,								
                        roe.ExchangeRate   AS 'rate',
						YEAR(roe.ExchangeRateDateKey) AS 'year'
					--into #CurrencyFXRates	 									
            FROM    									
                        [sources].[vw_dwhr_Currencies] ccyFrom   									
                        INNER JOIN sources.vw_dwhr_ISOCurrencies ccyFromISO ON ccyFrom.ISOCurrencyKey = ccyFromISO.ISOCurrencyKey   									
                        INNER JOIN sources.vw_dwhr_ExchangeRates roe ON ccyFromISO.ISOCurrencyKey = roe.ISOCurrencyFromKey   									
                        INNER JOIN sources.vw_dwhr_ISOCurrencies ccyToISO ON roe.ISOCurrencyToKey = ccyToISO.ISOCurrencyKey   									
            WHERE    									
                        ccyToISO.ISOCurrencyCode = N'USD'   									
                      --  AND roe.ExchangeRateTypeCode = N'[Lloyd''s PIM]'  									
						AND roe.ExchangeRateTypeCode = N'[GAAP Plan]' 			
						--AND YEAR(roe.ExchangeRateDateKey) = year(getdate()) 	
),	
RCTE AS
       (
              SELECT  TradeSectorParentID, TradeSectorID, 1 AS Lvl
			  FROM FinancialRisks.TradeSector
                 WHERE TradeSectorParentID <> 0
              UNION ALL
              SELECT rh.TradeSectorParentID, rc.TradeSectorID, Lvl+1 AS Lvl 
              FROM FinancialRisks.TradeSector rh
              INNER JOIN RCTE rc ON rh.TradeSectorID = rc.TradeSectorParentID
                 WHERE rh.TradeSectorParentID <> 0
       )
,CTE_RN AS 
       (
              SELECT *, ROW_NUMBER() OVER (PARTITION BY r.TradeSectorID ORDER BY r.Lvl DESC) RN
              FROM RCTE r
       )
,GFRLMIELossByExposure
AS 
(
SELECT
	   ExposureId,
	   ObligorEntityId,
	   EntityName,
	   CapitalIqId,
	   Region,
	   SPRating,
	   GCHPRating,
	   LibertyRating,
	   CedantName, 
	   ReportingClass,
	   ClassOfBusiness,
	   CobId,
	   CountryName,
	   ClassLGD,
	   SovereignRating,
	   TradeSectorName,
	   TradeSectorId,
	   InceptionDate,
	   ExpiryDate,
	   RateGroup,
	   --CASE WHEN CedantName = 'LIB' THEN NULL ELSE TreatyType END AS TreatyType,
	   TreatyType,
	   CurrencyName, 
       GrossExposure,
	--XL CALC
	CASE WHEN TreatyType = 'XL' THEN
		CASE WHEN GrossExposure > (Excess /Rate) THEN  
			 CASE WHEN (GrossExposure - (Excess / Rate)) > (TreatyLimit / Rate) THEN (TreatyLimit / Rate) * SignedLine ELSE (GrossExposure - (Excess / Rate) ) * SignedLine END
		ELSE 0 END
	--QS CALC
	WHEN TreatyType in ('QS', 'BA') THEN 
		CASE WHEN ISNULL(TreatyLimit / Rate,0) > 0 THEN
			CASE WHEN GrossExposure > (TreatyLimit / Rate) THEN (TreatyLimit / Rate) * SignedLine ELSE GrossExposure * SignedLine END
		ELSE GrossExposure * SignedLine END
	ELSE GrossExposure -- For LMIE AND GFR that don't have treatys attached
	END AS LibertyExposure,
	InforceDate,TreatyLimit,Rate,Excess,SignedLine,OurShare,TreatyID,RiskReference,SystemTreatyId,assured,UploadDate,UltimateDomicile,UltimateRating, UltimateCountry
FROM
(
	SELECT DISTINCT tr.NewReference AS SystemTreatyId, e.ExposureId,
	c.Name AS CedantName,cob.ReportingClass,e.RiskReference,e.InceptionDate,e.ExpiryDate, tr.Limit AS TreatyLimit, ecr.Name AS CurrencyName, cr.RateGroup,
	 ttcr.Rate, e.CurrencyId, cob.CobId, cob.Name AS ClassOfBusiness,
	 tr.AuditCode AS TreatyType, tr.Excess, tr.SignedLine, tr.OurShare,
	CASE WHEN e.cobid NOT IN (1, 2, 5) THEN --COB IDs for GFR AND PTC which allready have their Currencies FX rates applied
		CASE WHEN e.GrossExposure / ecr.Rate > ISNULL(e.Limit / ecr.Rate,0) AND ISNULL(e.Limit / ecr.Rate,0) > 0 
		THEN ISNULL(e.Limit / ecr.Rate,0) 
		ELSE e.GrossExposure / ecr.Rate END
	ELSE e.GrossExposure END AS GrossExposure, 
	CASE 
		WHEN en.EntityName LIKE  '%Ministry%' OR en.EntityName LIKE  '%Confiscation%' THEN 
			CASE WHEN en.EntityName  LIKE  '%'+co.CountryName+'%' THEN en.EntityName
			ELSE en.EntityName +' - ' + co.CountryName  
		END ELSE en.EntityName
	END AS EntityName,
	 en.EntityId AS ObligorEntityId,
	 co.CountryName,
	 co.Region,
	ts.TradeSectorName,
	 ISNULL(ISNULL(OverrideTradeSectorId,ts.TradeSectorid),DefaultTradeSectorId) AS TradeSectorId,
	 CASE WHEN tso.TradeSectorName = 'Sovereign' THEN
	 -- Override > Sovereign > ->  GCHPRating -> LibertyRating -> Default
	       ISNULL(ISNULL(OverrideRating,ISNULL(NUllIF(co.SovereignRating,''),ISNULL(SPRating,(ISNULL(GCHPRating,LibertyRating))))),DefaultRating)
	    ELSE
	 -- Override-> S&P ->  GCHPRating -> LibertyRating -> Default 
           ISNULL(ISNULL(OverrideRating,ISNULL(SPRating,ISNULL(GCHPRating,LibertyRating))),DefaultRating)
      END as UltimateRating,
	 ISNULL(ISNULL(OverrideDomicile,Domicile),DefaultDomicile) AS UltimateDomicile,
	 ISNULL(ISNULL(ISNULL(OverrideDomicile,Domicile),DefaultDomicile),Co.CountryName) AS UltimateCountry,
	 cob.ClassLGD,
	 en.SPRating,
	 en.GCHPRating,
	 en.LibertyRating,
	 en.CapitalIqId,
	 co.SovereignRating,
	 e.InforceDate,TreatyID,assured,UploadDate
	FROM FinancialRisks.Exposures e
	--cedants
	LEFT JOIN FinancialRisks.Cedant c ON c.CedantID = e.CedantId
	--exposure riskcode mappings
	LEFT JOIN FinancialRisks.RiskCodeMappings riskCodeMappings ON riskCodeMappings.riskCode = ltrim(rtrim(e.RiskCode))
	--join treaties to exposures ON cedant, risk code group AND inforcedate
	LEFT JOIN FinancialRisks.Treaties tr ON tr.CedantId = c.CedantID  AND tr.InforceDate = e.InforceDate
	--exposure currency data
	LEFT JOIN FinancialRisks.Currencies cr ON cr.CurrencyID = e.CurrencyID
	--2019 Currency Exchange Rates for Exposures
	LEFT JOIN CurrencyFXRates ecr ON cr.CurrencyName = ecr.[Name] AND ecr.[year] = YEAR(UploadDate)
	--treaties currency data
	LEFT JOIN FinancialRisks.Currencies tcr ON tcr.CurrencyID = tr.CurrencyID
	--2019 Currency Exchange Rates for Treaties
	LEFT JOIN CurrencyFXRates ttcr ON tcr.CurrencyName = ttcr.[Name] AND ttcr.[year] = YEAR(UploadDate)
	--reporting classes data
	LEFT JOIN FinancialRisks.COB cob ON cob.CobId = e.CobId
	--obligor data
	LEFT JOIN FinancialRisks.Entities en ON en.EntityId = e.ObligorEntityId
	--country data
	LEFT JOIN FinancialRisks.Countries co ON co.CountryId = e.CountryId
	--trade sector data
	LEFT JOIN FinancialRisks.TradeSector ts ON ts.TradeSectorID = en.TradeSectorId
	LEFT JOIN FinancialRisks.TradeSector tso ON tso.TradeSectorID = en.OverrideTradeSectorId
	WHERE ((e.InceptionDate >= tr.InceptionDate AND e.InceptionDate <= tr.ExpiryDate) OR c.[Name] = 'LIB')
	AND en.EntityName != 'No capital IQ ID Assigned.'
	AND (e.RiskReference IS NULL OR e.RiskReference <> '584110/01/18')
	AND e.Source IN ('GFR','LMIE')
) innerQuery
),
/**************************************************************************************************************************************/
PTCLossByExposure
AS 
(
SELECT
	   ExposureId,
	   ObligorEntityId,
	   EntityName,
	   CapitalIqId,
	   Region,
	   SPRating,
	   GCHPRating,
	   LibertyRating,
	   CedantName, 
	   ReportingClass,
	   ClassOfBusiness,
	   CobId,
	   CountryName,
	   ClassLGD,
	   SovereignRating,
	   TradeSectorName,
	   TradeSectorId,
	   InceptionDate,
	   ExpiryDate,
	   RateGroup,
	   --CASE WHEN CedantName = 'LIB' THEN NULL ELSE TreatyType END AS TreatyType,
	   TreatyType,
	   CurrencyName, 
       GrossExposure,
	--XL CALC
	CASE WHEN TreatyType = 'XL' THEN
		CASE WHEN GrossExposure > (Excess /Rate) THEN  
			 CASE WHEN (GrossExposure - (Excess / Rate)) > (TreatyLimit / Rate) THEN (TreatyLimit / Rate) * SignedLine ELSE (GrossExposure - (Excess / Rate) ) * SignedLine END
		ELSE 0 END
	--QS CALC
	WHEN TreatyType in ('QS', 'BA') THEN 
		CASE WHEN ISNULL(TreatyLimit / Rate,0) > 0 THEN
			CASE WHEN GrossExposure > (TreatyLimit / Rate) THEN (TreatyLimit / Rate) * SignedLine ELSE GrossExposure * SignedLine END
		ELSE GrossExposure * SignedLine END
	ELSE GrossExposure -- For LMIE AND GFR that don't have treatys attached
	END AS LibertyExposure,
	InforceDate,TreatyLimit,Rate,Excess,SignedLine,OurShare,TreatyID,RiskReference,SystemTreatyId,assured,UploadDate,UltimateDomicile,UltimateRating, UltimateCountry
FROM
(
	SELECT DISTINCT tr.NewReference AS SystemTreatyId, e.ExposureId,
	c.Name AS CedantName,cob.ReportingClass,e.RiskReference,e.InceptionDate,e.ExpiryDate, tr.Limit AS TreatyLimit, ecr.[Name] AS CurrencyName, cr.RateGroup,
	 ttcr.Rate, e.CurrencyId, cob.CobId, cob.[Name] AS ClassOfBusiness,
	 tr.AuditCode AS TreatyType, tr.Excess, tr.SignedLine, tr.OurShare,
	CASE WHEN e.cobid NOT IN (1, 2, 5) THEN --COB IDs for GFR AND PTC which allready have their Currencies FX rates applied
		CASE WHEN e.GrossExposure / ecr.Rate > ISNULL(e.Limit / ecr.Rate,0) AND ISNULL(e.Limit / ecr.Rate,0) > 0 
		THEN ISNULL(e.Limit / ecr.Rate,0) 
		ELSE e.GrossExposure / ecr.Rate END
	ELSE e.GrossExposure END AS GrossExposure, 
	 
	 CASE WHEN en.EntityName LIKE  '%Ministry%' OR en.EntityName LIKE  '%Confiscation%'  
		  THEN CASE WHEN  en.EntityName  LIKE  '%'+co.CountryName+'%'
					THEN en.EntityName
					ELSE en.EntityName +' - ' + co.CountryName  
				END
		  ELSE en.EntityName
		END AS EntityName,
	 en.EntityId AS ObligorEntityId,
	 co.CountryName,
	 co.Region,
	 ts.TradeSectorName,
	 ISNULL(ISNULL(OverrideTradeSectorId,ts.TradeSectorid),DefaultTradeSectorId) AS TradeSectorId,
	 CASE WHEN tso.TradeSectorName = 'Sovereign' THEN
	 -- Override > Sovereign > ->  GCHPRating -> LibertyRating -> Default
	       ISNULL(ISNULL(OverrideRating,ISNULL(NUllIF(co.SovereignRating,''),ISNULL(SPRating,(ISNULL(GCHPRating,LibertyRating))))),DefaultRating)
	    ELSE
	 -- Override-> S&P ->  GCHPRating -> LibertyRating -> Default 
           ISNULL(ISNULL(OverrideRating,ISNULL(SPRating,ISNULL(GCHPRating,LibertyRating))),DefaultRating)
      END as UltimateRating,
	 ISNULL(ISNULL(OverrideDomicile,Domicile),DefaultDomicile) AS UltimateDomicile,
	 ISNULL(ISNULL(ISNULL(OverrideDomicile,Domicile),DefaultDomicile),Co.CountryName) AS UltimateCountry,
	 cob.ClassLGD,
	 en.SPRating,
	 en.GCHPRating,
	 en.LibertyRating,
	 en.CapitalIqId,
	 co.SovereignRating,
	 e.InforceDate,TreatyID,assured,UploadDate
	FROM FinancialRisks.Exposures e
	--cedants
	LEFT JOIN FinancialRisks.Cedant c ON c.CedantID = e.CedantId
	--exposure riskcode mappings
	LEFT JOIN FinancialRisks.RiskCodeMappings riskCodeMappings ON riskCodeMappings.riskCode = ltrim(rtrim(e.RiskCode))
	--join treaties to exposures ON cedant, risk code group AND inforcedate
	LEFT JOIN FinancialRisks.Treaties tr ON tr.CedantId = c.CedantID  AND tr.InforceDate = e.InforceDate AND e.RiskReference=tr.NewReference
	--exposure currency data
	LEFT JOIN FinancialRisks.Currencies cr ON cr.CurrencyID = e.CurrencyID
	--2019 Currency Exchange Rates for Exposures
	LEFT JOIN CurrencyFXRates ecr ON cr.CurrencyName = ecr.[Name] AND ecr.[year] = YEAR(UploadDate)
	--treaties currency data
	LEFT JOIN FinancialRisks.Currencies tcr ON tcr.CurrencyID = tr.CurrencyID
	--2019 Currency Exchange Rates for Treaties
	LEFT JOIN CurrencyFXRates ttcr ON tcr.CurrencyName = ttcr.[Name] AND ttcr.[year] = YEAR(UploadDate)
	--reporting classes data
	LEFT JOIN FinancialRisks.COB cob ON cob.CobId = e.CobId
	--obligor data
	LEFT JOIN FinancialRisks.Entities en ON en.EntityId = e.ObligorEntityId
	--country data
	LEFT JOIN FinancialRisks.Countries co ON co.CountryId = e.CountryId
	--trade sector data
	LEFT JOIN FinancialRisks.TradeSector ts ON ts.TradeSectorID = en.TradeSectorId
	LEFT JOIN FinancialRisks.TradeSector tso ON tso.TradeSectorID = en.OverrideTradeSectorId
	WHERE ((e.InceptionDate >= tr.InceptionDate AND e.InceptionDate <= tr.ExpiryDate) OR c.[Name] = 'LIB')
	AND en.EntityName != 'No capital IQ ID Assigned.'
	AND (e.RiskReference IS NULL OR e.RiskReference <> '584110/01/18')
	AND e.Source = 'PTC'
) innerQuery
/**************************************************************************************************************************************/
),PecLossByExposure AS 

(
SELECT
	   ExposureId,
	   ObligorEntityId,
	   EntityName,
	   CapitalIqId,
	   Region,
	   SPRating,
	   GCHPRating,
	   LibertyRating,
	   CedantName, 
	   ReportingClass,
	   ClassOfBusiness,
	   CobId,
	   CountryName,
	   ClassLGD,
	   SovereignRating,
	   TradeSectorName,
	   TradeSectorId,
	   InceptionDate,
	   ExpiryDate,
	   RateGroup,
	   --CASE WHEN CedantName = 'LIB' THEN NULL ELSE TreatyType END AS TreatyType,
	   TreatyType,
	   CurrencyName, 
       GrossExposure,
	--XL CALC
	CASE WHEN TreatyType = 'XL' THEN
		CASE WHEN GrossExposure > (Excess /Rate) THEN  
			 CASE WHEN (GrossExposure - (Excess / Rate)) > (TreatyLimit / Rate) THEN (TreatyLimit / Rate) * SignedLine ELSE (GrossExposure - (Excess / Rate) ) * SignedLine END
		ELSE 0 END
	--QS CALC
	WHEN TreatyType in ('QS', 'BA') THEN 
		CASE WHEN ISNULL(TreatyLimit / Rate,0) > 0 THEN
			CASE WHEN GrossExposure > (TreatyLimit / Rate) THEN (TreatyLimit / Rate) * SignedLine ELSE GrossExposure * SignedLine END
		ELSE GrossExposure * SignedLine END
	ELSE GrossExposure -- For LMIE AND GFR that don't have treatys attached
	END AS LibertyExposure,
	InforceDate,TreatyLimit,Rate,Excess,SignedLine,OurShare,TreatyID,RiskReference,SystemTreatyId,assured,UploadDate,UltimateDomicile,UltimateRating, UltimateCountry
FROM
(
	SELECT DISTINCT tr.NewReference AS SystemTreatyId, e.ExposureId,
	c.[Name] AS CedantName,cob.ReportingClass,e.RiskReference,e.InceptionDate,e.ExpiryDate, tr.Limit AS TreatyLimit, ecr.[Name] AS CurrencyName, cr.RateGroup,
	 ttcr.Rate, e.CurrencyId, cob.CobId, cob.[Name] AS ClassOfBusiness,
	 tr.AuditCode AS TreatyType, tr.Excess, tr.SignedLine, tr.OurShare,
	CASE WHEN e.cobid NOT IN (1, 2, 5) THEN --COB IDs for GFR AND PTC which allready have their Currencies FX rates applied
		CASE WHEN e.GrossExposure / ecr.Rate > ISNULL(e.Limit / ecr.Rate,0) AND ISNULL(e.Limit / ecr.Rate,0) > 0 
		THEN ISNULL(e.Limit / ecr.Rate,0) 
		ELSE e.GrossExposure / ecr.Rate END
	ELSE e.GrossExposure END AS GrossExposure, 
	 
	 CASE WHEN en.EntityName LIKE  '%Ministry%' OR en.EntityName LIKE  '%Confiscation%' 
		  THEN CASE WHEN  en.EntityName  LIKE  '%'+co.CountryName+'%'
					THEN en.EntityName
					ELSE en.EntityName +' - ' + co.CountryName  
				END
		  ELSE en.EntityName
		END AS EntityName,
	 en.EntityId AS ObligorEntityId,
	 co.CountryName,
	 co.Region,
	 ts.TradeSectorName,
	 ISNULL(ISNULL(OverrideTradeSectorId,ts.TradeSectorid),DefaultTradeSectorId) AS TradeSectorId,
	 CASE WHEN tso.TradeSectorName = 'Sovereign' THEN
	 -- Override > Sovereign > ->  GCHPRating -> LibertyRating -> Default
	       ISNULL(ISNULL(OverrideRating,ISNULL(NUllIF(co.SovereignRating,''),ISNULL(SPRating,(ISNULL(GCHPRating,LibertyRating))))),DefaultRating)
	    ELSE
	 -- Override-> S&P ->  GCHPRating -> LibertyRating -> Default 
           ISNULL(ISNULL(OverrideRating,ISNULL(SPRating,ISNULL(GCHPRating,LibertyRating))),DefaultRating)
     END AS UltimateRating,
	 ISNULL(ISNULL(OverrideDomicile,Domicile),DefaultDomicile) AS UltimateDomicile,
	 ISNULL(ISNULL(ISNULL(OverrideDomicile,Domicile),DefaultDomicile),Co.CountryName) AS UltimateCountry,
	 cob.ClassLGD,
	 en.SPRating,
	 en.GCHPRating,
	 en.LibertyRating,
	 en.CapitalIqId,
	 co.SovereignRating,
	 e.InforceDate,TreatyID,assured,UploadDate
	FROM FinancialRisks.Exposures e
	--cedants
	LEFT JOIN FinancialRisks.Cedant c ON c.CedantID = e.CedantId
	--exposure riskcode mappings
	LEFT JOIN FinancialRisks.RiskCodeMappings riskCodeMappings ON riskCodeMappings.riskCode = ltrim(rtrim(e.RiskCode)) 
	--join treaties to exposures ON cedant, risk code group AND inforcedate
	LEFT JOIN FinancialRisks.Treaties tr ON tr.CedantId = c.CedantID  AND tr.InforceDate = e.InforceDate AND riskCodeMappings.RiskCodeGroupId = tr.RiskCodeGroupId
	--exposure currency data
	LEFT JOIN FinancialRisks.Currencies cr ON cr.CurrencyID = e.CurrencyID
	--2019 Currency Exchange Rates for Exposures
	LEFT JOIN CurrencyFXRates ecr ON cr.CurrencyName = ecr.[Name] AND ecr.[year] = YEAR(UploadDate)
	--treaties currency data
	LEFT JOIN FinancialRisks.Currencies tcr ON tcr.CurrencyID = tr.CurrencyID
	--2019 Currency Exchange Rates for Treaties
	LEFT JOIN CurrencyFXRates ttcr ON tcr.CurrencyName = ttcr.[Name] AND ttcr.[year] = YEAR(UploadDate)
	--reporting classes data
	LEFT JOIN FinancialRisks.COB cob ON cob.CobId = e.CobId
	--obligor data
	LEFT JOIN FinancialRisks.Entities en ON en.EntityId = e.ObligorEntityId
	--country data
	LEFT JOIN FinancialRisks.Countries co ON co.CountryId = e.CountryId
	--trade sector data
	LEFT JOIN FinancialRisks.TradeSector ts ON ts.TradeSectorID = en.TradeSectorId
	LEFT JOIN FinancialRisks.TradeSector tso ON tso.TradeSectorID = en.OverrideTradeSectorId
	WHERE ((e.InceptionDate >= tr.InceptionDate AND e.InceptionDate <= tr.ExpiryDate) OR c.[Name] = 'LIB')
	AND en.EntityName != 'No capital IQ ID Assigned.'
	AND (e.RiskReference IS NULL OR e.RiskReference <> '584110/01/18')
	AND e.Source NOT IN ('PTC','LMIE','GFR')
) innerQuery

)

--lbeCSM AS (
	SELECT * 
	into #lbeCSM
	FROM (
		SELECT * FROM PecLossByExposure  
		UNION
		SELECT * FROM   PTCLossByExposure 
		UNION
		SELECT * FROM GFRLMIELossByExposure
	) A


	select distinct TreatyReference from FinancialRisks.TreatyReassignment where Changing = 'YES'   and InforceDate ='20211001'


	--choose several TreatyID to test
	select distinct SystemTreatyId --,* 
	from #lbeCSM
	where InforceDate='20230101' and CedantName in ('Nexus_BAA', 'FIA_Surety')
	and SystemTreatyId in (select distinct TreatyReference from FinancialRisks.TreatyReassignment where Changing = 'YES')
	

	/*
	'122518/01/22',
	'122518/03/22',
	'122525/02/21',
	'122534/01/20',
	'122534/01/21',
	'122632/01/13',
	'122632/01/15',
	'122632/01/17',
	'122632/01/18',
	'122632/02/14'
*/


	--choose several records

	insert into FinancialRisks.TreatyReassignment (CedantName,	ReportingClass,	TreatyReference,	Class,	ActualReportingClass,	Changing,	InforceDate)
	select CedantName,	ReportingClass,	TreatyReference,	Class,	'FRRI Surety',	Changing,	'20230101' 
	from FinancialRisks.TreatyReassignment where Changing = 'YES'  and InforceDate ='20211001'
	and TreatyReference in (
	'122518/01/22')

	insert into FinancialRisks.TreatyReassignment (CedantName,	ReportingClass,	TreatyReference,	Class,	ActualReportingClass,	Changing,	InforceDate)
	select CedantName,	ReportingClass,	TreatyReference,	Class,	ActualReportingClass,	Changing,	'20230101' 
	from FinancialRisks.TreatyReassignment where Changing = 'YES'  and InforceDate ='20211001'
	and TreatyReference in (
	'122534/01/21')




	,
	'122518/03/22',
	'122525/02/21',
	'122534/01/20',
	'122534/01/21',
	'122632/01/13',
	'122632/01/15',
	'122632/01/17',
	'122632/01/18',
	'122632/02/14')



	SELECT lbe.SystemTreatyId , lbe.InforceDate,
	
	lbe.[ExposureId]
	  ,lbe.TreatyID
	  ,lbe.CedantName
	  ,CASE WHEN  tr.ActualReportingClass IS NOT NULL THEN (SELECT Cobid FROM FinancialRisks.COB c WHERE c.[Name] = tr.ActualReportingClass) ELSE lbe.Cobid END AS CobId
	  ,CASE WHEN tr.ActualReportingClass IS NOT NULL THEN tr.ActualReportingClass ELSE lbe.ReportingClass END AS ReportingClass
	  ,CASE WHEN  tr.ActualReportingClass IS NOT NULL THEN (SELECT [Name] FROM FinancialRisks.COB c WHERE c.[Name] = tr.ActualReportingClass) ELSE lbe.ClassOfBusiness END AS ClassOfBusiness
	  ,CASE WHEN  tr.ActualReportingClass IS NOT NULL THEN (SELECT ClassLGD FROM FinancialRisks.COB c WHERE c.[Name] = tr.ActualReportingClass) ELSE lbe.ClassLGD END AS ClassLGD
	  ,lbe.SovereignRating
	  ,ts.tradesectorid AS TradeSectorId
	  ,ts.TradeSectorName
	  ,lbe.CurrencyName
	  ,lbe.RateGroup
	  ,lbe.CountryName
      ,lbe.[GrossExposure]
	  ,lbe.LibertyExposure
      ,lbe.[ObligorEntityId]
	  ,lbe.EntityName
      ,lbe.CapitalIqId
	  ,lbe.SPRating
	  ,lbe.GCHPRating
	  ,lbe.LibertyRating
      ,lbe.[Region]
      ,lbe.Rate
	  ,lbe.TreatyType
	  ,lbe.InforceDate
	  ,ISNULL(ISNULL(uts.UltimateParentID,lbe.TradeSectorID),0) AS TopLevelTradeSectorID --CSM TRADE SECTOR	  
	  ,ISNULL(OverrideTradeSectorId,ISNULL(e.TradeSectorId,DefaultTradeSectorId)) AS UltimateTradeSectorID
	  ,UltimateDomicile
	  ,UltimateRating
	  ,e.OverrideDomicile
	  ,e.OverrideRating
	  ,e.OverrideTradeSectorId
	  ,e.DefaultDomicile
	  ,e.DefaultRating
	  ,e.DefaultTradeSectorId
	  ,ts1.TradeSectorName AS OverrideTradeSectorName
	  ,ts2.TradeSectorName AS DefaultTradeSectorName
	  ,ts3.TradeSectorName AS TopLevelTradeSectorName
	  ,ts4.TradeSectorName AS UltimateTradeSectorName
	  ,lbe.[UltimateCountry]
 FROM #lbeCSM lbe
 LEFT JOIN FinancialRisks.TreatyReassignment tr ON lbe.SystemTreatyId = tr.TreatyReference 
												   AND lbe.CedantName = tr.CedantName	
												   AND lbe.InforceDate = tr.InforceDate 
												   AND tr.Changing = 'YES'
 LEFT JOIN FinancialRisks.TradeSector ts ON ts.TradeSectorID = lbe.TradeSectorId
 LEFT JOIN FinancialRisks.Entities e ON lbe.ObligorEntityId = e.EntityId
 LEFT JOIN  (
    SELECT c.TradeSectorID,ts2.TradeSectorName,c.TradeSectorParentID AS UltimateParentID,ts.TradeSectorName AS UltimateParentName 
	   FROM #CTE_RN c
       INNER JOIN FinancialRisks.TradeSector ts ON ts.TradeSectorID = c.TradeSectorParentID
       INNER JOIN FinancialRisks.TradeSector ts2 ON ts2.TradeSectorID = c.TradeSectorID
       WHERE RN=1 ) uts  ON uts.TradeSectorID = ISNULL(e.OverrideTradeSectorId, ISNULL(e.TradeSectorId, DefaultTradeSectorId))
 LEFT JOIN FinancialRisks.TradeSector ts1 ON ts1.TradeSectorID = e.OverrideTradeSectorId
 LEFT JOIN FinancialRisks.TradeSector ts2 ON ts2.TradeSectorID = e.DefaultTradeSectorId
 LEFT JOIN FinancialRisks.TradeSector ts3 ON ts3.TradeSectorID = ISNULL(ISNULL(uts.UltimateParentID,lbe.TradeSectorID),0) 
 LEFT JOIN FinancialRisks.TradeSector ts4 ON ts4.TradeSectorID = ISNULL(e.OverrideTradeSectorId, ISNULL(e.TradeSectorId,DefaultTradeSectorId))
 where lbe.SystemTreatyId in ('122534/01/21') and lbe.InforceDate='20230101'


 	SELECT lbe.SystemTreatyId , lbe.InforceDate,
	
	lbe.[ExposureId]
	  ,lbe.TreatyID
	  ,lbe.CedantName
	  ,CASE WHEN  tr.ActualReportingClass IS NOT NULL THEN (SELECT Cobid FROM FinancialRisks.COB c WHERE c.[Name] = tr.ActualReportingClass) ELSE lbe.Cobid END AS CobId
	  ,CASE WHEN tr.ActualReportingClass IS NOT NULL THEN tr.ActualReportingClass ELSE lbe.ReportingClass END AS ReportingClass
	  ,CASE WHEN  tr.ActualReportingClass IS NOT NULL THEN (SELECT [Name] FROM FinancialRisks.COB c WHERE c.[Name] = tr.ActualReportingClass) ELSE lbe.ClassOfBusiness END AS ClassOfBusiness
	  ,CASE WHEN  tr.ActualReportingClass IS NOT NULL THEN (SELECT ClassLGD FROM FinancialRisks.COB c WHERE c.[Name] = tr.ActualReportingClass) ELSE lbe.ClassLGD END AS ClassLGD
	  ,lbe.SovereignRating
	  ,ts.tradesectorid AS TradeSectorId
	  ,ts.TradeSectorName
	  ,lbe.CurrencyName
	  ,lbe.RateGroup
	  ,lbe.CountryName
      ,lbe.[GrossExposure]
	  ,lbe.LibertyExposure
      ,lbe.[ObligorEntityId]
	  ,lbe.EntityName
      ,lbe.CapitalIqId
	  ,lbe.SPRating
	  ,lbe.GCHPRating
	  ,lbe.LibertyRating
      ,lbe.[Region]
      ,lbe.Rate
	  ,lbe.TreatyType
	  ,lbe.InforceDate
	  ,ISNULL(ISNULL(uts.UltimateParentID,lbe.TradeSectorID),0) AS TopLevelTradeSectorID --CSM TRADE SECTOR	  
	  ,ISNULL(OverrideTradeSectorId,ISNULL(e.TradeSectorId,DefaultTradeSectorId)) AS UltimateTradeSectorID
	  ,UltimateDomicile
	  ,UltimateRating
	  ,e.OverrideDomicile
	  ,e.OverrideRating
	  ,e.OverrideTradeSectorId
	  ,e.DefaultDomicile
	  ,e.DefaultRating
	  ,e.DefaultTradeSectorId
	  ,ts1.TradeSectorName AS OverrideTradeSectorName
	  ,ts2.TradeSectorName AS DefaultTradeSectorName
	  ,ts3.TradeSectorName AS TopLevelTradeSectorName
	  ,ts4.TradeSectorName AS UltimateTradeSectorName
	  ,lbe.[UltimateCountry]
	  into 
 FROM #lbeCSM lbe
 LEFT JOIN FinancialRisks.TreatyReassignment tr ON lbe.SystemTreatyId = tr.TreatyReference 
												   AND lbe.CedantName = tr.CedantName	
												   AND lbe.InforceDate = tr.InforceDate 
												   AND tr.Changing = 'YES'
 LEFT JOIN FinancialRisks.TradeSector ts ON ts.TradeSectorID = lbe.TradeSectorId
 LEFT JOIN FinancialRisks.Entities e ON lbe.ObligorEntityId = e.EntityId
 LEFT JOIN  (
    SELECT c.TradeSectorID,ts2.TradeSectorName,c.TradeSectorParentID AS UltimateParentID,ts.TradeSectorName AS UltimateParentName 
	   FROM #CTE_RN c
       INNER JOIN FinancialRisks.TradeSector ts ON ts.TradeSectorID = c.TradeSectorParentID
       INNER JOIN FinancialRisks.TradeSector ts2 ON ts2.TradeSectorID = c.TradeSectorID
       WHERE RN=1 ) uts  ON uts.TradeSectorID = ISNULL(e.OverrideTradeSectorId, ISNULL(e.TradeSectorId, DefaultTradeSectorId))
 LEFT JOIN FinancialRisks.TradeSector ts1 ON ts1.TradeSectorID = e.OverrideTradeSectorId
 LEFT JOIN FinancialRisks.TradeSector ts2 ON ts2.TradeSectorID = e.DefaultTradeSectorId
 LEFT JOIN FinancialRisks.TradeSector ts3 ON ts3.TradeSectorID = ISNULL(ISNULL(uts.UltimateParentID,lbe.TradeSectorID),0) 
 LEFT JOIN FinancialRisks.TradeSector ts4 ON ts4.TradeSectorID = ISNULL(e.OverrideTradeSectorId, ISNULL(e.TradeSectorId,DefaultTradeSectorId))
 where lbe.SystemTreatyId in ('122518/01/22') and lbe.InforceDate='20230101'



