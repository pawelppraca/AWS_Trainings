select top 100 * from FinancialRisks.Countries c
join [FinancialRisks].[CountryPseudonym] cp on cp.CountryID=c.CountryId
where CountryName like 'United States of America%'


select top 100 * from FinancialRisks.Entities e
left join FinancialRisks.Countries c on c.CountryName = e.domicile
where e.Domicile='LAos'


select  * from FinancialRisks.Countries c
left join [FinancialRisks].[CountryPseudonym] cp on cp.CountryID=c.CountryId
where CountryName like 'L%'
order by c.CountryName


select * from FinancialRisks.Entities where OverrideTradeSectorId=262


--Wyszukanie krajow, ktore trzeba zmienic w Countries 

select * from financialrisks.countries c
left join (select distinct domicile from FinancialRisks.Entities) d on d.Domicile = c.CountryName
order by c.CountryName

select * from financialrisks.countries c
left join (select distinct domicile from FinancialRisks.Entities where OverrideTradeSectorId=262) d on d.Domicile = c.CountryName
where 
order by c.CountryName




select FinancialRisks.fn_CountryName_in_Input(EntityName) country,*  from FinancialRisks.Entities where OverrideTradeSectorId=262 and Domicile is null


select * from financialrisks.countries c 
join (select distinct FinancialRisks.fn_CountryName_in_Input(EntityName) country  from FinancialRisks.Entities where OverrideTradeSectorId=262 and Domicile is null) d on d.country = c.CountryName



select * from FinancialRisks.Entities where OverrideTradeSectorId=262

Select * from financialrisks.Entities e
Left join financialrisks.countries c on c.countryname=e.domicile 
Where c.countryid is null and  OverrideTradeSectorId=262



select * from [FinancialRisks].[CountryPseudonym]



select * from FinancialRisks.Countries where CountryName like '%kitts%'






select Domicile,* from FinancialRisks.Countries c
right join 
(
	select distinct Domicile  
	from FinancialRisks.Entities where OverrideTradeSectorId=262 and Domicile is not null
) d on d.Domicile=c.CountryName
where CountryId is null


select * from  FinancialRisks.Entities where OverrideTradeSectorId=262 and Domicile is  null




select * from FinancialRisks.Countries c where CountryName like '%Argentina%' 
select * from FinancialRisks.CountryPseudonym c where CountryPseudonym like '%Argentina%' 
select * from FinancialRisks.Countries c where CountryId=12



select * from FinancialRisks.Countries c where CountryName like '%Armenia%' 
select * from FinancialRisks.CountryPseudonym c where CountryPseudonym like '%Armenia%' 
select * from FinancialRisks.Countries c where CountryId=12


select count(*), CountryCapitalIqId
from FinancialRisks.Countries 
group by CountryCapitalIqId
having count(*)>1

select * from FinancialRisks.Countries c where CountryCapitalIqId in ('IQ49432987','IQ30189743')
select * from FinancialRisks.Countries c where CountryCapitalIqId is null








select distinct Domicile
into #Domicile2Add
from 
(
	select distinct Domicile from FinancialRisks.Entities where Domicile is not null 
) d
left join FinancialRisks.Countries c on d.Domicile=c.CountryName
where CountryId is null and d.Domicile not in ('(Invalid Identifier)','0','Misc','Other','Reunion')


--kraje ktore istnieja w Pseudonym i w Countries
--drop table #Countries_in_Pseudonym

select c.CountryId , c.CountryName CountryName_in_pseudonyms
into #Countries_in_Pseudonym
from FinancialRisks.Countries c
join FinancialRisks.CountryPseudonym cp on cp.CountryID=c.CountryId
and c.CountryName = cp.CountryPseudonym
order by c.CountryName 

select * from #Countries_in_Pseudonym
select * from #Domicile2Add

 

--Dodanie do CountryPseudonym brakujacych  (Bosnia-Herzegovina  )
select d2a.Domicile
into #Domicile2Add_as_Pseudonym
from FinancialRisks.Countries c
join FinancialRisks.CountryPseudonym cp on cp.CountryID=c.CountryId
join (
	select * from #Countries_in_Pseudonym
) c2 on c2.CountryId = c.CountryId
right join #Domicile2Add d2a on d2a.Domicile=cp.CountryPseudonym
where c.CountryId is null

select * from #Domicile2Add_as_Pseudonym dp
left join ( 
	select * from FinancialRisks.countries 
	) c on CHARINDEX (dp.Domicile, c.CountryName) > 0



/*
Bolivia
Democratic Republic of the Congo
Macedonia
South Korea
Syria
Cape Verde
Falkland Islands
Moldova
Palestinian Authority
Taiwan
Venezuela
*/



--Checking


select * from FinancialRisks.Countries c where CountryName like '%Macedonia%' 
select * from FinancialRisks.CountryPseudonym c where CountryPseudonym like '%Macedonia%' 

select * from #Countries_in_Pseudonym where CountryName_in_pseudonyms like '%Bosnia%'




select CountryName, d2a.Domicile, * 

from FinancialRisks.Countries c
join FinancialRisks.CountryPseudonym cp on cp.CountryID=c.CountryId
join (
	select * from #Countries_in_Pseudonym
) c2 on c2.CountryId = c.CountryId
join #Domicile2Add d2a on d2a.Domicile=cp.CountryPseudonym


select * from FinancialRisks.Countries c where CountryName like '%Timor%' 
select * from FinancialRisks.CountryPseudonym c where CountryPseudonym like '%Timor%' 



select * from FinancialRisks.Countries c where CountryName like '%Argentina%' 
select * from FinancialRisks.CountryPseudonym c where CountryPseudonym like '%Argentina%' 
select * from FinancialRisks.Countries c where CountryId=12


select count(*), CountryCapitalIqId
from FinancialRisks.Countries 
group by CountryCapitalIqId
having count(*)>1

select * from FinancialRisks.Countries where CountryCapitalIqId = ''