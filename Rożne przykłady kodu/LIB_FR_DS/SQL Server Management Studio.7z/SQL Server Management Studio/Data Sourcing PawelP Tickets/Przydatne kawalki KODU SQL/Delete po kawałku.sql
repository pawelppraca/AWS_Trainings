
while (exists (select top 1 1 from _temp_test_pp where name is not null))
begin

	begin tran
		delete top (10000) from _temp_test_pp where name is not null
	commit tran

	select 'deleted 10k'

end

