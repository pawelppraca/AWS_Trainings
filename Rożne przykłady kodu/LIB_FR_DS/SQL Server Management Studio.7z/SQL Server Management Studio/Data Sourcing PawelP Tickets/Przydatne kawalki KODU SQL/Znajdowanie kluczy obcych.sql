SELECT TOP 1000 
	fk.[name] as FKName
	,psch.name as SchemaName
	,ptbl.name as TableName
	,sch.name as RefSchemaName
	,tbl.name as RefTableName
  FROM [Warehouse_Repository].[sys].[foreign_keys] fk
  inner join sys.tables tbl
	on fk.[referenced_object_id] = tbl.object_id
  inner join sys.tables ptbl
	on fk.[parent_object_id] = ptbl.object_id
  inner join sys.schemas sch
	on tbl.schema_id = sch.schema_id
  inner join sys.schemas psch
	on ptbl.schema_id = psch.schema_id
  where tbl.name = 'Brokers'