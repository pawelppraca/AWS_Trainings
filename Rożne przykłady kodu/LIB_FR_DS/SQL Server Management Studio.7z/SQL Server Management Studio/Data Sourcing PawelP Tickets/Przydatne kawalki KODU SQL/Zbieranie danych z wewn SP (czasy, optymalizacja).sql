DROP TABLE IF EXISTS #proc_stat;
CREATE TABLE #proc_stat (id int not null IDENTITY(1,1), step NVARCHAR(100), starttime DATETIME, EndTime DateTIME)

DECLARE @stepMsg NVARCHAR(100) = N'Procedure started'


SET @stepMsg = N'pre-Load : TRUNCATE stats table';
insert into #proc_stat values (@stepMsg, getdate(), null)


/*

Tu jest kawa?ek kodu

*/

update #proc_stat set EndTime=getdate() where step = @stepMsg


--Nast?pny krok
SET @stepMsg = N'Co? tam';

insert into #proc_stat values (@stepMsg, getdate(), null)

/*

Tu jest kawa?ek kodu

*/

update #proc_stat set EndTime=getdate() where step = @stepMsg





--raport
select *, CONVERT(TIME, DATEADD(ss,DATEDIFF(SECOND,starttime,EndTime),0)) [Czas] from #proc_stat

