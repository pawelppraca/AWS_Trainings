--Przeliczenie sekund na minuty
DECLARE @s INT
SET  @s = 325
SELECT @s, CONVERT(TIME, DATEADD(SECOND, @s, 0));


--Czasy wykonania, r�?nica pomi?dzy godzinami przeliczona ma godziny, minuty i sekundy
IF OBJECT_ID('tempdb..#tab') IS NOT NULL  DROP TABLE #tab
SELECT EventExecutionKey, MIN(ExecutionStartDate) StartDate, MAX(ExecutionEndDate) EndDate
INTO #tab
FROM [ETL_Control].[dbo].[WorkQueueLog] WHERE TaskCode like '%APAC'
GROUP BY EventExecutionKey
ORDER BY EventExecutionKey


SELECT 
	CONVERT(VARCHAR, StartDate, 23) [Date] 
	,FORMAT(DATEADD(ss,DATEDIFF(SECOND,StartDate,EndDate),0),'HH:mm:ss') [Czas]
	,CONVERT(TIME, DATEADD(ss,DATEDIFF(SECOND,StartDate,EndDate),0)) [Czas]
	,* 
FROM #tab
ORDER BY StartDate