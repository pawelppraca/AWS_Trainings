INSERT INTO InsertDemo 
 VALUES ('Jack','2000-02-10',5,'London','56552244')
       ,('Daniel','2000-07-24',5,'Oxford','56448899')
     ,('Gonzalo','2000-01-13',5,'Cambridge','56254896')