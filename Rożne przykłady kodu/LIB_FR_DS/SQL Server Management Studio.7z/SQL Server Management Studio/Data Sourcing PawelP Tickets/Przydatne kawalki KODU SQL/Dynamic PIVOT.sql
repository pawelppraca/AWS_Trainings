-- Na podstawie 
-- https://www.mssqltips.com/sqlservertip/7233/sql-pivot-sql-unpivot-examples-transform-data/



declare @columns nvarchar(max), @sql nvarchar(max)
SET @columns = N'';

SELECT @columns += N', p.' + QUOTENAME([Day])
  FROM (SELECT convert(varchar, [ExecutionStartDate], 23) [Day] FROM #tasks AS p GROUP BY convert(varchar, [ExecutionStartDate], 23)) AS x;


SET @sql = N'
SELECT TaskCode, ' + STUFF(@columns, 1, 2, '') + '
FROM
(
   select TaskCode,task_time_min, convert(varchar, [ExecutionStartDate], 23) [Day] from #tasks
) AS j
PIVOT
(
  min(task_time_min) FOR [Day] IN ('
  + STUFF(REPLACE(@columns, ', p.[', ',['), 1, 1, '')
  + ')
) AS p;';

PRINT @sql;
EXEC sp_executesql @sql;

