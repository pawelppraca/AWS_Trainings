
--Losowae dane testowe
create table _temp_test_pp (id int identity(1,1), name varchar(100), quantity int)
--truncate table _temp_test_pp

declare @i int, @number int, @j int, @word varchar(30)
set @i = 0
while @i < 100000
begin
	
	--losowe s?owo	

	set @j = 1
	set @word=''
	while @j < 20
	begin
		set @word = @word + char(cast((90 - 65 )*rand() + 65 as integer)) 
		set @j = @j +1
	end
	--losowy numer
	set @number = CAST(RAND(CHECKSUM(NEWID()))*100000 as int) 
	insert into _temp_test_pp values (@word,@number)

	set @i = @i+1
end

select * from _temp_test_pp

