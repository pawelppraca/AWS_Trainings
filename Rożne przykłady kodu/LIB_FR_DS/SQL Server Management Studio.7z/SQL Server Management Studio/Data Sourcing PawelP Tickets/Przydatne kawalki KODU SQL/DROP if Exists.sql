IF OBJECT_ID('tempdb..#Results') IS NOT NULL
    DROP TABLE #Results

DROP TABLE IF EXISTS <table_name