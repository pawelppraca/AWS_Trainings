Select Column_Name + ' [' + DATA_TYPE + ']' + 
case when Data_Type in ('numeric', 'varchar', 'char')
    then '(' +
        case
            when DATA_TYPE = 'numeric' then CAST(numeric_precision as varchar(3)) + ',' + CAST(numeric_scale as varchar(3))
            when DATA_TYPE = 'varchar' then CAST(CHARACTER_MAXIMUM_LENGTH as varchar(3))
            when DATA_TYPE = 'char' then CAST(CHARACTER_MAXIMUM_LENGTH as varchar(3))
        end
         + ')'
    else ''
end
+ ','
, * 
From tempdb.INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME LIKE '#pptZUSP'

