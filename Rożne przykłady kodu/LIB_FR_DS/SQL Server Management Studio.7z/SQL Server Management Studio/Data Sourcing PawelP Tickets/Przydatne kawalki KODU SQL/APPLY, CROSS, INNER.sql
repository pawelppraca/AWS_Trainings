https://www.mssqltips.com/sqlservertip/1958/sql-server-cross-apply-and-outer-apply/


DROP TABLE IF EXISTS #LeftTable;
CREATE TABLE #LeftTable
(
    Id INT,
    Name NVARCHAR(10)
)
INSERT INTO #LeftTable
(
    Id,
    Name
)
VALUES
(1, 'Red'), (2, 'Green'), (3, 'Blue'), (4, 'Yellow'), (5, 'Purple');

DROP TABLE IF EXISTS #RightTable;
CREATE TABLE #RightTable
(
    Id INT,
    ReferenceId INT,
    Name NVARCHAR(10)
)
INSERT INTO #RightTable
(
    Id,
    ReferenceId,
    Name
)
VALUES
(1, 1, 'Dog'), (2, 1, 'Cat'), (3, 2, 'Bird'), (4, 4, 'Horse'), (5, 3, 'Bear'), (6, 1, 'Deer');
GO

-- CROSS APPLY
SELECT L.Name,
       R.Name
FROM #LeftTable L
    CROSS APPLY
(SELECT Name FROM #RightTable R WHERE R.ReferenceId = L.Id) R;

-- INNER JOIN
SELECT L.Name,
       R.Name
FROM #LeftTable L
    INNER JOIN #RightTable R
        ON R.ReferenceId = L.Id;

-- OUTER APPLY
SELECT L.Name,
       R.Name
FROM #LeftTable L
    OUTER APPLY
(SELECT Name FROM #RightTable R WHERE R.ReferenceId = L.Id) R;

-- LEFT OUTER JOIN
SELECT L.Name,
       R.Name
FROM #LeftTable L
    LEFT OUTER JOIN #RightTable R
        ON R.ReferenceId = L.Id;

-- CROSS APPLY with a Table Expression
SELECT *
FROM #LeftTable L
    CROSS APPLY
(
    SELECT TOP 2
        R.Name
    FROM #RightTable R
    WHERE R.ReferenceId = L.Id
    ORDER BY R.Id DESC
) R;