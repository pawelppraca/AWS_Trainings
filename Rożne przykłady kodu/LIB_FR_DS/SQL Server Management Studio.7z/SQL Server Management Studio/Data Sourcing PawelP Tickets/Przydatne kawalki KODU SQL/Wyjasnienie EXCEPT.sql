
create table #t1 (id int identity(1,1), name varchar(30))
create table #t2 (id int identity(1,1), name varchar(30))

insert into #t1 values ('A'),('B'),('C')
insert into #t2 values ('A'),('B'),('D')

delete from #t1 where name='B'

insert into #t1 values ('B')



select * from #t1
Except
select * from #t2

select * from #t2
Except
select * from #t1