--Control_Shared_IncrementalProcessingLogValidateEndPoints.dtsx

declare @SourceSystemCode varchar(30), @SourceEndPoint int, @TargetEndPoint int

set @SourceSystemCode = 'MDS'
set @SourceEndPoint= ''
set @TargetEndPoint = 

SELECT
LogEntryType
,OpenedByEventExecutionKey
,SourceEndPoint
,TargetEndPoint
,SourceSystemCode
FROM
dbo.IncrementalProcessingLog
WHERE
SourceSystemCode = @SourceSystemCode
AND SourceEndPoint = @SourceEndPoint
AND TargetEndPoint = @TargetEndPoint
ORDER BY
LogEntryType
,OpenedByEventExecutionKey
,SourceEndPoint
,TargetEndPoint