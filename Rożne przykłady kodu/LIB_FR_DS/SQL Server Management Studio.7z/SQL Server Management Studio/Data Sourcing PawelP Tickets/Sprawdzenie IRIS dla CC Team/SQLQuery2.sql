-- IRIS
-- Sfailowawane SCM sa w tabelach UTK
-- SCMy kt�re przesz?y walidacj? s? w UKK

-- 1. Z kr�tej tabeli s? replikowane SCMy do DWH
-- 2. Czy dla SCM�w w DWH populowana jest kolumna zawieraj?ca UMR (Unique Market Reference)? Z tego co wspominali w IRISie ona jest pod polem KMUMRF na tabeli UKKMREP.
-- v 3. W jaki spos�b SCMy trafiaj? do DWH? Czy s? pushowane z IRISa czy leci pulling batch po stronie DWH? - DONE

SELECT TOP 100 KMUMRF,* FROM [ODS_IRIS].dbo.[UKKMREP] ORDER BY [_EventExecutionKey] desc






SELECT UniqueMarketReference,UniqueClaimReference, [_MergeKey], [_SourceSystemCode], [_EffectiveFrom],[_EffectiveTo],* FROM [Warehouse_Repository].dbo.claims WHERE UniqueMarketReference 
IN
(
'B0775TS343B11',
'B0868PUSNA1200459',
'B0775TS343B12',
'B0823QC1404355',
'B0572NA14NRA1',
'B110814A0Z1045',
'B080122546P15',
'B0509FINPL1500030'
)
