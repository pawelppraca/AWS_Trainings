CREATE TABLE #DHWCCIDs(id INT) 

INSERT INTO #DHWCCIDs VALUES 

--list of max ids from cc 

GO 

? 

select I 
,BPR 
,MovementReference 
, SyndicateID 
, Ucr 
, CarrierReference 
into #temp1 
FROM(                                                        
	SELECT                                                        
	utk.TransactionSeq                                         AS [I] 
	, KOBPR                                                    AS BPR 
	, KMSYN                                                    AS SyndicateID 
	, KOMVRF                                                   AS MovementReference 
	, KMUCRF                                                   AS Ucr 
	, KMSYC                                                       AS CarrierReference 
	from    [ODS_IRIS].[cole].[FeederMap_SCMTransaction_UTKOREP] utk  
	INNER JOIN  [ODS_IRIS]..UTKOREP ON TransactionSeq = KOKTSQ 
	inner join (
			SELECT KMCTCD, KMCMF, KMASOG, KMSYN, KMLCR, KMLOF, kmbpr, KMTFCD, KMUCRF, KMPHID, KMCMSQ, KMDRCD, KMSYC, [_LastAction], [_DateCreated] 
			, ROW_NUMBER() OVER( PARTITION BY KMCTCD, KMSYN, KMLCR, KMLOF, kmbpr, KMDRCD ORDER BY [_DateCreated] DESC, [_LastAction] DESC, [_EventExecutionKey] desc) AS rank1 
			FROM [ODS_IRIS]..UKKMREP) 
			ukkmord on ukkmord.kmbpr=KOBPR AND Rank1 = 1 
			) t1 
    join #DHWCCIDs on #DHWCCIDs.id=I 
    go 

? 
    select * from #temp1 
    select distinct(select t1.I ) 

    FROM (
		SELECT                                                        
			utk.TransactionSeq                                         AS [I] 
			, KOBPR                                                    AS BPR 
			, KMSYN                                                    AS SyndicateID 
			, KOMVRF                                                   AS MovementReference 
			, KMUCRF                                                   AS Ucr 
			, KMSYC                                                       AS CarrierReference 
		FROM    [ODS_IRIS].[cole].[FeederMap_SCMTransaction_UTKOREP] utk  
		INNER JOIN  [ODS_IRIS]..UTKOREP ON TransactionSeq = KOKTSQ 
		INNER join (
						SELECT KMCTCD, KMCMF, KMASOG, KMSYN, KMLCR, KMLOF, kmbpr, KMTFCD, KMUCRF, KMPHID, KMCMSQ, KMDRCD, KMSYC, [_LastAction], [_DateCreated] 
						, ROW_NUMBER() OVER( PARTITION BY KMCTCD, KMSYN, KMLCR, KMLOF,kmbpr, KMDRCD ORDER BY [_DateCreated] DESC, [_LastAction] DESC, [_EventExecutionKey] desc) AS rank1 
						FROM [ODS_IRIS]..UKKMREP 
						) ukkmord on ukkmord.kmbpr=KOBPR AND Rank1 = 1 
					) t1 
    join #temp1 on #temp1.BPR=t1.BPR and #temp1.CarrierReference=t1.CarrierReference  
    and #temp1.SyndicateID=t1.SyndicateID and #temp1.Ucr=t1.Ucr and t1.MovementReference<#temp1.MovementReference 

    drop table #DHWCCIDs 
    drop table #temp1 