
--W jakich taskach jest uzyta tabela 

isEnabled - czy wlaczone


SELECT  TaskCode, TaskDescription, t.TaskGroupCode, t.TaskTypeCode, t.LayerCode, t.SourceSystemCode, ExecutableName, ExecutionPriority, IsBLOEMode, IsEnabled, EventCode, *
  FROM [ETL_Control].[dbo].[Tasks] t
  JOIN TaskGroups tg ON tg.TaskGroupCode = t.TaskGroupCode
  JOIN [dbo].[WorkflowConstraints] wc ON wc.PrecedentTaskGroupCode  = tg.TaskGroupCode
  WHERE t.taskcode like '%CBIClaimListing%'


--Lista po??cze? uzywana w wybranych taskach

select 
ConnectionString,t.TaskCode,tgc.ConnectionCode 
from
ETL_Control.[dbo].[EventTaskGroups] etg 
left join ETL_Control.[dbo].TaskGroups tg on etg.TaskGroupCode=tg.TaskGroupCode
left join ETL_Control.[dbo].Tasks t on tg.TaskGroupCode = t.TaskGroupCode
left join [ETL_Control].[dbo].[TaskGroupConnections] tgc on tgc.TaskGroupCode = tg.TaskGroupCode
left join [ETL_Control].dbo.connections c on c.ConnectionCode=tgc.ConnectionCode
where TaskCode  in ('LOAD_IRIS_PremiumAmendmentGroups','LOAD_MDS_PremiumAmendmentGroups','EXTRACT_MDS_PremiumAmendmentGroups','EXTRACT_IRIS_PremiumAmendmentGroups')







USE ETL_Control

select * from Events where SourceSystemCode ='CORE'

select * from Events e
join taskgroups tg on tg.SourceSystemCode = e.SourceSystemCode 
where e.SourceSystemCode ='CORE' 
and e.EventCode='MASTER_DWH_IBD_LOAD'


select * from [dbo].[GetTaskDepth]('MDS')


select top 100 EventExecutionKey, WorkQueueTaskKey, EventCode, EventStatusCode, TaskCode, TaskStatusCode, ElapsedTime, TaskDescription, TaskGroupCode, LayerCode, LayerDescription, Depth, ExecutionPriority, BLOEMode, TaskExecutionStartDate, TaskExecutionEndDate
,* from [UI].[WorkQueueGridStatistics] where eventcode like '%POSTDWLOADPROCESSING_2%'


declare @EventCode varchar(250)
set @EventCode= 'EXEC_EVENT_POSTDWLOADPROCESSING'

SELECT 
	eel.EventExecutionKey, 
	eel.EventCode, 
	eel.SourceSystemCode, 
	IIF(wqel.EventExecutionKey IS NULL, 'SUCCESSFUL', 'FAILED') EventStatus,
	eel.EventStatusCode AS EventFinalStatus, 
	eel.ExecutionStartDate, 
	eel.ExecutionEndDate, 
	DateDiff(SECOND, eel.ExecutionStartDate, eel.ExecutionEndDate) AS DurationSeconds,
	CAST(IIF(wqel.EventExecutionKey IS NULL, DateDiff(SECOND, eel.ExecutionStartDate, eel.ExecutionEndDate), 0) AS INT) AS DurationSecondsSuccessful,
	CAST(IIF(wqel.EventExecutionKey IS NULL, 1, 0) AS INT) AS IsSuccessful,
	eel.ExecutedByUser, 
	eel.ParentEventExecutionKey	
FROM
	dbo.EventExecutionLog eel
LEFT JOIN 
	(
		SELECT DISTINCT EventExecutionKey FROM dbo.WorkQueueErrorLog 
	) wqel
ON
	eel.EventExecutionKey = wqel.EventExecutionKey
WHERE
	eel.ExecutionStartDate > (SELECT DeploymentDate FROM [dbo].[ETLControlVersion] WHERE [Version] = 'Version 2')
AND	eel.EventCode = @EventCode


--Lista wykona?

exec [Report].[EventExecutionDetails] 272006


--Sprawdzenie b?ed�w ONP z poprzedniego dnia

SELECT top 100
	eel.EventExecutionKey, eel.SourceSystemCode, eel.EventStatusCode, eel.ExecutedByUser,
	eel.EventCode,
	eel.ExecutionStartDate AS EventExecutionStartDate,
	wqel.TaskCode,
	wqel.TaskStatusCode,
	wqel.ExecutionStartDate,
	wqel.ExecutionEndDate,
	wqel.ErrorInformation
FROM
	[ETL_Control].dbo.WorkQueueErrorLog wqel
JOIN 
	[ETL_Control].dbo.EventExecutionLog eel
ON 
	wqel.EventExecutionKey = eel.EventExecutionKey
WHERE 
	eel.ExecutionStartDate >= dateadd(day,-1,getdate())






--Jak sprawdzi? nadrz?dny proces - na przyk?adzie 
-- MASTER_DWH_IBD_LOAD > EXEC_EVENT_MASTER_DWH_LOAD > EXEC_EVENT_MDS  > EXTRACT_MDS_AccountingCurrencies

Use ETL_Control

Select * from Tasks where taskcode='EXTRACT_MDS_AccountingCurrencies'
Select * from Events where eventcode='MDS'
Select * from Events where SourceSystemCode='MDS'

Select * from [dbo].[TaskGroups] where SourceSystemCode='MDS'


select 
etg.*,'|||',tg.*,'|||',t.*,'|||',tgc.*,'|||',c.*
from
ETL_Control.[dbo].[EventTaskGroups] etg 
left join ETL_Control.[dbo].TaskGroups tg on etg.TaskGroupCode=tg.TaskGroupCode
left join ETL_Control.[dbo].Tasks t on tg.TaskGroupCode = t.TaskGroupCode
left join [ETL_Control].[dbo].[TaskGroupConnections] tgc on tgc.TaskGroupCode = tg.TaskGroupCode
left join [ETL_Control].dbo.connections c on c.ConnectionCode=tgc.ConnectionCode
where TaskCode  in ('EXTRACT_MDS_AccountingCurrencies')



Select * from Tasks where taskcode like '%POSTDWLOADPROCESSING_2%'

select * from Events e
join taskgroups tg on tg.SourceSystemCode = e.SourceSystemCode 
where e.SourceSystemCode ='CORE' 
and e.EventCode='MASTER_DWH_IBD_LOAD'



--Event do ktorego nalezy task
select ETG.EventCode, T.TaskCode  
	FROM 
		dbo.Tasks T
	INNER JOIN
		dbo.TaskGroups TG
	ON 
		T.TaskGroupCode = TG.TaskGroupCode
	INNER JOIN 
		dbo.EventTaskGroups ETG
	ON
		TG.TaskGroupCode = ETG.TaskGroupCode 
	WHERE
	TaskCode like '%POSTDWLOADPROCESSING_2%'


	--Taski i eventy podrz?dn?
	select ETG.EventCode, T.TaskCode,*  
	FROM 
		dbo.Tasks T
	INNER JOIN
		dbo.TaskGroups TG
	ON 
		T.TaskGroupCode = TG.TaskGroupCode
	INNER JOIN 
		dbo.EventTaskGroups ETG
	ON
		TG.TaskGroupCode = ETG.TaskGroupCode 
	WHERE
	EventCode='MASTER_PUBLISH_DWH_DATABASES'




	select ETG.EventCode, T.TaskCode  
 
	FROM 
		dbo.Tasks T
	INNER JOIN
		dbo.TaskGroups TG
	ON 
		T.TaskGroupCode = TG.TaskGroupCode
	INNER JOIN 
		dbo.EventTaskGroups ETG
	ON
		TG.TaskGroupCode = ETG.TaskGroupCode 
	WHERE ETG.EventCode in
 
(
select ETG.EventCode
 
	FROM 
		dbo.Tasks T
	INNER JOIN
		dbo.TaskGroups TG
	ON 
		T.TaskGroupCode = TG.TaskGroupCode
	INNER JOIN 
		dbo.EventTaskGroups ETG
	ON
		TG.TaskGroupCode = ETG.TaskGroupCode 
	WHERE
	TaskCode like '%POSTDWLOADPROCESSING_2%' 
)


--Depth

select * from [WorkflowConstraints] where [EventCode] ='MASTER_PUBLISH_DWH_DATABASES' 


select * from [dbo].[GetTaskDepth] ('MASTER_PUBLISH_DWH_DATABASES')