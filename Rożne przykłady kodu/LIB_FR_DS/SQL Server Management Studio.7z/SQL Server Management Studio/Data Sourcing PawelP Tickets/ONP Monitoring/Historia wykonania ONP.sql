
--Historia wykonania ONP

SELECT [EventExecutionKey]
      ,[EventCode]
      ,[SourceSystemCode]
      ,[CDCLowerBoundary]
      ,[CDCUpperBoundary]
      ,[EventStatusCode]
      ,[ExecutionStartDate]
      ,[ExecutionEndDate]
	  , DATEDIFF(MINUTE,[ExecutionStartDate],[ExecutionEndDate]) ExecutionTime_min
	  , SUBSTRING(CAST(CONVERT(TIME,DATEADD(SECOND,DATEDIFF(SECOND,[ExecutionStartDate],[ExecutionEndDate]) ,1)) AS VARCHAR),1,8) ExecutionTime_str
      ,[ExecutedByUser]
      ,[ParentEventExecutionKey]
  FROM [ETL_Control].[dbo].[EventExecutionLog]
  WHERE 1=1
  --and EventCode = 'MASTER_DWH_IBD_LOAD' --Glowny Event IBD (Startuje codziennie o godz. 20 UK)
  --and EventCode = 'LMIELIBRE' --Glowny Event DWH (Startuje codziennie o godz. 0.50 UK)
  --and EventCode = 'MASTER_GENIUS_REP' --trzeci Job ()
  --and EventCode = 'MASTER_PUBLISH_DWH_DATABASES' --Genius LOad to DWH
  --and EventCode = 'MASTER_PUBLISH_DWH_DATABASES_APAC'
  --and EventStatusCode ='SUCCESSFUL'
  AND EventCode = 'FinanceDataPlatformLoad'
  AND ExecutionStartDate BETWEEN '20241225' AND '20250103'

  ORDER BY EventExecutionKey DESC 



  --sprawdzenie szczeg�l�w dla wybranego EEK
  DECLARE @EEK INT = 328215
  SELECT * FROM etl_control.dbo.WorkQueueLog 
  WHERE [EventExecutionKey]=@EEK
  ORDER BY WorkflowReverseDependencyDepth 




  
SELECT [EventExecutionKey]
      ,[EventCode]
      ,[SourceSystemCode]
      ,[CDCLowerBoundary]
      ,[CDCUpperBoundary]
      ,[EventStatusCode]
      ,[ExecutionStartDate]
      ,[ExecutionEndDate]
	  , DATEDIFF(MINUTE,[ExecutionStartDate],[ExecutionEndDate]) ExecutionTime_min
	  , SUBSTRING(CAST(CONVERT(TIME,DATEADD(SECOND,DATEDIFF(SECOND,[ExecutionStartDate],[ExecutionEndDate]) ,1)) as varchar),1,8) ExecutionTime_str
      ,[ExecutedByUser]
      ,[ParentEventExecutionKey]
  FROM [ETL_Control].[dbo].[EventExecutionLog]
  where 1=1
  --and EventCode = 'MASTER_DWH_IBD_LOAD' --Glowny Event IBD (Startuje codziennie o godz. 20 UK)
  --and EventCode = 'LMIELIBRE' --Glowny Event DWH (Startuje codziennie o godz. 0.50 UK)
  --and EventCode = 'MASTER_GENIUS_REP' --trzeci Job ()
  and EventCode = 'MASTER_PUBLISH_DWH_DATABASES_APAC' --Glowny Event IBD (Startuje codziennie o godz. 20 UK)
  --and EventStatusCode ='SUCCESSFUL'
  and ExecutionStartDate between '20240701' and '20240711'

  order by EventExecutionKey desc 




  

SELECT [EventExecutionKey]
      ,[EventCode]
      ,[SourceSystemCode]
      ,[CDCLowerBoundary]
      ,[CDCUpperBoundary]
      ,[EventStatusCode]
      ,[ExecutionStartDate]
      ,[ExecutionEndDate]
	  , DATEDIFF(MINUTE,[ExecutionStartDate],[ExecutionEndDate]) ExecutionTime
	  , substring(cast(convert(Time,Dateadd(second,DATEDIFF(second,[ExecutionStartDate],[ExecutionEndDate]) ,1)) as varchar),1,8) ExecutionTime_str
      ,[ExecutedByUser]
      ,[ParentEventExecutionKey]
  FROM [ETL_Control].[dbo].[EventExecutionLog]
  where 1=1
  --and EventCode = 'MASTER_DWH_IBD_LOAD' --Glowny Event IBD (Startuje codziennie o godz. 20 UK)
  --and EventCode = 'MASTER_PUBLISH_DWH_DATABASES' --Glowny Event DWH (Startuje codziennie o godz. 0.50 UK)
  --and EventCode = 'MASTER_GENIUS_REP' --trzeci Job ()
  --and EventCode = 'MASTER_DWH_IBD_LOAD' --Glowny Event IBD (Startuje codziennie o godz. 20 UK)
  and EventCode = 'AIR_ADM_FEED'
  and ExecutionStartDate >='20240401'
  order by EventExecutionKey desc


  --Sprawdzenie czy Event by? w kolejce
  select top 10 * from [ETL_Control].[dbo].[WorkQueueLog] (nolock)
  where taskcode='LOAD_FinanceDataPlatform'
  order by EventExecutionKey desc


  
  --Sprawdzenie b?ed�w event�w w kolejce
  select top 100 * from [ETL_Control].[dbo].[WorkQueueErrorLog] 
  where ErrorInformation like '%LOAD_FinanceDataPlatform%'
  order by EventExecutionKey desc

  
--Przeliczenie sekund na minuty
DECLARE @s INT
Set  @s = 325
SELECT @s, CONVERT(TIME, DATEADD(SECOND, @s, 0));


--Czasy wykonania, r�?nica pomi?dzy godzinami przeliczona ma godziny, minuty i sekundy
IF OBJECT_ID('tempdb..#tab') IS NOT NULL  DROP TABLE #tab
select EventExecutionKey, min(ExecutionStartDate) StartDate, max(ExecutionEndDate) EndDate
into #tab
from [ETL_Control].[dbo].[WorkQueueLog] where TaskCode like '%APAC'
group by EventExecutionKey
order by EventExecutionKey


select convert(varchar, StartDate, 23) [Date], format(dateadd(ss,datediff(SECOND,StartDate,EndDate),0),'HH:mm:ss'),* from #tab
order by StartDate


--Zbieranie danych LSMDATA-

--drop table #temp

SELECT [EventExecutionKey]
      ,[EventCode]
      ,[SourceSystemCode]
      ,[EventStatusCode]
      ,[ExecutionStartDate]
      ,[ExecutionEndDate]
	  , DATEDIFF(MINUTE,[ExecutionStartDate],[ExecutionEndDate]) ExecutionTime_min
	  , substring(cast(convert(Time,Dateadd(second,DATEDIFF(second,[ExecutionStartDate],[ExecutionEndDate]) ,1)) as varchar),1,8) ExecutionTime_str
      ,[ExecutedByUser]
  INTO #temp
  FROM [ETL_Control].[dbo].[EventExecutionLog]
  WHERE 1=1
  AND EventCode = 'GENIUStoDWH_DP'
  AND ExecutionStartDate >='20240201'
  AND EventStatusCode='SUCCESSFUL'
  ORDER BY EventExecutionKey 



SELECT 
	  t.eventcode
	, t.ExecutionTime_min Event_Exec_Time_min
	, t.ExecutionTime_str Event_Exec_Time
	, t.EventExecutionKey
	, TaskCode
	, DATEDIFF(MINUTE,wq.[ExecutionStartDate],wq.[ExecutionEndDate]) task_time_min
	, SUBSTRING(CAST(CONVERT(TIME,DATEADD(SECOND,DATEDIFF(SECOND,wq.[ExecutionStartDate],wq.[ExecutionEndDate]) ,1)) AS VARCHAR),1,8) Task_ExecutionTime
	, wq.ExecutionStartDate
	, wq.ExecutionEndDate
INTO #tasks
FROM [ETL_Control].[dbo].[WorkQueueLog] wq
JOIN #temp t ON t.[EventExecutionKey] = wq.EventExecutionKey
WHERE DATEDIFF(MINUTE,wq.[ExecutionStartDate],wq.[ExecutionEndDate]) > 1 --longer than 1 min
ORDER BY t.EventExecutionKey


select * from #tasks where TaskCode='CONTROL_GENIUS_ProcessPolicyStatusUpdates_DWH_DP'



select 
	CASE 
		WHEN FORMAT ([ExecutionStartDate], 'HH:mm:dd') between '10:00:00' and '19:00:00' 
			THEN FORMAT ([ExecutionStartDate], 'yyyy-MM-dd')+'_APAC'
			ELSE FORMAT ([ExecutionStartDate], 'yyyy-MM-dd')+'_'
	END [Day]
, FORMAT ([ExecutionStartDate], 'HH:mm:dd') as time
, FORMAT ([ExecutionStartDate], 'yyyy-MM-dd') as [Day]

from #tasks order by ExecutionStartDate


select  TaskCode,task_time_min, Task_ExecutionTime, convert(varchar, [ExecutionStartDate], 23) [Day],
CASE 
		WHEN FORMAT ([ExecutionStartDate], 'HH:mm:dd') between '10:00:00' and '19:00:00' 
			THEN FORMAT ([ExecutionStartDate], 'yyyy-MM-dd')+'_APAC'
			ELSE FORMAT ([ExecutionStartDate], 'yyyy-MM-dd')+'_'
	END [Day]
from #tasks
order by convert(varchar, [ExecutionStartDate], 23), TaskCode


declare @columns nvarchar(max), @sql nvarchar(max)
SET @columns = N'';

SELECT @columns += N', p.' + QUOTENAME([Day])
  FROM (SELECT 
			CASE 
			WHEN FORMAT ([ExecutionStartDate], 'HH:mm:dd') between '10:00:00' and '19:00:00' 
				THEN FORMAT ([ExecutionStartDate], 'yyyy-MM-dd')+'_APAC'
				ELSE FORMAT ([ExecutionStartDate], 'yyyy-MM-dd')
			END [Day]
		FROM #tasks AS p GROUP BY 
					CASE 
						WHEN FORMAT ([ExecutionStartDate], 'HH:mm:dd') between '10:00:00' and '19:00:00' 
						THEN FORMAT ([ExecutionStartDate], 'yyyy-MM-dd')+'_APAC'
						ELSE FORMAT ([ExecutionStartDate], 'yyyy-MM-dd')
					END
		) AS x;

	select @columns

SET @sql = N'
SELECT TaskCode, ' + STUFF(@columns, 1, 2, '') + '
FROM
(
   select TaskCode,Task_ExecutionTime, CASE 
			WHEN FORMAT ([ExecutionStartDate], ''HH:mm:dd'') between ''10:00:00'' and ''19:00:00'' 
				THEN FORMAT ([ExecutionStartDate], ''yyyy-MM-dd'')+''_APAC''
				ELSE FORMAT ([ExecutionStartDate], ''yyyy-MM-dd'')
			END [Day] from #tasks
) AS j
PIVOT
(
  min(Task_ExecutionTime) FOR [Day] IN ('
  + STUFF(REPLACE(@columns, ', p.[', ',['), 1, 1, '')
  + ')
) AS p;';

PRINT @sql;
EXEC sp_executesql @sql;



Select distinct TaskCode, [2024-02-01],[2024-02-02],[2024-02-04],[2024-02-05],[2024-02-06]

FROM
	(select TaskCode,task_time_min, convert(varchar, [ExecutionStartDate], 23) [Day] from #tasks) ts
PIVOT
(
	min(task_time_min) 
	FOR  Day IN ([2024-02-01],[2024-02-02],[2024-02-04],[2024-02-05],[2024-02-06])
) AS pt




select top 10 * from etl_control.[dbo].[SSIS_Packages_audit_Log_log] order by id desc


exec useradmin.[dbo].[usp_check_agent_job_history] 'WH_PUBLISH_DWH_DATABASES'


select top 100 * from ETL_Control.dbo.WorkQueueErrorLog order by 1 desc

select top 100 * from ETL_Control.dbo.EventExecutionLog order by 1 desc



--Event FinanceDataPlatformLoad - patrz skrypt FinanceDataPlatformLoad - uruchamianie.sql