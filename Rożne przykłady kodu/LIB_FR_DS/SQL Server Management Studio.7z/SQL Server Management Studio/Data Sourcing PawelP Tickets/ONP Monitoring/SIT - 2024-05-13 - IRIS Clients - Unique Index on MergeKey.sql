


SELECT 
	 [ClientCode]
,	 [ClientName]
,	 [ApprovalStatus]
,                   [BureauCode]
,                   [BureauName]
,	 [D&BDUNSNumber]
,	 [DomicileCode]
,	 [DomicileName]
,	 [LibertyUltimateName]
,                   [NAICCode]
,                   [NAICName]
,                   [NameKeyClientFlag]
,	 [RatingCode]
,	 [RatingName]
,[PersonCompanyFlag]
,[InsuredBusinessNumber]
,	 [_MergeKey_AreaKey]
,                   [_MergeKey_ClientNameMapping]
,	 [_LastAction]
,	 [_MergeKey]
,	 [_SourceSystemCode]
FROM 
ODS_IRIS.[dbo].[Warehouse_Clients] 
 WHERE 
	 _LastAction <> 'D'
	 and _MergeKey ='[IRIS][<<UNKNOWN>>][GROSSHAUS CARL][<<UNKNOWN>>]'



select top 10 _MergeKey,* from warehouse_repository.[STAGE].[Clients_IRIS] AS t 
where _MergeKey ='[IRIS][<<UNKNOWN>>][GROSSHAUS CARL][<<UNKNOWN>>]'
	 

select top 10 [ClientKey],_MergeKey, * from [WORK].[Clients_IRIS] AS t 
where _MergeKey ='[IRIS][<<UNKNOWN>>][GROSSHAUS CARL][<<UNKNOWN>>]'


select  [ClientKey],_MergeKey, * from [WORK].[Clients_IRIS] AS t 
where _MergeKey like '%SS%'


select top 10 [ClientKey],_MergeKey, * 
from [dbo].[Clients] AS t 
where _MergeKey ='[IRIS][<<UNKNOWN>>][GROSSHAUS CARL][<<UNKNOWN>>]'

select [ClientKey],_MergeKey, * 
from [dbo].[Clients] AS t 
where _MergeKey like '[IRIS]%SS%'

select top 10 [ClientKey],*
--update c set _MergeKey='[IRIS][<<UNKNOWN>>][GRO�HAUS CARL][<<UNKNOWN>>]'
from [dbo].[Clients] c
where _MergeKey ='[IRIS][<<UNKNOWN>>][GRO�HAUS CARL_][<<UNKNOWN>>]'


select top 10 * from [WORK].[Clients_IRIS] AS t 
where _MergeKey ='[IRIS][<<UNKNOWN>>][GRO�HAUS CARL][<<UNKNOWN>>]'



use ODS_IRIS
select * from Warehouse_clients where ClientName like '%HAUS CARL%' and _SOurceSystemCode = 'IRIS'




--Merge
select * 
FROM 
 [dbo].[Clients] t 
INNER JOIN 
 WORK.[Clients_IRIS] s 
ON 
 t.[ClientKey] = s.[ClientKey] 
WHERE 
 t.[_LastAction] <> 'D' 
AND
 s.[_LastAction] = 'D'
 and s._MergeKey ='[IRIS][<<UNKNOWN>>][GRO�HAUS CARL][<<UNKNOWN>>]'





DECLARE @Result AS BIT

SELECT @Result = 1 FROM
 (SELECT TOP 1 1 FROM dbo.ClientNameMapping cpi
  INNER JOIN dbo.GetOpenEventExecutionKeys(N'Written',  N'Warehouse_Repository', 'MDS') goeek
   ON cpi._EventExecutionKey = goeek._EventExecutionKey
 ) tab(c);

SELECT COALESCE(@Result, 0)


SELECT 
	 t.[ClientKey]
,	 t.[AreaKey]
,	 t.[ApprovalStatus]
,                   t.[BureauCode]
,                   t.[BureauName]
,	 t.[ClientCode]
,	 t.[ClientName]
,	 t.[DomicileCode]
,	 t.[DomicileName]
,	 t.[D&BDUNSNumber]
,	 t.[LibertyUltimateName]
,                   t.[NAICCode]
,                   t.[NAICName]
,                   t.[NameKeyClientFlag]
,	 t.[RatingCode]
,	 t.[RatingName]
,	t.PersonCompanyFlag
,	t.InsuredBusinessNumber
,	 t.[_LastAction]
,	 t.[_MergeKey]
FROM 
[dbo].[Clients] t
	 INNER JOIN [STAGE].[Clients_IRIS] s
	 ON s._MergeKey = t._MergeKey 
	 where s._MergeKey ='[IRIS][<<UNKNOWN>>][GROSSHAUS CARL][<<UNKNOWN>>]'
	 ORDER BY 
	 t.[_MergeKey]






--Migotanie

use ODS_IRIS

SELECT-- DISTINCT 
                decl.AssuredName
            ,    decl.DomicileCode
            ,    N'<<Unknown>>' AS [D&BDUNSNumber]
            ,    decl._EventExecutionKey 
            ,    decl._SourceSystemCode
            FROM 
                dbo.Map_BusinessItems_UPIZREP decl 
            WHERE 
                decl.ItemTypeCodeKey = 'DECS'
                and  decl.AssuredName  like 'G%HAUS CARL%'