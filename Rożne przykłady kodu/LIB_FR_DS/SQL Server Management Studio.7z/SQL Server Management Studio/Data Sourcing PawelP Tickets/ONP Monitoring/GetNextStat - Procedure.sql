--dluga wersja:
use ETL_Control
 
declare @iETLServerCode NVARCHAR(50) = 'LIBERTYSERVER'
,	    @ExecutionServerName NVARCHAR(100) = 'VMBIT-GSQLDB01A'
,	    @ExecutionNodeName NVARCHAR(100) = 'NODE1'
,	    @oParameterXML XML  = ''
 
exec GetNextTask @iETLServerCode,@ExecutionServerName ,@ExecutionNodeName , @oParameterXML Output

select @oParameterXML

--exec GetNextTask 'LIBERTYSERVER', 'VMBIT-GSQLDB01A', 'NODE1', ''



USE ETL_Control;
GO
EXEC sp_recompile N'GetNextTask';
GO