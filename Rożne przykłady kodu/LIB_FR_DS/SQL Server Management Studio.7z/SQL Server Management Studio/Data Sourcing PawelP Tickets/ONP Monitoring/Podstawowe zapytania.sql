select * from [dbo].[WorkQueue] -- Kolejka

select top 10 * from [dbo].[WorkQueueLog] (nolock)  order by WorkQueueTaskKey desc -- Log z wykonania

select * from [dbo].[WorkQueueErrorLog]  (nolock)  order by WorkQueueTaskKey desc -- Log bledow

select * from [dbo].[TaskWorkQueueLog]



select TaskCode,	TaskDescription,	t.TaskGroupCode,	t.TaskTypeCode,	t.LayerCode,	t.SourceSystemCode,	ExecutableName,	ExecutionPriority,	IsBLOEMode,	IsEnabled,ConnectionBindingCode, ConnectionCode
from Tasks t
join TaskGroups tg on tg.TaskGroupCode = t.TaskGroupCode
join [TaskGroupConnections] tgc on tgc.TaskGroupCode = t.TaskGroupCode
where t.TaskCode = 'IDSMART_Checks'


select * from Events
select * from Events where EventCode='POSTDWLOADPROCESSING_2'




select * from [dbo].[TaskGroupConnections]



--Historia wykonania ONP

SELECT TOP(100)
	   [EventExecutionKey]
      ,[EventCode]
      ,[SourceSystemCode]
      ,[CDCLowerBoundary]
      ,[CDCUpperBoundary]
      ,[EventStatusCode]
      ,[ExecutionStartDate]
      ,[ExecutionEndDate]
	  , DATEDIFF(MINUTE,[ExecutionStartDate],[ExecutionEndDate]) ExecutionTime
      ,[ExecutedByUser]
      ,[ParentEventExecutionKey]
  FROM [ETL_Control].[dbo].[EventExecutionLog]
  where 1=1
  --and EventCode = 'MASTER_DWH_IBD_LOAD' --Glowny Event IBD (Startuje codziennie o godz. 20 UK)
 -- and EventCode = 'MASTER_PUBLISH_DWH_DATABASES' --Glowny Event DWH (Startuje codziennie o godz. 0.50 UK)
  --and EventCode = 'TreatyEngine' --trzeci Job ()
  --and EventCode = 'LOAD_GENIUS_Missing_RI_Policies' --Glowny Event IBD (Startuje codziennie o godz. 20 UK)
  and EventCode = 'GENIUSToDWH_DP' 
  ORDER BY [EventExecutionKey] desc


  --Sprawdzanie Taska

  
select TaskCode,	TaskDescription,	t.TaskGroupCode,	t.TaskTypeCode,	t.LayerCode,	t.SourceSystemCode,	ExecutableName,	ExecutionPriority,	IsBLOEMode,	IsEnabled,ConnectionBindingCode, ConnectionCode
--update 
from Tasks t
join TaskGroups tg on tg.TaskGroupCode = t.TaskGroupCode
join [TaskGroupConnections] tgc on tgc.TaskGroupCode = t.TaskGroupCode
where t.TaskCode like  '%GENIUStoDWH_DP%'


--Wlaczenie Taska
select TaskCode,	TaskDescription,	t.TaskGroupCode,	t.TaskTypeCode,	t.LayerCode,	t.SourceSystemCode,	ExecutableName,	ExecutionPriority,	IsBLOEMode,	IsEnabled
--update t set IsEnabled=1
from Tasks t
where t.TaskCode like  '%CBIClaim%'
and TaskCode='LOAD_GENIUS_Missing_RI_Policies'


SELECT  TaskCode, TaskDescription, t.TaskGroupCode, t.TaskTypeCode, t.LayerCode, t.SourceSystemCode, ExecutableName, ExecutionPriority, IsBLOEMode, IsEnabled, EventCode, *
  FROM [ETL_Control].[dbo].[Tasks] t
  JOIN [ETL_Control].[dbo].TaskGroups tg ON tg.TaskGroupCode = t.TaskGroupCode
  JOIN [ETL_Control].[dbo].[WorkflowConstraints] wc ON wc.PrecedentTaskGroupCode  = tg.TaskGroupCode
  WHERE t.taskcode like 'LOAD_GENIUS_Missing_RI_Policies'

select * from WorkQueue

use staging_IRIS

SELECT
LogEntryType
,OpenedByEventExecutionKey
,SourceEndPoint
,TargetEndPoint
,SourceSystemCode
into #source
FROM
staging_iris.dbo.IncrementalProcessingLog
WHERE
SourceSystemCode = 'IRIS'
AND SourceEndPoint = 'STAGING_IRIS'
AND TargetEndPoint = 'ODS_IRIS'
ORDER BY
LogEntryType
,OpenedByEventExecutionKey
,SourceEndPoint
,TargetEndPoint




SELECT
LogEntryType
,OpenedByEventExecutionKey
,SourceEndPoint
,TargetEndPoint
,SourceSystemCode
into #target
FROM
ods_IRIS.dbo.IncrementalProcessingLog
WHERE
SourceSystemCode = 'IRIS'
AND SourceEndPoint = 'STAGING_IRIS'
AND TargetEndPoint = 'ODS_IRIS'
ORDER BY
LogEntryType
,OpenedByEventExecutionKey
,SourceEndPoint
,TargetEndPoint


select * from [dbo].[_PP_ODS_Iris_IncProcLog_20230526]

select * from #source s
full outer join [dbo].[_PP_ODS_Iris_IncProcLog_20230526] t on t.SourceEndPoint = s.SourceEndPoint and t.TargetEndPoint = s.TargetEndPoint and t.SourceSystemCode = s.SourceSystemCode and t.OpenedByEventExecutionKey = s.OpenedByEventExecutionKey
where t.SourceSystemCode is  null or s.SourceSystemCode is  null



select * from #source s
full outer join #target t  on t.SourceEndPoint = s.SourceEndPoint and t.TargetEndPoint = s.TargetEndPoint and t.SourceSystemCode = s.SourceSystemCode and t.OpenedByEventExecutionKey = s.OpenedByEventExecutionKey
where t.SourceSystemCode is  null or s.SourceSystemCode is  null




use etl_control

select * from connections where connectioncode like'ODSIRIS' 


--Control_IRIS_LogValidateEndPointsStagingODS


use ETL_Control




select top (20)
DATEDIFF(minute,ExecutionStartDate,ExecutionEndDate) as TimeInMin,* 
FROM etl_control.dbo.workqueuelog (nolock) 
WHERE taskcode= 'Control_IRIS_LogValidateEndPointsStagingODS'
order by ExecutionStartDate desc


select  * from [dbo].[WorkQueue]

select top 100 * from [dbo].WorkQueueErrorLog order by WorkQueueTaskKey desc

select * from workqueue

select * from [dbo].[EventExecutionLog] order by EventExecutionKey  desc

select top 10 * from [dbo].[WorkQueueLog] order by WorkQueueTaskKey desc





--Sprawdzenie zale?no?ci

select * from ETL_Control.[dbo].[Events] where EventCode like '%GENIUStoDWH_DP%'

select * from ETL_Control.[dbo].[EventTaskGroups] where eventcode='LoadingGENIUSMissingRIPolicies_DP'

select * from ETL_Control.[dbo].[TaskGroups]

select * from ETL_Control.[dbo].[TaskGroups] where TaskGroupCode like 'LoadingGENIUSMissingRIPolicies_DP%'

select * from ETL_Control.[dbo].[Events] where EventCode like '%Genius%'

select * from ETL_Control.[dbo].[tasks] where TaskCode like '%LOAD_GENIUS_Missing_RI_Policies%'

--Wszystkie taski eventu
select * from ETL_Control.[dbo].[EventTaskGroups] etg
join ETL_Control.dbo.tasks t on t.taskgroupCode=etg.taskgroupcode
where etg.eventcode='GENIUStoDWH_DP'
and isBloeMode=1


--Czyszczenie kolejki jak proces ONP Stuck
https://libertymutual.atlassian.net/wiki/spaces/GSLITMI/pages/372574921/ETL+Controller+Events+Hanging+Stuck
-- 1. Zapami?ta? jakie taski trzeba uruchomi? po wyczyszczeniu kolejki (screenshot)

--Wyczyszczenie Kolejki
exec UserAdmin.dbo.usp_truncate_etl_work_queue

-- ustawienie NOD'a na Idle
--UPDATE [ETL_Control].[dbo].[ExecutionNodes] SET [Status] = 'Idle'

--Restart Noda 1
exec UserAdmin.[dbo].[usp_stop_executionhost_node1_sqlagent_job]

exec UserAdmin.[dbo].[usp_start_executionhost_node1_sqlagent_job]

--Sprawdzenie statusu w ETL_Contolerze

-- Dodanie do kolejki eventu ktory ma wystartowa?






--Co wchodzi w sk?ad Eventa

DECLARE @EventName NVARCHAR(50) = 'MASTER_DWH_IBD_LOAD';

select
	ev.*
	,tk.IsEnabled
	,tk.IsBLOEMode
from GetTaskDepthDesignTime(@EventName) ev
inner join Tasks tk
on ev.TaskCode = tk.TaskCode
order by TaskDepth



--Procesy czekaj?ce na pami??

select text,grant_time,granted_memory_kb,* from sys.dm_exec_query_memory_grants cross apply sys.dm_exec_sql_text(sql_handle)




--Wy?aczenie taska 

SELECT * FROM ETL_Control.[dbo].Tasks WHERE TaskCode = 'Control_LMIEIRIS_ProcessDeductionProfiles'

EXEC [ETL_Control].[dbo].[SetTaskEnabledState] @TaskCode = 'Control_LMIEIRIS_ProcessDeductionProfiles', @IsEnabled = 0, @IncidentNumber = 'INC002618080000'

SELECT * FROM ETL_Control.[dbo].Tasks WHERE TaskCode = 'Control_LMIEIRIS_ProcessDeductionProfiles'



--Restart Nod�w


EXEC UserAdmin.dbo.usp_truncate_etl_work_queue
EXEC [UserAdmin].[dbo].[usp_stop_WH_job] 'WH_Core_ExecutionHost16_Node1'
-- EXEC [UserAdmin].[dbo].[usp_stop_WH_job] 'WH_Core_ExecutionHost16_Node2'
 
select * from [ETL_Control].[dbo].[ExecutionNodes]


--UPDATE [ETL_Control].[dbo].[ExecutionNodes] SET [Status] = 'Idle'
 
EXEC [UserAdmin].[dbo].[usp_start_WH_job] 'WH_Core_ExecutionHost16_Node1'
-- EXEC [UserAdmin].[dbo].[usp_start_WH_job] 'WH_Core_ExecutionHost16_Node2'


select * from [ETL_Control].[dbo].[ExecutionNodes]


select * from [ETL_Control].[dbo].WorkQueue



--Sprawdzanie historii eventa
select * from Work