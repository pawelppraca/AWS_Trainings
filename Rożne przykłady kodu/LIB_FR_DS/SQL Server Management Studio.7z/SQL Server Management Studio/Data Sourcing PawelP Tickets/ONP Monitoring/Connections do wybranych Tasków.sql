use ETL_Control

SELECT 
ConnectionString,t.TaskCode,tgc.ConnectionCode FROM
ETL_Control.[dbo].[EventTaskGroups] etg 
LEFT JOIN ETL_Control.[dbo].TaskGroups tg ON etg.TaskGroupCode=tg.TaskGroupCode
LEFT JOIN ETL_Control.[dbo].Tasks t ON tg.TaskGroupCode = t.TaskGroupCode
LEFT JOIN [ETL_Control].[dbo].[TaskGroupConnections] tgc ON tgc.TaskGroupCode = tg.TaskGroupCode
LEFT JOIN [ETL_Control].dbo.connections c ON c.ConnectionCode=tgc.ConnectionCode
WHERE TaskCode  IN ('LOAD_GENIUS_ZHDP')
--('LOAD_IRIS_PremiumAmendmentGroups','LOAD_MDS_PremiumAmendmentGroups','EXTRACT_MDS_PremiumAmendmentGroups','EXTRACT_IRIS_PremiumAmendmentGroups')



--Connection to BI_LZ PROD
SELECT DISTINCT 
ConnectionString,tgc.ConnectionCode 
FROM
ETL_Control.[dbo].[EventTaskGroups] etg 
LEFT JOIN ETL_Control.[dbo].TaskGroups tg ON etg.TaskGroupCode=tg.TaskGroupCode
LEFT JOIN ETL_Control.[dbo].Tasks t ON tg.TaskGroupCode = t.TaskGroupCode
LEFT JOIN [ETL_Control].[dbo].[TaskGroupConnections] tgc ON tgc.TaskGroupCode = tg.TaskGroupCode
left join [ETL_Control].dbo.connections c on c.ConnectionCode=tgc.ConnectionCode
WHERE ConnectionString like 
--'%bi_lz%'
'%rds%'

--RDS SIT
Data Source=lsm-dp-rds-test.cgv2icxo5x7e.eu-west-1.rds.amazonaws.com,1433;User Id=v-token-papi-break-glass-dbowner-pH5pVPqf52OS5AQNQBz7-1716272320; Password=b3mV3o8-cSZPGPlriBx7; Initial Catalog=ODS_GENIUS;Application Name=LSMWarehouse;Provider=SQLNCLI11.1;Auto Translate=False;



Data Source=VMBIT-GSQLDB01A.lm.lmig.com;Initial Catalog=ETL_CONTROL;Provider=SQLNCLI11.1;Integrated Security=SSPI;Auto Translate=False;Application Name=LSMWarehouse;
Data Source=VMBIT-GSQLDB01A.lm.lmig.com;Initial Catalog=ODS_IRIS;Provider=SQLNCLI11.1;Integrated Security=SSPI;Auto Translate=False;Application Name=LSMWarehouse;
Data Source=VMBIT-GSQLDB01A.lm.lmig.com;Initial Catalog=Warehouse_Repository;Provider=SQLNCLI11.1;Integrated Security=SSPI;Auto Translate=False;Application Name=LSMWarehouse;

Data Source=lsm-dp-rds-production.cwxzjisfla9q.eu-west-1.rds.amazonaws.com,1433;User Id=v-token-papi-deploy-8iT5o0t9SuEgWBM8GYyZ-1718085984; Password=sv4bjs8-O7XjCpGrUDf9; Initial Catalog=ODS_GENIUS;Application Name=LSMWarehouse;Provider=SQLNCLI11.1;Auto Translate=False;


--BI_LZ PROD
Data Source=grs-datatech-bi-rds-mssql-bi-lz-prd.c5fn12wn0mtw.us-east-1.rds.amazonaws.com,1433;User Id=v-token-papi-read-only-lE8Ak76SwcmXXNSn9Rz4-1711951572; Password=zff62WFNELFW11TpgS-s; Initial Catalog=BI_LZ;Application Name=LSMWarehouse;Provider=SQLNCLI11.1;Auto Translate=False;


--RDS ODS_GENIUS PRD 
Data Source=lsm-dp-rds-production.cwxzjisfla9q.eu-west-1.rds.amazonaws.com,1433;User Id=v-token-papi-deploy-aCViXkqhXLUeVWTgE64l-1719381926; Password=Q8hyn14c-rnkdjYLVLlh; Initial Catalog=ODS_GENIUS;Application Name=LSMWarehouse;Provider=SQLNCLI11.1;Auto Translate=False;
Data Source=lsm-dp-rds-production.cwxzjisfla9q.eu-west-1.rds.amazonaws.com,1433;User Id=v-token-papi-deploy-VMT6ZFaB0dtoVhnoDnyr-1719814299; Password=ksXN71B7m-1melEjPZVl; Initial Catalog=ODS_GENIUS;Application Name=LSMWarehouse;Provider=SQLNCLI11.1;Auto Translate=False;