EXEC sys.sp_readerrorlog 0, 1, 'single_user';

--Przydzia? Pami?ci do 
select text,grant_time,granted_memory_kb,* from sys.dm_exec_query_memory_grants cross apply sys.dm_exec_sql_text(sql_handle)