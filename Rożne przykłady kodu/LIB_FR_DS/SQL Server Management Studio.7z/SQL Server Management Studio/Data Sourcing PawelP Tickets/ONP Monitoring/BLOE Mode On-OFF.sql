use etl_Control
select * from tasks where TaskCode in�
(
'FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH_DP'
)

select count(*) from Tasks where IsBLOEMode = 0� --2360
select count(*) from Tasks where IsBLOEMode = 1 --948


USE UserAdmin;

EXEC [dbo].[usp_SetBLOEModeState] 'UPDATE ETL_Control.dbo.Tasks
SET IsBLOEMode = 0
WHERE TaskCode IN (
''FACT_GENIUS_PolicyPremiumIncome_DWH_DP''
)
'
,'CHG00753625';

�
--recznie ON BLOE 
use etl_Control
select * 
--update t set IsBLOEMode = 0
from tasks t where TaskCode in�
(
'FACT_GENIUS_ClaimTransactions_DWH_DP',
'FACT_GENIUS_PolicyPremiumIncome_DWH_DP'
)

select count(*) from Tasks where IsBLOEMode = 0� --2359
select count(*) from Tasks where IsBLOEMode = 1 --949


--Wszystkie taski eventu z BLOE
select * from ETL_Control.[dbo].[EventTaskGroups] etg
join ETL_Control.dbo.tasks t on t.taskgroupCode=etg.taskgroupcode
where etg.eventcode='GENIUStoDWH_DP'
and isBloeMode=1



--Bez BLOE czas wykonania FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH_DP na SIT: 8:55 min (28.05.2024)
--Z BLOE i po optymalizacji czas wykonania na SIT: 21:13 (29.05.2024)
--BEZ  BLOE i po optymalizacji czas wykonania na SIT:  (30.05.2024)




--UAT
--Bez BLOE czas wykonania FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH_DP na UAT: 15:27 (28.05.2024)
--Z BLOE czas wykonania FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH_DP na UAT: 


use etl_Control
select count(*) from Tasks where IsBLOEMode = 0� --2370
select count(*) from Tasks where IsBLOEMode = 1 --934




--recznie ON BLOE 
use etl_Control
select IsBLOEMode, * 
--update t set IsBLOEMode = 1
from tasks t where TaskCode in�
(
--'DIMENSION_GENIUS_Covers_DWH_DP'
'DIMENSION_GENIUS_PolicyDetails_DWH_DP'
--,'DIMENSION_GENIUS_Brokers_DWH_DP'
)

use etl_Control
select count(*) from Tasks where IsBLOEMode = 0� --2369
select count(*) from Tasks where IsBLOEMode = 1  -- 935
