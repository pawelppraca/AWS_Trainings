
SELECT [EventExecutionKey]
      ,[EventCode]
      ,[SourceSystemCode]
      ,[CDCLowerBoundary]
      ,[CDCUpperBoundary]
      ,[EventStatusCode]
      ,[ExecutionStartDate]
      ,[ExecutionEndDate]
	  , DATEDIFF(MINUTE,[ExecutionStartDate],[ExecutionEndDate]) ExecutionTime
	  , substring(cast(convert(Time,Dateadd(second,DATEDIFF(second,[ExecutionStartDate],[ExecutionEndDate]) ,1)) as varchar),1,8) ExecutionTime_str
      ,[ExecutedByUser]
      ,[ParentEventExecutionKey]
  FROM [ETL_Control].[dbo].[EventExecutionLog]
  where 1=1
  --and EventCode = 'MASTER_DWH_IBD_LOAD' --Glowny Event IBD (Startuje codziennie o godz. 20 UK)
  --and EventCode = 'MASTER_PUBLISH_DWH_DATABASES' --Glowny Event DWH (Startuje codziennie o godz. 0.50 UK)
  --and EventCode = 'MASTER_GENIUS_REP' --trzeci Job ()
  --and EventCode = 'MASTER_DWH_IBD_LOAD' --Glowny Event IBD (Startuje codziennie o godz. 20 UK)
  --and EventCode = 'POSTDWLOADPROCESSING_2'
  --and EventCode = 'COREDWHPUBLISH'
  and EventCode = 'FEDERATEDDATASTORE_DWH'
  and ExecutionStartDate >='20240101'
  order by EventExecutionKey





  SELECT * FROM [ETL_Control].dbo.ONPCustomParams WHERE ProcessName = 'CheckPublishDWHPreConditions'


  	DECLARE
		@PublishDWHStatusCode AS NVARCHAR(50) = NULL,
		@PublishDWHEventCode NVARCHAR(50)	= 'MASTER_PUBLISH_DWH_DATABASES',
		@NoGoFlag INT

	-- 1. Check if not completed already (regardless the final status).
	SELECT
		--@PublishDWHStatusCode = EventStatusCode
		*
	FROM 
		[ETL_Control].dbo.EventExecutionLog 
	WHERE 
		EventCode = @PublishDWHEventCode
		AND CAST(ExecutionStartDate AS DATE) = CAST(GETDATE()-1 AS DATE) -- assuming the job is scheduled after midnight


select * from dbo.EventExecutionLog where EventCode='GENIUStoDWH_DP' order by EventExecutionKey desc
		
	SELECT 
		EventCode
		,MAX(EventExecutionKey) AS EEK
	INTO #LastEEK
	FROM 
		dbo.EventExecutionLog 
	WHERE 
		EventCode IN (SELECT DISTINCT ParamName FROM dbo.ONPCustomParams WHERE ProcessName = 'CheckPublishDWHPreConditions')
	GROUP BY EventCode
	;

	select * from #LastEEK

	SELECT 
		* --@NoGoFlag = count(9)
	FROM 
		dbo.EventExecutionLog eelog
	INNER JOIN #LastEEK lasteek
		ON eelog.EventCode = lasteek.EventCode
		AND eelog.EventExecutionKey = lasteek.EEK
	LEFT OUTER JOIN dbo.ONPCustomParams par
		ON eelog.EventCode = par.ParamName
		AND par.ProcessName = 'CheckPublishDWHPreConditions'
		AND eelog.EventStatusCode = par.ParamValue
	WHERE par.ParamValue IS NULL