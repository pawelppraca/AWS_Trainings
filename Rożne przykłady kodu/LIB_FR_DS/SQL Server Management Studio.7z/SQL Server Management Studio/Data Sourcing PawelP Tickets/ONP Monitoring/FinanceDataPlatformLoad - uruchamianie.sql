
--OD tego czy uruchomine jest task FinanceDataPlatformLoad
--kr�ty uruchamiany jest 
--MASTER_DWH_IBD_LOAD > MASTER_POST_IBD_PUBLISH_EVENTS > FinanceDataPlatformLoad
--decyduje czy w poni?szej tabelce IsEventEnabled jest  ustawione na 1

SELECT [Name], [Code], [ChangeTrackingMask], [EventName], [IsEventEnabled], [EnterDateTime], [EnterUserName], [EnterVersionNumber], [LastChgDateTime], [LastChgUserName], [LastChgVersionNumber], [ValidationStatus]
FROM [MDSDatabase].mdm.[IBDPublishStatus]


--O tym decyduj? DC + L1 Support
--Ta tabelka zasila inn? tabelk?, 

SELECT * FROM [IntegratedBusinessData].[dbo].[IBDPublishStatus]

-- Je?li tam jest na 0 to Event si? nie uruchamia