use ETL_Control
Select top 100 * from [dbo].[IDSMartChecksResults]
where CheckNumber = (Select max(CheckNumber) from [dbo].[IDSMartChecksResults])
order by 1 desc


https://libertymutual.atlassian.net/browse/LSMDATA-4861

USE ODS_IRIS
SELECT _MergeKey_ClaimLossLocationKey, * 
FROM warehouse_claims 
WHERE claimreference in ('170883/01/21/001','123520/01/17/002')


USE Warehouse_Repository
SELECT ClaimLossLocationKey,* 
FROM claims WHERE claimreference in ('170883/01/21/001','123520/01/17/002') 


Select top 100 * from [dbo].[IDSMartChecksResults]
where MergeKey = '_MergeKey_LossCountry'
order by 1 desc


select   DATEDIFF(MINUTE,[ExecutionStartDate],[ExecutionEndDate]) ExecutionTime,* 
from ETL_Control.dbo.WorkQueueLog 
where taskcode='DIMENSION_IRIS_Claims'

order by [ExecutionStartDate] desc

select top 10 * from ETL_Control.[dbo].[EventExecutionLog]



SELECT COUNT(*) AS Deviation, CAST('IDS_MART.dbo.Claims' AS NVARCHAR(255)) AS TableName, CAST('LossCountryId' AS NVARCHAR(255)) AS ColumnName, CAST('_MergeKey_LossCountry' AS NVARCHAR(255)) AS MergeKey, 1 AS AcceptableDeviation, 274 AS CheckNumber 


select LossCountryId, _MergeKey_LossCountry,_MergeKey_Policies,* 
FROM IDS_MART.dbo.Claims WHERE CAST(LossCountryId AS NVARCHAR(255)) = CAST('-1' AS NVARCHAR(255)) AND CAST(_MergeKey_LossCountry AS NVARCHAR(255)) NOT LIKE '%<<Unknown>>%' 


select * from dbo.Location where _MergeKey like '%Myanmar%' or _MergeKey like '%Virgin%'

[IRIS][Myanmar]
[IRIS][US Virgin Islands]

select * from areas 


	FROM dwh.Claims		AS c
	INNER JOIN 
	dwh.Policies pol ON c.PolicyKey = pol.PolicyKey AND pol._MergeKey in ('[IRIS][372478]','[IRIS][562822]')

select 
CAST(CASE WHEN a.AreaCode='<<Unknown>>' THEN '<<Unknown>>' ELSE  '[' + c._SourceSystemCode + ']['+ a.AreaCode + ']' END AS NVARCHAR(255)) Loc_MergeKey,
'*** Claims --> ', c.*,'*** Policies --> ', pol.*, '*** Areas --> ',a.* , loc.*

	FROM dwh.Claims		AS c
	INNER JOIN 
		dwh.ClaimDetails AS cd ON cd.ClaimDetailKey = c.ClaimDetailKey
	LEFT JOIN 
		dwh.Areas a ON c.ClaimLossLocationKey = a.AreaKey
	INNER JOIN 
		dwh.Catastrophes cat ON c.CatastropheKey = cat.CatastropheKey
	INNER JOIN 
		dwh.Policies pol ON c.PolicyKey = pol.PolicyKey AND pol._MergeKey in ('[IRIS][372478]','[IRIS][562822]')
	INNER JOIN 	
		dwh.ContractStatus cons ON cons.ContractStatusKey = pol.PolicyStatusKey 
	INNER JOIN 
		dwh.PolicyDetails pd 
	ON 
		pd.PolicyDetailKey   = pol.PolicyDetailKey 
		AND ((pd.PolicyDescriptionAdditional = '1' AND pol._SourceSystemCode ='GENIUS') OR pol._SourceSystemCode <> 'GENIUS')
	
	INNER JOIN 
		dwh.Companies com ON com.CompanyKey = pol.CompanyKey 		
	INNER JOIN
		dwh.ClaimStatus cs ON c.ClaimStatusKey = cs.ClaimStatusKey
	INNER JOIN 
		dwh.InternalEvents ie ON c.InternalEventKey = ie.InternalEventKey
	LEFT JOIN 
	(
		SELECT  
			Z1.ClaimReference
		,	Z1.Narrative
		FROM
		(
			SELECT 
				ClaimReference
			,	Narrative
			,	ROW_NUMBER() OVER(PARTITION BY ClaimReference ORDER BY NarrativeSequence DESC) AS RID
			FROM
				dwh.ClaimNarratives
			WHERE  
				Narrative LIKE 'LCN%'
		) Z1
		WHERE Z1.RID = 1 
	)z 
		ON 
			c.ClaimReference = Z.ClaimReference

	INNER JOIN 
		dwh.TrustFunds tf ON tf.TrustFundKey = c.ClaimTrustFundKey
	INNER JOIN 
		dwh.PolicyTypes polt  on polt.PolicyTypeKey = pol.PolicyTypeKey
	--LEFT JOIN
	--	cteClaimsExtract AS ce 
	--		ON ce.UniqueClaimReference = c.UniqueClaimReference 
	--		AND ce.PolicyNo = pol.UnderwriterReference 
	--		AND ce.RN = 1 
	--		AND ce._SourceSystemCode = c._SourceSystemCode 
	--LEFT JOIN cteRegion AS reg
	--ON 
	--	pol.BranchCode = reg.BranchCode

LEFT JOIN dbo.Location loc ON  loc._MergeKey = CAST(CASE WHEN a.AreaCode='<<Unknown>>' THEN '<<Unknown>>' ELSE  '[' + c._SourceSystemCode + ']['+ a.AreaCode + ']' END AS NVARCHAR(255))
--LEFT JOIN dbo.Policies pol ON y._MergeKey_Policies = pol._MergeKey
--LEFT JOIN dbo.Catastrophes cat ON y._MergeKey_Catastrophes = cat._MergeKey
LEFT JOIN stage.ExcludedPolicies expol ON pol._MergeKey = expol._MergeKey
LEFT JOIN stage.ExcludedCovers excov ON pol._MergeKey = excov._MergeKey

	WHERE 
	(
		c._SourceSystemCode = 'GENIUS' 
		OR
		(
		c._SourceSystemCode = 'LMR' AND c.[ClaimType] IN ( 'Financial', 'QS Monitoring' ) AND pd.[Source] NOT IN ('Notional Cession to GSRe (LMRe)','Notional Cession to GSRe (LSM)')
		)
		OR
		(
		polt.PolicyTypeCode <> 'AA' AND c._SourceSystemCode = 'IRIS' AND  cons.ContractStatusGroupName = 'Active'
		)
		OR 
		(
		c._SourceSystemCode IN ( 'LMIEIRIS','LMIELIBRE','LMIERUNOFF','LMIEHELMSMAN')
		)
	)	
	AND c._CurrentFlag = 1 AND pol._CurrentFlag = 1




