SELECT
ClientKey ,_MergeKey
into #Clients
FROM
dbo.Clients
WHERE _SourceSystemCode IN ('IRIS', '<<Unknown>>')



SELECT 
	 [PolicyReference]
,	 [DeclarationSequenceNumber]
,	 [AircraftTypeCode]
,	 [AircraftTypeName]
,	 [CreatedDate]
,                   [Brokerage]
,	 [ConfiscationByGovernmentOfRegistrationCode]
,	 [ConfiscationByGovernmentOfRegistrationName]
,	 [DeclarationNumber]
,	 [DomicileCode]
,	 [DomicileName]
,	 [EstimatedSignedLine]
,	 [ExpectedLossRatioPercentage]
,	 [ExpiryDate]
,	 [InceptionDate]
,                   [IconFlag]
,	 [LibertyShare]
,	 [SignedLine]
,	 [SignedOrder]
,	 [TypeOfBusinessCode]
,	 [TypeOfBusinessName]
,	 [UniqueMarketReference]
,	 [YearOfAccount]
,	 [_LastAction]
,	 [_MergeKey]
,	 [_MergeKey_Assured]
,	 [_MergeKey_ConfiscationByGovernmentOfRegistrationArea1]
,	 [_MergeKey_ConfiscationByGovernmentOfRegistrationArea2]
,	 [_MergeKey_ConfiscationByGovernmentOfRegistrationArea3]
,	 [_MergeKey_Obligor]
,	 [_MergeKey_Reassured]
,	 [_MergeKey_Currency]
,                   [_MergeKey_Areas]
,                   [_MergeKey_Underwriter]
,	 [_SourceSystemCode]
into #Warehouse_Declarations_Delta
FROM 
ODS_IRIS.[dbo].[Warehouse_Declarations_Delta]

select _MergeKey_Assured, * from #Warehouse_Declarations_Delta d
left join #Clients c on c._MergeKey = d._MergeKey_Assured
where c.ClientKey is null