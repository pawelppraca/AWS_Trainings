
--checking Errors

SELECT TOP(100)
	eel.EventExecutionKey, eel.SourceSystemCode, eel.EventStatusCode, eel.ExecutedByUser,
	eel.EventCode,
	eel.ExecutionStartDate AS EventExecutionStartDate,
	wqel.TaskCode,
	wqel.TaskStatusCode,
	wqel.ExecutionStartDate,
	wqel.ExecutionEndDate,
	wqel.ErrorInformation
FROM
	[ETL_Control].dbo.WorkQueueErrorLog wqel
JOIN 
	[ETL_Control].dbo.EventExecutionLog eel
ON 
	wqel.EventExecutionKey = eel.EventExecutionKey
WHERE 
	eel.ExecutionStartDate >= DATEADD(DAY,-5,GETDATE())
--AND	[eel].[EventCode] NOT IN (N'DWH_FKsCheck',N'IDSMART_Checks')
--AND [eel].[EventCode] IN (N'GENIUSSourceLoad', N'MASTER_GENIUSREP' )
ORDER BY eel.EventExecutionKey


 --History of the event
 
SELECT TOP(1000)
	eel.EventExecutionKey, eel.SourceSystemCode, eel.EventStatusCode, eel.ExecutedByUser,
	eel.EventCode,
	eel.ExecutionStartDate AS EventExecutionStartDate,
	wqel.TaskCode,
	wqel.TaskStatusCode,
	wqel.ExecutionStartDate,
	wqel.ExecutionEndDate,
	wqel.ErrorInformation
FROM
	[ETL_Control].dbo.EventExecutionLog eel
LEFT JOIN
	[ETL_Control].dbo.WorkQueueErrorLog wqel
ON 
	wqel.EventExecutionKey = eel.EventExecutionKey
WHERE 1=1
	AND eel.ExecutionStartDate >= dateadd(day,-5,getdate())
	AND eel.[EventCode] = 'GENIUStoDWH_DP_APAC'
ORDER BY EventExecutionStartDate




-- Check history of the job: WH_PUBLISH_DWH_DATABASES - it runs event: MASTER_PUBLISH_DWH_DATABASES


exec useradmin.[dbo].[usp_check_agent_job_history] 'WH_PUBLISH_DWH_DATABASES'


--Detailed History of the Event

SELECT [EventExecutionKey]
      ,[EventCode]
      ,[SourceSystemCode]
      ,[CDCLowerBoundary]
      ,[CDCUpperBoundary]
      ,[EventStatusCode]
      ,[ExecutionStartDate]
      ,[ExecutionEndDate]
	  , DATEDIFF(MINUTE,[ExecutionStartDate],[ExecutionEndDate]) ExecutionTime_min
	  , SUBSTRING(CAST(CONVERT(TIME,DATEADD(SECOND,DATEDIFF(SECOND,[ExecutionStartDate],[ExecutionEndDate]) ,1)) AS VARCHAR),1,8) ExecutionTime_str
      ,[ExecutedByUser]
      ,[ParentEventExecutionKey]
  FROM [ETL_Control].[dbo].[EventExecutionLog]
  WHERE 1=1
  --and EventCode = 'MASTER_DWH_IBD_LOAD' --Glowny Event IBD (Startuje codziennie o godz. 20 UK)
  --and EventCode = 'LMIELIBRE' --Glowny Event DWH (Startuje codziennie o godz. 0.50 UK)
  --and EventCode = 'MASTER_GENIUS_REP' --trzeci Job ()
  --and EventCode = 'MASTER_PUBLISH_DWH_DATABASES' --Genius LOad to DWH
  --and EventCode = 'MASTER_PUBLISH_DWH_DATABASES_APAC'
  --and EventStatusCode ='SUCCESSFUL'
  AND EventCode = 'FinanceDataPlatformLoad'
  AND ExecutionStartDate BETWEEN '20241225' AND '20250103'

  ORDER BY EventExecutionKey DESC 



  
--Active session of the server with locking,

SELECT      r.start_time [Start Time],session_ID [SPID],
            blocking_session_ID Blocking_SPID,
            DB_NAME(database_id) [Database],
            SUBSTRING(t.text,(r.statement_start_offset/2)+1,
            CASE WHEN statement_end_offset=-1 OR statement_end_offset=0 
            THEN (DATALENGTH(t.Text)-r.statement_start_offset/2)+1 
            ELSE (r.statement_end_offset-r.statement_start_offset)/2+1
            END) [Executing SQL], 
            Status,command,wait_type,wait_time,wait_resource, 
            last_wait_type
FROM        sys.dm_exec_requests r
OUTER APPLY sys.dm_exec_sql_text(sql_handle) t
WHERE       session_id != @@SPID -- don't show this query
AND         session_id > 50 -- don't show system queries
ORDER BY    SPID--r.start_time


--Locks
SELECT DISTINCT
        name AS database_name,
        session_id,
        host_name,
        login_time,
        login_name,
        reads,
        writes,
		request_mode,
		resource_type
FROM    sys.dm_exec_sessions
        LEFT OUTER JOIN sys.dm_tran_locks ON sys.dm_exec_sessions.session_id = sys.dm_tran_locks.request_session_id
        INNER JOIN sys.databases ON sys.dm_tran_locks.resource_database_id = sys.databases.database_id
WHERE   1=1
--AND resource_type <> 'DATABASE'
AND request_mode IN( 'X', 'XI','Sch-s','Sch-m')
--AND name ='Warehouse_Repository'
ORDER BY name


--Open connections to server except users
SELECT text,d.name,* 
FROM sys.sysprocesses ps
CROSS APPLY sys.dm_exec_sql_text(sql_handle)
INNER JOIN master.sys.sysdatabases d
ON ps.dbid = d.dbid
WHERE loginame NOT LIKE  'LM\n%'
ORDER BY ps.blocked DESC,ps.spid