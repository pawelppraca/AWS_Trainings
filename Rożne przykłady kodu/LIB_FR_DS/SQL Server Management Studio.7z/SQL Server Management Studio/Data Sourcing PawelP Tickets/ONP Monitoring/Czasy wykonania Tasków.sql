--Czasy wykonani task�w
USE ETL_Control


IF OBJECT_ID('tempdb..#temp') IS NOT NULL drop table #temp
IF OBJECT_ID('tempdb..#tasks') IS NOT NULL drop table #tasks

SELECT [EventExecutionKey]
      ,[EventCode]
      ,[SourceSystemCode]
      ,[EventStatusCode]
      ,[ExecutionStartDate]
      ,[ExecutionEndDate]
	  , DATEDIFF(MINUTE,[ExecutionStartDate],[ExecutionEndDate]) ExecutionTime_min
	  , substring(cast(convert(Time,Dateadd(second,DATEDIFF(second,[ExecutionStartDate],[ExecutionEndDate]) ,1)) as varchar),1,8) ExecutionTime_str
      ,[ExecutedByUser]
  INTO #temp
  FROM [ETL_Control].[dbo].[EventExecutionLog] (nolock)
  WHERE 1=1
  AND EventCode = 'LIBERTYLINKToDWH' --'GENIUStoDWH_DP'
  AND ExecutionStartDate >='20240718'
  AND EventStatusCode='SUCCESSFUL' --Tylko Wykonania OK
  --and [EventExecutionKey] = 285342 - konkretne wykoanie
  ORDER BY EventExecutionKey 



SELECT 
	  t.eventcode
	, t.ExecutionTime_min Event_Exec_Time_min
	, t.ExecutionTime_str Event_Exec_Time
	, t.EventExecutionKey
	, TaskCode
	, DATEDIFF(MINUTE,wq.[ExecutionStartDate],wq.[ExecutionEndDate]) task_time_min
	, SUBSTRING(CAST(CONVERT(TIME,DATEADD(SECOND,DATEDIFF(SECOND,wq.[ExecutionStartDate],wq.[ExecutionEndDate]) ,1)) AS VARCHAR),1,8) Task_ExecutionTime
	, wq.ExecutionStartDate
	, wq.ExecutionEndDate
INTO #tasks
FROM [ETL_Control].[dbo].[WorkQueueLog] wq (nolock)
JOIN #temp t ON t.[EventExecutionKey] = wq.EventExecutionKey
--WHERE DATEDIFF(MINUTE,wq.[ExecutionStartDate],wq.[ExecutionEndDate]) > 1 --longer than 1 min
ORDER BY t.EventExecutionKey



--select * from #tasks where taskcode='FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH_DP'


declare @columns nvarchar(max), @sql nvarchar(max)
SET @columns = N'';

SELECT @columns += N', p.' + QUOTENAME([Day])
  FROM (SELECT 
			FORMAT ([ExecutionStartDate], 'yyyy-MM-dd')[Day]
		FROM #tasks AS p GROUP BY FORMAT ([ExecutionStartDate], 'yyyy-MM-dd')
		) AS x;



SET @sql = N'
SELECT TaskCode, ' + STUFF(@columns, 1, 2, '') + '
into #report
FROM
(
   select TaskCode,Task_ExecutionTime,FORMAT ([ExecutionStartDate], ''yyyy-MM-dd'') [Day] from #tasks
) AS j
PIVOT
(
  max(Task_ExecutionTime) FOR [Day] IN ('
  + STUFF(REPLACE(@columns, ', p.[', ',['), 1, 1, '')
  + ')
) AS p;

select * from #report order by 1

';

--PRINT @sql;


EXEC sp_executesql @sql;

