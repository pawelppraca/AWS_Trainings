SELECT 
--[_LastAction] 
*
--,[_CDCDateTime]
select IAPONO, * 
FROM 
[dbo].[ILLEREP] 
where [IACOC2]=''


select distinct IAPONO
FROM 
[dbo].[ILLEREP__ct]


--3. DWH_Assembly_DB_SIT.lmig.com - vmbit-gsqldb01a

use staging_IRIS

select distinct [IACOC2] FROM Staging_IRIS.[dbo].[ILLEREP__ct] order by [IACOC2]

select distinct [IACOC2] FROM Staging_IRIS.[dbo].[ILLEREP] order by [IACOC2]




