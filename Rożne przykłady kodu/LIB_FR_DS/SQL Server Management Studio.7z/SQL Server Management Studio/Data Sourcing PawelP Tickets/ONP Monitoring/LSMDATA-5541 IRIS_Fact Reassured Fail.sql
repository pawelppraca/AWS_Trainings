
B?ad WITH IRIS LSMDATA


widok: [dbo].[Warehouse_Clients]
widok: [dbo].[Map_CompanyMaster_UCCSREP]




SELECT TOP 10 
	 [PolicyReference]
,	 [PrimaryReassuredFlag]
,	 [PolicyReassuredCount]
,	 [_MergeKey_Reassured]
,	 r.[_MergeKey]
,	 [_SourceSystemCode],c.*
FROM 
ods_iris.[dbo].[Warehouse_PolicyReassureds] r
LEFT JOIN (
	SELECT
	ClientKey
	, _MergeKey,
	ClientName
	FROM [Warehouse_Repository].dbo.Clients
	WHERE _SourceSystemCode IN (N'IRIS', N'<<Unknown>>')
) c ON c._MergeKey = r.[_MergeKey_Reassured]
WHERE C.clientkey IS NOT NULL
AND [_MergeKey_Reassured] LIKE '%REASSUR]%'
ORDER BY c.[ClientKey] DESC


[IRIS][REASSUR][LB622][G69] --not exists

[IRIS][REASSUR][ST631][V03] --exists

SELECT TOP 210 * FROM [Staging_IRIS].dbo.UCCSREP WHERE CSCSCD LIKE '%LB622%'

SELECT * FROM [ODS_IRIS].[dbo].[Map_CompanyMaster_UCCSREP] WHERE CompanyCode LIKE '%LB622%'



SELECT
	ClientKey
	, _MergeKey,
	ClientName,*
	FROM [Warehouse_Repository].dbo.Clients
	WHERE _SourceSystemCode IN (N'IRIS', N'<<Unknown>>') 
	AND ClientCode LIKE '%LB622%'


SELECT
	ClientKey
	, _MergeKey,
	ClientName,*
	FROM [Warehouse_Repository].dbo.Clients
	WHERE _SourceSystemCode IN (N'IRIS', N'<<Unknown>>') 
	AND ClientCode LIKE '%ST631%'


	[ST631]







	SELECT TOP 10 
	 [PolicyReference]
,	 [PrimaryReassuredFlag]
,	 [PolicyReassuredCount]
,	 [_MergeKey_Reassured]
,	 r.[_MergeKey]
,	 [_SourceSystemCode],c.*
FROM 
ods_iris.[dbo].[Warehouse_PolicyReassureds] r
LEFT JOIN (
	SELECT
	ClientKey
	, _MergeKey,
	ClientName
	FROM [Warehouse_Repository].dbo.Clients
	WHERE _SourceSystemCode IN (N'IRIS', N'<<Unknown>>')
) c ON c._MergeKey = r.[_MergeKey_Reassured]
--ORDER BY c.[ClientKey] desc
WHERE c.clientkey IS NULL



SELECT TOP 10 
	 [PolicyReference]
,	 [PrimaryReassuredFlag]
,	 [PolicyReassuredCount]
,	 [_MergeKey_Reassured]
,	 r.[_MergeKey]
,	 [_SourceSystemCode],c.*
FROM 
ods_iris.[dbo].[Warehouse_PolicyReassureds] r
LEFT JOIN (
	SELECT
	ClientKey
	, _MergeKey,
	ClientName
	FROM [Warehouse_Repository].dbo.Clients
	WHERE _SourceSystemCode IN (N'IRIS', N'<<Unknown>>')
) c ON c._MergeKey = r.[_MergeKey_Reassured]
WHERE C.clientkey IS NOT NULL
AND [_MergeKey_Reassured] LIKE '%REASSUR]%'
ORDER BY c.[ClientKey] DESC



SELECT TOP 210 * FROM [Staging_IRIS].dbo.UCCSREP WHERE CSCSCD LIKE '%LB622%'

SELECT * FROM [ODS_IRIS].[dbo].[Map_CompanyMaster_UCCSREP] WHERE CompanyCode LIKE '%LB622%'
SELECT * FROM [ODS_IRIS].[dbo].[Map_CompanyMaster_UCCSREP] WHERE CompanyCode LIKE '%ST631%'


SELECT TOP 210 * FROM [Staging_IRIS].dbo.UCCSREP WHERE CSCSNM LIKE '%STARR PROPERTY CASUALTY INSURANCE CHINA%'
[IRIS][441165][REASSUR][ST799][V03]   STARR PROPERTY CASUALTY INSURANCE CHINA