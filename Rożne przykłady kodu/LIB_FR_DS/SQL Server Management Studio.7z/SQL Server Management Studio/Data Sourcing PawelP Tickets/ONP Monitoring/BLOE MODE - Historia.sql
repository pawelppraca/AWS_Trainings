SELECT TOP 30 DATEDIFF(MINUTE,ExecutionStartDate,ExecutionEndDate) AS TimeInMin,CAST((ExecutionEndDate - ExecutionStartDate) AS TIME) AS [hh:mm:ss],* 
FROM etl_control.dbo.workqueuelog (NOLOCK) WHERE taskcode= 'FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH_DP'
ORDER BY ExecutionStartDate DESC