SELECT TOP (2000) 
	[id], 
	[event], 
	[computer], 
	[source], 
	[starttime], 
	[endtime], 
	[datacode], 
	[message]
  FROM [ETL_Control].[dbo].[sysssislog] 
  where --datacode <>0 AND 
  source like '%IDSMART_PlanData%'
  order by 1 DESC
  