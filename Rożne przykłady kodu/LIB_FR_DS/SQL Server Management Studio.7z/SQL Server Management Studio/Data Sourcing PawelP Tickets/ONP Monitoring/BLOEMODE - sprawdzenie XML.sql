USE ETL_Control

SELECT 
	TaskCode
	, DATEDIFF(MINUTE,wq.[ExecutionStartDate],wq.[ExecutionEndDate]) task_time_min
	, SUBSTRING(CAST(CONVERT(TIME,DATEADD(SECOND,DATEDIFF(SECOND,wq.[ExecutionStartDate],wq.[ExecutionEndDate]) ,1)) AS VARCHAR),1,8) Task_ExecutionTime
	, wq.ExecutionStartDate
	, wq.ExecutionEndDate
	,TaskXML.value('(/ParameterSet/Parameter/ParameterName)[11]','VARCHAR(100)') As ParameterName
	,TaskXML.value('(/ParameterSet/Parameter/ParameterValue)[11]','VARCHAR(100)') As BLOEMode
	,*
FROM [ETL_Control].[dbo].[WorkQueueLog] wq (nolock)
WHERE TaskCode='FACT_GENIUS_PolicyPremiumIncome_DWH_DP'
AND wq.[ExecutionStartDate] >='20240101'
AND TaskXML.value('(/ParameterSet/Parameter/ParameterValue)[11]','VARCHAR(100)')='True'
ORDER BY EventExecutionKey desc




select count(*) from Warehouse_Repository.[WORK].[PolicyPremiumTransactionsCoverage_GENIUS]


--Lista task�w z BLOE

SELECT 
	wq.[TaskCode]
	, DATEDIFF(MINUTE,wq.[ExecutionStartDate],wq.[ExecutionEndDate]) task_time_min
	, SUBSTRING(CAST(CONVERT(TIME,DATEADD(SECOND,DATEDIFF(SECOND,wq.[ExecutionStartDate],wq.[ExecutionEndDate]) ,1)) AS VARCHAR),1,8) Task_ExecutionTime
	, wq.ExecutionStartDate
	, wq.ExecutionEndDate
	,TaskXML.value('(/ParameterSet/Parameter/ParameterName)[11]','VARCHAR(100)') As ParameterName
	,TaskXML.value('(/ParameterSet/Parameter/ParameterValue)[11]','VARCHAR(100)') As BLOEMode
	,*
FROM [ETL_Control].[dbo].[WorkQueueLog] wq WITH(NOLOCK)
JOIN [dbo].[Tasks]  t WITH(NOLOCK) ON t.[TaskCode] = wq.[TaskCode]
JOIN [dbo].[TaskGroups] tg WITH(NOLOCK) ON tg.[TaskGroupCode]=t.[TaskGroupCode]
JOIN [dbo].[EventTaskGroups] etg WITH(NOLOCK) ON etg.[TaskGroupCode] = tg.[TaskGroupCode]
WHERE etg.[EventCode]='GENIUSToDWH_DP'
AND wq.[ExecutionStartDate] >='20240701'
AND TaskXML.value('(/ParameterSet/Parameter/ParameterValue)[11]','VARCHAR(100)')='True'
ORDER BY wq.[EventExecutionKey] DESC

SELECT 
	wq.[TaskCode]
	, DATEDIFF(MINUTE,wq.[ExecutionStartDate],wq.[ExecutionEndDate]) task_time_min
	, SUBSTRING(CAST(CONVERT(TIME,DATEADD(SECOND,DATEDIFF(SECOND,wq.[ExecutionStartDate],wq.[ExecutionEndDate]) ,1)) AS VARCHAR),1,8) Task_ExecutionTime
	, wq.ExecutionStartDate
	, wq.ExecutionEndDate
	,TaskXML.value('(/ParameterSet/Parameter/ParameterName)[11]','VARCHAR(100)') As ParameterName
	,TaskXML.value('(/ParameterSet/Parameter/ParameterValue)[11]','VARCHAR(100)') As BLOEMode
	,[wq].[EventExecutionKey]
	,[wq].[WorkflowReverseDependencyDepth] 
FROM [ETL_Control].[dbo].[WorkQueueLog] wq WITH(NOLOCK)
JOIN [dbo].[Tasks]  t WITH(NOLOCK) ON t.[TaskCode] = wq.[TaskCode]
JOIN [dbo].[TaskGroups] tg WITH(NOLOCK) ON tg.[TaskGroupCode]=t.[TaskGroupCode]
JOIN [dbo].[EventTaskGroups] etg WITH(NOLOCK) ON etg.[TaskGroupCode] = tg.[TaskGroupCode]
WHERE etg.[EventCode]='GENIUSToDWH_DP'
AND wq.[ExecutionStartDate] >='20240701'
AND TaskXML.value('(/ParameterSet/Parameter/ParameterName)[11]','VARCHAR(100)')='IsBLOEMode'
--AND TaskXML.value('(/ParameterSet/Parameter/ParameterValue)[11]','VARCHAR(100)')='True'
ORDER BY wq.[EventExecutionKey] DESC, [wq].[WorkflowReverseDependencyDepth] asc







DECLARE @ParentEEK INT, @EEK INT, @Event VARCHAR(100)
SET @Event = 'GENIUStoDWH_DP_APAC' 

SELECT @ParentEEK = MAX([EventExecutionKey]) FROM [dbo].[EventExecutionLog] WHERE [EventCode] = @Event
SELECT @EEK = MIN([EventExecutionKey]) FROM [dbo].[EventExecutionLog] WHERE [ParentEventExecutionKey] = @ParentEEK  --  ORDER BY [EventExecutionKey] DESC

IF @Event = 'GENIUStoDWH_DP' 
	SET @EEK = @ParentEEK

SELECT 
	wq.[TaskCode]
	, DATEDIFF(MINUTE,wq.[ExecutionStartDate],wq.[ExecutionEndDate]) task_time_min
	, SUBSTRING(CAST(CONVERT(TIME,DATEADD(SECOND,DATEDIFF(SECOND,wq.[ExecutionStartDate],wq.[ExecutionEndDate]) ,1)) AS VARCHAR),1,8) Task_ExecutionTime
	, wq.ExecutionStartDate
	, wq.ExecutionEndDate
	,TaskXML.value('(/ParameterSet/Parameter/ParameterName)[11]','VARCHAR(100)') As ParameterName
	,TaskXML.value('(/ParameterSet/Parameter/ParameterValue)[11]','VARCHAR(100)') As BLOEMode
	,[wq].[EventExecutionKey]
	,[wq].[WorkflowReverseDependencyDepth] 
FROM [ETL_Control].[dbo].[WorkQueueLog] wq WITH(NOLOCK)
LEFT JOIN [dbo].[Tasks]  t WITH(NOLOCK) ON t.[TaskCode] = wq.[TaskCode]
JOIN [dbo].[TaskGroups] tg WITH(NOLOCK) ON tg.[TaskGroupCode]=t.[TaskGroupCode]
JOIN [dbo].[EventTaskGroups] etg WITH(NOLOCK) ON etg.[TaskGroupCode] = tg.[TaskGroupCode]
WHERE etg.[EventCode] = 'GENIUSToDWH_DP'
AND wq.[EventExecutionKey] = @EEK
AND TaskXML.value('(/ParameterSet/Parameter/ParameterName)[11]','VARCHAR(100)')='IsBLOEMode'
AND TaskXML.value('(/ParameterSet/Parameter/ParameterValue)[11]','VARCHAR(100)')='True'
ORDER BY wq.[EventExecutionKey] DESC, [wq].[WorkflowReverseDependencyDepth] ASC
