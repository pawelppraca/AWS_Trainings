-- Sprawdzenie b?ed�w ONP


SELECT TOP 100
	eel.EventExecutionKey, eel.SourceSystemCode, eel.EventStatusCode, eel.ExecutedByUser,
	eel.EventCode,
	eel.ExecutionStartDate AS EventExecutionStartDate,
	wqel.TaskCode,
	wqel.TaskStatusCode,
	wqel.ExecutionStartDate,
	wqel.ExecutionEndDate,
	wqel.ErrorInformation
FROM
	[ETL_Control].dbo.WorkQueueErrorLog wqel
JOIN 
	[ETL_Control].dbo.EventExecutionLog eel
ON 
	wqel.EventExecutionKey = eel.EventExecutionKey
WHERE 
	eel.ExecutionStartDate >= DATEADD(DAY,-5,GETDATE())
AND
	[eel].[EventCode] NOT IN (N'DWH_FKsCheck',N'IDSMART_Checks')
AND 
	[eel].[EventCode] IN (N'GENIUSSourceLoad', N'MASTER_GENIUSREP' )
    


	  Task Failure The first part of the error information follows:  SSIS Error Code DTS_E_OLEDBERROR.  An OLE DB error has occurred. Error code: 0x80004005.  An OLE DB record is available.  Source: "Microsoft SQL Server Native Client 11.0"  Hresult: 0x80004005  Description: "Communication link failure".  An OLE DB record is available.  Source: "Microsoft SQL Server Native Client 11.0"  Hresult: 0x80004005  Description: "TCP Provider: An existing connection was forcibly closed by the remote host.  ".   "Read From Change Table" failed validation and returned validation status "VS_ISBROKEN".   One or more component failed validation.   There were errors during task validation.  

-- Sprawdzenie historii JOBA Publish


EXEC useradmin.[dbo].[usp_check_agent_job_history] 'WH_PUBLISH_DWH_DATABASES'


--Sprawdzenie IDSMART_DataCheck

 SELECT * FROM ETL_Control.dbo.IDSMartChecksResults WHERE CheckNumber = 255

 SELECT * FROM ETL_Control.dbo.IDSMartChecksResults WHERE CheckNumber = 255 AND Deviation > AcceptableDeviation



 SELECT COUNT(*) AS Deviation, CAST('IDS_MART.dbo.Claims' AS NVARCHAR(255)) AS TableName, CAST('LossCountryId' AS NVARCHAR(255)) AS ColumnName, CAST('_MergeKey_LossCountry' AS NVARCHAR(255)) AS MergeKey, 1 AS AcceptableDeviation, 255 AS CheckNumber FROM IDS_MART.dbo.Claims WHERE CAST(LossCountryId AS NVARCHAR(255)) = CAST('-1' AS NVARCHAR(255)) AND CAST(_MergeKey_LossCountry AS NVARCHAR(255)) NOT LIKE '%<<Unknown>>%' 



 --Sprawdzenie przeprocesowania si? Eventa
 
SELECT TOP 1000
	eel.EventExecutionKey, eel.SourceSystemCode, eel.EventStatusCode, eel.ExecutedByUser,
	eel.EventCode,
	eel.ExecutionStartDate AS EventExecutionStartDate,
	wqel.TaskCode,
	wqel.TaskStatusCode,
	wqel.ExecutionStartDate,
	wqel.ExecutionEndDate,
	wqel.ErrorInformation
FROM
	[ETL_Control].dbo.EventExecutionLog eel
LEFT JOIN
	[ETL_Control].dbo.WorkQueueErrorLog wqel
ON 
	wqel.EventExecutionKey = eel.EventExecutionKey
WHERE 1=1
and eel.ExecutionStartDate >= dateadd(day,-5,getdate())
ORDER BY EventExecutionStartDate

