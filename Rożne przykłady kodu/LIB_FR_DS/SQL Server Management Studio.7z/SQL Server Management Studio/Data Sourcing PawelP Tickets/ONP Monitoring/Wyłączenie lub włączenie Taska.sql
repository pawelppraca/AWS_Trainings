

--Wy?aczenie taska 

SELECT * FROM ETL_Control.[dbo].Tasks WHERE TaskCode = 'Control_LMIEIRIS_ProcessDeductionProfiles'

EXEC [ETL_Control].[dbo].[SetTaskEnabledState] @TaskCode = 'Control_LMIEIRIS_ProcessDeductionProfiles', @IsEnabled = 0, @IncidentNumber = 'INC002618080000'

SELECT * FROM ETL_Control.[dbo].Tasks WHERE TaskCode = 'Control_LMIEIRIS_ProcessDeductionProfiles'