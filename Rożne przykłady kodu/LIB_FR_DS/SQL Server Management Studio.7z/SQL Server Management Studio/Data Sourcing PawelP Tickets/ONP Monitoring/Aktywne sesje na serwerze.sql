


USE master

�
select text,d.name,* from sys.sysprocesses ps
cross apply sys.dm_exec_sql_text(sql_handle)
inner join master.sys.sysdatabases d
on ps.dbid = d.dbid
--where d.name ='ODS_GENIUS'
order by ps.blocked DESC,ps.spid


--Aktywne sesje na serwerze z Blokowanie,
SELECT      r.start_time [Start Time],session_ID [SPID],
            blocking_session_ID Blocking_SPID,
            DB_NAME(database_id) [Database],
            SUBSTRING(t.text,(r.statement_start_offset/2)+1,
            CASE WHEN statement_end_offset=-1 OR statement_end_offset=0 
            THEN (DATALENGTH(t.Text)-r.statement_start_offset/2)+1 
            ELSE (r.statement_end_offset-r.statement_start_offset)/2+1
            END) [Executing SQL], 
            Status,command,wait_type,wait_time,wait_resource, 
            last_wait_type
FROM        sys.dm_exec_requests r
OUTER APPLY sys.dm_exec_sql_text(sql_handle) t
WHERE       session_id != @@SPID -- don't show this query
AND         session_id > 50 -- don't show system queries
ORDER BY    SPID--r.start_time


--locki
SELECT DISTINCT
        name AS database_name,
        session_id,
        host_name,
        login_time,
        login_name,
        reads,
        writes,
		request_mode,
		resource_type
FROM    sys.dm_exec_sessions
        LEFT OUTER JOIN sys.dm_tran_locks ON sys.dm_exec_sessions.session_id = sys.dm_tran_locks.request_session_id
        INNER JOIN sys.databases ON sys.dm_tran_locks.resource_database_id = sys.databases.database_id
WHERE   1=1
--AND resource_type <> 'DATABASE'
AND request_mode IN( 'X', 'XI','Sch-s','Sch-m')
--AND name ='Warehouse_Repository'
ORDER BY name


--Przydzia?y pami?ci
SELECT text,* FROM sys.dm_exec_query_memory_grants CROSS APPLY sys.dm_exec_sql_text(sql_handle)
ORDER BY grant_time DESC


--Otwarte po??czenia do serwera z pomini?ciem user�w
SELECT text,d.name,* 
FROM sys.sysprocesses ps
CROSS APPLY sys.dm_exec_sql_text(sql_handle)
INNER JOIN master.sys.sysdatabases d
ON ps.dbid = d.dbid
WHERE loginame NOT LIKE  'LM\n%'
ORDER BY ps.blocked DESC,ps.spid


pozostale:
EXEC sp_who2
 
-----------------------
USE UserAdmin 
--EXEC Useradmin.[dbo].[sp_WhoIsActive]
 
------------------------------
 
USE UserAdmin
--EXEC usp_kill_WH_spid 93


SELECT * FROM [CandidateTaskGroupsForExecution]


SELECT * FROM ETL_Control.dbo.WorkQueue ORDER BY WorkQueueTaskKey DESC


SELECT conn.session_id, host_name, program_name,     nt_domain, login_name, connect_time, last_request_end_time 
FROM sys.dm_exec_sessions AS sess
JOIN sys.dm_exec_connections AS conn
ON sess.session_id = conn.session_id;


--Procesy na Serwerze 
select text,d.name,* from sys.sysprocesses ps
cross apply sys.dm_exec_sql_text(sql_handle)
inner join master.sys.sysdatabases d
on ps.dbid = d.dbid
WHERE loginame NOT LIKE  'LM\n%'
ORDER by ps.blocked DESC,ps.spid


select * from [dbo].[ExecutionNodes]


--Reset Eventu r?cznie na bazie ETL_Control

exec dbo.UpdateEventStatus 'RESET' , 309085



--R?czne wy?aczenie Taska

EXEC [ETL_Control].[dbo].[SetTaskEnabledState] @TaskCode = 'Control_LMIEIRIS_ProcessDeductionProfiles', @IsEnabled = 0, @IncidentNumber = 'INC002618080000'
 
--Sprawdzenie czy Task 
SELECT * FROM ETL_Control.[dbo].Tasks WHERE TaskCode = 'Control_LMIEIRIS_ProcessDeductionProfiles'




--Restart Nod�w


EXEC UserAdmin.dbo.usp_truncate_etl_work_queue
EXEC [UserAdmin].[dbo].[usp_stop_WH_job] 'WH_Core_ExecutionHost16_Node1'
-- EXEC [UserAdmin].[dbo].[usp_stop_WH_job] 'WH_Core_ExecutionHost16_Node2'
 
select * from [ETL_Control].[dbo].[ExecutionNodes]


UPDATE [ETL_Control].[dbo].[ExecutionNodes] SET [Status] = 'Idle'
 
EXEC [UserAdmin].[dbo].[usp_start_WH_job] 'WH_Core_ExecutionHost16_Node1'
-- EXEC [UserAdmin].[dbo].[usp_start_WH_job] 'WH_Core_ExecutionHost16_Node2'


select * from [ETL_Control].[dbo].[ExecutionNodes]


select * from [ETL_Control].[dbo].WorkQueue