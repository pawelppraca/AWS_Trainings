
--UAT lub PROD

use Warehouse_Repository

--pokazuje te kt�re moga by? czyli ilo?c b?ed�w kt�ra jest akceptowalna
select * from FksCheckParameters where AcceptableDeviation>0

select * from FksCheckResults ORDER BY TableName, ForeignKeyName

SELECT ForeignKeyName, [DateCreated], COUNT(*) FROM FksCheckResults  GROUP BY [DateCreated],ForeignKeyName ORDER BY [DateCreated],ForeignKeyName 


/*

DWHChecksResultsKey	SourceSystemCode	TableName	ForeignKeyName	MergeKey	DateCreated
602	GENIUS	CoverLines	CoverKey	[GENIUS][811013390701T1][ACV3O4][001][99][GEST0214][01]	2024-05-30 22:10:30.4100000
531	GENIUS	CoverLines	CoverKey	[GENIUS][811012756203T1][ACV3FC][001][99][GEST0214][01]	2024-05-29 22:10:25.4300000
102	GENIUS	Policies	AreaKey	[GENIUS][113513][001][10][020]	2024-05-24 14:22:45.1433333
532	GENIUS	Policies	BrokerKey	[GENIUS][ACV3O1][001][10][001]	2024-05-30 22:08:32.8100000
533	GENIUS	Policies	BrokerKey	[GENIUS][ACV3O1][001][10][002]	2024-05-30 22:08:32.8100000
534	GENIUS	Policies	BrokerKey	[GENIUS][ACV3O1][001][10][003]	2024-05-30 22:08:32.8100000
535	GENIUS	Policies	BrokerKey	[GENIUS][ACV3O1][001][10][004]	2024-05-30 22:08:32.8100000
539	GENIUS	Policies	PolicyDetailKey	[GENIUS][ACV3N3][001][10][001]	2024-05-30 22:08:32.9200000
540	GENIUS	Policies	PolicyDetailKey	[GENIUS][ACV3N3][001][10][002]	2024-05-30 22:08:32.9200000
541	GENIUS	Policies	PolicyDetailKey	[GENIUS][ACV3N4][001][10][001]	2024-05-30 22:08:32.9200000
542	GENIUS	Policies	PolicyDetailKey	[GENIUS][ACV3N4][001][10][002]	2024-05-30 22:08:32.9200000
543	GENIUS	Policies	PolicyDetailKey	[GENIUS][ACV3N7][001][10][001]	2024-05-30 22:08:32.9200000
544	GENIUS	Policies	PolicyDetailKey	[GENIUS][ACV3N7][001][10][002]	2024-05-30 22:08:32.9200000

*/

--Sprawdzamy w tabeli na WR

select coverkey,* from Warehouse_Repository.dbo.coverlines where _mergekey in (
'[GENIUS][811013390701T1][ACV3O4][001][99][GEST0214][01]',
'[GENIUS][811012756203T1][ACV3FC][001][99][GEST0214][01]'
)

--Sa dwa rekordy, ale w kolumnie CoverKey maja warto?? -1 (brakuje im klucza do Covers)
/*
CoverLineKey	CoverReference	CoverKey	LineNumber	BadAgedDebtKey	BrokerKey	MajorParticipationKey	OriginalCurrencyKey	ReinsurerKey	ReinsurerLinePercentage	ReinsurerParticipationPercentage	ReinsurerLineContractMinimumPremiumOriginalCurrency	ReinsurerLineContractDepositPremiumOriginalCurrency	ReinsurerLine100CededPremiumOriginalCurrency	ReinsurerLineLSMMinimumPremiumOriginalCurrency	ReinsurerLineLSMDepositPremiumOriginalCurrency	ReinsurerLineLSM100CededPremiumOriginalCurrency	_CurrentFlag	_EffectiveFrom	_EffectiveTo	_EventExecutionKey	_LastAction	_MergeKey	_SequenceNumber	_SourceSystemCode
625061	811012756203T1	-1	1	-1	82161	4264036	-1	4264036	100.0000000	100.0000000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	1	2024-05-29 21:25:00.0000000	9999-12-31 00:00:00.0000000	288480	U	[GENIUS][811012756203T1][ACV3FC][001][99][GEST0214][01]	1	GENIUS
625062	811013390701T1	-1	1	-1	82161	4264036	-1	4264036	100.0000000	100.0000000	0.0000	0.0000	0.0000	0.0000	0.0000	0.0000	1	2024-05-30 21:25:00.0000000	9999-12-31 00:00:00.0000000	288480	U	[GENIUS][811013390701T1][ACV3O4][001][99][GEST0214][01]	1	GENIUS
*/

--Sprawdzamy czy w ?r�dle czyli w widoku Warehouse_CoverLines na RDS (UAT) s? te rekordy  i jakie maj? klucze w kolumnie _MergeKey_CoverKey 

select distinct _MergeKey_CoverKey from warehouse_coverlines where _mergekey in (
'[GENIUS][811013390701T1][ACV3O4][001][99][GEST0214][01]',
'[GENIUS][811012756203T1][ACV3FC][001][99][GEST0214][01]'
)

--Sprawdzamy na RDS czy s? w widoku Warehouse_Covers rekordy z takimi kluczami w MergeKey

select * from Warehouse_Covers where _MergeKey in (
'[GENIUS][ACV3O4][001][99]'
,'[GENIUS][ACV3FC][001][99]'
)

--je?li s? to upewniamy si? czy s? w Covers na WR (powinno ich nie by?)

select * from Warehouse_Repository.dbo.Covers where _MergeKey in (
'[GENIUS][ACV3O4][001][99]'
,'[GENIUS][ACV3FC][001][99]'
)
--Rekordy Istniej?
--  To wymaga BLOE na COVERS

-- Je?li ich nie ma to trzeba sprawdzi? w tabelach z kt�rych korzysta widok Warehouse_Covers i przeanalizowa? czy widok tego nie wycina


--BROKERS
-----------------------------

select BrokerKey,* from Warehouse_Repository.dbo.Policies where _mergekey in (
'[GENIUS][ACV3O1][001][10][001]'
,'[GENIUS][ACV3O1][001][10][002]'
,'[GENIUS][ACV3O1][001][10][003]'
,'[GENIUS][ACV3O1][001][10][004]'
)

--2 Rekord�w z czego kazdy ma w BrokerKey -1
/*

BrokerKey	PolicyKey	PolicyReference	10USSEShrs	AdminClaimFlag	AdminPremFlag	ADRListing	AreaKey	ActualUnderlyingRateChange	BondType	BondTypeDescription	BondForm	BoundDateKey	BrokerKey	BurnAttachment	CancellationDateKey	ClaimAttachmentBasisName	ClaimAttachmentBasisCode	ClassAccumulatorKey	ClassKey	ClassUnderwriterKey	CombinedRatio	CombinedPolicyFlag	CompanyKey	ContractRetention	DateOfFirstShowKey	DeductionProfileSetKey	DefenceCost	DepartmentCode	DepartmentName	DistributionChannel	EEAPercentageFlag	EnteredSyndicateKey	ExpiryDateKey	ExternalExpenseRatio	FILCodeKey	InceptionDateKey	InceptionDateOriginalKey	IndustryCode	IndustryName	IndustryMinorCode	IndustryMinorName	LayerSubtype	LegalEntityName	LeadInsurerPolicyNo	LineOfBusinessCode	LineOfBusinessName	MaintenanceStartDate	MaintenanceEndDate	MotorPolicyDetailKey	ObligorKey	OccupancyKey	OriginalAssuredKey	PerilKey	PolicyDetailKey	PolicyEntryDateKey	PolicyJunkDetailKey	PolicyStatusChangeDateKey	PolicyStatusCurrentKey	PolicyStatusKey	PolicyTypeKey	PrimaryCurrencyKey	ProfitOrg	ProfitOrgShortDescription	ProfitOrgLongDescription	RealisticDisasterScenarioKey	RegionCode	RegionName	RetailOrManagingBrokerKey	RiskCodeSplitProfileKey	SectionDetailTitle	SectionTitle	SectionType	SectionDetailValue1	SectionDetailValue2	SectionDetailValue3	SectionDetailValue4	SectionDetailValue5	SectionDetailValue6	SectionDetailDate1	SectionDetailDate2	SettlementDueDateKey	SubSyndicateKey	SyndicateKey	UnderwriterKey	WrittenDateKey	BrokerContact	BranchCode	OriginalBranch	CalculatedRateOnLinePercentage	DeclinedToRenewCode	DeclinedToRenewFlag	DeclinedToRenewName	EnteredBrokerageOnGrossPercentage	EnteredRateOnLinePercentage	EnteredUpfrontDeductionsPercentage	EstimatedSignedPercentage	ExposureGrowth	InwardsOutwardsCode	InwardsOutwardsName	LMReEquitytoPremium	LMReROE	LSMEquitytoPremium	LSMROE	ModifiedTechnicalLossRatio	NewOrRenewalName	PolicyNumber	PolicySequence	PolicyYearOfAccount	PrivateEquity	ProducerCode	ProducerName	ProjectedRenewalPremium	ProjectedRenewalPremiumIncrease	RateMonitoringEntryCompleteCode	RateMonitoringEntryCompleteName	RateMonitoringExclusionCode	RateMonitoringExclusionName	RateMonitoringPureRateChangeRatio	ReinsuranceOrDirectCode	ReinsuranceOrDirectName	ReinsuranceRateChange	ReinsurerMarginPercentage	RenewalChainId	RenewalChainSequenceNumber	RenewalStatusCode	RenewalStatusName	ReportingYearOfAccount	RestructuredLayerIndicator	RiskCode	ShareChange	SideAOnly	SideCOnly	SignedDownPercentage	SignedLine	SignedOrder	SignedPercentage	StampCode	StructureChange	TechnicalLossRatio	TotalDeductionsPercent	TotalCommissionsPercent	TotalPremiumReductionsPercent	UnderwriterReference	UnderlyingRateChange	WrittenLine	WrittenOrder	WrittenPercentage	FinancialLoss	ProducingOfficeCode	ZUSSectionDeleted	OwnershipType	EndorsementTypeCode	EndorsementTypeDescription	_CurrentFlag	_EffectiveFrom	_EffectiveTo	_EventExecutionKey	_LastAction	_MergeKey	_MergeKey_Brokers	_MergeKey_RetailOrManagingBrokers	_SequenceNumber	_SourceSystemCode
-1	12358005	8110135035-01	<<Unknown>>	N	N	<<Unknown>>	121940	NULL	N027	Miscellaneous	N	1900-01-01	-1	<<Unknown>>	1900-01-01	NULL	NULL	[GENIUS][2229][EFE][N000][NEW YORK][2023]	15088	-1	NULL	N	304	NULL	1900-01-01	<<Unknown>>                       	<<Unknown>>	EFE	ONN - Power Generation	LMIC	NULL	-1	2024-10-01	NULL	-1	2023-10-01	2023-10-01	N000	Power Generation	N027	Miscellaneous	NULL	LIUI - USA	<<Unknown>>	2229	POWER GENERATION	NULL	NULL	-1	-1	70303	-1	-1	-1	2024-05-29	998087	1900-01-01	157	157	180	1426	<<Unknown>>	<<Unknown>>	<<Unknown>>	-1	North America	North America	-1	<<Unknown>>                       	US - FL Cantonment	Onshore Energy	ONE						U	NULL	NULL	1900-01-01	-1	-1	15234	2024-05-29	TU	NEW YORK	<<Unknown>>	NULL	<<Unknown>>	<<Unknown>>	<<Unknown>>	NULL	NULL	NULL	100.0000000	NULL	I	Inwards	NULL	NULL	NULL	NULL	NULL	New Business	ACV3O1	1	2023	<<Unknown>>	TEST2192	TEST, BROKER	NULL	NULL	<<Unknown>>	<<Unknown>>	<<Unknown>>	<<Unknown>>	NULL	D	Direct	NULL	NULL	[GENIUS][ACV3O1]	1	<<Unknown>>	<<Unknown>>	2023	NULL	<<Unknown>>	NULL	<<Unknown>>	No	-2.5000000	82.0000000	100.0000000	82.0000000	<<Unknown>>	NULL	NULL	NULL	NULL	NULL	8110135035-01	NULL	80.0000000	100.0000000	80.0000000	<<Unknown>>	NULL	0	<<Unknown>>	INC	INCEPTION	0	2024-05-30 21:25:00.0000000	2024-05-31 13:25:59.9990000	288480	U	[GENIUS][ACV3O1][001][10][001]	[GENIUS][MARS4292]	<<Unknown>>	1	GENIUS
-1	12360795	8110135035-01	<<Unknown>>	N	N	<<Unknown>>	121940	NULL	N027	Miscellaneous	N	1900-01-01	-1	<<Unknown>>	1900-01-01	NULL	NULL	[GENIUS][2229][EFE][N000][NEW YORK][2023]	15088	-1	NULL	N	304	NULL	1900-01-01	<<Unknown>>                       	<<Unknown>>	EFE	ONN - Power Generation	LMIC	NULL	-1	2024-10-01	NULL	-1	2023-10-01	2023-10-01	N000	Power Generation	N027	Miscellaneous	NULL	LIUI - USA	<<Unknown>>	2229	POWER GENERATION	NULL	NULL	-1	-1	70303	-1	-1	-1	2024-05-29	998087	1900-01-01	157	157	180	1426	<<Unknown>>	<<Unknown>>	<<Unknown>>	-1	North America	North America	-1	<<Unknown>>                       	US - FL Cantonment	Onshore Energy	ONE						U	NULL	NULL	1900-01-01	-1	-1	15234	2024-05-29	TU	NEW YORK	<<Unknown>>	NULL	<<Unknown>>	<<Unknown>>	<<Unknown>>	NULL	NULL	NULL	100.0000000	NULL	I	Inwards	NULL	NULL	NULL	NULL	NULL	New Business	ACV3O1	1	2023	<<Unknown>>	TEST2192	TEST, BROKER	NULL	NULL	<<Unknown>>	<<Unknown>>	<<Unknown>>	<<Unknown>>	NULL	D	Direct	NULL	NULL	[GENIUS][ACV3O1]	1	<<Unknown>>	<<Unknown>>	2023	NULL	<<Unknown>>	NULL	<<Unknown>>	No	-2.5000000	82.0000000	100.0000000	82.0000000	<<Unknown>>	NULL	NULL	NULL	NULL	NULL	8110135035-01	NULL	80.0000000	100.0000000	80.0000000	<<Unknown>>	NULL	0	<<Unknown>>	INC	INCEPTION	0	2024-06-02 13:23:00.0000000	2024-06-02 20:28:59.9990000	288480	U	[GENIUS][ACV3O1][001][10][001]	[GENIUS][MARS4292]	<<Unknown>>	3	GENIUS
-1	12358008	8110135035-01	<<Unknown>>	N	N	<<Unknown>>	124214	NULL	N027	Miscellaneous	N	1900-01-01	-1	<<Unknown>>	1900-01-01	NULL	NULL	[GENIUS][2229][EFE][N000][NEW YORK][2023]	15088	-1	NULL	N	304	NULL	1900-01-01	<<Unknown>>                       	<<Unknown>>	EFE	ONN - Power Generation	LMIC	NULL	-1	2024-10-01	NULL	-1	2023-10-01	2023-10-01	N000	Power Generation	N027	Miscellaneous	NULL	LIUI - USA	<<Unknown>>	2229	POWER GENERATION	NULL	NULL	-1	-1	70303	-1	-1	-1	2024-05-29	998087	1900-01-01	157	157	180	1426	<<Unknown>>	<<Unknown>>	<<Unknown>>	-1	North America	North America	-1	<<Unknown>>                       	US - West Virginia	Onshore Energy	ONE						U	NULL	NULL	1900-01-01	-1	-1	15234	2024-05-29	TU	NEW YORK	<<Unknown>>	NULL	<<Unknown>>	<<Unknown>>	<<Unknown>>	NULL	NULL	NULL	100.0000000	NULL	I	Inwards	NULL	NULL	NULL	NULL	NULL	New Business	ACV3O1	1	2023	<<Unknown>>	TEST2192	TEST, BROKER	NULL	NULL	<<Unknown>>	<<Unknown>>	<<Unknown>>	<<Unknown>>	NULL	D	Direct	NULL	NULL	[GENIUS][ACV3O1]	1	<<Unknown>>	<<Unknown>>	2023	NULL	<<Unknown>>	NULL	<<Unknown>>	No	-2.5000000	82.0000000	100.0000000	82.0000000	<<Unknown>>	NULL	NULL	NULL	NULL	NULL	8110135035-01	NULL	80.0000000	100.0000000	80.0000000	<<Unknown>>	NULL	0	<<Unknown>>	INC	INCEPTION	0	2024-05-30 21:25:00.0000000	2024-05-31 13:25:59.9990000	288480	U	[GENIUS][ACV3O1][001][10][004]	[GENIUS][MARS4292]	<<Unknown>>	1	GENIUS

*/

-- na UAT RDS szukamy czy te rekordy istineja i maja Broker_Key

select distinct _MergeKey_BrokerKey from Warehouse_Policies where _MergeKey in (
'[GENIUS][ACV3O1][001][10][001]'
,'[GENIUS][ACV3O1][001][10][002]'
,'[GENIUS][ACV3O1][001][10][003]'
,'[GENIUS][ACV3O1][001][10][004]'
)

--Wynik
-- [GENIUS][MARS4292]

--RDS UAT - spprawdzamy czy w widoku Brokers istnieje taki rekord
select * from Warehouse_Brokers where _MergeKey in (
'[GENIUS][MARS4292]'
)

/*

AddressLineOne	AddressLineTwo	AddressLineThree	AddressLineFour	AddressLineFive	BrokerCity	BrokerCode	BrokerCodeUnconformed	BrokerName	BrokerNumber	BrokerState	PostCode	_CDCDateTime	_EventExecutionKey	_LastAction	_MergeKey	_MergeKey_AreaKey	_SourceSystemCode
1502 London Road, Suite 210	Duluth, MN  55812				<<Unknown>>	MARS4292	[GENIUS][MARS4292]	MARSH & MC ALB-CH-MN	0	<<Unknown>>	55812	2024-05-29 22:18:15.0000000	288288	I	[GENIUS][MARS4292]	[GENIUS][U22]	GENIUS

*/

--Jesli istnieje w widoku Warehouse Brokers - trzeba prze?adowa? tabel? Brokers w BLOE
--Je?li nie istnieje - spawdzi? widok i tabele ?r�d?owe dlaczego to wycina i czy sa w tabelach ZU...

--Areas

--Sprawdzamy w tabeli na WR

select AreaKey,* from Warehouse_Repository.dbo.Policies where _mergekey in (
'[GENIUS][113513][001][10][020]'
)


--Sa dwa rekordy, ale w kolumnie AreaKey maja wartosc -1 (brakuje im klucza do Areas)
/*
AreaKey	PolicyKey	PolicyReference	10USSEShrs	AdminClaimFlag	AdminPremFlag	ADRListing	AreaKey	ActualUnderlyingRateChange	BondType	BondTypeDescription	BondForm	BoundDateKey	BrokerKey	BurnAttachment	CancellationDateKey	ClaimAttachmentBasisName	ClaimAttachmentBasisCode	ClassAccumulatorKey	ClassKey	ClassUnderwriterKey	CombinedRatio	CombinedPolicyFlag	CompanyKey	ContractRetention	DateOfFirstShowKey	DeductionProfileSetKey	DefenceCost	DepartmentCode	DepartmentName	DistributionChannel	EEAPercentageFlag	EnteredSyndicateKey	ExpiryDateKey	ExternalExpenseRatio	FILCodeKey	InceptionDateKey	InceptionDateOriginalKey	IndustryCode	IndustryName	IndustryMinorCode	IndustryMinorName	LayerSubtype	LeadInsurerPolicyNo	LegalEntityName	LineOfBusinessCode	LineOfBusinessName	MaintenanceStartDate	MaintenanceEndDate	MotorPolicyDetailKey	ObligorKey	OccupancyKey	OriginalAssuredKey	PerilKey	PolicyDetailKey	PolicyEntryDateKey	PolicyJunkDetailKey	PolicyStatusChangeDateKey	PolicyStatusCurrentKey	PolicyStatusKey	PolicyTypeKey	PrimaryCurrencyKey	ProducingOfficeCode	ProfitOrg	ProfitOrgShortDescription	ProfitOrgLongDescription	RealisticDisasterScenarioKey	RegionCode	RegionName	RetailOrManagingBrokerKey	RiskCodeSplitProfileKey	SectionDetailTitle	SectionTitle	SectionType	SectionDetailValue1	SectionDetailValue2	SectionDetailValue3	SectionDetailValue4	SectionDetailValue5	SectionDetailValue6	SectionDetailDate1	SectionDetailDate2	SettlementDueDateKey	SubSyndicateKey	SyndicateKey	UnderwriterKey	WrittenDateKey	BrokerContact	BranchCode	OriginalBranch	CalculatedRateOnLinePercentage	DeclinedToRenewCode	DeclinedToRenewFlag	DeclinedToRenewName	EnteredBrokerageOnGrossPercentage	EnteredRateOnLinePercentage	EnteredUpfrontDeductionsPercentage	EstimatedSignedPercentage	ExposureGrowth	InwardsOutwardsCode	InwardsOutwardsName	LMReEquitytoPremium	LMReROE	LSMEquitytoPremium	LSMROE	ModifiedTechnicalLossRatio	NewOrRenewalName	PolicyNumber	PolicySequence	PolicyYearOfAccount	PrivateEquity	ProducerCode	ProducerName	ProjectedRenewalPremium	ProjectedRenewalPremiumIncrease	RateMonitoringEntryCompleteCode	RateMonitoringEntryCompleteName	RateMonitoringExclusionCode	RateMonitoringExclusionName	RateMonitoringPureRateChangeRatio	ReinsuranceOrDirectCode	ReinsuranceOrDirectName	ReinsuranceRateChange	ReinsurerMarginPercentage	RenewalChainId	RenewalChainSequenceNumber	RenewalStatusCode	RenewalStatusName	ReportingYearOfAccount	RestructuredLayerIndicator	RiskCode	ShareChange	SideAOnly	SideCOnly	SignedDownPercentage	SignedLine	SignedOrder	SignedPercentage	StampCode	StructureChange	TechnicalLossRatio	TotalDeductionsPercent	TotalCommissionsPercent	TotalPremiumReductionsPercent	UnderwriterReference	UnderlyingRateChange	WrittenLine	WrittenOrder	WrittenPercentage	FinancialLoss	ZUSSectionDeleted	OwnershipType	EndorsementTypeCode	EndorsementTypeDescription	_CurrentFlag	_EffectiveFrom	_EffectiveTo	_EventExecutionKey	_LastAction	_MergeKey	_MergeKey_Brokers	_MergeKey_RetailOrManagingBrokers	_SequenceNumber	_SourceSystemCode
-1	5328532	MMEB71072514012	<<Unknown>>	N	N	<<Unknown>>	-1	NULL	N107	OTHER	N	1900-01-01	53874	<<Unknown>>	1900-01-01	NULL	NULL	[GENIUS][2228][NA][N700][5DALLAS][2002]	12499	-1	NULL	N	175	NULL	1900-01-01	0x4881232B0D8C9C401B180C0DBDE046E7	<<Unknown>>	NA	Not Applicable	LMIC	NULL	-1	2003-09-01	NULL	-1	2002-09-01	2002-09-01	N700	Chemicals	N107	OTHER	NULL	<<Unknown>>	Liberty Surplus Ins	2228	OIL & GAS	NULL	NULL	-1	-1	52568	-1	-1	2227773	2002-09-13	1243139	1900-01-01	144	144	174	1305	NULL	<<Unknown>>	<<Unknown>>	<<Unknown>>	-1	Europe	Europe	-1	<<Unknown>>                       	Richard, LA	Onshore Energy	ONE							NULL	NULL	1900-01-01	-1	-1	8396	2002-09-10	<<Unknown>>	DALLAS	<<Unknown>>	NULL	EX	Yes	Expired	NULL	NULL	NULL	0.0000000	NULL	I	Inwards	NULL	NULL	NULL	NULL	NULL	New Business	113513	1	2002	<<Unknown>>	<<Unknown>>	<<Unknown>>	NULL	NULL	<<Unknown>>	<<Unknown>>	<<Unknown>>	<<Unknown>>	NULL	D	Direct	NULL	NULL	[GENIUS][113513]	1	R	Renewed	2002	NULL	<<Unknown>>	NULL	<<Unknown>>	No	0.0000000	100.0000000	100.0000000	100.0000000	<<Unknown>>	NULL	NULL	NULL	NULL	NULL	MMEB71072514012	NULL	100.0000000	100.0000000	100.0000000	<<Unknown>>	0	<<Unknown>>	SCH	Schedule Change	0	2022-03-08 11:53:00.0000000	2023-04-19 21:17:59.9990000	310509	U	[GENIUS][113513][001][10][020]	[GENIUS][USRI0026]	<<Unknown>>	1	GENIUS
-1	7634516	MMEB71072514012	<<Unknown>>	N	N	<<Unknown>>	-1	NULL	N107	OTHER	N	1900-01-01	53874	<<Unknown>>	1900-01-01	NULL	NULL	[GENIUS][2228][NA][N700][DALLAS][2002]	12499	-1	NULL	N	175	NULL	1900-01-01	0x4881232B0D8C9C401B180C0DBDE046E7	<<Unknown>>	NA	Not Applicable	LMIC	NULL	-1	2003-09-01	NULL	-1	2002-09-01	2002-09-01	N700	Chemicals	N107	OTHER	NULL	<<Unknown>>	Liberty Surplus Ins	2228	OIL & GAS	NULL	NULL	-1	-1	52568	-1	-1	2227773	2002-09-13	1243139	1900-01-01	144	144	174	1305	NULL	<<Unknown>>	<<Unknown>>	<<Unknown>>	-1	North America	North America	-1	<<Unknown>>                       	Richard, LA	Onshore Energy	ONE							NULL	NULL	1900-01-01	-1	-1	8396	2002-09-10	<<Unknown>>	DALLAS	<<Unknown>>	NULL	EX	Yes	Expired	NULL	NULL	NULL	0.0000000	NULL	I	Inwards	NULL	NULL	NULL	NULL	NULL	New Business	113513	1	2002	<<Unknown>>	<<Unknown>>	<<Unknown>>	NULL	NULL	<<Unknown>>	<<Unknown>>	<<Unknown>>	<<Unknown>>	NULL	D	Direct	NULL	NULL	[GENIUS][113513]	1	R	Renewed	2002	NULL	<<Unknown>>	NULL	<<Unknown>>	No	0.0000000	100.0000000	100.0000000	100.0000000	<<Unknown>>	NULL	NULL	NULL	NULL	NULL	MMEB71072514012	NULL	100.0000000	100.0000000	100.0000000	<<Unknown>>	0	<<Unknown>>	SCH	Schedule Change	1	2023-04-19 21:18:00.0000000	9999-12-31 00:00:00.0000000	310509	U	[GENIUS][113513][001][10][020]	[GENIUS][USRI0026]	<<Unknown>>	2	GENIUS*/



--Sprawdzamy czy w zr�dle czyli w widoku Warehouse_Aras na RDS (PRD) sa te rekordy  i jakie maja klucze w kolumnie _MergeKey_AreaKey 

select distinct _MergeKey_AreaKey from warehouse_Policies where _mergekey in (
'[GENIUS][113513][001][10][020]'
)
