--Zbieranie danych LSMDATA-
USE ETL_Control


IF OBJECT_ID('tempdb..#temp') IS NOT NULL DROP TABLE #temp
IF OBJECT_ID('tempdb..#tasks') IS NOT NULL DROP TABLE #tasks

SELECT [EventExecutionKey]
      ,[EventCode]
      ,[SourceSystemCode]
      ,[EventStatusCode]
      ,[ExecutionStartDate]
      ,[ExecutionEndDate]
	  , DATEDIFF(MINUTE,[ExecutionStartDate],[ExecutionEndDate]) ExecutionTime_min
	  , SUBSTRING(CAST(CONVERT(TIME,DATEADD(SECOND,DATEDIFF(SECOND,[ExecutionStartDate],[ExecutionEndDate]) ,1)) AS VARCHAR),1,8) ExecutionTime_str
      ,[ExecutedByUser]
  INTO #temp
  FROM [ETL_Control].[dbo].[EventExecutionLog]
  WHERE 1=1
  AND EventCode = 'GENIUStoDWH_DP'
  --AND ExecutionStartDate >='20240311'
  AND ExecutionStartDate BETWEEN '20241201' AND '20250102'
  AND EventStatusCode='SUCCESSFUL'
  ORDER BY EventExecutionKey 



SELECT 
	  t.eventcode
	, t.ExecutionTime_min Event_Exec_Time_min
	, t.ExecutionTime_str Event_Exec_Time
	, t.EventExecutionKey
	, TaskCode
	, DATEDIFF(MINUTE,wq.[ExecutionStartDate],wq.[ExecutionEndDate]) task_time_min
	, SUBSTRING(CAST(CONVERT(TIME,DATEADD(SECOND,DATEDIFF(SECOND,wq.[ExecutionStartDate],wq.[ExecutionEndDate]) ,1)) AS VARCHAR),1,8) Task_ExecutionTime
	, wq.ExecutionStartDate
	, wq.ExecutionEndDate
INTO #tasks
FROM [ETL_Control].[dbo].[WorkQueueLog] wq
JOIN #temp t ON t.[EventExecutionKey] = wq.EventExecutionKey
--WHERE DATEDIFF(MINUTE,wq.[ExecutionStartDate],wq.[ExecutionEndDate]) > 1 --longer than 1 min
ORDER BY t.EventExecutionKey

--select * from #tasks where taskcode='CONTROL_GENIUS_ProcessBuild_CashDebt_DP' order by ExecutionStartDate



DECLARE @columns NVARCHAR(MAX), @sql NVARCHAR(MAX)
SET @columns = N'';

SELECT @columns += N', p.' + QUOTENAME([Day])
  FROM (SELECT 
			CASE 
			WHEN FORMAT ([ExecutionStartDate], 'HH:mm:dd') between '10:00:00' and '19:00:00' 
				THEN FORMAT ([ExecutionStartDate], 'yyyy-MM-dd')+'_APAC'
				ELSE FORMAT ([ExecutionStartDate], 'yyyy-MM-dd')
			END [Day]
		FROM #tasks AS p GROUP BY 
					CASE 
						WHEN FORMAT ([ExecutionStartDate], 'HH:mm:dd') between '10:00:00' and '19:00:00' 
						THEN FORMAT ([ExecutionStartDate], 'yyyy-MM-dd')+'_APAC'
						ELSE FORMAT ([ExecutionStartDate], 'yyyy-MM-dd')
					END
		) AS x;



SET @sql = N'
SELECT TaskCode, ' + STUFF(@columns, 1, 2, '') + '

FROM
(
   select TaskCode,Task_ExecutionTime, CASE 
			WHEN FORMAT ([ExecutionStartDate], ''HH:mm:dd'') between ''10:00:00'' and ''19:00:00'' 
				THEN FORMAT ([ExecutionStartDate], ''yyyy-MM-dd'')+''_APAC''
				ELSE FORMAT ([ExecutionStartDate], ''yyyy-MM-dd'')
			END [Day] from #tasks
) AS j
PIVOT
(
  max(Task_ExecutionTime) FOR [Day] IN ('
  + STUFF(REPLACE(@columns, ', p.[', ',['), 1, 1, '')
  + ')
) AS p;



';

PRINT @sql;


EXEC sp_executesql @sql;

/*
--Histoia BLOE MODE
Select 'Blode Mode dla taska'
SELECT TOP 30 DATEDIFF(MINUTE,ExecutionStartDate,ExecutionEndDate) AS TimeInMin,CAST((ExecutionEndDate - ExecutionStartDate) AS TIME) AS [hh:mm:ss],* 
FROM etl_control.dbo.workqueuelog (NOLOCK) WHERE taskcode= 'FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH_DP'
ORDER BY ExecutionStartDate DESC

*/