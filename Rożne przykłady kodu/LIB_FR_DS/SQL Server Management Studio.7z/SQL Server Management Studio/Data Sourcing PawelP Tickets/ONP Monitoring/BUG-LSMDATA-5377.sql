-- ON WR
USE [Warehouse_Repository]

SELECT policykey, policydetailkey, policyreference,_currentflag, ZUSSectionDeleted,_eventExecutionKey, *
FROM
[dbo].[Policies]
WHERE
PolicyDetailKey = '-1' AND
regioncode ='Asia Pacific Direct'


SELECT TOP 10 * 
FROM [dbo].[PolicyDetails] WHERE [PolicyReference] IN (
	SELECT policyreference
	FROM
	[dbo].[Policies]
	WHERE
	PolicyDetailKey = '-1' AND
	regioncode ='Asia Pacific Direct'

)


SELECT TOP 10 * 
FROM [dbo].[PolicyDetails] WHERE [_MergeKey] IN (
'[GENIUS][AAFPNG][014]'
)




select TOP 10 *
From
[dbo].warehouse_Policies (NOLOCK)
WHERE [PolicyReference] IN
(
N'SY00016P0224MI',
N'CPBN24A119632',
N'ADCAS24419253',
N'BNCAS24410397',
N'PRSY24A582856'
)
ORDER BY [PolicyReference]


SELECT TOP 10 *
FROM
[dbo].[Warehouse_PolicyDetails] (NOLOCK)
WHERE [PolicyReference] IN
(
N'SY00016P0224MI',
N'CPBN24A119632',
N'ADCAS24419253',
N'BNCAS24410397',
N'PRSY24A582856'
)
ORDER BY [PolicyReference]




--on RDS
SELECT *
FROM [dbo].[Warehouse_PolicyDetails] (nolock) WHERE [PolicyReference]='BNCAS24410397'


SELECT *
FROM [dbo].[Warehouse_Policies] (nolock) WHERE [_MergeKey_PolicyDetailKey] ='[GENIUS][AA6K0Q][010]'

315282