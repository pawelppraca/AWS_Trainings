
--RDS_SIT

	-- ALL Currently processed Covers
	drop table if exists #all_cov
	select *  --65392
	into #all_cov
	FROM  dbo.Map_Master_ZUMA ZUMA 
	WHERE ZUMA.InwardsOutwardsFlag = '2'

	select count(*) from #all_cov


	--covers which are not joined to ZURI (shouldn't be processed) - SIT: 37257

	drop table if exists #cov_2_Del 

	select distinct cov.MasterNumberKey, cov.MasterSequenceKey, cov.MasterReferenceKey, cov.MasterProductCode
	into #cov_2_Del
	FROM  #all_cov cov
	LEFT JOIN Map_RIAttachment_ZURI zuri on zuri.RIMasterNumber = cov.MasterNumberKey and zuri.RIMasterSequence = cov.MasterSequenceKey
	WHERE cov.InwardsOutwardsFlag = '2' 
	AND COV.MasterProductCode in ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3')
	AND zuri.MasterNumberKey IS NULL 
	AND zuri.MasterSequenceKey IS NULL


	--Covers not Joined to ZURI and out of products codes --9 szt (SIT)
	drop table if exists #cov_no_zuri_no_prodcodes
	select distinct cov.MasterNumberKey, cov.MasterSequenceKey, cov.MasterReferenceKey, cov.MasterProductCode
	into #cov_no_zuri_no_prodcodes
	FROM  #all_cov cov
	LEFT JOIN Map_RIAttachment_ZURI zuri on zuri.RIMasterNumber = cov.MasterNumberKey and zuri.RIMasterSequence = cov.MasterSequenceKey
	LEFT JOIN dbo.Map_Master_ZUMA POL on pol.MasterNumberKey = zuri.MasterNumberKey and pol.MasterSequenceKey = zuri.MasterSequenceKey
	WHERE cov.InwardsOutwardsFlag = '2' 
	AND COV.MasterProductCode NOT in ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3')
	AND pol.MasterNumberKey IS NULL AND pol.MasterSequenceKey IS  NULL


	select * from #cov_no_zuri_no_prodcodes --9 szt (SIT)



	--Covers Joined to ZURI and inclued in Products Codes (which should be processed) - SIT: 28126
	
	drop table if exists #cov_2_stay
	select distinct cov.MasterNumberKey, cov.MasterSequenceKey, cov.MasterReferenceKey, cov.MasterProductCode
	into #cov_2_stay
	FROM  #all_cov cov
	JOIN Map_RIAttachment_ZURI zuri on zuri.RIMasterNumber = cov.MasterNumberKey and zuri.RIMasterSequence = cov.MasterSequenceKey
	JOIN dbo.Map_Master_ZUMA POL on pol.MasterNumberKey = zuri.MasterNumberKey and pol.MasterSequenceKey = zuri.MasterSequenceKey
	WHERE cov.InwardsOutwardsFlag = '2' 
	AND pol.MasterNumberKey IS NOT NULL AND pol.MasterSequenceKey IS NOT NULL

	
	--Covers NOT JOINED To ZURI - SIT: 37019
	drop table if exists #cov_no_zuri
	
	select distinct cov.MasterNumberKey, cov.MasterSequenceKey, cov.MasterReferenceKey, cov.MasterProductCode
	into #cov_no_zuri
	FROM  #all_cov cov
	LEFT JOIN Map_RIAttachment_ZURI zuri on zuri.RIMasterNumber = cov.MasterNumberKey and zuri.RIMasterSequence = cov.MasterSequenceKey
	LEFT JOIN dbo.Map_Master_ZUMA POL on pol.MasterNumberKey = zuri.MasterNumberKey and pol.MasterSequenceKey = zuri.MasterSequenceKey
	WHERE cov.InwardsOutwardsFlag = '2' 
	AND pol.MasterNumberKey IS NULL AND pol.MasterSequenceKey IS NULL


	--SIT
	select count(*) all_cov from #all_cov --65392
	select count(*) cov_2_Del from #cov_2_Del --37257
	select count(*) cov_2_stay from #cov_2_stay --28126  
	select count(*) cov_no_zuri from #cov_no_zuri --37266
	select 65392-37257 -- = 28135
	select 28135-28126 -- = 9




	--Display Data

	select top 100 * 
	FROM  dbo.Map_Master_ZUMA COV





	
	
	--sprawdzenie czy s? 

	select * from #cov_2_Del
	INTERSECT
	select * from #cov_2_stay --nie ma 




	-- COV kt�rych nie powinno si? brac pod uwag?
	select cov.*
	into #cov_2_process
	FROM  #all_cov cov 
	LEFT JOIN #cov_2_Del c2d on c2d.MasterNumberKey = cov.MasterNumberKey and c2d.MasterSequenceKey = cov.MasterSequenceKey
	WHERE cov.InwardsOutwardsFlag = '2'
	AND c2d.MasterNumberKey is NULL and c2d.MasterSequenceKey IS NULL

	select * from #cov_2_process  c2p
	LEFT JOIN Map_RIAttachment_ZURI zuri on zuri.RIMasterNumber = c2p.MasterNumberKey and zuri.RIMasterSequence = c2p.MasterSequenceKey
	LEFT JOIN dbo.Map_Master_ZUMA POL on pol.MasterNumberKey = zuri.MasterNumberKey and pol.MasterSequenceKey = zuri.MasterSequenceKey
	WHERE c2p.InwardsOutwardsFlag = '2' 
	AND c2p.MasterProductCode in ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3')
	AND pol.MasterNumberKey IS NULL AND pol.MasterSequenceKey IS NULL

	
	
	--Sprawdzenie czy #cov_2_Del zawiera coversy kt�re nie maj? po?aczenia w ZURI  - nie ma
	select *
	from #cov_2_Del c2d
	JOIN Map_RIAttachment_ZURI zuri on zuri.RIMasterNumber = c2d.MasterNumberKey and zuri.RIMasterSequence = c2d.MasterSequenceKey



--RDS_SIT - filtrowanie v2

-- Z listy Covers�w ktore wpad?y po rozszerzeniu filtra
--Wyci?gnac tylko te kt�re przesz?y oryginalny filtr ZUMA
--Wyci?gnac wszystkie, kt�re s? nowe, 
--Te Nowe polaczyc do ZURI i tylko te po?aczone doda? do Reszty


	drop table if exists #all_cov
	select  MasterNumberKey, MasterSequenceKey, MasterReferenceKey, MasterProductCode, CompanyNameCode, DepartmentCode, BranchNameCodeUnconformed
	into #all_cov
	FROM  dbo.Map_Master_ZUMA ZUMA 
	WHERE ZUMA.InwardsOutwardsFlag = '2'

	select count(*) from #all_cov

	--Filtr przed rozszerzeniem
	-- MACNCD = CompanyNameCode, MAMAPC = MasterProductCode, MADPCD = DepartmentCode, MAMABN = BranchNameCodeUnconformed

	drop table if exists #all_covers_zuma_filtered
	Select * 
	into #all_covers_zuma_filtered
	from #all_cov
	WHERE (CompanyNameCode in ('CHILE', 'ARGNTA', 'MLYON', 'BRZAFFIL', 'LIBSEGBR', 'MLYOFF', 'COLOMBIA', 'COL', 'LMLATAM', 'CHL', 
                'BRASIL', 'PERU', 'ECUADOR', 'LSILATAM', 'LIUILATM', 'LIBSEGPE', 'MEXICO', 'SING', 'SOF', 'AUS', 'HK',
                'BENELUX', 'BHAMUK', 'BRISTLUK', 'COLOGNUK', 'DUBAI', 'DUBUK', 'GLASGOUK', 'HAMBRGUK', 'IRELC', 'LEEDSUK',
                'LMUK', 'MANUK', 'MILANUK', 'PARISUK', 'SOEASTUK', 'SPAIN', 'SWISSUK', 'VISIONUW', 'IRE', 'LUXUK',
                'NORWAY','SWEDEN','BELGIUM') --companies
		OR MasterProductCode in ('EQUINE', 'TPR', 'TERROR' , 'ENGNR', 'HVY', 'OFNRG', 'ONNRG', 'INLM', 'INLMQ', 'COC', 'ONNRGQ','OFNRGQ', 'HVYQ', 'ENGNRQ')
						--, 'FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3') --lsm_products_Ext_RI
		OR DepartmentCode in ('GLA', 'GUA', 'GUC', 'GUD', 'SD5') --lsm_departments
		OR BranchNameCodeUnconformed in('3MIAMI', '5MIAMI', '4PAULO', '3PR') --lsm_west_branches
		) 
	AND NOT (MasterProductCode ='TPR' AND CompanyNameCode in ('III', 'ISIC'))
	AND (LEFT(BranchNameCodeUnconformed, 1) <> '7' OR MasterProductCode NOT IN ('INLM', 'INLMQ'))




