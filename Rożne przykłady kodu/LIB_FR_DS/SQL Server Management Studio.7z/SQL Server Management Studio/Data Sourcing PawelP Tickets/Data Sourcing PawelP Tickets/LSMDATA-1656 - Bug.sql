select top 100 pol.policykey,* 

from Warehouse_Repository.dbo.CoverPremiumIncome cpi
join Warehouse_Repository.dbo.covers cov on cpi.coverkey=cov.coverkey
join Warehouse_Repository.dbo.policies pol on pol.policykey=cpi.policykey
where pol.underwriterreference='HKENG08180011A'


select top 100 * from Warehouse_Repository.dbo.covers 

select top 100 * from Warehouse_Repository.dbo.CoverPremiumIncome where policykey=5519335

select * 
from Warehouse_Repository.dbo.policies pol 

--left join Warehouse_Repository.dbo.covers cov on pol.policykey=cpi.policykey
where pol.underwriterreference='HKENG08180011A'


select top 1000 * from Warehouse_Repository.dbo.CoverPremiumIncomePosting where policykey=5519335


select top 1000 * from Warehouse_CoverPremiumIncomePosting  where policykey=5519335


select top 1000 * from [dbo].[Build_CoverPremiumIncomeAggrView]
