
USE ODS_GENIUS

select count(*) from CBIClaimListing where _LastAction='D' and ([Coverage Name] ='<<Unknown>>' or  [Coverage Name] ='')

select count(*) from CBIClaimListing where _LastAction='D'


select count(*) from CBIClaimListing

select (868979/1637152.00)*100



select _LastAction, count(*) 
from CBIClaimListing group by _LastAction

select distinct [Coverage Name] from CBIClaimListing where _LastAction='D'

select * from CBIClaimListing where [claim number]='175000622-A'




--testowe kasowanie rekord�w 
use ods_genius

--Losowae dane testowe
create table _temp_test_pp (id int identity(1,1), name varchar(100), quantity int)
--truncate table _temp_test_pp

declare @i int, @number int, @j int, @word varchar(30)
set @i = 0
while @i < 100000
begin
	
	--losowe s?owo	

	set @j = 1
	set @word=''
	while @j < 20
	begin
		set @word = @word + char(cast((90 - 65 )*rand() + 65 as integer)) 
		set @j = @j +1
	end
	--losowy numer
	set @number = CAST(RAND(CHECKSUM(NEWID()))*100000 as int) 
	insert into _temp_test_pp values (@word,@number)

	set @i = @i+1
end

select * from _temp_test_pp  --96122

select top 1 1 from _temp_test_pp where name is  null

--Dodorbi? kasowanie rekord�w po 10k w paczkach otwieraj?ci i zamykaj?c transakcje


while (exists (select top 1 1 from _temp_test_pp where name is not null))
begin

	begin tran
		delete top (10000) from _temp_test_pp where name is not null
	commit tran

	select 'deleted 10k'

end





--Przygotowa? Datafixa i Zdeplowac go?

USE ODS_GENIUS

--delete  from CBIClaimListing where _LastAction='D' and ([Coverage Name] ='<<Unknown>>' or  [Coverage Name] ='')



while (exists (select top 1 1 from CBIClaimListing where _LastAction='D' and ([Coverage Name] ='<<Unknown>>' or  [Coverage Name] ='')))
begin

	begin tran
		delete top (10000) from CBIClaimListing where _LastAction='D' and ([Coverage Name] ='<<Unknown>>' or  [Coverage Name] ='')
	commit tran

end




--UAT TEST

--BEFORE deployment DataFIX

USE ODS_GENIUS

select count(*) from CBIClaimListing where _LastAction='D' and ([Coverage Name] ='<<Unknown>>' or  [Coverage Name] ='')

select count(*) from CBIClaimListing where _LastAction='D'



--AFTER DataFIX

USE ODS_GENIUS

select count(*) from CBIClaimListing where _LastAction='D' and ([Coverage Name] ='<<Unknown>>' or  [Coverage Name] ='')

select count(*) from CBIClaimListing where _LastAction='D'


