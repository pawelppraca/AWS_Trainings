

--BI_LZ
/*
--ZUMA
-- (t)BI_LZ.Genius.ZUMA 
	--> RDS.ODS_Genius.ZUMA 
	--> (vw)RDS.ODS_Genius.[dbo].[Map_Master_ZUMA_build] 
	--> (t)RDS.ODS_Genius.[dbo].[Map_Master_ZUMA] --> 
	--> (vw)RDS.ODS_Genius.[dbo].Warehouse_Covers
	.Warehouse_CoverDetails(vw)
	.Warehouse_CoverTypes(vw)
	.Warehouse_Limits(vw)
	.Warehouse_Occupancies(vw)
	.Warehouse_Policies(vw)
	.Warehouse_PolicyDetails(vw)
	.Warehouse_PolicyTypes(vw)
	.Warehouse_Brokers(vw)
	.Warehouse_Claims(vw)
	.Warehouse_ClaimTransactions(vw)
	.Warehouse_Clients(vw)
	.Warehouse_QuotesDetils(vw)
	.Warehouse_CoverLines(vw)
	.Warehouse_CoverPremiumTransactions(vw)
	.Warehouse_PostedTransactions(vw)
	.Warehouse_Quotes(vw)
	.Warehouse_PaymentDetails(vw)
	....

*/

/*
ZUNI
========
--(t) BI_LZ.GENIUS.ZUNI(_log) 
	--> RDS.ODS_Genius.ZUNI 
	--> (vw)RDS.ODS_Genius.[dbo].[Map_NameInvolvement_ZUNI_build]
	--> (t)RDS.ODS_Genius.[dbo].[Map_NameInvolvement_ZUNI]
	--> (vw)RDS.ODS_Genius.[dbo].Warehouse_Underwriters
	--> (vw)RDS.ODS_Genius.[dbo].Warehouse_Companies --> (t)WR.dbo.COMPANIES --> WR.dbo.PolicyCompanies
	--> (vw)RDS.ODS_Genius.[dbo].Warehouse_Covers
	--> (vw)RDS.ODS_Genius.[dbo].Warehouse_Policies
	--> (vw)RDS.ODS_Genius.[dbo].Warehouse_PolicyDetails
	--> (vw)RDS.ODS_Genius.[dbo].Warehouse_Claims
	--> (vw)RDS.ODS_Genius.[dbo].Warehouse_Clientaddress
	--> (vw)RDS.ODS_Genius.[dbo].Warehouse_Clients
	--> (vw)RDS.ODS_Genius.[dbo].Warehouse_Quotes
	--> (vw)RDS.ODS_Genius.[dbo].Warehouse_QuotesDetails
	--> (vw)RDS.ODS_Genius.[dbo].Warehouse_PolicyAssured
	--> (vw)RDS.ODS_Genius.[dbo].Warehouse_PolicyReassured
	
	--> (sp)RDS.ODS_Genius.[dbo].ProcessBuild_UserAllocation
	--> (sp)RDS.ODS_Genius.[dbo].ProcessBuild_CashDebt
	--> (sp)RDS.ODS_Genius.[dbo].ProcessBuild_Policies

*/

/*
ZUCO


*/


select MAMANU, MAMASE, MAMABN, MACNCD, MAMAS2, 'ZUNI_log --> ZUNI --> COMPANIES' [table],
z___.* 
from Genius.ZUMA_log zuma
join [Genius].[ZUNI_log] z___ on z___.NIMANU = ZUMA.MAMANU AND z___.NIMASE = ZUMA.MAMASE
where zuma.MAPORF in ('SKACVJFM001')--,'SKACVJCQ001','NOACVJCN001','NOACVJFJ001')



--zuco
-- BI_LZ (t)Genius.ZUCO --> (t) ODS_Genious.ZUCO --> (vw)ODS_GENIUS.dbo.[Map_Coverage_ZUCO_build] --> (sp)ODS_GENIUS.dbo.ProcessBuild_PolicyPremiumIncome 
	--> (t)ODS_Genius.dbo.Build_PolicyPremiumIncome
select MAMANU, MAMASE, MAMABN, MACNCD, MAMAS2, 
zuco.* 
from Genius.ZUMA zuma
join [Genius].[ZUCO] zuco on zuco.COMANU = ZUMA.MAMANU AND ZUCO.COMASE = ZUMA.MAMASE
where zuma.MAPORF in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')

--ZUCO_log --Policy_premium_Income
select MAMANU, MAMASE, MAMABN, MACNCD, MAMAS2, 
zuco.* 
from Genius.ZUMA_log zuma
join [Genius].[ZUCO_log] zuco on zuco.COMANU = ZUMA.MAMANU AND ZUCO.COMASE = ZUMA.MAMASE
where zuma.MAPORF in ('SKACVJFM001')--,'SKACVJCQ001','NOACVJCN001','NOACVJFJ001')



--ZSE5

Map_StatisticsPosting_ZSE5_build



--ZUNI_log --> ZUNI --> COMPANIES
select MAMANU, MAMASE, MAMABN, MACNCD, MAMAS2, 'ZUNI_log --> ZUNI --> COMPANIES' [table],
z___.* 
from Genius.ZUMA_log zuma
join [Genius].[ZUNI_log] z___ on z___.NIMANU = ZUMA.MAMANU AND z___.NIMASE = ZUMA.MAMASE
where zuma.MAPORF in ('SKACVJFM001')--,'SKACVJCQ001','NOACVJCN001','NOACVJFJ001')



--ZKFA
select MAMANU, MAMASE, MAMABN, MACNCD, MAMAS2, 
z__.* 
from Genius.ZUMA zuma
join [Genius].ZKFA z__ 
	on z__.FAFANU = ZUMA.MAMANU 
	AND Z__.FAFASE = ZUMA.MAMASE
where zuma.MAPORF in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')

--ZUNI
select MAMANU, MAMASE, MAMABN, MACNCD, MAMAS2, 
z__.* 
from Genius.ZUMA zuma
join [Genius].ZUNI z__ 
	on z__.NIMANU = ZUMA.MAMANU 
	AND Z__.NIMASE = ZUMA.MAMASE
where zuma.MAPORF in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')

--ZNNU
select MAMANU, MAMASE, MAMABN, MACNCD, MAMAS2, 
z__.* 
from Genius.ZUMA zuma
join [Genius].ZNNU z__ 
	on z__.NIMANU = ZUMA.MAMANU 
	AND Z__.NIMASE = ZUMA.MAMASE
where zuma.MAPORF in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')



--RDS UAT

select MAMANU, MAMASE, MAMABN, MACNCD, MAMAS2, *
from ZUMA zuma
where zuma.MAPORF in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')



select MAMANU, MAMASE, MAMABN, MACNCD, MAMAS2, 
zuco.* 
from ZUMA zuma
join [ZUCO] zuco on zuco.COMANU = ZUMA.MAMANU AND ZUCO.COMASE = ZUMA.MAMASE
where zuma.MAPORF in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')


select MAMANU, MAMASE, MAMABN, MACNCD, MAMAS2, 
zuni.* 
from ZUMA zuma
join [ZUNI] zuni on zuni.NIMANU = ZUMA.MAMANU AND ZUNI.NIMASE = ZUMA.MAMASE
where zuma.MAPORF in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')


--ZSE5 Jest wype?niona
select MAMANU, MAMASE, MAMABN, MACNCD, MAMAS2, 
z.* 
from ZUMA zuma
join [ZSE5] z on z.E5MANU = ZUMA.MAMANU AND Z.E5MASE = ZUMA.MAMASE
where zuma.MAPORF in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')


select top 100 * from [dbo].[Map_StatisticsPosting_ZSE5_build]

select * from dbo.Map_Master_ZUMA
where MasterReferenceKey in 
('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')

USE ODS_GENIUS
select top 10 zse.*, zse5.*
FROM 
	dbo.Map_Master_ZUMA ZUMA
	LEFT JOIN 
		dbo.Map_StatisticsHeader_ZSE ZSE
		ON ZSE.MasterNumberKey = ZUMA.MasterNumberKey
		AND ZSE.MasterSequenceKey = ZUMA.MasterSequenceKey		
	LEFT  JOIN 
		dbo.Map_StatisticsPosting_ZSE5 ZSE5
		ON ZSE5.GGNStatisticsHeaderSequence = ZSE.GGNStatisticsHeaderSequenceKey
where zuma.MasterReferenceKey in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')






select MAMANU, MAMASE, MAMABN, MACNCD, MAMAS2, 'ZUNI_log --> ZUNI --> COMPANIES' [table],
z___.* 
from Genius.ZUMA_log zuma with(nolock)
join [Genius].[ZUNI_log] z___ with(nolock) on z___.NIMANU = ZUMA.MAMANU AND z___.NIMASE = ZUMA.MAMASE
where zuma.MAPORF in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001','24ACVJCM','24ACVJCP')



select MAMANU, MAMASE, MAMABN, MACNCD, MAMAS2, 'ZUNI --> ZUNI --> COMPANIES' [table],
z___.* 
from Genius.ZUMA zuma  with(nolock)
join [Genius].[ZUNI]  z___ with(nolock) on z___.NIMANU = ZUMA.MAMANU AND z___.NIMASE = ZUMA.MAMASE
where zuma.MAPORF in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001','24ACVJCM','24ACVJCP')
