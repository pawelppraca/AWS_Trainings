

USE IDS_Mart

CREATE SYNONYM [dwh].[SIILMALClassMapping] FOR [Warehouse_Repository].[dbo].[SIILMALClassMapping]
GO

CREATE SYNONYM [dwh].[SIILMIEClassMapping] FOR [Warehouse_Repository].[dbo].[SIILMIEClassMapping]
GO



CREATE TABLE [dbo].[SIILMALClassMapping](
    [Code]					[NVARCHAR](250) NOT NULL
,   [DataClass]			    [NVARCHAR](255)   NULL
,   [ReservingClass_Code]	[NVARCHAR](250)   NULL
,   [ReservingClass_Name]	[NVARCHAR](250)   NULL
,   [CMTClass_Code]		    [NVARCHAR](250)   NULL
,   [CMTClass_Name]		    [NVARCHAR](250)   NULL
,   [_DateCreated]			DATETIME2(7)		NOT NULL
,   [_EventExecutionKey]	INT					NOT NULL
,   [_LastAction]			NVARCHAR(1)			NOT NULL
,	[_MergeKey]				NVARCHAR(255)		NOT NULL
,	[_SourceSystemCode]     NVARCHAR(250)		NOT NULL
);
GO
CREATE NONCLUSTERED INDEX [IX_SIILMALClassMapping]
ON [dbo].[SIILMALClassMapping] ([Code])





ALTER PROCEDURE [dwh].[ProcessBuild_SIILMALClassMapping]
	@EventExecutionKey INT
AS
/**
***************************************************************************
**
** File			 : Build_SIILMALClassMapping.sql
** Version		 : $Revision: 24.07.00 $
** Description	 : DunsNo
** Called by	 : Various
**
***************************************************************************
** Change History
** Revision:			Date:		Author:					Description:
** ----------			----------	----------------------	---------------
** Version 24.07.00		15/07/2024	Pawel Parasyn			Initial Version
***************************************************************************
**/	

BEGIN

DECLARE @DateCreated DATETIME2 (7);  
SET @DateCreated = GETDATE();  


TRUNCATE TABLE [dbo].[SIILMALClassMapping]

INSERT INTO [dbo].[SIILMALClassMapping]
(
    [Code]					
,   [DataClass]			    
,   [ReservingClass_Code]	
,   [ReservingClass_Name]	
,   [CMTClass_Code]		    
,   [CMTClass_Name]		    
,	[_DateCreated]
,	[_EventExecutionKey]
,	[_LastAction]
,	[_MergeKey]
,	[_SourceSystemCode]
)
SELECT
	SIILMAL_Code
,	SIILMAL_DataClass
,	SIILMAL_ReservingClass_Code
,	SIILMAL_ReservingClass_Name
,	SIILMAL_CMTClass_Code
,	SIILMAL_CMTClass_Name
,	@DateCreated       AS [_DateCreated]
,	@EventExecutionKey AS [_EventExecutionKey]
,	[_LastAction]
,	[_MergeKey]
,	[_SourceSystemCode]

FROM 
	[dwh].[SIILMALClassMapping]
	WHERE _LastAction <> 'D'
END




Drop Table if EXISTS [SIILMIEClassMapping]

CREATE TABLE [dbo].[SIILMIEClassMapping](
    [Code]					[NVARCHAR](250) NOT NULL
,   [S2ReserveClass]	    [NVARCHAR](255)   NULL
,   [ReservingClass_Code]	[NVARCHAR](250)   NULL
,   [ReservingClass_Name]	[NVARCHAR](250)   NULL
,   [CMTClass_Code]		    [NVARCHAR](250)   NULL
,   [CMTClass_Name]		    [NVARCHAR](250)   NULL
,   [_DateCreated]			DATETIME2(7)		NOT NULL
,   [_EventExecutionKey]	INT					NOT NULL
,   [_LastAction]			NVARCHAR(1)			NOT NULL
,	[_MergeKey]				NVARCHAR(255)		NOT NULL
,	[_SourceSystemCode]     NVARCHAR(250)		NOT NULL
);
GO
CREATE NONCLUSTERED INDEX [IX_SIILMIEClassMapping]
ON [dbo].[SIILMIEClassMapping] ([Code])



ALTER PROCEDURE [dwh].[ProcessBuild_SIILMIEClassMapping]
	@EventExecutionKey INT
AS
/**
***************************************************************************
**
** File			 : Build_SIILMIEClassMapping.sql
** Version		 : $Revision: 24.07.00 $
** Description	 : DunsNo
** Called by	 : Various
**
***************************************************************************
** Change History
** Revision:			Date:		Author:					Description:
** ----------			----------	----------------------	---------------
** Version 24.07.00		15/07/2024	Pawel Parasyn			Initial Version
***************************************************************************
**/	

BEGIN

DECLARE @DateCreated DATETIME2 (7);  
SET @DateCreated = GETDATE();  

TRUNCATE TABLE [dbo].[SIILMIEClassMapping]


INSERT INTO [dbo].[SIILMIEClassMapping]
(
    [Code]					
,   [S2ReserveClass]			    
,   [ReservingClass_Code]	
,   [ReservingClass_Name]	
,   [CMTClass_Code]		    
,   [CMTClass_Name]		    
,	[_DateCreated]
,	[_EventExecutionKey]
,	[_LastAction]
,	[_MergeKey]
,	[_SourceSystemCode]
)
SELECT
	SIILMIE_Code
,	SIILMIE_S2ReserveClass
,	SIILMIE_ReservingClass_Code
,	SIILMIE_ReservingClass_Name
,	SIILMIE_CMTClass_Code
,	SIILMIE_CMTClass_Name
,	@DateCreated       AS [_DateCreated]
,	@EventExecutionKey AS [_EventExecutionKey]
,	[_LastAction]
,	[_MergeKey]
,	[_SourceSystemCode]

FROM 
	[dwh].[SIILMIEClassMapping]
WHERE _LastAction <> 'D'

END
