--Sprawdzenie powi?za? ZUMA-ZURI-ZUMA
--Sprawdzenie danych na BI_LZ PROD


SELECT count(distinct maporf)

FROM BI_LZ.GEnius.ZUMA z
WHERE (z.MACNCD in ('CHILE', 'ARGNTA', 'MLYON', 'BRZAFFIL', 'LIBSEGBR', 'MLYOFF', 'COLOMBIA', 'COL', 'LMLATAM', 'CHL', 
                'BRASIL', 'PERU', 'ECUADOR', 'LSILATAM', 'LIUILATM', 'LIBSEGPE', 'MEXICO', 'SING', 'SOF', 'AUS', 'HK',
                'BENELUX', 'BHAMUK', 'BRISTLUK', 'COLOGNUK', 'DUBAI', 'DUBUK', 'GLASGOUK', 'HAMBRGUK', 'IRELC', 'LEEDSUK',
                'LMUK', 'MANUK', 'MILANUK', 'PARISUK', 'SOEASTUK', 'SPAIN', 'SWISSUK', 'VISIONUW', 'IRE', 'LUXUK',
                'NORWAY','SWEDEN','BELGIUM') --companies
		OR z.MAMAPC in ('EQUINE', 'TPR', 'TERROR' , 'ENGNR', 'HVY', 'OFNRG', 'ONNRG', 'INLM', 'INLMQ', 'COC', 'ONNRGQ','OFNRGQ', 'HVYQ', 'ENGNRQ', 'FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3') --lsm_products
		OR z.MADPCD in ('GLA', 'GUA', 'GUC', 'GUD', 'SD5') --lsm_departments
		OR z.MAMABN in('3MIAMI', '5MIAMI', '4PAULO', '3PR') --lsm_west_branches
		) 
AND NOT (z.MAMAPC ='TPR' AND z.MACNCD in ('III', 'ISIC'))
AND (LEFT(z.MAMABN, 1) <> '7' OR z.MAMAPC NOT IN ('INLM', 'INLMQ'))
--count: 2529606 (bez nowych produkt�w)
--count: 2600543 (z nowymi produktami)
--R�znica: select  2600543 - 2529606 = 70937


SELECT *
into #Zuma_PoLicies_no_new_prod
FROM BI_LZ.Genius.ZUMA z
WHERE (z.MACNCD in ('CHILE', 'ARGNTA', 'MLYON', 'BRZAFFIL', 'LIBSEGBR', 'MLYOFF', 'COLOMBIA', 'COL', 'LMLATAM', 'CHL', 
                'BRASIL', 'PERU', 'ECUADOR', 'LSILATAM', 'LIUILATM', 'LIBSEGPE', 'MEXICO', 'SING', 'SOF', 'AUS', 'HK',
                'BENELUX', 'BHAMUK', 'BRISTLUK', 'COLOGNUK', 'DUBAI', 'DUBUK', 'GLASGOUK', 'HAMBRGUK', 'IRELC', 'LEEDSUK',
                'LMUK', 'MANUK', 'MILANUK', 'PARISUK', 'SOEASTUK', 'SPAIN', 'SWISSUK', 'VISIONUW', 'IRE', 'LUXUK',
                'NORWAY','SWEDEN','BELGIUM') --companies
		OR z.MAMAPC in ('EQUINE', 'TPR', 'TERROR' , 'ENGNR', 'HVY', 'OFNRG', 'ONNRG', 'INLM', 'INLMQ', 'COC', 'ONNRGQ','OFNRGQ', 'HVYQ', 'ENGNRQ') --, 'FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3') --lsm_products
		OR z.MADPCD in ('GLA', 'GUA', 'GUC', 'GUD', 'SD5') --lsm_departments
		OR z.MAMABN in('3MIAMI', '5MIAMI', '4PAULO', '3PR') --lsm_west_branches
		) 
AND NOT (z.MAMAPC ='TPR' AND z.MACNCD in ('III', 'ISIC'))
AND (LEFT(z.MAMABN, 1) <> '7' OR z.MAMAPC NOT IN ('INLM', 'INLMQ'))


--COVERY z Polis bez nowych produkt�w
select *
INTO #Covers_no_new_Prod --65243
FROM #Zuma_PoLicies_no_new_prod
WHERE MAMAIO=2


SELECT COUNT(DISTINCT MAPORF) 
FROM #Zuma_PoLicies_no_new_prod --2529603

--Ilo?c COVERS: MAMAIO=2
SELECT COUNT(DISTINCT MAPORF) 
FROM #Zuma_POLicies_no_new_prod WHERE MAMAIO=2 --65243

--Ilo?? COver�w MAMAIO=2 kt�rych nie ma w ZURI
SELECT COUNT(DISTINCT cov.MAPORF)  --36169
from #Covers_no_new_Prod cov 
LEFT JOIN GENIUS.ZURI map
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
LEFT JOIN #Zuma_POLicies_no_new_prod pol
    on  pol.MAMANU = map.RIMANU
    and pol.MAMASE = map.RIMASE
WHERE cov.MAMAIO=2
AND pol.MAMANU IS NULL AND pol.MAMASE IS NULL

--ile jest COver�w z wybranej listy produkt�w ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3') kt�re nie maj? ZURI

SELECT COUNT(DISTINCT cov.MAPORF)  --36162
from #Covers_no_new_Prod cov 
LEFT JOIN GENIUS.ZURI map
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
LEFT JOIN #Zuma_POLicies_no_new_prod pol
    on  pol.MAMANU = map.RIMANU
    and pol.MAMASE = map.RIMASE
WHERE cov.MAMAIO=2
AND pol.MAMANU IS NULL AND pol.MAMASE IS NULL
AND cov.MAMAPC in ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3')


--ILO?C Cover�w kt�re s? w ZURI
SELECT COUNT(DISTINCT cov.MAPORF)  --29075
from #Covers_no_new_Prod cov 
LEFT JOIN GENIUS.ZURI map
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
LEFT JOIN #Zuma_POLicies_no_new_prod pol
    on  pol.MAMANU = map.RIMANU
    and pol.MAMASE = map.RIMASE
WHERE cov.MAMAIO=2
AND pol.MAMANU IS NOT NULL AND pol.MAMASE IS NOT NULL





--Analiza dla ANIThy


--BI_LZ PROD



SELECT 'ZUMA_Current_Products_filter' [Filter], count(*)
FROM BI_LZ.GEnius.ZUMA z
WHERE (z.MACNCD in ('CHILE', 'ARGNTA', 'MLYON', 'BRZAFFIL', 'LIBSEGBR', 'MLYOFF', 'COLOMBIA', 'COL', 'LMLATAM', 'CHL', 
                'BRASIL', 'PERU', 'ECUADOR', 'LSILATAM', 'LIUILATM', 'LIBSEGPE', 'MEXICO', 'SING', 'SOF', 'AUS', 'HK',
                'BENELUX', 'BHAMUK', 'BRISTLUK', 'COLOGNUK', 'DUBAI', 'DUBUK', 'GLASGOUK', 'HAMBRGUK', 'IRELC', 'LEEDSUK',
                'LMUK', 'MANUK', 'MILANUK', 'PARISUK', 'SOEASTUK', 'SPAIN', 'SWISSUK', 'VISIONUW', 'IRE', 'LUXUK',
                'NORWAY','SWEDEN','BELGIUM') --companies
		OR z.MAMAPC in ('EQUINE', 'TPR', 'TERROR' , 'ENGNR', 'HVY', 'OFNRG', 'ONNRG', 'INLM', 'INLMQ', 'COC', 'ONNRGQ','OFNRGQ', 'HVYQ', 'ENGNRQ') 
		--, 'FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3') --lsm_products
		OR z.MADPCD in ('GLA', 'GUA', 'GUC', 'GUD', 'SD5') --lsm_departments
		OR z.MAMABN in('3MIAMI', '5MIAMI', '4PAULO', '3PR') --lsm_west_branches
		) 
AND NOT (z.MAMAPC ='TPR' AND z.MACNCD in ('III', 'ISIC'))
AND (LEFT(z.MAMABN, 1) <> '7' OR z.MAMAPC NOT IN ('INLM', 'INLMQ'))


SELECT 'ZUMA_Ext_Products_filter' [Filter], count(*)
FROM BI_LZ.GEnius.ZUMA z
WHERE (z.MACNCD in ('CHILE', 'ARGNTA', 'MLYON', 'BRZAFFIL', 'LIBSEGBR', 'MLYOFF', 'COLOMBIA', 'COL', 'LMLATAM', 'CHL', 
                'BRASIL', 'PERU', 'ECUADOR', 'LSILATAM', 'LIUILATM', 'LIBSEGPE', 'MEXICO', 'SING', 'SOF', 'AUS', 'HK',
                'BENELUX', 'BHAMUK', 'BRISTLUK', 'COLOGNUK', 'DUBAI', 'DUBUK', 'GLASGOUK', 'HAMBRGUK', 'IRELC', 'LEEDSUK',
                'LMUK', 'MANUK', 'MILANUK', 'PARISUK', 'SOEASTUK', 'SPAIN', 'SWISSUK', 'VISIONUW', 'IRE', 'LUXUK',
                'NORWAY','SWEDEN','BELGIUM') --companies
		OR z.MAMAPC in ('EQUINE', 'TPR', 'TERROR' , 'ENGNR', 'HVY', 'OFNRG', 'ONNRG', 'INLM', 'INLMQ', 'COC', 'ONNRGQ','OFNRGQ', 'HVYQ', 'ENGNRQ'
						, 'FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3') --lsm_products_Ext_RI
		OR z.MADPCD in ('GLA', 'GUA', 'GUC', 'GUD', 'SD5') --lsm_departments
		OR z.MAMABN in('3MIAMI', '5MIAMI', '4PAULO', '3PR') --lsm_west_branches
		) 
AND NOT (z.MAMAPC ='TPR' AND z.MACNCD in ('III', 'ISIC'))
AND (LEFT(z.MAMABN, 1) <> '7' OR z.MAMAPC NOT IN ('INLM', 'INLMQ'))



ZUMA_Current_Products_filter	2530042
ZUMA_Ext_Products_filter	2600984

Difference: 2600984 - 2530042 = 70942




-- ZUMA Current Products 


SELECT MAMANU, MAMASE, MAPORF, MAMAPC, MACNCD
into #zuma_current_products
FROM BI_LZ.GEnius.ZUMA z
WHERE (z.MACNCD in ('CHILE', 'ARGNTA', 'MLYON', 'BRZAFFIL', 'LIBSEGBR', 'MLYOFF', 'COLOMBIA', 'COL', 'LMLATAM', 'CHL', 
                'BRASIL', 'PERU', 'ECUADOR', 'LSILATAM', 'LIUILATM', 'LIBSEGPE', 'MEXICO', 'SING', 'SOF', 'AUS', 'HK',
                'BENELUX', 'BHAMUK', 'BRISTLUK', 'COLOGNUK', 'DUBAI', 'DUBUK', 'GLASGOUK', 'HAMBRGUK', 'IRELC', 'LEEDSUK',
                'LMUK', 'MANUK', 'MILANUK', 'PARISUK', 'SOEASTUK', 'SPAIN', 'SWISSUK', 'VISIONUW', 'IRE', 'LUXUK',
                'NORWAY','SWEDEN','BELGIUM') --companies
		OR z.MAMAPC in ('EQUINE', 'TPR', 'TERROR' , 'ENGNR', 'HVY', 'OFNRG', 'ONNRG', 'INLM', 'INLMQ', 'COC', 'ONNRGQ','OFNRGQ', 'HVYQ', 'ENGNRQ')
						--, 'FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3') --lsm_products_Ext_RI
		OR z.MADPCD in ('GLA', 'GUA', 'GUC', 'GUD', 'SD5') --lsm_departments
		OR z.MAMABN in('3MIAMI', '5MIAMI', '4PAULO', '3PR') --lsm_west_branches
		) 
AND NOT (z.MAMAPC ='TPR' AND z.MACNCD in ('III', 'ISIC'))
AND (LEFT(z.MAMABN, 1) <> '7' OR z.MAMAPC NOT IN ('INLM', 'INLMQ'))


SELECT MAMANU, MAMASE, MAPORF, MAMAPC, MACNCD
into #zuma_include_new_products
FROM BI_LZ.GEnius.ZUMA z
WHERE (z.MACNCD in ('CHILE', 'ARGNTA', 'MLYON', 'BRZAFFIL', 'LIBSEGBR', 'MLYOFF', 'COLOMBIA', 'COL', 'LMLATAM', 'CHL', 
                'BRASIL', 'PERU', 'ECUADOR', 'LSILATAM', 'LIUILATM', 'LIBSEGPE', 'MEXICO', 'SING', 'SOF', 'AUS', 'HK',
                'BENELUX', 'BHAMUK', 'BRISTLUK', 'COLOGNUK', 'DUBAI', 'DUBUK', 'GLASGOUK', 'HAMBRGUK', 'IRELC', 'LEEDSUK',
                'LMUK', 'MANUK', 'MILANUK', 'PARISUK', 'SOEASTUK', 'SPAIN', 'SWISSUK', 'VISIONUW', 'IRE', 'LUXUK',
                'NORWAY','SWEDEN','BELGIUM') --companies
		OR z.MAMAPC in ('EQUINE', 'TPR', 'TERROR' , 'ENGNR', 'HVY', 'OFNRG', 'ONNRG', 'INLM', 'INLMQ', 'COC', 'ONNRGQ','OFNRGQ', 'HVYQ', 'ENGNRQ'
						,'FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3') --lsm_products_Ext_RI
		OR z.MADPCD in ('GLA', 'GUA', 'GUC', 'GUD', 'SD5') --lsm_departments
		OR z.MAMABN in('3MIAMI', '5MIAMI', '4PAULO', '3PR') --lsm_west_branches
		) 
AND NOT (z.MAMAPC ='TPR' AND z.MACNCD in ('III', 'ISIC'))
AND (LEFT(z.MAMABN, 1) <> '7' OR z.MAMAPC NOT IN ('INLM', 'INLMQ'))


-- New ZUMAs


SELECT * 
into #ZUMA_New_records
from #zuma_include_new_products
EXCEPT
select * from #zuma_current_products cp



--Products using old filter


select MAMAPC , count(distinct MAPORF)
from #zuma_current_products cp --Policies extracted using not extended product filter
where MAMAPC in ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3')
group by MAMAPC


select MAMAPC , count(distinct MAPORF)
from #zuma_include_new_products cp --Policies extracted using not extended product filter
where MAMAPC in ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3')
group by MAMAPC



--COvers not present in ZURI

Select count(distinct cov.maporf) --36166
from #zuma_current_products zcp
join BI_LZ.Genius.ZUMA cov on cov.MAMANU = zcp.MAMANU and cov.MAMASE = zcp.MAMASE and cov.MAMAIO=2 --covers filtered zuma
left join GENIUS.ZURI map 
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
where map.RIMANU is null and map.RIMASE is null


Select distinct cov.*
from #zuma_current_products zcp
join BI_LZ.Genius.ZUMA cov on cov.MAMANU = zcp.MAMANU and cov.MAMASE = zcp.MAMASE and cov.MAMAIO=2 --covers filtered zuma
left join GENIUS.ZURI map 
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
where map.RIMANU is null and map.RIMASE is null








--Covers joined to ZURI in non extended filter

select cov.MAMAPC, count(distinct cov.MAPORF)  --29080
FROM Genius.ZUMA cov 
INNER JOIN #zuma_current_products znr on znr.MAMANU = cov.MAMANU and znr.MAMASE= cov.MAMASE and cov.MAMAIO = 2 --Covers
inner join GENIUS.ZURI map
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
group by cov.MAMAPC
order by cov.MAMAPC

--Covers NOT joined to ZURI in non extended filter

select cov.MAMAPC, count(distinct cov.MAPORF) --29080
FROM Genius.ZUMA cov 
INNER JOIN #zuma_current_products znr on znr.MAMANU = cov.MAMANU and znr.MAMASE= cov.MAMASE and cov.MAMAIO = 2 --Covers
LEFT join GENIUS.ZURI map
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
where map.RIMANU is null and map.RIMASE is null
group by cov.MAMAPC
order by cov.MAMAPC

--Covers joined to ZURI in extended filter

select cov.MAMAPC, count(distinct cov.MAPORF)  --29080
FROM Genius.ZUMA cov 
INNER JOIN #ZUMA_New_records znr on znr.MAMANU = cov.MAMANU and znr.MAMASE= cov.MAMASE and cov.MAMAIO = 2 --Covers
inner join GENIUS.ZURI map
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
group by cov.MAMAPC
order by cov.MAMAPC

--Covers Not Joined to ZURI in extended filter
select cov.MAMAPC, count(distinct cov.MAPORF)   --29080
FROM Genius.ZUMA cov 
INNER JOIN #ZUMA_New_records znr on znr.MAMANU = cov.MAMANU and znr.MAMASE= cov.MAMASE
LEFT join GENIUS.ZURI map
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
where map.RIMANU is null and map.RIMASE is null
group by cov.MAMAPC
order by cov.MAMAPC



--Sprawdzenie na DEV - baza PP_Temp

select top 10 * from [dbo].[Covers_not_in_ZURI_top_10000]

select top 10 * from [dbo].[WR_Covers_PROD]

select count(*) from [dbo].[WR_Covers_PROD]

select count(*) from [dbo].[Covers_not_in_ZURI] c

select count(distinct MAPORF) 
from [dbo].[Covers_not_in_ZURI_top_10000] c
join [dbo].[WR_Covers_PROD] wcp on wcp.CoverReference = c.MAPORF


select *
from [dbo].[Covers_not_in_ZURI] c
LEFT join [dbo].[WR_Covers_PROD] wcp on wcp.CoverReference = c.MAPORF
where wcp.CoverKey is null