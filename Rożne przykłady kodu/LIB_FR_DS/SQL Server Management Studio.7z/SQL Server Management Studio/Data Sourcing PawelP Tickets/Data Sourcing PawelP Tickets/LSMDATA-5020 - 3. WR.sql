USE Warehouse_Repository

--==========================
--SIILMALClassMapping
--==========================

DROP TABLE IF EXISTS [dbo].[SIILMALClassMapping]
CREATE TABLE [dbo].[SIILMALClassMapping] (
	 [SIILMAL_ClassMappingKey]		[INT] IDENTITY(1,1) NOT NULL
	,[SIILMAL_Code]					NVARCHAR(250) DEFAULT(N'<<Unknown>>')   NOT NULL
	,[SIILMAL_DataClass]			NVARCHAR(255) DEFAULT(N'<<Unknown>>')   NOT NULL
	,[SIILMAL_ReservingClass_Code]	NVARCHAR(250) DEFAULT(N'<<Unknown>>')   NOT NULL
	,[SIILMAL_ReservingClass_Name]	NVARCHAR(250) DEFAULT(N'<<Unknown>>')   NOT NULL
	,[SIILMAL_CMTClass_Code]		NVARCHAR(250) DEFAULT(N'<<Unknown>>')   NOT NULL
	,[SIILMAL_CMTClass_Name]		NVARCHAR(250) DEFAULT(N'<<Unknown>>')   NOT NULL
    ,[_DateCreated]                 DATETIME2(7)                            NOT NULL
    ,[_EventExecutionKey]           INT                                     NOT NULL
    ,[_LastAction]                  NCHAR(1)                                NOT NULL
    ,[_MergeKey]                    NVARCHAR(255)                           NOT NULL
    ,[_SourceSystemCode]            NVARCHAR(50)                            NOT NULL
    ,CONSTRAINT [PK_SIILMAL_Code] PRIMARY KEY CLUSTERED ([SIILMAL_Code] ASC) WITH (DATA_COMPRESSION = PAGE)
);


--Drop And Create Stage Table 
--------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[STAGE].[SIILMALClassMapping_MDS]') AND type in (N'U'))
DROP TABLE [STAGE].[SIILMALClassMapping_MDS]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [STAGE].[SIILMALClassMapping_MDS](
	 [SIILMAL_Code]					[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMAL_DataClass]			[NVARCHAR](255) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMAL_ReservingClass_Code]	[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMAL_ReservingClass_Name]	[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMAL_CMTClass_Code]		[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMAL_CMTClass_Name]		[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[_DateCreated]					[DATETIME2](7) NULL
	,[_LastAction]					[NCHAR](1) COLLATE Latin1_General_CI_AS NULL
	,[_MergeKey]					[NVARCHAR](255) COLLATE Latin1_General_CI_AS NULL
	,[_SourceSystemCode]			[NVARCHAR](50) COLLATE Latin1_General_CI_AS NULL
) ON [PRIMARY]


CREATE UNIQUE NONCLUSTERED INDEX [IX_STAGE_SIILMALClassMapping_MDS__MergeKey]
	ON [STAGE].[SIILMALClassMapping_MDS] ([_MergeKey])
	INCLUDE ([SIILMAL_Code],[SIILMAL_DataClass],[SIILMAL_ReservingClass_Code],[SIILMAL_ReservingClass_Name],[SIILMAL_CMTClass_Code],[SIILMAL_CMTClass_Name],[_DateCreated],[_LastAction],[_SourceSystemCode]);


--Drop And Create Work Table
--------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORK].[SIILMALClassMapping_MDS]') AND type in (N'U'))
DROP TABLE [WORK].[SIILMALClassMapping_MDS]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [WORK].[SIILMALClassMapping_MDS](
	 [SIILMAL_ClassMappingKey]		[INT] NULL
	,[SIILMAL_Code]					[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMAL_DataClass]			[NVARCHAR](255) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMAL_ReservingClass_Code]	[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMAL_ReservingClass_Name]	[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMAL_CMTClass_Code]		[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMAL_CMTClass_Name]		[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[_DateCreated]					[DATETIME2](7) NULL
	,[_EventExecutionKey]			[int] NULL
    ,[_LastAction]					[NCHAR](1) COLLATE Latin1_General_CI_AS NULL
	,[_MergeKey]					[NVARCHAR](255) COLLATE Latin1_General_CI_AS NULL
	,[_SourceSystemCode]			[NVARCHAR](50) COLLATE Latin1_General_CI_AS NULL
) ON [PRIMARY]


CREATE NONCLUSTERED INDEX [IX_WORK_SIILMALClassMapping_MDS_SIILMALClassMappingKey]
	ON [WORK].[SIILMALClassMapping_MDS] ([SIILMAL_ClassMappingKey])
	INCLUDE ([SIILMAL_Code],[SIILMAL_DataClass],[SIILMAL_ReservingClass_Code],[SIILMAL_ReservingClass_Name],[SIILMAL_CMTClass_Code],[SIILMAL_CMTClass_Name],[_DateCreated],[_LastAction],[_SourceSystemCode]);


CREATE NONCLUSTERED INDEX [IX_WORK_SIILMALClassMapping_MDS__LastAction]
	ON [WORK].[SIILMALClassMapping_MDS] ([_LastAction]);




--MERGE

UPDATE 
	t 
SET 
	t.[_LastAction] = s.[_LastAction] 
,	t.[_EventExecutionKey] = s.[_EventExecutionKey] 
FROM 
	[dbo].[SIILMALClassMapping] t 
INNER JOIN 
	WORK.[SIILMALClassMapping_MDS] s 
ON 
	t.[SIILMAL_ClassMappingKey] = s.[SIILMAL_ClassMappingKey] 
WHERE 
	t.[_LastAction] <> 'D' 
AND
	s.[_LastAction] = 'D'; 


MERGE [dbo].[SIILMALClassMapping] AS t 
USING [WORK].[SIILMALClassMapping_MDS] AS s 
ON 
(
	t.[SIILMAL_ClassMappingKey] = s.[SIILMAL_ClassMappingKey] 
)
WHEN MATCHED AND s.[_LastAction] IN ('I', 'U') 
THEN 
UPDATE 
SET 
	 [SIILMAL_Code] = s.[SIILMAL_Code]
,	 [SIILMAL_DataClass] = s.[SIILMAL_DataClass]
,	 [SIILMAL_ReservingClass_Code] = s.[SIILMAL_ReservingClass_Code]
,	 [SIILMAL_ReservingClass_Name] = s.[SIILMAL_ReservingClass_Name]
,	 [SIILMAL_CMTClass_Code] = s.[SIILMAL_CMTClass_Code]
,	 [SIILMAL_CMTClass_Name] = s.[SIILMAL_CMTClass_Name]
,	 [_EventExecutionKey] = s.[_EventExecutionKey]
,	 [_LastAction] = s.[_LastAction]
,	 [_MergeKey] = s.[_MergeKey]
,	 [_SourceSystemCode] = s.[_SourceSystemCode]
WHEN NOT MATCHED BY TARGET AND s.[_LastAction] IN ('I', 'U') THEN 
INSERT 
( 
	 [SIILMAL_Code]
,	 [SIILMAL_DataClass]
,	 [SIILMAL_ReservingClass_Code]
,	 [SIILMAL_ReservingClass_Name]
,	 [SIILMAL_CMTClass_Code]
,	 [SIILMAL_CMTClass_Name]
,	 [_DateCreated]
,	 [_EventExecutionKey]
,	 [_LastAction]
,	 [_MergeKey]
,	 [_SourceSystemCode]
)
VALUES
(
	 s.[SIILMAL_Code]
,	 s.[SIILMAL_DataClass]
,	 s.[SIILMAL_ReservingClass_Code]
,	 s.[SIILMAL_ReservingClass_Name]
,	 s.[SIILMAL_CMTClass_Code]
,	 s.[SIILMAL_CMTClass_Name]
,	 s.[_DateCreated]
,	 s.[_EventExecutionKey]
,	 s.[_LastAction]
,	 s.[_MergeKey]
,	 s.[_SourceSystemCode]
);








--==========================
--SIILMIEClassMapping
--==========================

DROP TABLE IF EXISTS [dbo].[SIILMIEClassMapping]
CREATE TABLE [dbo].[SIILMIEClassMapping] (
	 [SIILMIE_ClassMappingKey]		[INT] IDENTITY(1,1) NOT NULL
	,[SIILMIE_Code]					NVARCHAR(250) DEFAULT(N'<<Unknown>>')   NOT NULL
	,[SIILMIE_S2ReserveClass]		NVARCHAR(255) DEFAULT(N'<<Unknown>>')   NOT NULL
	,[SIILMIE_ReservingClass_Code]	NVARCHAR(250) DEFAULT(N'<<Unknown>>')   NOT NULL
	,[SIILMIE_ReservingClass_Name]	NVARCHAR(250) DEFAULT(N'<<Unknown>>')   NOT NULL
	,[SIILMIE_CMTClass_Code]		NVARCHAR(250) DEFAULT(N'<<Unknown>>')   NOT NULL
	,[SIILMIE_CMTClass_Name]		NVARCHAR(250) DEFAULT(N'<<Unknown>>')   NOT NULL
    ,[_DateCreated]                 DATETIME2(7)                            NOT NULL
    ,[_EventExecutionKey]           INT                                     NOT NULL
    ,[_LastAction]                  NCHAR(1)                                NOT NULL
    ,[_MergeKey]                    NVARCHAR(255)                           NOT NULL
    ,[_SourceSystemCode]            NVARCHAR(50)                            NOT NULL
    ,CONSTRAINT [PK_SIILMIE_Code] PRIMARY KEY CLUSTERED ([SIILMIE_Code] ASC) WITH (DATA_COMPRESSION = PAGE)
);


--Drop And Create Stage Table 
--------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[STAGE].[SIILMIEClassMapping_MDS]') AND type in (N'U'))
DROP TABLE [STAGE].[SIILMIEClassMapping_MDS]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [STAGE].[SIILMIEClassMapping_MDS](
	 [SIILMIE_Code]					[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMIE_S2ReserveClass]		[NVARCHAR](255) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMIE_ReservingClass_Code]	[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMIE_ReservingClass_Name]	[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMIE_CMTClass_Code]		[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMIE_CMTClass_Name]		[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[_DateCreated]					[DATETIME2](7) NULL
	,[_LastAction]					[NCHAR](1) COLLATE Latin1_General_CI_AS NULL
	,[_MergeKey]					[NVARCHAR](255) COLLATE Latin1_General_CI_AS NULL
	,[_SourceSystemCode]			[NVARCHAR](50) COLLATE Latin1_General_CI_AS NULL
) ON [PRIMARY]


CREATE UNIQUE NONCLUSTERED INDEX [IX_STAGE_SIILMIEClassMapping_MDS__MergeKey]
	ON [STAGE].[SIILMIEClassMapping_MDS] ([_MergeKey])
	INCLUDE ([SIILMIE_Code],[SIILMIE_S2ReserveClass],[SIILMIE_ReservingClass_Code],[SIILMIE_ReservingClass_Name],[SIILMIE_CMTClass_Code],[SIILMIE_CMTClass_Name],[_DateCreated],[_LastAction],[_SourceSystemCode]);


--Drop And Create Work Table
--------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORK].[SIILMIEClassMapping_MDS]') AND type in (N'U'))
DROP TABLE [WORK].[SIILMIEClassMapping_MDS]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [WORK].[SIILMIEClassMapping_MDS](
	 [SIILMIE_ClassMappingKey]		[INT] NULL
	,[SIILMIE_Code]					[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMIE_S2ReserveClass]		[NVARCHAR](255) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMIE_ReservingClass_Code]	[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMIE_ReservingClass_Name]	[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMIE_CMTClass_Code]		[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMIE_CMTClass_Name]		[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[_DateCreated]					[DATETIME2](7) NULL
	,[_EventExecutionKey]			[int] NULL
    ,[_LastAction]					[NCHAR](1) COLLATE Latin1_General_CI_AS NULL
	,[_MergeKey]					[NVARCHAR](255) COLLATE Latin1_General_CI_AS NULL
	,[_SourceSystemCode]			[NVARCHAR](50) COLLATE Latin1_General_CI_AS NULL
) ON [PRIMARY]


CREATE NONCLUSTERED INDEX [IX_WORK_SIILMIEClassMapping_MDS_SIILMIEClassMappingKey]
	ON [WORK].[SIILMIEClassMapping_MDS] ([SIILMIE_ClassMappingKey])
	INCLUDE ([SIILMIE_Code],[SIILMIE_S2ReserveClass],[SIILMIE_ReservingClass_Code],[SIILMIE_ReservingClass_Name],[SIILMIE_CMTClass_Code],[SIILMIE_CMTClass_Name],[_DateCreated],[_LastAction],[_SourceSystemCode]);


CREATE NONCLUSTERED INDEX [IX_WORK_SIILMIEClassMapping_MDS__LastAction]
	ON [WORK].[SIILMIEClassMapping_MDS] ([_LastAction]);


-- MERGE

UPDATE 
	t 
SET 
	t.[_LastAction] = s.[_LastAction] 
,	t.[_EventExecutionKey] = s.[_EventExecutionKey] 
FROM 
	[dbo].[SIILMIEClassMapping] t 
INNER JOIN 
	WORK.[SIILMIEClassMapping_MDS] s 
ON 
	t.[SIILMIE_ClassMappingKey] = s.[SIILMIE_ClassMappingKey] 
WHERE 
	t.[_LastAction] <> 'D' 
AND
	s.[_LastAction] = 'D'; 


MERGE [dbo].[SIILMIEClassMapping] AS t 
USING [WORK].[SIILMIEClassMapping_MDS] AS s 
ON 
(
	t.[SIILMIE_ClassMappingKey] = s.[SIILMIE_ClassMappingKey] 
)
WHEN MATCHED AND s.[_LastAction] IN ('I', 'U') 
THEN 
UPDATE 
SET 
	 [SIILMIE_Code] = s.[SIILMIE_Code]
,	 [SIILMIE_S2ReserveClass] = s.[SIILMIE_S2ReserveClass]
,	 [SIILMIE_ReservingClass_Code] = s.[SIILMIE_ReservingClass_Code]
,	 [SIILMIE_ReservingClass_Name] = s.[SIILMIE_ReservingClass_Name]
,	 [SIILMIE_CMTClass_Code] = s.[SIILMIE_CMTClass_Code]
,	 [SIILMIE_CMTClass_Name] = s.[SIILMIE_CMTClass_Name]
,	 [_EventExecutionKey] = s.[_EventExecutionKey]
,	 [_LastAction] = s.[_LastAction]
,	 [_MergeKey] = s.[_MergeKey]
,	 [_SourceSystemCode] = s.[_SourceSystemCode]
WHEN NOT MATCHED BY TARGET AND s.[_LastAction] IN ('I', 'U') THEN 
INSERT 
( 
	 [SIILMIE_Code]
,	 [SIILMIE_S2ReserveClass]
,	 [SIILMIE_ReservingClass_Code]
,	 [SIILMIE_ReservingClass_Name]
,	 [SIILMIE_CMTClass_Code]
,	 [SIILMIE_CMTClass_Name]
,	 [_DateCreated]
,	 [_EventExecutionKey]
,	 [_LastAction]
,	 [_MergeKey]
,	 [_SourceSystemCode]
)
VALUES
(
	 s.[SIILMIE_Code]
,	 s.[SIILMIE_S2ReserveClass]
,	 s.[SIILMIE_ReservingClass_Code]
,	 s.[SIILMIE_ReservingClass_Name]
,	 s.[SIILMIE_CMTClass_Code]
,	 s.[SIILMIE_CMTClass_Name]
,	 s.[_DateCreated]
,	 s.[_EventExecutionKey]
,	 s.[_LastAction]
,	 s.[_MergeKey]
,	 s.[_SourceSystemCode]
);




-- After Merge chnage filed name [SIILMALClassMappingKey] to [SIILMAL_ClassMappingKey] in Dimenstion SSIS_Package