--TESTY na SIT
USE ETL_Control

--Testowe wykonanie na SSIS z starym sposobem na SIT
declare @EventExecutionKey int = 2442601
declare @StartEventTime datetime


SELECT top 1 @StartEventTime = StartTime
FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** Start of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'
ORDER BY Id

UPDATE log SET StartTime = @StartEventTime
FROM SSIS_Packages_audit_Log log
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** END of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'

SELECT * FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
AND RunningTime is not null
ORDER BY Id


--Dane przed uruchomieniem starym sposobem
--Uruchomienia na SIT bez zapisu do PolicyPremiumTransactionsCoverage - stop na WORK
--Test wykonany przez uruchomienie pakietu SSIS w SSISDB na SIT

select count(*) from WAREHOUSE_Repository.STAGE.[PolicyPremiumTransactionsCoverage_GENIUS]  --4150592
select count(*) from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS]  --480192

select 'STAGE' [Table], count(*) qty_of_records, _LastAction
from WAREHOUSE_Repository.STAGE.[PolicyPremiumTransactionsCoverage_GENIUS] 
group by _LastAction

/*
Table	qty_of_records	_LastAction
STAGE	1766699	D
STAGE	2383893	I
*/


select 'WORK'[Table], count(*) qty_of_records, _LastAction
from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS] 
group by _LastAction

/*
Table	qty_of_records	_LastAction
WORK	364066	D
WORK	116126	U
*/

select 'PolicyPremiumTransactionsCoverage'[Table], count(*) qty_of_records, _LastAction
from WAREHOUSE_Repository.dbo.[PolicyPremiumTransactionsCoverage] 
where _SourceSystemCode='GENIUS'
group by _LastAction
order by _LastAction

/*
Table								qty_of_records	_LastAction
PolicyPremiumTransactionsCoverage	6810				D
PolicyPremiumTransactionsCoverage	2664				I
PolicyPremiumTransactionsCoverage	9020969				U
*/

--Backup checksum do weryfikacji zmiany rekord�w w PolicyPremiumTransactionsCoverage
--DROP TABLE IF EXISTS WORK.PolicyPremiumTransactionsCoverage_Checksums_before_opty_by_SSIS_GChD
--DROP TABLE IF EXISTS WORK.PolicyPremiumTransactionsCoverage_Checksums_after_opty_by_SSIS_GChD


--Przed uruchomieniem testu na SIT
--DROP TABLE IF EXISTS WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_GenChD]
--DROP TABLE IF EXISTS WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_Proc_GenChD]  



--RunPackage  FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH.dtsx on SIT  EEK=2442701


--Kopia tabeli WORK WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS]  po processingu stara metoda
select *
INTO WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_GenChD]  
FROM WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS]  --(9146991 rows affected)  Completion time: 2024-04-26T13:17:42.0048375+02:00


--RunPackage  FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH_OPT.dtsx on SIT  EEK=2442701


--Kopia tabeli WORK WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS]  po processingu Nowa metoda
select *
INTO WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_Proc_GenChD]  
FROM WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS]  --(9146991 rows affected)  Completion time:2024-04-26T18:00:30.2255766+02:00 


--TEST SIT 7.05.2024

--Przed uruchomieniem testu na SIT
--DROP TABLE IF EXISTS WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_GenChD]
--DROP TABLE IF EXISTS WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_Proc_GenChD]  

--RunPackage  FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH.dtsx on SIT  EEK=2450703


--Testowe wykonanie na SSIS star? metod? na SIT
declare @EventExecutionKey int = 2450703
declare @StartEventTime datetime

SELECT top 1 @StartEventTime = StartTime
FROM ETL_CONTROL.dbo.SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** Start of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'
ORDER BY Id

UPDATE log SET StartTime = @StartEventTime
FROM ETL_CONTROL.dbo.SSIS_Packages_audit_Log log
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** END of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'

SELECT * FROM ETL_CONTROL.dbo.SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
AND RunningTime is not null
ORDER BY Id

select * from ETL_CONTROL.dbo.SSIS_Packages_audit_Log where EventExecutionKey = 2450703



--Kopia tabeli WORK WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS]  po processingu stara metoda
select *
INTO WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_GenChD]  
FROM WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS]  --(9023954 rows affected)  Completion time: 2024-05-07T10:22:41.0505822+02:00




--RunPackage  FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH_OPT.dtsx on SIT  EEK=245705


--Testowe wykonanie na SSIS now? metod? na SIT
declare @EventExecutionKey int = 2450705
declare @StartEventTime datetime

SELECT top 1 @StartEventTime = StartTime
FROM ETL_CONTROL.dbo.SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** Start of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'
ORDER BY Id

UPDATE log SET StartTime = @StartEventTime
FROM ETL_CONTROL.dbo.SSIS_Packages_audit_Log log
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** END of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'

SELECT * FROM ETL_CONTROL.dbo.SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
AND RunningTime is not null
ORDER BY Id



select * from ETL_CONTROL.dbo.SSIS_Packages_audit_Log where EventExecutionKey = 2450705


--Kopia tabeli WORK WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS]  po processingu Nowa metoda
select *
INTO WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_Proc_GenChD]  
FROM WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS]  --(9023954 rows affected)  Completion time: 2024-05-07T10:50:00.2251898+02:00




--Por�wnanie tabel WORKowych


select
      [LimitKey]
      ,[OriginalCurrencyKey]
      ,[PolicyKey]
      ,[PolicyReference]
      ,[AuditNumber]
      ,[ExternalReferenceIdentifier]
      ,[DoubleEntryItemSequence]
      ,[StatisticsLedgerSequence]
      ,[CreatedBy]
      ,[UserName]
      ,[DueDate]
      ,[FiscalPeriod]
      ,[TransactionEntryDate]
      ,[TransactionTypeKey]
      ,[TransactionTypeCategoryCode]
      ,[TransactionTypeCategory]
      ,[TransactionOriginalFlag]
      ,[TransactionDescription]
      ,[TransactionLineOfBusinessCode]
      ,[TransactionBranch]
      ,[AccountingToBaseExchangeRate]
      ,[OriginalToBaseExchangeRate]
      ,[PolicyWrittenExchangeRate]
      ,[ClientPolicyPremiumGrossOriginalCurrency]
      ,[ClientPolicyPremiumNetOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedGrossOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedNetOriginalCurrency]
      ,[InitialPolicyPremiumSEPIGrossOriginalCurrency]
      ,[InitialPolicyPremiumSEPINetOriginalCurrency]
      ,[InitialPolicyPremiumSignedGrossOriginalCurrency]
      ,[InitialPolicyPremiumSignedNetOriginalCurrency]
      ,[InitialPolicyPremiumWrittenGrossOriginalCurrency]
      ,[InitialPolicyPremiumWrittenNetOriginalCurrency]
      ,[SignedDownPremiumEstimatedNetOriginalCurrency]
      ,[SignedDownPremiumWrittenNetOriginalCurrency]
      ,[SystemTransactionAmountOriginalCurrency]
      ,[_CDCDateKey]
      ,[_CDCTime]
--      ,[_DateCreated]
--      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_MergeKey_Limits]
      ,[_MergeKey_Policies]
      ,[_SourceSystemCode]
INTO #PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_or_Proc_GenChD_Diff
from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_GenChD]  
Except 
SELECT 
      [LimitKey]
      ,[OriginalCurrencyKey]
      ,[PolicyKey]
      ,[PolicyReference]
      ,[AuditNumber]
      ,[ExternalReferenceIdentifier]
      ,[DoubleEntryItemSequence]
      ,[StatisticsLedgerSequence]
      ,[CreatedBy]
      ,[UserName]
      ,[DueDate]
      ,[FiscalPeriod]
      ,[TransactionEntryDate]
      ,[TransactionTypeKey]
      ,[TransactionTypeCategoryCode]
      ,[TransactionTypeCategory]
      ,[TransactionOriginalFlag]
      ,[TransactionDescription]
      ,[TransactionLineOfBusinessCode]
      ,[TransactionBranch]
      ,[AccountingToBaseExchangeRate]
      ,[OriginalToBaseExchangeRate]
      ,[PolicyWrittenExchangeRate]
      ,[ClientPolicyPremiumGrossOriginalCurrency]
      ,[ClientPolicyPremiumNetOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedGrossOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedNetOriginalCurrency]
      ,[InitialPolicyPremiumSEPIGrossOriginalCurrency]
      ,[InitialPolicyPremiumSEPINetOriginalCurrency]
      ,[InitialPolicyPremiumSignedGrossOriginalCurrency]
      ,[InitialPolicyPremiumSignedNetOriginalCurrency]
      ,[InitialPolicyPremiumWrittenGrossOriginalCurrency]
      ,[InitialPolicyPremiumWrittenNetOriginalCurrency]
      ,[SignedDownPremiumEstimatedNetOriginalCurrency]
      ,[SignedDownPremiumWrittenNetOriginalCurrency]
      ,[SystemTransactionAmountOriginalCurrency]
      ,[_CDCDateKey]
      ,[_CDCTime]
--      ,[_DateCreated]
--      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_MergeKey_Limits]
      ,[_MergeKey_Policies]
      ,[_SourceSystemCode]

from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_Proc_GenChD]


select distinct _LastAction from #PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_or_Proc_GenChD_Diff


select _EventExecutionKey,
ClientPolicyPremiumNetOriginalCurrency
,ClientPolicyPremiumGrossOriginalCurrency
,SignedDownPremiumEstimatedNetOriginalCurrency
,SignedDownPremiumEstimatedNetOriginalCurrency
,SignedDownPremiumWrittenNetOriginalCurrency,*
from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_GenChD]  
where _MergeKey in (
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][1771]'
,'[GENIUS][260291][009][02][002][001][Estimated][INITIAL][PRM][GROSS][AUD][2846679]'
--'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][2004]',
--'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][272880]',
--'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][272881]',
--'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][2776]',
--'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][2783]'
)


select _MergeKey, _EventExecutionKey,
ClientPolicyPremiumNetOriginalCurrency
,ClientPolicyPremiumGrossOriginalCurrency
,SignedDownPremiumEstimatedNetOriginalCurrency
,SignedDownPremiumEstimatedNetOriginalCurrency
,SignedDownPremiumWrittenNetOriginalCurrency, *
from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_Proc_GenChD]
where _MergeKey in (
--'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][139972]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][1771]',
'[GENIUS][260291][009][02][002][001][Estimated][INITIAL][PRM][GROSS][AUD][2846679]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][2004]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][272880]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][272881]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][2776]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][2783]'
)

select 'STAGE',_MergeKey,
ClientPolicyPremiumNetOriginalCurrency
,ClientPolicyPremiumGrossOriginalCurrency
,SignedDownPremiumEstimatedNetOriginalCurrency
,SignedDownPremiumEstimatedNetOriginalCurrency
,SignedDownPremiumWrittenNetOriginalCurrency,*
FROM Warehouse_Repository.[STAGE].[PolicyPremiumTransactionsCoverage_GENIUS] (nolock)
where _MergeKey in (
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][1771]'
,'[GENIUS][260291][009][02][002][001][Estimated][INITIAL][PRM][GROSS][AUD][2846679]'
)

select 'Target',
ClientPolicyPremiumNetOriginalCurrency
,ClientPolicyPremiumGrossOriginalCurrency
,SignedDownPremiumEstimatedNetOriginalCurrency
,SignedDownPremiumEstimatedNetOriginalCurrency
,SignedDownPremiumWrittenNetOriginalCurrency
FROM Warehouse_Repository.[dbo].[PolicyPremiumTransactionsCoverage] 
WHERE _SourceSystemCode = 'GENIUS'
AND _MergeKey='[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][1771]'


--Po re?zny wywo?aniu procedury
select  _MergeKey,_EventExecutionKey,
ClientPolicyPremiumNetOriginalCurrency
,ClientPolicyPremiumGrossOriginalCurrency
,SignedDownPremiumEstimatedNetOriginalCurrency
,SignedDownPremiumEstimatedNetOriginalCurrency
,SignedDownPremiumWrittenNetOriginalCurrency, *
from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS] (nolock)
where _MergeKey in (
--'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][139972]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][1771]',
'[GENIUS][260291][009][02][002][001][Estimated][INITIAL][PRM][GROSS][AUD][2846679]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][139972]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][2004]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][272880]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][272881]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][2776]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][2783]'
)


select _EventExecutionKey,
ClientPolicyPremiumNetOriginalCurrency
,ClientPolicyPremiumGrossOriginalCurrency
,SignedDownPremiumEstimatedNetOriginalCurrency
,SignedDownPremiumEstimatedNetOriginalCurrency
,SignedDownPremiumWrittenNetOriginalCurrency, *
from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_Proc_GenChD]
where ClientPolicyPremiumNetOriginalCurrency<>0




--Por�wnanie tabel WORKowych

SELECT 
      [LimitKey]
      ,[OriginalCurrencyKey]
      ,[PolicyKey]
      ,[PolicyReference]
      ,[AuditNumber]
      ,[ExternalReferenceIdentifier]
      ,[DoubleEntryItemSequence]
      ,[StatisticsLedgerSequence]
      ,[CreatedBy]
      ,[UserName]
      ,[DueDate]
      ,[FiscalPeriod]
      ,[TransactionEntryDate]
      ,[TransactionTypeKey]
      ,[TransactionTypeCategoryCode]
      ,[TransactionTypeCategory]
      ,[TransactionOriginalFlag]
      ,[TransactionDescription]
      ,[TransactionLineOfBusinessCode]
      ,[TransactionBranch]
      ,[AccountingToBaseExchangeRate]
      ,[OriginalToBaseExchangeRate]
      ,[PolicyWrittenExchangeRate]
      ,[ClientPolicyPremiumGrossOriginalCurrency]
      ,[ClientPolicyPremiumNetOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedGrossOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedNetOriginalCurrency]
      ,[InitialPolicyPremiumSEPIGrossOriginalCurrency]
      ,[InitialPolicyPremiumSEPINetOriginalCurrency]
      ,[InitialPolicyPremiumSignedGrossOriginalCurrency]
      ,[InitialPolicyPremiumSignedNetOriginalCurrency]
      ,[InitialPolicyPremiumWrittenGrossOriginalCurrency]
      ,[InitialPolicyPremiumWrittenNetOriginalCurrency]
      ,[SignedDownPremiumEstimatedNetOriginalCurrency]
      ,[SignedDownPremiumWrittenNetOriginalCurrency]
      ,[SystemTransactionAmountOriginalCurrency]
      ,[_CDCDateKey]
      ,[_CDCTime]
--      ,[_DateCreated]
--      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_MergeKey_Limits]
      ,[_MergeKey_Policies]
      ,[_SourceSystemCode]
from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_Proc_GenChD]
except
select
      [LimitKey]
      ,[OriginalCurrencyKey]
      ,[PolicyKey]
      ,[PolicyReference]
      ,[AuditNumber]
      ,[ExternalReferenceIdentifier]
      ,[DoubleEntryItemSequence]
      ,[StatisticsLedgerSequence]
      ,[CreatedBy]
      ,[UserName]
      ,[DueDate]
      ,[FiscalPeriod]
      ,[TransactionEntryDate]
      ,[TransactionTypeKey]
      ,[TransactionTypeCategoryCode]
      ,[TransactionTypeCategory]
      ,[TransactionOriginalFlag]
      ,[TransactionDescription]
      ,[TransactionLineOfBusinessCode]
      ,[TransactionBranch]
      ,[AccountingToBaseExchangeRate]
      ,[OriginalToBaseExchangeRate]
      ,[PolicyWrittenExchangeRate]
      ,[ClientPolicyPremiumGrossOriginalCurrency]
      ,[ClientPolicyPremiumNetOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedGrossOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedNetOriginalCurrency]
      ,[InitialPolicyPremiumSEPIGrossOriginalCurrency]
      ,[InitialPolicyPremiumSEPINetOriginalCurrency]
      ,[InitialPolicyPremiumSignedGrossOriginalCurrency]
      ,[InitialPolicyPremiumSignedNetOriginalCurrency]
      ,[InitialPolicyPremiumWrittenGrossOriginalCurrency]
      ,[InitialPolicyPremiumWrittenNetOriginalCurrency]
      ,[SignedDownPremiumEstimatedNetOriginalCurrency]
      ,[SignedDownPremiumWrittenNetOriginalCurrency]
      ,[SystemTransactionAmountOriginalCurrency]
      ,[_CDCDateKey]
      ,[_CDCTime]
--      ,[_DateCreated]
--      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_MergeKey_Limits]
      ,[_MergeKey_Policies]
      ,[_SourceSystemCode]
from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_GenChD]  



--sprawdzenie last_action

select _lastAction,count(*) 
from  WAREHOUSE_Repository.WORK.PolicyPremiumTransactionsCoverage_GENIUS 
group by _lastAction



--Sprawdzanie dlaczego ?le si? procesuj? rekorsddy
--SIT 9.05.2024

--uruchomienie starego pakietu  EEK=245907
--drop table WAREHOUSE_Repository.STAGE.PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_GenChD_2459
--drop table WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_GenChD_2459]


--Kopia tabeli WORK WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS]  po processingu Nowa metoda r?cznie - testy nizgodno?ci
select *
INTO WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_GenChD_2459]  
FROM WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS] (nolock) 

--Kopia tabeli Stage
select *
INTO WAREHOUSE_Repository.STAGE.[PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_GenChD_2459]  
FROM WAREHOUSE_Repository.[STAGE].[PolicyPremiumTransactionsCoverage_GENIUS](nolock) 

/*
(9023954 rows affected)
(10274870 rows affected)
Completion time: 2024-05-09T12:19:01.4061129+02:00
*/


--uruchomienie nowego pakietu  EEK=245908

--Kopia tabeli Stage
select *
INTO WAREHOUSE_Repository.STAGE.[PolicyPremiumTransactionsCoverage_GENIUS_by_Proc_GenChD_2459]  
FROM WAREHOUSE_Repository.[STAGE].[PolicyPremiumTransactionsCoverage_GENIUS](nolock)  -- (10274870 rows affected) Completion time: 2024-05-09T12:29:17.0597112+02:00

exec WAREHOUSE_Repository.[dbo].[GenChangedData_PolicyPremiumTransactionsCoverage]  245908 (5:20)  --Procedura zawiera INNER Join w Update zamiast FULL OUTER  

--Kopia tabeli WORK WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS]  po processingu Nowa metoda r?cznie - testy nizgodno?ci
select *
INTO WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_Proc_GenChD_2459]  
FROM WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS] (nolock)  --(9023954 rows affected) Completion time: 2024-05-09T12:36:57.7508166+02:00

--Por�wnanie tabel WORKowych 
PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_GenChD_2459
PolicyPremiumTransactionsCoverage_GENIUS_by_Proc_GenChD_2459

!!! 0 Records przy zastosowaniu INNER JOIN 

select
      [LimitKey]
      ,[OriginalCurrencyKey]
      ,[PolicyKey]
      ,[PolicyReference]
      ,[AuditNumber]
      ,[ExternalReferenceIdentifier]
      ,[DoubleEntryItemSequence]
      ,[StatisticsLedgerSequence]
      ,[CreatedBy]
      ,[UserName]
      ,[DueDate]
      ,[FiscalPeriod]
      ,[TransactionEntryDate]
      ,[TransactionTypeKey]
      ,[TransactionTypeCategoryCode]
      ,[TransactionTypeCategory]
      ,[TransactionOriginalFlag]
      ,[TransactionDescription]
      ,[TransactionLineOfBusinessCode]
      ,[TransactionBranch]
      ,[AccountingToBaseExchangeRate]
      ,[OriginalToBaseExchangeRate]
      ,[PolicyWrittenExchangeRate]
      ,[ClientPolicyPremiumGrossOriginalCurrency]
      ,[ClientPolicyPremiumNetOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedGrossOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedNetOriginalCurrency]
      ,[InitialPolicyPremiumSEPIGrossOriginalCurrency]
      ,[InitialPolicyPremiumSEPINetOriginalCurrency]
      ,[InitialPolicyPremiumSignedGrossOriginalCurrency]
      ,[InitialPolicyPremiumSignedNetOriginalCurrency]
      ,[InitialPolicyPremiumWrittenGrossOriginalCurrency]
      ,[InitialPolicyPremiumWrittenNetOriginalCurrency]
      ,[SignedDownPremiumEstimatedNetOriginalCurrency]
      ,[SignedDownPremiumWrittenNetOriginalCurrency]
      ,[SystemTransactionAmountOriginalCurrency]
      ,[_CDCDateKey]
      ,[_CDCTime]
--      ,[_DateCreated]
--      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_MergeKey_Limits]
      ,[_MergeKey_Policies]
      ,[_SourceSystemCode]
INTO #PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_or_Proc_GenChD_Diff_2459
from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_GenChD_2459]  
Except 
SELECT 
      [LimitKey]
      ,[OriginalCurrencyKey]
      ,[PolicyKey]
      ,[PolicyReference]
      ,[AuditNumber]
      ,[ExternalReferenceIdentifier]
      ,[DoubleEntryItemSequence]
      ,[StatisticsLedgerSequence]
      ,[CreatedBy]
      ,[UserName]
      ,[DueDate]
      ,[FiscalPeriod]
      ,[TransactionEntryDate]
      ,[TransactionTypeKey]
      ,[TransactionTypeCategoryCode]
      ,[TransactionTypeCategory]
      ,[TransactionOriginalFlag]
      ,[TransactionDescription]
      ,[TransactionLineOfBusinessCode]
      ,[TransactionBranch]
      ,[AccountingToBaseExchangeRate]
      ,[OriginalToBaseExchangeRate]
      ,[PolicyWrittenExchangeRate]
      ,[ClientPolicyPremiumGrossOriginalCurrency]
      ,[ClientPolicyPremiumNetOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedGrossOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedNetOriginalCurrency]
      ,[InitialPolicyPremiumSEPIGrossOriginalCurrency]
      ,[InitialPolicyPremiumSEPINetOriginalCurrency]
      ,[InitialPolicyPremiumSignedGrossOriginalCurrency]
      ,[InitialPolicyPremiumSignedNetOriginalCurrency]
      ,[InitialPolicyPremiumWrittenGrossOriginalCurrency]
      ,[InitialPolicyPremiumWrittenNetOriginalCurrency]
      ,[SignedDownPremiumEstimatedNetOriginalCurrency]
      ,[SignedDownPremiumWrittenNetOriginalCurrency]
      ,[SystemTransactionAmountOriginalCurrency]
      ,[_CDCDateKey]
      ,[_CDCTime]
--      ,[_DateCreated]
--      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_MergeKey_Limits]
      ,[_MergeKey_Policies]
      ,[_SourceSystemCode]

from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_Proc_GenChD_2459]


select _mergeKey , * from #PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_or_Proc_GenChD_Diff_2459


--uruchomienie procedury z FULL OUTER
--truncate table WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS]

exec WAREHOUSE_Repository.[dbo].[GenChangedData_PolicyPremiumTransactionsCoverage]  245908 (11:52)  

select *
INTO WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_Proc_GenChD_2459_2]  
FROM WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS] (nolock)  --(9023954 rows affected) Completion time: 2024-05-09T13:14:19.3156781+02:00


select
      [LimitKey]
      ,[OriginalCurrencyKey]
      ,[PolicyKey]
      ,[PolicyReference]
      ,[AuditNumber]
      ,[ExternalReferenceIdentifier]
      ,[DoubleEntryItemSequence]
      ,[StatisticsLedgerSequence]
      ,[CreatedBy]
      ,[UserName]
      ,[DueDate]
      ,[FiscalPeriod]
      ,[TransactionEntryDate]
      ,[TransactionTypeKey]
      ,[TransactionTypeCategoryCode]
      ,[TransactionTypeCategory]
      ,[TransactionOriginalFlag]
      ,[TransactionDescription]
      ,[TransactionLineOfBusinessCode]
      ,[TransactionBranch]
      ,[AccountingToBaseExchangeRate]
      ,[OriginalToBaseExchangeRate]
      ,[PolicyWrittenExchangeRate]
      ,[ClientPolicyPremiumGrossOriginalCurrency]
      ,[ClientPolicyPremiumNetOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedGrossOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedNetOriginalCurrency]
      ,[InitialPolicyPremiumSEPIGrossOriginalCurrency]
      ,[InitialPolicyPremiumSEPINetOriginalCurrency]
      ,[InitialPolicyPremiumSignedGrossOriginalCurrency]
      ,[InitialPolicyPremiumSignedNetOriginalCurrency]
      ,[InitialPolicyPremiumWrittenGrossOriginalCurrency]
      ,[InitialPolicyPremiumWrittenNetOriginalCurrency]
      ,[SignedDownPremiumEstimatedNetOriginalCurrency]
      ,[SignedDownPremiumWrittenNetOriginalCurrency]
      ,[SystemTransactionAmountOriginalCurrency]
      ,[_CDCDateKey]
      ,[_CDCTime]
--      ,[_DateCreated]
--      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_MergeKey_Limits]
      ,[_MergeKey_Policies]
      ,[_SourceSystemCode]
INTO #PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_or_Proc_GenChD_Diff_2459_2
from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_GenChD_2459]  
Except 
SELECT 
      [LimitKey]
      ,[OriginalCurrencyKey]
      ,[PolicyKey]
      ,[PolicyReference]
      ,[AuditNumber]
      ,[ExternalReferenceIdentifier]
      ,[DoubleEntryItemSequence]
      ,[StatisticsLedgerSequence]
      ,[CreatedBy]
      ,[UserName]
      ,[DueDate]
      ,[FiscalPeriod]
      ,[TransactionEntryDate]
      ,[TransactionTypeKey]
      ,[TransactionTypeCategoryCode]
      ,[TransactionTypeCategory]
      ,[TransactionOriginalFlag]
      ,[TransactionDescription]
      ,[TransactionLineOfBusinessCode]
      ,[TransactionBranch]
      ,[AccountingToBaseExchangeRate]
      ,[OriginalToBaseExchangeRate]
      ,[PolicyWrittenExchangeRate]
      ,[ClientPolicyPremiumGrossOriginalCurrency]
      ,[ClientPolicyPremiumNetOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedGrossOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedNetOriginalCurrency]
      ,[InitialPolicyPremiumSEPIGrossOriginalCurrency]
      ,[InitialPolicyPremiumSEPINetOriginalCurrency]
      ,[InitialPolicyPremiumSignedGrossOriginalCurrency]
      ,[InitialPolicyPremiumSignedNetOriginalCurrency]
      ,[InitialPolicyPremiumWrittenGrossOriginalCurrency]
      ,[InitialPolicyPremiumWrittenNetOriginalCurrency]
      ,[SignedDownPremiumEstimatedNetOriginalCurrency]
      ,[SignedDownPremiumWrittenNetOriginalCurrency]
      ,[SystemTransactionAmountOriginalCurrency]
      ,[_CDCDateKey]
      ,[_CDCTime]
--      ,[_DateCreated]
--      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_MergeKey_Limits]
      ,[_MergeKey_Policies]
      ,[_SourceSystemCode]

from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_Proc_GenChD_2459_2]



select
      [LimitKey]
      ,[OriginalCurrencyKey]
      ,[PolicyKey]
      ,[PolicyReference]
      ,[AuditNumber]
      ,[ExternalReferenceIdentifier]
      ,[DoubleEntryItemSequence]
      ,[StatisticsLedgerSequence]
      ,[CreatedBy]
      ,[UserName]
      ,[DueDate]
      ,[FiscalPeriod]
      ,[TransactionEntryDate]
      ,[TransactionTypeKey]
      ,[TransactionTypeCategoryCode]
      ,[TransactionTypeCategory]
      ,[TransactionOriginalFlag]
      ,[TransactionDescription]
      ,[TransactionLineOfBusinessCode]
      ,[TransactionBranch]
      ,[AccountingToBaseExchangeRate]
      ,[OriginalToBaseExchangeRate]
      ,[PolicyWrittenExchangeRate]
      ,[ClientPolicyPremiumGrossOriginalCurrency]
      ,[ClientPolicyPremiumNetOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedGrossOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedNetOriginalCurrency]
      ,[InitialPolicyPremiumSEPIGrossOriginalCurrency]
      ,[InitialPolicyPremiumSEPINetOriginalCurrency]
      ,[InitialPolicyPremiumSignedGrossOriginalCurrency]
      ,[InitialPolicyPremiumSignedNetOriginalCurrency]
      ,[InitialPolicyPremiumWrittenGrossOriginalCurrency]
      ,[InitialPolicyPremiumWrittenNetOriginalCurrency]
      ,[SignedDownPremiumEstimatedNetOriginalCurrency]
      ,[SignedDownPremiumWrittenNetOriginalCurrency]
      ,[SystemTransactionAmountOriginalCurrency]
      ,[_CDCDateKey]
      ,[_CDCTime]
--      ,[_DateCreated]
--      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_MergeKey_Limits]
      ,[_MergeKey_Policies]
      ,[_SourceSystemCode]
INTO #PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_or_Proc_GenChD_Diff_2459_211
from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_Proc_GenChD_2459]  
Except 
SELECT 
      [LimitKey]
      ,[OriginalCurrencyKey]
      ,[PolicyKey]
      ,[PolicyReference]
      ,[AuditNumber]
      ,[ExternalReferenceIdentifier]
      ,[DoubleEntryItemSequence]
      ,[StatisticsLedgerSequence]
      ,[CreatedBy]
      ,[UserName]
      ,[DueDate]
      ,[FiscalPeriod]
      ,[TransactionEntryDate]
      ,[TransactionTypeKey]
      ,[TransactionTypeCategoryCode]
      ,[TransactionTypeCategory]
      ,[TransactionOriginalFlag]
      ,[TransactionDescription]
      ,[TransactionLineOfBusinessCode]
      ,[TransactionBranch]
      ,[AccountingToBaseExchangeRate]
      ,[OriginalToBaseExchangeRate]
      ,[PolicyWrittenExchangeRate]
      ,[ClientPolicyPremiumGrossOriginalCurrency]
      ,[ClientPolicyPremiumNetOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedGrossOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedNetOriginalCurrency]
      ,[InitialPolicyPremiumSEPIGrossOriginalCurrency]
      ,[InitialPolicyPremiumSEPINetOriginalCurrency]
      ,[InitialPolicyPremiumSignedGrossOriginalCurrency]
      ,[InitialPolicyPremiumSignedNetOriginalCurrency]
      ,[InitialPolicyPremiumWrittenGrossOriginalCurrency]
      ,[InitialPolicyPremiumWrittenNetOriginalCurrency]
      ,[SignedDownPremiumEstimatedNetOriginalCurrency]
      ,[SignedDownPremiumWrittenNetOriginalCurrency]
      ,[SystemTransactionAmountOriginalCurrency]
      ,[_CDCDateKey]
      ,[_CDCTime]
--      ,[_DateCreated]
--      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_MergeKey_Limits]
      ,[_MergeKey_Policies]
      ,[_SourceSystemCode]

from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_GenChD_2459]




select  _MergeKey,_EventExecutionKey,
ClientPolicyPremiumNetOriginalCurrency
,ClientPolicyPremiumGrossOriginalCurrency
,SignedDownPremiumEstimatedNetOriginalCurrency
,SignedDownPremiumEstimatedNetOriginalCurrency
,SignedDownPremiumWrittenNetOriginalCurrency, *
from WAREHOUSE_Repository.[STAGE].[PolicyPremiumTransactionsCoverage_GENIUS]  (nolock)
where _MergeKey in (
--'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][139972]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][1771]',
'[GENIUS][260291][009][02][002][001][Estimated][INITIAL][PRM][GROSS][AUD][2846679]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][139972]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][2004]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][272880]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][272881]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][2776]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][2783]',
'[GENIUS][000030][002][02][001][001][Estimated][INITIAL][COM][GROSS][USD][208759]',
'[GENIUS][000030][002][02][001][001][Estimated][INITIAL][COM][GROSS][USD][475114]',
'[GENIUS][000030][002][02][001][001][Estimated][INITIAL][COM][GROSS][USD][475207]',
'[GENIUS][000030][002][04][001][001][Estimated][INITIAL][PRM][GROSS][USD][208758]'
)



--Po re?zny wywo?aniu procedury
select  _MergeKey,_EventExecutionKey,
ClientPolicyPremiumNetOriginalCurrency
,ClientPolicyPremiumGrossOriginalCurrency
,SignedDownPremiumEstimatedNetOriginalCurrency
,SignedDownPremiumEstimatedNetOriginalCurrency
,SignedDownPremiumWrittenNetOriginalCurrency, *
from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS] (nolock)
where _MergeKey in (
--'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][139972]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][1771]',
'[GENIUS][260291][009][02][002][001][Estimated][INITIAL][PRM][GROSS][AUD][2846679]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][139972]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][2004]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][272880]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][272881]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][2776]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][2783]',
'[GENIUS][000030][002][02][001][001][Estimated][INITIAL][COM][GROSS][USD][208759]',
'[GENIUS][000030][002][02][001][001][Estimated][INITIAL][COM][GROSS][USD][475114]',
'[GENIUS][000030][002][02][001][001][Estimated][INITIAL][COM][GROSS][USD][475207]',
'[GENIUS][000030][002][04][001][001][Estimated][INITIAL][PRM][GROSS][USD][208758]'
)



select _MergeKey, _EventExecutionKey,
ClientPolicyPremiumNetOriginalCurrency
,ClientPolicyPremiumGrossOriginalCurrency
,SignedDownPremiumEstimatedNetOriginalCurrency
,SignedDownPremiumEstimatedNetOriginalCurrency
,SignedDownPremiumWrittenNetOriginalCurrency, *
from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_Proc_GenChD]
where _MergeKey in (
--'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][139972]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][1771]',
'[GENIUS][260291][009][02][002][001][Estimated][INITIAL][PRM][GROSS][AUD][2846679]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][2004]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][272880]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][272881]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][2776]',
'[GENIUS][000020][002][02][001][001][Estimated][ADJUSTMENT][PRM][GROSS][GBP][2783]',
'[GENIUS][000030][002][02][001][001][Estimated][INITIAL][COM][GROSS][USD][208759]',
'[GENIUS][000030][002][02][001][001][Estimated][INITIAL][COM][GROSS][USD][475114]',
'[GENIUS][000030][002][02][001][001][Estimated][INITIAL][COM][GROSS][USD][475207]',
'[GENIUS][000030][002][04][001][001][Estimated][INITIAL][PRM][GROSS][USD][208758]'
)


