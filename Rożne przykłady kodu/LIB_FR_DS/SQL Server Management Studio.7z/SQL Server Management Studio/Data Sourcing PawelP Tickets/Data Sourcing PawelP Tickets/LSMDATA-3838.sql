--UAT Weryfikacja istniej?cyh wpis�w dot MASTER_PUBLISH_DWH_DATABASES
--  Na tej podstaie budowany b?dzie skrypt tworz?cy nowy Master event MASTER_PUBLISH_DWH_DATABASES_APAC

use ETL_Control
select * from ETL_Control.[dbo].[Events] where [EventCode] = 'MASTER_PUBLISH_DWH_DATABASES'

select * from ETL_Control.dbo.[TaskGroups] where taskgroupcode like '%POSTDWLOADPROCESSING%'

select * from ETL_Control.dbo.[TaskGroupConnections] where taskgroupcode like '%POSTDWLOADPROCESSING%'


select * from ETL_Control.[dbo].[EventTaskGroups] where [EventCode] = 'MASTER_PUBLISH_DWH_DATABASES'


select * from ETL_Control.[dbo].[WorkflowConstraints] where [EventCode] = 'MASTER_PUBLISH_DWH_DATABASES'

select * from ETL_Control.[dbo].[Tasks] where taskgroupcode like '%POSTDWLOADPROCESSING%'

declare @iEventCode varchar(255)
set @iEventCode='POSTDWLOADPROCESSING_2'

			SELECT 
				tasks.TaskCode
			,	tasks.IsEnabled
			,	etg.TaskGroupCode
			,	etg.EventCode
			,	tasks.ETLServerCode
			,	tasks.ExecutionNodeName
			FROM 
				dbo.EventTaskGroups etg
			-- Left Join will pick up empty task groups
			LEFT OUTER JOIN 
				dbo.Tasks tasks 
			ON 
				etg.TaskGroupCode = tasks.TaskGroupCode
			AND
				tasks.IsEnabled = 1
			WHERE
				etg.EventCode = @iEventCode;

select * from Connections where 

--Depth

select * from ETL_Control.[dbo].[WorkflowConstraints] where [EventCode] ='MASTER_PUBLISH_DWH_DATABASES' 


select * from ETL_Control.[dbo].[GetTaskDepth] ('MASTER_PUBLISH_DWH_DATABASES') order by TaskDepth




--Testowanie Event�w na SIT
/*
Opis
-----------
Procedura _Event1_SP_PP - uruchamiana przez Event _Event1_SP_PP
Procedura _Event2_SP_PP - uruchamiana przez Event _Event2_SP_PP
Procedura _Event3_SP_PP - uruchamiana przez Event _Event3_SP_PP

Event MASTEREvent_PP wywo?uje 2 eventy podrz?dne
	Event1_TEST_PP
		Event1_SP_PP 10
		Event3_SP_PP 10
	Event2_TEST_PP
		Event2_SP_PP 15
		Event3_SP_PP 5


*/

--Tabele testowe
USE Staging_Misc
create table _test1_pp (id int identity (1,1), name varchar(100))
create table _test2_pp (id int identity (1,1), name varchar(100))
create table _test3_pp (id int identity (1,1), name varchar(100))
GO

CREATE PROCEDURE dbo._Event1_SP_PP
	@qty int
AS
	declare @i int =  1
	Declare @DesiredLength AS INT = 10;
	declare @name varchar(20)

	while @i <= @qty
	begin
		
		select @name = Lower(substring(replace(newID(), '-', ''), cast(RAND() * (31 - @DesiredLength) AS INT), @DesiredLength)) 
		Insert into _test1_pp values (@name)

		set @i = @i +1
	end
	
GO


CREATE PROCEDURE dbo._Event2_SP_PP
	@qty int
AS
	declare @i int =  1
	Declare @DesiredLength AS INT = 10;
	declare @name varchar(20)

	while @i <= @qty
	begin
		
		select @name = Lower(substring(replace(newID(), '-', ''), cast(RAND() * (31 - @DesiredLength) AS INT), @DesiredLength)) 
		Insert into _test2_pp values (UPPER(@name))

		set @i = @i +1
	end
	
GO

CREATE PROCEDURE dbo._Event3_SP_PP
	@qty int
AS
	declare @i int =  1
	Declare @DesiredLength AS INT = 10;
	declare @name varchar(20)

	while @i <= @qty
	begin
		
		select @name = Lower(substring(replace(newID(), '-', ''), cast(RAND() * (31 - @DesiredLength) AS INT), @DesiredLength)) 
		Insert into _test3_pp values (UPPER(@name))

		set @i = @i +1
	end
	
GO




--truncate table _test1_pp
--truncate table _test2_pp

select * from _test1_pp
select * from _test2_pp

/* 

drop procedure _Event1_SP_PP
drop procedure _Event2_SP_PP
drop procedure _Event3_SP_PP
drop table _test1_pp
drop table _test2_pp

*/

select * from ETL_Control.dbo.[Connections] where Connectioncode='STAGINGMISC'


select * from [dbo].[TaskTypes]

select * from layers

select * from [dbo].[SourceSystems]


