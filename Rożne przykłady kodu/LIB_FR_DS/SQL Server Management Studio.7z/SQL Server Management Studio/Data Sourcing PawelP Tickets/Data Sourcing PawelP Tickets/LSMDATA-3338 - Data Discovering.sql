
--Zapytanie do ZUMY z uwzgl?dnieniem filtr�w 
lsm_companies = ["CHILE", "ARGNTA", "MLYON", "BRZAFFIL", "LIBSEGBR", "MLYOFF", "COLOMBIA", "COL", "LMLATAM", "CHL", 
                "BRASIL", "PERU", "ECUADOR", "LSILATAM", "LIUILATM", "LIBSEGPE", "MEXICO", "SING", "SOF", "AUS", "HK",
                "BENELUX", "BHAMUK", "BRISTLUK", "COLOGNUK", "DUBAI", "DUBUK", "GLASGOUK", "HAMBRGUK", "IRELC", "LEEDSUK",
                "LMUK", "MANUK", "MILANUK", "PARISUK", "SOEASTUK", "SPAIN", "SWISSUK", "VISIONUW", "IRE", "LUXUK",
                "NORWAY","SWEDEN","BELGIUM"]
lsm_products = ["EQUINE", "TPR", "TERROR" , "ENGNR", "HVY", "OFNRG", "ONNRG", "INLM", "INLMQ", "COC", "ONNRGQ",
                "OFNRGQ", "HVYQ", "ENGNRQ"]
lsm_departments = ["GLA", "GUA", "GUC", "GUD", "SD5"]
lsm_west_branches = ["3MIAMI", "5MIAMI", "4PAULO", "3PR"]

--Rekordy odfiltrowane 2 360 601 z 8 911 288
SELECT *
into #Zuma_POLicies
FROM BI_LZ.GEnius.ZUMA z
WHERE (z.MACNCD in ('CHILE', 'ARGNTA', 'MLYON', 'BRZAFFIL', 'LIBSEGBR', 'MLYOFF', 'COLOMBIA', 'COL', 'LMLATAM', 'CHL', 
                'BRASIL', 'PERU', 'ECUADOR', 'LSILATAM', 'LIUILATM', 'LIBSEGPE', 'MEXICO', 'SING', 'SOF', 'AUS', 'HK',
                'BENELUX', 'BHAMUK', 'BRISTLUK', 'COLOGNUK', 'DUBAI', 'DUBUK', 'GLASGOUK', 'HAMBRGUK', 'IRELC', 'LEEDSUK',
                'LMUK', 'MANUK', 'MILANUK', 'PARISUK', 'SOEASTUK', 'SPAIN', 'SWISSUK', 'VISIONUW', 'IRE', 'LUXUK',
                'NORWAY','SWEDEN','BELGIUM') --companies
		OR z.MAMAPC in ('EQUINE', 'TPR', 'TERROR' , 'ENGNR', 'HVY', 'OFNRG', 'ONNRG', 'INLM', 'INLMQ', 'COC', 'ONNRGQ','OFNRGQ', 'HVYQ', 'ENGNRQ') --lsm_products
		OR z.MADPCD in ('GLA', 'GUA', 'GUC', 'GUD', 'SD5') --lsm_departments
		OR z.MAMABN in('3MIAMI', '5MIAMI', '4PAULO', '3PR') --lsm_west_branches
		) 
AND NOT (z.MAMAPC ='TPR' AND z.MACNCD in ('III', 'ISIC'))
AND (LEFT(z.MAMABN, 1) <> '7' OR z.MAMAPC NOT IN ('INLM', 'INLMQ'))
--end of Python Filtes
AND z.MAMAIO = '1' --po przefiltrowaniu obecnym zawieraj? 1 i 2



--Zapytanie kt�re ma zwr�ci? policy reasekuracyjne
SELECT DISTINCT top 10  pol.MAMANU, pol.MAMASE, cov.MAMANU, cov.MAMASE
FROM #Zuma_Policies pol
INNER JOIN BI_LZ.GEnius.ZURI map
    ON  pol.MAMANU = map.RIMANU
    AND pol.MAMASE = map.RIMASE
INNER JOIN BI_LZ.GEnius.ZUMA cov
    ON map.RIRIMN = cov.MAMANU
    AND map.RIRIMS = cov.MAMASE


--checking productcodes
select count(*) from #Zuma_Policies -- bez rozszerzonego filtra na produkty RI ilo??: 2360718


select distinct MAMAPC from #Zuma_Policies where MAMAPC in ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3') --jest tylko FAC, QS i XLS
select count(*) FROM BI_LZ.GEnius.ZUMA where MAMAPC in ('FAC', 'QS', 'SRP', 'XSL')  --130008


SELECT *
into #Zuma_POLicies_inc_RI
FROM BI_LZ.GEnius.ZUMA z
WHERE (z.MACNCD in ('CHILE', 'ARGNTA', 'MLYON', 'BRZAFFIL', 'LIBSEGBR', 'MLYOFF', 'COLOMBIA', 'COL', 'LMLATAM', 'CHL', 
                'BRASIL', 'PERU', 'ECUADOR', 'LSILATAM', 'LIUILATM', 'LIBSEGPE', 'MEXICO', 'SING', 'SOF', 'AUS', 'HK',
                'BENELUX', 'BHAMUK', 'BRISTLUK', 'COLOGNUK', 'DUBAI', 'DUBUK', 'GLASGOUK', 'HAMBRGUK', 'IRELC', 'LEEDSUK',
                'LMUK', 'MANUK', 'MILANUK', 'PARISUK', 'SOEASTUK', 'SPAIN', 'SWISSUK', 'VISIONUW', 'IRE', 'LUXUK',
                'NORWAY','SWEDEN','BELGIUM') --companies
		OR z.MAMAPC in ('EQUINE', 'TPR', 'TERROR' , 'ENGNR', 'HVY', 'OFNRG', 'ONNRG', 'INLM', 'INLMQ', 'COC', 'ONNRGQ','OFNRGQ', 'HVYQ', 'ENGNRQ', 'FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3') --lsm_products
		OR z.MADPCD in ('GLA', 'GUA', 'GUC', 'GUD', 'SD5') --lsm_departments
		OR z.MAMABN in('3MIAMI', '5MIAMI', '4PAULO', '3PR') --lsm_west_branches
		) 
AND NOT (z.MAMAPC ='TPR' AND z.MACNCD in ('III', 'ISIC'))
AND (LEFT(z.MAMABN, 1) <> '7' OR z.MAMAPC NOT IN ('INLM', 'INLMQ'))
--end of Python Filtes

select count(*) from #Zuma_POLicies_inc_RI -- z rozszerzonym filtrem na produkty RI ilo??: 2429134 - 2360718 (bez RI) = 68416

select top 100  concat(mamanu, ' ', mamase) from #Zuma_POLicies_inc_RI 

select count(distinct concat(mamanu, mamase)) from #Zuma_POLicies_inc_RI  --2429134

select count(distinct MAPORF) from #Zuma_POLicies_inc_RI --2429066

select * from #Zuma_POLicies_inc_RI where maporf in ( --68 wierszy
	select MAPORF
	from #Zuma_POLicies_inc_RI 
	group by MAPORF
	having count(*)>1
)






--Analiza danych na DEV - Baza PP_TestDB

select distinct MAMANU1, MAMASE1 from [dbo].[LSMDATA_3338_BI_ZL_RI_Policy]


select 'UAT_missing',  count(distinct concat(bi.mamanu1,' ',bi.mamase1))
from [dbo].[LSMDATA_3338_BI_ZL_RI_Policy] bi
left join LSMDATA_3338_UAT_WR_Covers wr on wr.coverreference=concat(bi.mamanu1,' ',bi.mamase1)
where coverreference is null


select 'UAT_existing',  count(distinct coverreference)
from [dbo].[LSMDATA_3338_BI_ZL_RI_Policy] bi
left join LSMDATA_3338_UAT_WR_Covers wr on wr.coverreference=concat(bi.mamanu1,' ',bi.mamase1)
where coverreference is not null


select 'PROD_missing',  count(distinct concat(bi.cov_mamanu,' ',bi.cov_mamase))
from [dbo].[LSMDATA_3338_PROD_BI_ZL_RI_Policy] bi
left join LSMDATA_3338_PROD_WR_Covers wr on wr.coverreference=concat(bi.cov_mamanu,' ',bi.cov_mamase)
where coverreference is null


select 'PROD_existing',  count(distinct coverreference)
from [dbo].[LSMDATA_3338_PROD_BI_ZL_RI_Policy] bi
left join LSMDATA_3338_PROD_WR_Covers wr on wr.coverreference=concat(bi.cov_mamanu,' ',bi.cov_mamase)
where coverreference is not null




select top 1000 *
from [dbo].[LSMDATA_3338_PROD_BI_ZL_RI_Policy] bi
left join LSMDATA_3338_PROD_WR_Covers wr on wr.coverreference=concat(bi.cov_mamanu,' ',bi.cov_mamase)
where coverreference is  null
order by bi.pol_mamanu desc, bi.pol_mamase desc


----Znale?? powi?zania mi?dzy Policies a Covers, Limits, sprawdzi? jak to jest powi?zane
------------------------------------------------------------------------------------------



select distinct top 100  MAMANU_POL, MAMASE_POL, mamanu, mamase, maporf,LastUpdatedDate,* 
from #ZUMA_RI_Policies zp order by zp.LastUpdatedDate desc

/* Polisy RI
MAMANU_POL	MAMASE_POL	mamanu	mamase	maporf	LastUpdatedDate
ACV3TN	001	ACV3TM	001	811013505401F2	2024-05-30 17:14:19.000
ACV3O5	001	ACV3O4	001	811013390701T1	2024-05-29 22:58:35.000
ACVRFW	003	ACV3FC	001	811012756203T1	2024-05-28 17:45:08.000
ABXOC3	005	ACV25G	001	100038952905T1	2024-05-27 04:59:26.000
ACV2EX	001	ACV2EW	001	811013434601T1	2024-05-22 03:27:48.000
ACV2ES	001	ACV2ER	001	811013444201F2	2024-05-22 02:53:24.000
ACV2ES	001	ACV2EQ	001	811013444201F1	2024-05-22 02:52:49.000
ACV195	001	ACV194	001	811013421001T1	2024-05-21 15:58:48.000
ACV18E	001	ACV18D	001	811013391301T2	2024-05-21 09:53:54.000
ACV18E	001	ACV18C	001	811013391301T1	2024-05-21 09:53:24.000
*/


--sprawdzenie tabel pozosta?ych
select mamanu, mamase, zuni.LastUpdatedDate, * 
from  Genius.ZUNI 
INNER JOIN Genius.ZUMA ON ZUNI.NIMANU = ZUMA.MAMANU AND ZUNI.NIMASE = ZUMA.MAMASE
where zuma.mamanu='ACV3TM' and zuma.mamase='001'


select mamanu, mamase, zuni.LastUpdatedDate, header_change_seq, header_timestamp, * 
from  Genius.ZUNI_log zuni
INNER JOIN Genius.ZUMA ON ZUNI.NIMANU = ZUMA.MAMANU AND ZUNI.NIMASE = ZUMA.MAMASE
where zuma.mamanu='ACV3TM' and zuma.mamase='001'
order by zuni.header_change_seq desc


SELECT DISTINCT ZNNU.* 
FROM Genius.ZNNU{log} 
INNER JOIN Genius.ZUNI ON ZNNU.NUNACD = ZUNI.NINACD INNER JOIN Genius.ZUMA ".format(log=log_table) +
	                "ON ZUNI.NIMANU = ZUMA.MAMANU AND ZUNI.NIMASE = ZUMA.MAMASE",





--Przyk?adowe polisy na Produkcji (mo?e s? na UAT)
SELECT top 1000 pol.MAMANU, pol.MAMASE, cov.MAMANU cov_MAMANU, cov.MAMASE cov_MAMASE, cov.*
--intu 
FROM #Zuma_Policies_prod pol
INNER JOIN BI_LZ.GEnius.ZURI map
    ON  pol.MAMANU = map.RIMANU
    AND pol.MAMASE = map.RIMASE
LEFT JOIN BI_LZ.GEnius.ZUMA cov
    ON map.RIRIMN = cov.MAMANU
    AND map.RIRIMS = cov.MAMASE
where pol.mamanu in ('ACYMD9' ,'ACXSC0','ACZZ9E')
order by pol.mamanu, pol.MAMASE



--ZUMA SCOPE

SELECT TOP (1000) [MAMANU]
      ,[MAMASE]
      ,[MACNCD]
      ,[MAPORF]
      ,[InwardsOutwardsFlag]
      ,[IsLSMFlag]
      ,[HFullFlag]
  FROM [BI_LZ].[Genius].[ZUMAScope]
