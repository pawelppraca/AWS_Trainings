﻿--Rozpoznanie LSMDATA-4561


use Warehouse_Repository

select pol.BranchCode, count(*) as [RowCount]
	from dbo.Policies pol
	join dbo.Companies com on pol.CompanyKey = com.CompanyKey
where 
	pol._SourceSystemCode = 'GENIUS'
	and com.CompanyCode in ('SWEDEN','NORWAY')
group by pol.BranchCode


select CompanyKey,* 
from dbo.Policies pol where PolicyReference in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')
select top 10 * from dbo.Quotes  where QuoteReference in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')



select qte.BranchName, count(*) as [RowCount]
	from dbo.Quotes qte
	join dbo.Companies com on qte.CompanyKey = com.CompanyKey
where qte._CurrentFlag = 1
	and qte._SourceSystemCode = 'GENIUS'
	and com.CompanyCode in ('SWEDEN','NORWAY')
group by qte.BranchName

select * from dbo.Companies where CompanyCode in ('SWEDEN','NORWAY')


select top 10 qte.BranchName, *
from dbo.Quotes qte
where quotereference='24ACVJCM'



use Warehouse_Repository

select	pol.UnderwriterReference,
		pol.IndustryCode,
		pol.IndustryName,
		pol.IndustryMinorCode,
		pol.IndustryMinorName,
		pol.LineOfBusinessCode
	from dbo.Policies pol
where _CurrentFlag = 1
and UnderwriterReference in ('SKACVLH2001')
IndustryCode



--Data flow
----------------
/*
--Companies
RDS.ODS_Genius.dbo.Warehouse_Companies(view) -> DIMENSION_GENIUS_Companies_DWH.dtsx -> Warehouse_Repository.dbo.Companies (tab) -> 

--Policies
RDS.ODS_Genius.dbo.Warehouse_Policies(view)  -> DIMENSION_GENIUS_Policies_(DWH).dtsx (dużo lookupów) -> Warehouse_Repository.dbo.Policies (tab)


--Quotes
RDS.ODS_Genius.dbo.Warehouse_Quotes(view)  -> DIMENSION_GENIUS_Quotes_(DWH).dtsx  -> Warehouse_Repository.dbo.Quotes (tab)

*/

--View RDS.ODS_Genius.dbo.Warehouse_Companies

	SELECT DISTINCT 
	--Attributes
		CAST(ni.NameCodeKey AS NVARCHAR(50)) AS CompanyCode
	,	COALESCE(name.ListName, N'<<Unknown>>') AS CompanyName
	,	CAST(COALESCE(cg.CompanyGroupName, N'<<Unknown>>') AS NVARCHAR(255)) AS CompanyGroupName
	--System Columns
	,	UPPER(CAST(N'[' + ni._SourceSystemCode + N'][' + ni.NameCodeKey + N']' AS NVARCHAR(255))) AS _MergeKey
	,	ni._SourceSystemCode
	,	ni.NameCode
	FROM
		ODS_GENIUS.dbo.Map_NameInvolvement_ZUNI ni
	LEFT JOIN
		ODS_GENIUS.dbo.Map_Name_ZNNA name
	ON
		ni.NameCodeKey = name.NameCodeKey
	LEFT OUTER JOIN
		ODS_GENIUS.dbo.Map_CompanyGroups cg
	ON
		name.NameCode = cg.CompanyCode
	AND 
		cg._LastAction <> N'D' 
	where 
	CAST(ni.NameCodeKey AS NVARCHAR(50))  in ('SWEDEN','NORWAY')




--Polisy
--Widok RDS.ODS_GENIUS.[dbo].[Warehouse_Policies]

Widok bierze dane z tabel



--DANE TESTOWE BI_LZ (UAT)

select * from Genius.ZUMA where MAPORF in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')

select MAMABN, MACNCD, MAMAS2, * from Genius.ZUMA where MAMABN in ('OSLO','STOCKHLM') or MACNCD in ('NORWAY','SWEDEN') or MAMAS2 in ('NORWAY','SWEDEN')

/*
Norway
24ACVJCM                          Q
NOACVJCN001                  P
NOACVJFJ001                    P

Sweden
24ACVJCP                           Q
SKACVJCQ001                    P
SKACVJFM001                   P
SKACVLH2001                    P

*/


SELECT DDEY.*,ZUMA.MACNCD AS CompanyCode
FROM Genius.DDEY 
INNER JOIN Genius.ZUMA ON DDEY.EYAOCD = ZUMA.MAPORF


select * from ZUMA where MAPORF in (
'24ACVJCM',
'NOACVJCN001',
'24ACVJCP',
'SKACVJCQ001',
'NOACVJFJ001',
'SKACVJFM001'
)




select * from Genius.ZUMA where MAPORF in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')

select * from Genius.ZUMA where MAMABN in ('OSLO','STOCKHLM') or MACNCD in ('NORWAY','SWEDEN') or MAMAS2 in ('NORWAY','SWEDEN')

select * from Genius.ZUNI where NINACD in ('NORWAY','SWEDEN') 


SELECT ZUMA.MACNCD 
,MAMAPC,MADPCD,MAMABN
,'ZUNI_TAB-->',ZUNI.*
FROM Genius.ZUNI 
INNER JOIN Genius.ZUMA ON ZUNI.NIMANU = ZUMA.MAMANU AND ZUNI.NIMASE = ZUMA.MAMASE
where MAPORF in (
'24ACVJCM',
'NOACVJCN001',
'24ACVJCP',
'SKACVJCQ001',
'NOACVJFJ001',
'SKACVJFM001'
) 
or MACNCD='BENELUX'


select top 100 * from Genius.ZSE5 (nolock) where E5CNCD in (
'NORWAY',
'SWEDEN'
)





select MAMABN, MACNCD, MAMAS2, * from Genius.ZUMA where MAPORF in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')

select MAMABN, MACNCD, MAMAS2, * from Genius.ZUMA where MAMABN in ('OSLO','STOCKHLM') or MACNCD in ('NORWAY','SWEDEN') or MAMAS2 in ('NORWAY','SWEDEN')


select top 1000 E5CNCD,* from Genius.ZSE5

select distinct E5CNCD from Genius.ZSE5 (nolock) where E5CNCD in ('OSLO','STOCKHLM') or E5CNCD in ('NORWAY','SWEDEN')

select distinct BLMHCD from Genius.ZABL (nolock) where BLMHCD like '%OS%' or BLMHCD like '%STOC%' or BLMHCD like '%NOR%' or BLMHCD like '%SWE%'


select distinct BLMHCD  from Genius.ZABL (nolock) where BLB541 = 'BANK'
AND BLMHCD not IN 
						 ('ICBENX','ICBHAM','ICBRSTOL','ICCOLOG','ICDUB','ICDUBAI','ICDUBUK','ICGLASG','ICHAMBUR','ICIRE','ICIRELC',
						  'ICLEEDS','ICLMIE','ICLMUK','ICLMUKHA','ICLOLEED','ICLON','ICLONBEN','ICLONBHM','ICLOND','ICLONDON','ICLONGLA',
						  'ICLONMIL','ICLONPAR','ICMANUK','ICMILAN','ICOLON','ICPARIS','ICSPAIN','ICSPALON','ICSWISS','ICVISION','INTERCO',
						  'ICBHAM','ICDUB','ICGLASG','ICHAMBUR','ICLEEDS','ICLMUKHA','ICLOLEED','ICLON','ICLONBHM','ICLONGLA','ICLONMIL',
						  'ICMILAN','ICSEAST','ICTRANS','IRINTRE0','IRINTRE1','IRINTRE2','IRINTRE3','IRINTRE4','IRSURETY','LIICIC', 'IC-LMUK', 'IC-LUXUK'

						  ) 
						  order by BLMHCD

select BLMHCD, BLB541,* 
from Genius.ZUMA zuma
join Genius.ZSE5 zse5 on zse5.E5MANU = zuma.MAMANU and zse5.E5MASE = zuma.MAMASE
join Genius.ZABL zabl on zabl.BLMPNB = zse5.E5MPNB
where zuma.MAPORF in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')


--UAT TEST

select top 10 * from ODS_GENIUS.dbo.zuma (nolock)
where MAPORF in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')


select MAMABN, MACNCD, MAMAS2, * 
--update mamati='Test for NORWAY.'
from Genius.ZUMA where MAPORF in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')
and MAMANU='ACVJCN'


--RDS-SIT - Próbne Polisy



--Przed przeladowaniem

select top 10 * from ODS_GENIUS.dbo.zuma (nolock)
where MAPORF in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')


select count(*) from ODS_GENIUS.[dbo].[ZUMA] --2357914
select count(*) from ODS_GENIUS.[dbo].[Map_Master_ZUMA] --2357914
select count(*) from ODS_GENIUS.[WORK].[ZUMA] --27

select * from ODS_GENIUS.[WORK].[ZUMA]

select count(*) from ODS_GENIUS.[dbo].[Map_StatisticsPosting_ZSE5] --26939538
select count(*) from ODS_GENIUS.[dbo].[ZSE5] -- 26939538
select count(*) from ODS_GENIUS.[WORK].[ZSE5] --3


select top 100 * from Genius.ZSE5 (nolock) where E5CNCD in (
'NORWAY',
'SWEDEN'
)








select top 1000 mst.MAPORF, mst.MAMAIO 
--	cover.MAPORF, cover.MAMAIO, cover.MACNCD, cover.MAMAPC, cover.MADPCD, cover.MAMABN
from Genius.ZUMA mst
--left outer join Genius.ZURI ri
--	on mst.MAMANU = ri.RIMANU
--	and mst.MAMASE = ri.RIMASE
--left outer join Genius.ZUMA cover
--	on ri.RIRIMN = cover.MAMANU
--	and ri.RIRIMS = cover.MAMASE
where 
-- mst filter
        (
            mst.MACNCD in ('CHILE', 'ARGNTA', 'MLYON', 'BRZAFFIL', 'LIBSEGBR', 'MLYOFF', 'COLOMBIA', 'COL', 'LMLATAM', 'CHL', 
                'BRASIL', 'PERU', 'ECUADOR', 'LSILATAM', 'LIUILATM', 'LIBSEGPE', 'MEXICO', 'SING', 'SOF', 'AUS', 'HK',
                'BENELUX', 'BHAMUK', 'BRISTLUK', 'COLOGNUK', 'DUBAI', 'DUBUK', 'GLASGOUK', 'HAMBRGUK', 'IRELC', 'LEEDSUK',
                'LMUK', 'MANUK', 'MILANUK', 'PARISUK', 'SOEASTUK', 'SPAIN', 'SWISSUK', 'VISIONUW', 'IRE', 'LUXUK','SWEDEN','NORWAY')
            OR mst.MAMAPC in ('EQUINE', 'TPR', 'TERROR' , 'ENGNR', 'HVY', 'OFNRG', 'ONNRG', 'INLM', 'INLMQ', 'COC', 'ONNRGQ',
                'OFNRGQ', 'HVYQ', 'ENGNRQ')
            OR mst.MADPCD in ('GLA', 'GUA', 'GUC', 'GUD', 'SD5')
            OR mst.MAMABN in ('3MIAMI', '5MIAMI', '4PAULO', '3PR')
        )
        AND
        NOT (mst.MAMAPC in ('TPR') 
			AND mst.MACNCD in ('III', 'ISIC')
			)
        AND (
            NOT left(mst.MAMABN, 1) = '7'
            OR NOT mst.MAMAPC in ('INLM', 'INLMQ')
			)
and 
CONCAT(mst.MAMANU, mst.MAMASE) in (
'ACVJCN001','ACVJFJ001','ACVJCQ001','ACVJFM001'
)



select top 10 * from ODS_GENIUS.dbo.zuma (nolock)
where MAPORF in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001','24ACVJCM')


select top 100 * from ODS_GENIUS.dbo.ZSE5 (nolock) where E5CNCD in ('NORWAY','SWEDEN') --To jest w UAT RDS


--POlisy Są w Warehouse

select * from ODS_GENIUS.dbo.[Map_Master_ZUMA_build] where  MasterReferenceKey in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')
select MasterReference,MasterReferenceKey,* from ODS_GENIUS.dbo.[Map_Master_ZUMA] where  MasterReferenceKey in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')

select * from ODS_GENIUS.dbo.warehouse_policies where  PolicyReference in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001')



--Brakuje Companies

select top 10 * 
	FROM
		ODS_GENIUS.dbo.[Warehouse_Companies] where CompanyCode in ('NORWAY','SWEDEN')

select top 10 NINACD,* FROM dbo.ZUNI ni where NINACD in ('NORWAY','SWEDEN')



/*Quotes*/ 
--Dane pochodza z ZUMA ale nie ma ich w Quotes, bo nie ma danych z widoku  MAP_MASTER_ZUMA w ktore w polu MasterInternalStatus1 mają wartośc 2 - ta wartość definiuje Quotes
--Sprawdzenie Quotes - brakuje 

select * from ODS_GENIUS.[dbo].[Warehouse_Quotes] where QuoteReference in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001','24ACVJCM')


select MasterInternalStatus1,* 
from ODS_GENIUS.dbo.[Map_Master_ZUMA_build] where  MasterReferenceKey in ('SKACVJFM001','SKACVJCQ001','NOACVJCN001','NOACVJFJ001','24ACVJCM')


