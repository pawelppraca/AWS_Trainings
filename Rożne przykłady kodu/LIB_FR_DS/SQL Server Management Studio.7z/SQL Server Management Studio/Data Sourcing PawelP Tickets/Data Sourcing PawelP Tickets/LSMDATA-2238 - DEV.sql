select * from ETL_Control.dbo.connections where ConnectionCode like '%rad%'

select ExecutableName  Paczka_SSIS,* from [dbo].[Tasks] where taskcode='Control_MDS_LogPropagateEntriesODSToWarehouse'

select ExecutableName  Paczka_SSIS,* from [dbo].[Tasks] where taskcode like '%cbiclaim%'

select ExecutableName  Paczka_SSIS,* 
--update t set IsEnabled = 1
from [dbo].[Tasks] t where taskcode like '%LOAD_GENIUS_CBIClaimListing%'



select top 10  * from [dbo].[CBIClaimListing_PRD]


--rozszerzenie tabeli 
alter table [dbo].[CBIClaimListing_aws] add 
	[Policy number]					NVARCHAR(50)	NULL,
	[Coverage Name]					NVARCHAR(255)	NULL,
	[Business Sub Component]		NVARCHAR(100)	NULL,
	[Insured Name]					NVARCHAR(300)	NULL,
	[Location ID]					NVARCHAR(50)	NULL,
--	[Branch]						NVARCHAR(50)	NULL,
	[Broker Name]					NVARCHAR(200)	NULL,
	[Underwriter]					NVARCHAR(100)	NULL,
	[Risk engineer]					NVARCHAR(100)	NULL,
	[LIU Share]						FLOAT	NULL,
	[Attachment Point] 				INTEGER	NULL,
	[Total Inr curr(Gross)]			FLOAT	NULL,
	[Deductible Amount] 			INTEGER	NULL
	
	--Zmiana Tabeli dot wymagan LSMDATA-2238
alter table [dbo].[CBIClaimListing_aws] add [Business Component] NVARCHAR(100)	NULL

alter table [RADM].[dbo].[CBIClaimListing_aws] alter column [Insured Name] NVARCHAR(200)	NULL
alter table [RADM].[dbo].[CBIClaimListing_aws] alter column [Coverage Name] NVARCHAR(100)	NULL
alter table [RADM].[dbo].[CBIClaimListing_aws] alter column [Location ID] NVARCHAR(100)	NULL
alter table [RADM].[dbo].[CBIClaimListing_aws] alter column [Underwriter] NVARCHAR(200)	NULL
alter table [RADM].[dbo].[CBIClaimListing_aws] alter column [Total Inr curr(Gross)] NUMERIC(38,4)	NULL
alter table [RADM].[dbo].[CBIClaimListing_aws] alter column [Risk engineer] NVARCHAR(200)	NULL
alter table [RADM].[dbo].[CBIClaimListing_aws] alter column [LIU Share] NUMERIC(28,4)	NULL
alter table [RADM].[dbo].[CBIClaimListing_aws] drop column [Deductible Amount] 
alter table [RADM].[dbo].[CBIClaimListing_aws] drop column [Attachment Point]  








	--zmiana widoku: [IDS].[CBIClaimListing_UAT]
	--zmiana widoku: [IDS].[CBIClaimListing]



--Rozszerzenie tabeli


	--Zmiana Tabeli dot wymagan LSMDATA-2238
alter table Staging_Genius.[dbo].[CBIClaimListing] add [Business Component] NVARCHAR(100)	NULL

alter table Staging_Genius.[dbo].[CBIClaimListing] alter column [Insured Name] NVARCHAR(200)	NULL
alter table Staging_Genius.[dbo].[CBIClaimListing] alter column [Coverage Name] NVARCHAR(100)	NULL
alter table Staging_Genius.[dbo].[CBIClaimListing] alter column [Location ID] NVARCHAR(100)	NULL
alter table Staging_Genius.[dbo].[CBIClaimListing] alter column [Underwriter] NVARCHAR(200)	NULL
alter table Staging_Genius.[dbo].[CBIClaimListing] alter column [Total Inr curr(Gross)] NUMERIC(38,4)	NULL
alter table Staging_Genius.[dbo].[CBIClaimListing] alter column [Risk engineer] NVARCHAR(200)	NULL
alter table Staging_Genius.[dbo].[CBIClaimListing] alter column [LIU Share] NUMERIC(28,4)	NULL
alter table Staging_Genius.[dbo].[CBIClaimListing] drop column [Deductible Amount] 
alter table Staging_Genius.[dbo].[CBIClaimListing] drop column [Attachment Point]  




--Modify Packages:
	EXTRACT_GENIUS_CBIClaimListing.dtsx


alter table ODS_Genius.[dbo].[CBIClaimListing] add 
	[Policy number]					NVARCHAR(50)	NULL,
	[Business Sub Component]				NVARCHAR(100)	NULL,
	[Insured Name]					NVARCHAR(300)	NULL,
	[Location ID]						NVARCHAR(50)	NULL,
	[Branch]						NVARCHAR(50)	NULL,
	[Broker Name]						NVARCHAR(200)	NULL,
	[Underwriter]						NVARCHAR(100)	NULL,
	[Risk engineer]					NVARCHAR(100)	NULL,
	[LIU Share]						FLOAT	NULL,
	[Attachment Point] 					INTEGER	NULL,
	[Coverage Name]					NVARCHAR(255)	NULL,
	[Total Inr curr(Gross)]				FLOAT	NULL,
	[Deductible Amount] 					INTEGER	NULL


alter table ODS_Genius.[dbo].[CBIClaimListing] add 
    [Cause of Loss 4 Other Description]     NVARCHAR(256) NULL,
    [Cause Of Loss5]                        NVARCHAR(250) NULL,
    [Loss Code Group]                       NVARCHAR(250) NULL,
    [Organization]                          NVARCHAR(250) NULL,
    [Cyber Consideration]                   NVARCHAR(250) NULL,
    [Cyber Consideration Other Description] NVARCHAR(256) NULL,
    [Ransomware Aspect]                     NVARCHAR(250) NULL


--Zmiana Tabeli dot wymagan LSMDATA-2238
alter table ODS_Genius.[dbo].[CBIClaimListing] add [Business Component] NVARCHAR(100)	NULL

alter table ODS_Genius.[dbo].[CBIClaimListing] alter column [Insured Name] NVARCHAR(200)	NULL
alter table ODS_Genius.[dbo].[CBIClaimListing] alter column [Coverage Name] NVARCHAR(100)	NOT NULL
alter table ODS_Genius.[dbo].[CBIClaimListing] alter column [Location ID] NVARCHAR(100)	NULL
alter table ODS_Genius.[dbo].[CBIClaimListing] alter column [Underwriter] NVARCHAR(200)	NULL
alter table ODS_Genius.[dbo].[CBIClaimListing] alter column [Total Inr curr(Gross)] NUMERIC(38,4)	NULL
alter table ODS_Genius.[dbo].[CBIClaimListing] alter column [Risk engineer] NVARCHAR(200)	NULL
alter table ODS_Genius.[dbo].[CBIClaimListing] alter column [LIU Share] NUMERIC(28,4)	NULL
alter table ODS_Genius.[dbo].[CBIClaimListing] drop column [Deductible Amount] 
alter table ODS_Genius.[dbo].[CBIClaimListing] drop column [Attachment Point]  

--Zmiana klucza glownego
ALTER TABLE ODS_Genius.[dbo].[CBIClaimListing] DROP CONSTRAINT [PK_Claim Number]

ALTER TABLE ODS_Genius.[dbo].[CBIClaimListing] ADD CONSTRAINT [PK_Claim_Number_Coverage_Name] PRIMARY KEY ([Claim Number],[Coverage Name])



alter table ODS_Genius.[WORK].[CBIClaimListing] add 
	[Policy number]					NVARCHAR(50)	NULL,
	[Business Sub Component]				NVARCHAR(100)	NULL,
	[Insured Name]					NVARCHAR(300)	NULL,
	[Location ID]						NVARCHAR(50)	NULL,
	[Branch]						NVARCHAR(50)	NULL,
	[Broker Name]						NVARCHAR(200)	NULL,
	[Underwriter]						NVARCHAR(100)	NULL,
	[Risk engineer]					NVARCHAR(100)	NULL,
	[LIU Share]						FLOAT	NULL,
	[Attachment Point] 					INTEGER	NULL,
	[Coverage Name]					NVARCHAR(255)	NULL,
	[Total Inr curr(Gross)]				FLOAT	NULL,
	[Deductible Amount] 					INTEGER	NULL


--Zmiana Tabeli dot wymagan LSMDATA-2238
--alter table ODS_Genius.[WORK].[CBIClaimListing] add [Business Component] NVARCHAR(100)	NULL

alter table ODS_Genius.[WORK].[CBIClaimListing] alter column [Insured Name] NVARCHAR(200)	NULL
alter table ODS_Genius.[WORK].[CBIClaimListing] alter column [Coverage Name] NVARCHAR(100)	NULL
alter table ODS_Genius.[WORK].[CBIClaimListing] alter column [Location ID] NVARCHAR(100)	NULL
alter table ODS_Genius.[WORK].[CBIClaimListing] alter column [Underwriter] NVARCHAR(200)	NULL
alter table ODS_Genius.[WORK].[CBIClaimListing] alter column [Total Inr curr(Gross)] NUMERIC(38,4)	NULL
alter table ODS_Genius.[WORK].[CBIClaimListing] alter column [Risk engineer] NVARCHAR(200)	NULL
alter table ODS_Genius.[WORK].[CBIClaimListing] alter column [LIU Share] NUMERIC(28,4)	NULL
alter table ODS_Genius.[WORK].[CBIClaimListing] drop column [Deductible Amount] 
alter table ODS_Genius.[WORK].[CBIClaimListing] drop column [Attachment Point]  

alter table ODS_Genius.[WORK].[CBIClaimListing] alter column [Coverage Name] NVARCHAR(100)	NOT NULL


alter table ODS_Genius.[WORK].[CBIClaimListing] add 
    [Cause of Loss 4 Other Description]     NVARCHAR(256) NULL,
    [Cause Of Loss5]                        NVARCHAR(250) NULL,
    [Loss Code Group]                       NVARCHAR(250) NULL,
    [Organization]                          NVARCHAR(250) NULL,
    [Cyber Consideration]                   NVARCHAR(250) NULL,
    [Cyber Consideration Other Description] NVARCHAR(256) NULL,
    [Ransomware Aspect]                     NVARCHAR(250) NULL

alter table 

--UNIT TESTS v2 (po zmianie kolumn)


select top 100 * from  RADM.IDS.CBIClaimListing

select top 100 * from Staging_GENIUS.dbo.CBIClaimListing

select top 100 * from ODS_GENIUS.dbo.CBIClaimListing
select top 100 * from ODS_GENIUS.WORK.CBIClaimListing

--before test

select top 100 * from RADM.dbo.CBIClaimListing_aws where       
	  [Policy number] is not null
      and [Business Sub Component] is not null
      and [Business Component] is not null
      and [Insured Name] is not null
      and [Location ID] is not null
      and [Branch] is not null
      and [Broker Name] is not null
      and [Underwriter] is not null
      and [Risk engineer] is not null
      and [LIU Share] is not null
      and [Coverage Name]	 is not null
      and [Total Inr curr(Gross)]	 is not null

select top 100 * 
--update c set 
--      [Policy number] = ' '
--      ,[Business Sub Component] = ' '
--      ,[Business Component] = ' '
--	  ,[Insured Name] = ' '
--      ,[Location ID] = ' '
--      ,[Branch] = ' '
--      ,[Broker Name] = ' '
--      ,[Underwriter] = ' '
--      ,[Risk engineer] = ' '
--      ,[LIU Share] = 0
--      ,[Coverage Name]= ' '
--      ,[Total Inr curr(Gross)] = 0
from RADM.dbo.CBIClaimListing_aws c where [Claim Number] in ('DUBSPC000289745','PARSPC000289738','COLSPC000289739','LONPEC000289729')

--Po Update
select count(*) from RADM.dbo.CBIClaimListing_aws where       
	  [Policy number] is not null
      and [Business Sub Component] is not null
      and [Business Component] is not null
      and [Insured Name] is not null
      and [Location ID] is not null
      and [Branch] is not null
      and [Broker Name] is not null
      and [Underwriter] is not null
      and [Risk engineer] is not null
      and [LIU Share] is not null
      and [Coverage Name]	 is not null
      and [Total Inr curr(Gross)]	 is not null



select count(*)from Staging_GENIUS.dbo.CBIClaimListing where       
	  [Policy number] is not null
      and [Business Sub Component] is not null
      and [Business Component] is not null
      and [Insured Name] is not null
      and [Location ID] is not null
      and [Branch] is not null
      and [Broker Name] is not null
      and [Underwriter] is not null
      and [Risk engineer] is not null
      and [LIU Share] is not null
      and [Coverage Name]	 is not null
      and [Total Inr curr(Gross)]	 is not null


alter table 




--Staging_GENIUS

select [Claim Number], Claimant, [Coverage Name]
from Staging_Genius.dbo.CBIClaimListing
group by [Claim Number], Claimant, [Coverage Name]
having count(9)>1


--RADM UAT
select [Claim Number], Claimant, [Coverage Name]
from IDS.CBIClaimListing
group by [Claim Number], Claimant, [Coverage Name]
having count(9)>1


select count(9)
from IDS.CBIClaimListing
group by [Claim Number], Claimant, [Coverage Name]
having count(9)>1

