


select top 1000 mst.MAPORF, mst.MAMAIO 
--	cover.MAPORF, cover.MAMAIO, cover.MACNCD, cover.MAMAPC, cover.MADPCD, cover.MAMABN
from Genius.ZUMA mst
--left outer join Genius.ZURI ri
--	on mst.MAMANU = ri.RIMANU
--	and mst.MAMASE = ri.RIMASE
--left outer join Genius.ZUMA cover
--	on ri.RIRIMN = cover.MAMANU
--	and ri.RIRIMS = cover.MAMASE
where 
-- mst filter
        (
            mst.MACNCD in ('CHILE', 'ARGNTA', 'MLYON', 'BRZAFFIL', 'LIBSEGBR', 'MLYOFF', 'COLOMBIA', 'COL', 'LMLATAM', 'CHL', 
                'BRASIL', 'PERU', 'ECUADOR', 'LSILATAM', 'LIUILATM', 'LIBSEGPE', 'MEXICO', 'SING', 'SOF', 'AUS', 'HK',
                'BENELUX', 'BHAMUK', 'BRISTLUK', 'COLOGNUK', 'DUBAI', 'DUBUK', 'GLASGOUK', 'HAMBRGUK', 'IRELC', 'LEEDSUK',
                'LMUK', 'MANUK', 'MILANUK', 'PARISUK', 'SOEASTUK', 'SPAIN', 'SWISSUK', 'VISIONUW', 'IRE', 'LUXUK')
            OR mst.MAMAPC in ('EQUINE', 'TPR', 'TERROR' , 'ENGNR', 'HVY', 'OFNRG', 'ONNRG', 'INLM', 'INLMQ', 'COC', 'ONNRGQ',
                'OFNRGQ', 'HVYQ', 'ENGNRQ')
            OR mst.MADPCD in ('GLA', 'GUA', 'GUC', 'GUD', 'SD5')
            OR mst.MAMABN in ('3MIAMI', '5MIAMI', '4PAULO', '3PR')
        )
        AND
        NOT (mst.MAMAPC in ('TPR') 
			AND mst.MACNCD in ('III', 'ISIC')
			)
        AND (
            NOT left(mst.MAMABN, 1) = '7'
            OR NOT mst.MAMAPC in ('INLM', 'INLMQ')
			)
and 
CONCAT(mst.MAMANU, mst.MAMASE) in (
'GAYPT1001','GAYPXA001','GAYPT0001','GAYPY0001'
)

-- cover filter
--and     (
--            cover.MACNCD in ('CHILE', 'ARGNTA', 'MLYON', 'BRZAFFIL', 'LIBSEGBR', 'MLYOFF', 'COLOMBIA', 'COL', 'LMLATAM', 'CHL', 
--                'BRASIL', 'PERU', 'ECUADOR', 'LSILATAM', 'LIUILATM', 'LIBSEGPE', 'MEXICO', 'SING', 'SOF', 'AUS', 'HK',
--                'BENELUX', 'BHAMUK', 'BRISTLUK', 'COLOGNUK', 'DUBAI', 'DUBUK', 'GLASGOUK', 'HAMBRGUK', 'IRELC', 'LEEDSUK',
--                'LMUK', 'MANUK', 'MILANUK', 'PARISUK', 'SOEASTUK', 'SPAIN', 'SWISSUK', 'VISIONUW', 'IRE', 'LUXUK')
--            OR cover.MAMAPC in ('EQUINE', 'TPR', 'TERROR' , 'ENGNR', 'HVY', 'OFNRG', 'ONNRG', 'INLM', 'INLMQ', 'COC', 'ONNRGQ',
--                'OFNRGQ', 'HVYQ', 'ENGNRQ')
--            OR cover.MADPCD in ('GLA', 'GUA', 'GUC', 'GUD', 'SD5')
--            OR cover.MAMABN in ('3MIAMI', '5MIAMI', '4PAULO', '3PR')
--        )
--        AND
--        NOT (cover.MAMAPC in ('TPR') 
--			AND cover.MACNCD in ('III', 'ISIC')
--			)
--        AND (
--            NOT left(cover.MAMABN, 1) = '7'
--            OR NOT cover.MAMAPC in ('INLM', 'INLMQ')
--			)
