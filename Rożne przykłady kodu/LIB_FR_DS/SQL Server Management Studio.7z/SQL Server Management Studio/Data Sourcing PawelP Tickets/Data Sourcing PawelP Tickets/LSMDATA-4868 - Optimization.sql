--CREATE PROCEDURE [dbo].[ProcessBuild_PolicyPremiumTransactionsCoverage]
--	    @currentEEK		BIGINT
--	   , @Summary		NVARCHAR(MAX) OUTPUT
--AS
/**
***************************************************************************
**
** File              : ProcessBuild_PolicyPremiumTransactionsCoverage.proc
** Version           : $Revision: 24.02.00 $ 
** Description       : 
** 
** Procedure prepares data to load PolicyPremiumTransactionsCoverage fact table.
** Table requested by APAC, based on the design of PolicyPremiumIncome, but:
** - Coverage-level grain
** - No EPI and related logic
** - No TECH
** Return values: RESULT INT, SUMMARY NVARCHAR
**
** Called by  : FACT_PolicyPremiumTransactionsCoverage_DWH.dtsx
**
** Parameters:
** In  : EventExecutionKey from the calling process, required.
** 
***************************************************************************
** Change History
** Revision:	Date:		Author:					Description:
** ----------	----------	----------------------	---------------------------
** 23.11.00		02/11/2023	Ireneusz Dawgiallo		LSMDATA-3701 Initial version
** 24.01.00		05/01/2024	Ireneusz Dawgiallo		Refactoring, code fixes
**													LSMDATA-4025 LimitKey added
**													LSMDATA-2425 ExternalReferenceIdentifier added
**													LSMDATA-2421 Transaction LOB Code and Transaction branch added
** 24.02.00		07/02/2024	Adam Osak				LSMDATA-2457 TransactionTypeCategoryCode and TransactionTypeCategory added
													LSMDATA-3479 UserName added
************************************************************************
**/
DECLARE @Summary		NVARCHAR(MAX) 
DECLARE @stepMsg NVARCHAR(100) = N'Procedure started'

DROP TABLE IF EXISTS #proc_stat;
CREATE TABLE #proc_stat (id int not null IDENTITY(1,1), step NVARCHAR(100), starttime DATETIME, EndTime DateTIME)
;

BEGIN TRY

------------------------------------------------------------------
-- Statistics-based Premiums
------------------------------------------------------------------
-------------------
--SET @stepMsg = N'pre-Load : TRUNCATE stats table';

	--TRUNCATE TABLE [Build_PolicyPremiumTransactionsCoverage];

--------------
SET @stepMsg = N'#pptZUSP';

DROP TABLE IF EXISTS #pptZUSP;

insert into #proc_stat values (@stepMsg, getdate(), null)

	-- 1sec
	SELECT 
		ZUGP.MasterNumberKey,
		ZUGP.MasterSequenceKey,
		ZUSP.ShareOfWhole,
		ZUSP.SignedLine,
		ZUSP.SignedOrder,
		ZUSP.WrittenLine,
		ZUSP.WrittenOrder,
		ROW_NUMBER() OVER (PARTITION BY ZUGP.MasterNumberKey, ZUGP.MasterSequenceKey ORDER BY ZUSP.ParticipationGroupNumber DESC) AS RowNo,
		ROW_NUMBER() OVER (PARTITION BY MasterNumberKey, MasterSequenceKey ORDER BY ZUGP.ParticipationGroupEndDate DESC) AS RowDate,
		IIF(ZUGP._EventExecutionKey > ZUSP._EventExecutionKey, ZUGP._EventExecutionKey, ZUSP._EventExecutionKey) AS _EventExecutionKey,
		IIF(ZUGP._CDCDateTime > ZUSP._CDCDateTime, ZUGP._CDCDateTime, ZUSP._CDCDateTime) AS _CDCDateTime
	INTO #pptZUSP
	FROM 
		dbo.Map_ParticipationGroupVersion_ZUGP ZUGP
	JOIN 
		dbo.Map_Participation_ZUSP ZUSP
		ON ZUGP.ParticipationGroupNumberKey = ZUSP.ParticipationGroupNumberKey
		AND ZUGP.ParticipationGroupSequenceKey = ZUSP.ParticipationGroupSequenceKey
		AND ZUSP.MajorParticipationType = '1' 
	WHERE 
		ZUSP.MajorParticipationType = '1'
	AND ZUSP._LastAction <> 'D'
	;

update #proc_stat set EndTime=getdate() where step = @stepMsg

----------------
SET @stepMsg = N'#pptStats';

insert into #proc_stat values (@stepMsg, getdate(), null)

	DROP TABLE IF EXISTS #pptStats;
	--33 sec
	SELECT
		ZUMA.MasterReference,
		ZSE2.MasterNumber,
		ZSE2.MasterSequence, 
		ZSE2.SectionSequence,
		ZSE2.SectionDetailSequence,
		ZSE2.CoverageSequence,
		ZSE.CurrencyOfAmounts,
		IIF(ZSE.EndorsementNumber > 0, 'ADJUSTMENT', 'INITIAL') AS EndorsementFactor,
		ZSE3.INCASAmountCode,
		ZSE3.INCASAmountTypeCode,
		ZUMA.InwardsOutwardsFlag,
		ZSE5.OriginalBaseClosedRate AS OriginalToBaseExchangeRate,
		ZSE5.AccountingBaseClosedRate AS AccountingToBaseExchangeRate,			/* LSMDATA-1517 */
		CAST(1 AS INT) AS PolicyWrittenExchangeRate,
		ZSE3.TransationAmountClosedOriginal,
		ZSE2._SourceSystemCode,
		ZSE5.AuditNumber,
		ZSE5.TransactionReference2 AS ExternalReferenceIdentifier,
		ZSE2.Class2Code AS LineOfBusinessCode,
		ZSE.BranchNameCode AS Branch,
		ZSE5.TransactionTypeCode AS TransactionTypeCategoryCode,
		IIF(ZACB._LastAction = 'D', NULL ,ZACB.TransactionTypeShortDescription) AS  TransactionTypeCategory,

		/*LSMDATA-1226*/
		ZSE5.TransactionOriginalFlag,
		ZSE5.TransactionDescription,
		ZSE5.DoubleEntryItemSequence,
		ZSE5.StatisticsLedgerSequence,

		CAST(LEFT(ZSE.ReportingPeriod,6) AS INT) AS FiscalPeriod,
		CAST(ZSE1.InstalmentDueDate + 19000000 AS NVARCHAR(8)) AS DueDate,
		ZSE.EntryDate AS TransactionEntryDate,
		ZSE.GGNStatisticsHeaderSequenceKey,
		ZSE1.JobUser AS CreatedBy,
		ZKT8.UserName,
		IIF(ZSE3._LastAction = 'D' 
			OR ZSE2._LastAction = 'D' 
			OR ZSE._LastAction = 'D' 
			OR ZSE1._LastAction = 'D' 
			OR ZUMA._LastAction = 'D' 
			OR ZSE5._LastAction = 'D'
			, 'D'
			, 'I') AS _LastAction,
		ca_eventexecutionkeys._EventExecutionKey,
		ca_timestamps._CDCDateTime
	
	INTO #pptStats
	FROM
		dbo.Map_Master_ZUMA ZUMA
	INNER JOIN 
		dbo.Map_StatisticsHeader_ZSE ZSE
		ON ZUMA.MasterNumberKey	   = ZSE.MasterNumberKey
		AND ZUMA.MasterSequenceKey = ZSE.MasterSequenceKey
	INNER JOIN
		dbo.Map_StatisticsSection_ZSE2 ZSE2
		ON ZSE.GGNStatisticsHeaderSequenceKey = ZSE2.GGNStatisticsHeaderSequenceKey
	INNER JOIN 
		dbo.Map_StatisticsAmount_ZSE3 ZSE3
		ON ZSE2.GGNStatisticsHeaderSequenceKey = ZSE3.GGNStatisticsHeaderSequenceKey
		AND ZSE2.GGNStatisticsSectionSequenceKey = ZSE3.GGNStatisticsSectionSequenceKey
	INNER JOIN 
		dbo.Map_StatisticsHeaderAccount_ZSE1 ZSE1
		ON ZSE.GGNStatisticsHeaderSequenceKey = ZSE1.GGNStatisticsHeaderSequenceKey
	INNER JOIN 
		dbo.Map_StatisticsPosting_ZSE5 ZSE5
		ON ZSE5.GGNStatisticsHeaderSequence = ZSE3.GGNStatisticsHeaderSequenceKey
		AND ZSE5.GGNStatisticsPostingSequence = ZSE3.GGNStatisticsPostingSequence
	LEFT JOIN dbo.Map_TransactionType_ZACB ZACB
		ON ZSE5.TransactionTypeCodeKey = ZACB.TransactionTypeCodeKey
	LEFT JOIN
		dbo.Map_User_ZKT8 ZKT8
		ON ZSE1.JobUser = ZKT8.GENIUSUserID
	CROSS APPLY
	(
		SELECT
			MAX(pvtek._EventExecutionKey) AS _EventExecutionKey
		FROM
		(
			SELECT 
				ZSE3._EventExecutionKey AS _EventExecutionKey_ZSE3
			,	ZSE2._EventExecutionKey AS _EventExecutionKey_ZSE2
			,	ZSE._EventExecutionKey AS _EventExecutionKey_ZSE
			,	ZSE1._EventExecutionKey AS _EventExecutionKey_ZSE1
			,	ZUMA._EventExecutionKey AS _EventExecutionKey_ZUMA
			,	ZSE5._EventExecutionKey AS _EventExecutionKey_ZSE5
			,	ZKT8._EventExecutionKey AS _EventExecutionKey_ZKT8
			,	ZACB._EventExecutionKey AS _EventExecutionKey_ZACB
			) ts
		UNPIVOT
		(
			_EventExecutionKey FOR EventExecutionKeycolumn IN 
			( 
				ts._EventExecutionKey_ZSE3
			,	ts._EventExecutionKey_ZSE2
			,	ts._EventExecutionKey_ZSE
			,	ts._EventExecutionKey_ZSE1
			,	ts._EventExecutionKey_ZUMA	
			,	ts._EventExecutionKey_ZSE5
			,	ts._EventExecutionKey_ZKT8
			,	ts._EventExecutionKey_ZACB
			) 
		) pvtek
	) ca_eventexecutionkeys
	CROSS APPLY
	(
		SELECT
			MAX(pvtts._CDCDateTime) AS _CDCDateTime
		FROM
		(		
			SELECT 
				ZSE3._CDCDateTime AS _CDCDateTime_ZSE3
			,	ZSE2._CDCDateTime AS _CDCDateTime_ZSE2
			,	ZSE._CDCDateTime AS _CDCDateTime_ZSE
			,	ZSE1._CDCDateTime AS _CDCDateTime_ZSE1
			,	ZUMA._CDCDateTime AS _CDCDateTime_ZUMA
			,	ZSE5._CDCDateTime AS _CDCDateTime_ZSE5
			,	ZKT8._CDCDateTime AS _CDCDateTime_ZKT8
			,	ZACB._CDCDateTime AS _CDCDateTime_ZACB
			) ts
			UNPIVOT
			(
				_CDCDateTime FOR CDCDateTimeColumn IN 
				(		
					ts._CDCDateTime_ZSE3
				,	ts._CDCDateTime_ZSE2
				,	ts._CDCDateTime_ZSE
				,	ts._CDCDateTime_ZSE1
				,	ts._CDCDateTime_ZUMA
				,	ts._CDCDateTime_ZSE5
				,	ts._CDCDateTime_ZKT8
				,	ts._CDCDateTime_ZACB
				) 
			) pvtts
		) ca_timestamps
	WHERE 
		ZSE3.INCASAmountCode <> 'CLM'
	AND ZSE3.GGNStatisticsRISequence = '0'
	AND ZUMA.MasterInternalStatus1 = '1'
	;

update #proc_stat set EndTime=getdate() where step = @stepMsg

----------------
SET @stepMsg = N'#pptAggregatedStats';

DROP TABLE IF EXISTS #pptAggregatedStats;

insert into #proc_stat values (@stepMsg, getdate(), null)

-- 16 sec
	SELECT
		MAX(MasterReference) AS MasterReference,
		MasterNumber,
		MasterSequence, 
		SectionSequence,
		SectionDetailSequence,
		CoverageSequence,
		CurrencyOfAmounts,
		EndorsementFactor,
		INCASAmountCode,
		GGNStatisticsHeaderSequenceKey,	
		MAX(FiscalPeriod) AS FiscalPeriod,
		MAX(INCASAmountTypeCode) AS INCASAmountTypeCode,
		InwardsOutwardsFlag,
		AVG( OriginalToBaseExchangeRate ) AS OriginalToBaseExchangeRate,
		AVG( AccountingToBaseExchangeRate ) AS AccountingToBaseExchangeRate, 	/* LSMDATA-1517 */
		MAX(PolicyWrittenExchangeRate) AS PolicyWrittenExchangeRate,
		MAX(AuditNumber) AS AuditNumber,
		MAX(ExternalReferenceIdentifier) AS ExternalReferenceIdentifier, -- there is only one per grain
		MAX(LineOfBusinessCode) AS TransactionLineOfBusinessCode,	-- there is only one per grain
		MAX(Branch) AS TransactionBranch,							-- there is only one per grain
		MAX(TransactionTypeCategoryCode) AS TransactionTypeCategoryCode, -- there is only one per grain
		MAX(TransactionTypeCategory) AS TransactionTypeCategory, -- there is only one per grain
		
		/*LSMDATA-1226*/
		MAX(TransactionOriginalFlag) AS TransactionOriginalFlag,
		MAX(TransactionDescription) AS TransactionDescription,
		MAX( DoubleEntryItemSequence  ) AS DoubleEntryItemSequence,
		MAX( StatisticsLedgerSequence ) AS StatisticsLedgerSequence,
		
		MAX(DueDate) AS DueDate,
		MAX(TransactionEntryDate) AS TransactionEntryDate,
		MAX(CreatedBy) AS CreatedBy,
		MAX(UserName) AS UserName,
		SUM(IIF(_LastAction = 'D', 0, TransationAmountClosedOriginal)) AS TransationAmountClosedOriginal,
		MAX(_EventExecutionKey) AS _EventExecutionKey,
		MAX(_CDCDateTime) AS _CDCDateTime,
		IIF(COUNT(*) = SUM(IIF(_LastAction = 'D', 1, 0)), 'D', 'I') AS _LastAction,--If all records are 'D', set to 'D', otherwise 'I'
		_SourceSystemCode,
		CONCAT(
			QUOTENAME(_SourceSystemCode),
            QUOTENAME(MasterNumber),
            QUOTENAME(MasterSequence), 
            QUOTENAME(SectionSequence),
            QUOTENAME(SectionDetailSequence)
        ) AS PolicyKey
	INTO #pptAggregatedStats 
	FROM
		#pptStats
	GROUP BY
		MasterNumber,
		MasterSequence, 
		SectionSequence,
		SectionDetailSequence,
		CoverageSequence,
		CurrencyOfAmounts,
		EndorsementFactor,
		INCASAmountCode,
		InwardsOutwardsFlag,
		GGNStatisticsHeaderSequenceKey,
		_SourceSystemCode
	;

	DROP TABLE #pptStats;

update #proc_stat set EndTime=getdate() where step = @stepMsg

----------------------
SET @stepMsg = N'INSERT Stats Coverage level';

DROP TABLE IF EXISTS #result;

insert into #proc_stat values (@stepMsg, getdate(), null)

	--INSERT INTO [Build_PolicyPremiumTransactionsCoverage] 
	--	(
	--	 	[PolicyReference]									
	--	,	[AuditNumber]										
	--	,	[ExternalReferenceIdentifier]						
	--	,	[GGNStatisticsHeaderSequenceKey]					
	--	,	[DoubleEntryItemSequence]							
	--	,	[StatisticsLedgerSequence]							
	--	,	[CreatedBy]
	--	,	[UserName]   
	--	,	[DueDate]											
	--	,	[FiscalPeriod]										
	--	,	[TransactionOriginalFlag]							
	--	,	[TransactionDescription]							
	--	,	[TransactionEntryDate]								
	--	,	[TransactionTypeKey]
	--	,	[TransactionTypeCategoryCode]
	--	,	[TransactionTypeCategory]
	--	,	[TransactionLineOfBusinessCode]						
	--	,	[TransactionBranch]											
	--	,	[CurrencyOfAmounts]									
	--	,	[AccountingToBaseExchangeRate]						
	--	,	[OriginalToBaseExchangeRate]						
	--	,	[PolicyWrittenExchangeRate]							
	--	,	[ClientPolicyPremiumGrossOriginalCurrency]			
	--	,	[ClientPolicyPremiumNetOriginalCurrency]			
	--	,	[InitialPolicyPremiumEstimatedGrossOriginalCurrency]
	--	,	[InitialPolicyPremiumEstimatedNetOriginalCurrency]	
	--	,	[InitialPolicyPremiumSEPIGrossOriginalCurrency]		
	--	,	[InitialPolicyPremiumSEPINetOriginalCurrency]		
	--	,	[InitialPolicyPremiumSignedGrossOriginalCurrency]	
	--	,	[InitialPolicyPremiumSignedNetOriginalCurrency]		
	--	,	[InitialPolicyPremiumWrittenGrossOriginalCurrency]	
	--	,	[InitialPolicyPremiumWrittenNetOriginalCurrency]	
	--	,	[SignedDownPremiumEstimatedNetOriginalCurrency]		
	--	,	[SignedDownPremiumWrittenNetOriginalCurrency]		
	--	,	[SystemTransactionAmountOriginalCurrency]			
	--	,	[_CDCDateTime]										
	--	,	[_EventExecutionKey]								
	--	,	[_LastAction]										
	--	,	[_MergeKey]											
	--	,	[_SourceSystemCode]									
	--	,	[_MergeKey_LimitKey]								
	--	,	[_MergeKey_OriginalCurrencyKey]						
	--	,	[_MergeKey_PolicyKey]								
	--	)
	--53 sec
	SELECT
		--Attributes
		 	x.PolicyReference
		,	x.[AuditNumber]										
		,	x.[ExternalReferenceIdentifier]						
		,	x.[GGNStatisticsHeaderSequenceKey]					
		,	x.[DoubleEntryItemSequence]							
		,	x.[StatisticsLedgerSequence]							
		,	x.[CreatedBy]											
		,	x.[UserName]
		,	x.[DueDate]											
		,	x.[FiscalPeriod]										
		,	x.[TransactionOriginalFlag]							
		,	x.[TransactionDescription]							
		,	x.[TransactionEntryDate]								
		,	x.[TransactionTypeKey]		
		,	x.[TransactionTypeCategoryCode]
		,	x.[TransactionTypeCategory]
		,	x.[TransactionLineOfBusinessCode]						
		,	x.[TransactionBranch]											
		,	x.[CurrencyOfAmounts]									
		,	x.[AccountingToBaseExchangeRate]						
		,	x.[OriginalToBaseExchangeRate]						
		,	x.[PolicyWrittenExchangeRate]
		--Measures 
		,	x.ClientPolicyPremiumGrossOriginalCurrency
		,	x.ClientPolicyPremiumNetOriginalCurrency 
		,	x.InitialPolicyPremiumEstimatedGrossOriginalCurrency
		,	x.InitialPolicyPremiumEstimatedNetOriginalCurrency 
		,	x.InitialPolicyPremiumSEPIGrossOriginalCurrency
		,	x.InitialPolicyPremiumSEPINetOriginalCurrency
		,	x.InitialPolicyPremiumSignedGrossOriginalCurrency
		,	x.InitialPolicyPremiumSignedNetOriginalCurrency 
		,	x.InitialPolicyPremiumWrittenGrossOriginalCurrency 
		,	x.InitialPolicyPremiumWrittenNetOriginalCurrency
		,	x.SignedDownPremiumEstimatedNetOriginalCurrency
		,	x.SignedDownPremiumWrittenNetOriginalCurrency
		,	x.SystemTransactionAmountOriginalCurrency
		--System Columns
		,	x._CDCDateTime	
		,	x._EventExecutionKey
		,	x._LastAction
		,	x._MergeKey
		,	x._SourceSystemCode
		--Dimension Lookup Keys
		,	x._MergeKey_LimitKey
		,	x._MergeKey_OriginalCurrencyKey
		,	x._MergeKey_PolicyKey
		into #result
	FROM
	(
		SELECT
		--Attributes 
			ST.MasterReference AS PolicyReference
		,	ST.AuditNumber
		,	ST.ExternalReferenceIdentifier
		,	ST.DueDate
		,	ST.PolicyWrittenExchangeRate
		,	CAST(CONCAT(QUOTENAME(ST._SourceSystemCode), calcsTTKey.TransactionTypeKey) AS NVARCHAR(255)) AS TransactionTypeKey
		,	ST.CurrencyOfAmounts
		,	ST.GGNStatisticsHeaderSequenceKey
		,	ST.FiscalPeriod
		,	ST.OriginalToBaseExchangeRate
		,	ST.AccountingToBaseExchangeRate		/* LSMDATA-1517 */
		,	ST.TransactionEntryDate AS TransactionEntryDate
		,	ST.CreatedBy
		,	ST.UserName
		,	ST.TransactionBranch
		,	ST.TransactionTypeCategoryCode
		,	ST.TransactionTypeCategory

		,	ST.TransactionLineOfBusinessCode
	
			/*LSMDATA-1226*/
		,	ST.TransactionOriginalFlag
		,	ST.TransactionDescription
		,	ST.DoubleEntryItemSequence
		,	ST.StatisticsLedgerSequence
	
		--Measures 
		,	CAST(COALESCE(calcs.InitialPolicyPremiumEstimatedGross * calcs.WholeMultiplier, 0) AS DECIMAL(18, 4)) AS ClientPolicyPremiumGrossOriginalCurrency
		,	CAST(COALESCE(calcs.InitialPolicyPremiumEstimatedNet * calcs.WholeMultiplier, 0) AS DECIMAL(18, 4)) AS ClientPolicyPremiumNetOriginalCurrency
		,	calcs.InitialPolicyPremiumEstimatedGross AS InitialPolicyPremiumEstimatedGrossOriginalCurrency
		,	calcs.InitialPolicyPremiumEstimatedNet AS InitialPolicyPremiumEstimatedNetOriginalCurrency
		,	calcs.InitialPolicyPremiumEstimatedGross AS InitialPolicyPremiumSEPIGrossOriginalCurrency
		,	calcs.InitialPolicyPremiumEstimatedNet AS InitialPolicyPremiumSEPINetOriginalCurrency
		,	calcs.InitialPolicyPremiumEstimatedGross AS InitialPolicyPremiumSignedGrossOriginalCurrency
		,	calcs.InitialPolicyPremiumEstimatedNet AS InitialPolicyPremiumSignedNetOriginalCurrency
		,	calcs.InitialPolicyPremiumEstimatedGross AS InitialPolicyPremiumWrittenGrossOriginalCurrency
		,	calcs.InitialPolicyPremiumEstimatedNet AS InitialPolicyPremiumWrittenNetOriginalCurrency
		,	CAST(COALESCE(calcs.InitialPolicyPremiumEstimatedNet * (#pptZUSP.WrittenLine - #pptZUSP.SignedLine), 0) AS DECIMAL(18, 4)) AS SignedDownPremiumEstimatedNetOriginalCurrency
		,	CAST(COALESCE(calcs.InitialPolicyPremiumEstimatedNet * (#pptZUSP.WrittenLine - #pptZUSP.SignedLine), 0) AS DECIMAL(18, 4)) AS SignedDownPremiumWrittenNetOriginalCurrency
			--This is the amount from the stats table without any calculations based on INCASAmountTypeCode
		,	ST.TransationAmountClosedOriginal AS SystemTransactionAmountOriginalCurrency
		--System Columns
		,	ca_timestamps._CDCDateTime
		,	ca_eventexecutionkeys._EventExecutionKey 
		,	CAST(ST._LastAction AS NCHAR(1)) AS _LastAction
		,	CAST(CONCAT(ST.PolicyKey, QUOTENAME(ST.CoverageSequence), calcsTTKey.TransactionTypeKey, QUOTENAME(ST.CurrencyOfAmounts), QUOTENAME(ST.GGNStatisticsHeaderSequenceKey)) AS NVARCHAR(255)) AS _MergeKey
		,	ST._SourceSystemCode
		--Dimension Lookup Keys
		,	CAST(CONCAT(ST.PolicyKey, QUOTENAME(ST.CoverageSequence)) AS NVARCHAR(255)) AS _MergeKey_LimitKey
		,	CAST(CONCAT(QUOTENAME(ST._SourceSystemCode), QUOTENAME(ST.CurrencyOfAmounts)) AS NVARCHAR(255)) AS _MergeKey_OriginalCurrencyKey
		,	CAST(ST.PolicyKey AS NVARCHAR(255)) AS _MergeKey_PolicyKey
		FROM
			#pptAggregatedStats ST
		LEFT JOIN 
			#pptZUSP 
			ON ST.MasterNumber = #pptZUSP.MasterNumberKey
			AND ST.MasterSequence = #pptZUSP.MasterSequenceKey
			AND #pptZUSP.RowNo = 1
			AND #pptZUSP.RowDate = 1
		CROSS APPLY 
		(
			SELECT
			CONCAT(
					QUOTENAME('Estimated'),
					QUOTENAME(ST.EndorsementFactor),
					QUOTENAME(ST.INCASAmountCode),
					QUOTENAME(CASE    
								WHEN InwardsOutwardsFlag = 1 THEN 'GROSS' 
								WHEN InwardsOutwardsFlag = 2 THEN 'CEDED'
								ELSE 'NA'
							END)
					) AS TransactionTypeKey
		) calcsTTKey
		LEFT JOIN [dbo].[Map_MasterTransactionTypeHierarchy] Map_MTTH
		ON  Map_MTTH.TransactionTypeKey = CONCAT(QUOTENAME(ST._SourceSystemCode), calcsTTKey.TransactionTypeKey)
		CROSS APPLY 
			(
						  SELECT 
						 CAST(
							   IIF (
							   (Map_MTTH.TransactionLevel1Name='Estimated Premium'
							   AND Map_MTTH.DeductionLevelName ='Gross'), ST.TransationAmountClosedOriginal, 0) 
							   AS DECIMAL(18, 4)) AS InitialPolicyPremiumEstimatedGross
				  ,      CAST(
							   IIF(
							   (Map_MTTH.TransactionLevel1Name='Estimated Premium'
							   AND Map_MTTH.DeductionLevelName ='Gross') OR 
							   (Map_MTTH.TransactionLevel1Name='Estimated Premium'
							   AND Map_MTTH.DeductionLevelName ='Deduction'),
							   ST.TransationAmountClosedOriginal, 0) 
							   AS DECIMAL(18, 4)) AS InitialPolicyPremiumEstimatedNet
				  ,      (100 / IIF(#pptZUSP.ShareOfWhole = 0, 100, #pptZUSP.ShareOfWhole)) AS WholeMultiplier
				  ) calcs
			CROSS APPLY
			(
				SELECT
					MAX(pvtek._EventExecutionKey) AS _EventExecutionKey
				FROM
				(
					SELECT 
						ST._EventExecutionKey AS _EventExecutionKey_ST
					,	#pptZUSP._EventExecutionKey AS _EventExecutionKey_#pptZUSP
					,	Map_MTTH._EventExecutionKey AS _EventExecutionKey_Map_MTTH
					) ts
				UNPIVOT
				(
					_EventExecutionKey FOR EventExecutionKeycolumn IN 
					( 
						ts._EventExecutionKey_ST
					,	ts._EventExecutionKey_#pptZUSP
					,	ts._EventExecutionKey_Map_MTTH
					) 
				) pvtek
			) ca_eventexecutionkeys
			CROSS APPLY
			(
				SELECT
					MAX(pvtts._CDCDateTime) AS _CDCDateTime
				FROM
				(		
					SELECT 
						ST._CDCDateTime AS _CDCDateTime_ST
					,	#pptZUSP._CDCDateTime AS _CDCDateTime_#pptZUSP
				) ts
				UNPIVOT
				(
					_CDCDateTime FOR CDCDateTimeColumn IN 
					(		
						ts._CDCDateTime_ST
					,	ts._CDCDateTime_#pptZUSP
					) 
				) pvtts
			) ca_timestamps
	) x;

update #proc_stat set EndTime=getdate() where step = @stepMsg

--SET @Summary = N'Procedure completed';

--RETURN 0;

END TRY

BEGIN CATCH

	SET @Summary = 'Procedure failed at step: ' + @stepMsg + ' Original Message: ' + ERROR_MESSAGE();

	RAISERROR('%s', 16, 1, @Summary);

	--RETURN 1;

END CATCH;
GO


--select *, CONVERT(TIME, DATEADD(ss,DATEDIFF(SECOND,starttime,EndTime),0)) [Czas] from #proc_stat
