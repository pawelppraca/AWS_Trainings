--Sprawdzenie tabel powi?zanych dla przyk?ad�w z ticketa LSMDATA-3383

/*

Inward: '1000215493-02' -> Outward '100021549302F1'
INWARD: CFCGACQF50022 -> Outward: 
T0358F5-22A     
T0358F5-22B     
T0358F5-22BB    
FACACQF50022 E  
FACACQF50022 H  
FACACQF50022 M  
FACACQF50022 S  
FACACQF50022 T  
FACACQF50022GRS 


*/

--Sprawdzenie ?r�d?a BI_LZ UAT

--BI_LZ
select top 1000 pol.maporf PolicyNr, cov.maporf cover_nr, pol.MAMAIO POL_InwardsOutwardsFlag, cov.MAMAIO RI_InwardsOutwardsFlag
,zusk.LastUpdatedDate ZUSK_LastUpdatedDate
,zus.LastUpdatedDate ZUS_LastUpdatedDate
,ZUSK_add_det.LastUpdatedDate Add_Details_LastUpdatedDate
,map.* from GENIUS.ZUMA pol
inner join GENIUS.ZURI map
    on  pol.MAMANU = map.RIMANU
    and pol.MAMASE = map.RIMASE
inner join Genius.ZUMA cov
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
--sprawdzenie covers, coverdetails
left join GENIUS.ZUSK zusk --OK
	ON  pol.MAMANU = ZUSK.SKMANU 
	AND pol.MAMASE = ZUSK.SKMASE
left join GENIUS.ZUS zus -- coverlines - OK
	ON  pol.MAMANU = ZUS.SFMANU 
	AND pol.MAMASE = ZUS.SFMASE
	AND zUSK.SKRKRS = ZUS.SFRKRS
LEFT JOIN Genius.ZUSK ZUSK_add_det
	ON  pol.MAMANU = ZUSK.SKMANU 
	AND pol.MAMASE = ZUSK.SKMASE
	AND  ZUSK.SKRECD <>'LSM'
	AND  ZUSK.SKSKTL <> 'Master Details'

where pol.MAPORF like '080005-010-02'

--LIMITS


select top 1000 ri.*
,zusk.LastUpdatedDate ZUSK_LastUpdatedDate
,zus.LastUpdatedDate ZUS_LastUpdatedDate
,ZUCO.LastUpdatedDate ZUCO_LastUpdatedDate
,ZHKT.LastUpdatedDate ZHKT_LastUpdatedDate
from GENIUS.ZUCO zuco
join GENIUS.ZUS zus 
	ON  zuco.COMANU = ZUS.SFMANU 
	AND zuco.COMASE = ZUS.SFMASE
	AND ZUCO.CORKRS = ZUS.SFRKRS
	AND ZUCO.COSDSQ = ZUS.SFSDSQ
join GENIUS.ZUSK zusk --
	ON  zus.SFMANU = ZUSK.SKMANU 
	AND zus.SFMASE = ZUSK.SKMASE
join (
		select pol.maporf PolicyNr, cov.maporf cover_nr, pol.MAMAIO POL_InwardsOutwardsFlag, cov.MAMAIO RI_InwardsOutwardsFlag
		,cov.MAMANU RI_ZUMA_MAMANU, cov.MAMASE RI_ZUMA_MAMASE
		from GENIUS.ZUMA pol
		inner join GENIUS.ZURI map
			on  pol.MAMANU = map.RIMANU
			and pol.MAMASE = map.RIMASE
		inner join Genius.ZUMA cov
			on map.RIRIMN = cov.MAMANU
			and map.RIRIMS = cov.MAMASE
)	RI 
	on RI.RI_ZUMA_MAMANU = zusk.SKMANU AND RI.RI_ZUMA_MAMASE = zusk.SKMASE
join Genius.ZHKT 
ON ZHKT.KTCTCO = ZUCO.COCTCO --CoverageTypeCode

where ri.PolicyNr like '1000215493-02'





--Sprawdzenie danych na BI_LZ UAT


SELECT count(distinct maporf)

FROM BI_LZ.GEnius.ZUMA z
WHERE (z.MACNCD in ('CHILE', 'ARGNTA', 'MLYON', 'BRZAFFIL', 'LIBSEGBR', 'MLYOFF', 'COLOMBIA', 'COL', 'LMLATAM', 'CHL', 
                'BRASIL', 'PERU', 'ECUADOR', 'LSILATAM', 'LIUILATM', 'LIBSEGPE', 'MEXICO', 'SING', 'SOF', 'AUS', 'HK',
                'BENELUX', 'BHAMUK', 'BRISTLUK', 'COLOGNUK', 'DUBAI', 'DUBUK', 'GLASGOUK', 'HAMBRGUK', 'IRELC', 'LEEDSUK',
                'LMUK', 'MANUK', 'MILANUK', 'PARISUK', 'SOEASTUK', 'SPAIN', 'SWISSUK', 'VISIONUW', 'IRE', 'LUXUK',
                'NORWAY','SWEDEN','BELGIUM') --companies
		OR z.MAMAPC in ('EQUINE', 'TPR', 'TERROR' , 'ENGNR', 'HVY', 'OFNRG', 'ONNRG', 'INLM', 'INLMQ', 'COC', 'ONNRGQ','OFNRGQ', 'HVYQ', 'ENGNRQ', 'FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3') --lsm_products
		OR z.MADPCD in ('GLA', 'GUA', 'GUC', 'GUD', 'SD5') --lsm_departments
		OR z.MAMABN in('3MIAMI', '5MIAMI', '4PAULO', '3PR') --lsm_west_branches
		) 
AND NOT (z.MAMAPC ='TPR' AND z.MACNCD in ('III', 'ISIC'))
AND (LEFT(z.MAMABN, 1) <> '7' OR z.MAMAPC NOT IN ('INLM', 'INLMQ'))
--count: 2360904 (bez nowych produkt�w)
--count: 2429293 (z nowymi produktami)
--R�znica: select  2429289 - 2360904 = 68385


SELECT *
into #Zuma_POLicies_inc_RI
FROM BI_LZ.Genius.ZUMA z
WHERE (z.MACNCD in ('CHILE', 'ARGNTA', 'MLYON', 'BRZAFFIL', 'LIBSEGBR', 'MLYOFF', 'COLOMBIA', 'COL', 'LMLATAM', 'CHL', 
                'BRASIL', 'PERU', 'ECUADOR', 'LSILATAM', 'LIUILATM', 'LIBSEGPE', 'MEXICO', 'SING', 'SOF', 'AUS', 'HK',
                'BENELUX', 'BHAMUK', 'BRISTLUK', 'COLOGNUK', 'DUBAI', 'DUBUK', 'GLASGOUK', 'HAMBRGUK', 'IRELC', 'LEEDSUK',
                'LMUK', 'MANUK', 'MILANUK', 'PARISUK', 'SOEASTUK', 'SPAIN', 'SWISSUK', 'VISIONUW', 'IRE', 'LUXUK',
                'NORWAY','SWEDEN','BELGIUM') --companies
		OR z.MAMAPC in ('EQUINE', 'TPR', 'TERROR' , 'ENGNR', 'HVY', 'OFNRG', 'ONNRG', 'INLM', 'INLMQ', 'COC', 'ONNRGQ','OFNRGQ', 'HVYQ', 'ENGNRQ', 'FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3') --lsm_products
		OR z.MADPCD in ('GLA', 'GUA', 'GUC', 'GUD', 'SD5') --lsm_departments
		OR z.MAMABN in('3MIAMI', '5MIAMI', '4PAULO', '3PR') --lsm_west_branches
		) 
AND NOT (z.MAMAPC ='TPR' AND z.MACNCD in ('III', 'ISIC'))
AND (LEFT(z.MAMABN, 1) <> '7' OR z.MAMAPC NOT IN ('INLM', 'INLMQ'))



select count(distinct cov.maporf)  -- count(distinct cov.maporf) = 36645
--top 1000 pol.maporf PolicyNr, cov.maporf cover_nr, pol.MAMAIO POL_InwardsOutwardsFlag, cov.MAMAIO RI_InwardsOutwardsFlag, pol.MAMAPC, cov.MAMAPC
--,map.* 
--,pol.*

from #Zuma_POLicies_inc_RI pol (nolock)
join GENIUS.ZURI map
    on  pol.MAMANU = map.RIMANU
    and pol.MAMASE = map.RIMASE
join #Zuma_POLicies_inc_RI cov
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
--where pol.MAPORF like '1000215493-02'
WHERE pol.MAMAIO=1 and cov.MAMAIO=2
AND COV.MAMAPC in ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3')
--order by cov._CDCDateTime desc

select top 100 pol.maporf PolicyNr, cov.maporf cover_nr, pol.MAMAIO POL_InwardsOutwardsFlag, cov.MAMAIO RI_InwardsOutwardsFlag, pol.MAMAPC, cov.MAMAPC
,pol.LastUpdatedDate Pol_LUD, cov.LastUpdatedDate COV_LUD
,cov.MAMASN COV_MAMASN
,pol.MAMASN POL_MAMASN
,pol.MAMANU POL_MAMANU, pol.MAMASE POL_MAMASE
,cov.MAMANU COV_MAMANU, cov.MAMASE COV_MAMASE
,pol.*
,map.* 
,cov.*

from #Zuma_POLicies_inc_RI pol
join GENIUS.ZURI map  (nolock)
    on  pol.MAMANU = map.RIMANU
    and pol.MAMASE = map.RIMASE
join #Zuma_POLicies_inc_RI cov
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
--where cov.MAPORF like 'T0117-99AMD'
WHERE pol.MAMAIO=1 and cov.MAMAIO=2
AND COV.MAMAPC in ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3')

order by cov.LastUpdatedDate desc

--Polisa z updatem po zmianie filtra ZUMY na Extrkcie
--PolicyNr	cover_nr	POL_InwardsOutwardsFlag	RI_InwardsOutwardsFlag	MAMAPC	MAMAPC	Pol_LUD	COV_LUD
8110135367-01	811013536701T1	1	2	ONNRG	FAC	2024-06-13 16:04:56.000	2024-06-13 16:03:06.000





select * from Genius.ZUMA where MAMANU='ACV5S1' and MAMASE='001' --POLICY
select * from Genius.ZUMA where MAMANU='ACV5S0' and MAMASE='001' --COVER

select 'POL',* from Genius.ZUMA_LOG where MAMANU='ACV5S1' and MAMASE='001'
select 'COV',* from Genius.ZUMA_LOG where MAMANU='ACV5S0' and MAMASE='001'



--Sprawdzenie ostatnich polis
select top 100 pol.maporf PolicyNr, pol.MAMAIO POL_InwardsOutwardsFlag, pol.MAMAPC
,pol.LastUpdatedDate Pol_LUD

,pol.MAMASN POL_MAMASN
,pol.MAMANU POL_MAMANU, pol.MAMASE POL_MAMASE

from Genius.ZUMA pol 
WHERE LastUpdatedDate < '2024-06-12T15:00:00'
order by LastUpdatedDate desc


select 'POL',* from Genius.ZUMA_LOG where MAMANU='966975' and MAMASE='001'  --IRONTXT31021300


--Polisy Karola
SELECT MAPORF, MAMABN, MAMANU,MAMASE,MAMAIO, MAMAPC LastUpdatedDate FROM genius.ZUMA WHERE MAPORF IN ('T0111-99','T0117-99','T0118-99','T0119-99','T0111A-99','T0098-00','T0099-00','T0118-99AMD','T0117-99AMD','T0117-99CXR','T0119-99AMD')






--Weryfikacja danych w RDS po przejsciu filtra

select count(*)
--top 1000 pol.maporf PolicyNr, cov.maporf cover_nr, pol.MAMAIO POL_InwardsOutwardsFlag, cov.MAMAIO RI_InwardsOutwardsFlag, pol.MAMAPC, cov.MAMAPC
--,map.* 
--,pol.*

from ZUMA pol
join ZURI map
    on  pol.MAMANU = map.RIMANU
    and pol.MAMASE = map.RIMASE
join ZUMA cov
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
--where pol.MAPORF like '1000215493-02'
WHERE pol.MAMAIO=1 and cov.MAMAIO=2
AND COV.MAMAPC in ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3')
order by cov._CDCDateTime desc


565038

select top 1000 pol.maporf PolicyNr, cov.maporf cover_nr, pol.MAMAIO POL_InwardsOutwardsFlag, cov.MAMAIO RI_InwardsOutwardsFlag, pol.MAMAPC, cov.MAMAPC
,map.* 
,pol.*

from ZUMA pol
left join ZURI map
    on  pol.MAMANU = map.RIMANU
    and pol.MAMASE = map.RIMASE
left join ZUMA cov
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
where pol.MAPORF like 'SYSPC00500046'



--Wyszukanie danych na RDS SIT

select top 1000 pol.maporf PolicyNr, cov.maporf cover_nr, pol.MAMAIO POL_InwardsOutwardsFlag, cov.MAMAIO RI_InwardsOutwardsFlag, pol.MAMAPC, cov.MAMAPC
--,pol.LastUpdatedDate Pol_LUD, cov.LastUpdatedDate COV_LUD
,cov.MAMASN COV_MAMASN
,pol.MAMASN POL_MAMASN
,pol.MAMANU POL_MAMANU, pol.MAMASE POL_MAMASE
,cov.MAMANU COV_MAMANU, cov.MAMASE COV_MAMASE
,pol.*
,map.* 
,cov.*
--update cov set MAMASN=''
from ZUMA pol
left join ZURI map
    on  pol.MAMANU = map.RIMANU
    and pol.MAMASE = map.RIMASE
left join ZUMA cov
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
where pol.MAPORF like 'S8110135355-01'
--and cov.maporf='T0120A-99' 



select * from ZUMA where MAMANU='ACV5MM' --and MAMASE='001' --POLICY
select * from ZUMA where MAMANU='ACV5S0' and MAMASE='001' --COVER

select 'POL',* from ZUMA_LOG where MAMANU='ACV5QY' and MAMASE='001'
select 'COV',* from ZUMA_LOG where MAMANU='ACKM3A' and MAMASE='001'


select top 10 * from ZUMA order by _CDCDateTime desc


--Sprawdzenie widoku z Polisami

select top 100  MasterReferenceKey, InwardsOutwardsFlag, MasterNumberKey, MasterSequenceKey, _EventExecutionKey,MasterProductCode, *  
from Map_Master_ZUMA_build zb 
where InwardsOutwardsFlag = 2
order by zb._EventExecutionKey desc


--obecne tylko kody produkt�w
select distinct MasterProductCode --FAC, QS, SRP, XSL
from Map_Master_ZUMA_build zb 
where InwardsOutwardsFlag = 2
order by zb._EventExecutionKey desc



---
--Wyszukanie polis na RDS
--	POlisa			Cover
--	8110126052-03	811012605203T1
--	8110126052-03	811012605203F1
--	8110126052-03	811012605203F1


select top 100 * from Warehouse_Policies where PolicyNumber  ='8110126052-03'


select top 100 * from Warehouse_Covers order by _EventExecutionKey desc
select top 100 * from Warehouse_CoverDetails order by _EventExecutionKey desc

select top 100 * from Warehouse_Covers where 



--Filtrowanie danych na poziomie ZUMA
--Pobranie danych ZUMA bez Filtra na produkcty


SELECT *
into #Zuma_Policies_LSM
FROM BI_LZ.Genius.ZUMA z
WHERE (z.MACNCD in ('CHILE', 'ARGNTA', 'MLYON', 'BRZAFFIL', 'LIBSEGBR', 'MLYOFF', 'COLOMBIA', 'COL', 'LMLATAM', 'CHL', 
                'BRASIL', 'PERU', 'ECUADOR', 'LSILATAM', 'LIUILATM', 'LIBSEGPE', 'MEXICO', 'SING', 'SOF', 'AUS', 'HK',
                'BENELUX', 'BHAMUK', 'BRISTLUK', 'COLOGNUK', 'DUBAI', 'DUBUK', 'GLASGOUK', 'HAMBRGUK', 'IRELC', 'LEEDSUK',
                'LMUK', 'MANUK', 'MILANUK', 'PARISUK', 'SOEASTUK', 'SPAIN', 'SWISSUK', 'VISIONUW', 'IRE', 'LUXUK',
                'NORWAY','SWEDEN','BELGIUM') --companies
		OR z.MAMAPC in ('EQUINE', 'TPR', 'TERROR' , 'ENGNR', 'HVY', 'OFNRG', 'ONNRG', 'INLM', 'INLMQ', 'COC', 'ONNRGQ',
				'OFNRGQ', 'HVYQ', 'ENGNRQ') --, 'FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3') --lsm_products
		OR z.MADPCD in ('GLA', 'GUA', 'GUC', 'GUD', 'SD5') --lsm_departments
		OR z.MAMABN in('3MIAMI', '5MIAMI', '4PAULO', '3PR') --lsm_west_branches
		) 
AND NOT (z.MAMAPC ='TPR' AND z.MACNCD in ('III', 'ISIC'))
AND (LEFT(z.MAMABN, 1) <> '7' OR z.MAMAPC NOT IN ('INLM', 'INLMQ'))

--Dodanie klucza
ALTER TABLE #Zuma_Policies_LSM ADD  CONSTRAINT [PK_Zuma_Policies_LSM_temp] PRIMARY KEY CLUSTERED 
(
	[MAMANU] ASC,
	[MAMASE] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, DATA_COMPRESSION = PAGE) ON [PRIMARY]
GO


--Pobranie danych o samych polisach RI zwi?zanych z Istniej?cymy POlisami LSM i wybranymi produktami

--Polisy RI do ZUMA_Filtered
select distinct cov.* 
into #RI_Policies --36653
from #Zuma_Policies_LSM pol
join GENIUS.ZURI map
    on  pol.MAMANU = map.RIMANU and pol.MAMASE = map.RIMASE
join GENIUS.ZUMA cov
    on map.RIRIMN = cov.MAMANU and map.RIRIMS = cov.MAMASE
where cov.MAMAPC in ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3')

--Sprawdzenie czy polisy z RI istniej? w ZUMA_LSM

select count(distinct ri.maporf) 
from #RI_Policies ri
left join #Zuma_PoLicies_LSM pol on ri.MAMANU = pol.MAMANU and ri.MAMASE=pol.MAMASE 
where pol.mamanu is null and pol.mamase is null

select ri.*
from #RI_Policies ri
left join #Zuma_PoLicies_LSM pol on ri.MAMANU = pol.MAMANU and ri.MAMASE=pol.MAMASE 
where pol.mamanu is null and pol.mamase is null



insert into #Zuma_PoLicies
select ri.*
from #RI_Policies ri
left join #Zuma_PoLicies pol on ri.MAMANU = pol.MAMANU and ri.MAMASE=pol.MAMASE 
where pol.mamanu is null and pol.mamase is null --tylko te kt�re nie istniej? w ZUMA


-- Weryfikacja zmian w danych

--BI_LZ
select distinct top 1000 pol.maporf PolicyNr, cov.maporf cover_nr, pol.MAMAIO POL_InwardsOutwardsFlag, cov.MAMAIO RI_InwardsOutwardsFlag
,pol.LastUpdatedDate POL_LastUpdatedDate
,cov.LastUpdatedDate COV_LastUpdatedDate
,cov.MACNCD

from GENIUS.ZUMA pol
inner join GENIUS.ZURI map
    on  pol.MAMANU = map.RIMANU
    and pol.MAMASE = map.RIMASE
inner join Genius.ZUMA cov
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
WHERE cov.MAPORF in (

'811013505401F2',
'811013114501F1',
'811013258901F1',
'811012983701F1',
'811012983002F1',
'811012859201F1',
'811012857901F1',
'811012745301F4',
'811012745301F3',
'811012740101F1'
)


Sprawdzanie na RDS

--Weryfikacja danych w SIT

select distinct top 1000 pol.maporf PolicyNr, cov.maporf cover_nr, pol.MAMAIO POL_InwardsOutwardsFlag, cov.MAMAIO RI_InwardsOutwardsFlag
,pol.*
,cov.*
from ZUMA pol
inner join ZURI map
    on  pol.MAMANU = map.RIMANU
    and pol.MAMASE = map.RIMASE
inner join ZUMA cov
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
WHERE cov.MAPORF in (

'811013505401F2',
'811013114501F1',
'811013258901F1',
'811012983701F1',
'811012983002F1',
'811012859201F1',
'811012857901F1',
'811012745301F4',
'811012745301F3',
'811012740101F1'
)

--Te dane istniej?

--sprawdzenie widok�w MAP

select top 10 * from Map_Master_ZUMA_build where MasterReference in ('8110135054-01','811013505401F2')
--Dane s?

Select top 10 * from Warehouse_Policies 


--Sprawdzenie Widok�w Warehouse 
select top 10 * from Warehouse_Covers where CoverReference in ('8110135054-01','811013505401F2')
--Dane s? - tylko covers

select top 10 * from Warehouse_CoverLines where CoverReference in ('8110135054-01','811013505401F2')
--Dane s? - tylko coverlines



select top 100 * from Warehouse_CoverDetails cd
join Warehouse_Covers c on c._MergeKey_CoverDetailKey= cd._MergeKey
where c.CoverReference in ('8110135054-01','811013505401F2')
--Dane s? - tylko coverlines


select top 1000 * from Warehouse_Limits l
join Warehouse_Policies pol on pol._MergeKey = l._MergeKey_PolicyKey
where pol.PolicyReference in ('8110135054-01','811013505401F2')


