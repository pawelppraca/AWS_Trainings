
--RUN Script 

--Sprawdzenie

Use ETL_Control
Select * from [Events] where [EventCode] like '%_APAC'

Select * from [TaskGroups] where [TaskGroupCode] like '%_APAC'


Select * from [TaskGroupConnections] where [TaskGroupCode] like '%_APAC'

Select * from [EventTaskGroups] where [EventCode] like '%_APAC'


Select * from [WorkflowConstraints] where [EventCode] like '%_APAC'

Select * from [Tasks] where [TaskCode] like '%_APAC'


Select * from [ExtendedTaskAttributes] where [TaskCode] like '%_APAC'

select * from dbo.DPEventCodes


--Sprawdzenie dodania do kolejki

select * from [dbo].[WorkQueue]

select  * from [dbo].[WorkQueueLog] where ExecutionStartDate between '20240204' and '20240205' order by WorkQueueTaskKey

select  * from [dbo].[WorkQueueLog] where EventExecutionKey = 280614 order by ExecutionStartDate

select  * from [dbo].[WorkQueueErrorLog] where EventExecutionKey = 280614 order by ExecutionStartDate



select * from UserAdmin.dbo.audit_log where date_time between '2024-02-04T12:00:00' and '2024-02-04T15:00:00'


--Statystyka czas�w wykonania Publisha


select EventExecutionKey, min(ExecutionStartDate) StartDate, max(ExecutionEndDate) EndDate
into #tab
from [dbo].[WorkQueueLog] where TaskCode like '%APAC'
group by EventExecutionKey
order by EventExecutionKey


select convert(varchar, StartDate, 23) [Date], format(dateadd(ss,datediff(SECOND,StartDate,EndDate),0),'HH:mm:ss'),* from #tab
order by StartDate



--Statystyka GENIUSToDWH_DP



  
--Czasy wykonania, r�?nica pomi?dzy godzinami przeliczona ma godziny, minuty i sekundy
IF OBJECT_ID('tempdb..#tab') IS NOT NULL  DROP TABLE #tab
select EventExecutionKey, TaskCode, min(ExecutionStartDate) StartDate, max(ExecutionEndDate) EndDate, WorkflowReverseDependencyDepth
--select * 
into #tab
from [ETL_Control].[dbo].[WorkQueueLog] where TaskCode like '%GENIUS%DWH_DP'
and ExecutionStartDate > '2024-02-15T19:00:00' and  ExecutionStartDate < '2024-02-16T10:00:00' 
group by EventExecutionKey, TaskCode, WorkflowReverseDependencyDepth
order by WorkflowReverseDependencyDepth


--select * from #tab

select StartDate,convert(varchar, StartDate, 23) [Date], TaskCode, format(dateadd(ss,datediff(SECOND,StartDate,EndDate),0),'HH:mm:ss') [Duration_time] , WorkflowReverseDependencyDepth
into #t15_onp
from #tab
order by StartDate



select o.TaskCode, a5.Duration_time APAC_15 , o.Duration_time ONP_15, a8.Duration_time APAC_18, o8.Duration_time ONP_18
from #t15_onp o
left join #t15_apac a5 on a5.taskcode = o.taskcode and o.WorkflowReverseDependencyDepth = a5.WorkflowReverseDependencyDepth
left join #t18_apac a8 on a8.taskcode = o.taskcode and o.WorkflowReverseDependencyDepth = a8.WorkflowReverseDependencyDepth
left join #t18_onp o8 on o8.taskcode = o.taskcode and o.WorkflowReverseDependencyDepth = o8.WorkflowReverseDependencyDepth
order by o.WorkflowReverseDependencyDepth


select * 
from #t18_onp o
left join #t18_apac a on a.taskcode = o.taskcode 
order by 
where a.TaskCode is null