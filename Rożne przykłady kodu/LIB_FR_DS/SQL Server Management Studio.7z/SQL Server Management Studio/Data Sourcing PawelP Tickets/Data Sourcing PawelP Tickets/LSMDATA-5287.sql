﻿--Tabela z Paramtrami

USE [ETL_Control]

SELECT [ParameterName],
       [ParameterType],
       [ParameterValue] FROM [ETL_Control].dbo.[Parameters]

--INSERT INTO [ETL_Control].dbo.[Parameters] ([ParameterName],[ParameterType],[ParameterValue]) VALUES ('APAC_Load','ControlParameter','0')

DELETE FROM [ETL_Control].dbo.[Parameters] WHERE [ParameterName]='APAC_Load'


EXEC [UserAdmin].dbo.[usp_DP_SETParameter] 'APAC_Load',1




EXEC ETL_Control.dbo.[SETParameter] 'APAC_Load',0

SELECT TOP(1) 1 FROM [ETL_Control].dbo.[Parameters] WHERE [ParameterName] = 'APAC_Load' AND [ParameterValue] = '1'


USE [UserAdmin]
GO
/****** Object:  StoredProcedure [dbo].[usp_DPAddEventToQueue]    Script Date: 8/1/2024 10:55:33 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_DP_SETParameter]
                @ParameterName NVARCHAR(100),
				@ParameterValue NVARCHAR(250)

AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY

		EXEC ETL_Control.dbo.SetParameter @ParameterName = @ParameterName, @ParameterValue = @ParameterValue

		INSERT INTO dbo.audit_log (date_time, executed_proc, host_machine_name, executing_user_name, original_login_name, suser_sname_name, system_user_name, username_name) 
				VALUES (GETDATE(), OBJECT_NAME(@@PROCID), HOST_NAME(), CURRENT_USER, ORIGINAL_LOGIN(), SUSER_SNAME(), SYSTEM_USER, USER_NAME())


	END TRY
	BEGIN CATCH
		DECLARE @ErrorMessage NVARCHAR(4000);  
			DECLARE @ErrorSeverity INT;  
			DECLARE @ErrorState INT; 
		
			SELECT   
				@ErrorMessage = ERROR_MESSAGE(),  
				@ErrorSeverity = ERROR_SEVERITY(),  
				@ErrorState = ERROR_STATE();  

			RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);

	END CATCH;

	RETURN 0
END



SELECT * FROM [ETL_Control].dbo.ExtendedTaskAttributes WHERE TaskCode = 'EXEC_CONDITIONALEVENT_ELGAR'
SELECT * FROM [ETL_Control].dbo.ExtendedTaskAttributes WHERE TaskCode = 'EXEC_CONDITIONAL_EVENT_BDX_MDStoBDX'

SELECT * FROM etl_control.dbo.tasks t 
JOIN [ETL_Control].[dbo].[TaskGroups] tg ON tg.[TaskGroupCode]=t.[TaskGroupCode]
WHERE [TaskCode] LIKE '%COND%'


--Warunkowe uruchomienia sa w MASTER_BDX_LOAD

--Event warunkowy musi uruchamiac SSIS o nazwie Control_Shared_ExecuteSQLScript.dtsx i w parametrze wejsciowy
IF (SELECT 1 FROM [dbo].[BordereauxCandidateLoads] WHERE [EventName] = 'BDX_MDStoBDX') = 1 BEGIN EXEC [dbo].[ExecuteEventSync] @iEventCode = N'BDX_MDStoBDX', @iParentEventExecutionKey = ? END



--Wszystkie taski eventu
select * from ETL_Control.[dbo].[EventTaskGroups] etg
join ETL_Control.dbo.tasks t on t.taskgroupCode=etg.taskgroupcode
WHERE t.[TaskCode] LIKE '%COND%'


--Sprawdzenie ETL Contolera

USE [ETL_Control]
		SELECT * 
		--delete
		FROM [dbo].[ExtendedTaskAttributes] WHERE [TaskCode] = N'Conditional_Master_Publish_DWH_DATABASES_APAC'

		SELECT * 
		--delete
		FROM [dbo].[Tasks] WHERE [TaskCode] = N'Conditional_Master_Publish_DWH_DATABASES_APAC'

		SELECT * 
		--delete
		FROM [dbo].[WorkflowConstraints] WHERE [EventCode] = N'GENIUSToDWH_DP'	AND [ConstrainedTaskGroupCode] = N'Conditional_Master_Publish_DWH_DATABASES_APAC'	

		SELECT * 
		--delete
		FROM [dbo].[EventTaskGroups] WHERE [EventCode] = N'GENIUSToDWH_DP' AND [TaskGroupCode] = N'Conditional_Master_Publish_DWH_DATABASES_APAC'

		
		SELECT * 
		--delete
		FROM [dbo].[TaskGroupConnections] WHERE [TaskGroupCode] = N'Conditional_Master_Publish_DWH_DATABASES_APAC' 

		SELECT * 
		--DELETE
		FROM [dbo].[TaskGroups] WHERE [TaskGroupCode] = N'Conditional_Master_Publish_DWH_DATABASES_APAC' 


--Dodanie brakujących rekordów w DEV2
	INSERT 
		[dbo].[TaskGroups] ([TaskGroupCode],	 [TaskTypeCode],	 [LayerCode],	 [SourceSystemCode],	 [TaskGroupDescription],	 [SemaphoreName],	 [MaxConcurrentExecutableTasks]) 
	VALUES 
			(N'DimensionGENIUSLoadGroup_MonthEnd_DP'					,	 N'BUILDDIMENSION'	,	 N'DW'		,	 N'GENIUS'		,	 N'Loading data into GeniusMonthEnd. A task from this group must be run at the very end of the event'	,	 NULL,	 NULL)


	INSERT 
		[dbo].[TaskGroupConnections] ([TaskGroupConnectionKey], [ConnectionCode], [ConnectionBindingCode], [TaskGroupCode], [TaskTypeCode], [LayerCode], [SourceSystemCode]) 
	VALUES 

		(NEXT VALUE FOR dbo.ETLControllerSequence, N'ODSGENIUS_DP'				, N'SOURCE'		, N'DimensionGENIUSLoadGroup_MonthEnd_DP'	, N'BUILDDIMENSION', N'DW', N'GENIUS')
	,	(NEXT VALUE FOR dbo.ETLControllerSequence, N'WAREHOUSEREPOSITORY_DP'	, N'TARGET'		, N'DimensionGENIUSLoadGroup_MonthEnd_DP'	, N'BUILDDIMENSION', N'DW', N'GENIUS')
	,	(NEXT VALUE FOR dbo.ETLControllerSequence, N'CONTROL'					, N'CONTROL'	, N'DimensionGENIUSLoadGroup_MonthEnd_DP'	, N'BUILDDIMENSION', N'DW', N'GENIUS')


	INSERT 
		[dbo].[EventTaskGroups] ([EventTaskGroupKey], [EventCode], [TaskGroupCode], [TaskTypeCode], [LayerCode], [SourceSystemCode]) 
	VALUES 
	(NEXT VALUE FOR dbo.ETLControllerSequence, N'GENIUSToDWH_DP', N'DimensionGENIUSLoadGroup_MonthEnd_DP', N'BUILDDIMENSION', N'DW', N'GENIUS')


--Sprawdzenie ETL


SELECT * FROM [dbo].[EventTaskGroups] WHERE [TaskGroupCode]  LIKE 'DimensionGENIUSLoadGroup_MonthEnd_DP'

SELECT * FROM [dbo].[EventTaskGroups] WHERE [EventCode]  LIKE '%APAC%'


SELECT * FROM [dbo].[WorkflowConstraints] WHERE [EventCode] = 'GENIUSToDWH_DP'

SELECT NEXT VALUE FOR dbo.ETLControllerSequence

--ALTER SEQUENCE ETLControllerSequence RESTART WITH 7000 ;  


SELECT MAX([WorkflowConstraintKey])) FROM [dbo].[WorkflowConstraints]


SELECT MAX(TaskGroupConnectionKey) FROM [dbo].[TaskGroupConnections]



		DELETE FROM
		[dbo].[ExtendedTaskAttributes] WHERE [TaskCode] = N'Conditional_Master_Publish_DWH_DATABASES_APAC'

		DELETE FROM
		[dbo].[Tasks] WHERE [TaskCode] = N'Conditional_Master_Publish_DWH_DATABASES_APAC'

		DELETE FROM
		[dbo].[WorkflowConstraints] WHERE [EventCode] = N'GENIUSToDWH_DP'	AND [ConstrainedTaskGroupCode] = N'Conditional_Master_Publish_DWH_DATABASES_APAC'	

		DELETE FROM
		[dbo].[EventTaskGroups] WHERE [EventCode] = N'GENIUSToDWH_DP' AND [TaskGroupCode] = N'Conditional_Master_Publish_DWH_DATABASES_APAC'

		
		DELETE FROM
		[dbo].[TaskGroupConnections] WHERE [TaskGroupCode] = N'Conditional_Master_Publish_DWH_DATABASES_APAC' 

		DELETE FROM
		[dbo].[TaskGroups] WHERE [TaskGroupCode] = N'Conditional_Master_Publish_DWH_DATABASES_APAC' 




SELECT * FROM [dbo].[ExtendedTaskAttributes] WHERE [TaskCode] = N'Conditional_Master_Publish_DWH_DATABASES_APAC'

SELECT * FROM [dbo].[Tasks] WHERE [TaskCode] = N'Conditional_Master_Publish_DWH_DATABASES_APAC'

SELECT * FROM [dbo].[WorkflowConstraints] WHERE [EventCode] = N'GENIUSToDWH_DP'	AND [ConstrainedTaskGroupCode] = N'Conditional_Master_Publish_DWH_DATABASES_APAC'	

SELECT * FROM [dbo].[EventTaskGroups] WHERE [EventCode] = N'GENIUSToDWH_DP' AND [TaskGroupCode] = N'Conditional_Master_Publish_DWH_DATABASES_APAC'
	
SELECT * FROM [dbo].[TaskGroupConnections] WHERE [TaskGroupCode] = N'Conditional_Master_Publish_DWH_DATABASES_APAC' 

SELECT * FROM [dbo].[TaskGroups] WHERE [TaskGroupCode] = N'Conditional_Master_Publish_DWH_DATABASES_APAC' 

