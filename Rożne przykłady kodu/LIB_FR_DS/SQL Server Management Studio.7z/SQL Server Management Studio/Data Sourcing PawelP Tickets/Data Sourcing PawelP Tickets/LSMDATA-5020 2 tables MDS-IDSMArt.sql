select * from MDSDatabase.mdm.SIILMALClassMapping

--SIILMALClassMapping
-----------------------------------------
USE Staging_MDS

CREATE TABLE [dbo].[SIILMALClassMapping](
	[ID] [INT] NULL
	,[MUID] [UNIQUEIDENTIFIER] NULL
	,[VersionName] [NVARCHAR](50) NULL
	,[VersionNumber] [INT] NULL
	,[Version_ID] [INT] NULL
	,[VersionFlag] [NVARCHAR](50) NULL
	,[Name] [NVARCHAR](250) NULL
	,[Code] [NVARCHAR](250) NOT NULL
	,[ChangeTrackingMask] INT NOT NULL
    ,[DataClass] [NVARCHAR](250) NULL
    ,[ReservingClass_Code] [NVARCHAR](250) NULL
    ,[ReservingClass_Name] [NVARCHAR](250) NULL
    ,[ReservingClass_ID] INT NULL
    ,[CMTClass_Code] [NVARCHAR](250) NULL
    ,[CMTClass_Name] [NVARCHAR](250) NULL
    ,[CMTClass_ID] INT NULL
    ,[EnterDateTime]  [DATETIME2](3) NOT NULL
    ,[EnterUserName] [NVARCHAR](100) NULL
	,[EnterVersionNumber] [INT] NULL
	,[LastChgDateTime] [DATETIME2](3) NULL
	,[LastChgUserName] [NVARCHAR](100) NULL
	,[LastChgVersionNumber] [INT] NULL
	,[ValidationStatus] [NVARCHAR](250) NULL
 CONSTRAINT [PK_SIILMALClassMapping] PRIMARY KEY CLUSTERED 
(
	[Code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

---SIILMIEClassMapping
---------------------------------------------------------

CREATE TABLE [dbo].[SIILMIEClassMapping](
	[ID] [INT] NULL
	,[MUID] [UNIQUEIDENTIFIER] NULL
	,[VersionName] [NVARCHAR](50) NULL
	,[VersionNumber] [INT] NULL
	,[Version_ID] [INT] NULL
	,[VersionFlag] [NVARCHAR](50) NULL
	,[Name] [NVARCHAR](250) NULL
	,[Code] [NVARCHAR](250) NOT NULL
	,[ChangeTrackingMask] INT NOT NULL
    ,[S2ReserveClass] [NVARCHAR](100) NULL
    ,[CMTClass_Code] [NVARCHAR](250) NULL
    ,[CMTClass_Name] [NVARCHAR](250) NULL
    ,[CMTClass_ID] INT NULL
    ,[ReservingClass_Code] [NVARCHAR](250) NULL
    ,[ReservingClass_Name] [NVARCHAR](250) NULL
    ,[ReservingClass_ID] INT NULL
	,[EnterDateTime]  [DATETIME2](3) NOT NULL
    ,[EnterUserName] [NVARCHAR](100) NULL
	,[EnterVersionNumber] [INT] NULL
	,[LastChgDateTime] [DATETIME2](3) NULL
	,[LastChgUserName] [NVARCHAR](100) NULL
	,[LastChgVersionNumber] [INT] NULL
	,[ValidationStatus] [NVARCHAR](250) NULL
 CONSTRAINT [PK_SIILMIEClassMapping] PRIMARY KEY CLUSTERED 
(
	[Code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
