select ClaimNo from [dbo].Map_GeniusClaimHeader 

select [Claim Number],Claimant, count(*) cnt
from Staging_GENIUS.dbo.CBIClaimListing 
group by [Claim Number],Claimant
having count(9) > 1
order by count(9) desc


select  [Claim Number],Claimant--, *
from Staging_GENIUS.dbo.CBIClaimListing 
where [Claim Number]='AMSENG000233484'
group by [Claim Number],Claimant
having count(9) >1

select  [Claim Number],Claimant--, *
from Staging_GENIUS.dbo.CBIClaimListing 
where [Claim Number]='DUBENG000191948'
group by [Claim Number],Claimant
having count(9) >1

select [Claim Number],Claimant,[Loss Fund], *
from Staging_GENIUS.dbo.CBIClaimListing 
where [Claim Number]='DUBCAS000193141'


select [Claim Number],Claimant,[Loss Fund], *
from Staging_GENIUS.dbo.CBIClaimListing 
where [Claim Number]='DUBENG000191948'

select top 100 * from [IDS].[CBIClaimListing]