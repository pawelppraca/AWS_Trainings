--drop table #cbi_RADM

select * 
into #UAT_IDS_CBIClaimListing
from IDS.[CBIClaimListing] 
--3,5 minuty, 924737 records
-- 1:12:17 - 993864 records


select * 
from #UAT_IDS_CBIClaimListing


SELECT 
	 distinct
	 x.[Catastrophe Code]
,	 x.[Catastrophe Description]
,	 x.[Cause of Loss 1]
,	 x.[Cause of Loss 4 - Type]
,	 x.[Cause Of Loss2]
,	 x.[Claim Closure Reason]
,	 x.[Claim Create Date]
,	 x.[Claim Current State]
,	 x.[Claim Description]
,	 x.[Claim Handler]
,	 x.[Claim Number]
,	 x.[Claim Title]
,	 x.[Claim Type]
,	 x.[Date Last Closed]
,	 x.[Date Last Reopened]
,	 x.[Date Of Loss]
,	 x.[Date Reported/Event]
,	 x.[First Exposure Claimant]
,	 x.[Loss Country]
,	 x.[Severity]
,	 x.[Claim Event Code]
,	 x.[Event Description]
,	 x.[TPA Claim Number]
,	 x.[Cause of Loss3]
,	 x.[Loss City]
,	 x.[Loss State]
,	 x.[Region]
,	 x.[Loss Region]
,	 x.[Cause of Loss 1 Other Description]
,	 x.[Cause of Loss 2 Other Description]
,	 x.[Cause of Loss 3 Other Description]
,	 x.[Cause of Loss 4 Other Description]    
,	 x.[Cause Of Loss5]                       
,	 x.[Loss Code Group]                      
,	 x.[Organization]                         
,	 x.[Cyber Consideration]                  
,	 x.[Cyber Consideration Other Description]
,	 x.[Ransomware Aspect]
,	 x.[Batched Claim]	
,	 x.[Block File]
,	 x.[Loss Fund]
,	 x.[Policy number]
,	 x.[Coverage Name]
,	 x.[Business Sub Component]
,	 x.[Business Component]
,	 x.[Insured Name]
,	 x.[Branch]
,	 x.[Location ID]
,	 x.[Total Inr curr(Gross)]
--,	 sum(x.[Total Inr curr(Gross)]) [Total Inr curr(Gross)]
,	 x.[Broker Name]
,	 x.[Underwriter]
,	 x.[Risk engineer]
,	 x.[LIU Share]
into #UAT_CBIClaimListing2
FROM

(
SELECT  
	 [Catastrophe Code]
,	 [Catastrophe Description]
,	 [Cause of Loss 1]
,	 [Cause of Loss 4 - Type]
,	 [Cause Of Loss2]
,	 [Claim Closure Reason]
,	 [Claim Create Date]
,	 [Claim Current State]
,	 [Claim Description]
,	 [Claim Handler]
,	 [Claim Number]
,	 [Claim Title]
,	 [Claim Type]
,	 [Date Last Closed]
,	 [Date Last Reopened]
,	 [Date Of Loss]
,	 [Date Reported/Event]
,	 [First Exposure Claimant]
,	 [Loss Country]
,	 [Severity]
,	 [Claim Event Code]
,	 [Event Description]
,	 [TPA Claim Number]
,	 [Cause of Loss3]
,	 [Loss City]
,	 [Loss State]
,	 [Region]
,	 [Loss Region]
,	 [Cause of Loss 1 Other Description]
,	 [Cause of Loss 2 Other Description]
,	 [Cause of Loss 3 Other Description]
,	 [Cause of Loss 4 Other Description]    
,	 [Cause Of Loss5]                       
,	 [Loss Code Group]                      
,	 [Organization]                         
,	 [Cyber Consideration]                  
,	 [Cyber Consideration Other Description]
,	 [Ransomware Aspect]
,	 [Batched Claim]	
,	 [Block File]
,	 [Loss Fund]
,	 [Policy number]
,	 [Coverage Name]
,	 [Business Sub Component]
,	 [Business Component]
,	 [Insured Name]
,	 [Branch]
,	 [Location ID]
,	 [Total Inr curr(Gross)]
,	 [Broker Name]
,	 [Underwriter]
,	 [Risk engineer]
,	 [LIU Share]
,	 ROW_NUMBER() OVER (PARTITION BY [Claim Number], [Coverage Name], Claimant ORDER BY [Claim Create Date]) AS RowNum
FROM #UAT_IDS_CBIClaimListing 
)x 
WHERE x.RowNum=1
--group by 
--	 x.[Catastrophe Code]
--,	 x.[Catastrophe Description]
--,	 x.[Cause of Loss 1]
--,	 x.[Cause of Loss 4 - Type]
--,	 x.[Cause Of Loss2]
--,	 x.[Claim Closure Reason]
--,	 x.[Claim Create Date]
--,	 x.[Claim Current State]
--,	 x.[Claim Description]
--,	 x.[Claim Handler]
--,	 x.[Claim Number]
--,	 x.[Claim Title]
--,	 x.[Claim Type]
--,	 x.[Date Last Closed]
--,	 x.[Date Last Reopened]
--,	 x.[Date Of Loss]
--,	 x.[Date Reported/Event]
--,	 x.[First Exposure Claimant]
--,	 x.[Loss Country]
--,	 x.[Severity]
--,	 x.[Claim Event Code]
--,	 x.[Event Description]
--,	 x.[TPA Claim Number]
--,	 x.[Cause of Loss3]
--,	 x.[Loss City]
--,	 x.[Loss State]
--,	 x.[Region]
--,	 x.[Loss Region]
--,	 x.[Cause of Loss 1 Other Description]
--,	 x.[Cause of Loss 2 Other Description]
--,	 x.[Cause of Loss 3 Other Description]
--,	 x.[Cause of Loss 4 Other Description]    
--,	 x.[Cause Of Loss5]                       
--,	 x.[Loss Code Group]                      
--,	 x.[Organization]                         
--,	 x.[Cyber Consideration]                  
--,	 x.[Cyber Consideration Other Description]
--,	 x.[Ransomware Aspect]
--,	 x.[Batched Claim]	
--,	 x.[Block File]
--,	 x.[Loss Fund]
--,	 x.[Policy number]
--,	 x.[Coverage Name]
--,	 x.[Business Sub Component]
--,	 x.[Business Component]
--,	 x.[Insured Name]
--,	 x.[Branch]
--,	 x.[Location ID]
--,	 x.[Broker Name]
--,	 x.[Underwriter]
--,	 x.[Risk engineer]
--,	 x.[LIU Share]

ORDER BY  [Claim Number]



select * from #UAT_CBIClaimListing



select [Claim Number],  [Coverage Name],  [Policy number], [Total Inr curr(Gross)], Claimant,* 
from #UAT_IDS_CBIClaimListing where [Claim Number]='HOUHUL000023645'

select [Claim Number],  [Coverage Name],  [Policy number],[Total Inr curr(Gross)], * 
from #UAT_CBIClaimListing where [Claim Number]='HOUHUL000023645'


select [Claim Number],  [Coverage Name],  [Policy number], [Total Inr curr(Gross)], * 
from #UAT_CBIClaimListing2 where [Claim Number]='HOUHUL000023645'





select [Claim Number],  [Coverage Name],  [Policy number] , count(*)  duplicates_qty
from #UAT_CBIClaimListing3
group by [Claim Number],  [Coverage Name], [Policy number]
having count(*) > 1





select cbi.[Claim Number],  cbi.[Coverage Name], cbi.[Policy number],cbi.[Total Inr curr(Gross)], [Business Sub Component], [Business Component], *  
from #UAT_IDS_CBIClaimListing cbi
join (
	select [Claim Number],  [Coverage Name],  [Policy number] , count(*)  duplicates_qty
	from #UAT_CBIClaimListing
	group by [Claim Number],  [Coverage Name], [Policy number]
	having count(*) > 1
) dps on dps.[Claim Number] = cbi.[Claim Number] and dps.[Coverage Name]=cbi.[Coverage Name] and dps.[Policy number]=cbi.[Policy number]
order by cbi.[Claim Number]




select cbi.[Claim Number],  cbi.[Coverage Name], cbi.[Policy number],cbi.[Total Inr curr(Gross)], [Business Sub Component], [Business Component], *  
from #UAT_CBIClaimListing cbi
where [Claim Number] ='4NSPC000366901' and [Coverage Name]='INLAND MARINE FOR SPC' 