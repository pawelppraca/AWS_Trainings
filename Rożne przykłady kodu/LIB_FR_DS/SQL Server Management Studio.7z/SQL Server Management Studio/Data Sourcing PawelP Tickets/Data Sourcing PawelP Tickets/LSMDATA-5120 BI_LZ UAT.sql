--Sprawdzenie powi?za? ZUMA-ZURI-ZUMA
--Sprawdzenie danych na BI_LZ UAT


SELECT count(*)
FROM BI_LZ.GEnius.ZUMA z
WHERE (z.MACNCD in ('CHILE', 'ARGNTA', 'MLYON', 'BRZAFFIL', 'LIBSEGBR', 'MLYOFF', 'COLOMBIA', 'COL', 'LMLATAM', 'CHL', 
                'BRASIL', 'PERU', 'ECUADOR', 'LSILATAM', 'LIUILATM', 'LIBSEGPE', 'MEXICO', 'SING', 'SOF', 'AUS', 'HK',
                'BENELUX', 'BHAMUK', 'BRISTLUK', 'COLOGNUK', 'DUBAI', 'DUBUK', 'GLASGOUK', 'HAMBRGUK', 'IRELC', 'LEEDSUK',
                'LMUK', 'MANUK', 'MILANUK', 'PARISUK', 'SOEASTUK', 'SPAIN', 'SWISSUK', 'VISIONUW', 'IRE', 'LUXUK',
                'NORWAY','SWEDEN','BELGIUM') --companies
		OR z.MAMAPC in ('EQUINE', 'TPR', 'TERROR' , 'ENGNR', 'HVY', 'OFNRG', 'ONNRG', 'INLM', 'INLMQ', 'COC', 'ONNRGQ','OFNRGQ', 'HVYQ', 'ENGNRQ') --, 'FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3') --lsm_products
		OR z.MADPCD in ('GLA', 'GUA', 'GUC', 'GUD', 'SD5') --lsm_departments
		OR z.MAMABN in('3MIAMI', '5MIAMI', '4PAULO', '3PR') --lsm_west_branches
		) 
AND NOT (z.MAMAPC ='TPR' AND z.MACNCD in ('III', 'ISIC'))
AND (LEFT(z.MAMABN, 1) <> '7' OR z.MAMAPC NOT IN ('INLM', 'INLMQ'))

--count: 2373118 (bez nowych produkt�w)
--count: 2441508 (z nowymi produktami)
--R�znica: select  2441508 - 2373118 = 68390


SELECT *
into #Zuma_PoLicies_no_new_prod
FROM BI_LZ.Genius.ZUMA z
WHERE (z.MACNCD in ('CHILE', 'ARGNTA', 'MLYON', 'BRZAFFIL', 'LIBSEGBR', 'MLYOFF', 'COLOMBIA', 'COL', 'LMLATAM', 'CHL', 
                'BRASIL', 'PERU', 'ECUADOR', 'LSILATAM', 'LIUILATM', 'LIBSEGPE', 'MEXICO', 'SING', 'SOF', 'AUS', 'HK',
                'BENELUX', 'BHAMUK', 'BRISTLUK', 'COLOGNUK', 'DUBAI', 'DUBUK', 'GLASGOUK', 'HAMBRGUK', 'IRELC', 'LEEDSUK',
                'LMUK', 'MANUK', 'MILANUK', 'PARISUK', 'SOEASTUK', 'SPAIN', 'SWISSUK', 'VISIONUW', 'IRE', 'LUXUK',
                'NORWAY','SWEDEN','BELGIUM') --companies
		OR z.MAMAPC in ('EQUINE', 'TPR', 'TERROR' , 'ENGNR', 'HVY', 'OFNRG', 'ONNRG', 'INLM', 'INLMQ', 'COC', 'ONNRGQ','OFNRGQ', 'HVYQ', 'ENGNRQ') --, 'FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3') --lsm_products
		OR z.MADPCD in ('GLA', 'GUA', 'GUC', 'GUD', 'SD5') --lsm_departments
		OR z.MAMABN in('3MIAMI', '5MIAMI', '4PAULO', '3PR') --lsm_west_branches
		) 
AND NOT (z.MAMAPC ='TPR' AND z.MACNCD in ('III', 'ISIC'))
AND (LEFT(z.MAMABN, 1) <> '7' OR z.MAMAPC NOT IN ('INLM', 'INLMQ'))

--Wszystkich Polis bez nowych produkt�w
select count(*) from #Zuma_PoLicies_no_new_prod --2373159


--COVERY z Polis bez nowych produkt�w
select *
INTO #Covers_no_new_Prod --61589
FROM #Zuma_PoLicies_no_new_prod
WHERE MAMAIO=2


SELECT COUNT(DISTINCT MAPORF) 
FROM #Zuma_PoLicies_no_new_prod --2373118

--Ilosc COVERS: MAMAIO=2
SELECT COUNT(DISTINCT MAPORF) 
FROM #Zuma_POLicies_no_new_prod WHERE MAMAIO=2 --61565

--Ilosc COver�w MAMAIO=2 kt�rych nie ma w ZURI
SELECT cov.*  --34930
into #Covers_no_new_Prod_no_ZURI
from #Covers_no_new_Prod cov 
LEFT JOIN GENIUS.ZURI map
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
LEFT JOIN #Zuma_POLicies_no_new_prod pol
    on  pol.MAMANU = map.RIMANU
    and pol.MAMASE = map.RIMASE
WHERE cov.MAMAIO=2
AND pol.MAMANU IS NULL AND pol.MAMASE IS NULL


--ile jest COver�w z wybranej listy produkt�w ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3') kt�re nie maj? ZURI

SELECT COUNT(DISTINCT cov.MAPORF)  --34730
from #Covers_no_new_Prod cov 
LEFT JOIN GENIUS.ZURI map
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
LEFT JOIN #Zuma_POLicies_no_new_prod pol
    on  pol.MAMANU = map.RIMANU
    and pol.MAMASE = map.RIMASE
WHERE cov.MAMAIO=2
AND pol.MAMANU IS NULL AND pol.MAMASE IS NULL
AND cov.MAMAPC in ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3')



--Dodanie nowych produkt�w


SELECT *
into #Zuma_PoLicies_new_prod
FROM BI_LZ.Genius.ZUMA z
WHERE (z.MACNCD in ('CHILE', 'ARGNTA', 'MLYON', 'BRZAFFIL', 'LIBSEGBR', 'MLYOFF', 'COLOMBIA', 'COL', 'LMLATAM', 'CHL', 
                'BRASIL', 'PERU', 'ECUADOR', 'LSILATAM', 'LIUILATM', 'LIBSEGPE', 'MEXICO', 'SING', 'SOF', 'AUS', 'HK',
                'BENELUX', 'BHAMUK', 'BRISTLUK', 'COLOGNUK', 'DUBAI', 'DUBUK', 'GLASGOUK', 'HAMBRGUK', 'IRELC', 'LEEDSUK',
                'LMUK', 'MANUK', 'MILANUK', 'PARISUK', 'SOEASTUK', 'SPAIN', 'SWISSUK', 'VISIONUW', 'IRE', 'LUXUK',
                'NORWAY','SWEDEN','BELGIUM') --companies
		OR z.MAMAPC in ('EQUINE', 'TPR', 'TERROR' , 'ENGNR', 'HVY', 'OFNRG', 'ONNRG', 'INLM', 'INLMQ', 'COC', 'ONNRGQ','OFNRGQ', 'HVYQ', 'ENGNRQ', 'FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3') --lsm_products
		OR z.MADPCD in ('GLA', 'GUA', 'GUC', 'GUD', 'SD5') --lsm_departments
		OR z.MAMABN in('3MIAMI', '5MIAMI', '4PAULO', '3PR') --lsm_west_branches
		) 
AND NOT (z.MAMAPC ='TPR' AND z.MACNCD in ('III', 'ISIC'))
AND (LEFT(z.MAMABN, 1) <> '7' OR z.MAMAPC NOT IN ('INLM', 'INLMQ'))

--Wszystkich Polis bez nowych produkt�w
select count(*) from #Zuma_PoLicies_new_prod --2441576


--COVERY z Polis bez nowych produkt�w
select *
INTO #All_Covers_new_Prod --130006
FROM #Zuma_PoLicies_new_prod
WHERE MAMAIO=2


select count(distinct MAPORF) from #All_Covers_new_Prod --129955

drop table if exists #Covers_new_Prod_no_ZURI
--Ilosc COver�w MAMAIO=2 kt�rych nie ma w ZURI
SELECT cov.*  --1890115
into #Covers_new_Prod_no_ZURI
from #All_Covers_new_Prod cov 
LEFT JOIN GENIUS.ZURI map
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
LEFT JOIN #Zuma_POLicies_no_new_prod pol
    on  pol.MAMANU = map.RIMANU
    and pol.MAMASE = map.RIMASE
WHERE cov.MAMAIO=2
AND pol.MAMANU IS NULL AND pol.MAMASE IS NULL


select count(distinct MAPORF) from #Covers_new_Prod_no_ZURI --93615




select * from BI_LZ.GEnius.ZUMA 
where MAPORF in (
'2000012609-04',
'T0127T-22B',
'T0127V2-22A',
'T0127V-22A',
'T0127V-22B',
'T0127A-22B',
'TESTPROP5',
'20509389',
'T0127V4-22A',
'8110116963-01',
'T0127V5-22A',
'T0127V3-22B',
'OPP0288891',
'TESTPROP4',
'T0127V4-22B',
'F0007876',
'T0127V2-22B',
'T0127Y1-22A',
'T0127T-22A',
'T0127V1-22A',
'T0127Y-22A',
'T0127A-22A',
'T0127V3-22A',
'2000283426-01',
'BRLATOU0102241',
'F0007702',
'TESTPROP3',
'S8110116963-01',
'T0127V1-22B',
'1000462862-01',
'T0127T2-22A',
'EQM101284-01',
'T0127V5-22B',
'TESTPROP2',
'T0127Y1-22B',
'TESTPROP1',
'ZUB4FVW0PA22',
'1000462862-02',
'S2000311901-01',
'T0127Y-22B',
'T0127T2-22B'
)