IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORK].[CBIClaimListing]') AND type in (N'U'))
DROP TABLE [WORK].[CBIClaimListing]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [WORK].[CBIClaimListing] (
    [Claim Number]                          NVARCHAR (100)  NULL,
    [Batched Claim]			                NVARCHAR (3)    NULL,
	[Block File]			                NVARCHAR (3)    NULL,
    [Catastrophe Code]                      NVARCHAR (10)   NULL,
    [Catastrophe Description]               NVARCHAR (100)  NULL,
    [Cause of Loss 1]                       NVARCHAR (100)  NULL,
    [Cause of Loss 4 - Type]                NVARCHAR (100)  NULL,
    [Cause Of Loss2]                        NVARCHAR (100)  NULL,
    [Claim Closure Reason]                  NVARCHAR (100)  NULL,
    [Claim Create Date]                     DATETIME2 (3)   NULL,
    [Claim Current State]                   NVARCHAR (100)  NULL,
    [Claim Description]                     NVARCHAR (1300) NULL,
    [Claim Handler]                         NVARCHAR (200)  NULL,
    [Claim Title]                           NVARCHAR (256)  NULL,
    [Claim Type]                            NVARCHAR (100)  NULL,
    [Date Last Closed]                      DATETIME2 (3)   NULL,
    [Date Last Reopened]                    DATETIME2 (3)   NULL,
    [Date Of Loss]                          DATE            NULL,
    [Date Reported/Event]                   DATETIME2 (3)   NULL,
    [First Exposure Claimant]               NVARCHAR (200)  NULL,
    [Loss Country]                          NVARCHAR (100)  NULL,
    [Severity]                              NVARCHAR (100)  NULL,
    [_DateCreated]                          DATETIME2 (7)   NULL,
    [_EventExecutionKey]                    INT             NULL,
    [_LastAction]                           NCHAR (1)       NULL,
    [Claim Event Code]                      NVARCHAR (10)   NULL,
    [Event Description]                     NVARCHAR (100)  NULL,
    [TPA Claim Number]                      NVARCHAR (100)  NULL,
    [Cause of Loss3]                        NVARCHAR (100)  NULL,
    [Loss City]                             NVARCHAR (256)  NULL,
    [Loss Fund]								NVARCHAR (3)	NULL,
    [Loss State]                            NVARCHAR (100)  NULL,
	[Region]				                NVARCHAR (100)  NULL,
	[Loss Region]                           NVARCHAR (100)  NULL,
    [Cause of Loss 1 Other Description]     NVARCHAR(256) NULL,
    [Cause of Loss 2 Other Description]     NVARCHAR(256) NULL,
    [Cause of Loss 3 Other Description]     NVARCHAR(256) NULL,
    [Cause of Loss 4 Other Description]     NVARCHAR(256) NULL,
    [Cause Of Loss5]                        NVARCHAR(250) NULL,
    [Loss Code Group]                       NVARCHAR(250) NULL,
    [Organization]                          NVARCHAR(250) NULL,
    [Cyber Consideration]                   NVARCHAR(250) NULL,
    [Cyber Consideration Other Description] NVARCHAR(256) NULL,
    [Ransomware Aspect]                     NVARCHAR(250) NULL,
	[Policy number]							NVARCHAR(50)	NULL,
	[Coverage Name]							NVARCHAR(100)	NOT NULL,
	[Business Sub Component]				NVARCHAR(100)	NULL,
	[Business Component]					NVARCHAR(100)	NULL,
	[Insured Name]							NVARCHAR(200)	NULL,
	[Branch]								NVARCHAR(50)	NULL,
	[Location ID]							NVARCHAR(100)	NULL,
	[Total Inr curr(Gross)]					NUMERIC(38,4)	NULL,
	[Broker Name]							NVARCHAR(200)	NULL,
	[Underwriter]							NVARCHAR(200)	NULL,
	[Risk engineer]							NVARCHAR(200)	NULL,
	[LIU Share]								NUMERIC(28,4)	NULL,
);


GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_WORK_CBIClaimListing_Claim Number]
    ON [WORK].[CBIClaimListing]([Claim Number],[Coverage Name]  ASC)
	INCLUDE ([Catastrophe Code],[Catastrophe Description],[Cause of Loss 1],[Cause of Loss 4 - Type],[Cause Of Loss2],[Claim Closure Reason],[Claim Create Date],[Claim Current State],[Claim Description],[Claim Handler],[Claim Title],[Claim Type],[Date Last Closed],[Date Last Reopened],[Date Of Loss],[Date Reported/Event],[First Exposure Claimant],[Loss Country],[Severity],[Claim Event Code],[Event Description],[TPA Claim Number],[Cause of Loss3],[Loss City],[Loss State],[Region],[Loss Region],[Cause of Loss 1 Other Description],[Cause of Loss 2 Other Description],[Cause of Loss 3 Other Description],[_DateCreated],[_EventExecutionKey],[_LastAction],[Cause of Loss 4 Other Description],[Cause Of Loss5],[Loss Code Group],[Organization],[Cyber Consideration],[Cyber Consideration Other Description],[Ransomware Aspect], [Policy number], [Business Sub Component], [Business Component], [Insured Name], [Branch], [Location ID], [Total Inr curr(Gross)], [Broker Name], [Underwriter], [Risk engineer], [LIU Share]) WITH (DATA_COMPRESSION=PAGE);

GO
CREATE NONCLUSTERED INDEX [IX_WORK_CBIClaimListing__LastAction]
    ON [WORK].[CBIClaimListing]([_LastAction] ASC) WITH (DATA_COMPRESSION=PAGE);

