
select FirstName, LastName ,* from [Staging_MDS].dbo.MasterUnderwriters where FirstName is not null



select firstname, LastName,* from [ODS_MDS].[dbo].[MasterUnderwriters] where code in (8346,8360,8361)
select firstname, LastName,* from [ODS_MDS].[dbo].Map_MasterUnderwriters where code in (8346,8360,8361)




select firstname, LastName,* from MasterUnderwriters where FirstName is not null






select firstname, LastName,* from IDS_Mart.[dbo].[Underwriters] where FirstName <>'<<Unknown>>'