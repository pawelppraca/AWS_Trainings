--Sprawdzenie czas�w taska po optymalizacji
USE ETL_Control

SELECT 
	TaskCode
	, DATEDIFF(MINUTE,wq.[ExecutionStartDate],wq.[ExecutionEndDate]) task_time_min
	, SUBSTRING(CAST(CONVERT(TIME,DATEADD(SECOND,DATEDIFF(SECOND,wq.[ExecutionStartDate],wq.[ExecutionEndDate]) ,1)) AS VARCHAR),1,8) Task_ExecutionTime
	, wq.ExecutionStartDate
	, wq.ExecutionEndDate
	,TaskXML.value('(/ParameterSet/Parameter/ParameterName)[11]','VARCHAR(100)') As ParameterName
	,TaskXML.value('(/ParameterSet/Parameter/ParameterValue)[11]','VARCHAR(100)') As BLOEMode
	,*
FROM [ETL_Control].[dbo].[WorkQueueLog] wq (nolock)
WHERE TaskCode='FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH_DP'
ORDER BY EventExecutionKey desc




select count(*) from Warehouse_Repository.[WORK].[PolicyPremiumTransactionsCoverage_GENIUS]

select count(*) from Warehouse_Repository.[WORK].[PolicyPremiumTransactionsCoverage_GENIUS]


select count(*) from Warehouse_Repository.[WORK].[PolicyPremiumTransactionsCoverage_GENIUS_Temp_Staged_Data]
select count(*) from Warehouse_Repository.[WORK].[PolicyPremiumTransactionsCoverage_GENIUS_Temp_Target_Data]