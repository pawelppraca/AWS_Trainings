use ETL_Control

DROP TABLE IF EXISTS dbo.SSIS_Packages_audit_Log

CREATE TABLE dbo.SSIS_Packages_audit_Log (
	Id INT NOT NULL IDENTITY(1,1)
	, PackageName NVARCHAR(100)
	, TaskName NVARCHAR(100)
	, EventExecutionKey INT 
	, StartTime DATETIME
	, EndTime DATETIME
	, RunningTime AS (CONVERT(TIME,DATEADD(SECOND,DATEDIFF(SECOND,StartTime,EndTime) ,1)))

);

GO

--tabela rejestruj?ca logowanie zdarze?
CREATE TABLE dbo.SSIS_Packages_audit_Log_log (
	Id INT NOT NULL IDENTITY(1,1)
	, PackageName NVARCHAR(100)
	, TaskName NVARCHAR(100)
	, EventExecutionKey INT 
	, Log_Operation  NVARCHAR(100)
	, LogTime DATETIME
);

GO 

CREATE PROCEDURE dbo.SSIS_Packages_audit_Log_Pre
	@PackageName NVARCHAR(100), @TaskName NVARCHAR(100), @EEK int
	
AS
	DECLARE @Audit_Log_Id int
	
	INSERT INTO dbo.SSIS_Packages_audit_Log_log (PackageName,TaskName,EventExecutionKey, Log_Operation, LogTime)
	VALUES (@PackageName,@TaskName,@EEK, 'Audit_Log_Pre', GETDATE())

	IF @PackageName = @TaskName
	BEGIN
		INSERT INTO SSIS_Packages_audit_Log ( 
			PackageName
			, TaskName
			, StartTime
			, EndTime
			, EventExecutionKey
		)
		VALUES (@PackageName, '*** Start of Package '+ @TaskName +' for EEK = '+ cast(@EEK as VARCHAR) +' ***', GETDATE() ,null, @EEK )
	END
	
	INSERT INTO SSIS_Packages_audit_Log ( 
		PackageName
		, TaskName
		, StartTime
		, EndTime
		, EventExecutionKey
	)
	VALUES (@PackageName, @TaskName, GETDATE() ,null, @EEK )
	SET @Audit_Log_Id = SCOPE_IDENTITY()
	Select @Audit_Log_Id
GO


CREATE PROCEDURE dbo.SSIS_Packages_audit_Log_Past
	@PackageName NVARCHAR(100), @TaskName NVARCHAR(100), @Audit_Log_Id int, @EEK int
	
AS


	UPDATE SSIS_Packages_audit_Log  SET EndTime = GETDATE() 
		WHERE Id =  @Audit_Log_Id 
			and PackageName = @PackageName 
			and TaskName = @TaskName 
			and EventExecutionKey = @EEK
			and EndTime is null

	IF @PackageName = @TaskName
	BEGIN
		INSERT INTO SSIS_Packages_audit_Log ( 
			PackageName
			, TaskName
			, StartTime
			, EndTime
			, EventExecutionKey
		)
		VALUES (@PackageName, '*** END of Package '+ @TaskName +' for EEK = '+ cast(@EEK as VARCHAR) +' ***', null ,GETDATE(), @EEK )
	END

	INSERT INTO dbo.SSIS_Packages_audit_Log_log (PackageName,TaskName,EventExecutionKey, Log_Operation, LogTime)
	VALUES (@PackageName,@TaskName,@EEK, 'Audit_Log_Past Audit_Log_ID = ' +CAST(@Audit_Log_Id AS VARCHAR) , GETDATE())
GO


--UPDATE SSIS_Packages_audit_Log  SET EndTime = GETDATE() 
--		WHERE Id =  (select top 1 Id from SSIS_Packages_audit_Log 
--						where Packagename='FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH'
--						and TaskName = 'FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH'
--						and EndTime is null)

--TESTING


declare @EventExecutionKey int = 125013002
declare @StartEventTime datetime


SELECT top 1 @StartEventTime = StartTime
FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** Start of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'
ORDER BY Id

UPDATE log SET StartTime = @StartEventTime
FROM SSIS_Packages_audit_Log log
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** END of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'

SELECT * FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
AND RunningTime is not null
ORDER BY Id


--Wykonanie bez BLOE
declare @EventExecutionKey int = 125013003
declare @StartEventTime datetime


SELECT top 1 @StartEventTime = StartTime
FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** Start of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'
ORDER BY Id

UPDATE log SET StartTime = @StartEventTime
FROM SSIS_Packages_audit_Log log
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** END of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'

SELECT * FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
AND RunningTime is not null
ORDER BY Id





--Wykonanie bez BLOE
declare @EventExecutionKey int = 240422001
declare @StartEventTime datetime


SELECT top 1 @StartEventTime = StartTime
FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** Start of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'
ORDER BY Id

UPDATE log SET StartTime = @StartEventTime
FROM SSIS_Packages_audit_Log log
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** END of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'

SELECT * FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
AND RunningTime is not null
ORDER BY Id


--Wykonanie z BLOE
declare @EventExecutionKey int = 240422002
declare @StartEventTime datetime


SELECT top 1 @StartEventTime = StartTime
FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** Start of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'
ORDER BY Id

UPDATE log SET StartTime = @StartEventTime
FROM SSIS_Packages_audit_Log log
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** END of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'

SELECT * FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
AND RunningTime is not null
ORDER BY Id



--Wykonanie z BLOE
declare @EventExecutionKey int = 240422003
declare @StartEventTime datetime


SELECT top 1 @StartEventTime = StartTime
FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** Start of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'
ORDER BY Id

UPDATE log SET StartTime = @StartEventTime
FROM SSIS_Packages_audit_Log log
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** END of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'

SELECT * FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
AND RunningTime is not null
ORDER BY Id

GO

--Wykonanie z BLOE z za?o?nymi Indeksami
declare @EventExecutionKey int = 240422004
declare @StartEventTime datetime


SELECT top 1 @StartEventTime = StartTime
FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** Start of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'
ORDER BY Id

UPDATE log SET StartTime = @StartEventTime
FROM SSIS_Packages_audit_Log log
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** END of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'

SELECT * FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
AND RunningTime is not null
ORDER BY Id

GO
--Wykonanie z BLOE z za?o?nymi Indeksami v2
declare @EventExecutionKey int = 240422005
declare @StartEventTime datetime


SELECT top 1 @StartEventTime = StartTime
FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** Start of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'
ORDER BY Id

UPDATE log SET StartTime = @StartEventTime
FROM SSIS_Packages_audit_Log log
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** END of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'

SELECT * FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
AND RunningTime is not null
ORDER BY Id



GO
--Wykonanie z BLOE bez indeks�w, batch=500000
declare @EventExecutionKey int = 240422006
declare @StartEventTime datetime


SELECT top 1 @StartEventTime = StartTime
FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** Start of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'
ORDER BY Id

UPDATE log SET StartTime = @StartEventTime
FROM SSIS_Packages_audit_Log log
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** END of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'

SELECT * FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
AND RunningTime is not null
ORDER BY Id



GO
--Wykonanie z BLOE bez indeks�w, batch=10000
declare @EventExecutionKey int = 240422007
declare @StartEventTime datetime


SELECT top 1 @StartEventTime = StartTime
FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** Start of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'
ORDER BY Id

UPDATE log SET StartTime = @StartEventTime
FROM SSIS_Packages_audit_Log log
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** END of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'

SELECT * FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
AND RunningTime is not null
ORDER BY Id

GO

--Testowe wykonanie na SSIS z now? procedur?
declare @EventExecutionKey int = 240424001
declare @StartEventTime datetime



SELECT top 1 @StartEventTime = StartTime
FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** Start of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'
ORDER BY Id

UPDATE log SET StartTime = @StartEventTime
FROM SSIS_Packages_audit_Log log
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** END of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'

SELECT * FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
AND RunningTime is not null
ORDER BY Id


Go
--Testowe wykonanie na SSIS z nowa procedura (bez daty z pakietu)
declare @EventExecutionKey int = 2442501
declare @StartEventTime datetime


select * from SSIS_Packages_audit_Log where 2442501



SELECT top 1 @StartEventTime = StartTime
FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** Start of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'
ORDER BY Id

UPDATE log SET StartTime = @StartEventTime
FROM SSIS_Packages_audit_Log log
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** END of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'

SELECT * FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
AND RunningTime is not null
ORDER BY Id



--Por�wnanie wynik�w

--kopia danych po procedurze
select count(*) from WAREHOUSE_Repository_AM.[STAGE].[PolicyPremiumTransactionsCoverage_GENIUS] --4894826
select count(*) from WAREHOUSE_Repository_AM.WORK.[PolicyPremiumTransactionsCoverage_GENIUS] --4894826

select count(*), _LastAction
from WAREHOUSE_Repository_AM.WORK.PolicyPremiumTransactionsCoverage_GENIUS
group by _LastAction

select top 10 * from WAREHOUSE_Repository_AM.WORK.[PolicyPremiumTransactionsCoverage_GENIUS]



select count(*) from WAREHOUSE_Repository_AM.WORK.[PolicyPremiumTransactionsCoverage_GENIUS] 


--kopia danych po BLOE i procesowaniu przez procedur? GenChnagedData...

select count(*) FROM WAREHOUSE_Repository_AM.[dbo].[PolicyPremiumTransactionsCoverage]  --17205213
WHERE _SourceSystemCode = 'GENIUS'


select count(*), _LastAction
from WAREHOUSE_Repository_AM.[dbo].[PolicyPremiumTransactionsCoverage]
 WHERE _SourceSystemCode = 'GENIUS'
group by _LastAction
/*
12 310 387	D
 4 894 826	U
*/

--Kopia danych 
SELECT * 
into WAREHOUSE_Repository_AM.[dbo].[PolicyPremiumTransactionsCoverage_BLOE_Opty_proc_GenChd]
FROM WAREHOUSE_Repository_AM.[dbo].[PolicyPremiumTransactionsCoverage]
 WHERE _SourceSystemCode = 'GENIUS' 


 select top 100 * from WAREHOUSE_Repository_AM.[dbo].[PolicyPremiumTransactionsCoverage_BLOE_Opty_proc_GenChd]

 
Go
--Testowe wykonanie na SSIS z starym sposobem 
declare @EventExecutionKey int = 2442502
declare @StartEventTime datetime



SELECT top 1 @StartEventTime = StartTime
FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** Start of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'
ORDER BY Id

UPDATE log SET StartTime = @StartEventTime
FROM SSIS_Packages_audit_Log log
WHERE EventExecutionKey= @EventExecutionKey
and TaskName='*** END of Package FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH for EEK = ' + CAST(@EventExecutionKey AS VARCHAR) +' ***'

SELECT * FROM SSIS_Packages_audit_Log (NOLOCK) 
WHERE EventExecutionKey= @EventExecutionKey
AND RunningTime is not null
ORDER BY Id




select count(*), _LastAction
from WAREHOUSE_Repository_AM.[dbo].[PolicyPremiumTransactionsCoverage]
 WHERE _SourceSystemCode = 'GENIUS'
group by _LastAction
/*
12 310 387	D
 4 894 826	U
*/

--Kopia danych 
SELECT * 
into WAREHOUSE_Repository_AM.[dbo].[PolicyPremiumTransactionsCoverage_BLOE_by_SSIS_GenChd]
FROM WAREHOUSE_Repository_AM.[dbo].[PolicyPremiumTransactionsCoverage]
 WHERE _SourceSystemCode = 'GENIUS' 




select
      [LimitKey]
      ,[OriginalCurrencyKey]
      ,[PolicyKey]
      ,[PolicyReference]
      ,[AuditNumber]
      ,[ExternalReferenceIdentifier]
      ,[DoubleEntryItemSequence]
      ,[StatisticsLedgerSequence]
      ,[CreatedBy]
      ,[UserName]
      ,[DueDate]
      ,[FiscalPeriod]
      ,[TransactionEntryDate]
      ,[TransactionTypeKey]
      ,[TransactionTypeCategoryCode]
      ,[TransactionTypeCategory]
      ,[TransactionOriginalFlag]
      ,[TransactionDescription]
      ,[TransactionLineOfBusinessCode]
      ,[TransactionBranch]
      ,[AccountingToBaseExchangeRate]
      ,[OriginalToBaseExchangeRate]
      ,[PolicyWrittenExchangeRate]
      ,[ClientPolicyPremiumGrossOriginalCurrency]
      ,[ClientPolicyPremiumNetOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedGrossOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedNetOriginalCurrency]
      ,[InitialPolicyPremiumSEPIGrossOriginalCurrency]
      ,[InitialPolicyPremiumSEPINetOriginalCurrency]
      ,[InitialPolicyPremiumSignedGrossOriginalCurrency]
      ,[InitialPolicyPremiumSignedNetOriginalCurrency]
      ,[InitialPolicyPremiumWrittenGrossOriginalCurrency]
      ,[InitialPolicyPremiumWrittenNetOriginalCurrency]
      ,[RegionCode]
      ,[SignedDownPremiumEstimatedNetOriginalCurrency]
      ,[SignedDownPremiumWrittenNetOriginalCurrency]
      ,[SystemTransactionAmountOriginalCurrency]
      ,[_CDCDateKey]
      ,[_CDCTime]
--      ,[_DateCreated]
--      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_MergeKey_Limits]
      ,[_MergeKey_Policies]
      ,[_SourceSystemCode]
from WAREHOUSE_Repository_AM.[dbo].[PolicyPremiumTransactionsCoverage_BLOE_by_SSIS_GenChd]
Except 
SELECT 
      [LimitKey]
      ,[OriginalCurrencyKey]
      ,[PolicyKey]
      ,[PolicyReference]
      ,[AuditNumber]
      ,[ExternalReferenceIdentifier]
      ,[DoubleEntryItemSequence]
      ,[StatisticsLedgerSequence]
      ,[CreatedBy]
      ,[UserName]
      ,[DueDate]
      ,[FiscalPeriod]
      ,[TransactionEntryDate]
      ,[TransactionTypeKey]
      ,[TransactionTypeCategoryCode]
      ,[TransactionTypeCategory]
      ,[TransactionOriginalFlag]
      ,[TransactionDescription]
      ,[TransactionLineOfBusinessCode]
      ,[TransactionBranch]
      ,[AccountingToBaseExchangeRate]
      ,[OriginalToBaseExchangeRate]
      ,[PolicyWrittenExchangeRate]
      ,[ClientPolicyPremiumGrossOriginalCurrency]
      ,[ClientPolicyPremiumNetOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedGrossOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedNetOriginalCurrency]
      ,[InitialPolicyPremiumSEPIGrossOriginalCurrency]
      ,[InitialPolicyPremiumSEPINetOriginalCurrency]
      ,[InitialPolicyPremiumSignedGrossOriginalCurrency]
      ,[InitialPolicyPremiumSignedNetOriginalCurrency]
      ,[InitialPolicyPremiumWrittenGrossOriginalCurrency]
      ,[InitialPolicyPremiumWrittenNetOriginalCurrency]
      ,[RegionCode]
      ,[SignedDownPremiumEstimatedNetOriginalCurrency]
      ,[SignedDownPremiumWrittenNetOriginalCurrency]
      ,[SystemTransactionAmountOriginalCurrency]
      ,[_CDCDateKey]
      ,[_CDCTime]
--      ,[_DateCreated]
--      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_MergeKey_Limits]
      ,[_MergeKey_Policies]
      ,[_SourceSystemCode]

from WAREHOUSE_Repository_AM.[dbo].[PolicyPremiumTransactionsCoverage_BLOE_Opty_proc_GenChd]


