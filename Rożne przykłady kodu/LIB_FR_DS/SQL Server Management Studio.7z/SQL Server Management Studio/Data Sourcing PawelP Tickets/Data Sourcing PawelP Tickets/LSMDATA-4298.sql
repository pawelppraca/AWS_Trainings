select top 1000 
[IndemTotalPaidThisTimeOrig]
, [100% Paid This Time Ind Orig - Amount Sign (SCM files)]
, * 
from [cole].[FeederMap_SCMTransaction_UTKOREP] 
where len([100% Paid This Time Ind Orig - Amount Sign (SCM files)])>0

select top 1000 * from [cole].[FeederMap_SCMTransaction_UTKOREP] where LloydsClaimRef like '%B1526011306500101%'



select distinct [100% Paid This Time Ind Orig - Amount Sign (SCM files)]
from [cole].[FeederMap_SCMTransaction_UTKOREP] 

select distinct KOSTIS from ODS_IRIS.dbo.UTKOREP utko

select distinct KOPDIS from dbo.UTKOREP utko
 
select distinct KOSTFS from dbo.UTKOREP utko


select KOSTIS, count(*) from ODS_IRIS.dbo.UTKOREP utko group by KOSTIS

select KOPDIS, count(*)   from dbo.UTKOREP utko group by KOPDIS
select KOSTFS, count(*)   from dbo.UTKOREP utko group by KOSTFS
 
select distinct KOSTFS from dbo.UTKOREP utko


select top 1000 IndStThTi100 IndStThTi100_,*
into #temp2
--RTRIM(LTRIM([100% Paid This Time Ind Orig - Amount Sign (SCM files)])) [sign] ,

from ODS_IRIS.cole.Feeder_Scm 
where IndStThTi100 < 0
--RTRIM(LTRIM([100% Paid This Time Ind Orig - Amount Sign (SCM files)])) ='-'


select * from #temp where IndStThTi100_ < 0
