--Modelowanie GENERATED_Changed BLOE

--truncate table WORK.PolicyPremiumTransactionsCoverage_GENIUS

select count(*), _LastAction
from WORK.PolicyPremiumTransactionsCoverage_GENIUS
group by _LastAction


select count(*)
from STAGE.PolicyPremiumTransactionsCoverage_GENIUS (nolock)



select *
from WORK.PolicyPremiumTransactionsCoverage_GENIUS (nolock)


 exec [dbo].[GenChangedData_PolicyPremiumTransactionsCoverage]  2442404, '20240424'





