use ODS_GENIUS

select * 
--into CBIClaimListing_prev_UPPER  --Tabelka
from CBIClaimListing

--truncate table CBIClaimListing


select count(*) from CBIClaimListing (nolock)

select count(*) from staging_Genius.dbo.CBIClaimListing (nolock)

select count(*) from CBIClaimListing_prev

select count(*) from CBIClaimListing_prev_UPPER

--SPrawdzi iloci rekordow po przeprocesowaniu



select top 10 * from Staging_GENIUS.dbo.CBIClaimListing



--Wlaczenie taska

Use ETL_Controler
select 
