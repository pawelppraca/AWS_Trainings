		SELECT * 
		--delete
		FROM [dbo].[ExtendedTaskAttributes] WHERE [TaskCode]  IN ('EXEC_EVENT_GENIUSToDWH_DP_FOR_APAC','EXEC_EVENT_PUBLISH_DWH_DATABASES_FOR_APAC')

		SELECT * 
		--delete
		FROM [dbo].[Tasks] WHERE [TaskCode]  IN ('EXEC_EVENT_GENIUSToDWH_DP_FOR_APAC','EXEC_EVENT_PUBLISH_DWH_DATABASES_FOR_APAC')

		SELECT * 
		--delete
		FROM [dbo].[WorkflowConstraints] WHERE [EventCode] = N'GENIUSToDWH_DP_APAC'	

		SELECT * 
		--delete
		FROM [dbo].[EventTaskGroups] WHERE [EventCode] = N'GENIUSToDWH_DP_APAC'

		
		SELECT * 
		--delete
		FROM [dbo].[TaskGroupConnections] WHERE [TaskGroupCode] IN ('EXEC_EVENT_GENIUSToDWH_DP_FOR_APAC','EXEC_EVENT_PUBLISH_DWH_DATABASES_FOR_APAC')

		SELECT * 
		--DELETE
		FROM [dbo].[TaskGroups] WHERE [TaskGroupCode] IN ('EXEC_EVENT_GENIUSToDWH_DP_FOR_APAC','EXEC_EVENT_PUBLISH_DWH_DATABASES_FOR_APAC')

		SELECT * 
		--DELETE
		FROM [dbo].[Events] WHERE [EventCode] IN ('GENIUSToDWH_DP_APAC')

