USE Warehouse_Repository



select * 
from etl_control.dbo.workqueuelog 
WHERE TaskCode like '%DIMENSION_GENIUS_Covers_DWH_DP%'
AND ExecutionStartDate>='20240701'
order by EventExecutionKey desc


drop table if exists #temp
select EventExecutionKey,  FORMAT ([ExecutionStartDate], 'yyyy-MM-dd') ExecDate
into #temp
from etl_control.dbo.workqueuelog 
WHERE TaskCode like '%DIMENSION_GENIUS_Covers_DWH_DP%'
AND ExecutionStartDate>='20240701'


select * from #temp


Select count(*), _EventExecutionKey 
from Covers 
group by _EventExecutionKey


/*
drop table if exists #Stat

select 'covers                              ' tableName, count(*) Records_Count, wl.execdate
Into #Stat
from [Warehouse_Repository].[dbo].covers c (nolock)
join #temp wl on wl.EventExecutionKey=c._EventExecutionKey
where _sourcesystemcode='GENIUS' and c._LastAction <>'D'
group by wl.execdate
order by Execdate

Insert Into #Stat 
select 'coverDetails' tableName, count(*) Records_Count, wl.execdate
from [Warehouse_Repository].[dbo].coverDetails cd (nolock)
join #temp wl on wl.EventExecutionKey=cd._EventExecutionKey
where _sourcesystemcode='GENIUS' and cd._LastAction <>'D'
group by wl.execdate
order by Execdate


Insert Into #Stat 
select 'coverLines' tableName, count(*) Records_Count, wl.execdate
from [Warehouse_Repository].[dbo].coverLines c (nolock)
join #temp wl on wl.EventExecutionKey=c._EventExecutionKey
where _sourcesystemcode='GENIUS' and c._LastAction <>'D'
group by wl.execdate
order by Execdate

Insert Into #Stat 
select 'Limits' tableName, count(*) Records_Count, wl.execdate
from [Warehouse_Repository].[dbo].Limits l (nolock)
join [Warehouse_Repository].[dbo].Covers c (nolock) on c._MergeKey = l._MergeKey_Covers 
join #temp wl on wl.EventExecutionKey=c._EventExecutionKey
where c._sourcesystemcode='GENIUS' and c._LastAction <>'D'
group by wl.execdate
order by Execdate


Insert Into #Stat 
select 'ClaimTransactions' tableName, count(distinct ct.ClaimTransactionKey) Records_Count, wl.execdate
from [Warehouse_Repository].[dbo].ClaimTransactions ct (nolock)
join [Warehouse_Repository].[dbo].Covers c (nolock) on c._MergeKey = ct._MergeKey_Covers 
join #temp wl on wl.EventExecutionKey=c._EventExecutionKey
where c._sourcesystemcode='GENIUS' and c._LastAction <>'D'
group by wl.execdate
order by Execdate


Insert Into #Stat 
select 'CoverPremiumIncome' tableName, count(distinct cpi.CoverPremiumIncomeKey) Records_Count, wl.execdate
from [Warehouse_Repository].[dbo].CoverPremiumIncome cpi (nolock)
join [Warehouse_Repository].[dbo].Covers c (nolock) on c._MergeKey = cpi._MergeKey_Covers 
join #temp wl on wl.EventExecutionKey=c._EventExecutionKey
where c._sourcesystemcode='GENIUS' and c._LastAction <>'D'
group by wl.execdate
order by Execdate

select * from #stat order by execdate, tableName

*/


-- Based on EffectiveDateFrom
drop table if exists #Covers
select CoverKey, CoverDetailKey, _MergeKey,  FORMAT (_EffectiveFrom, 'yyyy-MM-dd') _EffectiveFromDate
into #Covers
from [Warehouse_Repository].[dbo].covers c (nolock)
where _sourcesystemcode='GENIUS' and c._LastAction <>'D' and _SequenceNUmber=1
and FORMAT (_EffectiveFrom, 'yyyy-MM-dd') >= '20240701' 


select * from #Covers

drop table if exists #Stat


select 'covers                              ' tableName, count(*) Records_Count, _EffectiveFromDate
--Into #Stat
from [Warehouse_Repository].[dbo].covers c (nolock)
join #Covers cc on cc.CoverKey = c.CoverKey
group by _EffectiveFromDate
order by _EffectiveFromDate

--Insert Into #Stat 
select 'coverDetails' tableName, count(*) Records_Count, _EffectiveFromDate
from [Warehouse_Repository].[dbo].coverDetails cd (nolock)
join #Covers cc on cc.CoverDetailKey = cd.CoverDetailKey
group by _EffectiveFromDate
order by _EffectiveFromDate



Insert Into #Stat 
select 'coverLines' tableName, count(*) Records_Count, _EffectiveFromDate
from [Warehouse_Repository].[dbo].coverLines cl (nolock)
join #Covers cc on cc.CoverKey = cl.CoverKey
group by _EffectiveFromDate
order by _EffectiveFromDate



Insert Into #Stat 
select 'Limits' tableName, count(*) Records_Count, _EffectiveFromDate
from [Warehouse_Repository].[dbo].Limits l (nolock)
join #Covers cc on cc._MergeKey = l._MergeKey_Covers 
group by _EffectiveFromDate
order by _EffectiveFromDate


Insert Into #Stat 
select 'ClaimTransactions' tableName, count(distinct ct.ClaimTransactionKey) Records_Count, _EffectiveFromDate
from [Warehouse_Repository].[dbo].ClaimTransactions ct (nolock)
join #Covers cc on cc._MergeKey = ct._MergeKey_Covers 
group by _EffectiveFromDate
order by _EffectiveFromDate


Insert Into #Stat 
select 'CoverPremiumIncome' tableName, count(distinct cpi.CoverPremiumIncomeKey) Records_Count, _EffectiveFromDate
from [Warehouse_Repository].[dbo].CoverPremiumIncome cpi (nolock)
join #Covers cc on cc._MergeKey = cpi._MergeKey_Covers 
group by _EffectiveFromDate
order by _EffectiveFromDate






-- Detale
select wl.execdate, wl.EventExecutionKey, 'Covers -->' tablename, c.*
from [Warehouse_Repository].[dbo].covers c
join #temp wl on wl.EventExecutionKey=c._EventExecutionKey
where _sourcesystemcode='GENIUS'
order by wl.execdate


select wl.execdate, wl.EventExecutionKey, 'Limits -->' tablename, l.*
from [Warehouse_Repository].[dbo].Limits l (nolock)
join [Warehouse_Repository].[dbo].Covers c (nolock) on c._MergeKey = l._MergeKey_Covers 
join #temp wl on wl.EventExecutionKey=c._EventExecutionKey
where c._sourcesystemcode='GENIUS'
and c._LastAction <>'D'

select wl.execdate, wl.EventExecutionKey, 'ClaimTransactions -->' tablename, ct.*
from [Warehouse_Repository].[dbo].ClaimTransactions ct (nolock)
join [Warehouse_Repository].[dbo].Covers c (nolock) on c._MergeKey = ct._MergeKey_Covers 
join #temp wl on wl.EventExecutionKey=c._EventExecutionKey
where c._sourcesystemcode='GENIUS'
and c._LastAction <>'D'

select wl.execdate, wl.EventExecutionKey, 'CoverPremiumIncome-->' tableName, cpi.*
from [Warehouse_Repository].[dbo].CoverPremiumIncome cpi (nolock)
join [Warehouse_Repository].[dbo].Covers c (nolock) on c._MergeKey = cpi._MergeKey_Covers 
join #temp wl on wl.EventExecutionKey=c._EventExecutionKey
where c._sourcesystemcode='GENIUS'
and c._LastAction <>'D'


select * from coverde


--Non in CoverCessionPct  Branch, Product Code, Country Company --brakuje mi tych p�l

--COUNT
  drop table if exists #covers_not_in_CoversCessionPct
  select 
	count(distinct c.CoverReference) Count_of_Covers
	, c.BranchCode
	, c.ContractTypeCode
	, rh.Country
	, cd.RITypeDescription
	, FORMAT (cd._DateCreated, 'yyyy-MM-dd') CoverDetails_DateCreated
	, cd.BranchCode CoverDetails_BranchCode
	, FORMAT (min(c._EffectiveFrom), 'yyyy-MM-dd')   min_covers_effective_date
  into #covers_not_in_CoversCessionPct
  from [Warehouse_Repository].[dbo].Covers c
  left join [Warehouse_Repository].[dbo].CoverDetails cd (nolock)on cd.CoverDetailKey=c.CoverDetailKey 
  left join [Warehouse_Repository].[dbo].RegionHierarchy rh (nolock) on rh.BranchCode = c.BranchCode and rh.Market='GENIUS'
  left join [Warehouse_Repository].[dbo].CoversCessionPct ccp (nolock) on ccp._MergeKey_Covers = c._MergeKey
  where ccp.CoversCessionPctKey is not null
  and c._SourceSystemCode = 'GENIUS'
  and c._LastAction <> 'D'
  group by c.BranchCode, c.ContractTypeCode , rh.Country, cd.RITypeDescription, FORMAT (cd._DateCreated, 'yyyy-MM-dd') , cd.BranchCode

  --Details
  drop table if exists #covers_not_in_CoversCessionPct_details
  select 
		c.CoverReference
		, c.BranchCode
		, c.ContractTypeCode
		, rh.Country
		, cd.RITypeDescription
		, FORMAT (cd._DateCreated, 'yyyy-MM-dd')  CoverDetails_DateCreated
		, cd.BranchCode CoverDetails_BranchCode
		, FORMAT (min(c._EffectiveFrom), 'yyyy-MM-dd')   min_covers_effective_date
  into #covers_not_in_CoversCessionPct_details
  from [Warehouse_Repository].[dbo].Covers c
  left join [Warehouse_Repository].[dbo].CoverDetails cd  (nolock) on cd.CoverDetailKey=c.CoverDetailKey 
  left join [Warehouse_Repository].[dbo].RegionHierarchy rh  (nolock) on rh.BranchCode = c.BranchCode and rh.Market='GENIUS'
  left join [Warehouse_Repository].[dbo].CoversCessionPct ccp  (nolock) on ccp._MergeKey_Covers = c._MergeKey
  where ccp.CoversCessionPctKey is not null
  and c._SourceSystemCode = 'GENIUS'
  and c._LastAction <> 'D'
  group by 
  c.CoverReference
		, c.BranchCode
		, c.ContractTypeCode
		, rh.Country
		, cd.RITypeDescription
		, FORMAT (cd._DateCreated, 'yyyy-MM-dd')  
		, cd.BranchCode 




  select top 10 * from [Warehouse_Repository].[dbo].[MasterReservingClassHierarchy]


  select * from #covers_not_in_CoversCessionPct where BranchCode ='London'

  select top 5 * from #covers_not_in_CoversCessionPct_details where BranchCode ='London' and ContractTypeCode ='XSL'


  FAC
QS
FXL
QS2
XSL




drop table if exists #temp
select distinct EventExecutionKey,EventCode, EventStatusCode, FORMAT ([ExecutionStartDate], 'yyyy-MM-dd') ExecDate
into #temp
from etl_control.dbo.EventExecutionLog 
WHERE EventCode like '%GeniusToDWH_DP%' AND 
ExecutionStartDate>='20240701'
and SourceSystemCode='GENIUS'


INSERT into #temp
select distinct EventExecutionKey,TaskCode, TaskStatusCode, FORMAT ([ExecutionStartDate], 'yyyy-MM-dd') ExecDate, ErrorInformation
from etl_control.dbo.WorkQueueErrorLog 
WHERE TaskCode like '%DIMENSION_GENIUS_Covers_DWH_DP%' AND 
ExecutionStartDate>='20240701'

select count(distinct CoverReference)
from [Warehouse_Repository].[dbo].covers c (nolock)
where _sourcesystemcode='GENIUS' and c._LastAction <>'D'


select * from #temp

select * from #Stat


drop table if exists #Stat

select 'covers                              ' tableName, count(distinct CoverReference) Records_Count, wl.execdate, wl.EventStatusCode, EventExecutionKey
Into #Stat
from [Warehouse_Repository].[dbo].covers c (nolock)
join #temp wl on wl.EventExecutionKey=c._EventExecutionKey
where _sourcesystemcode='GENIUS' and c._LastAction <>'D'
group by wl.execdate, wl.EventStatusCode, EventExecutionKey
order by Execdate


Insert Into #Stat 
select 'coverDetails' tableName, count(distinct CoverDetailKey) Records_Count, wl.execdate, wl.EventStatusCode, EventExecutionKey
from [Warehouse_Repository].[dbo].coverDetails cd (nolock)
join #temp wl on wl.EventExecutionKey=cd._EventExecutionKey
where _sourcesystemcode='GENIUS' and cd._LastAction <>'D'
group by wl.execdate, wl.EventStatusCode, EventExecutionKey
order by Execdate



Insert Into #Stat 
select 'coverLines' tableName, count(distinct CoverLineKey) Records_Count, wl.execdate, wl.EventStatusCode, EventExecutionKey
from [Warehouse_Repository].[dbo].coverLines c (nolock)
join #temp wl on wl.EventExecutionKey=c._EventExecutionKey
where _sourcesystemcode='GENIUS' and c._LastAction <>'D'
group by wl.execdate, wl.EventStatusCode, EventExecutionKey
order by Execdate

Insert Into #Stat 
select 'Limits' tableName, count(distinct LimitKey) Records_Count, wl.execdate, wl.EventStatusCode, EventExecutionKey
from [Warehouse_Repository].[dbo].Limits l (nolock)
join [Warehouse_Repository].[dbo].Covers c (nolock) on c._MergeKey = l._MergeKey_Covers 
join #temp wl on wl.EventExecutionKey=c._EventExecutionKey
where c._sourcesystemcode='GENIUS' and c._LastAction <>'D'
group by wl.execdate, wl.EventStatusCode, EventExecutionKey
order by Execdate


Insert Into #Stat 
select 'ClaimTransactions' tableName, count(distinct ct.ClaimTransactionKey) Records_Count, wl.execdate, wl.EventStatusCode, EventExecutionKey
from [Warehouse_Repository].[dbo].ClaimTransactions ct (nolock)
join [Warehouse_Repository].[dbo].Covers c (nolock) on c._MergeKey = ct._MergeKey_Covers 
join #temp wl on wl.EventExecutionKey=c._EventExecutionKey
where c._sourcesystemcode='GENIUS' and c._LastAction <>'D'
group by wl.execdate, wl.EventStatusCode, EventExecutionKey
order by Execdate



Insert Into #Stat 
select 'CoverPremiumIncome' tableName, count(distinct cpi.CoverPremiumIncomeKey) Records_Count, wl.execdate, wl.EventStatusCode, EventExecutionKey
from [Warehouse_Repository].[dbo].CoverPremiumIncome cpi (nolock)
join [Warehouse_Repository].[dbo].Covers c (nolock) on c._MergeKey = cpi._MergeKey_Covers 
join #temp wl on wl.EventExecutionKey=c._EventExecutionKey
where c._sourcesystemcode='GENIUS' and cpi._LastAction <>'D'
group by wl.execdate, wl.EventStatusCode, EventExecutionKey
order by Execdate

select * from #stat order by execdate, tableName





-- Detale
select wl.EventStatusCode,wl.execdate, wl.EventExecutionKey, 'Covers -->' tablename, c.*
from [Warehouse_Repository].[dbo].covers c
join #temp wl on wl.EventExecutionKey=c._EventExecutionKey
where _sourcesystemcode='GENIUS'
order by wl.execdate



select count(distinct coverreference), _EventExecutionKey 
from covers 
group by _EventExecutionKey





select top 10 * from etl_control.dbo.[WorkQueueErrorLog] where EventExecutionKey=290329
select top 10 * from etl_control.dbo.[WorkQueueLog] 


