------------------------------------------------------------------------------
--Testowanie - MDS --> STAGING_MDS (EXTRACT_MDS_MasterUnderwriters.dtsx)
------------------------------------------------------------------------------

--nowe kolumny w tabelach na DEV

USE [Staging_MDS]
alter table [Staging_MDS].dbo.MasterUnderwriters add FirstName NVARCHAR(250), LastName NVARCHAR(250)

alter table [Staging_MDS].dbo.MasterUnderwriters alter column FirstName NVARCHAR(250)
alter table [Staging_MDS].dbo.MasterUnderwriters alter column LastName NVARCHAR(250)



--Dodanie danych testowych  do tabeli MDSDatabase.mdm.MasterUnderwriters via Excel

--Checking test data using vie mdm.MasterUnderwriters

select * from MDSDatabase.mdm.MasterUnderwriters where code in (8346,8360,8361)


--Checking data in Staging_MDS.dbo.MasterUnderwiters BEFORE Executing package Extract_MDS_MasterUnderWriters.dtsx

select * from Staging_MDS.[dbo].[MasterUnderwriters] where code in (8346,8360,8361)

--Checking data in Staging_MDS.dbo.MasterUnderwiters AFTER Executing package Extract_MDS_MasterUnderWriters.dtsx

select * from Staging_MDS.[dbo].[MasterUnderwriters] where code in (8346,8360,8361)


--Uruchomienie pakietow kontrolnych



select max(OpenedByEventExecutionKey) from dbo.IncrementalProcessingLog

--Moj klucz#1  237300
--declare @SourceSystemCode varchar(30) = 'MDS'
--declare @SourceEndPoint varchar(30) = 'STAGING_MDS'
--declare @TargetEndPoint varchar(30) = 'ODS_MDS'


--SELECT * FROM dbo.IncrementalProcessingLog
--WHERE SourceSystemCode = @SourceSystemCode AND SourceEndPoint = @SourceEndPoint AND TargetEndPoint = @TargetEndPoint
--ORDER BY LogEntryType ,OpenedByEventExecutionKey ,SourceEndPoint ,TargetEndPoint






------------------------------------------------------------------------------
--Testowanie - Staging_MDS --> ODS_MDS (LOAD_MDS_MasterUnderwriters.dtsx)
------------------------------------------------------------------------------

--Rozszerzenie tabeli dbo.MasterUnderwriters
alter table [ODS_MDS].dbo.MasterUnderwriters add FirstName NVARCHAR(250), LastName NVARCHAR(250)
alter table [ODS_MDS].dbo.MasterUnderwriters alter column  FirstName NVARCHAR(250)
alter table [ODS_MDS].dbo.MasterUnderwriters alter column  LastName NVARCHAR(250)

--Modyfikacja widoku [dbo].[Map_MasterUnderwriters]
--Modyfikacja widoku [dbo].[Warehouse_MasterUnderwriters]
--Modyfikacja tabeli WORK.MasterUnderwriters


select * from [ODS_MDS].[dbo].[MasterUnderwriters] where code in (8346,8360,8361)



--Checking 
select firstname, LastName,* from [ODS_MDS].[dbo].[MasterUnderwriters] where code in (8346,8360,8361)
select firstname, LastName,* from [ODS_MDS].[dbo].Map_MasterUnderwriters where code in (8346,8360,8361)


select * from [ODS_MDS].[dbo].Warehouse_MasterUnderwriters where substring(_MergeKey,2,4) in ('8346','8360','8361') or substring(_MergeKey,1,4) in ('8346','8360','8361')


--Powtrzenie testu
--usuniecie rekordu z Abackim

select * from [ODS_MDS].[dbo].Warehouse_MasterUnderwriters where substring(_MergeKey,2,4) in ('8346','8360','8361') or substring(_MergeKey,1,4) in ('8346','8360','8361')


--Tu Skonczylem.




------------------------------------------------------------------------------
--Testowanie - ODS_MDS --> Warehouse_Repository (DIM_MDS_MasterUnderwriters.dtsx)
------------------------------------------------------------------------------



--alter table Warehouse_Repository.dbo.MasterUnderwriters add FirstName NVARCHAR(250), LastName NVARCHAR(250)

--przed testowaniem, trzeba uruchomic Paczke 

--Po przejsciu paczki dane powinny byc w 
--Warehouse_Repository.[dbo].[MasterUnderwriters]  i  Warehouse_Repository.[WORK].[MasterUnderwriters_MDS]


Tu Skonczylem - NIE ma dlaszych danych w Warehouse_Repository.[dbo].[MasterUnderwriters] mimo uruchomienia pakietu DIMENSION_MDS_MasterUnderwriters 
Konieczne bylo dodanie klucza  237300

--dodac klucz 


declare 
	@LogEntryType varchar(100)='Consumed', 
	@_EventExecutionKey int = 237300, 
	@SourceEndPoint varchar(100)='STAGING_MDS', 
	@TargetEndPoint varchar(100)='ODS_MDS', 
	@_SourceSystemCode varchar(100) = 'MDS'

INSERT INTO ODS_MDS.dbo.IncrementalProcessingLog VALUES (@LogEntryType, @_EventExecutionKey, @SourceEndPoint, @TargetEndPoint, @_SourceSystemCode, @_EventExecutionKey)

select distinct SourceEndPoint, TargetEndPoint  from ODS_MDS.dbo.IncrementalProcessingLog

select top 100 * from ODS_MDS.dbo.IncrementalProcessingLog order by OpenedByEventExecutionKey desc

--update ODS_MDS.dbo.IncrementalProcessingLog set LogEntryType='Consumed' where OpenedByEventExecutionKey = 237300 and ClosedByEventExecutionKey is null

select * 
--update mu set _EventExecutionKey =237300
from ODS_MDS.dbo.MasterUnderwriters mu where _EventExecutionKey =1


select * from [WORK].[MasterUnderwriters_MDS]


select FirstName, Lastname,* from Warehouse_Repository.[dbo].[MasterUnderwriters] mu where _EventExecutionKey = 237300










------------------------------------------------------------------------------
--Testowanie - Warehouse_Repository  --> IDS_MART (.dtsx)
------------------------------------------------------------------------------

--alter table IDS_MART.dbo.[Underwriters] drop column FirstName , LastName
--alter table IDS_MART.dbo.[Underwriters] add FirstName NVARCHAR(100), LastName NVARCHAR(100)


SELECT
       [N_Number]
      ,[System]
	  ,[FirstName]
	  ,[LastName]
      ,[UWCode]
      ,[UWName]
      ,[UWNameConformed]
      ,[_MergeKey]
      ,[_SourceSystemCode]
  FROM
      [ids_mart].[Build_Underwriters]


SELECT*  FROM  Warehouse_Repository.[ids_mart].[Build_Underwriters] where _SourceSystemCode='GENIUS'


SELECT * FROM Warehouse_Repository.[dbo].[MasterUnderwriters]
where MasterUnderwriterName in ('Christian Krauter','Robert Dixon','Jason Abacki')

select * from Warehouse_Repository.[dbo].[Underwriters] where UnderwriterKey in  ('8346','8360','8361')
8925

WITH
cte_MasterUnderwriters AS
(
SELECT _OriginatingSourceSystemCode,
		FirstName,
		LastName,
		UnderwriterCodeUnconformed,
		MasterUnderwriterName, 
		NNumber,
		ROW_NUMBER() OVER(Partition by _OriginatingSourceSystemCode,UnderwriterCodeUnconformed ORDER BY NNumber Desc) RowNo
FROM [dbo].[MasterUnderwriters]

)
	   SELECT DISTINCT
			  COALESCE(muw.NNumber,'<<Unknown>>') AS N_NUmber
	  		 ,CAST(
				CASE uw._SourceSystemCode 
					WHEN 'GENIUS' THEN 'LMIE - Genius'
					WHEN 'IRIS'  THEN 'LMAL - Iris'
					WHEN 'LMIEIRIS' THEN 'LMIE - Iris'
					WHEN 'LMIELIBRE' THEN 'LMIE - Iris'
					WHEN 'LMIERUNOFF' THEN 'LMIE - Iris'
					WHEN 'LMR' THEN 'LMR - xls'
					ELSE uw._SourceSystemCode
				 END
			  AS NVARCHAR(100)) AS [System]
			,REPLACE(uw.UnderwriterCode,' ','') AS UWCode
			,CASE WHEN uw._SourceSystemCode = 'IRIS' AND uw.UnderwriterName = '<<Unknown>>' THEN uw.UnderwriterCode ELSE uw.UnderwriterName END AS UWName
			,CAST(COALESCE(NULLIF(muw.FirstName,'<<Unknown>>'),'<<Unknown>>') AS NVARCHAR(100)) AS FirstName
			,CAST(COALESCE(NULLIF(muw.LastName,'<<Unknown>>'),'<<Unknown>>') AS NVARCHAR(100)) AS LastName
			,CAST(COALESCE(NULLIF(muw.MasterUnderwriterName,'<<Unknown>>'),REPLACE(uw.UnderwriterName,', ',' '),'<<Unknown>>') AS NVARCHAR(100)) AS UWNameConformed
			,CAST('['+ uw._SourceSystemCode + '][' + LTRIM(uw.UnderwriterCode) + ']' AS NVARCHAR(255)) AS _MergeKey
			,uw._SourceSystemCode
			
	  FROM [dbo].[Underwriters] uw
		 left JOIN  cte_MasterUnderwriters muw
		   ON  uw._SourceSystemCode = muw._OriginatingSourceSystemCode 
			 AND uw.UnderwriterCodeUnconformed = muw.UnderwriterCodeUnconformed
	   		 --AND muw.RowNo = 1
	  WHERE  muw.LastName ='Dixon'
	  
	  uw._SourceSystemCode IN ('GENIUS','IRIS','LMR','LMIEIRIS','LMIELIBRE','LMIERUNOFF','LMIEHELMSMAN')
		  AND uw._LastAction <> 'D'



select * from IDS_Mart.dbo.Underwriters where UWName like '%Krauter%' or UWName like '%Dixon%' or UWName like '%Abacki%'

