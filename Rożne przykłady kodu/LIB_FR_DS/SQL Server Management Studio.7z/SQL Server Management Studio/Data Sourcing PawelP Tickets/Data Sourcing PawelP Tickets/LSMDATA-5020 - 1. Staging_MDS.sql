USE [Staging_MDS]
GO

/****** Object:  Table [dbo].[SIILMALClassMapping]    Script Date: 7/8/2024 10:28:58 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Drop TABLE IF EXISTS [dbo].[SIILMALClassMapping]
CREATE TABLE [dbo].[SIILMALClassMapping](
	[VersionName] [nvarchar](50) NULL,
	[VersionNumber] [int] NULL,
	[Version_ID] [int] NULL,
	[VersionFlag] [nvarchar](50) NULL,
	[Name] [nvarchar](250) NULL,
	[Code] [nvarchar](250) NOT NULL,
	[ChangeTrackingMask] [int] NOT NULL,
	[DataClass] [nvarchar](255) NULL,
	[ReservingClass_Code] [nvarchar](250) NULL,
	[ReservingClass_Name] [nvarchar](250) NULL,
	[ReservingClass_ID] [int] NULL,
	[CMTClass_Code] [nvarchar](250) NULL,
	[CMTClass_Name] [nvarchar](250) NULL,
	[CMTClass_ID] [int] NULL,
	[EnterDateTime] [datetime2](3) NOT NULL,
	[EnterUserName] [nvarchar](100) NULL,
	[EnterVersionNumber] [int] NULL,
	[LastChgDateTime] [datetime2](3) NULL,
	[LastChgUserName] [nvarchar](100) NULL,
	[LastChgVersionNumber] [int] NULL,
	[ValidationStatus] [nvarchar](250) NULL,
 CONSTRAINT [PK_SIILMALClassMapping] PRIMARY KEY CLUSTERED 
(
	[Code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

Drop TABLE IF EXISTS [dbo].[SIILMIEClassMapping]
CREATE TABLE [dbo].[SIILMIEClassMapping](
	[VersionName] [NVARCHAR](50) NULL
	,[VersionNumber] [INT] NULL
	,[Version_ID] [INT] NULL
	,[VersionFlag] [NVARCHAR](50) NULL
	,[Name] [NVARCHAR](250) NULL
	,[Code] [NVARCHAR](250) NOT NULL
	,[ChangeTrackingMask] INT NOT NULL
    ,[S2ReserveClass] [NVARCHAR](100) NULL
    ,[CMTClass_Code] [NVARCHAR](250) NULL
    ,[CMTClass_Name] [NVARCHAR](250) NULL
    ,[CMTClass_ID] INT NULL
    ,[ReservingClass_Code] [NVARCHAR](250) NULL
    ,[ReservingClass_Name] [NVARCHAR](250) NULL
    ,[ReservingClass_ID] INT NULL
	,[EnterDateTime]  [DATETIME2](3) NOT NULL
    ,[EnterUserName] [NVARCHAR](100) NULL
	,[EnterVersionNumber] [INT] NULL
	,[LastChgDateTime] [DATETIME2](3) NULL
	,[LastChgUserName] [NVARCHAR](100) NULL
	,[LastChgVersionNumber] [INT] NULL
	,[ValidationStatus] [NVARCHAR](250) NULL
 CONSTRAINT [PK_SIILMIEClassMapping] PRIMARY KEY CLUSTERED 
(
	[Code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


