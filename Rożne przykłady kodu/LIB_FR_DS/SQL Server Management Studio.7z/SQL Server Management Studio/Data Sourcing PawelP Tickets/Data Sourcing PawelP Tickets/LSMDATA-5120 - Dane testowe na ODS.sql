﻿--LSMDATA-5120

--Trzeba w procedurach (widokach) ładujących dane do tabel 
--a.	Covers
--b.	CoverLines
--c.	CoverDetails
--d.	CoverPremiumIncome
--e.	Limits
--f.	ClaimTransactions

--Uwzględnić aby aby przy ładowaniu dla warunku ZUMA.InwardsOutwardsFlag = '2' wykluczał inne niż te które dotyczą produktów  [‘FAC’, ‘QS’, ‘SUR’, ‘XSL’, ‘FXL’, ‘QS2’, ‘QS3’]
--Czyli trzeba znaleźć takie które są z tych produktów ale 
-- a) są NIE powiązane z ZURI i one mają zostać odrzucone 
-- b) i takie które są powiązane i one mają zostać

--Dane Testowe na ODS_GENIUS (SIT RDS)

--Znaleźć 


--LSMDATA-5120

--Dane Testowe na ODS_GENIUS (SIT RDS)



    -- --Takie które są w ZURI i są nowe (productcodes)
	select  distinct
			pol.MasterReferenceKey PolicyNumber
			, pol.MasterNumberKey
			, pol.MasterSequenceKey
			, pol.BranchNameCode, pol.BranchNameCodeUnconformed, pol.CompanyNameCode
			, pol.MasterProductCode 
			, cov.MasterReferenceKey RI_PolicyNumber
			, cov.MasterNumberKey
			, cov.MasterSequenceKey

			, cov.MasterProductCode RI_MasterProductCode
			, cov.BranchNameCode, cov.BranchNameCodeUnconformed, cov.CompanyNameCode
		
	FROM   dbo.Map_Master_ZUMA cov 
	JOIN   Map_RIAttachment_ZURI zuri on zuri.RIMasterNumber = cov.MasterNumberKey and zuri.RIMasterSequence = cov.MasterSequenceKey
	JOIN   dbo.Map_Master_ZUMA pol on pol.MasterNumberKey = zuri.MasterNumberKey and zuri.MasterSequenceKey = pol.MasterSequenceKey
	WHERE  cov.InwardsOutwardsFlag = '2'
	and cov.MasterProductCode in ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3')


	    -- --Takie które są w ZURI i NIE są nowe (productcodes)
	select  distinct
			pol.MasterReferenceKey PolicyNumber
			, pol.MasterNumberKey
			, pol.MasterSequenceKey
			, pol.BranchNameCode, pol.BranchNameCodeUnconformed, pol.CompanyNameCode
			, pol.MasterProductCode 
			, cov.MasterReferenceKey RI_PolicyNumber
			, cov.MasterNumberKey
			, cov.MasterSequenceKey

			, cov.MasterProductCode RI_MasterProductCode
			, cov.BranchNameCode, cov.BranchNameCodeUnconformed, cov.CompanyNameCode
		
	FROM   dbo.Map_Master_ZUMA cov 
	JOIN   Map_RIAttachment_ZURI zuri on zuri.RIMasterNumber = cov.MasterNumberKey and zuri.RIMasterSequence = cov.MasterSequenceKey
	JOIN   dbo.Map_Master_ZUMA pol on pol.MasterNumberKey = zuri.MasterNumberKey and zuri.MasterSequenceKey = pol.MasterSequenceKey
	WHERE  cov.InwardsOutwardsFlag = '2'
	AND		cov.MasterProductCode NOT in ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3') --te które są w ZURI i nie są z wybranych produktów


	-- --takie które są w products code ale nie ma ich w ZURI
	select distinct cov.MasterReferenceKey, cov.MasterNumberKey, cov.MasterSequenceKey, MasterProductCode
	FROM dbo.Map_Master_ZUMA cov 
	left JOIN Map_RIAttachment_ZURI zuri on zuri.RIMasterNumber = cov.MasterNumberKey and zuri.RIMasterSequence = cov.MasterSequenceKey
	WHERE  cov.InwardsOutwardsFlag = '2'
	and cov.MasterProductCode in ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3')
	and ZURI.MasterNumberKey is null and zuri.RIMasterSequence is null


	select distinct cov.MasterReferenceKey, cov.MasterNumberKey, cov.MasterSequenceKey, MasterProductCode
	FROM dbo.Map_Master_ZUMA cov 
	left JOIN Map_RIAttachment_ZURI zuri on zuri.RIMasterNumber = cov.MasterNumberKey and zuri.RIMasterSequence = cov.MasterSequenceKey
	WHERE  cov.InwardsOutwardsFlag = '2'
	and cov.MasterProductCode in ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3')
	and ZURI.MasterNumberKey is null and zuri.RIMasterSequence is null



	select top 10 * from Map_RIAttachment_ZURI
	select max(_CDCDateTime) from Map_RIAttachment_ZURI  - dane są aktulane


	-- Polisy zawierające RI
	AB9PDP 001 G
	AB9PDP 001 G
	T0064Y-21F
	T0064Y-21F
	T0064Y-21F
	T0064Y1-21E
	T0064Y1-21E
	T0064Y1-21E
	F0002396
	100031371902F1

	-- Wyszukiwanie zbiorów  (ilosci)

	-- Rekordy oznaczone flagą ZUMA.InwardsOutwardsFlag = 2
	select count(distinct MAPORF)
	FROM	dbo.Map_Master_ZUMA ZUMA 
	WHERE  ZUMA.InwardsOutwardsFlag = '2'







	select top 10  zuma.MasterReferenceKey, zuma.MasterNumberKey, zuma.MasterSequenceKey, MasterProductCode, zuri.* 
	--select distinct MasterProductCode
	FROM dbo.Map_Master_ZUMA ZUMA 
	left JOIN Map_RIAttachment_ZURI zuri on zuri.RIMasterNumber = zuma.MasterNumberKey and zuri.RIMasterSequence = zuma.MasterSequenceKey
	WHERE ZUMA.InwardsOutwardsFlag = '2'
	and MasterProductCode in ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3')
	and ZURI.MasterNumberKey is null and zuri.RIMasterSequence is null

