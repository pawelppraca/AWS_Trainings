

--Dimiesion_MDS_SIILMALClassMapping


DECLARE @TargetEmpty BIT = 1;
SELECT TOP 1 @TargetEmpty = 0 FROM [dbo].SIILMALClassMapping
WHERE _SourceSystemCode = 'MDS';
SELECT @TargetEmpty;




--Load Full


--Read Source

SELECT 
	[SIILMAL_Code]
	,[SIILMAL_DataClass]
	,[SIILMAL_ReservingClass_Code]
	,[SIILMAL_ReservingClass_Name]
	,[SIILMAL_CMTClass_Code]
	,[SIILMAL_CMTClass_Name]
	,[_DateCreated]
	,[_EventExecutionKey]
	,[_LastAction]
	,[_MergeKey]
	,[_SourceSystemCode]
 FROM [dbo].[Warehouse_SIILMALClassMapping]
 WHERE 
	 _LastAction <> 'D'


--Drop And Create Stage Table

USE Warehouse_Repository
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[STAGE].[SIILMALClassMapping_MDS]') AND type in (N'U'))
DROP TABLE [STAGE].[SIILMALClassMapping_MDS]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [STAGE].[SIILMALClassMapping_MDS](
	 [SIILMAL_Code]					[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMAL_DataClass]			[NVARCHAR](255) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMAL_ReservingClass_Code]	[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMAL_ReservingClass_Name]	[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMAL_CMTClass_Code]		[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[SIILMAL_CMTClass_Name]		[NVARCHAR](250) COLLATE Latin1_General_CI_AS  NULL
	,[_DateCreated]					[DATETIME2](7) NULL
	,[_LastAction]					[NCHAR](1) COLLATE Latin1_General_CI_AS NULL
	,[_MergeKey]					[NVARCHAR](255) COLLATE Latin1_General_CI_AS NULL
	,[_SourceSystemCode]			[NVARCHAR](50) COLLATE Latin1_General_CI_AS NULL
) ON [PRIMARY]


CREATE UNIQUE NONCLUSTERED INDEX [IX_STAGE_SIILMALClassMapping_MDS__MergeKey]
	ON [STAGE].[SIILMALClassMapping_MDS] ([_MergeKey])
	INCLUDE ([SIILMAL_Code],[SIILMAL_DataClass],[SIILMAL_ReservingClass_Code],[SIILMAL_ReservingClass_Name],[SIILMAL_CMTClass_Code],[SIILMAL_CMTClass_Name],[_DateCreated],[_LastAction],[_SourceSystemCode]);


--Drop and Create Work Table

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORK].[LloydsCauseOfLoss_MDS]') AND type in (N'U'))
DROP TABLE [WORK].[LloydsCauseOfLoss_MDS]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [WORK].[LloydsCauseOfLoss_MDS](
	[LloydsCauseOfLossKey] [int] NULL,
	[LloydsCauseCode] [NVARCHAR](50) COLLATE Latin1_General_CI_AS NOT NULL,
	[CauseCodeDescription] [NVARCHAR](255) COLLATE Latin1_General_CI_AS NULL,
	[_DateCreated] [datetime2](7) NULL,
	[_EventExecutionKey] [int] NULL,
	[_LastAction] [nchar](1) COLLATE Latin1_General_CI_AS NULL,
	[_MergeKey] [nvarchar](255) COLLATE Latin1_General_CI_AS NULL,
	[_SourceSystemCode] [nvarchar](50) COLLATE Latin1_General_CI_AS NULL
) ON [PRIMARY]


CREATE NONCLUSTERED INDEX [IX_WORK_LloydsCauseOfLoss_MDS_LloydsCauseOfLossKey]
	ON [WORK].[LloydsCauseOfLoss_MDS] ([LloydsCauseOfLossKey])
	INCLUDE ([LloydsCauseCode],[CauseCodeDescription],[_DateCreated],[_EventExecutionKey],[_LastAction],[_MergeKey],[_SourceSystemCode]);


CREATE NONCLUSTERED INDEX [IX_WORK_LloydsCauseOfLoss_MDS__LastAction]
	ON [WORK].[LloydsCauseOfLoss_MDS] ([_LastAction]);

