--Testy jednostkowe LSMDATA-2238 - DEV
--8.03.2023


--truncate table [dbo].[CBIClaimListing_aws_PRD]

select count(*) from [CBIClaimListing_aws_PRD]  -- 359156 records

--wybor 
select top 100 [Claim Number], [Coverage Name],*
from RADM.dbo.[CBIClaimListing_aws_PRD] c order by c.[Claim Number], c.[Coverage Name]




select [Claim Number],  [Coverage Name],  [claimant] , count(*)  duplicates_qty, sum([Total Inr curr(Gross)]) [SUM_Total Inr curr(Gross)], sum([Total Inr curr(Gross)]) % count(*) 
from RADM.dbo.[CBIClaimListing_aws_PRD]
group by [Claim Number],  [Coverage Name], [claimant]
having count(*) > 2
order by count(*) desc


--Rekordy do testow

Claim Number	Coverage Name	Policy number	duplicates_qty
00-SPC-0001-AJ	D&O LIMIT	SYSPC99400027	2
00-CAS-0006-BA	BLENDED LIMIT	BNCAS00400027L	6
00-SPC-0001-AK	BLENDED LIMIT	BNCAS00400027L	3

select top 100 [Claim Number], [Coverage Name], Claimant, [Total Inr curr(Gross)],*
from RADM.dbo.[CBIClaimListing_aws_PRD] c where [Claim Number] = '5AOTH000183630' and [Coverage Name]='REAL PROPERTY - BUILDINGS'


--BEFORE Run Extract

select  [Claim Number], [Coverage Name],claimant,[Total Inr curr(Gross)], *
from RADM.dbo.[CBIClaimListing_aws_PRD] c where [Claim Number] in ('00-SPC-0001-AJ','00-CAS-0006-BA','00-SPC-0001-AK','02-SPC-0001/AY','5AOTH000183630')
order by c.[Claim Number], c.[Coverage Name]


select [Claim Number], [Coverage Name],[Total Inr curr(Gross)],*
from Staging_GENIUS.dbo.[CBIClaimListing] c where [Claim Number] in ('00-SPC-0001-AJ','00-CAS-0006-BA','00-SPC-0001-AK','02-SPC-0001/AY','5AOTH000183630')
order by c.[Claim Number], c.[Coverage Name]



--AFTER Run Extract

select  [Claim Number], [Coverage Name],claimant,[Total Inr curr(Gross)], *
from RADM.dbo.[CBIClaimListing_aws_PRD] c where [Claim Number] in ('00-SPC-0001-AJ','00-CAS-0006-BA','00-SPC-0001-AK','02-SPC-0001/AY','5AOTH000183630')
order by c.[Claim Number], c.[Coverage Name]

select [Claim Number], [Coverage Name],[Total Inr curr(Gross)], *
from Staging_GENIUS.dbo.[CBIClaimListing] c where [Claim Number] in ('00-SPC-0001-AJ','00-CAS-0006-BA','00-SPC-0001-AK','02-SPC-0001/AY','5AOTH000183630')
order by c.[Claim Number], c.[Coverage Name]



--Test before Run LOAD


select [Claim Number], [Coverage Name],[Total Inr curr(Gross)], *
from Staging_GENIUS.dbo.[CBIClaimListing] c where [Claim Number] in ('00-SPC-0001-AJ','00-CAS-0006-BA','00-SPC-0001-AK','02-SPC-0001/AY','5AOTH000183630')
order by c.[Claim Number], c.[Coverage Name]


select [Claim Number], [Coverage Name],sum([Total Inr curr(Gross)]) --, *
from Staging_GENIUS.dbo.[CBIClaimListing] c where [Claim Number] in ('00-SPC-0001-AJ','00-CAS-0006-BA','00-SPC-0001-AK','02-SPC-0001/AY','5AOTH000183630')
group  by c.[Claim Number], c.[Coverage Name]
order by c.[Claim Number], c.[Coverage Name]


select [Claim Number], [Coverage Name],[Total Inr curr(Gross)], *
from ODS_GENIUS.dbo.[CBIClaimListing] c where [Claim Number] in ('00-SPC-0001-AJ','00-CAS-0006-BA','00-SPC-0001-AK','02-SPC-0001/AY','5AOTH000183630')
order by c.[Claim Number], c.[Coverage Name]


--Update  - Wymagany Datafix

select * 
--update cbi set [Coverage Name] = '<<Unknown>>'
from ODS_GENIUS.dbo.[CBIClaimListing] cbi where [Coverage Name] is null


select * 
--update cbi set [Coverage Name] = '<<Unknown>>'
from Staging_GENIUS.dbo.[CBIClaimListing] cbi where [Coverage Name] is null


After LOAD


select [Claim Number], [Coverage Name],[Total Inr curr(Gross)], *
from Staging_GENIUS.dbo.[CBIClaimListing] c where [Claim Number] in ('00-SPC-0001-AJ','00-CAS-0006-BA','00-SPC-0001-AK')
order by c.[Claim Number], c.[Coverage Name]


select [Claim Number], [Coverage Name],[Total Inr curr(Gross)], *
from Staging_GENIUS.dbo.[CBIClaimListing] c where [Claim Number] in ('00-SPC-0001-AJ','00-CAS-0006-BA','00-SPC-0001-AK')
order by c.[Claim Number], c.[Coverage Name]


select [Claim Number], [Coverage Name],[Total Inr curr(Gross)], *
from ODS_GENIUS.dbo.[CBIClaimListing] c where [Claim Number] in ('00-SPC-0001-AJ','00-CAS-0006-BA','00-SPC-0001-AK')
order by c.[Claim Number], c.[Coverage Name]
