
--RDS_UAT

	drop table if exists #all_cov
	select *  --71422
	into #all_cov
	FROM  dbo.Map_Master_ZUMA ZUMA 
	WHERE ZUMA.InwardsOutwardsFlag = '2'

	select count(*) from #all_cov

	
	--covery kt�re maja zosta?
	
	drop table if exists #cov_2_stay
	
	select distinct cov.MasterNumberKey, cov.MasterSequenceKey, cov.MasterReferenceKey, cov.MasterProductCode
	into #cov_2_stay
	FROM  dbo.Map_Master_ZUMA cov
	JOIN Map_RIAttachment_ZURI zuri on zuri.RIMasterNumber = cov.MasterNumberKey and zuri.RIMasterSequence = cov.MasterSequenceKey
	JOIN dbo.Map_Master_ZUMA POL on pol.MasterNumberKey = zuri.MasterNumberKey and pol.MasterSequenceKey = zuri.MasterSequenceKey
	WHERE cov.InwardsOutwardsFlag = '2' 
	AND COV.MasterProductCode in ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3')
	AND pol.MasterNumberKey IS NOT NULL AND pol.MasterSequenceKey IS NOT NULL

	
	--covery kt�re maja by? wyci?te

	drop table if exists #cov_2_Del

	select distinct cov.MasterNumberKey, cov.MasterSequenceKey, cov.MasterReferenceKey, cov.MasterProductCode
	into #cov_2_Del
	FROM  dbo.Map_Master_ZUMA cov
	LEFT JOIN Map_RIAttachment_ZURI zuri on zuri.RIMasterNumber = cov.MasterNumberKey and zuri.RIMasterSequence = cov.MasterSequenceKey
	LEFT JOIN dbo.Map_Master_ZUMA POL on pol.MasterNumberKey = zuri.MasterNumberKey and pol.MasterSequenceKey = zuri.MasterSequenceKey
	WHERE cov.InwardsOutwardsFlag = '2' 
	AND COV.MasterProductCode in ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3')
	AND pol.MasterNumberKey IS NULL AND pol.MasterSequenceKey IS NULL

	
	--sprawdzenie czy s? 

	select * from #cov_2_Del
	INTERSECT
	select * from #cov_2_stay --nie ma 


	select count(*) all_cov from #all_cov --71422
	select count(*) cov_2_Del from #cov_2_Del --34739
	select count(*) cov_2_stay from #cov_2_stay --36652  
	select 71422-34739 -- = 36683
	select 36683-36652 -- = 31


	-- COV kt�rych nie powinno si? brac pod uwag?
	select cov.*
	into #cov_2_process
	FROM  #all_cov cov 
	LEFT JOIN #cov_2_Del c2d on c2d.MasterNumberKey = cov.MasterNumberKey and c2d.MasterSequenceKey = cov.MasterSequenceKey
	WHERE cov.InwardsOutwardsFlag = '2'
	AND c2d.MasterNumberKey is NULL and c2d.MasterSequenceKey IS NULL
	

	--Sprawdzenie czy istniej? powi?zania mi?dzy COV, kt�re zostan? a ZURI
	select distinct cov.MasterNumberKey, cov.MasterSequenceKey, cov.MasterReferenceKey, cov.MasterProductCode
					, pol.MasterNumberKey, pol.MasterSequenceKey, pol.MasterReferenceKey, pol.MasterProductCode
	FROM  #cov_2_process cov
	JOIN Map_RIAttachment_ZURI zuri on zuri.RIMasterNumber = cov.MasterNumberKey and zuri.RIMasterSequence = cov.MasterSequenceKey
	JOIN dbo.Map_Master_ZUMA POL on pol.MasterNumberKey = zuri.MasterNumberKey and pol.MasterSequenceKey = zuri.MasterSequenceKey
	WHERE cov.InwardsOutwardsFlag = '2' 
	order by pol.MasterReferenceKey


	--Sprawdzenie czy zostaj? COVY, ktorych nie ma w ZURI - UAT: 8 szt

	select distinct cov.MasterNumberKey, cov.MasterSequenceKey, cov.MasterReferenceKey, cov.MasterProductCode
					, pol.MasterNumberKey, pol.MasterSequenceKey, pol.MasterReferenceKey, pol.MasterProductCode
	FROM  #cov_2_process cov
	left JOIN Map_RIAttachment_ZURI zuri on zuri.RIMasterNumber = cov.MasterNumberKey and zuri.RIMasterSequence = cov.MasterSequenceKey
	left JOIN dbo.Map_Master_ZUMA POL on pol.MasterNumberKey = zuri.MasterNumberKey and pol.MasterSequenceKey = zuri.MasterSequenceKey
	WHERE cov.InwardsOutwardsFlag = '2' 
	AND pol.MasterNumberKey IS NULL AND pol.MasterSequenceKey IS NULL



	--Sprawdzenie czy w pierwotnym zbiorze s? Covery ktorycvch nie ma w ZURI

	select distinct cov.MasterNumberKey, cov.MasterSequenceKey, cov.MasterReferenceKey, cov.MasterProductCode
					, pol.MasterNumberKey, pol.MasterSequenceKey, pol.MasterReferenceKey, pol.MasterProductCode
	FROM  #all_cov cov
	left JOIN Map_RIAttachment_ZURI zuri on zuri.RIMasterNumber = cov.MasterNumberKey and zuri.RIMasterSequence = cov.MasterSequenceKey
	left JOIN dbo.Map_Master_ZUMA POL on pol.MasterNumberKey = zuri.MasterNumberKey and pol.MasterSequenceKey = zuri.MasterSequenceKey
	WHERE cov.InwardsOutwardsFlag = '2' 
	AND pol.MasterNumberKey IS NULL AND pol.MasterSequenceKey IS NULL





	--Sprawdzenia

	select   cov.MasterReferenceKey, cov.MasterNumberKey, cov.MasterSequenceKey, cov.MasterProductCode,cov.*
	--select distinct InwardsOutwardsFlag
	--select distinct cov.MasterProductCode
	FROM dbo.Map_Master_ZUMA cov
	JOIN #cov_2_Del c2d on c2d.MasterNumberKey = cov.MasterNumberKey and c2d.MasterSequenceKey = cov.MasterSequenceKey
	JOIN Map_RIAttachment_ZURI zuri on zuri.MasterNumberKey = cov.MasterNumberKey and zuri.MasterSequenceKey = cov.MasterSequenceKey
	




		select 
			zuma.MasterReferenceKey PolicyNumber
			, zuma.MasterNumberKey
			, zuma.MasterSequenceKey
			, zuma.BranchNameCode, zuma.BranchNameCodeUnconformed, zuma.CompanyNameCode
			, zumari.MasterReferenceKey RI_PolicyNumber
			, zumari.MasterNumberKey
			, zumari.MasterSequenceKey
			, zuma.MasterProductCode 
			, zumari.MasterProductCode RI_MasterProductCode
			, zumari.BranchNameCode, zumari.BranchNameCodeUnconformed, zumari.CompanyNameCode
	FROM   dbo.Map_Master_ZUMA
	WHERE  ZUMA.InwardsOutwardsFlag = '2'
	and zumari.MasterProductCode not in ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3') --te kt�re s? w ZURI i nie s? z wybranych produkt�w

