/*
Odczytanie CDCBoundary z BI_LZ
Zapisanie do RDS granic




*/


--Tabela na granice CDC

USE [ODS_Genius]
GO

CREATE TABLE [dbo].[RI_Policies_CDCDateTime](
	[RI_Policies_CDCDateTime_Key] [int] IDENTITY(1,1) NOT NULL,
	[TableName] [nvarchar](50) NULL,
	[CDC] [nvarchar](50) NULL,
	[LineOfBusinessCode] [nvarchar](50) NULL,
	[DepartmentCode] [nvarchar](50) NULL,
	[IndustryCode] [nvarchar](50) NULL,
	[IndustryMinorCode] [nvarchar](50) NULL,
	[RiskCountry] [nvarchar](100) NULL,
	[RiskState] [nvarchar](100) NULL,
	[_SourceSystemCode] [nvarchar](250) NULL,
	[_EventExecutionKey_pol] [int] NOT NULL,
	[_EventExecutionKey_gptm] [int] NOT NULL,
	[_EventExecutionKey_gbm] [int] NOT NULL,
	[_EventExecutionKey_grl] [int] NOT NULL,
	[_CDCDateTime_pol] [datetime2](7) NOT NULL,
	[_CDCDateTime_gptm] [datetime2](7) NOT NULL,
	[_CDCDateTime_gbm] [datetime2](7) NOT NULL,
	[_CDCDateTime_grl] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_Build_Pol_CDCDateTime] PRIMARY KEY CLUSTERED 
(
	[Build_Pol_CDCDateTimeKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, DATA_COMPRESSION = PAGE) ON [PRIMARY]
) ON [PRIMARY]
GO


