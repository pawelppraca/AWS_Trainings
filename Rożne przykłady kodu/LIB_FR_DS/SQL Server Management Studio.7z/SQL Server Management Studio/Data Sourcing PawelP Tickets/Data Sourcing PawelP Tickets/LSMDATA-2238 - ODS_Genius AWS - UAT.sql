IF OBJECT_ID('tempdb..#Results_UAT') IS NOT NULL
    DROP TABLE #Results_UAT


		SELECT  
			clm.[Claim Number] AS ClaimNo
		,	CAST(REPLACE(clm.[Claim Handler], ',',' ') AS NVARCHAR(50)) AS ClaimHandler
		,	CAST(clm.[Catastrophe Code] AS NVARCHAR(50)) AS CatNo
		,	clm.[Catastrophe Description]  AS CatDescription
		,	CAST(COALESCE(clm.[Date Last Closed], '1900-01-01') AS DATE) AS ClosedDate
		,	CAST(COALESCE(clm.[Date Last Reopened], '1900-01-01') AS DATE) AS ReopenedDate
		,	CAST(COALESCE(clm.[Date Of Loss], '1900-01-01') AS DATE) AS LossDate
		,	CAST(COALESCE(clm.[Date Reported/Event] , '1900-01-01') AS DATE) AS ReportedDate
		,	clm.[Cause of Loss 1] AS CauseOfLoss
		,	clm.[Cause of Loss 4 - Type] AS CauseOfLoss4
		,	clm.[Cause Of Loss2] AS CauseOfLoss2
		,	CAST(clm.[Cause Of Loss3] AS NVARCHAR(100)) AS CauseOfLoss3
		,	CAST(clm.[Claim Closure Reason] AS NVARCHAR(100)) AS ClaimOutcome
		,	CAST(REPLACE(clm.[Claim Description], ',', ' ') AS NVARCHAR(4000)) AS ClaimDescription
		,	CAST(clm.[Claim Event Code] AS NVARCHAR(50)) AS ClaimEventCode
		,	CAST([Claim Current State] AS NVARCHAR(255)) AS ClaimStatus
		,	CAST(clm.Severity AS NVARCHAR(50)) AS ClaimSeverity
		,	CAST(COALESCE(clm.[Claim Title], N'<<Unknown>>') AS NVARCHAR(255)) AS ClaimTitle
		,	CAST(clm.[Claim Type] AS NVARCHAR(50)) AS ClaimType
		,	CAST(COALESCE(clm.[Claim Create Date], '1900-01-01') AS DATE) AS CreatedDate
		,	clm.[Cause of Loss 1 Other Description] AS DescriptionOfOther1
		,	clm.[Cause of Loss 2 Other Description] AS DescriptionOfOther2
		,	clm.[Cause of Loss 3 Other Description] AS DescriptionOfOther3
		,	CAST(clm.[Event Description] AS NVARCHAR(100)) AS EventDescription
		,	CAST(LEFT(clm.[Loss City],255) AS NVARCHAR(100)) AS LossCity 
		,	clm.[Loss Country] AS LossCountry
		,	clm.[Loss Region] AS LossRegion
		,	CAST(clm.[Loss State] AS NVARCHAR(100)) AS LossState 
		,	CAST(clm.[First Exposure Claimant] AS NVARCHAR(255)) AS FirstExposureClaimant
		,	clm.Region
		,	CAST(clm.[TPA Claim Number] AS NVARCHAR(100)) AS TPAClaimNumber
		,	clm.[Cause of Loss 4 Other Description] AS DescriptionOfOther4  
		,	clm.[Cause Of Loss5] AS CauseOfLoss5                       
		,	clm.[Loss Code Group] AS LossCodeGroup                 
		,	clm.[Organization] AS Organization                      
		,	clm.[Cyber Consideration] AS CyberConsideration               
		,	clm.[Cyber Consideration Other Description] AS CyberConsiderationOtherDescription
		,	clm.[Ransomware Aspect] AS RansomwareAspect
		,	clm.[Batched Claim] AS BatchedClaim
		,	clm.[Block File] AS BlockFile
		,	clm.[Loss Fund] AS LossFund
		,	MIN(clm._DateCreated) _DateCreated
		,	MAX(clm._EventExecutionKey) _EventExecutionKey
		,	MAX(clm._LastAction) _LastAction
		,	CAST(N'GENIUS' AS NVARCHAR(50)) AS _SourceSystemCode
		into #Results_UAT
		FROM
			dbo.CBIClaimListing clm
		group by 
		clm.[Claim Number] 
		,	CAST(REPLACE(clm.[Claim Handler], ',',' ') AS NVARCHAR(50)) 
		,	CAST(clm.[Catastrophe Code] AS NVARCHAR(50)) 
		,	clm.[Catastrophe Description]  
		,	CAST(COALESCE(clm.[Date Last Closed], '1900-01-01') AS DATE) 
		,	CAST(COALESCE(clm.[Date Last Reopened], '1900-01-01') AS DATE) 
		,	CAST(COALESCE(clm.[Date Of Loss], '1900-01-01') AS DATE)
		,	CAST(COALESCE(clm.[Date Reported/Event] , '1900-01-01') AS DATE) 
		,	clm.[Cause of Loss 1] 
		,	clm.[Cause of Loss 4 - Type] 
		,	clm.[Cause Of Loss2] 
		,	CAST(clm.[Cause Of Loss3] AS NVARCHAR(100)) 
		,	CAST(clm.[Claim Closure Reason] AS NVARCHAR(100))
		,	CAST(REPLACE(clm.[Claim Description], ',', ' ') AS NVARCHAR(4000)) 
		,	CAST(clm.[Claim Event Code] AS NVARCHAR(50)) 
		,	CAST([Claim Current State] AS NVARCHAR(255)) 
		,	CAST(clm.Severity AS NVARCHAR(50)) 
		,	CAST(COALESCE(clm.[Claim Title], N'<<Unknown>>') AS NVARCHAR(255)) 
		,	CAST(clm.[Claim Type] AS NVARCHAR(50)) 
		,	CAST(COALESCE(clm.[Claim Create Date], '1900-01-01') AS DATE)
		,	clm.[Cause of Loss 1 Other Description] 
		,	clm.[Cause of Loss 2 Other Description] 
		,	clm.[Cause of Loss 3 Other Description] 
		,	CAST(clm.[Event Description] AS NVARCHAR(100)) 
		,	CAST(LEFT(clm.[Loss City],255) AS NVARCHAR(100)) 
		,	clm.[Loss Country] 
		,	clm.[Loss Region] 
		,	CAST(clm.[Loss State] AS NVARCHAR(100)) 
		,	CAST(clm.[First Exposure Claimant] AS NVARCHAR(255)) 
		,	clm.Region
		,	CAST(clm.[TPA Claim Number] AS NVARCHAR(100)) 
		,	clm.[Cause of Loss 4 Other Description]  
		,	clm.[Cause Of Loss5]                       
		,	clm.[Loss Code Group]                
		,	clm.[Organization]                       
		,	clm.[Cyber Consideration]               
		,	clm.[Cyber Consideration Other Description] 
		,	clm.[Ransomware Aspect]
		,	clm.[Batched Claim] 
		,	clm.[Block File] 
		,	clm.[Loss Fund] 


select * 
from CBIClaimListing
where [Claim Number] in (
		select ClaimNo from #Results_UAT group by ClaimNo having count(*) > 1
) order by [Claim Number]



select * from CBIClaimListing where [claim number] in (
'NEWSPC000001524',
'PRO00052024',
'101862797-001',
'ATLCAR110205732',
'HCL00079812'
)
order by [claim number]
