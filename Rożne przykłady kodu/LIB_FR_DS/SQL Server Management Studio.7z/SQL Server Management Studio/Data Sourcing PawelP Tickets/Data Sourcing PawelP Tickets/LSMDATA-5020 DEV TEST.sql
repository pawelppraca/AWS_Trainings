
--DEV TEST 
--==============================
-- SIILMALClassMapping
--==============================

Select count(*) from Staging_MDS.dbo.SIILMALClassMapping  --158

-- Test UPDATE - PASS
SELECT *  
--update t set ReservingClass_Name = ReservingClass_Name+'@'
FROM Staging_MDS.[dbo].[SIILMALClassMapping] t where code=1

--TESTE DELETE - PASS
SELECT *  
--delete from t
FROM Staging_MDS.[dbo].[SIILMALClassMapping] t where code=10

--TEst Insert
Select max(cast(code as INT))  FROM Staging_MDS.[dbo].[SIILMALClassMapping] 

--Insert into Staging_MDS.[dbo].[SIILMALClassMapping] (VersionName, VersionNumber, Version_ID, VersionFlag, Name, Code, ChangeTrackingMask, DataClass, ReservingClass_Code, ReservingClass_Name, ReservingClass_ID, CMTClass_Code, CMTClass_Name, CMTClass_ID, EnterDateTime, EnterUserName, EnterVersionNumber, LastChgDateTime, LastChgUserName, LastChgVersionNumber, ValidationStatus)
SELECT VersionName, VersionNumber, Version_ID, VersionFlag, Name, 200, ChangeTrackingMask, 'Primary & Low Excess - Test PP', ReservingClass_Code, ReservingClass_Name, ReservingClass_ID, CMTClass_Code, CMTClass_Name, CMTClass_ID, getdate(), EnterUserName, EnterVersionNumber, LastChgDateTime, LastChgUserName, LastChgVersionNumber, ValidationStatus
FROM Staging_MDS.[dbo].[SIILMALClassMapping] t where code=114



Select * from ODS_MDS.[WORK].[SIILMALClassMapping]

Select _LastAction, * from ODS_MDS.[dbo].[Map_SIILMALClassMapping] t where SIILMAL_Code in ( 1, 10, 200)

Select * from ODS_MDS.[dbo].[Warehouse_SIILMALClassMapping] t where SIILMAL_Code in ( 1, 10, 200)


Select _LastAction, * from Warehouse_Repository.dbo.SIILMALClassMapping


SELECT 
       t.[SIILMAL_ClassMappingKey]
      ,t.[SIILMAL_Code]
      ,t.[SIILMAL_DataClass]
      ,t.[SIILMAL_ReservingClass_Code]
      ,t.[SIILMAL_ReservingClass_Name]
      ,t.[SIILMAL_CMTClass_Code]
      ,t.[SIILMAL_CMTClass_Name]
      ,t.[_DateCreated]
      ,t.[_EventExecutionKey]
      ,t.[_LastAction]
      ,t.[_MergeKey]
      ,t.[_SourceSystemCode]
  FROM Warehouse_Repository.[dbo].[SIILMALClassMapping] t
  FULL OUTER JOIN Warehouse_Repository.[STAGE].[SIILMALClassMapping_MDS] s 
  ON s._MergeKey = t._MergeKey
  WHERE s.SIILMAL_Code in ( 1, 10, 200)
  ORDER BY t._MergeKey

Select * 
from Warehouse_Repository.dbo.SIILMALClassMapping t
JOIN Warehouse_Repository.WORK.SIILMALClassMapping_MDS s
ON t._EventExecutionKey = s._EventExecutionKey



--==============================
-- SIILMIEClassMapping
--==============================

Select count(*) from Staging_MDS.dbo.SIILMIEClassMapping  --121


-- Test UPDATE - PASS
SELECT *  
--update t set ReservingClass_Name = ReservingClass_Name+'@'
FROM Staging_MDS.[dbo].[SIILMIEClassMapping] t where code=1

--TESTE DELETE - PASS
SELECT *  
--delete from t
FROM Staging_MDS.[dbo].[SIILMIEClassMapping] t where code=10

--TEst Insert - PASS
Select max(cast(code as INT))  FROM Staging_MDS.[dbo].[SIILMIEClassMapping] 

--Insert into Staging_MDS.[dbo].[SIILMIEClassMapping] (VersionName, VersionNumber, Version_ID, VersionFlag, Name, Code, ChangeTrackingMask, S2ReserveClass, ReservingClass_Code, ReservingClass_Name, ReservingClass_ID, CMTClass_Code, CMTClass_Name, CMTClass_ID, EnterDateTime, EnterUserName, EnterVersionNumber, LastChgDateTime, LastChgUserName, LastChgVersionNumber, ValidationStatus)
SELECT VersionName, VersionNumber, Version_ID, VersionFlag, Name, 200, ChangeTrackingMask, 'Marine Cargo - Test PP', ReservingClass_Code, ReservingClass_Name, ReservingClass_ID, CMTClass_Code, CMTClass_Name, CMTClass_ID, getdate(), EnterUserName, EnterVersionNumber, LastChgDateTime, LastChgUserName, LastChgVersionNumber, ValidationStatus
--select *
FROM Staging_MDS.[dbo].[SIILMIEClassMapping] t where code=64

-- Test UPDATE No BLOE- PASS
SELECT *  
--update t set ReservingClass_Name = ReservingClass_Name+'@'
FROM Staging_MDS.[dbo].[SIILMIEClassMapping] t where code=200


Select _LastAction,* from ODS_MDS.[dbo].[Map_SIILMIEClassMapping]where SIILMIE_Code in ( 1, 10, 200)

Select _LastAction,* from ODS_MDS.[dbo].[Map_SIILMIEClassMapping]where SIILMIE_Code in ( 1, 10, 200)

Select _LastAction,* from ODS_MDS.[dbo].[Warehouse_SIILMIEClassMapping]where SIILMIE_Code in ( 1, 10, 200)

Select _LastAction, * from Warehouse_Repository.dbo.SIILMIEClassMapping where SIILMIE_Code in ( 1, 10, 200)



Select _LastAction, * from IDS_MART.dbo.SIILMALClassMapping where Code in ( 1, 10, 200)
Select _LastAction, * from IDS_MART.dbo.SIILMIEClassMapping where Code in ( 1, 10, 200)



-- SIT TESTS
--==============================
--==============================



select * from tasks where taskcode like '%SIIL%'

select * from Staging_MDS.dbo.SIILMALClassMapping
--Before SIT TEST

select 'Staging_MDS.dbo.SIILMALClassMapping' table_name, count(*) row_count from Staging_MDS.dbo.SIILMALClassMapping
select 'Staging_MDS.dbo.SIILMIEClassMapping' table_name, count(*) row_count from Staging_MDS.dbo.SIILMIEClassMapping

select 'ODS_MDS.dbo.SIILMALClassMapping' table_name, count(*) row_count from ODS_MDS.dbo.SIILMALClassMapping
select 'ODS_MDS.dbo.SIILMIEClassMapping' table_name, count(*) row_count from ODS_MDS.dbo.SIILMIEClassMapping

select 'Warehouse_Repository.dbo.SIILMALClassMapping' table_name, count(*) row_count from Warehouse_Repository.dbo.SIILMALClassMapping
select 'Warehouse_Repository.dbo.SIILMIEClassMapping' table_name, count(*) row_count from Warehouse_Repository.dbo.SIILMIEClassMapping

select 'IDS_Mart.dbo.SIILMALClassMapping' table_name, count(*) row_count from IDS_Mart.dbo.SIILMALClassMapping
select 'IDS_Mart.dbo.SIILMIEClassMapping' table_name, count(*) row_count from IDS_Mart.dbo.SIILMIEClassMapping


--After SIT TEST

select 'Staging_MDS.dbo.SIILMALClassMapping' table_name, count(*) row_count from Staging_MDS.dbo.SIILMALClassMapping
select 'Staging_MDS.dbo.SIILMIEClassMapping' table_name, count(*) row_count from Staging_MDS.dbo.SIILMIEClassMapping

select 'ODS_MDS.dbo.SIILMALClassMapping' table_name, count(*) row_count from ODS_MDS.dbo.SIILMALClassMapping
select 'ODS_MDS.dbo.SIILMIEClassMapping' table_name, count(*) row_count from ODS_MDS.dbo.SIILMIEClassMapping

select 'Warehouse_Repository.dbo.SIILMALClassMapping' table_name, count(*) row_count from Warehouse_Repository.dbo.SIILMALClassMapping
select 'Warehouse_Repository.dbo.SIILMIEClassMapping' table_name, count(*) row_count from Warehouse_Repository.dbo.SIILMIEClassMapping


select 'IDS_Mart.dbo.SIILMALClassMapping' table_name, count(*) row_count from IDS_Mart.dbo.SIILMALClassMapping
select 'IDS_Mart.dbo.SIILMIEClassMapping' table_name, count(*) row_count from IDS_Mart.dbo.SIILMIEClassMapping




-- UAT TESTS
--==============================
--==============================



select * from tasks where taskcode like '%SIIL%'

select * from Staging_MDS.dbo.SIILMALClassMapping
--Before SIT TEST

select 'Staging_MDS.dbo.SIILMALClassMapping' table_name, count(*) row_count from Staging_MDS.dbo.SIILMALClassMapping
select 'Staging_MDS.dbo.SIILMIEClassMapping' table_name, count(*) row_count from Staging_MDS.dbo.SIILMIEClassMapping

select 'ODS_MDS.dbo.SIILMALClassMapping' table_name, count(*) row_count from ODS_MDS.dbo.SIILMALClassMapping
select 'ODS_MDS.dbo.SIILMIEClassMapping' table_name, count(*) row_count from ODS_MDS.dbo.SIILMIEClassMapping

select 'Warehouse_Repository.dbo.SIILMALClassMapping' table_name, count(*) row_count from Warehouse_Repository.dbo.SIILMALClassMapping
select 'Warehouse_Repository.dbo.SIILMIEClassMapping' table_name, count(*) row_count from Warehouse_Repository.dbo.SIILMIEClassMapping

select 'IDS_Mart.dbo.SIILMALClassMapping' table_name, count(*) row_count from IDS_Mart.dbo.SIILMALClassMapping
select 'IDS_Mart.dbo.SIILMIEClassMapping' table_name, count(*) row_count from IDS_Mart.dbo.SIILMIEClassMapping

-- PROD TESTS
--==============================
--==============================



select * from tasks where taskcode like '%SIIL%'

select * from Staging_MDS.dbo.SIILMALClassMapping
--Before SIT TEST

select 'Staging_MDS.dbo.SIILMALClassMapping' table_name, count(*) row_count from Staging_MDS.dbo.SIILMALClassMapping
select 'Staging_MDS.dbo.SIILMIEClassMapping' table_name, count(*) row_count from Staging_MDS.dbo.SIILMIEClassMapping

select 'ODS_MDS.dbo.SIILMALClassMapping' table_name, count(*) row_count from ODS_MDS.dbo.SIILMALClassMapping
select 'ODS_MDS.dbo.SIILMIEClassMapping' table_name, count(*) row_count from ODS_MDS.dbo.SIILMIEClassMapping

select 'Warehouse_Repository.dbo.SIILMALClassMapping' table_name, count(*) row_count from Warehouse_Repository.dbo.SIILMALClassMapping
select 'Warehouse_Repository.dbo.SIILMIEClassMapping' table_name, count(*) row_count from Warehouse_Repository.dbo.SIILMIEClassMapping

select 'IDS_Mart.dbo.SIILMALClassMapping' table_name, count(*) row_count from IDS_Mart.dbo.SIILMALClassMapping
select 'IDS_Mart.dbo.SIILMIEClassMapping' table_name, count(*) row_count from IDS_Mart.dbo.SIILMIEClassMapping

