/*
Przyk?ad 1:
--------------
dbo.Policies where Underwriterrefrence='1000215493-02'

dbo.Covers where coverreference='100021549302F1'

Przyk?ad 2
-------------

Policies = CFCGACQF50022

Covers in (
'T0358F5-22A'     
,'T0358F5-22B'     
,'T0358F5-22BB'    
,'FACACQF50022 E'
,'FACACQF50022 H'  
,'FACACQF50022 M'  
,'FACACQF50022 S'  
,'FACACQF50022 T' 
,'FACACQF50022GRS'
)



*/


--WarehouseRepository (UAT)
USE Warehouse_Repository
select * from dbo.Policies where underwriterreference='1000215493-02' and _CurrentFlag=1 --jest 1 wiersz

select * from dbo.Covers where coverreference='100021549302F1'

--Przyk?ad 2
select * from dbo.Policies where Policyreference='CFCGACQF50022' and _CurrentFlag=1 --jest 1 wiersz


--Dane w ODS (UAT, RDS)
select top 100 * from ZUMA where MAPORF like 'CFCGACQF50022%'




--Dane w BI_LZ

--BI_LZ
select top 100 pol.maporf PolicyNr, cov.maporf cover_nr, map.* from GENIUS.ZUMA pol
inner join GENIUS.ZURI map
    on  pol.MAMANU = map.RIMANU
    and pol.MAMASE = map.RIMASE
inner join Genius.ZUMA cov
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
where pol.MAPORF like 'CFCGACQF50022%'

/*
PolicyNr	cover_nr
CFCGACQF50022	T0358F5-22A
CFCGACQF50022	T0358F5-22B
CFCGACQF50022	T0358F5-22BB
CFCGACQF50022	FACACQF50022 E
CFCGACQF50022	FACACQF50022 H
CFCGACQF50022	FACACQF50022 M
CFCGACQF50022	FACACQF50022 S
CFCGACQF50022	FACACQF50022 T
CFCGACQF50022	FACACQF50022GRS
*/





select top 100 * from GENIUS.ZUMA where MAPORF like 'CFCGACQF50022%'

select top 100 * from GENIUS.ZUMA where MAPORF like 'FACACQF50022GRS%'



--BI_LZ
select top 100 pol.maporf PolicyNr, cov.maporf cover_nr, map.* from GENIUS.ZUMA pol
inner join GENIUS.ZURI map
    on  pol.MAMANU = map.RIMANU
    and pol.MAMASE = map.RIMASE
inner join Genius.ZUMA cov
    on map.RIRIMN = cov.MAMANU
    and map.RIRIMS = cov.MAMASE
where pol.MAPORF like 'CFCGACQF50022%'

select top 100 * from GENIUS.ZUMA where MAPORF like 'FACACQF50022GRS%'



--CDC
select top 1000 * from Genius.ZUMA where MAPORF = 'FACACQF50022GRS'

select top 1000 * from Genius.ZUMA_LOG (nolock) where MAPORF = 'FACACQF50022GRS'


select top 1000 
header_change_seq hcs, header_timestamp, MAMANU, MAMASE, LastUpdatedDate
,* from Genius.ZUMA_LOG (nolock) 
order by header_change_seq desc


-- exec IDS.GetCurrentCDCUpperBoundary tego nie da si? uruchomi?
declare @result varchar(100)
exec IDS.GetCurrentCDCUpperBoundary_ID @result output
exec IDS.GetCurrentCDCUpperBoundary_PP
select @result


--Za?o?enie ostatni przeprocesowany header_change_seq
--20240605100314680000000000876150725 -- 2024-06-05 09:51:05.662309000

declare @CDCBoundMin varchar(100) = '20240605100314680000000000876150725'
declare @CDCBoundMax varchar(100) = '20240605131119900000000000876819101'

select 
header_change_seq hcs, header_timestamp, MAMANU, MAMASE, LastUpdatedDate, MAPORF
,* from Genius.ZUMA_LOG (nolock) 
where header_change_seq > @CDCBoundMin --between  @CDCBoundMin and @CDCBoundMax
order by header_change_seq



--sprawdzenie danych w Warehouse vs dane z ZUMA i ZUMA LOG


--Dane maj? by? pobierane z tabelki bez LOG
