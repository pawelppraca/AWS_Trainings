--SIT 14.05.2024

--uruchomienie FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH_Opt pakietu  EEK=2451505 - Test bez generowania danych z RDS - odczyt z widoku BLOE

exec [dbo].[GenChangedData_PolicyPremiumTransactionsCoverage] 2451510, True
 --ROLLBACK TRANSACTION; 


 select count(*) from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS] (nolock) --9023954

--Kopia tabeli WORK WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS]  po processingu Nowa metoda - testy niezgodnosci
select *
INTO WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_PROC_GenChD_24515_1_BLOE]  
FROM WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS] (nolock) 

--Kopia tabeli Stage
select *
INTO WAREHOUSE_Repository.STAGE.[PolicyPremiumTransactionsCoverage_GENIUS_by_PROC_GenChD_24515_1_BLOE]  
FROM WAREHOUSE_Repository.[STAGE].[PolicyPremiumTransactionsCoverage_GENIUS](nolock) 

/*
(9023954 rows affected)
(10274870 rows affected)
Completion time: 2024-05-15T18:13:53.0171070+02:00
*/



--uruchomienie FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH_noOpt pakietu  EEK=2451521 - Test bez generowania danych z RDS - odczyt z widoku BLOE

--Kopia tabeli WORK WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS]  po processingu star? metod?e - testy zgodnosci
select *
INTO WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_GenChD_24515_1_BLOE]  
FROM WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS] (nolock) 

--Kopia tabeli Stage
select *
INTO WAREHOUSE_Repository.STAGE.[PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_GenChD_24515_1_BLOE]  
FROM WAREHOUSE_Repository.[STAGE].[PolicyPremiumTransactionsCoverage_GENIUS](nolock) 



/*

(9023954 rows affected)

(10274870 rows affected)

Completion time: 2024-05-15T20:57:01.7739725+02:00

*/





--Por�wnanie tabel WORKowych 
--WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_GenChD_24515_1_BLOE]  
--WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_PROC_GenChD_24515_1_BLOE]  


select
      [LimitKey]
      ,[OriginalCurrencyKey]
      ,[PolicyKey]
      ,[PolicyReference]
      ,[AuditNumber]
      ,[ExternalReferenceIdentifier]
      ,[DoubleEntryItemSequence]
      ,[StatisticsLedgerSequence]
      ,[CreatedBy]
      ,[UserName]
      ,[DueDate]
      ,[FiscalPeriod]
      ,[TransactionEntryDate]
      ,[TransactionTypeKey]
      ,[TransactionTypeCategoryCode]
      ,[TransactionTypeCategory]
      ,[TransactionOriginalFlag]
      ,[TransactionDescription]
      ,[TransactionLineOfBusinessCode]
      ,[TransactionBranch]
      ,[AccountingToBaseExchangeRate]
      ,[OriginalToBaseExchangeRate]
      ,[PolicyWrittenExchangeRate]
      ,[ClientPolicyPremiumGrossOriginalCurrency]
      ,[ClientPolicyPremiumNetOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedGrossOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedNetOriginalCurrency]
      ,[InitialPolicyPremiumSEPIGrossOriginalCurrency]
      ,[InitialPolicyPremiumSEPINetOriginalCurrency]
      ,[InitialPolicyPremiumSignedGrossOriginalCurrency]
      ,[InitialPolicyPremiumSignedNetOriginalCurrency]
      ,[InitialPolicyPremiumWrittenGrossOriginalCurrency]
      ,[InitialPolicyPremiumWrittenNetOriginalCurrency]
      ,[SignedDownPremiumEstimatedNetOriginalCurrency]
      ,[SignedDownPremiumWrittenNetOriginalCurrency]
      ,[SystemTransactionAmountOriginalCurrency]
      ,[_CDCDateKey]
      ,[_CDCTime]
--      ,[_DateCreated]
--      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_MergeKey_Limits]
      ,[_MergeKey_Policies]
      ,[_SourceSystemCode]
INTO #PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_or_Proc_GenChD_Diff_24515_1_BLOE
from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_GenChD_24515_1_BLOE]  
Except 
SELECT 
      [LimitKey]
      ,[OriginalCurrencyKey]
      ,[PolicyKey]
      ,[PolicyReference]
      ,[AuditNumber]
      ,[ExternalReferenceIdentifier]
      ,[DoubleEntryItemSequence]
      ,[StatisticsLedgerSequence]
      ,[CreatedBy]
      ,[UserName]
      ,[DueDate]
      ,[FiscalPeriod]
      ,[TransactionEntryDate]
      ,[TransactionTypeKey]
      ,[TransactionTypeCategoryCode]
      ,[TransactionTypeCategory]
      ,[TransactionOriginalFlag]
      ,[TransactionDescription]
      ,[TransactionLineOfBusinessCode]
      ,[TransactionBranch]
      ,[AccountingToBaseExchangeRate]
      ,[OriginalToBaseExchangeRate]
      ,[PolicyWrittenExchangeRate]
      ,[ClientPolicyPremiumGrossOriginalCurrency]
      ,[ClientPolicyPremiumNetOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedGrossOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedNetOriginalCurrency]
      ,[InitialPolicyPremiumSEPIGrossOriginalCurrency]
      ,[InitialPolicyPremiumSEPINetOriginalCurrency]
      ,[InitialPolicyPremiumSignedGrossOriginalCurrency]
      ,[InitialPolicyPremiumSignedNetOriginalCurrency]
      ,[InitialPolicyPremiumWrittenGrossOriginalCurrency]
      ,[InitialPolicyPremiumWrittenNetOriginalCurrency]
      ,[SignedDownPremiumEstimatedNetOriginalCurrency]
      ,[SignedDownPremiumWrittenNetOriginalCurrency]
      ,[SystemTransactionAmountOriginalCurrency]
      ,[_CDCDateKey]
      ,[_CDCTime]
--      ,[_DateCreated]
--      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_MergeKey_Limits]
      ,[_MergeKey_Policies]
      ,[_SourceSystemCode]

from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_PROC_GenChD_24515_1_BLOE]


select _mergeKey , * from #PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_or_Proc_GenChD_Diff_24515_1_BLOE





select
      [LimitKey]
      ,[OriginalCurrencyKey]
      ,[PolicyKey]
      ,[PolicyReference]
      ,[AuditNumber]
      ,[ExternalReferenceIdentifier]
      ,[DoubleEntryItemSequence]
      ,[StatisticsLedgerSequence]
      ,[CreatedBy]
      ,[UserName]
      ,[DueDate]
      ,[FiscalPeriod]
      ,[TransactionEntryDate]
      ,[TransactionTypeKey]
      ,[TransactionTypeCategoryCode]
      ,[TransactionTypeCategory]
      ,[TransactionOriginalFlag]
      ,[TransactionDescription]
      ,[TransactionLineOfBusinessCode]
      ,[TransactionBranch]
      ,[AccountingToBaseExchangeRate]
      ,[OriginalToBaseExchangeRate]
      ,[PolicyWrittenExchangeRate]
      ,[ClientPolicyPremiumGrossOriginalCurrency]
      ,[ClientPolicyPremiumNetOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedGrossOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedNetOriginalCurrency]
      ,[InitialPolicyPremiumSEPIGrossOriginalCurrency]
      ,[InitialPolicyPremiumSEPINetOriginalCurrency]
      ,[InitialPolicyPremiumSignedGrossOriginalCurrency]
      ,[InitialPolicyPremiumSignedNetOriginalCurrency]
      ,[InitialPolicyPremiumWrittenGrossOriginalCurrency]
      ,[InitialPolicyPremiumWrittenNetOriginalCurrency]
      ,[SignedDownPremiumEstimatedNetOriginalCurrency]
      ,[SignedDownPremiumWrittenNetOriginalCurrency]
      ,[SystemTransactionAmountOriginalCurrency]
      ,[_CDCDateKey]
      ,[_CDCTime]
--      ,[_DateCreated]
--      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_MergeKey_Limits]
      ,[_MergeKey_Policies]
      ,[_SourceSystemCode]
INTO #PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_or_Proc_GenChD_Diff_24515_2_BLOE
from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_Proc_GenChD_24515_1_BLOE]  
Except 
SELECT 
      [LimitKey]
      ,[OriginalCurrencyKey]
      ,[PolicyKey]
      ,[PolicyReference]
      ,[AuditNumber]
      ,[ExternalReferenceIdentifier]
      ,[DoubleEntryItemSequence]
      ,[StatisticsLedgerSequence]
      ,[CreatedBy]
      ,[UserName]
      ,[DueDate]
      ,[FiscalPeriod]
      ,[TransactionEntryDate]
      ,[TransactionTypeKey]
      ,[TransactionTypeCategoryCode]
      ,[TransactionTypeCategory]
      ,[TransactionOriginalFlag]
      ,[TransactionDescription]
      ,[TransactionLineOfBusinessCode]
      ,[TransactionBranch]
      ,[AccountingToBaseExchangeRate]
      ,[OriginalToBaseExchangeRate]
      ,[PolicyWrittenExchangeRate]
      ,[ClientPolicyPremiumGrossOriginalCurrency]
      ,[ClientPolicyPremiumNetOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedGrossOriginalCurrency]
      ,[InitialPolicyPremiumEstimatedNetOriginalCurrency]
      ,[InitialPolicyPremiumSEPIGrossOriginalCurrency]
      ,[InitialPolicyPremiumSEPINetOriginalCurrency]
      ,[InitialPolicyPremiumSignedGrossOriginalCurrency]
      ,[InitialPolicyPremiumSignedNetOriginalCurrency]
      ,[InitialPolicyPremiumWrittenGrossOriginalCurrency]
      ,[InitialPolicyPremiumWrittenNetOriginalCurrency]
      ,[SignedDownPremiumEstimatedNetOriginalCurrency]
      ,[SignedDownPremiumWrittenNetOriginalCurrency]
      ,[SystemTransactionAmountOriginalCurrency]
      ,[_CDCDateKey]
      ,[_CDCTime]
--      ,[_DateCreated]
--      ,[_EventExecutionKey]
      ,[_LastAction]
      ,[_MergeKey]
      ,[_MergeKey_Limits]
      ,[_MergeKey_Policies]
      ,[_SourceSystemCode]

from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS_by_SSIS_GenChD_24515_1_BLOE]




--Testy insert, update - delete

Stage --> WORK


select * from WAREHOUSE_Repository.Stage.[PolicyPremiumTransactionsCoverage_GENIUS] (nolock)


select * from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS] (nolock)



--sprawdzenie dzia?ania procedury GENERATED_Changed 

--TEST Bez Zmian

--Uruchomienie Pakietu bez Generowania Danych do WORK - tylko do STAGE

--Stage
select _LastAction,* 
from WAREHOUSE_Repository.Stage.[PolicyPremiumTransactionsCoverage_GENIUS] 
WHERE PolicyReference in (
'LOABGEWJ004',
'AMABK0EV007',
'COB4FWAHZA23',
'COB4FWAHZA24',
'COB4FWMGJA23',
'COB4FWMGJA24'
)

select count(*) from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS] (nolock)


Exec WAREHOUSE_Repository.[dbo].[GenChangedData_PolicyPremiumTransactionsCoverage] 2452101 , 1
/*
Commands completed successfully.
Completion time: 2024-05-21T08:47:06.2617872+02:00
*/

select _LastAction,* 
from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS] 
WHERE PolicyReference in (
'LOABGEWJ004',
'AMABK0EV007',
'COB4FWAHZA23',
'COB4FWAHZA24',
'COB4FWMGJA23',
'COB4FWMGJA24'
) order by PolicyPremiumTransactionsCoverageKey



select _LastAction,* 
from WAREHOUSE_Repository.dbo.PolicyPremiumTransactionsCoverage
WHERE PolicyReference in (
'LOABGEWJ004',
'AMABK0EV007',
'COB4FWAHZA23',
'COB4FWAHZA24',
'COB4FWMGJA23',
'COB4FWMGJA24'
)
order by PolicyPremiumTransactionsCoverageKey



select * from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS] (nolock)


--Insert new Coverage related to Policy LOABGEWJ004

--Stage
insert into WAREHOUSE_Repository.Stage.[PolicyPremiumTransactionsCoverage_GENIUS] (PolicyReference,AuditNumber,ExternalReferenceIdentifier,CreatedBy,UserName,DueDate,LimitKey,PolicyKey,OriginalCurrencyKey,TransactionTypeKey,TransactionTypeCategoryCode,TransactionTypeCategory,TransactionEntryDate,TransactionOriginalFlag,TransactionDescription,TransactionLineOfBusinessCode,TransactionBranch,DoubleEntryItemSequence,StatisticsLedgerSequence,FiscalPeriod,OriginalToBaseExchangeRate,AccountingToBaseExchangeRate,PolicyWrittenExchangeRate,ClientPolicyPremiumGrossOriginalCurrency,ClientPolicyPremiumNetOriginalCurrency,InitialPolicyPremiumEstimatedGrossOriginalCurrency,InitialPolicyPremiumEstimatedNetOriginalCurrency,InitialPolicyPremiumSEPIGrossOriginalCurrency,InitialPolicyPremiumSEPINetOriginalCurrency,InitialPolicyPremiumSignedGrossOriginalCurrency,InitialPolicyPremiumSignedNetOriginalCurrency,InitialPolicyPremiumWrittenGrossOriginalCurrency,InitialPolicyPremiumWrittenNetOriginalCurrency,SignedDownPremiumEstimatedNetOriginalCurrency,SignedDownPremiumWrittenNetOriginalCurrency,SystemTransactionAmountOriginalCurrency,_CDCDateKey,_CDCTime,_EventExecutionKey,_LastAction,_MergeKey,_MergeKey_Limits,_MergeKey_Policies,_SourceSystemCode)
select top 1 PolicyReference,AuditNumber,ExternalReferenceIdentifier,CreatedBy,UserName,DueDate,LimitKey,PolicyKey,OriginalCurrencyKey,TransactionTypeKey,TransactionTypeCategoryCode,TransactionTypeCategory,TransactionEntryDate,TransactionOriginalFlag,TransactionDescription,TransactionLineOfBusinessCode,TransactionBranch,DoubleEntryItemSequence,StatisticsLedgerSequence,FiscalPeriod,OriginalToBaseExchangeRate,AccountingToBaseExchangeRate,PolicyWrittenExchangeRate,ClientPolicyPremiumGrossOriginalCurrency,ClientPolicyPremiumNetOriginalCurrency,InitialPolicyPremiumEstimatedGrossOriginalCurrency,InitialPolicyPremiumEstimatedNetOriginalCurrency,InitialPolicyPremiumSEPIGrossOriginalCurrency,InitialPolicyPremiumSEPINetOriginalCurrency,InitialPolicyPremiumSignedGrossOriginalCurrency,InitialPolicyPremiumSignedNetOriginalCurrency,InitialPolicyPremiumWrittenGrossOriginalCurrency,InitialPolicyPremiumWrittenNetOriginalCurrency,SignedDownPremiumEstimatedNetOriginalCurrency,SignedDownPremiumWrittenNetOriginalCurrency,-888.000,'2024-05-21','10:00:00',2452111,_LastAction,'[GENIUS][ABG1MP][004][03][001][001][Estimated][ADJUSTMENT][IUK][GROSS][USD][11930888]',_MergeKey_Limits,_MergeKey_Policies,_SourceSystemCode
from WAREHOUSE_Repository.Stage.[PolicyPremiumTransactionsCoverage_GENIUS] 
WHERE PolicyReference in (
'LOABGEWJ004'
) and AuditNumber =142414788 and SystemTransactionAmountOriginalCurrency = -600.0000



insert into WAREHOUSE_Repository.Stage.[PolicyPremiumTransactionsCoverage_GENIUS] (PolicyReference,AuditNumber,ExternalReferenceIdentifier,CreatedBy,UserName,DueDate,LimitKey,PolicyKey,OriginalCurrencyKey,TransactionTypeKey,TransactionTypeCategoryCode,TransactionTypeCategory,TransactionEntryDate,TransactionOriginalFlag,TransactionDescription,TransactionLineOfBusinessCode,TransactionBranch,DoubleEntryItemSequence,StatisticsLedgerSequence,FiscalPeriod,OriginalToBaseExchangeRate,AccountingToBaseExchangeRate,PolicyWrittenExchangeRate,ClientPolicyPremiumGrossOriginalCurrency,ClientPolicyPremiumNetOriginalCurrency,InitialPolicyPremiumEstimatedGrossOriginalCurrency,InitialPolicyPremiumEstimatedNetOriginalCurrency,InitialPolicyPremiumSEPIGrossOriginalCurrency,InitialPolicyPremiumSEPINetOriginalCurrency,InitialPolicyPremiumSignedGrossOriginalCurrency,InitialPolicyPremiumSignedNetOriginalCurrency,InitialPolicyPremiumWrittenGrossOriginalCurrency,InitialPolicyPremiumWrittenNetOriginalCurrency,SignedDownPremiumEstimatedNetOriginalCurrency,SignedDownPremiumWrittenNetOriginalCurrency,SystemTransactionAmountOriginalCurrency,_CDCDateKey,_CDCTime,_EventExecutionKey,_LastAction,_MergeKey,_MergeKey_Limits,_MergeKey_Policies,_SourceSystemCode)
select  PolicyReference,AuditNumber,ExternalReferenceIdentifier,CreatedBy,UserName,DueDate,LimitKey,PolicyKey,OriginalCurrencyKey,TransactionTypeKey,TransactionTypeCategoryCode,TransactionTypeCategory,TransactionEntryDate,TransactionOriginalFlag,TransactionDescription,TransactionLineOfBusinessCode,TransactionBranch,DoubleEntryItemSequence,StatisticsLedgerSequence,FiscalPeriod,OriginalToBaseExchangeRate,AccountingToBaseExchangeRate,PolicyWrittenExchangeRate,ClientPolicyPremiumGrossOriginalCurrency,ClientPolicyPremiumNetOriginalCurrency,InitialPolicyPremiumEstimatedGrossOriginalCurrency,InitialPolicyPremiumEstimatedNetOriginalCurrency,InitialPolicyPremiumSEPIGrossOriginalCurrency,InitialPolicyPremiumSEPINetOriginalCurrency,InitialPolicyPremiumSignedGrossOriginalCurrency,InitialPolicyPremiumSignedNetOriginalCurrency,InitialPolicyPremiumWrittenGrossOriginalCurrency,InitialPolicyPremiumWrittenNetOriginalCurrency,SignedDownPremiumEstimatedNetOriginalCurrency,SignedDownPremiumWrittenNetOriginalCurrency,888.000,'2024-05-21','10:00:00',2452111,_LastAction,'[GENIUS][ABG1MP][004][03][001][001][Estimated][ADJUSTMENT][IUK][GROSS][USD][11930999]',_MergeKey_Limits,_MergeKey_Policies,_SourceSystemCode
from WAREHOUSE_Repository.Stage.[PolicyPremiumTransactionsCoverage_GENIUS] 
WHERE PolicyReference in (
'LOABGEWJ004'
) and AuditNumber =142414794 and SystemTransactionAmountOriginalCurrency = 600.0000


--Truncate Table WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS] 

select SystemTransactionAmountOriginalCurrency,_CDCDateKey,_CDCTime,_EventExecutionKey,_LastAction,_MergeKey,* 
from WAREHOUSE_Repository.STAGE.[PolicyPremiumTransactionsCoverage_GENIUS] s
WHERE PolicyReference in ('LOABGEWJ004') order by s._CDCDateKey desc,s._CDCTime desc


Exec WAREHOUSE_Repository.[dbo].[GenChangedData_PolicyPremiumTransactionsCoverage] 2452111 , 1
/*
Commands completed successfully.
Completion time: 2024-05-21T10:29:01.9465674+02:00
*/



select SystemTransactionAmountOriginalCurrency,_CDCDateKey,_CDCTime,_EventExecutionKey,_LastAction,_MergeKey,* 
from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS] 
WHERE PolicyReference in ('LOABGEWJ004') order by PolicyPremiumTransactionsCoverageKey



select SystemTransactionAmountOriginalCurrency,_CDCDateKey,_CDCTime,_EventExecutionKey,_LastAction,_MergeKey,SystemTransactionAmountOriginalCurrency,* 
from WAREHOUSE_Repository.dbo.PolicyPremiumTransactionsCoverage
WHERE PolicyReference in ('LOABGEWJ004')
order by PolicyPremiumTransactionsCoverageKey







--Update Policy Reference='ASACVW8L001'





--Stage

select SystemTransactionAmountOriginalCurrency,_CDCDateKey,_CDCTime,_EventExecutionKey,_LastAction,_MergeKey,
PolicyReference,AuditNumber,ExternalReferenceIdentifier,CreatedBy,UserName,DueDate,LimitKey,PolicyKey,OriginalCurrencyKey,TransactionTypeKey,TransactionTypeCategoryCode,TransactionTypeCategory,TransactionEntryDate,TransactionOriginalFlag,TransactionDescription,TransactionLineOfBusinessCode,TransactionBranch,DoubleEntryItemSequence,StatisticsLedgerSequence,FiscalPeriod,OriginalToBaseExchangeRate,AccountingToBaseExchangeRate,PolicyWrittenExchangeRate,ClientPolicyPremiumGrossOriginalCurrency,ClientPolicyPremiumNetOriginalCurrency,InitialPolicyPremiumEstimatedGrossOriginalCurrency,InitialPolicyPremiumEstimatedNetOriginalCurrency,InitialPolicyPremiumSEPIGrossOriginalCurrency,InitialPolicyPremiumSEPINetOriginalCurrency,InitialPolicyPremiumSignedGrossOriginalCurrency,InitialPolicyPremiumSignedNetOriginalCurrency,InitialPolicyPremiumWrittenGrossOriginalCurrency,InitialPolicyPremiumWrittenNetOriginalCurrency,SignedDownPremiumEstimatedNetOriginalCurrency,SignedDownPremiumWrittenNetOriginalCurrency,SystemTransactionAmountOriginalCurrency,'2024-05-21','10:30:00',2452111,_LastAction,_MergeKey,_MergeKey_Limits,_MergeKey_Policies,_SourceSystemCode
from WAREHOUSE_Repository.Stage.[PolicyPremiumTransactionsCoverage_GENIUS] 
WHERE PolicyReference in (
'ASACVW8L001'
) 


update s set
	ClientPolicyPremiumGrossOriginalCurrency			  =55555,
	ClientPolicyPremiumNetOriginalCurrency				  =55555,
	InitialPolicyPremiumEstimatedGrossOriginalCurrency	  =55555,
	InitialPolicyPremiumEstimatedNetOriginalCurrency	  =55555,
	InitialPolicyPremiumSEPIGrossOriginalCurrency		  =55555,
	InitialPolicyPremiumSEPINetOriginalCurrency			  =55555,
	InitialPolicyPremiumSignedGrossOriginalCurrency		  =55555,
	InitialPolicyPremiumSignedNetOriginalCurrency		  =55555,
	InitialPolicyPremiumWrittenGrossOriginalCurrency	  =55555,
	InitialPolicyPremiumWrittenNetOriginalCurrency		  =55555,
	SystemTransactionAmountOriginalCurrency				  =55555,
	_CDCDateKey											  ='2024-05-21',
	_CDCTime											  ='10:33:00',
	_EventExecutionKey									  =2452151,
	_LastAction											  ='U'
from WAREHOUSE_Repository.Stage.[PolicyPremiumTransactionsCoverage_GENIUS] s
WHERE PolicyReference in (
'ASACVW8L001'
) 


select SystemTransactionAmountOriginalCurrency,_CDCDateKey,_CDCTime,_EventExecutionKey,_LastAction,_MergeKey,
PolicyReference,AuditNumber,ExternalReferenceIdentifier,CreatedBy,UserName,DueDate,LimitKey,PolicyKey,OriginalCurrencyKey,TransactionTypeKey,TransactionTypeCategoryCode,TransactionTypeCategory,TransactionEntryDate,TransactionOriginalFlag,TransactionDescription,TransactionLineOfBusinessCode,TransactionBranch,DoubleEntryItemSequence,StatisticsLedgerSequence,FiscalPeriod,OriginalToBaseExchangeRate,AccountingToBaseExchangeRate,PolicyWrittenExchangeRate,ClientPolicyPremiumGrossOriginalCurrency,ClientPolicyPremiumNetOriginalCurrency,InitialPolicyPremiumEstimatedGrossOriginalCurrency,InitialPolicyPremiumEstimatedNetOriginalCurrency,InitialPolicyPremiumSEPIGrossOriginalCurrency,InitialPolicyPremiumSEPINetOriginalCurrency,InitialPolicyPremiumSignedGrossOriginalCurrency,InitialPolicyPremiumSignedNetOriginalCurrency,InitialPolicyPremiumWrittenGrossOriginalCurrency,InitialPolicyPremiumWrittenNetOriginalCurrency,SignedDownPremiumEstimatedNetOriginalCurrency,SignedDownPremiumWrittenNetOriginalCurrency,SystemTransactionAmountOriginalCurrency,'2024-05-21','10:30:00',2452111,_LastAction,_MergeKey,_MergeKey_Limits,_MergeKey_Policies,_SourceSystemCode
from WAREHOUSE_Repository.Stage.[PolicyPremiumTransactionsCoverage_GENIUS] 
WHERE PolicyReference in (
'ASACVW8L001'
) 


--Truncate Table WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS] 

Exec WAREHOUSE_Repository.[dbo].[GenChangedData_PolicyPremiumTransactionsCoverage] 2452151 , 1



/*

Commands completed successfully.

Completion time: 2024-05-21T12:32:00.3606925+02:00

*/



select SystemTransactionAmountOriginalCurrency,_CDCDateKey,_CDCTime,_EventExecutionKey,_LastAction,_MergeKey,* 
from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS] 
WHERE PolicyReference in ('ASACVW8L001') order by PolicyPremiumTransactionsCoverageKey



select SystemTransactionAmountOriginalCurrency,_CDCDateKey,_CDCTime,_EventExecutionKey,_LastAction,_MergeKey,SystemTransactionAmountOriginalCurrency,* 
from WAREHOUSE_Repository.dbo.PolicyPremiumTransactionsCoverage
WHERE PolicyReference in ('ASACVW8L001')
order by PolicyPremiumTransactionsCoverageKey








--DELETE Policy Reference ='COACVW54002' 





--Stage

select SystemTransactionAmountOriginalCurrency,_CDCDateKey,_CDCTime,_EventExecutionKey,_LastAction,_MergeKey,
PolicyReference,AuditNumber,ExternalReferenceIdentifier,CreatedBy,UserName,DueDate,LimitKey,PolicyKey,OriginalCurrencyKey,TransactionTypeKey,TransactionTypeCategoryCode,TransactionTypeCategory,TransactionEntryDate,TransactionOriginalFlag,TransactionDescription,TransactionLineOfBusinessCode,TransactionBranch,DoubleEntryItemSequence,StatisticsLedgerSequence,FiscalPeriod,OriginalToBaseExchangeRate,AccountingToBaseExchangeRate,PolicyWrittenExchangeRate,ClientPolicyPremiumGrossOriginalCurrency,ClientPolicyPremiumNetOriginalCurrency,InitialPolicyPremiumEstimatedGrossOriginalCurrency,InitialPolicyPremiumEstimatedNetOriginalCurrency,InitialPolicyPremiumSEPIGrossOriginalCurrency,InitialPolicyPremiumSEPINetOriginalCurrency,InitialPolicyPremiumSignedGrossOriginalCurrency,InitialPolicyPremiumSignedNetOriginalCurrency,InitialPolicyPremiumWrittenGrossOriginalCurrency,InitialPolicyPremiumWrittenNetOriginalCurrency,SignedDownPremiumEstimatedNetOriginalCurrency,SignedDownPremiumWrittenNetOriginalCurrency,SystemTransactionAmountOriginalCurrency,'2024-05-21','10:30:00',2452111,_LastAction,_MergeKey,_MergeKey_Limits,_MergeKey_Policies,_SourceSystemCode
from WAREHOUSE_Repository.Stage.[PolicyPremiumTransactionsCoverage_GENIUS] 
WHERE PolicyReference in ('COACVW54002') 

select SystemTransactionAmountOriginalCurrency,_CDCDateKey,_CDCTime,_EventExecutionKey,_LastAction,_MergeKey,* 
from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS] 
WHERE PolicyReference in ('COACVW54002') order by PolicyPremiumTransactionsCoverageKey


select SystemTransactionAmountOriginalCurrency,_CDCDateKey,_CDCTime,_EventExecutionKey,_LastAction,_MergeKey,SystemTransactionAmountOriginalCurrency,* 
from WAREHOUSE_Repository.dbo.PolicyPremiumTransactionsCoverage
WHERE PolicyReference in ('COACVW54002')
order by PolicyPremiumTransactionsCoverageKey


--deleteing 
Update s set _LastAction='D' from WAREHOUSE_Repository.Stage.[PolicyPremiumTransactionsCoverage_GENIUS] s where PolicyReference in ('COACVW54002')




Exec WAREHOUSE_Repository.[dbo].[GenChangedData_PolicyPremiumTransactionsCoverage] 2452161 , 1



/*
Commands completed successfully.
Completion time: 2024-05-21T14:03:29.3875558+02:00

*/



select SystemTransactionAmountOriginalCurrency,_CDCDateKey,_CDCTime,_EventExecutionKey,_LastAction,_MergeKey,
PolicyReference,AuditNumber,ExternalReferenceIdentifier,CreatedBy,UserName,DueDate,LimitKey,PolicyKey,OriginalCurrencyKey,TransactionTypeKey,TransactionTypeCategoryCode,TransactionTypeCategory,TransactionEntryDate,TransactionOriginalFlag,TransactionDescription,TransactionLineOfBusinessCode,TransactionBranch,DoubleEntryItemSequence,StatisticsLedgerSequence,FiscalPeriod,OriginalToBaseExchangeRate,AccountingToBaseExchangeRate,PolicyWrittenExchangeRate,ClientPolicyPremiumGrossOriginalCurrency,ClientPolicyPremiumNetOriginalCurrency,InitialPolicyPremiumEstimatedGrossOriginalCurrency,InitialPolicyPremiumEstimatedNetOriginalCurrency,InitialPolicyPremiumSEPIGrossOriginalCurrency,InitialPolicyPremiumSEPINetOriginalCurrency,InitialPolicyPremiumSignedGrossOriginalCurrency,InitialPolicyPremiumSignedNetOriginalCurrency,InitialPolicyPremiumWrittenGrossOriginalCurrency,InitialPolicyPremiumWrittenNetOriginalCurrency,SignedDownPremiumEstimatedNetOriginalCurrency,SignedDownPremiumWrittenNetOriginalCurrency,SystemTransactionAmountOriginalCurrency,'2024-05-21','10:30:00',2452111,_LastAction,_MergeKey,_MergeKey_Limits,_MergeKey_Policies,_SourceSystemCode
from WAREHOUSE_Repository.Stage.[PolicyPremiumTransactionsCoverage_GENIUS] 
WHERE PolicyReference in ('COACVW54002') 

select SystemTransactionAmountOriginalCurrency,_CDCDateKey,_CDCTime,_EventExecutionKey,_LastAction,_MergeKey,* 
from WAREHOUSE_Repository.WORK.[PolicyPremiumTransactionsCoverage_GENIUS] 
WHERE PolicyReference in ('COACVW54002') order by PolicyPremiumTransactionsCoverageKey


select SystemTransactionAmountOriginalCurrency,_CDCDateKey,_CDCTime,_EventExecutionKey,_LastAction,_MergeKey,SystemTransactionAmountOriginalCurrency,* 
from WAREHOUSE_Repository.dbo.PolicyPremiumTransactionsCoverage
WHERE PolicyReference in ('COACVW54002')
order by PolicyPremiumTransactionsCoverageKey





SELECT 
	TaskCode
	, DATEDIFF(MINUTE,wq.[ExecutionStartDate],wq.[ExecutionEndDate]) task_time_min
	, SUBSTRING(CAST(CONVERT(TIME,DATEADD(SECOND,DATEDIFF(SECOND,wq.[ExecutionStartDate],wq.[ExecutionEndDate]) ,1)) AS VARCHAR),1,8) Task_ExecutionTime
	, wq.ExecutionStartDate
	, wq.ExecutionEndDate
	,TaskXML.value('(/ParameterSet/Parameter/ParameterName)[11]','VARCHAR(100)') As ParameterName
	,TaskXML.value('(/ParameterSet/Parameter/ParameterValue)[11]','VARCHAR(100)') As BLOEMode
	,*
FROM [ETL_Control].[dbo].[WorkQueueLog] wq (nolock)
WHERE TaskCode='FACT_GENIUS_PolicyPremiumTransactionsCoverage_DWH_DP'
ORDER BY EventExecutionKey desc
