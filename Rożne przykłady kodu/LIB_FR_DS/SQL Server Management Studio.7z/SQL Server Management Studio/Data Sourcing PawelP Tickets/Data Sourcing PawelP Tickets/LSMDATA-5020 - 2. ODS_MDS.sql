USE ODS_MDS

DROP TABLE IF EXISTS [dbo].[SIILMALClassMapping]
CREATE TABLE [dbo].[SIILMALClassMapping](
	[VersionName] [NVARCHAR](50) NULL
	,[VersionNumber] [INT] NULL
	,[Version_ID] [INT] NULL
	,[VersionFlag] [NVARCHAR](50) NULL
	,[Name] [NVARCHAR](250) NULL
	,[Code] [NVARCHAR](250) NOT NULL
	,[ChangeTrackingMask] INT NOT NULL
    ,[DataClass] [NVARCHAR](255) NULL
    ,[ReservingClass_Code] [NVARCHAR](250) NULL
    ,[ReservingClass_Name] [NVARCHAR](250) NULL
    ,[ReservingClass_ID] INT NULL
    ,[CMTClass_Code] [NVARCHAR](250) NULL
    ,[CMTClass_Name] [NVARCHAR](250) NULL
    ,[CMTClass_ID] INT NULL
    ,[EnterDateTime]  [DATETIME2](3) NOT NULL
    ,[EnterUserName] [NVARCHAR](100) NULL
	,[EnterVersionNumber] [INT] NULL
	,[LastChgDateTime] [DATETIME2](3) NULL
	,[LastChgUserName] [NVARCHAR](100) NULL
	,[LastChgVersionNumber] [INT] NULL
	,[ValidationStatus] [NVARCHAR](250) NULL
	,[_DateCreated] [DATETIME2](7) NULL	
	,[_EventExecutionKey] [INT] NULL	
	,[_LastAction] [NCHAR](1) NULL

 CONSTRAINT [PK_SIILMALClassMapping] PRIMARY KEY CLUSTERED 
(
	[Code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

---SIILMIEClassMapping
---------------------------------------------------------
DROP TABLE IF EXISTS [dbo].[SIILMIEClassMapping]
CREATE TABLE [dbo].[SIILMIEClassMapping](
	[VersionName] [NVARCHAR](50) NULL
	,[VersionNumber] [INT] NULL
	,[Version_ID] [INT] NULL
	,[VersionFlag] [NVARCHAR](50) NULL
	,[Name] [NVARCHAR](250) NULL
	,[Code] [NVARCHAR](250) NOT NULL
	,[ChangeTrackingMask] INT NOT NULL
    ,[S2ReserveClass] [NVARCHAR](100) NULL
    ,[CMTClass_Code] [NVARCHAR](250) NULL
    ,[CMTClass_Name] [NVARCHAR](250) NULL
    ,[CMTClass_ID] INT NULL
    ,[ReservingClass_Code] [NVARCHAR](250) NULL
    ,[ReservingClass_Name] [NVARCHAR](250) NULL
    ,[ReservingClass_ID] INT NULL
	,[EnterDateTime]  [DATETIME2](3) NOT NULL
    ,[EnterUserName] [NVARCHAR](100) NULL
	,[EnterVersionNumber] [INT] NULL
	,[LastChgDateTime] [DATETIME2](3) NULL
	,[LastChgUserName] [NVARCHAR](100) NULL
	,[LastChgVersionNumber] [INT] NULL
	,[ValidationStatus] [NVARCHAR](250) NULL
	,[_DateCreated] [DATETIME2](7) NULL	
	,[_EventExecutionKey] [INT] NULL	
	,[_LastAction] [NCHAR](1) NULL
 CONSTRAINT [PK_SIILMIEClassMapping] PRIMARY KEY CLUSTERED 
(
	[Code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


CREATE VIEW [dbo].[Map_SIILMALClassMapping] AS
/**
***************************************************************************
**
** File				: Map_SIILMALClassMappings.sql
** Version			: $Revision: 24.07.00 $
** Description		: Uses SIILMALClassMapping data and conforms to Warehouse data type standards
** Called by		: 
**
***************************************************************************
** Change History
** Revision:         Date:			Author:					Description:
** ----------        ----------		----------------------	---------------
** Version 24.07.00   2024/07/05	Pawel Parasyn			Initial Version - LSMDATA-5020
***************************************************************************
**/ 

	SELECT 
		y.Code AS SIILMAL_Code
	,   COALESCE(y.[DataClass] , N'<<Unknown>>') AS [SIILMAL_DataClass] 
	,	COALESCE(y.[ReservingClass_Code], N'<<Unknown>>') AS [SIILMAL_ReservingClass_Code]
	,	COALESCE(y.[ReservingClass_Name], N'<<Unknown>>') AS [SIILMAL_ReservingClass_Name]
	,	COALESCE(y.[CMTClass_Code], N'<<Unknown>>') AS [SIILMAL_CMTClass_Code]
	,	COALESCE(y.[CMTClass_Name], N'<<Unknown>>') AS [SIILMAL_CMTClass_Name]
	,	y.VersionName
	,	y.VersionNumber
	,	y._DateCreated
	,	y._EventExecutionKey
	,	y._LastAction
	,	y._SourceSystemCode
	FROM 
	(
		SELECT 	
			CAST(smal.[Code] AS NVARCHAR(250)) AS [Code]
		,   CAST(smal.[DataClass] AS NVARCHAR(250)) AS [DataClass]
		,   CAST(smal.[ReservingClass_Code] AS NVARCHAR(250)) AS [ReservingClass_Code]
		,   CAST(smal.[ReservingClass_Name] AS NVARCHAR(250)) AS [ReservingClass_Name]
		,   CAST(smal.[CMTClass_Code] AS NVARCHAR(250)) AS [CMTClass_Code]
		,   CAST(smal.[CMTClass_Name] AS NVARCHAR(250)) AS [CMTClass_Name]
		,	smal.VersionName
		,	smal.VersionNumber
		,	smal._DateCreated
		,	smal._EventExecutionKey
		,	smal._LastAction
		,	CAST(N'MDS' AS NVARCHAR(50)) AS _SourceSystemCode
		FROM 
			dbo.SIILMALClassMapping smal
	) y

;


CREATE VIEW [dbo].[Map_SIILMIEClassMapping] AS
/**
***************************************************************************
**
** File				: Map_SIILMIEClassMappings.sql
** Version			: $Revision: 24.07.00 $
** Description		: Uses SIILMIEClassMapping data and conforms to Warehouse data type standards
** Called by		: 
**
***************************************************************************
** Change History
** Revision:         Date:			Author:					Description:
** ----------        ----------		----------------------	---------------
** Version 24.07.00   2024/07/05	Pawel Parasyn			Initial Version - LSMDATA-5020
***************************************************************************
**/ 

	SELECT 
		y.Code AS SIILMIE_Code
	,   COALESCE(y.[S2ReserveClass] , N'<<Unknown>>') AS [SIILMIE_S2ReserveClass] 
	,	COALESCE(y.[ReservingClass_Code], N'<<Unknown>>') AS [SIILMIE_ReservingClass_Code]
	,	COALESCE(y.[ReservingClass_Name], N'<<Unknown>>') AS [SIILMIE_ReservingClass_Name]
	,	COALESCE(y.[CMTClass_Code], N'<<Unknown>>') AS [SIILMIE_CMTClass_Code]
	,	COALESCE(y.[CMTClass_Name], N'<<Unknown>>') AS [SIILMIE_CMTClass_Name]
	,	y.VersionName
	,	y.VersionNumber
	,	y._DateCreated
	,	y._EventExecutionKey
	,	y._LastAction
	,	y._SourceSystemCode
	FROM 
	(
		SELECT 	
			CAST(smie.[Code] AS NVARCHAR(250)) AS [Code]
		,   CAST(smie.[S2ReserveClass] AS NVARCHAR(100)) AS [S2ReserveClass]
		,   CAST(smie.[ReservingClass_Code] AS NVARCHAR(250)) AS [ReservingClass_Code]
		,   CAST(smie.[ReservingClass_Name] AS NVARCHAR(250)) AS [ReservingClass_Name]
		,   CAST(smie.[CMTClass_Code] AS NVARCHAR(250)) AS [CMTClass_Code]
		,   CAST(smie.[CMTClass_Name] AS NVARCHAR(250)) AS [CMTClass_Name]
		,	smie.VersionName
		,	smie.VersionNumber
		,	smie._DateCreated
		,	smie._EventExecutionKey
		,	smie._LastAction
		,	CAST(N'MDS' AS NVARCHAR(50)) AS _SourceSystemCode
		FROM 
			dbo.SIILMIEClassMapping smie
	) y




ALTER VIEW [dbo].[Warehouse_SIILMALClassMapping] AS
/**
***************************************************************************
**
** File				: Warehouse_SIILMALClassMapping.sql
** Version			: $Revision: 24.07.00 $
** Description		: Translates SIILMALClassMapping MDS map view into Warehouse view
** Called by		: 
**
***************************************************************************
** Change History
** Revision:         Date:			Author:					Description:
** ----------        ----------		----------------------	---------------
** Version 24.07.00   2024/07/05	Pawel Parasyn			Initial Version - LSMDATA-5020
***************************************************************************
**/ 


SELECT 

		x.[SIILMAL_Code]
	,	x.[SIILMAL_DataClass]
	,	x.[SIILMAL_ReservingClass_Code]
	,	x.[SIILMAL_ReservingClass_Name]
	,	x.[SIILMAL_CMTClass_Code]
	,	x.[SIILMAL_CMTClass_Name]
	,	x.[VersionName]
	,	x.VersionNumber
	,	x._DateCreated
	,	x._EventExecutionKey
	,	x._LastAction
	,	x._MergeKey
	,	x._SourceSystemCode

FROM
(
	SELECT 		
		 smal.[SIILMAL_Code]
		,smal.[SIILMAL_DataClass]
		,smal.[SIILMAL_ReservingClass_Code]
		,smal.[SIILMAL_ReservingClass_Name]
		,smal.[SIILMAL_CMTClass_Code]
		,smal.[SIILMAL_CMTClass_Name]
		,smal.[VersionName]
		,smal.[VersionNumber]
		,smal.[_DateCreated]
		,smal.[_EventExecutionKey]
		,smal.[_LastAction]
		,UPPER(CAST(N'[MDS][' + smal.[SIILMAL_Code] + N']'AS NVARCHAR(255)))	AS [_MergeKey]
		,smal.[_SourceSystemCode]
	FROM 
		Map_SIILMALClassMapping smal

) x



ALTER VIEW [dbo].[Warehouse_SIILMIEClassMapping] AS
/**
***************************************************************************
**
** File				: Warehouse_SIILMIEClassMapping.sql
** Version			: $Revision: 24.07.00 $
** Description		: Translates SIILMIEClassMapping MDS map view into Warehouse view
** Called by		: 
**
***************************************************************************
** Change History
** Revision:         Date:			Author:					Description:
** ----------        ----------		----------------------	---------------
** Version 24.07.00   2024/07/05	Pawel Parasyn			Initial Version - LSMDATA-5020
***************************************************************************
**/ 


SELECT 
		x.[SIILMIE_Code]
	,	x.[SIILMIE_S2ReserveClass]
	,	x.[SIILMIE_ReservingClass_Code]
	,	x.[SIILMIE_ReservingClass_Name]
	,	x.[SIILMIE_CMTClass_Code]
	,	x.[SIILMIE_CMTClass_Name]
	,	x.[VersionName]
	,	x.VersionNumber
	,	x._DateCreated
	,	x._EventExecutionKey
	,	x._LastAction
	,	x._MergeKey
	,	x._SourceSystemCode

FROM
(
	SELECT 		
		 smie.[SIILMIE_Code]
		,smie.[SIILMIE_S2ReserveClass]
		,smie.[SIILMIE_ReservingClass_Code]
		,smie.[SIILMIE_ReservingClass_Name]
		,smie.[SIILMIE_CMTClass_Code]
		,smie.[SIILMIE_CMTClass_Name]
		,smie.[VersionName]
		,smie.[VersionNumber]
		,smie.[_DateCreated]
		,smie.[_EventExecutionKey]
		,smie.[_LastAction]
		,UPPER(CAST(N'[MDS][' + smie.[SIILMIE_Code] + N']'AS NVARCHAR(255)))	AS [_MergeKey]
		,smie.[_SourceSystemCode]
	FROM 
		Map_SIILMIEClassMapping smie

) x



CREATE VIEW [dbo].[Warehouse_SIILMALClassMapping_Delta]
AS
/**
***************************************************************************
**
** File				: Warehouse_SIILMALClassMapping_Delta.sql
** Version			: $Revision: 24.07.00 $
** Description		: Translates SIILMALClassMapping MDS map view into Warehouse view
** Called by		: 
**
***************************************************************************
** Change History
** Revision:         Date:			Author:					Description:
** ----------        ----------		----------------------	---------------
** Version 24.07.00   2024/07/05	Pawel Parasyn			Initial Version - LSMDATA-5020
***************************************************************************
**/ 


SELECT 
		x.[SIILMAL_Code]
	,	x.[SIILMAL_DataClass]
	,	x.[SIILMAL_ReservingClass_Code]
	,	x.[SIILMAL_ReservingClass_Name]
	,	x.[SIILMAL_CMTClass_Code]
	,	x.[SIILMAL_CMTClass_Name]
	,	x.VersionNumber
	,	x._DateCreated
	,	x._EventExecutionKey
	,	x._LastAction
	,	x._MergeKey
	,	x._SourceSystemCode
FROM dbo.Warehouse_SIILMALClassMapping x
	INNER JOIN
		dbo.EventExecutionKeysToLoad() ektl 
	ON
		ektl._EventExecutionKey = x._EventExecutionKey


CREATE VIEW [dbo].[Warehouse_SIILMIEClassMapping_Delta]
AS
/**
***************************************************************************
**
** File				: Warehouse_SIILMIEClassMapping_Delta.sql
** Version			: $Revision: 24.07.00 $
** Description		: Translates SIILMIEClassMapping MDS map view into Warehouse view
** Called by		: 
**
***************************************************************************
** Change History
** Revision:         Date:			Author:					Description:
** ----------        ----------		----------------------	---------------
** Version 24.07.00   2024/07/15	Pawel Parasyn			Initial Version - LSMDATA-5020
***************************************************************************
**/ 


SELECT 
		x.[SIILMIE_Code]
	,	x.[SIILMIE_S2ReserveClass]
	,	x.[SIILMIE_ReservingClass_Code]
	,	x.[SIILMIE_ReservingClass_Name]
	,	x.[SIILMIE_CMTClass_Code]
	,	x.[SIILMIE_CMTClass_Name]
	,	x.VersionNumber
	,	x._DateCreated
	,	x._EventExecutionKey
	,	x._LastAction
	,	x._MergeKey
	,	x._SourceSystemCode
FROM dbo.Warehouse_SIILMIEClassMapping x
	INNER JOIN
		dbo.EventExecutionKeysToLoad() ektl 
	ON
		ektl._EventExecutionKey = x._EventExecutionKey



-- Pakiet FUll Compare

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORK].[SIILMALClassMapping]') AND type in (N'U'))
DROP TABLE [WORK].[SIILMALClassMapping]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [WORK].[SIILMALClassMapping](
	[VersionName] [NVARCHAR](50) COLLATE Latin1_General_CI_AS NULL
	,[VersionNumber] [INT] NULL
	,[Version_ID] [INT] NULL
	,[VersionFlag] [NVARCHAR](50) COLLATE Latin1_General_CI_AS NULL
	,[Name] [NVARCHAR](250) COLLATE Latin1_General_CI_AS NULL
	,[Code] [NVARCHAR](250) COLLATE Latin1_General_CI_AS NOT NULL
	,[ChangeTrackingMask] INT NULL
    ,[DataClass] [NVARCHAR](255) COLLATE Latin1_General_CI_AS NULL
    ,[ReservingClass_Code] [NVARCHAR](250) COLLATE Latin1_General_CI_AS NULL
    ,[ReservingClass_Name] [NVARCHAR](250) COLLATE Latin1_General_CI_AS NULL
    ,[ReservingClass_ID] INT NULL
    ,[CMTClass_Code] [NVARCHAR](250) COLLATE Latin1_General_CI_AS NULL
    ,[CMTClass_Name] [NVARCHAR](250) COLLATE Latin1_General_CI_AS NULL
    ,[CMTClass_ID] INT NULL
    ,[EnterDateTime]  [DATETIME2](3) NOT NULL
    ,[EnterUserName] [NVARCHAR](100) COLLATE Latin1_General_CI_AS NULL
	,[EnterVersionNumber] [INT] NULL
	,[LastChgDateTime] [DATETIME2](3) NULL
	,[LastChgUserName] [NVARCHAR](100) COLLATE Latin1_General_CI_AS NULL
	,[LastChgVersionNumber] [INT] NULL
	,[ValidationStatus] [NVARCHAR](250) COLLATE Latin1_General_CI_AS NULL
	,[_DateCreated] [DATETIME2](7) NULL	
	,[_EventExecutionKey] [INT] NULL	
	,[_LastAction] [NCHAR](1) NULL
) ON [PRIMARY]


CREATE UNIQUE NONCLUSTERED INDEX [IX_WORK_SIILMALClassMapping_Code]
	ON [WORK].[SIILMALClassMapping] ([Code])
	INCLUDE ([VersionName], [VersionNumber], [Version_ID], [VersionFlag], [Name], [ChangeTrackingMask], [DataClass], [ReservingClass_Code], [ReservingClass_Name], [ReservingClass_ID], [CMTClass_Code], [CMTClass_Name], [CMTClass_ID], [EnterDateTime], [EnterUserName], [EnterVersionNumber], [LastChgDateTime], [LastChgUserName], [LastChgVersionNumber], [ValidationStatus], [_DateCreated], [_EventExecutionKey], [_LastAction]);

CREATE NONCLUSTERED INDEX [IX_WORK_SIILMALClassMapping__LastAction]
	ON [WORK].[SIILMALClassMapping] ([_LastAction]);




-- READ Target



-- Read Source


-- MERGE in LOAD Package
UPDATE 
	t 
SET 
	t.[_LastAction] = s.[_LastAction] 
,	t.[_EventExecutionKey] = s.[_EventExecutionKey] 
FROM 
	[dbo].[SIILMALClassMapping] t 
INNER JOIN 
	[WORK].[SIILMALClassMapping] s 
ON 
	t.[Code] = s.[Code] 
WHERE 
	t.[_LastAction] <> 'D' 
AND
	s.[_LastAction] = 'D'; 


MERGE [dbo].[SIILMALClassMapping] AS t 
USING [WORK].[SIILMALClassMapping] AS s 
ON 
(
	t.[Code] = s.[Code] 
)
WHEN MATCHED AND s.[_LastAction] IN ('I', 'U') 
THEN 
UPDATE 
SET 
[VersionName]              = s.[VersionName]
,[VersionNumber]           = s.[VersionNumber]
,[Version_ID]              = s.[Version_ID]
,[VersionFlag]             = s.[VersionFlag]
,[Name] 				   = s.[Name]
,[ChangeTrackingMask]      = s.[ChangeTrackingMask]
,[DataClass]               = s.[DataClass] 
,[ReservingClass_Code]     = s.[ReservingClass_Code] 
,[ReservingClass_Name]     = s.[ReservingClass_Name]
,[ReservingClass_ID]       = s.[ReservingClass_ID]
,[CMTClass_Code]           = s.[CMTClass_Code]
,[CMTClass_Name]           = s.[CMTClass_Name]
,[CMTClass_ID]             = s.[CMTClass_ID]
,[EnterDateTime]           = s.[EnterDateTime]
,[EnterUserName]           = s.[EnterUserName]
,[EnterVersionNumber]      = s.[EnterVersionNumber]
,[LastChgDateTime]         = s.[LastChgDateTime]
,[LastChgUserName]         = s.[LastChgUserName]
,[LastChgVersionNumber]    = s.[LastChgVersionNumber]
,[ValidationStatus]        = s.[ValidationStatus]
,[_EventExecutionKey]      = s.[_EventExecutionKey]
,[_LastAction]             = s.[_LastAction] 
WHEN NOT MATCHED BY TARGET AND s.[_LastAction] IN ('I', 'U') THEN 
INSERT 
( 
[VersionName]
,[VersionNumber]
,[Version_ID]
,[VersionFlag]
,[Name]
,[Code]
,[ChangeTrackingMask]
,[DataClass]
,[ReservingClass_Code]
,[ReservingClass_Name]
,[ReservingClass_ID]
,[CMTClass_Code]
,[CMTClass_Name]
,[CMTClass_ID]
,[EnterDateTime]
,[EnterUserName]
,[EnterVersionNumber]
,[LastChgDateTime]
,[LastChgUserName]
,[LastChgVersionNumber]
,[ValidationStatus]
,[_DateCreated]
,[_EventExecutionKey]
,[_LastAction])
VALUES
(
 s.[VersionName]
,s.[VersionNumber]
,s.[Version_ID]
,s.[VersionFlag]
,s.[Name]
,s.[Code]
,s.[ChangeTrackingMask]
,s.[DataClass]
,s.[ReservingClass_Code]
,s.[ReservingClass_Name]
,s.[ReservingClass_ID]
,s.[CMTClass_Code]
,s.[CMTClass_Name]
,s.[CMTClass_ID]
,s.[EnterDateTime]
,s.[EnterUserName]
,s.[EnterVersionNumber]
,s.[LastChgDateTime]
,s.[LastChgUserName]
,s.[LastChgVersionNumber]
,s.[ValidationStatus]
,s.[_DateCreated]
,s.[_EventExecutionKey]
,s.[_LastAction]
);





--Pakiet LOAD Full Compare SIILMIEClassMapping

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[WORK].[SIILMIEClassMapping]') AND type in (N'U'))
DROP TABLE [WORK].[SIILMIEClassMapping]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [WORK].[SIILMIEClassMapping](
       [VersionName]			[NVARCHAR](50) COLLATE Latin1_General_CI_AS NULL
      ,[VersionNumber]			[INT] NULL
      ,[Version_ID]				[INT] NULL
      ,[VersionFlag]			[NVARCHAR](50) COLLATE Latin1_General_CI_AS NULL
      ,[Name]					[NVARCHAR](250) COLLATE Latin1_General_CI_AS NULL
      ,[Code]					[NVARCHAR](250) COLLATE Latin1_General_CI_AS NULL
      ,[ChangeTrackingMask]		INT  NULL
      ,[S2ReserveClass]			[NVARCHAR](100) COLLATE Latin1_General_CI_AS NULL
      ,[CMTClass_Code]			[NVARCHAR](250) COLLATE Latin1_General_CI_AS NULL
      ,[CMTClass_Name]			[NVARCHAR](250) COLLATE Latin1_General_CI_AS NULL
      ,[CMTClass_ID]			INT NULL
      ,[ReservingClass_Code]	[NVARCHAR](250) COLLATE Latin1_General_CI_AS NULL
      ,[ReservingClass_Name]	[NVARCHAR](250) COLLATE Latin1_General_CI_AS NULL
      ,[ReservingClass_ID]		INT NULL
      ,[EnterDateTime]			[DATETIME2](3)  NULL
      ,[EnterUserName]			[NVARCHAR](100) COLLATE Latin1_General_CI_AS NULL
      ,[EnterVersionNumber]		INT NULL
      ,[LastChgDateTime]		[DATETIME2](3) NULL
      ,[LastChgUserName]		[NVARCHAR](100) COLLATE Latin1_General_CI_AS NULL
      ,[LastChgVersionNumber]	INT NULL
      ,[ValidationStatus]		[NVARCHAR](250) COLLATE Latin1_General_CI_AS NULL
	  ,[_DateCreated] [DATETIME2](7) NULL	
	  ,[_EventExecutionKey] [INT] NULL	
	  ,[_LastAction] [NCHAR](1) NULL
) ON [PRIMARY]


CREATE UNIQUE NONCLUSTERED INDEX [IX_WORK_SIILMIEClassMapping_Code]
	ON [WORK].[SIILMIEClassMapping] ([Code])
	INCLUDE ([VersionName] ,[VersionNumber] ,[Version_ID] ,[VersionFlag] ,[Name] ,[ChangeTrackingMask] ,[S2ReserveClass] ,[CMTClass_Code] ,[CMTClass_Name] ,[CMTClass_ID] ,[ReservingClass_Code] ,[ReservingClass_Name] ,[ReservingClass_ID] ,[EnterDateTime] ,[EnterUserName] ,[EnterVersionNumber] ,[LastChgDateTime] ,[LastChgUserName] ,[LastChgVersionNumber] ,[ValidationStatus]);
			 
CREATE NONCLUSTERED INDEX [IX_WORK_SIILMIELClassMapping__LastAction]
	ON [WORK].[SIILMIEClassMapping] ([_LastAction]);



--Read Target
SELECT 
	 [VersionName]
	,[VersionNumber]
	,[Version_ID]
	,[VersionFlag]
	,[Name]
	,[Code]
	,[ChangeTrackingMask]
	,[S2ReserveClass]
	,[ReservingClass_Code]
	,[ReservingClass_Name]
	,[ReservingClass_ID]
	,[CMTClass_Code]
	,[CMTClass_Name]
	,[CMTClass_ID]
	,[EnterDateTime]
	,[EnterUserName]
	,[EnterVersionNumber]
	,[LastChgDateTime]
	,[LastChgUserName]
	,[LastChgVersionNumber]
	,[ValidationStatus]
 FROM [dbo].[SIILMIEClassMapping]
 WHERE [_LastAction] <> 'D'
 ORDER BY [Code]


--Read Source

SELECT 
	 [VersionName]
	,[VersionNumber]
	,[Version_ID]
	,[VersionFlag]
	,[Name]
	,[Code]
	,[ChangeTrackingMask]
	,[S2ReserveClass]
	,[ReservingClass_Code]
	,[ReservingClass_Name]
	,[ReservingClass_ID]
	,[CMTClass_Code]
	,[CMTClass_Name]
	,[CMTClass_ID]
	,[EnterDateTime]
	,[EnterUserName]
	,[EnterVersionNumber]
	,[LastChgDateTime]
	,[LastChgUserName]
	,[LastChgVersionNumber]
	,[ValidationStatus]
  FROM [dbo].[SIILMIEClassMapping]
  ORDER BY [Code]


--MERGE

UPDATE 
	t 
SET 
	t.[_LastAction] = s.[_LastAction] 
,	t.[_EventExecutionKey] = s.[_EventExecutionKey] 
FROM 
	[dbo].[SIILMIEClassMapping] t 
INNER JOIN 
	[WORK].[SIILMIEClassMapping] s 
ON 
	t.[Code] = s.[Code] 
WHERE 
	t.[_LastAction] <> 'D' 
AND
	s.[_LastAction] = 'D'; 


MERGE [dbo].[SIILMIEClassMapping] AS t 
USING [WORK].[SIILMIEClassMapping] AS s 
ON 
(
	t.[Code] = s.[Code] 
)
WHEN MATCHED AND s.[_LastAction] IN ('I', 'U') 
THEN 
UPDATE 
SET 
[VersionName]              = s.[VersionName]
,[VersionNumber]           = s.[VersionNumber]
,[Version_ID]              = s.[Version_ID]
,[VersionFlag]             = s.[VersionFlag]
,[Name] 				   = s.[Name]
,[ChangeTrackingMask]      = s.[ChangeTrackingMask]
,[S2ReserveClass]          = s.[S2ReserveClass] 
,[ReservingClass_Code]     = s.[ReservingClass_Code] 
,[ReservingClass_Name]     = s.[ReservingClass_Name]
,[ReservingClass_ID]       = s.[ReservingClass_ID]
,[CMTClass_Code]           = s.[CMTClass_Code]
,[CMTClass_Name]           = s.[CMTClass_Name]
,[CMTClass_ID]             = s.[CMTClass_ID]
,[EnterDateTime]           = s.[EnterDateTime]
,[EnterUserName]           = s.[EnterUserName]
,[EnterVersionNumber]      = s.[EnterVersionNumber]
,[LastChgDateTime]         = s.[LastChgDateTime]
,[LastChgUserName]         = s.[LastChgUserName]
,[LastChgVersionNumber]    = s.[LastChgVersionNumber]
,[ValidationStatus]        = s.[ValidationStatus]
,[_EventExecutionKey]      = s.[_EventExecutionKey]
,[_LastAction]             = s.[_LastAction] 
WHEN NOT MATCHED BY TARGET AND s.[_LastAction] IN ('I', 'U') THEN 
INSERT 
( 
[VersionName]
,[VersionNumber]
,[Version_ID]
,[VersionFlag]
,[Name]
,[Code]
,[ChangeTrackingMask]
,[S2ReserveClass]
,[ReservingClass_Code]
,[ReservingClass_Name]
,[ReservingClass_ID]
,[CMTClass_Code]
,[CMTClass_Name]
,[CMTClass_ID]
,[EnterDateTime]
,[EnterUserName]
,[EnterVersionNumber]
,[LastChgDateTime]
,[LastChgUserName]
,[LastChgVersionNumber]
,[ValidationStatus]
,[_DateCreated]
,[_EventExecutionKey]
,[_LastAction])
VALUES
(
 s.[VersionName]
,s.[VersionNumber]
,s.[Version_ID]
,s.[VersionFlag]
,s.[Name]
,s.[Code]
,s.[ChangeTrackingMask]
,s.[S2ReserveClass]
,s.[ReservingClass_Code]
,s.[ReservingClass_Name]
,s.[ReservingClass_ID]
,s.[CMTClass_Code]
,s.[CMTClass_Name]
,s.[CMTClass_ID]
,s.[EnterDateTime]
,s.[EnterUserName]
,s.[EnterVersionNumber]
,s.[LastChgDateTime]
,s.[LastChgUserName]
,s.[LastChgVersionNumber]
,s.[ValidationStatus]
,s.[_DateCreated]
,s.[_EventExecutionKey]
,s.[_LastAction]
);





--- TESTOWANIE

select * from SIILMALClassMapping 
select * from SIILMIEClassMapping

select * from LloydsCauseOfLoss