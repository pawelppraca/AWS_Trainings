
DECLARE @ConnectionString NVARCHAR(MAX) = '\\VMBIT-GDWAPP01.lm.lmig.com\DWH_Extract$\ofac_lsm_london_f.dat'


SELECT *
FROM [dbo].[Connections] con
WHERE  ConnectionCode ='FEEDERSOFACSANCTIONS'
AND ConnectionString != @ConnectionString



SELECT *
FROM [dbo].[Connections] con
WHERE  ConnectionCode ='FEEDERSOFACSANCTIONS'

