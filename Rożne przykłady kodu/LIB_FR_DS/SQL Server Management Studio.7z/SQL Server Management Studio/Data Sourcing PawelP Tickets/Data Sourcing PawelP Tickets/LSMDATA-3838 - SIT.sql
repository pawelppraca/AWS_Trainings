
--RUN Script 

--Sprawdzenie

Use ETL_Control
Select * from [Events] where [EventCode] like '%_APAC'

Select * from [TaskGroups] where [TaskGroupCode] like '%_APAC'


Select * from [TaskGroupConnections] where [TaskGroupCode] like '%_APAC'

Select * from [EventTaskGroups] where [EventCode] like '%_APAC'


Select * from [WorkflowConstraints] where [EventCode] like '%_APAC'

Select * from [Tasks] where [TaskCode] like '%_APAC'


Select * from [ExtendedTaskAttributes] where [TaskCode] like '%_APAC'

--Sprawdzenie dodania do kolejki

select * from [dbo].[WorkQueue]

select  * from [dbo].[WorkQueueLog] where ExecutionStartDate between '20240204' and '20240205' order by WorkQueueTaskKey

select  * from [dbo].[WorkQueueLog] where EventExecutionKey = 280614 order by ExecutionStartDate

select  * from [dbo].[WorkQueueErrorLog] where EventExecutionKey = 280614 order by ExecutionStartDate



select * from UserAdmin.dbo.audit_log where date_time between '2024-02-04T12:00:00' and '2024-02-04T15:00:00'