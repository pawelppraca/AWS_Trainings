declare @cdc_lower nvarchar(100) = '20240603000001000000000000000000000', @cdc_upper nvarchar(100) ='20240605000001000000000000000000000'

drop table if exists #ZUMA_Policies_log
Select * 
into #ZUMA_Policies_log
FROM BI_LZ.Genius.ZUMA_log (nolock) z
WHERE header_change_seq > @cdc_lower  and header_change_seq <=@cdc_upper

-- (313252 rows affected)

--Filtrowanie
drop table if Exists #Zuma_Policies_LSM
SELECT *
into #Zuma_Policies_LSM
--FROM BI_LZ.Genius.ZUMA z
FROM #ZUMA_Policies_log z
WHERE (z.MACNCD in ('CHILE', 'ARGNTA', 'MLYON', 'BRZAFFIL', 'LIBSEGBR', 'MLYOFF', 'COLOMBIA', 'COL', 'LMLATAM', 'CHL', 
                'BRASIL', 'PERU', 'ECUADOR', 'LSILATAM', 'LIUILATM', 'LIBSEGPE', 'MEXICO', 'SING', 'SOF', 'AUS', 'HK',
                'BENELUX', 'BHAMUK', 'BRISTLUK', 'COLOGNUK', 'DUBAI', 'DUBUK', 'GLASGOUK', 'HAMBRGUK', 'IRELC', 'LEEDSUK',
                'LMUK', 'MANUK', 'MILANUK', 'PARISUK', 'SOEASTUK', 'SPAIN', 'SWISSUK', 'VISIONUW', 'IRE', 'LUXUK',
                'NORWAY','SWEDEN','BELGIUM') --companies
		OR z.MAMAPC in ('EQUINE', 'TPR', 'TERROR' , 'ENGNR', 'HVY', 'OFNRG', 'ONNRG', 'INLM', 'INLMQ', 'COC', 'ONNRGQ',
				'OFNRGQ', 'HVYQ', 'ENGNRQ', 'FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3') --lsm_products
		OR z.MADPCD in ('GLA', 'GUA', 'GUC', 'GUD', 'SD5') --lsm_departments
		OR z.MAMABN in('3MIAMI', '5MIAMI', '4PAULO', '3PR') --lsm_west_branches
		) 
AND NOT (z.MAMAPC ='TPR' AND z.MACNCD in ('III', 'ISIC'))
AND (LEFT(z.MAMABN, 1) <> '7' OR z.MAMAPC NOT IN ('INLM', 'INLMQ'))
--zakres dat gdzie sa dane w malej ilosci 
AND header_change_seq > '20240603000001000000000000000000000' and header_change_seq < '20240605000001000000000000000000000'
--(78435 rows affected)




declare @cdc_lower1 nvarchar(100) = '20240010100001000000000000000000000', @cdc_upper1 nvarchar(100) ='20240701000001000000000000000000000'

--wszystkie coversy
drop table if exists #Covers
SELECT ZUMA.*,ZUMA.MACNCD AS CompanyCode 
into #Covers
FROM GENIUS.ZUMA (nolock) --_log (nolock)  WHERE ZUMA_log.header_change_seq > @cdc_lower1 AND ZUMA_log.header_change_seq <= @cdc_upper1
--(59057 rows affected)

--wszystkie ZURI
drop table if exists #zuri_covers
SELECT RIMANU,RIMASE,RIRIMN,RIRIMS 
into #zuri_covers
FROM GENIUS.ZURI (nolock) -- WHERE ZURI_log.header_change_seq > @cdc_lower1 AND ZURI_log.header_change_seq <= @cdc_upper1

--(13366 rows affected)


--POLISY RI wzystkie zwiazana z ZUMA przez ZURI i wyfiltrowane po produktach
drop table if exists #RI_Policies
select distinct cov.* 
into #RI_Policies 
from #Zuma_Policies_LSM pol
join #zuri_covers map
    on  pol.MAMANU = map.RIMANU and pol.MAMASE = map.RIMASE
join #Covers cov
    on map.RIRIMN = cov.MAMANU and map.RIRIMS = cov.MAMASE
where cov.MAMAPC in ('FAC', 'QS', 'SUR', 'XSL', 'FXL', 'QS2', 'QS3')



select * from #RI_Policies 

-- UWAGA!!! - Sprawdzi? w RDS SIT CzyTych polis nie ma ju? wczesniej przeprocesowanych

--wyszukanie zmian do tych COver�w
select ZUMA_log.*,ZUMA_log.MACNCD AS CompanyCode
into #RI_Policies_Log
FROM Genius.ZUMA_log 
JOIN #RI_Policies ri on ri.MAMANU = ZUMA_log.MAMANU and ri.MAMASE = ZUMA_log.MAMASE
order by header_timestamp


--Polisy do dodania
--insert into #Zuma_Policies_LSM
drop table if exists #RI_Policies_to_Add
select distinct ri.*
--into #RI_Policies_to_Add
from #RI_Policies_Log ri
left join #Zuma_Policies_LSM pol on ri.MAMANU = pol.MAMANU and ri.MAMASE=pol.MAMASE 
where pol.mamanu is null and pol.mamase is null --tylko te kt�re nie istniej? w ZUMA

--sprawdzenie zakresu z kt�rego sa dane

select distinct substring(ri.header_change_seq,1,14)

from #RI_Policies ri
left join #Zuma_Policies_LSM pol on ri.MAMANU = pol.MAMANU and ri.MAMASE=pol.MAMASE 
where pol.mamanu is null and pol.mamase is null --tylko te kt�re nie istniej? w ZUMA
order by substring(ri.header_change_seq,1,14)


--Sprawdzenie jakic polis ZUMA ktorych dotyczna nowo dodawane RI
select distinct pol.maporf, pol.MACNCD, ri.maporf, ri.MACNCD

from #Zuma_Policies_LSM pol
join #zuri_covers map on pol.MAMANU = map.RIMANU and pol.MAMASE = map.RIMASE
join #RI_Policies_to_Add ri on map.RIRIMN = ri.MAMANU and map.RIRIMS = ri.MAMASE



--Sprawdzenie jakic polis ZUMA ktorych dotyczna nowo dodawane RI

select  substring(pol.header_change_seq,1,14), count(distinct ri.MAPORF) , count(distinct pol.MAPORF)
from #Zuma_Policies_LSM pol
join #zuri_covers map on pol.MAMANU = map.RIMANU and pol.MAMASE = map.RIMASE
join #RI_Policies_to_Add ri on map.RIRIMN = ri.MAMANU and map.RIRIMS = ri.MAMASE
group by substring(pol.header_change_seq,1,14)
order by substring(pol.header_change_seq,1,14)

/*
Data	Ilosc Polis RI	Ilosc Polis ZUMA
20240603015656	1	2
20240603065813	1	2
20240603135535	2	1
20240604012709	1	2
20240604014029	1	2
20240604022609	1	2
20240612103102	2	1
20240612131600	2	1
20240612143204	2	1
20240612143542	2	1
20240612143738	2	1
20240612143908	2	1
20240618071517	1	2
20240618073039	1	2
20240620123205	1	2
*/


