select [Claim Number],Claimant, count(*) cnt
from Staging_GENIUS.dbo.CBIClaimListing 
group by [Claim Number],Claimant
having count(9) > 1
order by count(9) desc


AIR FRANCE-40225-001


select  [Claim Number],Claimant, *
from Staging_GENIUS.dbo.CBIClaimListing 
where [Claim Number]='AIR FRANCE-40225-001'
group by [Claim Number],Claimant
having count(9) >1
