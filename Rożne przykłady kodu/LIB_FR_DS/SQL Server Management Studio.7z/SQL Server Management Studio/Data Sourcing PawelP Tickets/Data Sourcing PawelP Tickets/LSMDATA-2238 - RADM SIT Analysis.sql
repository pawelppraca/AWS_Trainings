--drop table #SIT_CBIClaimListing2

select * 
into #UAT_CBIClaimListing
from IDS.CBIClaimListing


select 
		 y.[Catastrophe Code]
	,	 y.[Catastrophe Description]
	,	 y.[Cause of Loss 1]
	,	 y.[Cause of Loss 4 - Type]
	,	 y.[Cause Of Loss2]
	,	 y.[Claim Closure Reason]
	,	 y.[Claim Create Date]
	,	 y.[Claim Current State]
	,	 y.[Claim Description]
	,	 y.[Claim Handler]
	,	 y.[Claim Number]
	,	 y.[Claim Title]
	,	 y.[Claim Type]
	,	 y.[Date Last Closed]
	,	 y.[Date Last Reopened]
	,	 y.[Date Of Loss]
	,	 y.[Date Reported/Event]
	,	 y.[First Exposure Claimant]
	,	 y.[Loss Country]
	,	 y.[Severity]
	,	 y.[Claim Event Code]
	,	 y.[Event Description]
	,	 y.[TPA Claim Number]
	,	 y.[Cause of Loss3]
	,	 y.[Loss City]
	,	 y.[Loss State]
	,	 y.[Region]
	,	 y.[Loss Region]
	,	 y.[Cause of Loss 1 Other Description]
	,	 y.[Cause of Loss 2 Other Description]
	,	 y.[Cause of Loss 3 Other Description]
	,	 y.[Cause of Loss 4 Other Description]    
	,	 y.[Cause Of Loss5]                       
	,	 y.[Loss Code Group]                      
	,	 y.[Organization]                         
	,	 y.[Cyber Consideration]                  
	,	 y.[Cyber Consideration Other Description]
	,	 y.[Ransomware Aspect]  
	,	 y.[Batched Claim]	
	,	 y.[Block File]
	,	 y.[Loss Fund]	
	,	 y.[Policy number]
	,	 y.[Coverage Name]
	,	 y.[Business Sub Component]
	,	 y.[Business Component]
	,	 y.[Insured Name]
	,	 y.[Branch]
	,	 y.[Location ID]
	,	 y.[Total Inr curr(Gross)]
	,	 y.[Broker Name]
	,	 y.[Underwriter]
	,	 y.[Risk engineer]
	,	 y.[LIU Share]
from (
	SELECT 
		 x.[Catastrophe Code]
	,	 x.[Catastrophe Description]
	,	 x.[Cause of Loss 1]
	,	 x.[Cause of Loss 4 - Type]
	,	 x.[Cause Of Loss2]
	,	 x.[Claim Closure Reason]
	,	 x.[Claim Create Date]
	,	 x.[Claim Current State]
	,	 x.[Claim Description]
	,	 x.[Claim Handler]
	,	 x.[Claim Number]
	,	 x.[Claim Title]
	,	 x.[Claim Type]
	,	 x.[Date Last Closed]
	,	 x.[Date Last Reopened]
	,	 x.[Date Of Loss]
	,	 x.[Date Reported/Event]
	,	 x.[First Exposure Claimant]
	,	 x.[Loss Country]
	,	 x.[Severity]
	,	 x.[Claim Event Code]
	,	 x.[Event Description]
	,	 x.[TPA Claim Number]
	,	 x.[Cause of Loss3]
	,	 x.[Loss City]
	,	 x.[Loss State]
	,	 x.[Region]
	,	 x.[Loss Region]
	,	 x.[Cause of Loss 1 Other Description]
	,	 x.[Cause of Loss 2 Other Description]
	,	 x.[Cause of Loss 3 Other Description]
	,	 x.[Cause of Loss 4 Other Description]    
	,	 x.[Cause Of Loss5]                       
	,	 x.[Loss Code Group]                      
	,	 x.[Organization]                         
	,	 x.[Cyber Consideration]                  
	,	 x.[Cyber Consideration Other Description]
	,	 x.[Ransomware Aspect]  
	,	 x.[Batched Claim]	
	,	 x.[Block File]
	,	 x.[Loss Fund]	
	,	 x.[Policy number]
	,	 x.[Coverage Name]
	,	 x.[Business Sub Component]
	,	 x.[Business Component]
	,	 x.[Insured Name]
	,	 x.[Branch]
	,	 x.[Location ID]
	,	 x.[Total Inr curr(Gross)]
	,	 x.[Broker Name]
	,	 x.[Underwriter]
	,	 x.[Risk engineer]
	,	 x.[LIU Share]
	,	ROW_NUMBER() OVER (PARTITION BY x.[Claim Number], x.[Coverage Name] ORDER BY x.[Claim Create Date]) AS RowNum
	FROM
	(
		SELECT 
		 [Catastrophe Code]
	,	 [Catastrophe Description]
	,	 [Cause of Loss 1]
	,	 [Cause of Loss 4 - Type]
	,	 [Cause Of Loss2]
	,	 [Claim Closure Reason]
	,	 [Claim Create Date]
	,	 [Claim Current State]
	,	 [Claim Description]
	,	 [Claim Handler]
	,	 [Claim Number]
	,	 [Claim Title]
	,	 [Claim Type]
	,	 [Date Last Closed]
	,	 [Date Last Reopened]
	,	 [Date Of Loss]
	,	 [Date Reported/Event]
	,	 [First Exposure Claimant]
	,	 [Loss Country]
	,	 [Severity]
	,	 [Claim Event Code]
	,	 [Event Description]
	,	 [TPA Claim Number]
	,	 [Cause of Loss3]
	,	 [Loss City]
	,	 [Loss State]
	,	 [Region]
	,	 [Loss Region]
	,	 [Cause of Loss 1 Other Description]
	,	 [Cause of Loss 2 Other Description]
	,	 [Cause of Loss 3 Other Description]
	,	 [Cause of Loss 4 Other Description]    
	,	 [Cause Of Loss5]                       
	,	 [Loss Code Group]                      
	,	 [Organization]                         
	,	 [Cyber Consideration]                  
	,	 [Cyber Consideration Other Description]
	,	 [Ransomware Aspect] 
	,	 [Batched Claim]	
	,	 [Block File]
	,	 [Loss Fund]	
	,	 [Policy number]
	,	 ISNULL([Coverage Name],'<<Unknown>>') [Coverage Name]
	,	 [Business Sub Component]
	,	 [Business Component]
	,	 [Insured Name]
	,	 [Branch]
	,	 [Location ID]
	,	 SUM([Total Inr curr(Gross)]) [Total Inr curr(Gross)]
	,	 [Broker Name]
	,	 [Underwriter]
	,	 [Risk engineer]
	,	 [LIU Share]
		FROM #UAT_CBIClaimListing
	group by 
		 [Catastrophe Code]
	,	 [Catastrophe Description]
	,	 [Cause of Loss 1]
	,	 [Cause of Loss 4 - Type]
	,	 [Cause Of Loss2]
	,	 [Claim Closure Reason]
	,	 [Claim Create Date]
	,	 [Claim Current State]
	,	 [Claim Description]
	,	 [Claim Handler]
	,	 [Claim Number]
	,	 [Claim Title]
	,	 [Claim Type]
	,	 [Date Last Closed]
	,	 [Date Last Reopened]
	,	 [Date Of Loss]
	,	 [Date Reported/Event]
	,	 [First Exposure Claimant]
	,	 [Loss Country]
	,	 [Severity]
	,	 [Claim Event Code]
	,	 [Event Description]
	,	 [TPA Claim Number]
	,	 [Cause of Loss3]
	,	 [Loss City]
	,	 [Loss State]
	,	 [Region]
	,	 [Loss Region]
	,	 [Cause of Loss 1 Other Description]
	,	 [Cause of Loss 2 Other Description]
	,	 [Cause of Loss 3 Other Description]
	,	 [Cause of Loss 4 Other Description]    
	,	 [Cause Of Loss5]                       
	,	 [Loss Code Group]                      
	,	 [Organization]                         
	,	 [Cyber Consideration]                  
	,	 [Cyber Consideration Other Description]
	,	 [Ransomware Aspect]  
	,	 [Batched Claim]	
	,	 [Block File]
	,	 [Loss Fund]	
	,	 [Policy number]
	,	 [Coverage Name]
	,	 [Business Sub Component]
	,	 [Business Component]
	,	 [Insured Name]
	,	 [Branch]
	,	 [Location ID]
	,	 [Broker Name]
	,	 [Underwriter]
	,	 [Risk engineer]
	,	 [LIU Share]
	) x
) y 
where y.RowNum=1
ORDER BY y.[Claim Number], y.[Coverage Name]






select [Claim Number],  [Coverage Name],  [Policy number], [Total Inr curr(Gross)], Claimant,* 
from [dbo].[CBIClaimListing] where [Claim Number]='11-LEFC-0001'

select [Claim Number],  [Coverage Name],  [Policy number],[Total Inr curr(Gross)], * 
from #SIT_CBIClaimListing where [Claim Number]='11-LEFC-0001'

select [Claim Number],  [Coverage Name],  [Policy number], [Total Inr curr(Gross)], * 
from #SIT_CBIClaimListing2 where [Claim Number]='11-LEFC-0001'

select [Claim Number],  [Coverage Name],  [Policy number], [Total Inr curr(Gross)], * 
from #SIT_CBIClaimListing3 where [Claim Number]='11-LEFC-0001'



select [Claim Number],  [Coverage Name],  [Policy number] , count(*)  duplicates_qty
from #SIT_CBIClaimListing3
group by [Claim Number],  [Coverage Name], [Policy number]
having count(*) > 1


 select  [Claim Number],  [Coverage Name],  [Policy number],[Total Inr curr(Gross)], [Business Sub Component], [Business Component],* 
 from  [dbo].[CBIClaimListing] where [claim number] like 'HOUHUL000023645' and [Coverage Name]='PROTECTION & INDEMNITY'

  select  [Claim Number],  [Coverage Name],  [Policy number],[Total Inr curr(Gross)], [Business Sub Component], [Business Component],* 
 from  #SIT_CBIClaimListing where [claim number] like 'HOUHUL000023645' and [Coverage Name]='PROTECTION & INDEMNITY'

 select   [Claim Number],  [Coverage Name],  [Policy number], claimant, [Total Inr curr(Gross)], * 
 from  #SIT_CBIClaimListing  where [claim number] like '11-LEFC-0001' and [Coverage Name]='REAL PROPERTY'


--Claims with different fields 
Claim Number	Coverage Name	Policy number	duplicates_qty
HOUHUL000023645	PROTECTION & INDEMNITY	3H656634005	2
CHIHUL000108920	PROTECTION & INDEMNITY	3CAAFJUW004	2
ATLHUL000094746	PROTECTION & INDEMNITY	ATAAPIB7003	2
ATLHUL000174171	HULL & MACHINERY	LIUH-00025-05	2



select cbi.[Claim Number],  cbi.[Coverage Name], cbi.[Policy number],cbi.[Total Inr curr(Gross)], [Business Sub Component], [Business Component], *  
from #SIT_CBIClaimListing3 cbi
join (
	select [Claim Number],  [Coverage Name],  [Policy number] , count(*)  duplicates_qty
	from #SIT_CBIClaimListing3
	group by [Claim Number],  [Coverage Name], [Policy number]
	having count(*) > 1
) dps on dps.[Claim Number] = cbi.[Claim Number] and dps.[Coverage Name]=cbi.[Coverage Name] and dps.[Policy number]=cbi.[Policy number]
order by cbi.[Claim Number],  cbi.[Coverage Name], cbi.[Policy number]



select cbi.[Claim Number],  cbi.[Coverage Name], cbi.[Policy number],cbi.[Total Inr curr(Gross)], [Business Sub Component], [Business Component], *  
from #SIT_CBIClaimListing2 cbi
join (
	select [Claim Number],  [Coverage Name],  [Policy number] , count(*)  duplicates_qty
	from #SIT_CBIClaimListing2
	group by [Claim Number],  [Coverage Name], [Policy number]
	having count(*) > 1
) dps on dps.[Claim Number] = cbi.[Claim Number] and dps.[Coverage Name]=cbi.[Coverage Name] and dps.[Policy number]=cbi.[Policy number]
order by cbi.[Claim Number],  cbi.[Coverage Name], cbi.[Policy number]




where [Claim Number] ='LONSPC000030549' and [Coverage Name]='SINGLE LOSS LIMIT'



 select [Claim Number], [Coverage Name], [Total Inr curr(Gross)],*
 from #SIT_CBIClaimListing2 where [Claim Number] ='SINONN000139562' and [Coverage Name]='MACHINERY BREAKDOWN'