select * from ETL_Control.dbo.connections where ConnectionCode like '%rad%'

select ExecutableName  Paczka_SSIS,* from [dbo].[Tasks] where taskcode='Control_MDS_LogPropagateEntriesODSToWarehouse'


select top 10 * from [dbo].[CBIClaimListing_aws]


--rozszerzenie tabeli 
alter table [dbo].[CBIClaimListing_aws] add 
	[Policy number]					NVARCHAR(50)	NULL,
	[Business Sub Component]				NVARCHAR(100)	NULL,
	[Insured Name]					NVARCHAR(300)	NULL,
	[Location ID]						NVARCHAR(50)	NULL,
--	[Branch]						NVARCHAR(50)	NULL,
	[Broker Name]						NVARCHAR(200)	NULL,
	[Underwriter]						NVARCHAR(100)	NULL,
	[Risk engineer]					NVARCHAR(100)	NULL,
	[LIU Share]						FLOAT	NULL,
	[Attachment Point] 					INTEGER	NULL,
	[Coverage Name]					NVARCHAR(255)	NULL,
	[Total Inr curr(Gross)]				FLOAT	NULL,
	[Deductible Amount] 					INTEGER	NULL


	--zmiana widoku: [IDS].[CBIClaimListing_UAT]
	--zmiana widoku: [IDS].[CBIClaimListing]



--Rozszerzenie tabeli

--rozszerzenie tabeli 
alter table Staging_Genius.[dbo].[CBIClaimListing] add 
	[Policy number]					NVARCHAR(50)	NULL,
	[Business Sub Component]				NVARCHAR(100)	NULL,
	[Insured Name]					NVARCHAR(300)	NULL,
	[Location ID]						NVARCHAR(50)	NULL,
	[Branch]						NVARCHAR(50)	NULL,
	[Broker Name]						NVARCHAR(200)	NULL,
	[Underwriter]						NVARCHAR(100)	NULL,
	[Risk engineer]					NVARCHAR(100)	NULL,
	[LIU Share]						FLOAT	NULL,
	[Attachment Point] 					INTEGER	NULL,
	[Coverage Name]					NVARCHAR(255)	NULL,
	[Total Inr curr(Gross)]				FLOAT	NULL,
	[Deductible Amount] 					INTEGER	NULL

--Modify Packages:
	EXTRACT_GENIUS_CBIClaimListing.dtsx


alter table ODS_Genius.[dbo].[CBIClaimListing] add 
	[Policy number]					NVARCHAR(50)	NULL,
	[Business Sub Component]				NVARCHAR(100)	NULL,
	[Insured Name]					NVARCHAR(300)	NULL,
	[Location ID]						NVARCHAR(50)	NULL,
	[Branch]						NVARCHAR(50)	NULL,
	[Broker Name]						NVARCHAR(200)	NULL,
	[Underwriter]						NVARCHAR(100)	NULL,
	[Risk engineer]					NVARCHAR(100)	NULL,
	[LIU Share]						FLOAT	NULL,
	[Attachment Point] 					INTEGER	NULL,
	[Coverage Name]					NVARCHAR(255)	NULL,
	[Total Inr curr(Gross)]				FLOAT	NULL,
	[Deductible Amount] 					INTEGER	NULL


alter table ODS_Genius.[dbo].[CBIClaimListing] add 
    [Cause of Loss 4 Other Description]     NVARCHAR(256) NULL,
    [Cause Of Loss5]                        NVARCHAR(250) NULL,
    [Loss Code Group]                       NVARCHAR(250) NULL,
    [Organization]                          NVARCHAR(250) NULL,
    [Cyber Consideration]                   NVARCHAR(250) NULL,
    [Cyber Consideration Other Description] NVARCHAR(256) NULL,
    [Ransomware Aspect]                     NVARCHAR(250) NULL

alter table ODS_Genius.[WORK].[CBIClaimListing] add 
	[Policy number]					NVARCHAR(50)	NULL,
	[Business Sub Component]				NVARCHAR(100)	NULL,
	[Insured Name]					NVARCHAR(300)	NULL,
	[Location ID]						NVARCHAR(50)	NULL,
	[Branch]						NVARCHAR(50)	NULL,
	[Broker Name]						NVARCHAR(200)	NULL,
	[Underwriter]						NVARCHAR(100)	NULL,
	[Risk engineer]					NVARCHAR(100)	NULL,
	[LIU Share]						FLOAT	NULL,
	[Attachment Point] 					INTEGER	NULL,
	[Coverage Name]					NVARCHAR(255)	NULL,
	[Total Inr curr(Gross)]				FLOAT	NULL,
	[Deductible Amount] 					INTEGER	NULL

alter table ODS_Genius.[WORK].[CBIClaimListing] add 
    [Cause of Loss 4 Other Description]     NVARCHAR(256) NULL,
    [Cause Of Loss5]                        NVARCHAR(250) NULL,
    [Loss Code Group]                       NVARCHAR(250) NULL,
    [Organization]                          NVARCHAR(250) NULL,
    [Cyber Consideration]                   NVARCHAR(250) NULL,
    [Cyber Consideration Other Description] NVARCHAR(256) NULL,
    [Ransomware Aspect]                     NVARCHAR(250) NULL



--UNIT TESTS v2 (po zmianie kolumn)


select top 100 * from  RADM.IDS.CBIClaimListing

select top 100 * from Staging_GENIUS.dbo.CBIClaimListing

select top 100 * from ODS_GENIUS.dbo.CBIClaimListing


--before test

select top 100 * from RADM.dbo.CBIClaimListing_aws where       
	  [Policy number] is not null
      and [Business Sub Component] is not null
      and [Insured Name] is not null
      and [Location ID] is not null
      and [Branch] is not null
      and [Broker Name] is not null
      and [Underwriter] is not null
      and [Risk engineer] is not null
      and [LIU Share] is not null
      and [Attachment Point] is not null
      and [Coverage Name]	 is not null
      and [Total Inr curr(Gross)]	 is not null
      and [Deductible Amount]  is not null

select top 100 * 
--update c set 
      --[Policy number] = ' '
      --,[Business Sub Component] = ' '
      --,[Insured Name] = ' '
      --,[Location ID] = ' '
      --,[Branch] = ' '
      --,[Broker Name] = ' '
      --,[Underwriter] = ' '
      --,[Risk engineer] = ' '
      --,[LIU Share] = 0
      --,[Attachment Point] = 0
      --,[Coverage Name]= ' '
      --,[Total Inr curr(Gross)] = 0
      --,[Deductible Amount]  = 0
from RADM.dbo.CBIClaimListing_aws c where [Claim Number] in ('DUBSPC000289745','PARSPC000289738','COLSPC000289739','LONPEC000289729')

--Po Update
select count(*) from RADM.dbo.CBIClaimListing_aws where       
	  [Policy number] is not null
      and [Business Sub Component] is not null
      and [Insured Name] is not null
      and [Location ID] is not null
      and [Branch] is not null
      and [Broker Name] is not null
      and [Underwriter] is not null
      and [Risk engineer] is not null
      and [LIU Share] is not null
      and [Attachment Point] is not null
      and [Coverage Name]	 is not null
      and [Total Inr curr(Gross)]	 is not null
      and [Deductible Amount]  is not null



select count(*)from Staging_GENIUS.dbo.CBIClaimListing where       
	  [Policy number] is not null
      and [Business Sub Component] is not null
      and [Insured Name] is not null
      and [Location ID] is not null
      and [Branch] is not null
      and [Broker Name] is not null
      and [Underwriter] is not null
      and [Risk engineer] is not null
      and [LIU Share] is not null
      and [Attachment Point] is not null
      and [Coverage Name]	 is not null
      and [Total Inr curr(Gross)]	 is not null
      and [Deductible Amount]  is not null



select count(*)from ODS_GENIUS.dbo.CBIClaimListing where       
	  [Policy number] is not null
      and [Business Sub Component] is not null
      and [Insured Name] is not null
      and [Location ID] is not null
      and [Branch] is not null
      and [Broker Name] is not null
      and [Underwriter] is not null
      and [Risk engineer] is not null
      and [LIU Share] is not null
      and [Attachment Point] is not null
      and [Coverage Name]	 is not null
      and [Total Inr curr(Gross)]	 is not null
      and [Deductible Amount]  is not null


--Staging_GENIUS

select [Claim Number], Claimant, [Coverage Name]
from Staging_Genius.dbo.CBIClaimListing
group by [Claim Number], Claimant, [Coverage Name]
having count(9)>1


--RADM UAT
select [Claim Number], Claimant, [Coverage Name]
from IDS.CBIClaimListing
group by [Claim Number], Claimant, [Coverage Name]
having count(9)>1


select count(9)
from IDS.CBIClaimListing
group by [Claim Number], Claimant, [Coverage Name]
having count(9)>1
