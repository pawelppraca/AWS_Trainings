-- drop table #tab1
-- drop table #tab2

select 
		 y.[Catastrophe Code]
	,	 y.[Catastrophe Description]
	,	 y.[Cause of Loss 1]
	,	 y.[Cause of Loss 4 - Type]
	,	 y.[Cause Of Loss2]
	,	 y.[Claim Closure Reason]
	,	 y.[Claim Create Date]
	,	 y.[Claim Current State]
	,	 y.[Claim Description]
	,	 y.[Claim Handler]
	,	 UPPER(LTRIM(RTRIM(y.[Claim Number])))[Claim Number]
	,	 y.[Claim Title]
	,	 y.[Claim Type]
	,	 y.[Date Last Closed]
	,	 y.[Date Last Reopened]
	,	 y.[Date Of Loss]
	,	 y.[Date Reported/Event]
	,	 y.[First Exposure Claimant]
	,	 y.[Loss Country]
	,	 y.[Severity]
	,	 y.[Claim Event Code]
	,	 y.[Event Description]
	,	 y.[TPA Claim Number]
	,	 y.[Cause of Loss3]
	,	 y.[Loss City]
	,	 y.[Loss State]
	,	 y.[Region]
	,	 y.[Loss Region]
	,	 y.[Cause of Loss 1 Other Description]
	,	 y.[Cause of Loss 2 Other Description]
	,	 y.[Cause of Loss 3 Other Description]
	,	 y.[Cause of Loss 4 Other Description]    
	,	 y.[Cause Of Loss5]                       
	,	 y.[Loss Code Group]                      
	,	 y.[Organization]                         
	,	 y.[Cyber Consideration]                  
	,	 y.[Cyber Consideration Other Description]
	,	 y.[Ransomware Aspect]  
	,	 y.[Batched Claim]	
	,	 y.[Block File]
	,	 y.[Loss Fund]	
	,	 y.[Policy number]
	,	 UPPER(LTRIM(RTRIM(isnull(y.[Coverage Name],'<<Unknown>>')))) [Coverage Name]
	,	 y.[Business Sub Component]
	,	 y.[Business Component]
	,	 y.[Insured Name]
	,	 y.[Branch]
	,	 y.[Location ID]
	,	 y.[Total Inr curr(Gross)]
	,	 y.[Broker Name]
	,	 y.[Underwriter]
	,	 y.[Risk engineer]
	,	 y.[LIU Share]
into #tab1
from (
	SELECT 
		 x.[Catastrophe Code]
	,	 x.[Catastrophe Description]
	,	 x.[Cause of Loss 1]
	,	 x.[Cause of Loss 4 - Type]
	,	 x.[Cause Of Loss2]
	,	 x.[Claim Closure Reason]
	,	 x.[Claim Create Date]
	,	 x.[Claim Current State]
	,	 x.[Claim Description]
	,	 x.[Claim Handler]
	,	 x.[Claim Number]
	,	 x.[Claim Title]
	,	 x.[Claim Type]
	,	 x.[Date Last Closed]
	,	 x.[Date Last Reopened]
	,	 x.[Date Of Loss]
	,	 x.[Date Reported/Event]
	,	 x.[First Exposure Claimant]
	,	 x.[Loss Country]
	,	 x.[Severity]
	,	 x.[Claim Event Code]
	,	 x.[Event Description]
	,	 x.[TPA Claim Number]
	,	 x.[Cause of Loss3]
	,	 x.[Loss City]
	,	 x.[Loss State]
	,	 x.[Region]
	,	 x.[Loss Region]
	,	 x.[Cause of Loss 1 Other Description]
	,	 x.[Cause of Loss 2 Other Description]
	,	 x.[Cause of Loss 3 Other Description]
	,	 x.[Cause of Loss 4 Other Description]    
	,	 x.[Cause Of Loss5]                       
	,	 x.[Loss Code Group]                      
	,	 x.[Organization]                         
	,	 x.[Cyber Consideration]                  
	,	 x.[Cyber Consideration Other Description]
	,	 x.[Ransomware Aspect]  
	,	 x.[Batched Claim]	
	,	 x.[Block File]
	,	 x.[Loss Fund]	
	,	 x.[Policy number]
	,	 x.[Coverage Name]
	,	 x.[Business Sub Component]
	,	 x.[Business Component]
	,	 x.[Insured Name]
	,	 x.[Branch]
	,	 x.[Location ID]
	,	 x.[Total Inr curr(Gross)]
	,	 x.[Broker Name]
	,	 x.[Underwriter]
	,	 x.[Risk engineer]
	,	 x.[LIU Share]
	,	ROW_NUMBER() OVER (PARTITION BY x.[Claim Number], x.[Coverage Name] ORDER BY x.[Claim Create Date]) AS RowNum
	FROM
	(
		SELECT 
		 [Catastrophe Code]
	,	 [Catastrophe Description]
	,	 [Cause of Loss 1]
	,	 [Cause of Loss 4 - Type]
	,	 [Cause Of Loss2]
	,	 [Claim Closure Reason]
	,	 [Claim Create Date]
	,	 [Claim Current State]
	,	 [Claim Description]
	,	 [Claim Handler]
	,	 [Claim Number]
	,	 [Claim Title]
	,	 [Claim Type]
	,	 [Date Last Closed]
	,	 [Date Last Reopened]
	,	 [Date Of Loss]
	,	 [Date Reported/Event]
	,	 [First Exposure Claimant]
	,	 [Loss Country]
	,	 [Severity]
	,	 [Claim Event Code]
	,	 [Event Description]
	,	 [TPA Claim Number]
	,	 [Cause of Loss3]
	,	 [Loss City]
	,	 [Loss State]
	,	 [Region]
	,	 [Loss Region]
	,	 [Cause of Loss 1 Other Description]
	,	 [Cause of Loss 2 Other Description]
	,	 [Cause of Loss 3 Other Description]
	,	 [Cause of Loss 4 Other Description]    
	,	 [Cause Of Loss5]                       
	,	 [Loss Code Group]                      
	,	 [Organization]                         
	,	 [Cyber Consideration]                  
	,	 [Cyber Consideration Other Description]
	,	 [Ransomware Aspect] 
	,	 [Batched Claim]	
	,	 [Block File]
	,	 [Loss Fund]	
	,	 [Policy number]
	,	 [Coverage Name]
	,	 [Business Sub Component]
	,	 [Business Component]
	,	 [Insured Name]
	,	 [Branch]
	,	 [Location ID]
	,	 SUM([Total Inr curr(Gross)]) [Total Inr curr(Gross)]
	,	 [Broker Name]
	,	 [Underwriter]
	,	 [Risk engineer]
	,	 [LIU Share]
		FROM [dbo].[CBIClaimListing] 
	group by 
		 [Catastrophe Code]
	,	 [Catastrophe Description]
	,	 [Cause of Loss 1]
	,	 [Cause of Loss 4 - Type]
	,	 [Cause Of Loss2]
	,	 [Claim Closure Reason]
	,	 [Claim Create Date]
	,	 [Claim Current State]
	,	 [Claim Description]
	,	 [Claim Handler]
	,	 [Claim Number]
	,	 [Claim Title]
	,	 [Claim Type]
	,	 [Date Last Closed]
	,	 [Date Last Reopened]
	,	 [Date Of Loss]
	,	 [Date Reported/Event]
	,	 [First Exposure Claimant]
	,	 [Loss Country]
	,	 [Severity]
	,	 [Claim Event Code]
	,	 [Event Description]
	,	 [TPA Claim Number]
	,	 [Cause of Loss3]
	,	 [Loss City]
	,	 [Loss State]
	,	 [Region]
	,	 [Loss Region]
	,	 [Cause of Loss 1 Other Description]
	,	 [Cause of Loss 2 Other Description]
	,	 [Cause of Loss 3 Other Description]
	,	 [Cause of Loss 4 Other Description]    
	,	 [Cause Of Loss5]                       
	,	 [Loss Code Group]                      
	,	 [Organization]                         
	,	 [Cyber Consideration]                  
	,	 [Cyber Consideration Other Description]
	,	 [Ransomware Aspect]  
	,	 [Batched Claim]	
	,	 [Block File]
	,	 [Loss Fund]	
	,	 [Policy number]
	,	 [Coverage Name]
	,	 [Business Sub Component]
	,	 [Business Component]
	,	 [Insured Name]
	,	 [Branch]
	,	 [Location ID]
	,	 [Broker Name]
	,	 [Underwriter]
	,	 [Risk engineer]
	,	 [LIU Share]
	) x
) y 
where y.RowNum=1
ORDER BY 
UPPER(LTRIM(RTRIM(y.[Claim Number]))), UPPER(LTRIM(RTRIM(isnull(y.[Coverage Name],'<<Unknown>>'))))
COLLATE Latin1_General_CI_AS

SELECT 
	 [Catastrophe Code]
,	 [Catastrophe Description]
,	 [Cause of Loss 1]
,	 [Cause of Loss 4 - Type]
,	 [Cause Of Loss2]
,	 [Claim Closure Reason]
,	 [Claim Create Date]
,	 [Claim Current State]
,	 [Claim Description]
,	 [Claim Handler]
,	 UPPER(LTRIM(RTRIM([Claim Number]))) [Claim Number]
,	 [Claim Title]
,	 [Claim Type]
,	 [Date Last Closed]
,	 [Date Last Reopened]
,	 [Date Of Loss]
,	 [Date Reported/Event]
,	 [First Exposure Claimant]
,	 [Loss Country]
,	 [Severity]
,	 [Claim Event Code]
,	 [Event Description]
,	 [TPA Claim Number]
,	 [Cause of Loss3]
,	 [Loss City]
,	 [Loss State]
,	 [Region]
,	 [Loss Region]
,	 [Cause of Loss 1 Other Description]
,	 [Cause of Loss 2 Other Description]
,	 [Cause of Loss 3 Other Description]
,	 [Cause of Loss 4 Other Description]    
,	 [Cause Of Loss5]                       
,	 [Loss Code Group]                      
,	 [Organization]                         
,	 [Cyber Consideration]                  
,	 [Cyber Consideration Other Description]
,	 [Ransomware Aspect]
,	 [Batched Claim]	
,	 [Block File]
,	 [Loss Fund]
,	 [Policy number]
,	 UPPER(LTRIM(RTRIM(ISNULL([Coverage Name],'<<Unknown>>')))) [Coverage Name]
,	 [Business Sub Component]
,	 [Business Component]
,	 [Insured Name]
,	 [Branch]
,	 [Location ID]
,	 [Total Inr curr(Gross)]
,	 [Broker Name]
,	 [Underwriter]
,	 [Risk engineer]
,	 [LIU Share]
,	 [_LastAction]
into #tab2
FROM 
ODS_GENIUS.[dbo].[CBIClaimListing]
ORDER BY UPPER(LTRIM(RTRIM([Claim Number]))), UPPER(LTRIM(RTRIM(ISNULL([Coverage Name],'<<Unknown>>'))))
COLLATE Latin1_General_CI_AS





select [Claim Number],  [Coverage Name],  [Policy number] , count(*)  duplicates_qty
from Staging_GENIUS.dbo.CBIClaimListing
where [Claim Number]='100-1'
group by [Claim Number],  [Coverage Name], [Policy number]
having count(*) > 1
order by [Claim Number] 

select [Claim Number],  [Coverage Name],   count(*)  duplicates_qty
from #tab1
group by [Claim Number],  [Coverage Name]
having count(*) > 1
order by [Claim Number]


select [Claim Number],  [Coverage Name],   count(*)  duplicates_qty
from #tab2
group by [Claim Number],  [Coverage Name]
having count(*) > 1
order by [Claim Number]



select [Claim Number],  [Coverage Name],*
from ODS_GENIUS.[WORK].[CBIClaimListing_pp] (nolock) where _LastAction='U'


select [Claim Number],  [Coverage Name],   count(*)  duplicates_qty
from ODS_GENIUS.[WORK].[CBIClaimListing] (nolock)
group by [Claim Number],  [Coverage Name]
having count(*) > 1
order by [Claim Number]

select [Claim Number], [Coverage Name], * from Staging_GENIUS.dbo.CBIClaimListing sc where [Coverage Name] is null

select [Claim Number],[Coverage Name],* 
--update sc set [Coverage Name]='<<Unknown>>'
from Staging_GENIUS.dbo.CBIClaimListing sc where [Claim Number] in ('100-1','200-1')


select 'Staging_Genius' DB,[Claim Number],  [Coverage Name],
[Catastrophe Code], [Catastrophe Description], [Cause of Loss 1], [Cause of Loss 4 - Type], [Cause Of Loss2], [Claim Closure Reason], [Claim Create Date], [Claim Current State], [Claim Description], [Claim Handler], [Claim Number], [Claim Title], [Claim Type], [Date Last Closed], [Date Last Reopened], [Date Of Loss], [Date Reported/Event], [First Exposure Claimant], [Loss Country], [Severity], [Claim Event Code], [Event Description], [TPA Claim Number], [Cause of Loss3], [Loss City], [Loss State], [Region], [Loss Region], [Cause of Loss 1 Other Description], [Cause of Loss 2 Other Description], [Cause of Loss 3 Other Description], [Cause of Loss 4 Other Description], [Cause Of Loss5], [Loss Code Group], [Organization], [Cyber Consideration], [Cyber Consideration Other Description], [Ransomware Aspect], [Batched Claim], [Block File], [Loss Fund], [Policy number], [Coverage Name], [Business Sub Component], [Business Component], [Insured Name], [Branch], [Location ID], [Total Inr curr(Gross)], [Broker Name], [Underwriter], [Risk engineer], [LIU Share]
from Staging_GENIUS.dbo.CBIClaimListing cl where [Claim Number] in ('0-008','01-MCG-0001','01806-001','155001100-A')
order by cl.[Claim Number]

--select 'Source' DB,[Claim Number],  [Coverage Name],
--[Catastrophe Code], [Catastrophe Description], [Cause of Loss 1], [Cause of Loss 4 - Type], [Cause Of Loss2], [Claim Closure Reason], [Claim Create Date], [Claim Current State], [Claim Description], [Claim Handler], [Claim Number], [Claim Title], [Claim Type], [Date Last Closed], [Date Last Reopened], [Date Of Loss], [Date Reported/Event], [First Exposure Claimant], [Loss Country], [Severity], [Claim Event Code], [Event Description], [TPA Claim Number], [Cause of Loss3], [Loss City], [Loss State], [Region], [Loss Region], [Cause of Loss 1 Other Description], [Cause of Loss 2 Other Description], [Cause of Loss 3 Other Description], [Cause of Loss 4 Other Description], [Cause Of Loss5], [Loss Code Group], [Organization], [Cyber Consideration], [Cyber Consideration Other Description], [Ransomware Aspect], [Batched Claim], [Block File], [Loss Fund], [Policy number], [Coverage Name], [Business Sub Component], [Business Component], [Insured Name], [Branch], [Location ID], [Total Inr curr(Gross)], [Broker Name], [Underwriter], [Risk engineer], [LIU Share]
--from #tab1 cl where [Claim Number] in ('100-1','01-MCG-0001','080000544-1')
--order by cl.[Claim Number]


select top 1000 'ODS_Genius' DB,_lastAction,[Claim Number],  [Coverage Name], 
[Catastrophe Code], [Catastrophe Description], [Cause of Loss 1], [Cause of Loss 4 - Type], [Cause Of Loss2], [Claim Closure Reason], [Claim Create Date], [Claim Current State], [Claim Description], [Claim Handler], [Claim Number], [Claim Title], [Claim Type], [Date Last Closed], [Date Last Reopened], [Date Of Loss], [Date Reported/Event], [First Exposure Claimant], [Loss Country], [Severity], [Claim Event Code], [Event Description], [TPA Claim Number], [Cause of Loss3], [Loss City], [Loss State], [Region], [Loss Region], [Cause of Loss 1 Other Description], [Cause of Loss 2 Other Description], [Cause of Loss 3 Other Description], [Cause of Loss 4 Other Description], [Cause Of Loss5], [Loss Code Group], [Organization], [Cyber Consideration], [Cyber Consideration Other Description], [Ransomware Aspect], [Batched Claim], [Block File], [Loss Fund], [Policy number], [Coverage Name], [Business Sub Component], [Business Component], [Insured Name], [Branch], [Location ID], [Total Inr curr(Gross)], [Broker Name], [Underwriter], [Risk engineer], [LIU Share]
from ODS_GENIUS.dbo.CBIClaimListing cl --where [Claim Number] in ('0-008','01-MCG-0001','01806-001','155001100-A')
order by cl.[Claim Number]


select 'ODS_Genius_Work' DB, _lastAction,[Claim Number],  [Coverage Name], [SourceCheckSum], [TargetCheckSum],
[Catastrophe Code], [Catastrophe Description], [Cause of Loss 1], [Cause of Loss 4 - Type], [Cause Of Loss2], [Claim Closure Reason], [Claim Create Date], [Claim Current State], [Claim Description], [Claim Handler], [Claim Number], [Claim Title], [Claim Type], [Date Last Closed], [Date Last Reopened], [Date Of Loss], [Date Reported/Event], [First Exposure Claimant], [Loss Country], [Severity], [Claim Event Code], [Event Description], [TPA Claim Number], [Cause of Loss3], [Loss City], [Loss State], [Region], [Loss Region], [Cause of Loss 1 Other Description], [Cause of Loss 2 Other Description], [Cause of Loss 3 Other Description], [Cause of Loss 4 Other Description], [Cause Of Loss5], [Loss Code Group], [Organization], [Cyber Consideration], [Cyber Consideration Other Description], [Ransomware Aspect], [Batched Claim], [Block File], [Loss Fund], [Policy number], [Coverage Name], [Business Sub Component], [Business Component], [Insured Name], [Branch], [Location ID], [Total Inr curr(Gross)], [Broker Name], [Underwriter], [Risk engineer], [LIU Share]
from ODS_GENIUS.[WORK].[CBIClaimListing] cl (nolock) where [Claim Number] in ('0-008','01-MCG-0001','01806-001','155001100-A')
order by cl.[Claim Number]





select * from Staging_GENIUS.dbo.CBIClaimListing  s
join ODS_GENIUS.[WORK].[CBIClaimListing] o on o.[Claim Number] = s.[Claim Number] and o.[Coverage Name] = s.[Coverage Name]
where o.[Claim Number] in ('100-1','01-MCG-0001','05005-001')


select 'ODS_Genius_Work' DB, _lastAction,[Claim Number],  [Coverage Name], [SourceCheckSum], [TargetCheckSum],* 
from ODS_GENIUS.[WORK].[CBIClaimListing] o where _LastAction='U'



select top 1000 t1.[Claim Number],  t1.[Coverage Name],HASHBYTES('MD5', ltrim(rtrim(t1.[Claim Number])) + ltrim(rtrim(t1.[Coverage Name]))) '=========',
t2.[Claim Number],  t2.[Coverage Name],HASHBYTES('MD5', ltrim(rtrim(t2.[Claim Number])) + ltrim(rtrim(t2.[Coverage Name]))) 
from #tab1 t1 
full outer join #tab2 t2 on t2.[Claim Number] = t1.[Claim Number] and t2.[Coverage Name] = t1.[Coverage Name]
where --HASHBYTES('MD5', ltrim(rtrim(t1.[Claim Number])) + ltrim(rtrim(t1.[Coverage Name]))) <> HASHBYTES('MD5', ltrim(rtrim(t2.[Claim Number])) + ltrim(rtrim(t2.[Coverage Name]))) 
 t1.[Claim Number] in ('100-1','01-MCG-0001','080000544-1')





 --Testowe Claimy

 00-CAS-0001-CJ  --Update Cause of Loss 4 - Type: z "Operations" na "Operations ---"
 00-SPC-0043 --usuniecie z Stagingu
 01991*-001 , Program Med Mal DAT -- utworzenie podobnego Claima z innym Coverage Name  'Program Medical Mal DAT'


 select top 1000 'Staging_Genius' DB,[Claim Number],  [Coverage Name], 
[Catastrophe Code], [Catastrophe Description], [Cause of Loss 1], [Cause of Loss 4 - Type], [Cause Of Loss2], [Claim Closure Reason], [Claim Create Date], [Claim Current State], [Claim Description], [Claim Handler], [Claim Number], [Claim Title], [Claim Type], [Date Last Closed], [Date Last Reopened], [Date Of Loss], [Date Reported/Event], [First Exposure Claimant], [Loss Country], [Severity], [Claim Event Code], [Event Description], [TPA Claim Number], [Cause of Loss3], [Loss City], [Loss State], [Region], [Loss Region], [Cause of Loss 1 Other Description], [Cause of Loss 2 Other Description], [Cause of Loss 3 Other Description], [Cause of Loss 4 Other Description], [Cause Of Loss5], [Loss Code Group], [Organization], [Cyber Consideration], [Cyber Consideration Other Description], [Ransomware Aspect], [Batched Claim], [Block File], [Loss Fund], [Policy number], [Coverage Name], [Business Sub Component], [Business Component], [Insured Name], [Branch], [Location ID], [Total Inr curr(Gross)], [Broker Name], [Underwriter], [Risk engineer], [LIU Share]
--update cl set [Cause of Loss 4 - Type] = 'Operations ---'
from Staging_GENIUS.dbo.CBIClaimListing cl where [Claim Number] in ('00-CAS-0001-CJ')
order by cl.[Claim Number]

 select top 1000 'ODS_Genius' DB,_lastAction,[Claim Number],  [Coverage Name], 
[Catastrophe Code], [Catastrophe Description], [Cause of Loss 1], [Cause of Loss 4 - Type], [Cause Of Loss2], [Claim Closure Reason], [Claim Create Date], [Claim Current State], [Claim Description], [Claim Handler], [Claim Number], [Claim Title], [Claim Type], [Date Last Closed], [Date Last Reopened], [Date Of Loss], [Date Reported/Event], [First Exposure Claimant], [Loss Country], [Severity], [Claim Event Code], [Event Description], [TPA Claim Number], [Cause of Loss3], [Loss City], [Loss State], [Region], [Loss Region], [Cause of Loss 1 Other Description], [Cause of Loss 2 Other Description], [Cause of Loss 3 Other Description], [Cause of Loss 4 Other Description], [Cause Of Loss5], [Loss Code Group], [Organization], [Cyber Consideration], [Cyber Consideration Other Description], [Ransomware Aspect], [Batched Claim], [Block File], [Loss Fund], [Policy number], [Coverage Name], [Business Sub Component], [Business Component], [Insured Name], [Branch], [Location ID], [Total Inr curr(Gross)], [Broker Name], [Underwriter], [Risk engineer], [LIU Share]
from ODS_GENIUS.dbo.CBIClaimListing cl where [Claim Number] in ('00-CAS-0001-CJ')
order by cl.[Claim Number]

-- USUNIECIE 00-SPC-0043
 select top 1000 'Staging_Genius' DB,[Claim Number],  [Coverage Name], 
[Catastrophe Code], [Catastrophe Description], [Cause of Loss 1], [Cause of Loss 4 - Type], [Cause Of Loss2], [Claim Closure Reason], [Claim Create Date], [Claim Current State], [Claim Description], [Claim Handler], [Claim Number], [Claim Title], [Claim Type], [Date Last Closed], [Date Last Reopened], [Date Of Loss], [Date Reported/Event], [First Exposure Claimant], [Loss Country], [Severity], [Claim Event Code], [Event Description], [TPA Claim Number], [Cause of Loss3], [Loss City], [Loss State], [Region], [Loss Region], [Cause of Loss 1 Other Description], [Cause of Loss 2 Other Description], [Cause of Loss 3 Other Description], [Cause of Loss 4 Other Description], [Cause Of Loss5], [Loss Code Group], [Organization], [Cyber Consideration], [Cyber Consideration Other Description], [Ransomware Aspect], [Batched Claim], [Block File], [Loss Fund], [Policy number], [Coverage Name], [Business Sub Component], [Business Component], [Insured Name], [Branch], [Location ID], [Total Inr curr(Gross)], [Broker Name], [Underwriter], [Risk engineer], [LIU Share]
--delete from cl
from Staging_GENIUS.dbo.CBIClaimListing cl where [Claim Number] in ('00-SPC-0043')
order by cl.[Claim Number]


 select top 1000 'ODS_Genius' DB,_lastAction,[Claim Number],  [Coverage Name], 
[Catastrophe Code], [Catastrophe Description], [Cause of Loss 1], [Cause of Loss 4 - Type], [Cause Of Loss2], [Claim Closure Reason], [Claim Create Date], [Claim Current State], [Claim Description], [Claim Handler], [Claim Number], [Claim Title], [Claim Type], [Date Last Closed], [Date Last Reopened], [Date Of Loss], [Date Reported/Event], [First Exposure Claimant], [Loss Country], [Severity], [Claim Event Code], [Event Description], [TPA Claim Number], [Cause of Loss3], [Loss City], [Loss State], [Region], [Loss Region], [Cause of Loss 1 Other Description], [Cause of Loss 2 Other Description], [Cause of Loss 3 Other Description], [Cause of Loss 4 Other Description], [Cause Of Loss5], [Loss Code Group], [Organization], [Cyber Consideration], [Cyber Consideration Other Description], [Ransomware Aspect], [Batched Claim], [Block File], [Loss Fund], [Policy number], [Coverage Name], [Business Sub Component], [Business Component], [Insured Name], [Branch], [Location ID], [Total Inr curr(Gross)], [Broker Name], [Underwriter], [Risk engineer], [LIU Share]
from ODS_GENIUS.dbo.CBIClaimListing cl where [Claim Number] in ('00-CAS-0001-CJ')
order by cl.[Claim Number]


-- Dodanie nowej 01991*-001
--insert into Staging_GENIUS.dbo.CBIClaimListing ([Claim Number],  [Coverage Name], [Catastrophe Code], [Catastrophe Description], [Cause of Loss 1], [Cause of Loss 4 - Type], [Cause Of Loss2], [Claim Closure Reason], [Claim Create Date], [Claim Current State], [Claim Description], [Claim Handler], [Claim Title], [Claim Type], [Date Last Closed], [Date Last Reopened], [Date Of Loss], [Date Reported/Event], [First Exposure Claimant], [Loss Country], [Severity], [Claim Event Code], [Event Description], [TPA Claim Number], [Cause of Loss3], [Loss City], [Loss State], [Region], [Loss Region], [Cause of Loss 1 Other Description], [Cause of Loss 2 Other Description], [Cause of Loss 3 Other Description], [Cause of Loss 4 Other Description], [Cause Of Loss5], [Loss Code Group], [Organization], [Cyber Consideration], [Cyber Consideration Other Description], [Ransomware Aspect], [Batched Claim], [Block File], [Loss Fund], [Policy number],  [Business Sub Component], [Business Component], [Insured Name], [Branch], [Location ID], [Total Inr curr(Gross)], [Broker Name], [Underwriter], [Risk engineer], [LIU Share])
select top 1 [Claim Number],  'Program Medical Mal DAT',[Catastrophe Code], [Catastrophe Description], [Cause of Loss 1], [Cause of Loss 4 - Type], [Cause Of Loss2], [Claim Closure Reason], [Claim Create Date], [Claim Current State], [Claim Description], [Claim Handler], [Claim Title], [Claim Type], [Date Last Closed], [Date Last Reopened], [Date Of Loss], [Date Reported/Event], [First Exposure Claimant], [Loss Country], [Severity], [Claim Event Code], [Event Description], [TPA Claim Number], [Cause of Loss3], [Loss City], [Loss State], [Region], [Loss Region], [Cause of Loss 1 Other Description], [Cause of Loss 2 Other Description], [Cause of Loss 3 Other Description], [Cause of Loss 4 Other Description], [Cause Of Loss5], [Loss Code Group], [Organization], [Cyber Consideration], [Cyber Consideration Other Description], [Ransomware Aspect], [Batched Claim], [Block File], [Loss Fund], [Policy number], [Business Sub Component], [Business Component], [Insured Name], [Branch], [Location ID], [Total Inr curr(Gross)], [Broker Name], [Underwriter], [Risk engineer], [LIU Share]
from Staging_GENIUS.dbo.CBIClaimListing cl where [Claim Number] in ('01991*-001') and [Coverage Name] ='Program Med Mal DAT' and [Total Inr curr(Gross)] >0
order by cl.[Claim Number]


 select top 1000 'ODS_Genius' DB,_lastAction,[Claim Number],  [Coverage Name], 
[Catastrophe Code], [Catastrophe Description], [Cause of Loss 1], [Cause of Loss 4 - Type], [Cause Of Loss2], [Claim Closure Reason], [Claim Create Date], [Claim Current State], [Claim Description], [Claim Handler], [Claim Number], [Claim Title], [Claim Type], [Date Last Closed], [Date Last Reopened], [Date Of Loss], [Date Reported/Event], [First Exposure Claimant], [Loss Country], [Severity], [Claim Event Code], [Event Description], [TPA Claim Number], [Cause of Loss3], [Loss City], [Loss State], [Region], [Loss Region], [Cause of Loss 1 Other Description], [Cause of Loss 2 Other Description], [Cause of Loss 3 Other Description], [Cause of Loss 4 Other Description], [Cause Of Loss5], [Loss Code Group], [Organization], [Cyber Consideration], [Cyber Consideration Other Description], [Ransomware Aspect], [Batched Claim], [Block File], [Loss Fund], [Policy number], [Coverage Name], [Business Sub Component], [Business Component], [Insured Name], [Branch], [Location ID], [Total Inr curr(Gross)], [Broker Name], [Underwriter], [Risk engineer], [LIU Share]
from ODS_GENIUS.dbo.CBIClaimListing cl where [Claim Number] in ('01991*-001') and [Coverage Name] ='Program Med Mal DAT'
order by cl.[Claim Number]


--Przed testem


select top 1000 'Staging_Genius' DB,[Claim Number],  [Coverage Name], 
[Catastrophe Code], [Catastrophe Description], [Cause of Loss 1], [Cause of Loss 4 - Type], [Cause Of Loss2], [Claim Closure Reason], [Claim Create Date], [Claim Current State], [Claim Description], [Claim Handler], [Claim Number], [Claim Title], [Claim Type], [Date Last Closed], [Date Last Reopened], [Date Of Loss], [Date Reported/Event], [First Exposure Claimant], [Loss Country], [Severity], [Claim Event Code], [Event Description], [TPA Claim Number], [Cause of Loss3], [Loss City], [Loss State], [Region], [Loss Region], [Cause of Loss 1 Other Description], [Cause of Loss 2 Other Description], [Cause of Loss 3 Other Description], [Cause of Loss 4 Other Description], [Cause Of Loss5], [Loss Code Group], [Organization], [Cyber Consideration], [Cyber Consideration Other Description], [Ransomware Aspect], [Batched Claim], [Block File], [Loss Fund], [Policy number], [Coverage Name], [Business Sub Component], [Business Component], [Insured Name], [Branch], [Location ID], [Total Inr curr(Gross)], [Broker Name], [Underwriter], [Risk engineer], [LIU Share]
from Staging_GENIUS.dbo.CBIClaimListing cl where [Claim Number] in ('00-CAS-0001-CJ','01991*-001', '00-SPC-0043','CHIHUL000123357')
order by cl.[Claim Number]

select top 1000 'ODS_Genius' DB,_lastAction,[Claim Number],  [Coverage Name], 
[Catastrophe Code], [Catastrophe Description], [Cause of Loss 1], [Cause of Loss 4 - Type], [Cause Of Loss2], [Claim Closure Reason], [Claim Create Date], [Claim Current State], [Claim Description], [Claim Handler], [Claim Number], [Claim Title], [Claim Type], [Date Last Closed], [Date Last Reopened], [Date Of Loss], [Date Reported/Event], [First Exposure Claimant], [Loss Country], [Severity], [Claim Event Code], [Event Description], [TPA Claim Number], [Cause of Loss3], [Loss City], [Loss State], [Region], [Loss Region], [Cause of Loss 1 Other Description], [Cause of Loss 2 Other Description], [Cause of Loss 3 Other Description], [Cause of Loss 4 Other Description], [Cause Of Loss5], [Loss Code Group], [Organization], [Cyber Consideration], [Cyber Consideration Other Description], [Ransomware Aspect], [Batched Claim], [Block File], [Loss Fund], [Policy number], [Coverage Name], [Business Sub Component], [Business Component], [Insured Name], [Branch], [Location ID], [Total Inr curr(Gross)], [Broker Name], [Underwriter], [Risk engineer], [LIU Share]
from ODS_GENIUS.dbo.CBIClaimListing cl where [Claim Number] in ('00-CAS-0001-CJ','01991*-001', '00-SPC-0043','CHIHUL000123357')
order by cl.[Claim Number]



--W trakcie testu 



select 'ODS_Genius_Work' DB, _lastAction,[Claim Number],  [Coverage Name], [SourceCheckSum], [TargetCheckSum],
[Catastrophe Code], [Catastrophe Description], [Cause of Loss 1], [Cause of Loss 4 - Type], [Cause Of Loss2], [Claim Closure Reason], [Claim Create Date], [Claim Current State], [Claim Description], [Claim Handler], [Claim Number], [Claim Title], [Claim Type], [Date Last Closed], [Date Last Reopened], [Date Of Loss], [Date Reported/Event], [First Exposure Claimant], [Loss Country], [Severity], [Claim Event Code], [Event Description], [TPA Claim Number], [Cause of Loss3], [Loss City], [Loss State], [Region], [Loss Region], [Cause of Loss 1 Other Description], [Cause of Loss 2 Other Description], [Cause of Loss 3 Other Description], [Cause of Loss 4 Other Description], [Cause Of Loss5], [Loss Code Group], [Organization], [Cyber Consideration], [Cyber Consideration Other Description], [Ransomware Aspect], [Batched Claim], [Block File], [Loss Fund], [Policy number], [Coverage Name], [Business Sub Component], [Business Component], [Insured Name], [Branch], [Location ID], [Total Inr curr(Gross)], [Broker Name], [Underwriter], [Risk engineer], [LIU Share]
from ODS_GENIUS.[WORK].[CBIClaimListing] cl (nolock) where [Claim Number] in ('00-CAS-0001-CJ','01991*-001', '00-SPC-0043','155001100-A')
order by cl.[Claim Number]



select 'ODS_Genius_Work' DB, _lastAction,[Claim Number],  [Coverage Name], [SourceCheckSum], [TargetCheckSum],
[Catastrophe Code], [Catastrophe Description], [Cause of Loss 1], [Cause of Loss 4 - Type], [Cause Of Loss2], [Claim Closure Reason], [Claim Create Date], [Claim Current State], [Claim Description], [Claim Handler], [Claim Number], [Claim Title], [Claim Type], [Date Last Closed], [Date Last Reopened], [Date Of Loss], [Date Reported/Event], [First Exposure Claimant], [Loss Country], [Severity], [Claim Event Code], [Event Description], [TPA Claim Number], [Cause of Loss3], [Loss City], [Loss State], [Region], [Loss Region], [Cause of Loss 1 Other Description], [Cause of Loss 2 Other Description], [Cause of Loss 3 Other Description], [Cause of Loss 4 Other Description], [Cause Of Loss5], [Loss Code Group], [Organization], [Cyber Consideration], [Cyber Consideration Other Description], [Ransomware Aspect], [Batched Claim], [Block File], [Loss Fund], [Policy number], [Coverage Name], [Business Sub Component], [Business Component], [Insured Name], [Branch], [Location ID], [Total Inr curr(Gross)], [Broker Name], [Underwriter], [Risk engineer], [LIU Share]
from ODS_GENIUS.[WORK].[CBIClaimListing] cl (nolock) where _LastAction= 'U'
order by cl.[Claim Number]