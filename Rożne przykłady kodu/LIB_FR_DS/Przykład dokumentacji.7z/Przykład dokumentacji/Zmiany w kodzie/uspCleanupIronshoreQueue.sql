﻿


CREATE PROCEDURE [FinancialRisks].[uspCleanupIronshoreQueue]
AS
/********************************************************************************************/

-- Get distinct list of all possible country names and their ids
SELECT CountryID, CountryName,CountryPseudonymId into #country from
(
	SELECT CountryId, CountryName,''as CountryPseudonymId
	FROM FinancialRisks.Countries
	UNION
	SELECT CountryId, CountryPseudonym AS CountryName,CountryPseudonymId
	FROM FinancialRisks.CountryPseudonym
)a

UPDATE [FinancialRisks].[Ironshore_Data_Queue]
set [countryId] =countries.CountryID
,CountryPseudID=countries.CountryPseudonymId
FROM [FinancialRisks].[Ironshore_Data_Queue] eq
INNER JOIN #country countries on countries.CountryName = LTRIM(RTRIM(eq.country))


Declare @countryid int 
SET @countryid = (Select CountryID from  [FinancialRisks].[Countries]
where CountryName = 'No country name supplied')

UPDATE [FinancialRisks].[Ironshore_Data_Queue]
   SET [countryId] = @countryid
  where
  country is null or country =''

-- Get distinct list of all possible obligor names and their ids
select ObligorID, LTRIM(RTRIM(ObligorName)) as 'ObligorName',ObligorPseudonymId into  #Obligors from
(
	SELECT EntityId as ObligorId, LTRIM(RTRIM(EntityName)) as ObligorName ,'' as ObligorPseudonymId
	FROM FinancialRisks.Entities
	UNION
	SELECT ObligorId, LTRIM(RTRIM(ObligorPseudonym)) as ObligorName,ObligorPseudonymId
	FROM FinancialRisks.ObligorPseudonym
)b

--Map those with valid IDS
UPDATE [FinancialRisks].[Ironshore_Data_Queue]
set entityId =obligors.ObligorID
,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[Ironshore_Data_Queue] eq
INNER JOIN #Obligors obligors on obligors.ObligorName = LTRIM(RTRIM(eq.obligor))

SELECT QueueId, 
	   LTRIM(RTRIM([riskReference]))  [riskReference]
      ,CASE 
	  WHEN LTRIM(RTRIM([TransactionType])) in ('MTSB','STSB','RCF','STF','MB','SS') THEN 'CR'
	  when LTRIM(RTRIM([TransactionType])) = 'PRI' THEN 'PR'
	  else LTRIM(RTRIM([TransactionType])) end as [RiskCode]
      ,[obligor]
	  ,EntityId
      ,IDQ.[Country]
	  ,CountryID
      ,[LimitLiability]
      ,[inception_date]
      ,[expiry_date]
	  ,[insured]
      ,IDQ.[InforceDate]
	  ,IDQ.[UserNotified]
	  ,[GrossExposure]
	  ,ObligorPseudID
	  ,CountryPseudID
	  into #TempTable
  FROM 
  [FinancialRisks].[Ironshore_Data_Queue] IDQ
  where ISNUMERIC(EntityId) = 1 
  and  ISNUMERIC(CountryID) =1 

  INSERT INTO [FinancialRisks].[Ironshore_Data]
           ([riskReference]
           ,[country]
           ,[countryId]
           ,[inception_date]
           ,[expiry_date]
           ,[obligor]
           ,[entityId]
           ,[GrossExposure]
           ,[LimitLiability]
           ,[Insured]
           ,[RiskCode]
           ,[InforceDate]	  
		   ,ObligorPseudID
		   ,CountryPseudID)
		   Select 
		   [riskReference]
           ,[country]
           ,[countryId]
           ,[inception_date]
           ,[expiry_date]
           ,[obligor]
           ,[entityId]
           ,[GrossExposure]
           ,[LimitLiability]
           ,[Insured]
           ,[RiskCode]
           ,[InforceDate]	  
		   ,ObligorPseudID
		   ,CountryPseudID
		 FROM #TempTable

DELETE FROM [FinancialRisks].[Ironshore_Data_Queue]
WHERE QueueId IN (SELECT QueueId FROM #TempTable)

DROP TABLE #TempTable
DROP TABLE #Obligors
DROP TABLE #country