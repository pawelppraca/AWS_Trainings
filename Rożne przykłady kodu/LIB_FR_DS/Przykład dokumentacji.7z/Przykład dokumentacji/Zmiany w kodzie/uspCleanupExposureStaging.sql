﻿CREATE PROCEDURE [FinancialRisks].[uspCleanupExposureStaging] @CobId INT
AS

/********************************************************************************************/
-- Get distinct list of all possible country names and their ids
SELECT CountryID, CountryName,CountryPseudonymId into #country from
(
	SELECT CountryId, CountryName,''as CountryPseudonymId
	FROM FinancialRisks.Countries
	UNION
	SELECT CountryId, CountryPseudonym AS CountryName,CountryPseudonymId
	FROM FinancialRisks.CountryPseudonym
)a

UPDATE [FinancialRisks].[ExposuresQueue]
set [CountryName] =countries.CountryID
,CountryPseudID=countries.CountryPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #country countries on countries.CountryName = LTRIM(RTRIM(eq.CountryName))
  WHERE [Status] = 'NEW'
  AND [CobId] = @CobId

Declare @countryid int 
SET @countryid = (Select CountryID from  [FinancialRisks].[Countries]
where CountryName = 'No country name supplied')

IF @CobId<> 6
begin


UPDATE [FinancialRisks].[ExposuresQueue]
   SET [CountryName] = @countryid
  where
  [CountryName] is null  or [CountryName] =''
END
/********************************************************************************************/

-- Get distinct list of all possible obligor names and their ids
select ObligorID, ltrim(rtrim(ObligorName)) as 'ObligorName',ObligorPseudonymId,CountryName into  #Obligors from
(
	SELECT EntityId as ObligorId, rtrim(ltrim(EntityName)) as ObligorName ,'' as ObligorPseudonymId,Domicile as 'CountryName'
	FROM FinancialRisks.Entities
	UNION
	SELECT ObligorId, rtrim(ltrim(ObligorPseudonym)) as ObligorName,ObligorPseudonymId,''as 'CountryName'
	FROM FinancialRisks.ObligorPseudonym
)b

--Map those with valid IDS
UPDATE [FinancialRisks].[ExposuresQueue]
set [ObligorEntityName] =obligors.ObligorID
,ObligorPseudID = obligors.ObligorPseudonymId
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #Obligors obligors on obligors.ObligorName = ltrim(rtrim(eq.ObligorEntityName))
  WHERE [Status] = 'NEW'
  AND [CobId] = @CobId
---- Map Countries based on domicile
IF @CobId = 6
begin
	UPDATE [FinancialRisks].[ExposuresQueue]
	set [CountryName] =countries.CountryID
	FROM [FinancialRisks].[ExposuresQueue] eq
	inner join FinancialRisks.Entities ent on ent.EntityId = eq.ObligorEntityName
	INNER JOIN #country countries on countries.CountryName = ltrim(rtrim(ent.Domicile))
	  WHERE [Status] = 'NEW'
	  AND [CobId] = @CobId
	    and ISNUMERIC([ObligorEntityName]) =1

	UPDATE [FinancialRisks].[ExposuresQueue]
    SET [CountryName] = @countryid
    where ([CountryName] is null  or [CountryName] ='')
	and [Status] = 'NEW'
	AND [CobId] = @CobId
	and ISNUMERIC([ObligorEntityName]) =1
end
-----
-- Map non CF with no obligor name supplied to the one obligor
Declare @entityid int 
SET @entityid = (Select EntityID from  [FinancialRisks].[Entities]
where EntityName = 'No obligor name supplied')

UPDATE [FinancialRisks].[ExposuresQueue]
   SET [ObligorEntityName] = @entityid
  where
  ([ObligorEntityName] is null or [ObligorEntityName] = '') and LTRIM(RTRIM([RiskCode])) <> 'CF' 
  and [Status] = 'NEW'
  AND [CobId] = @CobId

-- Map  CF with no obligor name supplied to obligor with CD + Country Name + not supplied
INSERT INTO [FinancialRisks].[Entities]
           ([EntityName])

  Select distinct  'CF '+c.CountryName+' obligor name not supplied' as Name 
  FROM [FinancialRisks].[ExposuresQueue]e
  inner join [FinancialRisks].Countries c on e.CountryName = c.CountryId
  where ([ObligorEntityName] is null or [ObligorEntityName] = '') and LTRIM(RTRIM([RiskCode])) = 'CF' and isnumeric(e.CountryName)=1
  and 'CF '+c.CountryName+' obligor name not supplied' not in (SELECT EntityName as ObligorName
	FROM FinancialRisks.Entities)

  UPDATE [FinancialRisks].[ExposuresQueue]
   SET ObligorEntityName = ent.EntityId
   FROM [FinancialRisks].[ExposuresQueue]e
    inner join [FinancialRisks].Countries c on e.CountryName = c.CountryId
	inner join [FinancialRisks].Entities ent on ent.EntityName ='CF '+c.CountryName+' obligor name not supplied'
	WHERE  ([ObligorEntityName] is null or [ObligorEntityName] = '') and LTRIM(RTRIM([RiskCode])) = 'CF' and  isnumeric(e.CountryName)=1
/********************************************************************************************/
-- Get distinct list of all possible cedant names and their ids
select CedantId,Name into  #Cedants from
(
	SELECT CedantId, Name
	FROM FinancialRisks.Cedant
	
)b

UPDATE [FinancialRisks].[ExposuresQueue]
set cedantName =cedant.[CedantId]
FROM [FinancialRisks].[ExposuresQueue] eq
INNER JOIN #Cedants cedant on cedant.Name = ltrim(rtrim(eq.cedantName))
  WHERE [Status] = 'NEW'
  AND [CobId] = @CobId
/********************************************************************************************/

SELECT 
	   eq.ExposureQueueId,
	   [CedantName]as [CedantId]
      ,[CobId]
      ,LTRIM(RTRIM([RiskReference])) [RiskReference]
      ,[CurrencyId]
      ,[Year]
      ,[DataQuarter]
      ,[AssuredEntityId]
      ,LTRIM(RTRIM([RiskCode])) [RiskCode]
      ,LTRIM(RTRIM([LeadSyndicate])) [LeadSyndicate]
      ,[CountryName]as CountryID
      ,[InceptionDate]
      ,[ExpiryDate]
      ,[Limit]
      ,[UsdLimit]
      ,[GrossPremium]
      ,[GrossExposure]
      ,[ObligorEntityName] AS EntityId
      ,[InforceDate],[source],ObligorPseudID,CountryPseudID,SBU,Office,
	  AssumedLive,NoBillingOffsetTotalSuretyExposureNetPGE,NetSuretyExposure,ProductLine,region,assured,LGDSD_Surety,Max_Cap,Collateral,LocalId
	    INTO #TempTable
  FROM [FinancialRisks].[ExposuresQueue] eq
  where ISNUMERIC([CedantName]) = 1 
  and  ISNUMERIC([CountryName]) =1 
  and ISNUMERIC([ObligorEntityName]) =1
  and    [Status] = 'NEW'
  AND [CobId] = @CobId

  INSERT INTO [FinancialRisks].[Exposures]
           ([CedantId]
           ,[CobId]
           ,[RiskReference]
           ,[CurrencyId]
           ,[Year]
           ,[DataQuarter]
           ,[AssuredEntityId]
           ,[RiskCode]
           ,[LeadSyndicate]
           ,[CountryId]
           ,[InceptionDate]
           ,[ExpiryDate]
           ,[Limit]
           ,[UsdLimit]
           ,[GrossPremium]
           ,[GrossExposure]
           ,[ObligorEntityId]
           ,[InforceDate]
           ,[Source],ObligorPseudID,CountryPseudID,SBU,Office
		   ,AssumedLive,NoBillingOffsetTotalSuretyExposureNetPGE,NetSuretyExposure,ProductLine,region,Assured,LGDSD_Surety,Max_Cap,Collateral,uploaddate,LocalId
)
	 SELECT
	        [CedantId]
           ,[CobId]
           ,[RiskReference]
           ,[CurrencyId]
           ,[Year]
           ,[DataQuarter]
           ,[AssuredEntityId]
           ,[RiskCode]
           ,[LeadSyndicate]
           ,[CountryId]
           ,[InceptionDate]
           ,[ExpiryDate]
           ,[Limit]
           ,[UsdLimit]
           ,[GrossPremium]
           ,[GrossExposure]
           ,EntityId
           ,[InforceDate]
           ,[Source]
		   ,ObligorPseudID,CountryPseudID,SBU,Office
		   	 ,AssumedLive,NoBillingOffsetTotalSuretyExposureNetPGE,NetSuretyExposure,ProductLine,region,assured,LGDSD_Surety,Max_Cap,Collateral,Convert(date, getdate()),LocalId

		FROM   #TempTable

DELETE FROM [FinancialRisks].[ExposuresQueue]
WHERE [ExposureQueueId] IN (SELECT [ExposureQueueId] FROM #TempTable)

DROP TABLE #TempTable
DROP TABLE #Obligors
DROP TABLE #country