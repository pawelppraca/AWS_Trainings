import datetime
import boto3
import json

from datetime import timezone
from dateutil.tz import gettz
from dateutil import tz


ON_PREM_SUCCESS_MSG = "On prem job added to queue"
DEFAULT_SUCCESS_MSG = "Step Function completed successfully"
DEFAULT_ERROR_MSG = "Please check link below for more details"
CAUGHT_ERROR_KEY = "caught_error"
GLUE_JOBS_EXECUTED_MSG = "\t** Glue Jobs executed **\n"
ETL_PHASES = {
    "extract": "Extract",
    "rds_start": "RDS Start",
    "rds_load": "RDS Load",
    "dwh_load": "Warehouse Load",
}
ETL_MSG_TEMPLATE = """TIMINGS ({timezone}):
{etl_timings}

Jobs executed in each phase
EXTRACTION (cloud)
{extraction_details}

RDS LOAD (cloud)
{rds_load_details}

DWH LOAD (on-prem)
{dwh_load_details}
"""
EMAIL_MSG_TEMPLATE = """AWS {env:12} : {source} {phase} {date} - {status}

STEP FUNCTION    : {step_function_name}
EXECUTION NAME   : {execution_name}
DATA SOURCE      : {source}
DURATION         : {duration}
STATUS           : {status}

{body_details}

Full execution history : {execution_link}
"""
GB_TZ = gettz("GB")
CURRENT_TIMEZONE = datetime.datetime.now().astimezone(GB_TZ).strftime("%Z")


def get_phase(state_machine):
    """Takes in the name of a step function, and checks to see what phase the ETL process is at
    If the step function is not part of the ETL process - returns the step function name without prefix or env

    Args:
        state_machine (str): The step function that has completed

    Returns:
        str: phase of the ETL process

    """
    phases = {
        "lsm-dp-etl": "ETL",
        "lsm-dp-extract": "Extraction",
        "lsm-dp-dwh-load": "DWH Load",
        "lsm-dp-rds-load": "RDS Load",
        "lsm-dp-rds-start": "RDS Start",
    }
    # Note - remove environment from end of state machine
    sm_name, env = state_machine.rsplit("-", 1)
    return phases.get(sm_name, " ".join(sm_name.split("-")[2:]).title())


def get_exection_timings(execution_arn):
    """Given an execution ARN - retrieves the start time, stop time, and durations

    Args:
        execution_arn (str): Unique identifier of the Step Function execution that completed

    Returns:
        str: Execution start time, stop time, and durations, separated on new lines
    """

    # print("[DEBUG] Execution Arn : {}".format(execution_arn))
    _step_functions = boto3.client("stepfunctions")
    execution_details = _step_functions.describe_execution(executionArn=execution_arn)
    # SETTING TimeZone to GB (GMT/BST)
    start_time = execution_details["startDate"].astimezone(tz=GB_TZ).strftime("%X")
    stop_time = execution_details["stopDate"].astimezone(tz=GB_TZ).strftime("%X")
    duration = execution_details["stopDate"] - execution_details["startDate"]
    return f"\t{start_time:9} -> {stop_time:9} = {str(duration)[:-7]:9}\n"


def get_glue_jobs_output(job_list):
    """Takes a list of glue jobs that have completed.
    Iterates over the list of jobs, and appends the job name, arguments and duration to a new list
    The list is converted to a string and returned

    Args:
        job_list (list): Glue jobs that have run, including parameters & duration

    Returns:
        str: containing job names and durations, separated on new lines
    """
    output_list = []
    for index in job_list:
        job = index.get("jobname", index.get("JobName", "Unknown"))
        job_in_seconds = index.get("ExecutionTime") or index["status"].get(
            "ExecutionTime", 0
        )
        job_args = index.get("jobarguments") or index.get("Arguments", "")
        duration = datetime.timedelta(seconds=job_in_seconds)
        output_list.append("\t{} {} - {}".format(job, job_args or "", duration))
    return "\n".join(output_list)


def get_nested_list_output(nested_list):
    """Takes a nested list of glue jobs that have completed.
    Iterates over the outer list of jobs, calling get_glue_jobs_output()

    Args:
        nested_list (list): Nested list which contains sublists of glue jobs

    Returns:
        str: containing job names and durations
    """
    output = []
    for sub_list in nested_list:
        output.append(get_glue_jobs_output(sub_list["sub_list"]))
    return f'\n\t\t{"-"*15}\n'.join(output)


def get_dwh_load_output(output):
    """Takes the output of the step function - searches for glue job
     that added an event execution key for the DWH Load.
    The details of this completed job are added to the message being sent by sns

    Args:
        output (dict): output from step function.

    Returns:
        str: Message with details of On Prem jobs that have completed for email notification

    """
    job_queued = output["dwh"]["jobs"]["trigger_event"]["Arguments"]["--IN_ARGS"].split(
        "::"
    )[-1]
    eek = output["dwh"]["status"]["event-execution-key"]
    return "\t{} : {}\n\tEvent Execution Key : {}".format(
        ON_PREM_SUCCESS_MSG, job_queued, eek
    )


def get_etl_step_error(execution_arn):
    """Given an execution ARN - retrieves the history and finds the error/cause of the failure

    Args:
        execution_arn (str): Unique identifier of the Step Function execution that failed

    Returns:
        str: String containing error & cause of Step Function failure

    """
    print("[DEBUG] Get ETL Error\n[DEBUG] Execution Arn : {}".format(execution_arn))
    _step_functions = boto3.client("stepfunctions")
    execution_history = _step_functions.get_execution_history(
        executionArn=execution_arn, reverseOrder=True, includeExecutionData=True
    )
    for step in execution_history["events"]:
        if step["type"] == "FailStateEntered":
            print("[DEBUG] Failed Step : {}".format(step))
            step_input = json.loads(step["stateEnteredEventDetails"]["input"])
            for phase, name in ETL_PHASES.items():
                if CAUGHT_ERROR_KEY in step_input[phase].keys():
                    print("[DEBUG] Caught Error in {}".format(name))
                    print(
                        "[DEBUG] Details : {}".format(
                            step_input[phase][CAUGHT_ERROR_KEY]
                        )
                    )
                    failed_event = step_input[phase][CAUGHT_ERROR_KEY]
                    return "PHASE : {}\nERROR : {}\nCAUSE : {}".format(
                        name,
                        failed_event.get("Error", DEFAULT_ERROR_MSG),
                        failed_event.get("Cause", ""),
                    )


def get_step_error(execution_arn):
    """Given an execution ARN - retrieves the history and finds the error/cause of the failure

    Args:
        execution_arn (str): Unique identifier of the Step Function execution that failed

    Returns:
        str: String containing error & cause of Step Function failure

    """
    _step_functions = boto3.client("stepfunctions")
    execution_history = _step_functions.get_execution_history(
        executionArn=execution_arn, reverseOrder=True, includeExecutionData=True
    )

    for step in execution_history["events"]:
        if step["type"] == "FailStateEntered":
            print("[DEBUG] Failed Step : {}".format(step))
            step_input = json.loads(step["stateEnteredEventDetails"]["input"])
            failed_event = step_input[CAUGHT_ERROR_KEY]
            return "ERROR: {}\nCAUSE: {}".format(
                failed_event.get("Error", DEFAULT_ERROR_MSG),
                failed_event.get("Cause", ""),
            )


def get_execution_duration(event):
    """Given an execution ARN - retrieves the history and finds the error/cause of the failure

    Args:
        event (dict): Details of the step function that completed

    Returns:
        time: Duration of the step function that completed

    """
    start_time = event["startDate"]
    start_time = datetime.datetime.fromtimestamp(start_time // 10**3)
    stop_time = event["stopDate"]
    stop_time = datetime.datetime.fromtimestamp(stop_time // 10**3)
    return stop_time - start_time


def get_extract_data(email_data_dict):
    """takes in the default email_data_dict and calls get_etl_message()
        this will fetch the full ETL message for the step function and store in "body_details"

    Args:
        email_data_dict:

    Returns:
        dict: with updated "body_details

    """
    extract_msg = f"TIMINGS ({CURRENT_TIMEZONE}) :\n{get_exection_timings(email_data_dict['execution_arn'])}\nEXTRACTION (cloud)\n{get_nested_list_output(email_data_dict['output']['job_lists'])}"
    email_data_dict["body_details"] = extract_msg
    return email_data_dict


def get_rds_load_data(email_data_dict):
    """takes in the default email_data_dict and calls get_glue_jobs_output()
        this will fetch the DWH message for the step function and store in "body_details"

    Args:
        email_data_dict:

    Returns:
        dict: with updated "body_details

    """
    rds_load_msg = f"TIMINGS ({CURRENT_TIMEZONE}) :\n{get_exection_timings(email_data_dict['execution_arn'])}\nRDS LOAD (cloud) \n{get_glue_jobs_output(email_data_dict['output']['load_jobs'])}"
    email_data_dict["body_details"] = rds_load_msg
    return email_data_dict


def get_dwh_load_data(email_data_dict):
    """takes in the default email_data_dict and calls get_dwh_load_output()
        this will fetch the DWH message for the step function and store in "body_details"

    Args:
        email_data_dict:

    Returns:
        dict: with updated "body_details

    """
    dwh_load_msg = f"TIMINGS ({CURRENT_TIMEZONE}) :\n{get_exection_timings(email_data_dict['execution_arn'])}\nDWH LOAD (on-prem)\n{get_dwh_load_output(email_data_dict['output'])}"
    email_data_dict["body_details"] = dwh_load_msg
    return email_data_dict


def get_etl_message(email_data_dict):
    """takes in the default email_data_dict then calls functions for each phase of the ETL process

    Args:
        email_data_dict:

    Returns:
        str: ETL_MSG_TEMPLATE with the updated strings that were returned
    """

    # print("[DEBUG] ETL Data : {}".format(email_data_dict))
    email_data_dict["timezone"] = CURRENT_TIMEZONE
    etl_timings_msg = ""

    for phase, name in ETL_PHASES.items():
        etl_timings_msg += f"\t{name:16} : {get_exection_timings(email_data_dict['output'][phase]['ex_id'])}"
    email_data_dict["etl_timings"] = etl_timings_msg
    email_data_dict["extraction_details"] = get_nested_list_output(
        email_data_dict["output"]["extract"]["job_lists"]
    )
    email_data_dict["rds_load_details"] = get_glue_jobs_output(
        email_data_dict["output"]["rds_load"]["load_jobs"]
    )
    email_data_dict["dwh_load_details"] = get_dwh_load_output(
        email_data_dict["output"]["dwh_load"]
    )
    return ETL_MSG_TEMPLATE.format(**email_data_dict)


def get_etl_data(email_data_dict):
    """takes in the default email_data_dict and calls get_etl_message()
        this will fetch the full ETL message for the step function and store in "body_details"

    Args:
        email_data_dict:

    Returns:
        dict: with updated "body_details

    """
    email_data_dict["body_details"] = get_etl_message(email_data_dict)
    return email_data_dict


def get_error_message(email_data_dict):
    """takes in the default email_data_dict and calls get_step_error()
        this will fetch the error message for the step function and store in "body_details"

    Args:
        email_data_dict:

    Returns:
        dict: with updated "body_details

    """
    # print("[DEBUG] Event Phase : {}".format(email_data_dict["phase"]))
    if email_data_dict["phase"] == "ETL":
        email_data_dict["body_details"] = get_etl_step_error(
            email_data_dict["execution_arn"]
        )
    else:
        email_data_dict["body_details"] = get_step_error(
            email_data_dict["execution_arn"]
        )
    return email_data_dict


def lambda_handler(event, context):
    """Detail of Step Function status change is passed in.
        A message is constructed explaining the status change.
        Any successful jobs/ or failures are noted.
        Once the message body is complete - it is published & sent to via SNS

    Args:
        context:
        event (dict): Step Function status change details

    """

    _sns = boto3.client("sns")
    app_envs = {"test": "SIT", "qa": "UAT", "production": "Production"}
    try:
        # get EVENT DETAILS PASSED IN
        print("[DEBUG] Event Obj : {}".format(event))
        state_machine_arn = event["stateMachineArn"]
        (
            _arn,
            _aws,
            _states,
            region,
            acc_no,
            _service,
            state_machine,
        ) = state_machine_arn.split(":")
        app_env = state_machine.split("-")[-1]
        execution_arn = event["executionArn"]
        phase = get_phase(state_machine)
        execution_input_string = event["input"]
        execution_input = json.loads(execution_input_string)

        email_data_dict = {
            "env": app_envs.get(app_env, app_env).upper(),
            "source": execution_input["source"].upper(),
            "phase": phase,
            "date": datetime.datetime.now().strftime("%d/%m/%y"),
            "timezone": CURRENT_TIMEZONE,
            "status": event["status"],
            "step_function_name": state_machine,
            "execution_name": event["name"],
            "execution_arn": execution_arn,
            "duration": get_execution_duration(event),
            "body_details": DEFAULT_SUCCESS_MSG,
            "execution_link": "https://console.aws.amazon.com/states/home?region={}#/executions/details/{}".format(
                region, execution_arn
            ),
            "output": json.loads(event.get("output") or "[]"),
        }
        phase_data = {
            "Extraction": get_extract_data,
            "RDS Load": get_rds_load_data,
            "DWH Load": get_dwh_load_data,
            "ETL": get_etl_data,
            "error": get_error_message,
        }

        apac = execution_input["dwh_load"]["APACGeniusLoad"]

        if apac == "_APAC":
            apac = "APAC"
        else:
            apac = "ONP"

        # Format the subject/message
        sns_topic_arn = "arn:aws:sns:{}:{}:lsm-dp-stepfunction-sns-{}".format(
            region, acc_no, app_env
        )

        sns_message = EMAIL_MSG_TEMPLATE.format(
            **phase_data["error" if not event["status"] == "SUCCEEDED" else phase](
                email_data_dict
            )
        )
        # Publish/Send the message
        return _sns.publish(
            TopicArn=sns_topic_arn,
            Message=sns_message,
            Subject="[" + app_env.upper() + "] " + apac + " " + execution_input["source"].upper() + " " + event["status"]
        )

    except Exception as e:
        print("[ERROR] {}".format(str(e)))
        raise e
