import boto3
import json
import numpy as np


def lambda_handler(event, context):
    try:
        s3_bucket = event["s3_bucket"]
        s3_table_key = event["s3_table_key"]

        print(f"[DEBUG] s3 Bucket = '{s3_bucket}'")
        print(f"[DEBUG] s3 Table Key = '{s3_table_key}'")

        etl_data = event["etl_data"]
        print(f"[DEBUG] ETL data = '{etl_data}'")

        # table data, concurrent run config
        _s3 = boto3.resource("s3")
        obj = _s3.Object(s3_bucket, s3_table_key)
        table_data = json.load((obj.get()["Body"]))

        job_name = table_data["job_name"]
        concurrent_jobs = int(table_data["concurrent_jobs"])
        table_list = table_data["tables"]

        print(f"[DEBUG] job name = '{job_name}'")
        print(f"[DEBUG] concurrent jobs = '{concurrent_jobs}'")
        print(f"[DEBUG] table list = '{table_list}'")

        splits = np.array_split(table_list, concurrent_jobs)

        for array in splits:
            list_to_str = ",".join(map(str, list(array)))
            table_list_dict = {"--TABLES": list_to_str}
            list_dict = {
                "jobname": job_name,
                "jobarguments": table_list_dict,
            }
            etl_data["load_jobs"].append(list_dict)

        return etl_data["load_jobs"]

    except Exception as e:
        print(f"[ERROR] {str(e)}")
        raise e
