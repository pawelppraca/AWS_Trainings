def dynamic_exception(error, cause):
    class ErrorClass(Exception):
        pass

    ErrorClass.error = error
    ErrorClass.cause = cause
    ErrorClass.__name__ = "".join(error.split("."))
    return ErrorClass(cause)


def lambda_handler(event, context):

    try:
        if "Error" in event["caught_error"]:
            raise dynamic_exception(
                event["caught_error"]["Error"], event["caught_error"]["Cause"]
            )

    except Exception as e:
        print("[ERROR] {}".format(str(e)))
        raise e
