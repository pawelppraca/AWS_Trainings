import datetime
import json
import boto3
from dateutil.tz import gettz


def lambda_handler(event, context):

    _stepfunction = boto3.client("stepfunctions")
    _lambda = boto3.client("lambda")

    try:
        # get LAMBDA variables
        lambda_details = _lambda.get_function(FunctionName=context.function_name)
        read_s3_function_arn = lambda_details["Configuration"]["Environment"][
            "Variables"
        ]["readS3Function"]
        s3_bucket = lambda_details["Configuration"]["Environment"]["Variables"][
            "s3Bucket"
        ]
        s3_path = lambda_details["Configuration"]["Environment"]["Variables"]["s3Path"]
        state_arn_prefix = lambda_details["Configuration"]["Environment"]["Variables"][
            "stateMachineARNprefix"
        ]
        app_env = lambda_details["Tags"]["lm_app_env"]

        # get EVENT values
        event_phase = event["phase"]
        event_source = event["source"]
        event_APACGeniusLoad = event.get("APACGeniusLoad", "")

        s3_input_file = "{}/{}.json".format(event_phase, event_source)
        # Fetch s3 file
        input_params = {
            "S3Bucket": s3_bucket,
            "S3Path": s3_path,
            "S3File": s3_input_file,
        }
        # print("[DEBUG] Read s3 file input params : '{}'".format(input_params))
        read_s3_func_response = _lambda.invoke(
            FunctionName=read_s3_function_arn,
            InvocationType="RequestResponse",
            Payload=json.dumps(input_params),
        )
        step_input = json.load(read_s3_func_response["Payload"])
       
        #Setting value of Parameter APACGeniusLoad from Event only for GENIUS Load
        if "dwh_load" in step_input :
            step_input["dwh_load"]["APACGeniusLoad"] = event_APACGeniusLoad

        # set up Step Function ARN
        state_machine_arn = "{}-{}-{}".format(state_arn_prefix, event_phase, app_env)

        # set up Unique Execution Name
        now = datetime.datetime.now(gettz("GB"))
        execution_id = "{}_{}".format(event_source, now.strftime("%Y-%m-%d-%H-%M-%S"))
        print("[DEBUG] Execution Name : '{}'".format(execution_id))

        # Start the Step Function with given parameters
        response = _stepfunction.start_execution(
            stateMachineArn=state_machine_arn,
            name=execution_id,
            input=json.dumps(step_input),
        )

        print("[DEBUG] start step function response : '{}'".format(str(response)))

    except Exception as e:
        print("[ERROR] {}".format(str(e)))
        raise e
