import re
import boto3
import datetime


def get_snapshot_id_pattern(sub_str):
    """Returns ID pattern to match DBSnapshotIdentifier.

    Args:
        sub_str (str): Contains naming convention of manual snapshot.

    Returns:
        re.compile:

    Note:
        1. You can find the sub_str in lambda lookup against LambdaRDSSnapshotCleanUpFunction

    """
    yyyy = "20({})".format("|".join(str(_) for _ in range(20, 100)))
    mm = "({})".format("|".join(str(_) if _ > 9 else "0{}".format(_) for _ in range(1, 13)))
    dd = "({})".format("|".join(str(_) if _ > 9 else "0{}".format(_) for _ in range(1, 32)))
    hh = "({})".format("|".join(str(_) if _ > 9 else "0{}".format(_) for _ in range(24)))
    m = "({})".format("|".join(str(_) if _ > 9 else "0{}".format(_) for _ in range(60)))

    PATTERN = "{}-{}-{}-{}-{}-{}".format(
        sub_str,
        yyyy,
        mm,
        dd,
        hh,
        m
    )
    return re.compile(PATTERN, flags=re.UNICODE)


def deletion_criteria(db_snapshot, pattern, start_time):
    """Checks if the snapshot starts with name_fmt and is older than a week.

    Args:
        db_snapshot (dict): DB Snapshot Object.
        pattern (re.compile): Pattern Recognizer for DBSnapshotIdentifier.
        start_time (datetime.datetime): Start Time.

    Returns:
        bool: True if pattern.match(name_fmt) and _created_at <= start_time else False.

    """
    _id = db_snapshot["DBSnapshotIdentifier"]
    _created_at = db_snapshot["SnapshotCreateTime"]
    return pattern.match(_id) and _created_at.replace(tzinfo=None) <= start_time


def get_past_time_boundary(day_diff=1):
    """Returns Start and End Datetimes.

    Args:
        day_diff (int, optional): Datetime Delta. Defaults to 1.

    Returns:
        datetime.datetime: Start Datetime.
        datetime.datetime: End Datetime.

    """
    _e = datetime.datetime.now()
    _e = _e.replace(hour=23, minute=59, second=59, microsecond=000000, tzinfo=None)
    _s = _e - datetime.timedelta(days=day_diff)
    return _s, _e


def get_snapshots_to_delete(_rds, db_instance, snap_type, pattern, start):
    """Returns filtered list eligible of DB Snapshots for Deletion.

    Args:
        _rds (boto3.client): RDS Client Instance.
        db_instance (str): RDS Instance Name.
        snap_type (str): Snapshot Type. Can hold -
            1. automatic
            2. manual
        pattern (re.compile): Pattern Recognizer for DBSnapshotIdentifier.
        start (datetime.datetime): Boundary Reference Datetime to Delete from.

    Returns:
        filter: list of snapshot details eligible for deletion.
 
    """
    r = _rds.describe_db_snapshots(
        DBInstanceIdentifier=db_instance,
        SnapshotType=snap_type,
    )

    db_snapshots = r["DBSnapshots"]

    db_snapshots.sort(
        reverse=True,
        key=lambda db_snapshot: db_snapshot["SnapshotCreateTime"]
    )

    return filter(
        lambda db_snapshot: deletion_criteria(db_snapshot, pattern, start),
        db_snapshots
    )


def delete_snapshot(_rds, snapshot):
    """ Deletes a snapshot.

    Args: 
        _rds (boto3.client): RDS Client Instance.
        snapshot (dict): DB Snapshot details - that will be deleted.

    Returns:
        dict: delete DBSnapshot response.

    """
    return _rds.delete_db_snapshot(DBSnapshotIdentifier=snapshot["DBSnapshotIdentifier"])


def lambda_handler(event, context):
    day_diff = 8  # one week diff
    snap_type = "manual"
    min_snapshots = 1 

    try:
        _rds = boto3.client('rds')
        _lambda = boto3.client('lambda')

        lambda_details = _lambda.get_function_configuration(
            FunctionName=context.function_name
        )

        vars = lambda_details['Environment']['Variables']
        db_instance = vars['DBInstanceName']
        name_fmt = vars['snapshotNameFormat']

        start, end = get_past_time_boundary(day_diff=day_diff)

        pattern = get_snapshot_id_pattern(name_fmt)

        snapshots = get_snapshots_to_delete(_rds, db_instance, snap_type, pattern, start)

        for i, snapshot in enumerate(snapshots):
            if i > min_snapshots - 1:
                print("[DEBUG] Snapshot details: {}".format(snapshot["DBSnapshotIdentifier"]))
                _r = delete_snapshot(_rds, snapshot)
                print("[DEBUG] Snapshot Delete Status: {}".format(_r))
                
    except Exception as e:
        print("[ERROR] {}".format(str(e)))
        raise e