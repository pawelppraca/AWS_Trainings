import boto3
import datetime

def snapshot_waiter(_rds, db_instance, db_snapshot_name):
    """ Will wait/retry until Snapshot is available depending on waiter config
    Args:
        _rds (boto.client)
        db_snapshot_name (snapshot): snapshot being taken

    """
    print(' [NOTE] Calling snapshot waiter')
    _rds.get_waiter('db_snapshot_available').wait(
        DBInstanceIdentifier=db_instance,
        Filters = [
            {
                'Name': 'db-snapshot-id',
                'Values': [db_snapshot_name]
            }
        ],
        WaiterConfig={
            'Delay': 300,
            'MaxAttempts': 5
        }
    )

def rds_waiter(_rds, db_instance):
    """ Will wait/retry until RDS is available depending on waiter config
    Args:
        _rds (boto.client)
        db_instance (db instance): rds to be updated

    """
    print('[NOTE] Calling waiter - prevent throttling')
    _rds.get_waiter('db_instance_available').wait(
        DBInstanceIdentifier=db_instance,
        WaiterConfig={
            'Delay': 300,
            'MaxAttempts': 5
        }
    )


def lambda_handler(event, context):

    _rds = boto3.client('rds')
    _lambda = boto3.client('lambda')

    try:
        lambda_details = _lambda.get_function_configuration(
            FunctionName=context.function_name
        )
        db_instance = lambda_details['Environment']['Variables']['DBInstanceName']
        print("[DEBUG] dbInstance : '{}'".format(str(db_instance)))

        now = datetime.datetime.now()
        db_snapshot_name = "{}-snapshot-{}".format(db_instance, now.strftime("%Y-%m-%d-%H-%M"))

        # rds_waiter(_rds, db_instance)

        print("[DEBUG] creating dBSnapshot : '{}'".format(db_snapshot_name))

        # NOTE: taking manual snapshot
        response = _rds.create_db_snapshot(
            DBSnapshotIdentifier=db_snapshot_name,
            DBInstanceIdentifier=db_instance,
        )

        print("[DEBUG] create_db_snapshot response : '{}'".format(str(response)))

        # snapshot_waiter(_rds, db_instance, db_snapshot_name)


        return str(response)

    except Exception as e:
        print("[ERROR] {}".format(str(e)))
        raise e
