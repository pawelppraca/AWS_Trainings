import boto3
import botocore


STATUS_RDS_TAG_IN_USE = "in use"
STATUS_RDS_CONNECTING = "connecting"
CLIENT_ERROR_SUBSTRING = "operation (reached max retries: 4): Rate exceeded"


def get_in_use_rds_tags(rds_tags):
    """Returns currently 'in use' rds tags.
    Args:
        rds_tags (dict): collection of {rds_tags: status}
    Returns:
        int: number of rds tags in use
        list: rds tags in use
    """
    in_use_rds_tags = []
    count_in_use_rds_tags = 0
    for tag_list in rds_tags["TagList"]:
        if tag_list["Value"] == STATUS_RDS_TAG_IN_USE:
            in_use_rds_tags += [tag_list["Key"]]
            count_in_use_rds_tags += 1
    return count_in_use_rds_tags, in_use_rds_tags


def lambda_handler(event, context):

    rds = boto3.client("rds")
    _lambda = boto3.client("lambda")

    try:
        lambda_details = _lambda.get_function_configuration(
            FunctionName=context.function_name
        )
        DBARN = lambda_details["Environment"]["Variables"]["DBARN"]

        # NOTE: rds_access will only contains one of ["connecting", "disconnecting"]
        rds_access = event["rds_access"]
        # NOTE: rds_access_id will be stepfunction execution ID
        rds_access_id = event["rds_access_id"]

        rds_tags = rds.list_tags_for_resource(ResourceName=DBARN)
        print("[DEBUG] rds_tags = '{}'".format(rds_tags))

        num_of_tags, rds_active_tags = get_in_use_rds_tags(rds_tags)
        print("[DEBUG] rds_active_tags = '{}'".format(rds_active_tags))

        if rds_access == STATUS_RDS_CONNECTING:
            print("[INFO] adding '{}' to the rds_active_tags".format(rds_access_id))
            rds.add_tags_to_resource(
                ResourceName=DBARN,
                Tags=[{"Key": rds_access_id, "Value": STATUS_RDS_TAG_IN_USE}],
            )
            num_of_tags += 1
        elif rds_access_id in rds_active_tags:
            print("[INFO] remove '{}' from the rds_active_tags".format(rds_access_id))
            rds.remove_tags_from_resource(
                ResourceName=DBARN,
                TagKeys=[
                    rds_access_id,
                ],
            )
            num_of_tags -= 1

        return num_of_tags
    except botocore.exceptions.ClientError as e:
        if CLIENT_ERROR_SUBSTRING in str(e):
            print("[ERROR] Runtime warning : {}".format(str(e)))
            raise RuntimeWarning(str(e))
    except Exception as e:
        print("[ERROR] {}".format(str(e)))
        raise e
