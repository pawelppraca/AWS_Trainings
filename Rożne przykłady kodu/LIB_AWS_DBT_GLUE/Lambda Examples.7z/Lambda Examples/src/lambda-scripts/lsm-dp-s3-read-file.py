import boto3
import json


def lambda_handler(event, context):

    try:
        ## get EVENT values
        s3_bucket = event["S3Bucket"]
        s3_path = event["S3Path"]
        s3_file = event["S3File"]

        _s3 = boto3.resource("s3")
        s3_key = ("{}{}").format(s3_path, s3_file)

        print("[DEBUG] s3 Bucket = '{}'".format(s3_bucket))
        print("[DEBUG] s3 Key = '{}'".format(s3_key))

        obj = _s3.Object(s3_bucket, s3_key)
        data = json.load((obj.get()["Body"]))
        print("[DEBUG] data = '{}'".format(data))

        return data

    except Exception as e:
        print("[ERROR] {}".format(str(e)))
        raise e
