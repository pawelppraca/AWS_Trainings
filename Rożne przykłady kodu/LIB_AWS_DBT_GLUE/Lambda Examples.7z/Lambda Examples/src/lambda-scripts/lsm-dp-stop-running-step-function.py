import boto3
import datetime

#start - method which checks step function status
def sf_check_status(response,time_threshold,current_time):

    sf_to_stop = []                                                          # set list to collect list of step function to be stopped
    for response_item in response['executions']:
        response_startDate = response_item['startDate'].replace(tzinfo=None) # remove timezone offset from json format and compare startdate with current time
        response_time_diff = current_time - response_startDate
        response_time = round(response_time_diff.total_seconds(),2)          
        if ( response_time > time_threshold):                                # check if job is not running longer than defined threshold
            sf_to_stop.append(response_item['executionArn'])
        
    return sf_to_stop
#end

#main
def lambda_handler(event, context):

    _client = boto3.client('stepfunctions',region_name="eu-west-1")
    _lambda = boto3.client("lambda")
    
    try:
        lambda_details = _lambda.get_function_configuration(                        # get Step Function ARN
                FunctionName=context.function_name
            )
        exec_arn = lambda_details["Environment"]["Variables"]["SFARN"]

        response = _client.list_executions(
            stateMachineArn=exec_arn,
            statusFilter='RUNNING',
            maxResults=123
            )

        time_threshold = 60*60*2                                                    #threshold which indicates how long job can run
        current_time = datetime.datetime.now()

        result_sf_check_status = sf_check_status(response,time_threshold,current_time)                    # call method to check step function status
        
        if not result_sf_check_status:                                              #stop step functions if any is running - returned from list
            print("No step function was running")
        else:            
            for result_arn in result_sf_check_status:
                response_sf_check_status = _client.stop_execution(exec_arn=result_arn,error="Manual step function stop")
                print(result_arn, "has been stopped")
    
    except Exception as e:
        print("[ERROR] {}".format(str(e)))
        raise e
