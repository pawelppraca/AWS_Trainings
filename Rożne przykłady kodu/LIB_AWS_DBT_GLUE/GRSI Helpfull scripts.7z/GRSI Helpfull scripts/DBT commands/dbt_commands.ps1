
# Uruchamienia vnenv
------------------------------------
cd C:\Users\n1601471\source\GIT-GRSI\grsi-dp-warehouse\lib\dbt\grsi_dp_dwh
..\venv\Scripts\activate


============================================================
# Logowanie rozszerzone dbt test
---------------------------------------------------
dbt test --select test_environment_name


# Uruchamianie wybranego skryptu macro
dbt run-operation "log_results_recon_save_data"       

# Uruchamianie macro z parametrami
dbt run-operation "get_rowcounts" --args '{table_name: "recon_coverage_sumswholepremium", log_query: 1}'

dbt run-operation "create_pii_masking_policy" --args '{column_name: "risk_engineer_code", mask: "XXXYYYXXX", DATA_TYPE: "varchar"}'

dbt run-operation "create_pii_masking_view" --args '{role_name: "aad:eu-pii", priority: 10}'

dbt run-operation "report_recon" --args '{details_table_name: "recon_risk_rowCountSectionTypeCode_details", header_key_value: 0, where_condition:""}'


(column_name, mask, DATA_TYPE)
# Uruchamianie wg taga
dbt run -s tag:recon_risk


dbt run-operation "_review_dataset" --args '{list: ["aad:eu-pii","aad:ap-pii","aad:us-pii"]}'