
WITH limits AS (
    SELECT * from staging_warehouse_repository.limits
),
risks AS (
    select * from staging_warehouse_repository.policies
),
source_cte AS
(
    select qualifiercode AS coverage_code
        , qualifiername AS coverage_name
        ,SUM(l.limitoriginalcurrency) as source_SUM_coverage_whole_limit
    from limits l
    join risks r on r.policykey = l.policykey
    WHERE l._currentflag= true
    GROUP BY l.qualifiercode, l.qualifiername

),
target_cte AS (
    SELECT  coverage_code
            , coverage_name
            , SUM(coverage_whole_limit) as target_SUM_coverage_whole_limit
    FROM {{ ref('prep_coverage_final')}}
    WHERE _currentflag = true
    GROUP BY coverage_code, coverage_name
)

select * from source_cte s
join target_cte t on t.coverage_code = s.coverage_code AND t.coverage_name = s. coverage_name
WHERE source_SUM_coverage_whole_limit <> target_SUM_coverage_whole_limit
