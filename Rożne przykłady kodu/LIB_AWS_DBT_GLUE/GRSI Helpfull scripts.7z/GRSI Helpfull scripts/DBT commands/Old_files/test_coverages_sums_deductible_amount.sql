
{{    
    generate_cte(
        [
            {"table": "staging_warehouse_repository_limits", "alias": "limits", 
                "columns": [
                    "limitkey",
                    "policykey",
                    "originalcurrencycode",
                    "qualifiercode",
                    "qualifiername",
                    "limitoriginalcurrency",
                    "premium",
                    "deductibleoriginalcurrency",
					"_currentflag",
					"_effectivefrom",
					"_effectiveto",
					"_lastaction",
                    "_mergekey",
                    "_sequencenumber",
                    "_mergekey_policies",
                    "_sourcesystemcode"
                    ]
            },
            {"table": "staging_warehouse_repository_policies", "alias": "risks", "columns": ["policykey"]}
        ]
    )
}},
source_cte AS
(
    select qualifiercode AS coverage_code
        , qualifiername AS coverage_name
        ,SUM(l.deductibleoriginalcurrency)  as source_SUM_deductible_amount
    from staging_warehouse_repository.limits l
    join staging_warehouse_repository.policies r on r.policykey = l.policykey
    WHERE l._currentflag= true
    GROUP BY l.qualifiercode, l.qualifiername

),
target_cte AS (
    SELECT  coverage_code
            , coverage_name
            , SUM(deductible_amount) AS target_SUM_deductible_amount
    FROM transform.prep_coverage_final
    WHERE _currentflag = true
    GROUP BY coverage_code, coverage_name
)

select * from source_sums s
join target_sums t on t.coverage_code = s.coverage_code AND t.coverage_name = s. coverage_name
WHERE source_SUM_deductible_amount <> target_SUM_deductible_amount
