
WITH source_cte AS
(
    select qualifiercode AS coverage_code
        , qualifiername AS coverage_name
        ,SUM(l.premium) as source_SUM_coverage_whole_premium
    from staging_warehouse_repository.limits l
    join staging_warehouse_repository.policies r on r.policykey = l.policykey
    WHERE l._currentflag= true
    GROUP BY l.qualifiercode, l.qualifiername

),
target_cte AS (
    SELECT  coverage_code
            , coverage_name
            , SUM(coverage_whole_premium) AS target_SUM_coverage_whole_premium
    FROM transform.prep_coverage_final
    WHERE _currentflag = true
    GROUP BY coverage_code, coverage_name
)

select * from source_cte s
join target_cte t on t.coverage_code = s.coverage_code AND t.coverage_name = s. coverage_name
WHERE source_SUM_coverage_whole_premium <> target_SUM_coverage_whole_premium
