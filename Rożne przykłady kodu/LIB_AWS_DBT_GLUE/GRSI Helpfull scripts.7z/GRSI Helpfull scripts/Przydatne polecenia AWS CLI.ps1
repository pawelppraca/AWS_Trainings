#Ręczne uruchomienie Glue JOB

aws glue start-job-run --job-name grsi-dp-save-recon-GlueJob-test  --profile usertest  #--arguments "{\"--GROUP\":\"cleardown\"}"

aws glue start-job-run --job-name grsi-dp-save-recon-GlueJob-test  --profile admin-user-test


# Kopiowanie pliku na S3

aws s3 cp "C:\Users\n1601471\source\GIT-GRSI\grsi-dp-warehouse\lib\stacks\glue\scripts\job_scripts\save_reconciliation_results.py" s3://grsi-dp-warehouse-scripts-eu-test/job_scripts/save_reconciliation_results.py --profile admin-user-test

# Delete - ale nie uruchamiałem
aws s3api delete-bucket --bucket my-bucket --region us-east-1

# Kopiowanie pliku z S3 do Lokalnego folderu
aws s3 cp s3://grsi-dp-save-recon-data2-eu-test/reconciliation/part-00000-e17c50bb-3868-451a-a30a-e6fd956ecefb-c000.snappy.parquet "C:\Users\n1601471\OneDrive - Liberty Mutual\Documents\Visual Studio Code\GRSI Helpfull scripts\Parquet Files\Reconciliation" --profile admin-user-test


# Kopiowanie zawartości folderu na lokalny dysk
aws s3 cp s3://grsi-dp-save-recon-data2-eu-test/reconciliation/ "C:\Users\n1601471\OneDrive - Liberty Mutual\Documents\Visual Studio Code\GRSI Helpfull scripts\Parquet Files\Reconciliation" --recursive --include "*" --profile admin-user-test

aws s3 cp s3://grsi-dp-save-recon-data2-eu-test/reconciliation/part-00000-50e5e8cc-e611-40b4-af31-43a9243652a3-c000.snappy.parquet "C:\Users\n1601471\OneDrive - Liberty Mutual\Documents\Visual Studio Code\GRSI Helpfull scripts\Parquet Files\Reconciliation" --recursive --include "*" --profile admin-user-test

# Usuwanie pliku
aws s3 rm s3://grsi-dp-save-recon-data2-eu-test/reconciliation/coverage_row_counts/ --recursive --exclude "*" --include "part-00000-f7c9c95a-d5d6-473b-8f86-8d78338ca446-c000.snappy.parquet" --profile admin-user-test

#Usuwanie plików z foldera
aws s3 rm s3://grsi-dp-save-recon-data2-eu-test/reconciliation/coverage_sums_deductible_amount/ --recursive  --profile admin-user-test

aws s3 rm s3://grsi-dp-save-recon-data2-eu-test/reconciliation/ --recursive  --profile admin-user-test

# Odczyt danych z DynamoDB do pliku
aws dynamodb scan --table-name lsm-dp-etl-log-test --profile test >> output.txt

aws dynamodb scan --table-name grsi-dp-dynamodb-lock-table-eu-test --profile admin-user-test >> grsi-dp-dynamodb-lock-table-eu-test.txt

aws dynamodb scan --table-name grsi-dp-save-recon-header-table2-test --profile admin-user-test

aws dynamodb scan --table-name grsi-dp-save-recon-header-table2-test --profile admin-user-test >> grsi-dp-save-recon-header-table2-test.json