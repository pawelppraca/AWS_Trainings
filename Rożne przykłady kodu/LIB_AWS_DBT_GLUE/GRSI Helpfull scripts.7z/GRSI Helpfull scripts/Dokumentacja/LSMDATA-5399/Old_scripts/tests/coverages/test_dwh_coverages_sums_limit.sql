/*
reconciliation_sums(
	source_model_1, --mandatory
	source_model_2, --optional
	source_group_column_names, -- mandatory column used in group by
	source_summary_column,  --mandatory, column which is sum
	source_join_conditions, --mandatory if 2 models used, conditions  AND
	ssource_where_condition, --optional
	source_having_condition  --optional
    
	target_model_1, --madatory
	target_model_2, --optional
	target_group_column_names,  -- mandatory column used in group by
	target_summary_column, --mandatory column which is sum
	target_join_conditions, --mandatory if 2 models used, conditions connected by AND
	target_where_condition, --optional
	target_having_condition --optional
  )
*/

{{  reconciliation_sums(
          ref('staging_warehouse_repository_limits')  
        , ref('staging_warehouse_repository_policies')
        , ['qualifiercode','qualifiername']
        , 'limitoriginalcurrency'
        , [ref('staging_warehouse_repository_limits') ~ '.policykey = ' ~ ref('staging_warehouse_repository_policies') ~'.policykey']
        ,  ref('staging_warehouse_repository_limits') ~ '._currentflag = true'
        , ''
        , ref('coverage')
        , ''
        , ['coverage_code','coverage_name']
        , 'coverage_whole_limit'
        , ''
        , ''
        , '')
}}