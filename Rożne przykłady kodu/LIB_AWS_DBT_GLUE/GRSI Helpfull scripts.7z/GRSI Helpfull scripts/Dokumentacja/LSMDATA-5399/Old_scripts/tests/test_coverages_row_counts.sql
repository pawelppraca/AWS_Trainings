
WITH limits AS (
    SELECT * from {{ ref('staging_warehouse_repository_limits') }}
),
risks AS (
    select * from {{ ref('staging_warehouse_repository_policies') }}
),
source_cte AS
(
    select 
         qualifiercode AS coverage_code
       , qualifiername AS coverage_name
       , count(*) AS Source_records_qty
    from limits l
    join risks r on r.policykey = l.policykey
    WHERE l._currentflag= true
    GROUP BY l.qualifiercode, l.qualifiername
),
target_cte AS (
    SELECT  
        coverage_code
        , coverage_name
        , count(*) target_records_qty
    FROM {{ ref('coverage') }}
    GROUP BY coverage_code, coverage_name
)

select 
        s.coverage_code Source_Coverage_Code 
        , s.coverage_Name Source_Coverage_Name
        , s.source_records_qty
        , t.coverage_code Target_Coverage_Code 
        , t.coverage_Name Target_Coverage_Name
        , t.target_records_qty
from source_cte s
join target_cte t on t.coverage_code = s.coverage_code AND t.coverage_name = s. coverage_name
WHERE Source_records_qty<>target_records_qty
