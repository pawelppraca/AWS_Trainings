
WITH cc_contacts AS (
    SELECT * FROM {{ ref('staging_claim_center_cc_contact') }} 
),
cc_users AS (
    SELECT * FROM {{ ref('staging_claim_center_cc_user') }}
),

users AS (
    SELECT 
            c.firstname
            , c.lastname 
            ,u.id AS user_id 
    FROM cc_contacts c
    JOIN cc_users u 
        ON u.__load_id = c.__load_id 
        AND c.id = u.contactid
),


claims_row_counts_by_created_user_source AS (
    SELECT  
            DATE_PART_YEAR(trunc(lossdate)) AS LossDate_Year
            , u.Firstname
            , u.Lastname
            , count(c.id) count_of_claims
    from {{ ref('staging_claim_center_cc_claim') }} c
    JOIN users u on u.user_id = c.createuserid
    GROUP BY DATE_PART_YEAR(trunc(lossdate)) 
            , u.Firstname
            , u.Lastname

),

claims_row_counts_by_created_user_target AS(
    SELECT 
            DATE_PART_YEAR(trunc(date_of_loss)) AS LoassDate_Year 
            , ch.first_name
            , ch.last_name
            , count(*) count_of_claims 
    FROM {{ ref('claim') }} c
    JOIN {{ ref('claim_handler') }} ch on ch.claim_handler_key = c.created_by_claim_handler_key
    WHERE ch.claim_handler_key <> -1  
    GROUP BY DATE_PART_YEAR(trunc(date_of_loss)) 
            , ch.first_name
            , ch.last_name

)

select *
from claims_row_counts_by_created_user_source s
join claims_row_counts_by_created_user_target t 
        on t.LoassDate_Year = s.LoassDate_Year 
        and s.firstname = t.first_name
        and s.lastname = t.last_name
WHERE s.count_of_claims <> t.count_of_claims
