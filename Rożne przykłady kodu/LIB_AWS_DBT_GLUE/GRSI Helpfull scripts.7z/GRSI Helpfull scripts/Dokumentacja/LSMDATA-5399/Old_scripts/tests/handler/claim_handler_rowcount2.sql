WITH cc_users AS (
    select 
            c.firstname as first_name,
            c.lastname as last_name,
            c.firstname || ' ' || c.lastname as full_name
        from {{ ref('staging_claim_center_cc_contact') }}  c
        inner join {{ ref('staging_claim_center_cc_user') }}  u
            on c.__load_id = u.__load_id
            and c.id = u.contactid
        where  c.subtype = 14  -- person
),
genius_users AS (
    select 
        null as first_name,
        null as last_name,
        t8t8un as full_name
    from {{ ref('staging_genius_zkt8') }} 
),

total_users AS (
    select * from cc_users
    union all
    select * from genius_users
),
dim_claim_handlers AS (
    select * from reporting.dim_claim_handler WHERE claim_handler_key > 0 
)



{% set stage_relation = 'total_users' %}

{% set reporting_relation = 'dim_claim_handlers' %}

{{ compare_row_counts(
    a_relation = stage_relation,
    b_relation = reporting_relation
) }}