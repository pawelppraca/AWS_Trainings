/*
reconciliation_row_count(
	source_model_1, --mandatory
	source_model_2, --optional
	source_group_column_names, -- mandatory column used in group by
	source_join_conditions, --mandatory if 2 models used, conditions  AND
	ssource_where_condition, --optional
	source_having_condition  --optional
    
	target_model_1, --madatory
	target_model_2, --optional
	target_group_column_names,  -- mandatory column used in group by
	target_join_conditions, --mandatory if 2 models used, conditions connected by AND
	target_where_condition, --optional
	target_having_condition --optional
        add_WITH --mandatory if 
  )
*/

WITH users AS (
    SELECT 
            c.firstname
            , c.lastname 
            ,u.id AS user_id 
    FROM {{ ref('staging_claim_center_cc_contact') }} c
    JOIN {{ ref('staging_claim_center_cc_user') }} u 
        ON u.__load_id = c.__load_id 
        AND c.id = u.contactid
),


{{  reconciliation_row_count(
          ref('staging_claim_center_cc_claim')  
        , 'users'
        , ['DATE_PART_YEAR(trunc(lossdate))','Firstname','Lastname']
        , ['users.user_id = ' ~ ref('staging_claim_center_cc_claim')~ '.createuserid']
        , ''
        , ''
        , ref('claim')
        , ref('claim_handler')
        , ['DATE_PART_YEAR(trunc(date_of_loss))', 'first_name', 'last_name']
        , [ref('claim_handler') ~ '.claim_handler_key = '~ ref('claim') ~ '.created_by_claim_handler_key']
        , ''
        , ''
        , ''
        )
}}