
WITH claim_handler_groups AS (
    select * from {{ ref('claim_handler_group') }} where claim_handler_group_key > 0
)


{% set stage_relation = ref('staging_claim_center_cc_group') %}

{% set dwh_relation = ref('claim_handler_groups') %}

{{ compare_row_counts(
    a_relation = stage_relation,
    b_relation = dwh_relation
) }}