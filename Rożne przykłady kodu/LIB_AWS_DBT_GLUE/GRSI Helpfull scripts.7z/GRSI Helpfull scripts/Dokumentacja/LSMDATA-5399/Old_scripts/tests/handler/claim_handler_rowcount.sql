
WITH cc_users AS (
    select 
            c.firstname as first_name,
            c.lastname as last_name,
            c.firstname || ' ' || c.lastname as full_name
        from {{ ref('staging_claim_center_cc_contact') }}  c
        inner join {{ ref('staging_claim_center_cc_user') }}  u
            on c.__load_id = u.__load_id
            and c.id = u.contactid
        where  c.subtype = 14;  -- person
),

genius_users AS (
    select 
        null as first_name,
        null as last_name,
        t8t8un as full_name
    from {{ ref('staging_genius_zkt8') }} 
),

total_users AS (
    select * from cc_users
    UNION ALL
    select * from genius_users
)


{% set stage_relation = ref('staging_claim_center_cc_group') %}

{% set dwh_relation = 'claim_handler_groups' %}