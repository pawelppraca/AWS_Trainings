{% macro concatenate_part_columns_with_conversion(table_name, checksum_columns) %}
    {% set columns = checksum_columns %}
    {% set concatenated_columns = [] %}

    {% for column in columns %}
        {% set concatenated_columns = concatenated_columns + ["CAST(" ~ column.name ~ " AS STRING)"] %}
    {% endfor %}

    {% set concatenated_string = concatenated_columns | join(' || ') %}

    SELECT
        {{ concatenated_string }} AS concatenated_columns
    FROM {{ table_name }}
{% endmacro %}
