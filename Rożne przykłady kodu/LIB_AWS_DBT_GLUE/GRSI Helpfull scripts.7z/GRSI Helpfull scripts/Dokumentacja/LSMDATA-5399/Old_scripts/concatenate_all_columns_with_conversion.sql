{% macro concatenate_all_columns_with_conversion(table_name) %}
    {% set columns = adapter.get_columns_in_relation(ref(table_name)) %}
    {% set concatenated_columns = [] %}

    {% for column in columns %}
        {% if column.data_type in ('string', 'varchar', 'text') %}
            {% set concatenated_columns = concatenated_columns + [column.name] %}
        {% else %}
            {% set concatenated_columns = concatenated_columns + ["CAST(" ~ column.name ~ " AS STRING)"] %}
        {% endif %}
    {% endfor %}

    {% set concatenated_string = concatenated_columns | join(' || ') %}

    SELECT
        {{ concatenated_string }} AS concatenated_columns
    FROM {{ ref(table_name) }}
{% endmacro %}
