{% test checksum_comparison_md5(model, target, key_source, key_target) %} 


WITH source_checksum AS (
    {{ checksum_md5(model, key_source) }}
),
target_checksum AS (
    {{ checksum_md5(target, key_target) }}
)

SELECT
    source_checksum.checksum AS source_checksum,
    target_checksum.checksum AS target_checksum
FROM source_checksum, target_checksum
WHERE source_checksum.checksum != target_checksum.checksum

{% endtest %}
