{% macro checksum_md5(table_name, key_column) %}
    SELECT
        {{key_column}}, 
        {{ "'" ~ local_md5(concatenate_all_columns_with_conversion(table_name)) ~ "'"}} AS checksum
    FROM {{ table_name }}
{% endmacro %}

