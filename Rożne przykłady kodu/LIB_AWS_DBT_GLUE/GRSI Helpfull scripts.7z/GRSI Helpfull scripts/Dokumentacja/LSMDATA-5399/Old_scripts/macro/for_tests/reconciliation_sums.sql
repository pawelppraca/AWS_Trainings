
{% macro reconciliation_sums(
        s_model_1, 
        s_model_2, 
        s_group_column_names, 
        s_summary_column, 
        s_join_conditions, 
        s_where_condition, 
        s_having_condition, 
    
        t_model_1, 
        t_model_2, 
        t_group_column_names, 
        t_summary_column, 
        t_join_conditions, 
        t_where_condition, 
        t_having_condition

    ) %}

    

    {% if s_model_2 != '' %}

        WITH source_cte AS
        (
            select 
                {% for s_col in s_group_column_names %}
                    {{ s_col }} {% if not loop.last %},{% endif %}
                {% endfor %}
                , SUM({{ s_summary_column }}) AS source_SUM
            from  {{ s_model_1 }}   
            join  {{ s_model_2 }}    on 
                    {% for s_condition in s_join_conditions %}
                        {{ s_condition }} {% if not loop.last %} AND {% endif %}
                    {% endfor %}
            --WHERE Clause
            {% if s_where_condition %}
            where {{ s_where_condition }}
            {% endif %}
            --GROUP BY  
            {{ dbt_utils.group_by(n=s_group_column_names|length) }}
            --having clause
            {% if s_having_condition %}
            having {{ s_having_condition }}
            {% endif %}
            
        ),

    {% endif %}        

    {% if s_model_2 == '' %}

        WITH source_cte AS
        (
            select 
                {% for s_col in s_group_column_names %}
                    {{ s_col }} {% if not loop.last %},{% endif %}
                {% endfor %}
                ,SUM({{ s_summary_column }}) AS source_SUM
            from {{ s_model_1 }}  
            --WHERE Clause
            {% if s_where_condition %}
            where {{ s_where_condition }}
            {% endif %}
            --GROUP BY  
            {{ dbt_utils.group_by(n=s_group_column_names|length) }}
            --having clause
            {% if s_having_condition %}
            having {{ s_having_condition }}
            {% endif %}
        ),

    {% endif %}        


    
    
    {% if t_model_2 != '' %}
    
        target_cte AS
            (
                select 
                    {% for t_col in t_group_column_names %}
                        {{ t_col }} {% if not loop.last %},{% endif %}
                    {% endfor %}
                    ,SUM({{ t_summary_column }}) AS target_SUM
                from  {{ t_model_1 }}  
                join  {{ t_model_2 }}    on 
                        {% for t_condition in t_join_conditions %}
                            {{ t_condition }} {% if not loop.last %} AND {% endif %}
                        {% endfor %}
                --WHERE Clause
                {% if t_where_condition %}
                where  {{ t_where_condition }}
                {% endif %}
                --GROUP BY  
                {{ dbt_utils.group_by(n=t_group_column_names|length) }}
                --having clause
                {% if t_having_condition %}
                having {{ t_having_condition }}
                {% endif %}
                
            ),
    {% endif %}        


    {% if t_model_2 == '' %}

        target_cte AS
            (
                select 
                    {% for t_col in t_group_column_names %}
                        {{ t_col }} {% if not loop.last %},{% endif %}
                    {% endfor %}
                    ,SUM({{ t_summary_column }}) AS target_SUM
                from {{ t_model_1 }}  
                --WHERE Clause
                {% if t_where_condition|length > 0 %}
                    {{ "WHERE " ~ t_where_condition}}
                {% endif %}
                --GROUP BY  
                {{ dbt_utils.group_by(n=t_group_column_names|length) }}
                --having clause
                {% if t_having_condition|length > 0 %}
                    {{ "HAVING " ~ t_having_condition}}
                {% endif %}
            )
    
    {% endif %}  

    
    select * from source_cte s
    join target_cte t ON
            {% for t_col in t_group_column_names %}
                {{ "t." ~ t_col ~ " = s."~ s_group_column_names[loop.index-1] }} {% if not loop.last %} AND {% endif %}
            {% endfor %}
    WHERE source_SUM <> target_SUM


{% endmacro %}



