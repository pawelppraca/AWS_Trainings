
{% macro prep_coverages_sums(model, source_column_name, target_column_name) %}

WITH source_cte AS
(
    select qualifiercode AS coverage_code
        , qualifiername AS coverage_name
        ,SUM(l.{{ source_column_name }}) AS source_SUM
    from {{ ref('staging_warehouse_repository_limits') }} l
    join {{ ref('staging_warehouse_repository_policies') }} r on r.policykey = l.policykey
    WHERE l._currentflag= true
    GROUP BY l.qualifiercode, l.qualifiername
),

target_cte AS (
    SELECT  coverage_code
            , coverage_name
            , SUM({{ target_column_name }}) as target_SUM
    FROM {{ model }}
    WHERE _currentflag = true
    GROUP BY coverage_code, coverage_name
)

select * from source_cte s
join target_cte t on t.coverage_code = s.coverage_code AND t.coverage_name = s. coverage_name
WHERE source_SUM <> target_SUM


{% endmacro %}



