{% macro checksum_md5_columns(table_name, key_column, checksum_columns, where_condition) %}

    SELECT
        {{ key_column }} AS key_id,
        {{"md5(" }}
        {% for col in checksum_columns %}
            {{ "CONVERT( VARCHAR(256), " ~  col  ~ ") "}} {% if not loop.last %} || {% endif %}
        {% endfor %}
        {{ ")  AS checksum"}}
    FROM {{ table_name }} 
    --WHERE Clause
    {% if where_condition|length > 0 %}
        {{ "WHERE " ~ where_condition}}
    {% endif %}
{% endmacro %}

