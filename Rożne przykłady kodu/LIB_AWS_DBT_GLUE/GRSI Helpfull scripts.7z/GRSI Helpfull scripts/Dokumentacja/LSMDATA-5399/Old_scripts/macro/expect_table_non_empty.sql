{% test expect_table_non_empty(model, row_condition=None) %}
    {{ default__expect_table_non_empty(model, row_condition) }}
{% endtest %}

{% macro default__expect_table_non_empty(model, row_condition) %}
with
    limited as (
        select 1
        from {{ model }}
        {%- if row_condition %} where {{ row_condition }} {% endif %}
        limit 1
    ),
    grouped_expression as (select count(*) as expression from limited),
    validation_errors as (select * from grouped_expression where not (expression > 0))

select *
from validation_errors

{% endmacro %}


