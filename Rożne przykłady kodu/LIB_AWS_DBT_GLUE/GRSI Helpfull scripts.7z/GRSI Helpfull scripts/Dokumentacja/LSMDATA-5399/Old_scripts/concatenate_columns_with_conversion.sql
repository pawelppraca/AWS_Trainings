{% macro concatenate_columns_with_conversion(checksum_columns) %}
    {% set columns = checksum_columns %}
    {% set concatenated_columns = [] %}

    {% for column in columns %}
        {% set concatenated_columns = concatenated_columns + ["CAST(" ~ column.name ~ " AS STRING)"] %}
    {% endfor %}

    {% set concatenated_string = concatenated_columns | join(' || ') %}

     --{{ concatenated_string }}
    SELECT
        {{ concatenated_string }} AS concatenated_columns
    FROM {{ table_name }}
{% endmacro %}
