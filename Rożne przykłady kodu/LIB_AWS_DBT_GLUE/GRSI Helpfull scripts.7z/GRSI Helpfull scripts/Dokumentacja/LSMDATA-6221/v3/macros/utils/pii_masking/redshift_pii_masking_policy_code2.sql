{% macro redshift_pii_masking_policy_code2(schema_name, table_name, column_name, is_user, role_name, mask, data_type, priority) %}

    {% set masking_policy_name = table_name ~'_'~ column_name ~ '_masking' %}
    {% set table_name = schema_name ~'.'~ table_name %}

    

    {# Creating Masking Policy #}
    CREATE MASKING POLICY {{ masking_policy_name }} 
    WITH ( __data_region VARCHAR(100)  ,  {{ column_name }}
        {% if data_type | lower == "varchar" -%}
            VARCHAR(256) 
        {% elif data_type | lower == "number"-%}
            INT 
        {% elif data_type | lower == "date"-%}
            DATE 
        {% endif  -%}
    )
    USING
    (
        CASE
        WHEN   (__data_region = 'US' AND USER_IS_MEMBER_OF (CURRENT_USER, 'aad:g-np-us-lii-claims-mart-pii-read-only'))
            OR (__data_region = 'Europe' AND USER_IS_MEMBER_OF (CURRENT_USER, 'aad:g-np-eu-lii-claims-mart-pii-read-only'))
            OR (__data_region = 'APAC' AND USER_IS_MEMBER_OF (CURRENT_USER, 'aad:g-np-ap-lii-claims-mart-pii-read-only'))
        THEN {{ column_name }}
        {% if data_type | lower == "varchar" -%}
        ELSE {{ "'" ~ mask ~ "'" }} 
        {% elif data_type | lower == "number" -%}
        ELSE {{  mask  }} 
        {% elif data_type | lower == "date" -%}
        ELSE {{  "'" ~ mask ~ "'"  }} 
        {% endif -%}  
        END 
    ) ;
    {# Attaching Masking POLICY #}
    ATTACH MASKING POLICY {{ masking_policy_name }}
        ON {{ table_name }} ( {{ column_name }} )
        USING ( __data_region , {{ column_name }})
    {% if role_name | lower == "public" -%}
        TO {{  role_name }} 
    {% elif is_user == true -%}
        TO {{ '"' ~ role_name ~ '"' }} 
    {% else -%}
        TO ROLE {{ '"' ~ role_name ~ '"'}} 
    {% endif -%}  
    PRIORITY {{ priority }};

{% endmacro %}
