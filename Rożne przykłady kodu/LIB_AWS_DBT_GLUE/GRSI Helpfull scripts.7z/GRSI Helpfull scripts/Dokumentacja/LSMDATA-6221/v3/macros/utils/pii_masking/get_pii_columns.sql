{% macro get_pii_columns(model_name) %}

    {#-- Prevent querying of db in parsing mode.-#}
    {%- if not execute %}
        {{ return('') }}
    {% endif -%}

    {%- set columns = [] %}

    {% set columns = get_columns_by_meta_property_value(model_name, 'pii', 'yes') -%}

    {{ return(columns) }} 

{% endmacro %}