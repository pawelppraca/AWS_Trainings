{% macro pii_masking_utility(schema_name, table_name, column_name, role_name) %}
    
    {#-- Prevent querying of db in parsing mode.-#}
    {%- if not execute %}
        {{ return('') }}
    {% endif -%}

    {% set masking_policy_name = table_name ~'_'~ column_name ~ '_masking' %}
    
    {% if role_name | lower == "public" %}
        {% set masking_policy_name = masking_policy_name ~ '_public' %}
    {% endif %}

    {% do dbt_utils.log_info("Displaying data of masking policies named: " ~  masking_policy_name ) %} 


    {# {% set query0 = "select * from reconciliation.policy_masking_test2 LIMIT 5" %}
    {% set query0_results = run_query(query0) %}

    {% do dbt_utils.log_info("Data of query0: " ~  query0 ) %} 
    {% do query0_results.print_table() %} #}



    {% set query1 = "select * from svv_masking_policy" %}
    {% set query1_results = run_query(query1) %}

    {% do dbt_utils.log_info("Data of query: " ~  query1 ) %} 
    {% do query1_results.print_table() %}

    {% do dbt_utils.log_info("policy_name : " ~  query1_results.columns[1].values() ) %} 
    {% do dbt_utils.log_info("input_columns : " ~  query1_results.columns[2].values() ) %} 
    {% do dbt_utils.log_info("policy_expression : " ~  query1_results.columns[3].values() ) %} 


    {% set query2 = "SELECT  * FROM svv_attached_masking_policy " %}
    {% set query2_results = run_query(query2) %}
    
    {% do dbt_utils.log_info("Data of query: " ~  query2 ) %} 
    {% do query2_results.print_table() %}

    {% do dbt_utils.log_info("policy_name : " ~  query2_results.columns[0].values() ) %} 
    {% do dbt_utils.log_info("schema_name : " ~  query2_results.columns[1].values() ) %} 
    {% do dbt_utils.log_info("table_name : " ~  query2_results.columns[2].values() ) %} 
    {% do dbt_utils.log_info("grantee : " ~  query2_results.columns[5].values() ) %} 


    {# {% set detach_query_policy = "SELECT * FROM svv_attached_masking_policy WHERE grantee = '" ~ role_name ~ "' AND policy_name = '" ~ masking_policy_name ~ "' " %}
    {% set detach_query_policy_result = run_query(detach_query_policy) %}


    {% do dbt_utils.log_info("detach_query_policy : " ~  detach_query_policy ) %} 
    {% do detach_query_policy_result.print_table() %}

    {% do dbt_utils.log_info("policy_name : " ~  detach_query_policy_result.columns[0].values() ) %} 
    {% do dbt_utils.log_info("schema_name : " ~  detach_query_policy_result.columns[1].values() ) %} 
    {% do dbt_utils.log_info("table_name : " ~  detach_query_policy_result.columns[2].values() ) %} 
    {% do dbt_utils.log_info("grantee : " ~  detach_query_policy_result.columns[5].values() ) %} 


    {% set detach_query = "SELECT 1 IS_ATTACHED FROM svv_attached_masking_policy WHERE grantee = '" ~ role_name ~ "' AND policy_name = '" ~ masking_policy_name ~ "' " %}
    {% set detach_query_results = run_query(detach_query) %}

    {% set policy_exists = detach_query_results.columns[0].values()[0] %}
    {% do dbt_utils.log_info("policy_exists : " ~  policy_exists ) %} 

    {% do dbt_utils.log_info("detach_query : " ~  detach_query ) %} 
    {% do detach_query_results.print_table() %}

    {% do dbt_utils.log_info("IS_ATTACHED : " ~  detach_query_results.columns[0].values() ) %} 

   
    {% if policy_exists == 1 %}
        {% do dbt_utils.log_info("policy_exists =1 , czy tak?: " ~  policy_exists ) %} 
    {% else -%}
        {% do dbt_utils.log_info("policy_exists jest puste , czy tak?: " ~  policy_exists ) %} 
    {% endif -%}   #}


{% endmacro %}