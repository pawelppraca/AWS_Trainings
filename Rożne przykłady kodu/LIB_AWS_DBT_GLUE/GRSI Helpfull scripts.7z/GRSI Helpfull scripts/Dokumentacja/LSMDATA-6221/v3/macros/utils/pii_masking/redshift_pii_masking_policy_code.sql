{% macro redshift_pii_masking_policy_code(table_name, column_name, role_name, mask, data_type, priority) %}

    {% set masking_policy_name = table_name ~'_'~ column_name ~ '_masking' %}

    
    {# Detaching Masking Policy if Attach #}
    {% if is_pii_masking_policy_attached(masking_policy_name, table_name, column_name) %} 
       
        DETACH MASKING POLICY {{ masking_policy_name }}
            ON {{ table_name }}( {{column_name}} )
        FROM ROLE {{ role_name }} ;

    {% endif %}

    {# Dropping Masking POLICY #}
    DROP MASKING POLICY IF EXISTS {{ masking_policy_name }};

    {# Creating Masking Policy #}
    CREATE MASKING POLICY {{ masking_policy_name }} 
    WITH ( {{ insured_code TEXT, column_name }}
        {% if data_type | lower == "varchar" %}
            TEXT 
        {% elif data_type | lower == "number"%}
            INT 
        {% elif data_type | lower == "date"%}
            DATE 
        {% endif  %}
    )
    USING
    (
        CASE
        {# WHEN   (region = 'US' AND USER_IS_MEMBER_OF (CURRENT_USER, 'aad:g-np-us-lii-claims-mart-pii-read-only'))
            OR (region = 'Europe' AND USER_IS_MEMBER_OF (CURRENT_USER, 'aad:g-np-eu-lii-claims-mart-pii-read-only'))
            OR (region = 'AP' AND USER_IS_MEMBER_OF (CURRENT_USER, 'aad:g-np-ap-lii-claims-mart-pii-read-only')) #}
        WHEN insured_code = "RKCA0001"
        THEN {{ column_name }}
        {% if data_type | lower == "varchar" -%}
        ELSE {{ "'" ~ mask ~ "'" }} ::TEXT
        {% elif data_type | lower == "number" -%}
        ELSE {{  mask  }} ::INT
        {% elif data_type | lower == "date" -%}
        ELSE {{  mask  }} ::DATE
        {% endif -%}  
        END 
    ) ;
    {# Attaching Masking POLICY #}
    ATTACH MASKING POLICY {{ masking_policy_name }}
        ON {{ table_name }} ( {{ column_name }} )
        USING ( region , {{ column_name }})
    TO ROLE {{ '"' ~ role_name ~ '"'}} 
    PRIORITY {{ priority }};

{% endmacro %}
