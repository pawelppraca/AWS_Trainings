{% macro redshift_pii_masking_policy_code(schema_name, table_name, column_name, role_name, mask, data_type, priority) %}

    {% set masking_policy_name = table_name ~'_'~ column_name ~ '_unmasking' %}
    {% if role_name | lower == "public" %}
        {% set masking_policy_name = masking_policy_name | replace ('_unmasking','_masking') %}
    {% endif %}

    {% set table_name = schema_name ~'.'~ table_name %}

    {#  Checking if Masking Polisy is Attached #}
    {% if is_pii_masking_policy_exists (masking_policy_name,table_name) == false %}
      
        {# Creating Masking Policy #}
        CREATE MASKING POLICY {{ masking_policy_name }} 
        {# WITH ( insured_code VARCHAR(256)  ,  {{ column_name }} #}
        WITH ( {{ column_name }}
            {% if data_type | lower == "varchar" -%}
                VARCHAR(256) 
            {% elif data_type | lower == "number"-%}
                INT 
            {% elif data_type | lower == "date"-%}
                DATE 
            {% endif  -%}
        )
        USING
        (
            {% if mask  == ""-%}
                {{ column_name }}
            {% elif data_type | lower == "varchar" -%}
                {{ "'" ~ mask ~ "' :: TEXT" }} 
            {% elif data_type | lower == "number" -%}
                {{  mask ~ " :: INT" }} 
            {% elif data_type | lower == "date" -%}
                {{  "'" ~ mask ~ "' :: DATE"  }} 
            {% endif -%}  

        ) ;

    {% endif %}

    {% if is_pii_masking_policy_attached(masking_policy_name,table_name) == false %} 
        {# Attaching Masking POLICY #}
        ATTACH MASKING POLICY {{ masking_policy_name }}
            ON {{ table_name }} ( {{ column_name }} )
            {# USING ( insured_code , {{ column_name }}) #}
            USING ( {{ column_name }})
        {% if role_name | lower == "public" -%}
            TO PUBLIC
        {% elif role_name[0:4] == "aad:" -%}  
            TO ROLE {{ '"' ~ role_name ~ '"' }} 
        {% else -%}
            TO {{ '"' ~ role_name ~ '"'}} 
        {% endif -%}  
        PRIORITY {{ priority }};
 
    {% endif -%}  

{% endmacro %}
