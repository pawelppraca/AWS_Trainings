{% macro redshift_pii_masking_policy_drop(schema_name, table_name, column_name, role_name) %}

    {% set masking_policy_name = table_name ~'_'~ column_name ~ '_masking' %}

    {% if role_name | lower == "public" %}
        {% set masking_policy_name = masking_policy_name ~ '_public' %}
    {% endif %}

    {# {% set query_attached = "SELECT * FROM svv_attached_masking_policy " %}
    {% set query_results = run_query(query_attached) %}
    
    {% do dbt_utils.log_info("query_attached : " ~  query_attached ) %} 
    
    {% do query_results.print_table() %} #}


    {% set detach_query = "SELECT 1 IS_Policy_Attached FROM svv_attached_masking_policy WHERE policy_name = '" ~ masking_policy_name ~ "' AND grantee = '" ~ role_name ~ "' " %}
    {% set detach_query_results = run_query(detach_query) %}
    
    {# {% do dbt_utils.log_info("detach_query : " ~  detach_query ) %} 
    
    {% do detach_query_results.print_table() %}
    
    {% do dbt_utils.log_info("IS_Policy_Attached : " ~  detach_query_results.columns[0].values() ) %}  #}

    {% set policy_exists = detach_query_results.columns[0].values()[0] %}

    {# Deatching POLICY if Attached #}
    {% if policy_exists == 1 %}
        DETACH MASKING POLICY  {{ masking_policy_name }}
            ON {{table_name}}({{column_name}})
        {% if role_name | lower == "public" -%}
            FROM PUBLIC
        {% elif role_name[0:4] == "aad:" -%}  {# for AD Role #}
            FROM ROLE {{ '"'~role_name~'"' }}  
        {% else -%}
            FROM {{ '"'~role_name~'"' }} {# for User #}
        {% endif -%}  
        ;
    {% endif %}


    {# Dropping Masking POLICY #}
    DROP MASKING POLICY IF EXISTS {{ masking_policy_name }};

{% endmacro %}