{% macro redshift_pii_masking_policy_detach_drop(schema_name, table_name) %}

  
        {# get pii columns in the relation #}
        {% set model_cols = adapter.get_columns_in_relation(this) %} 
        {% set pii_columns = get_pii_columns(model_name) -%} 
        {% set table_name = this | replace (this.database ~ '.','') %}
        {% set table_name = table_name | replace (schema~'.', '')  %}
      

        {% set code = namespace(value='') %}
        {% set code_part = namespace(value='') %}

        {% for col in model_cols %}

            {% if is_pii_column(model_name, col.name) %} 

                {#  FOR ROLE  #}
                {% set masking_policy_name = table_name ~'_'~ col.name ~ '_masking' %}

                {% set detach_query = "SELECT table_name , role_name FROM svv_attached_masking_policy WHERE policy_name = '" ~ masking_policy_name ~ "' " %}
                {% set detach_query_results = run_query(detach_query) %}

                {# Displaying Table #}
                {% do detach_query_results.print_table() %}
                
                {% set attach_table = detach_query_results.columns[0].values()[0] %}
                {% set role_name = detach_query_results.columns[1].values()[0] %}
                
                {% if attach_table | length > 0 %}

                    {% set code_part.value  %}
                    
                        DETACH MASKING POLICY  {{ masking_policy_name }}
                            ON {{attach_table}}({{col.name}})
                        {% if role_name | lower == "public" -%}
                            FROM PUBLIC
                        {% elif role_name[0:4] == "aad:" -%}  {# for AD Role #}
                            FROM ROLE {{ '"'~role_name~'"' }}  
                        {% else -%}
                            FROM {{ '"'~role_name~'"' }} {# for User #}
                        {% endif -%}  
                        ;

                    {% endset %} {# end of set masking_policy_code #}

                    {% set code.value = code.value ~ code_part.value %}
                    {% set code_part.value = '' %}
                {% endif %}


                {#  FOR PUBLIC  #}
                {% set masking_policy_name_public = masking_policy_name ~ '_public' %}

                {% set detach_query = "SELECT table_name , role_name FROM svv_attached_masking_policy WHERE policy_name = '" ~ masking_policy_name ~ "' " %}
                {% set detach_query_results = run_query(detach_query) %}

                {# Displaying Table #}
                {% do detach_query_results.print_table() %}
                
                {% set attach_table = detach_query_results.columns[0].values()[0] %}
                {% set role_name = detach_query_results.columns[1].values()[0] %}
                
                {% if attach_table | length > 0 %}

                    {% set code_part.value  %}
                    
                        DETACH MASKING POLICY  {{ masking_policy_name }}
                            ON {{attach_table}}({{col.name}})
                        {% if role_name | lower == "public" -%}
                            FROM PUBLIC
                        {% elif role_name[0:4] == "aad:" -%}  {# for AD Role #}
                            FROM ROLE {{ '"'~role_name~'"' }}  
                        {% else -%}
                            FROM {{ '"'~role_name~'"' }} {# for User #}
                        {% endif -%}  
                        ;

                    {% endset %} {# end of set masking_policy_code #}

                    {% set code.value = code.value ~ code_part.value %}
                    {% set code_part.value = '' %}
                {% endif %}


            {% endfor %}



    {# Dropping Masking POLICY #}
    DROP MASKING POLICY IF EXISTS {{ masking_policy_name }};

  
{% endmacro %}