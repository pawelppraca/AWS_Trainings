{# Test Model to checking Reduction of the columns underwriter_name and inception_date_key  #}
{{
   config(
       pre_hook = [
                    "{{ pii_masking_show('Displaying MASKING POLICY on pre_hook') }}"
       ]
   )
}} 


{{
    generate_cte(
        [
            {"table": "policy", "alias": "dwh_policy_masking", "columns": ["policy_number","policy_reference", "underwriter_code", "underwriter_name", "risk_engineer_code", "risk_engineer_name", "insured_name", "insured_code", "year_of_account", "inception_date_key"]},
        ]
    )
}}, 

final AS (
    select *
    from dwh_policy_masking
)


select *
FROM final

{{
   config(
       post_hook = [
                    "{{ pii_masking_show('Displaying MASKING POLICY on post_hook before creating') }}"
                    ,"{{ create_pii_masking_policies(model.schema, model.name, 'v-token-pa-break-gl-3dhtqzmgaxfixevx6euz-1743747205', 10) }}"
                    ,"{{ pii_masking_show('Displaying MASKING POLICY on post_hook after creating') }}"
                    ]
   )
}}

{#  

Dropping masking policy
                    ,"{{ redshift_pii_masking_policy_detach_drop(model.schema, model.name) }}"

Creating masking Policy
                    ,"{{ create_pii_masking_policies(model.schema, model.name, 'v-token-pa-break-gl-gltp3lzk0s78zbrcmmaf-1743581500', 10) }}"

Displaying Masking Policy
                    ,"{{ pii_masking_utility(model.schema, model.name, 'underwriter_name', 'v-token-pa-break-gl-gltp3lzk0s78zbrcmmaf-1743581500') }}"                    


                    "{{ create_pii_masking_policies(model.schema, model.name, 'v-token-pa-break-gl-9jeg7vbe6jno1khwlqse-1743491281', 10) }}"


                    "{{ pii_masking_utility(model.schema,model.name, 'underwriter_name', 'v-token-pa-break-gl-9jeg7vbe6jno1khwlqse-1743491281') }}",
                    "{{ create_pii_masking_policies(model.schema, model.name, 'v-token-pa-break-gl-9jeg7vbe6jno1khwlqse-1743491281', 10) }}"



"{{ create_pii_masking_policies(model.schema,model.name, 'v-token-pa-break-gl-9jeg7vbe6jno1khwlqse-1743491281', 10)  }}"

"{{ pii_masking_utility(model.schema,model.name, 'underwriter_name', 'v-token-pa-break-gl-lcd64aaur7xupt9kqcdd-1743412553') }}"

 aad:g-np-eu-lii-claims-mart-pii-read-only #}
