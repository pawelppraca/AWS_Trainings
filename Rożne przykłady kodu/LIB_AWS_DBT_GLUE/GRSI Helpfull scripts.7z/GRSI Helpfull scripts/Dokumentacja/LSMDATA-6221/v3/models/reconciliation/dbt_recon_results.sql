
WITH final AS (
    select *
    from reconciliation.dbt_test_results
)


select *
FROM final