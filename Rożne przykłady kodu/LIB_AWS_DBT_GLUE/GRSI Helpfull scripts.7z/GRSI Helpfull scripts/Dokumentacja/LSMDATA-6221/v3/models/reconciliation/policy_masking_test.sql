{# Test Model to checking Reduction of the columns underwriter_name and inception_date_key  #}
{{
    generate_cte(
        [
            {"table": "policy", "alias": "dwh_policy_masking", "columns": ["policy_number","policy_reference", "underwriter_code", "underwriter_name", "risk_engineer_code", "risk_engineer_name", "insured_name", "insured_code", "year_of_account", "inception_date_key"]},
        ]
    )
}}, 

final AS (
    select *
    from dwh_policy_masking
)


select *
FROM final

{{
   config(
       post_hook = create_pii_masking_policies(model.name,'aad:g-np-eu-lii-claims-mart-pii-read-only', 10) 
   )
}}

