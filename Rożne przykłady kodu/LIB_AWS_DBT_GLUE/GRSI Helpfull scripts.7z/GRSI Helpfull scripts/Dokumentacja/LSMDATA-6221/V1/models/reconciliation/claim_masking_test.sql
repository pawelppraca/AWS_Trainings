{# Test Model to checking Reduction of the column  #}
{{
    generate_cte(
        [
            {"table": "claim", "alias": "dwh_claim_masking", "columns": ["claim_key", "policy_key", "claim_number", "date_claim_created", "claim_state"]},
        ]
    )
}}, 

final AS (
    select *
    from dwh_claim_masking
)


select *
FROM final

{{
   config(
       post_hook = create_pii_reduction_view() 
   )
}}

