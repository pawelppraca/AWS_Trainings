{% macro column_has_tag(column_name, tag) %}
    {% set tags = get_column_tags(column_name) %}
    {{ return(tag in tags) }}
{% endmacro %}