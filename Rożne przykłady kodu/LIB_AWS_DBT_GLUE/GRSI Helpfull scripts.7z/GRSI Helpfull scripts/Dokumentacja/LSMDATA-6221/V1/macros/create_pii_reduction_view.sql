{% macro create_pii_reduction_view(columns_to_mask = '') %}
   {% if execute %}
  
   {# get all columns in the relation #}
  
       {% set model_cols = adapter.get_columns_in_relation(this) %}
      
       {# create Relation object for masked view #}
      
       {%- set masked_view = api.Relation.create(
             database=this.database,
             schema=schema,
             identifier=this.identifier) ~ '_reduced_view' -%}



       {# create masked view in new schema for sensitive columns #}
        {# {% set view_columns %}
          
                   {% for col in model_cols %}
                       {% if column_has_tag(col.name, 'pii') %}
                       {{ pii_reduction_column(col.name) }} 
                       {%- else %}
                       {{ col.name }}
                       {%- endif -%}
                       {{ ", " if not loop.last }}
                   {%- endfor %}
        {% endset %}

        {% do dbt_utils.log_info("view_columns : " ~  view_columns ) %}  #}

       {% set view_sql %}
 
           DROP VIEW IF EXISTS {{ masked_view }};

           create view {{ masked_view }} as (
 
               select 
                   {% for col in model_cols %}
                       {# {%- if col.name in columns_to_mask -%} #}
                       {% if column_has_tag(col.name, 'pii') %}
                       {{ pii_reduction_column(col.name) }} 
                       {%- else %}
                       {{ col.name }}
                       {%- endif -%}
                       {{ ", " if not loop.last }}
                   {%- endfor %}
               from {{ this }}
           )
 
       {% endset %}
      
       {% do run_query(view_sql) %}
      
       {% do dbt_utils.log_info("Masked view sql: " ~  view_sql ) %} 
      
   {% endif %}
  
   select 1=1
  
{% endmacro %}