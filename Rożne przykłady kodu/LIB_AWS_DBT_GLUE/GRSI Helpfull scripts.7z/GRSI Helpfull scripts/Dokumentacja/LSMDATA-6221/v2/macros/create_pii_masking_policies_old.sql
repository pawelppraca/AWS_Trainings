{% macro create_pii_masking_policies(model_name, role_name, priority) %}
   {% if execute %}
  
       {# get pii columns in the relation #}
       {% set model_cols = adapter.get_columns_in_relation(this) %} 
       {% set pii_columns = get_pii_columns(model_name) -%} 
      
       {# create name for masked view #}
       {%- set masked_view = api.Relation.create(
             database=this.database,
             schema=schema,
             identifier=this.identifier) ~ '_masking_view' -%}

        {% set table_name = this | replace (this.database ~ '.','') %}
        {% set table_name = table_name | replace (schema~'.', '')  %}
        
        {% set masking_policy_code ='' %}
        {% set masking_policy_code_part ='' %}
        
            {# Utworzenie Masking Policies #}
            {% for col in model_cols %}

                {# {% if is_pii_column(model_name, col.name) %} #}

                {% if col.name in pii_columns %}

                    {% do dbt_utils.log_info("Column : " ~  col.name ~ 'is PII' ) %} 
                   
                    {% set masking_policy_code_part  %}
                    
                        {% if col.is_string() %}
                            {#  Creating Policy for text values #}
                            {% if is_pii_masking_policy_attached(masking_policy_name, table_name, col.name) %} 
                                {{ detach_pii_masking_policy(masking_policy_name, this, col.name, role_name) }}
                            {% endif %}
                            {{ drop_pii_masking_policy(masking_policy_name) }}
                            {{ create_pii_masking_policy(masking_policy_name, col.name,'XXXXXXX','varchar') }}   
                            {{ attach_pii_masking_policy(masking_policy_name, this, col.name, 'region ', role_name, priority)}}
                        {% elif col.is_number() %}
                            {#  Creating masking policy for numbers #}
                            {% if is_pii_masking_policy_attached(masking_policy_name, table_name, col.name) %} 
                                {{ detach_pii_masking_policy(masking_policy_name, this, col.name, role_name) }}
                            {% endif %}
                            {{ drop_pii_masking_policy(masking_policy_name) }}
                            {{ create_pii_masking_policy(masking_policy_name, col.name,'-1','number') }}   
                            {{ attach_pii_masking_policy(masking_policy_name, this, col.name, 'region ', role_name, priority)}}
                        {% elif is_date_column(col.name) %}
                            {#  Creating masking policy for date and timestamp #}
                            {% if is_pii_masking_policy_attached(masking_policy_name, table_name, col.name) %} 
                                {{ detach_pii_masking_policy(masking_policy_name, this, col.name, role_name) }}
                            {% endif %}
                            {{ drop_pii_masking_policy(masking_policy_name) }}
                            {{ create_pii_masking_policy(masking_policy_name, col.name,'7/4/1776','date') }}   
                            {{ attach_pii_masking_policy(masking_policy_name, this, col.name, 'region ', role_name, priority)}}
                        {% endif %}
                    {% endset %} {# end of set masking_policy_code #}
                {% endif %}

                {% set masking_policy_code = masking_policy_code_part %}
                {% set masking_policy_code_part = '' %}
            {% endfor %}


        {% do dbt_utils.log_info("masking_policy_code : " ~  masking_policy_code ) %} 

        {# {% do run_query(masking_policy_code) %} #}
    
      
   {% endif %}
  
   select 1=1
  
{% endmacro %}