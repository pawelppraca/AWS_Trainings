{% macro drop_pii_masking_policy(policy_name) %}

    DROP MASKING POLICY  IF EXISTS {{ policy_name }};

{% endmacro %}
