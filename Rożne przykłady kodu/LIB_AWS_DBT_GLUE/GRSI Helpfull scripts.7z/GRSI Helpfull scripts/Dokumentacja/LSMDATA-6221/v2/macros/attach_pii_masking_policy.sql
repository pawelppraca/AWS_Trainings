{% macro attach_pii_masking_policy(policy_name, table_name, field_name, add_fields, role_name, priority) %}

    ATTACH MASKING POLICY {{ policy_name }}
        ON {{table_name}}( {{field_name}} )
        USING ({{add_fields }} , {{field_name}})
    TO ROLE {{ '"' ~ role_name ~ '"'}} 
    PRIORITY {{ priority }};


{% endmacro %}
