
{% macro is_pii_masking_policy_attached(policy_name, table_name, column_name) %}

    {#-- Prevent querying of db in parsing mode.-#}
    {%- if not execute %}
        {{ return('') }}
    {% endif -%}


    {% set count_query %}
      
        SELECT
            count(*) row_count
        FROM
            information_schema.columns c
        JOIN
            svv_masking_policy mp ON c.column_name = mp.input_columns
        JOIN
            information_schema.tables t ON t.table_schema = c.table_schema AND t.table_name = c.table_name
        WHERE
            mp.policy_name = {{"'" ~ policy_name ~ "'"}} 
            AND t.table_name = {{"'" ~ table_name ~ "'"}}
            AND c.column_name = {{"'" ~ column_name ~ "'"}}; 

    {% endset %}   

    {% set rowcount_results = run_query(count_query) %}
    {% set table_row_count = 0 %} 

    {% for row in rowcount_results %}
        {% set table_row_count = row["row_count"] %} 
    {% endfor %}

    {% set is_attached = false %}
   
    {% if table_row_count > 0  %}
      {% set is_attached = true %}
    {% endif %}
  
    {{ return(is_attached) }}
{% endmacro %}









