{% macro detach_pii_masking_policy(policy_name, table_name, column_name, role_name) %}

    DETACH MASKING POLICY {{ policy_name }}
        ON {{table_name}}( {{column_name}} )
    FROM ROLE {{ role_name }} ;

{% endmacro %}
