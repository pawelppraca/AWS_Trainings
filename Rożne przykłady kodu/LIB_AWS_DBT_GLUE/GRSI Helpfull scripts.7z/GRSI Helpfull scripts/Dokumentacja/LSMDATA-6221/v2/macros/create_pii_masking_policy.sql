{% macro create_pii_masking_policy(policy_name, column_name, mask, DATA_TYPE) %}

    CREATE MASKING POLICY {{ policy_name }} 
    {% if DATA_TYPE | lower == "varchar" %}
        WITH ( {{ column_name }}  TEXT )
    {% elif DATA_TYPE | lower == "number"%}
        WITH ( {{ column_name }}  INT )
    {% elif DATA_TYPE | lower == "date"%}
        WITH ( {{ column_name }}  DATE )
    {% endif  %}
    USING
    (CASE
        WHEN (region = 'US' AND USER_IS_MEMBER_OF(CURRENT_USER, 'aad:g-np-us-lii-claims-mart-pii-read-only'))
            OR (region = 'EU' AND USER_IS_MEMBER_OF(CURRENT_USER, 'aad:g-np-eu-lii-claims-mart-pii-read-only'))
            OR  (region = 'AP' AND USER_IS_MEMBER_OF(CURRENT_USER, 'aad:g-np-ap-lii-claims-mart-pii-read-only'))
        THEN {{ column_name }}
        {% if DATA_TYPE | lower == "varchar" -%}
        ELSE {{ "'" ~ mask ~ "'" }} ::TEXT
        {% elif DATA_TYPE | lower == "number" -%}
        ELSE {{  mask  }} ::INT
        {% elif DATA_TYPE | lower == "date" -%}
        ELSE {{  mask  }} ::DATE
        {% endif -%}                    
{% endmacro %}


