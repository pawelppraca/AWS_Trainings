{{
    generate_cte(
        [
            {"table": "dbt_test_results", "alias": "recon_results"},
        ]
    )
}}, 

final AS (
    select *
    from recon_results
)


select *
FROM final