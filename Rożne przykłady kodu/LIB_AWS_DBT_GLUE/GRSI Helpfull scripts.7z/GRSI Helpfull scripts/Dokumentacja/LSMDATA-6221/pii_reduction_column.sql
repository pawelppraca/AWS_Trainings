{% macro pii_reduction_column(column_name) %}

 case current_user()
   when 'admin' then {{ column_name }}
   else md5({{ column_name }})
 end as {{ column_name }}
 
{% endmacro %}