{% macro redshift_pii_masking_policy_detach_drop(schema_name, model_name) %}

  
        {#  TO WYMAGA POPRAWY #}

        {# get pii columns in the relation #}
        {% set model_cols = adapter.get_columns_in_relation(this) %} 
        {% set pii_columns = get_pii_columns(model_name) -%} 
        {% set table_name = this | replace (this.database ~ '.','') %}
        {% set table_name = table_name | replace (schema_name~'.', '')  %}
      

        {% set code = namespace(value='') %}
        {% set code_part = namespace(value='') %}

        {% for col in model_cols %}

            {% if is_pii_column(model_name, col.name) %} 

                {#  Checking Masking Policies attached for PII Column   #}
                {% set masking_policy_name = table_name ~'_'~ col.name ~ '_masking%' %}

                {% set detach_query = "SELECT policy_name, table_name , grantee FROM svv_attached_masking_policy WHERE policy_name like '" ~ masking_policy_name ~ "%' " %}
                {% set detach_query_results = run_query(detach_query) %}

                {# Displaying Table #}
                {% do dbt_utils.log_info("Data of query from dropping macro: " ~  detach_query ) %} 
                {% do dbt_utils.log_info("-------------------------------"  ) %} 
                {% do detach_query_results.print_table() %}
                {% do dbt_utils.log_info("-------------------------------"  ) %} 

                {% if detach_query_results | length > 0 %}

                    {% for row in detach_query_results.rows %}
                        {% set policy_name = row[0] %}
                        {% set table_name = row[1] | replace("__dbt_backup","")%}
                        {% set table_name = table_name ~ "__dbt_backup" %}
                        {% set role_name = row[2] %}

                        {% set code_part.value  %}
                        
                            DETACH MASKING POLICY  {{ policy_name }}
                                ON {{table_name}}({{col.name}})
                            {% if role_name | lower == "public" -%}
                                FROM PUBLIC
                            {% elif role_name[0:4] == "aad:" -%}  {# for AD Role #}
                                FROM ROLE {{ '"'~role_name~'"' }}  
                            {% else -%}
                                FROM {{ '"'~role_name~'"' }} {# for User #}
                            {% endif -%}  
                            ;

                        {% endset %} {# end of set masking_policy_code #}

                        {% set code.value = code.value ~ code_part.value %}
                        {% set code_part.value = '' %}

                    {% endfor %}

                {% endif %}

                {# Dropping Masking POLICY #}
                {% set drop_query = "SELECT policy_name FROM svv_masking_policy WHERE policy_name like '" ~ masking_policy_name ~ "%' " %}
                {% set drop_query_results = run_query(drop_query) %}

                {% if drop_query_results | length > 0 %}

                    {% for row in drop_query_results.rows %}
                        {% set policy_name = row[0] %}

                        {% set code_part.value  %}
                            DROP MASKING POLICY IF EXISTS {{ policy_name }};
                        {% endset %}

                        {% set code.value = code.value ~ code_part.value %}
                        {% set code_part.value = '' %}
                    {% endfor %}

                {% endif %}

            {% endif %}

        {% endfor %}

        {% do dbt_utils.log_info("masking_policy_code : " ~  code.value ) %} 

        {{ code.value }}
  
{% endmacro %}