{% macro redshift_pii_masking_policy_detach_drop_all() %}

    {# Macro detaching and dropping all existing Maskng Policies #}

    {% set code = namespace(value='') %}
    {% set code_part = namespace(value='') %}

    {# {% do dbt_utils.log_info("============================="  ) %} 
    {% do dbt_utils.log_info("Detaching all Masking Polices"  ) %} 
    {% do dbt_utils.log_info("============================="  ) %}  #}

    {% set detach_query = "SELECT policy_name, table_name , grantee FROM svv_attached_masking_policy " %}
    {% set detach_query_results = run_query(detach_query) %}

    {# Displaying Table #}
    {# {% do dbt_utils.log_info("Data of query from dropping macro: " ~  detach_query ) %} 
    {% do dbt_utils.log_info("-------------------------------"  ) %} 
    {% do dbt_utils.log_info("-------------------------------"  ) %}  #}

    {% set prefix = '[{"colname":"' %}
    {% set quote = '"' %}
    

    {% if detach_query_results | length > 0 %}

         {% for row in detach_query_results.rows %}
            {% set policy_name = row[0] %}
            {% set table_name = row[1] %}
            {% set role_name = row[2] %}

            {% set colname_query = "SELECT SUBSTRING(replace(input_columns,'"~ prefix ~"',''),1,CHARINDEX('" ~ quote ~ "',replace(input_columns,'" ~ prefix ~ "',''))-1) input_columns from svv_masking_policy WHERE policy_name = '" ~ policy_name ~ "'" %}
            {% set colname_query_results = run_query(colname_query) %}

            {% set column_name = colname_query_results.columns[0].values()[0] %}

            {% set code_part.value  %}
            
                DETACH MASKING POLICY {{ policy_name }}
                    ON {{table_name}}({{column_name}})
                {% if role_name | lower == "public" -%}
                    FROM PUBLIC
                {% elif role_name[0:4] == "aad:" -%}  
                    FROM ROLE {{ '"'~role_name~'"' }}  
                {% else -%}
                    FROM {{ '"'~role_name~'"' }} 
                {% endif -%}  
                ;

            {% endset %} 

            {% set code.value = code.value ~ code_part.value %}
            {% set code_part.value = '' %}

        {% endfor %} 

    {% endif %}

    {# Dropping Masking POLICY #}
    {# {% do dbt_utils.log_info("============================="  ) %} 
    {% do dbt_utils.log_info("Dropping all Masking Polices"  ) %} 
    {% do dbt_utils.log_info("============================="  ) %}  #}

    {% set drop_query = "SELECT policy_name FROM svv_masking_policy " %}
    {% set drop_query_results = run_query(drop_query) %}

    {# Displaying Table #}
    {# {% do dbt_utils.log_info("Data of query from dropping macro: " ~  drop_query ) %} 
    {% do dbt_utils.log_info("-------------------------------"  ) %} 
    {% do dbt_utils.log_info("-------------------------------"  ) %}  #}

    {% if drop_query_results | length > 0 %}

        {% for row in drop_query_results.rows %}
            {% set policy_name = row[0] %}

            {% set code_part.value  %}
                DROP MASKING POLICY IF EXISTS {{ policy_name }};
            {% endset %}

            {% set code.value = code.value ~ code_part.value %}
            {% set code_part.value = '' %}
        {% endfor %}

    {% endif %}

    {% do dbt_utils.log_info("Detaching and dropping of masking_policy  SQLcode : " ~  code.value ) %} 

    {{ code.value }}
  
{% endmacro %}