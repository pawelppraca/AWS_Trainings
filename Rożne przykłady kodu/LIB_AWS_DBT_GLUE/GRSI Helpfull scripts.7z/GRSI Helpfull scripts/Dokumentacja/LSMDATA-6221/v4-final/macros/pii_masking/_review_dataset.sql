{% macro _review_dataset(list) %}


    {# {% set insured_code = 'RKCA%' %}

    {% set query = "select insured_code,  policy_number, policy_reference, underwriter_code, underwriter_name from reconciliation.policy_masking_test2 where insured_code like '" ~ insured_code ~ "' " %}
    {% set query_results = run_query(query) %}

    
    {% do query_results.print_table() %}
    
    {% set rows = query_results | length %}
    
    {% do dbt_utils.log_info("rows : " ~  rows ) %} 

    {% do dbt_utils.log_info("query_results.rows : " ~  query_results.rows ) %} 
    
    

    {% for row in query_results.rows %}
        {% set var = row[0] %}

       {% do dbt_utils.log_info("var : " ~  var ) %} 
    {% endfor %} 
 #}

    {% do dbt_utils.log_info("Pętla na słowniku" ) %} 

    {% set lista = [{"colname":"underwriter_name","type":"character varying(256)"}
                    
                    ] %}
    {# ', '[{"colname":"underwriter_name","type":"character varying(256)"}]', '[{"colname":"year_of_account","type":"integer"}]', '[{"colname":"year_of_account","type":"integer"}]', '[{"colname":"inception_date_key","type":"date"}]', '[{"colname":"inception_date_key","type":"date"}]') %} #}


    {% set slownik = ({"colname":"underwriter_name","type":"character varying(256)","colname":"year_of_account","type":"integer","colname":"inception_date_key","type":"date"}) %}
    
    {% do dbt_utils.log_info("Słownik:" ~ slownik ) %}   
    {% do dbt_utils.log_info("Lista:" ~ lista ) %}   


    {% do dbt_utils.log_info("----------------------" ) %}   
    {% do dbt_utils.log_info("Przegląd Listy" ) %}   


    {% set item = dict() %}
    {% for item in lista %}
         {% do dbt_utils.log_info("element:" ~ item) %}   
         {% do dbt_utils.log_info("|") %}   
         {% do dbt_utils.log_info(item.colname) %}   
    {% endfor %}
    
{#     
    {%- for type, column_name in slownik.items() -%}
        
        {% do dbt_utils.log_info(type ~ " | " ~  column_name ) %}   

        {% if type == "colname" %}
            {% do dbt_utils.log_info("Nazwa kolumny : " ~  column_name ) %}   
        {% else %}
            {% do dbt_utils.log_info("Typ:" ~ type ~ " | Nazwa kolumny : " ~  column_name ) %}   
        {% endif %}
    {%- endfor -%} #}

    {% for element in list %}
        {% do dbt_utils.log_info("element of list:" ~ element) %} 
    {% endfor %}

{% endmacro %}