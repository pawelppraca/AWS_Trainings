
{% macro is_pii_masking_policy_attached(policy_name, table_name) %}

    {# Macro checks if Masking Policy is attached to table. It results true or false #}

    {#-- Prevent querying of db in parsing mode.-#}
    {%- if not execute %}
        {{ return('') }}
    {% endif -%}


    {% set count_query %}
      
        SELECT
            count(*) row_count
        FROM
            information_schema.columns c
        JOIN
            svv_attached_masking_policy amp ON c.table_name = amp.table_name
        WHERE
            amp.policy_name = {{"'" ~ policy_name ~ "'"}} 
            AND (amp.table_name = {{"'" ~ table_name ~ "'"}} OR amp.table_name = {{"'" ~ table_name ~ "__dbt_backup'"}})

    {% endset %}   

    {% set rowcount_results = run_query(count_query) %}
    {% set table_row_count = rowcount_results.columns[0].values()[0] %}

    {% set is_attached = false %}
   
    {% if table_row_count > 0  %}
      {% set is_attached = true %}
    {% endif %}
  
    {{ return(is_attached) }}
{% endmacro %}









