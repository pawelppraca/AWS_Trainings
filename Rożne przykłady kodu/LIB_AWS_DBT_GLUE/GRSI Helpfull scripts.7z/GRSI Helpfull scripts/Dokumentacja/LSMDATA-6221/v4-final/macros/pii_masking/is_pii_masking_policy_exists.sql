
{% macro is_pii_masking_policy_exists(policy_name, table_name) %}

    {# Macro checks if Masking Policy is created. It results true or false #}

    {#-- Prevent querying of db in parsing mode.-#}
    {%- if not execute %}
        {{ return('') }}
    {% endif -%}


    {% set count_query %}
      
        SELECT
            count(*) row_count
        FROM 
            svv_masking_policy mp 
        WHERE
            mp.policy_name = {{"'" ~ policy_name ~ "'"}} 

    {% endset %}   

    {% set rowcount_results = run_query(count_query) %}
    {% set table_row_count = rowcount_results.columns[0].values()[0] %}

    {% set is_attached = false %}
   
    {% if table_row_count > 0  %}
      {% set is_attached = true %}
    {% endif %}
  
    {{ return(is_attached) }}
{% endmacro %}









