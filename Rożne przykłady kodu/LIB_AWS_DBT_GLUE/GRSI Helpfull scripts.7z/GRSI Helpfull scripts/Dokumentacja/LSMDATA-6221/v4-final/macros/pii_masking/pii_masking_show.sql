{% macro pii_masking_show(message) %}
    
    {#  This macro shows Masking Policies and attached masking Polices #}

    {#-- Prevent querying of db in parsing mode.-#}
    {%- if not execute %}
        {{ return('') }}
    {% endif -%}

    {% do dbt_utils.log_info("Model info"  ) %} 
    {% do dbt_utils.log_info("this: " ~ this ) %} 
    {% do dbt_utils.log_info("this.database: " ~ this.database ) %} 
    {% do dbt_utils.log_info("this.schema: " ~ this.schema ) %}     
    {% do dbt_utils.log_info("this.name: " ~ this.name ) %}     

    {% do dbt_utils.log_info("                                                                  "  ) %} 
    {% do dbt_utils.log_info("                                                                  "  ) %} 
    {% do dbt_utils.log_info("                                                                  "  ) %} 
    {% do dbt_utils.log_info("=================================================================="  ) %} 
    {% do dbt_utils.log_info("Displaying masking policies at: '" ~ message ~"'"  ) %} 
    {% do dbt_utils.log_info("-------------------------------"  ) %} 

    {% do dbt_utils.log_info("List of masking policies: "  ) %} 
    {% do dbt_utils.log_info("-------------------------------"  ) %} 

    {% set query1 = "select * from svv_masking_policy" %}
    {% set query1_results = run_query(query1) %}

    {% do dbt_utils.log_info("Data of query: " ~  query1 ) %} 
    {% do dbt_utils.log_info("-------------------------------"  ) %} 
    {% do query1_results.print_table() %}

    {% do dbt_utils.log_info("-------------------------------"  ) %} 

    {% do dbt_utils.log_info("policy_name : " ~  query1_results.columns[1].values() ) %} 
    {% do dbt_utils.log_info("input_columns : " ~  query1_results.columns[2].values() ) %} 
    {% do dbt_utils.log_info("policy_expression : " ~  query1_results.columns[3].values() ) %} 


    {% do dbt_utils.log_info("List of attached masking policies: "  ) %} 
    {% do dbt_utils.log_info("-------------------------------"  ) %} 

    {% set query2 = "SELECT  * FROM svv_attached_masking_policy " %}
    {% set query2_results = run_query(query2) %}
    
    {% do dbt_utils.log_info("Data of query: " ~  query2 ) %} 
    {% do dbt_utils.log_info("-------------------------------"  ) %} 
    {% do query2_results.print_table() %}

    {% do dbt_utils.log_info("-------------------------------"  ) %} 

    {% do dbt_utils.log_info("policy_name : " ~  query2_results.columns[0].values() ) %} 
    {% do dbt_utils.log_info("schema_name : " ~  query2_results.columns[1].values() ) %} 
    {% do dbt_utils.log_info("table_name : " ~  query2_results.columns[2].values() ) %} 
    {% do dbt_utils.log_info("grantee : " ~  query2_results.columns[5].values() ) %} 

{% endmacro %}