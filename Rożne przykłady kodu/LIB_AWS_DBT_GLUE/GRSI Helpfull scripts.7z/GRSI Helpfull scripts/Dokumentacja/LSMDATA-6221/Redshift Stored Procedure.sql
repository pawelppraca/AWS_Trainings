    CREATE OR REPLACE PROCEDURE detach_masking_policy()
    AS $$
        DECLARE cnt INT;
    BEGIN
        SELECT INTO cnt COUNT(*)
        FROM svv_attached_masking_policy m
        WHERE policy_name = {{ "'"~masking_policy_name~"'" }} ;



        IF cnt > 0 THEN
            DETACH MASKING POLICY  {{ masking_policy_name }}
                ON {{table_name}}({{column_name}})
            {% if role_name | lower == "public" -%}
                FROM {{  role_name }} 
            {% elif is_user == true -%}
                FROM {{ '"'~role_name~'"' }} 
            {% else -%}
                FROM ROLE {{ '"'~role_name~'"' }} 
            {% endif -%}  
            ; 
        END IF;
    END;
    $$ LANGUAGE plpgsql;
    

    CALL detach_masking_policy();

    DROP PROCEDURE detach_masking_policy();
