



{{
    generate_cte(
        [
            {"table": "claim", "alias": "dwh_claim", "columns": ["claim_key", "policy_key", "claim_number", "date_claim_created"]},
        ]
    )
}},

select *
from dwh_claim


{{
   config(
       post_hook = create_data_reduction_view(
            schema='reconciliation',
            columns_to_mask=['claim_number']
            
            ) 
   )
}}