{% macro save_recon_header_update(table_name) %}

    {#-- Prevent querying of db in parsing mode.-#}
    {%- if not execute %}
        {{ return('') }}
    {% endif -%}

    {% set header_data = get_test_results_header_data(table_name,0) %}

    {% if header_data|length > 0  %}

        {% set update_query %}

            UPDATE {{ ref("dbt_test_results") }} 
            SET processed_date = getdate() 
            WHERE processed_date IS NULL 
            AND lower(replace(replace(detail_table_name,schema_name+'.',''),database_name+'.','')) = lower(replace({{"'" ~ table_name ~"'" }}, '_details',''))    
            {%- for row in header_data %} 
                AND header_key = {{ row[0] }}
            {%- endfor %}
        {% endset %}


        {{ run_query(update_query) }}
        {# {{ log(update_query, info=True) }}  #}

        {# Here must be deleting details from source #}

    {% endif %}

{% endmacro %}
