  -- depends_on: {{ ref('dbt_test_results') }}
{{
  config(
    materialized = 'incremental',
    transient = False,
    unique_key = 'header_key',
  )
}}

{% set header_data = get_test_results_header_data(model.name) %}
{% set model_name = model.name | replace("_details", "") %}
{% set source_row_count = get_rowcounts('reconciliation.' ~ model_name) %}

{{
    generate_cte(
        [
            {"table": "recon_coverage_sumswholelimit", "alias": "cte"}
        ]
    )
}},


{% if header_data|length > 0 and source_row_count > 0  %}

    final as (
        select
            {%- for row in header_data %} 
                cast('{{row[0]}}' as int)  as header_key, 
                cast('{{row[1]}}' as TIMESTAMP) as header_time_stamp,
                cast('{{row[2]}}' as TIMESTAMP) as generated_date,
                cast('{{row[3]}}' as int)  as fail_rows,
                cast('{{row[4]}}' as float)  as execution_time,
                cast('{{row[5]}}' as varchar(100))  as table_name,
                cast('{{row[6]}}' as VARCHAR(1000))  as result_id,
            {%- endfor %} 
            cte.*
        FROM cte
    )

    select * 
    from final

{% else %}

    empty_table as (
        select
                cast('1' as int)  as header_key, 
                cast(getdate() as TIMESTAMP) as header_time_stamp,
                cast(getdate() as TIMESTAMP) as generated_date,
                cast('1' as int)  as fail_rows,
                cast('1' as float)  as execution_time,
                cast(null as varchar(100))  as table_name,
                cast(null as VARCHAR(1000))  as result_id,
            cte.*
        FROM cte
    )

  select * 
  from empty_table where 1=0

{% endif %}

{# This must be at the end of model#}
{{
  config(
    post_hook = save_recon_header_update(model.name) 
  )
}}
