{{
    generate_cte(
        [
            {"table": "claim", "alias": "dwh_claim"},
            {"table": "claim_handler", "alias": "dwh_claim_handler"},
            {"table": "claim_transaction", "alias": "dwh_claim_transaction"},
            {"table": "transaction_type", "alias": "dwh_transaction_type"},
            {"table": "claim_movement_type", "alias": "dwh_claim_movement_type"},
            {"table": "currency", "alias": "dwh_currency"},
            {"table": "ri_code", "alias": "dwh_ri_code"}
        ]
    )
}},
final AS (
    SELECT  c.claim_number,
            c.claim_state
            , CONVERT(VARCHAR(10),c.date_of_loss)            AS date_of_loss
            , ch.__merge_key                                AS claim_handler
            , ISNULL(tt.transaction_type_code,'Unknown')    AS transaction_type_code
            , ISNULL(cmt.__merge_key, 'Unknown')            AS claim_movement_type
            , ri_type_code                                  AS ri_code
            , isnull(ct.fiscal_date, '9999-12-31' )         AS fiscal_date
            , isnull( fxo.currency_code, 'Unknown')         AS original_currency_code
            , isnull( fxl.currency_code, 'Unknown')         AS local_currency_code
            , ISNULL(to_char(ct.transaction_date, 'yyyymmdd'), '19000101')      AS transaction_date
            , count(*)                                      AS row_count
            , sum(isnull(ct.amount_original,0))             AS amount_original
            , sum(isnull(ct.amount_local,0))                AS amount_local
    FROM dwh_claim  AS c
    LEFT OUTER JOIN dwh_claim_handler            AS ch   ON c.assigned_to_claim_handler_key = ch.claim_handler_key
    LEFT OUTER JOIN dwh_claim_transaction        AS ct   ON ct.claim_key = c.claim_key
    LEFT OUTER JOIN dwh_transaction_type         AS tt   ON ct.transaction_type_key = tt.transaction_type_key
    LEFT OUTER JOIN dwh_claim_movement_type      AS cmt  ON cmt.claim_movement_type_key = ct.claim_movement_type_key
    LEFT OUTER JOIN dwh_currency                 AS fxo  ON ct.original_currency_key = fxo.currency_key
    LEFT OUTER JOIN dwh_currency                  AS fxl  ON ct.local_currency_key = fxl.currency_key
    LEFT OUTER JOIN dwh_ri_code                  AS ri   ON ri.ri_code_key = ct.ri_code_key
    GROUP BY  
    c.claim_number,
            c.claim_state
            , CONVERT(VARCHAR(10),c.date_of_loss) 
            , ch.__merge_key
            , tt.transaction_type_code
            , cmt.__merge_key
            , ri_type_code
            , isnull(ct.fiscal_date, '9999-12-31' )
            , isnull( fxo.currency_code, 'Unknown')     
            , isnull( fxl.currency_code, 'Unknown') 
            , ISNULL(to_char(ct.transaction_date, 'yyyymmdd'), '19000101') 
)

SELECT *
FROM final

