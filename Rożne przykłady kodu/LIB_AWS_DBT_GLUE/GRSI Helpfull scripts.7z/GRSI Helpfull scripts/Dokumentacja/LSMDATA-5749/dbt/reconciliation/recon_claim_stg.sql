

{{
    generate_cte(
        [
            {"table": "staging_genius_map_fxrates_genius", "alias": "stg_fxrates", "columns": ["fiscalperiod", "currencycode", "rate", "fxratetypecode"]},
            {"table": "staging_claim_center_cc_transaction", "alias": "stg_cc_transactions", "columns": ["claimid","Ext_DeductRecReductReason","UpdateTime", "ext_gwtransactionid"]},
            {"table": "staging_claim_center_cc_claim", "alias": "stg_claim", "columns": ["claim_number", "LossDate", "AssignedUserID", "id", "state"]},
            {"table": "staging_claim_center_cctl_claimstate", "alias": "stg_claimstate", "columns": ["name", "id"]},
            {"table": "staging_genius_zkfa", "alias": "stg_zkfa", "columns": ["claim_master_code", "claim_number"]},
            {"table": "staging_genius_zkg", "alias": "stg_zkg", "columns": ["claim_master_code", "claim_section_code", "claim_trans_header_code", "policy_master_number", "policy_master_sequence", "claim_trans_ref", "reporting_period", "genius_user_id", "entry_date", "accounting_currency_code", "ri_master_number", "original_currency_code", "transaction_date"]},
            {"table": "staging_genius_zkg3", "alias": "stg_zkg3", "columns": ["movement_amt_orig", "trans_type_indicator", "claim_movement_type_1_code", "claim_movement_type_2_code", "movement_amt_acc", "claim_trans_header_code", "claim_master_code", "claim_section_code"]},
            {"table": "staging_genius_zuma", "alias": "stg_zuma", "columns": ["master_number", "master_sequence", "master_minor_type_code", ]},
            {"table": "staging_claim_center_cctl_ext_deductrecreductreason", "alias": "stg_deductrecreductreason", "columns": ["name", "id"]}
        ]
    )
}},

cte_fx AS (
                SELECT fiscalperiod, currencycode, rate 
                FROM stg_fxrates
                WHERE  __data_region ='Europe'
                AND fxratetypecode='GENIUS' 
                ORDER BY currencycode,fiscalperiod
),
cte_cc_tx AS (     
                SELECT t1.claimid, t2.Ext_gwTransactionID, t1.Ext_DeductRecReductReason
                FROM stg_cc_transactions AS t1
                INNER JOIN 
                        (       
                        SELECT Ext_gwTransactionID, max(UpdateTime) AS latest_update_time 
                        FROM stg_cc_transactions 
                        GROUP BY Ext_gwTransactionID ) AS t2 ON 
                                t1.Ext_gwTransactionID = t2.Ext_gwTransactionID 
                                AND t1.UpdateTime = t2.latest_update_time
                ),
                
final AS (
    SELECT c.claim_number AS claim_number,
            cs.[name]                                                                       AS claim_state
            , CONVERT(VARCHAR(10),c.LossDate)                                                AS date_of_loss
            , ISNULL( 'CLAIM_CENTER|' + convert(VARCHAR, c.AssignedUserID), 'Unknown')      AS claim_handler 
            , CASE WHEN ZKG3.trans_type_indicator = 0 THEN 'RSV'
                            WHEN ZKG3.trans_type_indicator = 1 THEN 'PMT'
                            ELSE 'Unknown' END                                              AS transaction_type_code  
            ,  CASE WHEN zkg3.claim_movement_type_1_code IS NULL
                THEN 'Unknown'
                ELSE 'GENIUS|'+ISNULL(ISNULL(zkg3.claim_movement_type_1_code,'NA') + '|' + ISNULL(zkg3.claim_movement_type_2_code,'NA') +'|' 
                        + ISNULL(NULLIF(UPPER(ded.[NAME]),''),'NA') , 'Unknown')  
                END                                                                      AS claim_movement_type
            , CASE WHEN zkg.ri_master_number=''       
                THEN zuma.master_minor_type_code 
                ELSE  (CASE WHEN zkg.ri_master_number ISNULL THEN NULL ELSE 'CED' END )            
            END                                                                          AS ri_code
            ,  ISNULL( 
                        to_date( 
                                CONVERT( 
                                        VARCHAR, ( (zkg.reporting_period + 190000)*100)+1 
                                        )
                                , 'yyyymmdd' )
                    , '9999-12-31'
                    )                                                                   AS fiscal_date
            , ISNULL(fxo.currencycode, 'Unknown')                                          AS original_currency_code
            , ISNULL(fxl.currencycode, 'Unknown')                                          AS local_currency_code
            , CASE WHEN (
                        CASE WHEN zkg.genius_user_id LIKE 'ESB%' THEN zkg.entry_date ELSE transaction_date END IS NULL 
                    or CASE WHEN zkg.genius_user_id LIKE 'ESB%' THEN zkg.entry_date ELSE transaction_date END =0
                        )
    --               -- missing day and month
                THEN '19000101' 
                    WHEN ( CASE WHEN zkg.genius_user_id LIKE 'ESB%' THEN zkg.entry_date ELSE transaction_date END ) % 10000 = 0
                    THEN convert(VARCHAR(8), 19000101 + (CASE WHEN zkg.genius_user_id LIKE 'ESB%' THEN zkg.entry_date ELSE transaction_date END)  )
    --               -- missing day 
                    WHEN ( CASE WHEN zkg.genius_user_id LIKE 'ESB%' THEN zkg.entry_date ELSE transaction_date END ) % 100 = 0
                    THEN convert(VARCHAR(8), 19000001 + (CASE WHEN zkg.genius_user_id LIKE 'ESB%' THEN zkg.entry_date ELSE transaction_date END)  )
                    --invalid dates (19999999, 99999999)
                    WHEN ( CASE WHEN zkg.genius_user_id LIKE 'ESB%' THEN zkg.entry_date ELSE transaction_date END ) IN ('1999999', '999999')
                    THEN convert(VARCHAR(8), 19000101   )               

                ELSE convert(VARCHAR(8), 19000000 + ( CASE WHEN ( CASE WHEN zkg.genius_user_id LIKE 'ESB%' THEN zkg.entry_date ELSE transaction_date END) IS NOT NULL 
                                                THEN (CASE WHEN zkg.genius_user_id LIKE 'ESB%' THEN zkg.entry_date ELSE transaction_date END) ELSE '19000101' END ) )
                END AS transaction_date
    --       
    --        
            , count(*)                                                                      AS row_count
            , convert(numeric(18,3),sum(ISNULL(zkg3.movement_amt_orig,0)))                             AS amount_original
            , CONVERT(NUMERIC(38,4),SUM(CASE WHEN ISNULL(ZKG3.trans_type_indicator,'1') = '0' 
                                            THEN ISNULL(zkg3.movement_amt_orig,0) * ISNULL(fxo.Rate,1) / ISNULL(fxl.Rate,1)    
                                        ELSE     ISNULL(zkg3.movement_amt_acc,0) 
                                        END )      )                                     AS amount_local
    FROM            stg_claim                   AS c
    LEFT OUTER JOIN stg_claimstate              AS cs ON c.[state] = cs.ID
    LEFT OUTER JOIN stg_zkfa                    AS zkfa ON c.claim_number = zkfa.claim_number
    LEFT OUTER JOIN stg_zkg                     AS zkg  ON zkfa.claim_master_code = zkg.claim_master_code
    LEFT OUTER JOIN stg_zkg3                    AS zkg3 ON zkg.claim_master_code = zkg3.claim_master_code AND zkg.claim_section_code = zkg3.claim_section_code AND zkg.claim_trans_header_code = zkg3.claim_trans_header_code
    LEFT OUTER JOIN stg_zuma                    AS zuma ON zuma.master_number = zkg.policy_master_number AND zuma.master_sequence = zkg.policy_master_sequence
    LEFT OUTER JOIN cte_cc_tx                   AS t    ON t.claimid = c.[id] AND zkg.claim_trans_ref = t.Ext_gwTransactionID
    LEFT OUTER JOIN stg_deductrecreductreason   AS ded ON ded.ID = t.Ext_DeductRecReductReason
    LEFT OUTER JOIN cte_fx as fxo ON 
                                fxo.FiscalPeriod = ISNULL( to_char ( dateadd ( mm, -1, to_date( 
                                                                                        convert( VARCHAR, ( (zkg.reporting_period + 190000)*100)+1), 'yyyymmdd'
                                                                                              )
                                                                             )
                                                      , 'YYYYMMDD'), 
                                                       '99991231')  -- joins on the previous Fiscal Period
                                AND  fxo.CurrencyCode = zkg.original_currency_code
                                                                
    LEFT OUTER JOIN cte_fx as fxl ON fxl.FiscalPeriod =  ISNULL( to_char ( dateadd ( mm, -1, to_date( 
                               convert( 
                                       VARCHAR, ( (zkg.reporting_period + 190000)*100)+1 
                                      )
                               , 'yyyymmdd' )  
                    )  
                    , 'YYYYMMDD')
                                                               , '99991231'
                                                               )  -- joins on the previous Fiscal Period
                                                                        AND  fxl.CurrencyCode = zkg.accounting_currency_code
WHERE 1=1
--********************    These criteria do not currently work as the below fields are redacted   **************************
-- *******************    Uncomment once these are unredacted
--and zkg.outstanding_status IN ('1', '5','')   -- O/S Status     1 = O/S Confirmed 5 = Unapplicable
--AND zkg.authorisation_status IN ('1', '3')   -- ClTrHdr Authorisation Status  1 = Authorised,  3 = Not Applicable 
--AND ZKG3.amount_retained_flag <> '2'   -- Amount retained flag
--**************************************************************************************************************************    
group by
    c.claim_number,
                    cs.[name]
                    , CONVERT(VARCHAR(10),c.LossDate)
                    , ISNULL('CLAIM_CENTER|' + convert(VARCHAR, c.AssignedUserID), 'Unknown')
                    , CASE WHEN ZKG3.trans_type_indicator = 0 THEN 'RSV'
                            WHEN ZKG3.trans_type_indicator = 1 THEN 'PMT'
                            ELSE 'Unknown' END
    , CASE WHEN zkg3.claim_movement_type_1_code IS NULL
                THEN 'Unknown'
                ELSE 'GENIUS|'+ISNULL(ISNULL(zkg3.claim_movement_type_1_code,'NA') + '|' + ISNULL(zkg3.claim_movement_type_2_code,'NA') +'|' 
                        + ISNULL(nullif(upper(ded.[NAME]),''),'NA') , 'Unknown')  
                END
    , CASE WHEN zkg.ri_master_number=''       
                THEN zuma.master_minor_type_code 
                ELSE  (CASE WHEN zkg.ri_master_number ISNULL THEN NULL ELSE 'CED' END )            
            END 
    , ISNULL( 
                        to_date( 
                                convert( 
                                        VARCHAR, ( (zkg.reporting_period + 190000)*100)+1 
                                        )
                                , 'yyyymmdd' )
                    , '9999-12-31'
                    )
    , fxo.currencycode 
    , fxl.currencycode 
    , CASE WHEN (
                        CASE WHEN zkg.genius_user_id LIKE 'ESB%' THEN zkg.entry_date ELSE transaction_date END IS NULL 
                    or CASE WHEN zkg.genius_user_id LIKE 'ESB%' THEN zkg.entry_date ELSE transaction_date END =0
                        )
                -- missing day and month
                THEN '19000101' 
                    WHEN ( CASE WHEN zkg.genius_user_id LIKE 'ESB%' THEN zkg.entry_date ELSE transaction_date END ) % 10000 = 0
                    THEN convert(VARCHAR(8), 19000101 + (CASE WHEN zkg.genius_user_id LIKE 'ESB%' THEN zkg.entry_date ELSE transaction_date END)  )
                -- missing day 
                    WHEN ( CASE WHEN zkg.genius_user_id LIKE 'ESB%' THEN zkg.entry_date ELSE transaction_date END ) % 100 = 0
                    THEN convert(VARCHAR(8), 19000001 + (CASE WHEN zkg.genius_user_id LIKE 'ESB%' THEN zkg.entry_date ELSE transaction_date END)  )
                    --invalid dates (19999999, 99999999)
                    WHEN ( CASE WHEN zkg.genius_user_id LIKE 'ESB%' THEN zkg.entry_date ELSE transaction_date END ) IN ('1999999', '999999')
                    THEN convert(VARCHAR(8), 19000101   )               

                ELSE convert(VARCHAR(8), 19000000 + ( CASE WHEN ( CASE WHEN zkg.genius_user_id LIKE 'ESB%' THEN zkg.entry_date ELSE transaction_date END) IS NOT NULL 
                                                THEN (CASE WHEN zkg.genius_user_id LIKE 'ESB%' THEN zkg.entry_date ELSE transaction_date END) ELSE '19000101' END ) )
                END

)

SELECT *
FROM final