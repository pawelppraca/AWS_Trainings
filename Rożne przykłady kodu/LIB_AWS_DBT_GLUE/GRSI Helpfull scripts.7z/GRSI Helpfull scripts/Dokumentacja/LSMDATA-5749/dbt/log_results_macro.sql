
-- depends_on: {{ ref("dbt_tests_results") }}
{% macro log_results(results) %}

  {% if execute %}

  {{ log("========== Begin Detail log ==========", info=True) }}

    {%- set parsed_results = parse_dbt_results(results) -%}
    {%- if parsed_results | length  > 0 -%}
            {%- for parsed_result_dict in parsed_results -%}
                {% set line -%}
                    result_id:      {{ parsed_result_dict.get('result_id') }}
                    invocation_id: {{ parsed_result_dict.get('invocation_id') }}
                    unique_id:     {{ parsed_result_dict.get('unique_id') }}
                    database_name: {{ parsed_result_dict.get('database_name') }}
                    schema_name:   {{ parsed_result_dict.get('schema_name') }}
                    test_name:     {{ parsed_result_dict.get('test_name') }}
                    status:        {{ parsed_result_dict.get('status') }}
                    execution_time {{ parsed_result_dict.get('execution_time') }}
                    message:       {{ parsed_result_dict.get('message') }}
                    fail_rows:     {{ parsed_result_dict.get('fail_rows') }}
                    detail_table_name:  {{ parsed_result_dict.get('detail_table_name') }}
                    started:            {{ parsed_result_dict.get('started') }}
                    completed:          {{ parsed_result_dict.get('completed') }}
                {%- endset %}

                {% set insert_dbt_results_query -%}
                    insert into reconciliation.dbt_test_results
                        (
                            result_id,
                            invocation_id,
                            unique_id,
                            database_name,
                            schema_name,
                            test_name,
                            status,
                            execution_time,
                            message,
                            fail_rows,
                            detail_table_name
                    ) values
                        {%- for parsed_result_dict in parsed_results -%}
                            (
                                '{{ parsed_result_dict.get('result_id') }}',
                                '{{ parsed_result_dict.get('invocation_id') }}',
                                '{{ parsed_result_dict.get('unique_id') }}',
                                '{{ parsed_result_dict.get('database_name') }}',
                                '{{ parsed_result_dict.get('schema_name') }}',
                                '{{ parsed_result_dict.get('test_name') }}',
                                '{{ parsed_result_dict.get('status') }}',
                                '{{ parsed_result_dict.get('execution_time') }}',
                                '{{ parsed_result_dict.get('message') }}',
                                '{{ parsed_result_dict.get('fail_rows') }}',
                                '{{ parsed_result_dict.get('detail_table_name') }}'
                            ) {{- "," if not loop.last else "" -}}
                        {%- endfor -%}
                {%- endset -%}
                {% do run_query(fake_query) %} 

            {%- endfor -%}
    {%- endif -%}
  
    {{ log("========== END Detail log ==========", info=True) }}

    {{ log("========== RUN Query ==========", info=True) }}
    {% set fake_query -%}
        insert into reconciliation.dbt_test_results
                        (
                            result_id,
                            invocation_id,
                            unique_id,
                            database_name,
                            schema_name,
                            test_name,
                            resource_type,
                            status,
                            execution_time,
                            fail_rows,
                            message,
                            detail_table_name,
                            start_time,
                            completed_time
                    ) values( 'a','a','a','a','a','a','a','a',1.01,100,'Message','nazwa_tabeli',getdate(),getdate()+1)
    {%- endset -%}
    {{ log(fake_query, info=True) }}
    {% do run_query(fake_query) %} 
    {{ log("========== END RUN Query ==========", info=True) }}

  {% endif %}

 {{ return ('') }}

{% endmacro %}