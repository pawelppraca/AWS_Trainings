        {% for timing in run_result_dict.get('timing', [])  %}
            {% for key in timing %} 
                {# {{ log("Key: " ~ key ~ " = Value: " ~ timing[key] , info=True) }} #}
                {% set started = timing['started_at'][:19] %}
                {% set completed = timing['completed_at'][:19] %}
            {% endfor %} 
        {% endfor %}


        {{ log("Started: " ~ started ~ " ; Completed: " ~ completed , info=True) }} 
        {{ log("Timing: " ~ run_result_dict.get('timing', []) , info=True) }}


-- Logowanie czasu wykoania testu
      {# {{ log("Time Started: " ~ run_started_at.strftime("%Y-%m-%d") ~ "T" ~ run_started_at.strftime("%H:%M:%S") , info=True) }}  #}