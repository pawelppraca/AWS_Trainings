{{
  config(
    materialized = 'incremental',
    transient = False,
    unique_key = 'header_key'
  )
}}

SELECT *
FROM {{ source('reconciliation','dbt_tests') }}
     