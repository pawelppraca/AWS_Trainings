{% macro save_recon_details_old(table_name, additional_columns, exclude_columns, where_condition) %}

    {%- set columns = adapter.get_columns_in_relation(ref(table_name)) -%}
    
    
    {% set query %} 
       
        SELECT top 1
            {% if additional_columns %}
                {{ additional_columns  }}
            {% endif%}
            {%- for column in columns -%}    
                {%- if column.name.lower() not in exclude_columns %}
                    {%- if column.is_string() %}
                    '{{ default_string_value[:column.string_size()] }}' as {{column.name}}
                    {%- elif column.is_number() %}
                    {{ default_number_value }} as {{column.name}}
                    {%- elif column.data_type.lower() == "boolean" %}
                    {{ default_boolean_value }} as {{column.name}}
                    {%- elif is_date_column(column) %}
                    '{{ default_date_value }}' as {{column.name}}
                    {%- else %}
                    --Unknown data type
                    null as {{column.name}}
                    {%- endif -%}
                    {% if not loop.last %},{% endif -%}
                {%- endif -%}
            {%- endfor %}

        FROM {{ table_name }} 
        {% if where_condition %}
            {{ "WHERE " ~ where_condition}}
        {% endif %}

    {% endset %}

    {{ return(query) }}

{% endmacro %}
