{% macro save_recon_details2(source_name, table_name, additional_columns, exclude_columns, where_condition) %}

    {#-- Prevent querying of db in parsing mode.-#}
    {%- if not execute %}
        {{ return('') }}
    {% endif -%}

    {%- set source_columns = get_source_column_meta_data(source_name, table_name) %}

    {# log("\n\nDictionary: \n\n" ~ source_columns, info=true) #}

    {%- if source_columns|length <= 0 -%}
        {% do return("/* no columns returned from get_source_column_meta_data() macro */") %}
    {% endif -%}

    with source as (

        select * 
        from {{ source(source_name, table_name) }}
    ),
    renamed as (

        select 
        {% if additional_columns %}
            {{ additional_columns  }}
        {% endif%}
        {%- for column in source_columns.keys() -%}
            {%- if column.name.lower() not in exclude_columns %}
                {%- set column_properties = source_columns.get(column) %}
                {%- set column_alias = column_properties.get("column_alias") %}
                {{ adapter.quote(column) if quote_identifiers else column }} {%- if column_alias is not none %} as {{ adapter.quote(column_alias) if quote_identifiers else column_alias }} {%- endif -%}
            {%- endif -%}
            {{',' if not loop.last }}
        {%- endfor %}
        from source
        {% if where_condition %}
            {{ "WHERE " ~ where_condition}}
        {% endif %}

    )
    select * 
    from renamed

{% endmacro %}
