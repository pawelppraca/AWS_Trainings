{# 
    {% for row in recon_summary_results %}
        
        {% set additional_columns = "'" ~ row[0] ~ "' AS header_key, " %} --header_key
        {% set additional_columns = additional_columns ~ "'" ~ row[1] ~ "' AS header_time_stamp, "  %} --header_time_stamp
        {% set additional_columns = additional_columns ~ "'" ~ row[2] ~ "' AS generated_date, "  %} --generated_date
        {% set additional_columns = additional_columns ~ "'" ~ row[3] ~ "' AS fail_rows, "  %} --fail_rows
        {% set additional_columns = additional_columns ~ "'" ~ row[4] ~ "' AS execution_time, "  %} --execution_time
        {% set additional_columns = additional_columns ~ "'" ~ row[5] ~ "' AS table_name, "  %} --table_name
        {% set additional_columns = additional_columns ~ "'" ~ row[6] ~ "' AS result_id "  %} --result_id 

        {{ log("Additonal_columns: " ~ additional_columns, info=True) }}  

    {% endfor %}  #}
