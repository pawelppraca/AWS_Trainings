{% macro pp_test_macro(table_name) %}

    {#-- Prevent querying of db in parsing mode.-#}
    {%- if not execute %}
        {{ return('') }}
    {% endif -%}

    {% set header_data = get_test_results_header_data(test_name) -%}


    {{ log("Started: " ~ started ~ " ; Completed: " ~ completed , info=True) }} 


{% endmacro %}
