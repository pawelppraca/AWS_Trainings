{{
  config(
    materialized = 'incremental',
    transient = False,
    unique_key = 'result_id'
  )
}}

with empty_table as (
    select
        cast(null as VARCHAR (1000)) as result_id,
        cast(null as VARCHAR (1000)) as invocation_id,
        cast(null as VARCHAR (1000)) as unique_id,
        cast(null as VARCHAR (255))  as database_name,
        cast(null as VARCHAR (255))  as schema_name,
        cast(null as VARCHAR (1000)) as test_name,
        cast(null as VARCHAR (1000)) as resource_type,
        cast(null as VARCHAR (50))  as status,
        cast('1' as float) as execution_time,
        cast('1' as int) as fail_rows,
        cast(null as VARCHAR (1000)) as message,
        cast(null as VARCHAR (1000)) as detail_table_name,
        cast(getdate() as TIMESTAMP) as start_time, 
        cast(getdate() as TIMESTAMP) as completed_time

)

select * from empty_table
-- This is a filter so we will never actually insert these values
where 1 = 0