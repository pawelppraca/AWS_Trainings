
{{ generate_staging_model('staging_test', 'recon_broker_checksum') }}