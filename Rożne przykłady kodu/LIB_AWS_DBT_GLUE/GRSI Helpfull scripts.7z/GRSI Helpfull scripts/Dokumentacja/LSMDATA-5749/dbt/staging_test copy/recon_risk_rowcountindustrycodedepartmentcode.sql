
{{ generate_staging_model('staging_test', 'recon_risk_rowcountindustrycodedepartmentcode') }}
