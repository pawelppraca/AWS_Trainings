
{{ generate_staging_model('staging_test', 'recon_geography_checksum') }}
