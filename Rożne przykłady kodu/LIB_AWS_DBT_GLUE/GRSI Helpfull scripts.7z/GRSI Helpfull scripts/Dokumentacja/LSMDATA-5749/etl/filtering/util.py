from typing import List

from etl.shared import DataRegion, DataFilterType
from .base import BaseDataFilter
from .gcc_filters import GccClaimDataFilter, GccContactDataFilter
from .genius_filters import GeniusPolicyDataFilter
from .wr_filters import WarehouseRepoDataFilter


class DataFilterFactory:

    @staticmethod 
    def create_data_filter(
                data_filter: DataFilterType, 
                data_regions: List[DataRegion]
        ) -> BaseDataFilter:

        if data_filter is DataFilterType.GCC_CLAIM_FILTER:
            return GccClaimDataFilter(data_filter, data_regions)
        elif data_filter is DataFilterType.GCC_CONTACT_FILTER:
            return GccContactDataFilter(data_filter, data_regions)
        elif data_filter is DataFilterType.GENIUS_POLICY_FILTER:
            return GeniusPolicyDataFilter(data_filter, data_regions)
        elif data_filter is DataFilterType.WR_POLICY_FILTER:
            return WarehouseRepoDataFilter(data_filter, data_regions)

    

