from typing import List, Dict

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col, expr, lower

from etl.shared import DataRegion, DataFilterType
from etl.filtering.base import BaseDataFilter
from etl.util import GlueLogger

class GccContactDataFilter(BaseDataFilter):
    def __init__(self, filter_name: str, data_regions: List[DataRegion]) -> None:
        super().__init__(filter_name=filter_name, data_regions=data_regions)

    def get_data_frame(
        self, 
        spark: SparkSession, 
        source_data_frames: Dict[str, DataFrame],
        logger: GlueLogger
    ) -> DataFrame:
        df_claim = (
            source_data_frames.get("cc_claim")
            .select(
                "id",
                "createuserid",
                "assigneduserid",
                "updateuserid",
                "assignedbyuserid",
                "previoususerid",
                "assignedgroupid",
            )
            .alias("clm")
        )

        df_activity = (
            source_data_frames.get("cc_activity")
            .select(
                "claimid",
                "assignedbyuserid",
                "assigneduserid",
                "closeuserid",
                "createuserid",
                "updateuserid")
            .alias("act")
        )

        df_lmmessage = (
            source_data_frames.get("ccx_lmmessage_ext")
            .select(
                "claim",
                "createuserid",
                "updateuserid",
                "assignedbyuserid",
                "assigneduserid",
                "previoususerid")
            .alias("lmm")
        )

        df_user = (
            source_data_frames.get("cc_user")
            .select("id", "contactid")
            .alias("usr")
        )
        
        df_contact = (
            source_data_frames.get("cc_contact")
            .select("id")
            .alias("con")
        )
        
        df_group = (
            source_data_frames.get("cc_group")
            .select("id", "supervisorid")
            .alias("grp")
        )
        
        # We're only allowed to bring in Contact records associated with Claim records for each region; have to filter on every userid field separately.
        df_user_contacts = (
            df_user.join(
                df_claim,
                on=expr(
                    "usr.id IN (clm.createuserid, clm.assigneduserid, clm.updateuserid, clm.assignedbyuserid, clm.previoususerid)"
                ),
                how="inner",
            )
            .join(df_contact, on=expr("usr.contactid = con.id"), how="inner")
            .join(
                source_data_frames.get(DataFilterType.GCC_CLAIM_FILTER).alias(
                    "claim_filter"
                ),
                on=expr("claim_filter.claimid = clm.id"),
                how="inner",
            )
            .select(col("con.id").alias("contactid"), "claim_filter.__data_region")
        )

        df_activity_contacts = (
            df_user.join(
                df_activity,
                on=expr(
                    "usr.ID IN (act.assignedbyuserid, act.assigneduserid, act.closeuserid, act.createuserid, act.updateuserid)"
                ),
                how="inner",
            )
            .join(df_contact, on=expr("usr.contactid = con.id"), how="inner")
            .join(
                source_data_frames.get(DataFilterType.GCC_CLAIM_FILTER).alias(
                    "claim_filter"
                ),
                on=expr("claim_filter.claimid = act.claimid"),
                how="inner",
            )
            .select(col("con.id").alias("contactid"), "claim_filter.__data_region")
        )

        df_lmmessage_contacts = (
            df_user.join(
                df_lmmessage,
                on=expr(
                    "usr.ID IN (lmm.createuserid, lmm.updateuserid, lmm.assignedbyuserid, lmm.assigneduserid, lmm.previoususerid)"
                ),
                how="inner",
            )
            .join(df_contact, on=expr("usr.contactid = con.id"), how="inner")
            .join(
                source_data_frames.get(DataFilterType.GCC_CLAIM_FILTER).alias(
                    "claim_filter"
                ),
                on=expr("claim_filter.claimid = lmm.claim"),
                how="inner",
            )
            .select(col("con.id").alias("contactid"), "claim_filter.__data_region")
        )
        
        df_supervisor_contacts = (
            df_claim.join (
                df_group,
                on=expr("clm.assignedgroupid = grp.id"),
                how="inner"
            )
            #Ensure the SupervisorID is a valid contact
            .join(
                df_contact,
                on=expr("grp.supervisorid = con.id"),
                how="inner"
            )
            .join(
                source_data_frames.get(DataFilterType.GCC_CLAIM_FILTER).alias("claim_filter"),
                on=expr("claim_filter.claimid = clm.id"),
                how="inner",
            )
            .select(col("con.id").alias("contactid"), "claim_filter.__data_region")
        )
        
        df_contacts_filter = (
            df_user_contacts
            .union(df_supervisor_contacts)
            .union(df_activity_contacts)
            .union(df_lmmessage_contacts)
            .distinct()
            .alias(DataFilterType.GCC_CONTACT_FILTER)
        )
        
        return df_contacts_filter


class GccClaimDataFilter(BaseDataFilter):
    def __init__(self, filter_name: str, data_regions: List[DataRegion]) -> None:
        super().__init__(filter_name=filter_name, data_regions=data_regions)

    def get_data_frame(
        self, 
        spark: SparkSession, 
        source_data_frames: Dict[str, DataFrame],
        logger: GlueLogger
    ) -> DataFrame:
        
        df_claim = (
            source_data_frames.get("cc_claim")
            .select(
                "id",
                "policyid",
                "ext_losscodeset"
            )
            .withColumn("ext_losscodeset", lower(col("ext_losscodeset")))
            .alias("clm")
        )
        
        df_policy = (
            source_data_frames.get("cc_policy")
            .select("id", "ext_geniusbranchcode", "ext_product")
            .withColumn("ext_geniusbranchcode", lower(col("ext_geniusbranchcode")))
            .alias("pol")
        )
       
        df_lsm_branch_codes = (
            source_data_frames.get("lsm_branch_codes")
            .withColumn("branch", lower(col("branch")))
            .alias("bc")
        )
        
        df_loss_code_set = (
            source_data_frames.get("cctl_ext_losscodeset")
            .withColumn("typecode", lower(col("typecode")))
            .select("id", "typecode")
            .alias("lcs")
        )
       
        df_product = (
            source_data_frames.get("cctl_ext_product")
            .withColumn("typecode", lower(col("typecode")))
            .select("id", "typecode")
            .alias("prod")
        )
        
        df_coverage = (
            source_data_frames.get("cc_coverage")
            .withColumn("ext_sfc2cd", lower(col("ext_sfc2cd")))
            .select("policyid", "ext_sfc2cd")
            .alias("coverage")
        )
       
        # Convert the ref data to lists
        lsm_us_product_codes = (
            source_data_frames.get("lsm_us_product_codes")
            .withColumn("lsm_us_product_code", lower(col("lsm_us_product_code")))
            .rdd.map(lambda x: x[0])
            .collect()
        )
        
        lsm_us_class_of_business = (
            source_data_frames.get("lsm_us_class_of_business")
            .withColumn("lsm_us_class_of_business", lower(col("lsm_us_class_of_business")))
            .rdd.map(lambda x: x[0])
            .collect()
        )
       
        #Identify the US claims
        df_us_claims = (
            df_claim.join(
                df_policy,
                on=expr("clm.policyid = pol.id"),
                how="inner",
            )
            .join (
                df_lsm_branch_codes,
                on=expr("pol.ext_geniusbranchcode = bc.branch"),
                how="inner"
            )
            .join (
                df_loss_code_set,
                on=expr("clm.ext_losscodeset = lcs.id"),
                how="left"
            )
            .join (
                df_product,
                on=expr("pol.ext_product = prod.id"),
                how="left"
            )
            #This is a 1-N relationship
            .join (
                df_coverage,
                on=expr("pol.id = coverage.policyid"),
                how="left"
            )
            .where(
                (
                    (lower(col("bc.__data_region")) == DataRegion.US.lower())
                    & col("prod.typecode").isin(lsm_us_product_codes)
                )
                | (
                    (lower(col("bc.__data_region")) == DataRegion.US.lower())
                    & col("coverage.ext_sfc2cd").isin(lsm_us_class_of_business)
                )
                | (
                    (lower(col("bc.__data_region")) == DataRegion.US.lower())
                    & (col("lcs.typecode") == "gts") #Global Transaction Solutions
                )
            )
            .select(col("clm.id").alias("claimid"), "bc.__data_region")
            .distinct()
        )
        
        #Identify the claims for all other regions
        df_non_us_claims = (
            df_claim.join(
                df_policy,
                on=expr("clm.policyid = pol.id"),
                how="inner",
            )
            .join (
                df_lsm_branch_codes,
                on=expr("pol.ext_geniusbranchcode = bc.branch"),
                how="inner"
            )
            .where (
                lower(col("bc.__data_region")) != DataRegion.US.lower()
            )
            .select (col("clm.id").alias("claimid"), "bc.__data_region")
            .distinct()
        )
        
        df_results = (
            df_us_claims.union(df_non_us_claims).alias(DataFilterType.GCC_CLAIM_FILTER)
        )
        
        return df_results