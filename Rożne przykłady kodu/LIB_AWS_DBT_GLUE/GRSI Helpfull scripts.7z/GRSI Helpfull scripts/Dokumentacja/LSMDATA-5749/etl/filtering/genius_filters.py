from typing import List, Dict

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import lower, col, expr

from etl.shared import DataRegion
from etl.filtering.base import BaseDataFilter
from etl.util import GlueLogger


class GeniusPolicyDataFilter(BaseDataFilter):
    def __init__(self, filter_name: str, data_regions: List[DataRegion]) -> None:
        super().__init__(filter_name=filter_name, data_regions=data_regions)

    def get_data_frame(
        self, 
        spark: SparkSession, 
        source_data_frames: Dict[str, DataFrame], 
        logger: GlueLogger
    ) -> DataFrame:
        df_zuma = (
            source_data_frames.get("zuma")
            .withColumn("MAMABN", lower(col("MAMABN")))  # Branch Code
            .withColumn("MACNCD", lower(col("MACNCD")))  # Company Code
            .withColumn("MAMAPC", lower(col("MAMAPC")))  # Product Code
            .withColumn("MADPCD", lower(col("MADPCD")))  # Dept Code
            .select("MAMANU", "MAMASE", "MAMABN", "MACNCD", "MAMAPC", "MADPCD")
            .alias("zuma")
        )

        df_lsm_branch_codes = (
            source_data_frames.get("lsm_branch_codes")
            .withColumn("branch", lower(col("branch")))
            .alias("bc")
        )

        # Convert the ref data to lists
        lsm_company_codes = (
            source_data_frames.get("lsm_company_codes")
            .withColumn("lsm_company_code", lower(col("lsm_company_code")))
            .rdd.map(lambda x: x[0])
            .collect()
        )

        lsm_product_codes = (
            source_data_frames.get("lsm_product_codes")
            .withColumn("lsm_product_code", lower(col("lsm_product_code")))
            .rdd.map(lambda x: x[0])
            .collect()
        )

        lsm_gts_dept_codes = (
            source_data_frames.get("lsm_gts_dept_codes")
            .withColumn("lsm_gts_dept_code", lower(col("lsm_gts_dept_code")))
            .rdd.map(lambda x: x[0])
            .collect()
        )

        df_policy_keys = (
            df_zuma.join(
                df_lsm_branch_codes, on=expr("zuma.MAMABN = bc.branch"), how="inner"
            )
            .where(
                (
                    (
                        col("zuma.MACNCD").isin(lsm_company_codes)
                        | col("zuma.MAMAPC").isin(lsm_product_codes)
                        | col("zuma.MADPCD").isin(lsm_gts_dept_codes)
                    )
                    & (col("zuma.MAMAPC") != "inlm")  # Use lowercase
                    & ~(col("zuma.MAMABN").startswith("7"))
                    & ~(col("zuma.MACNCD").isin("lsma", "lsmb"))  # Use lowercase
                )
            )
            .select("zuma.MAMANU", "zuma.MAMASE", "bc.__data_region")
            .distinct()
            .alias(self.filter_name)
        )

        return df_policy_keys
