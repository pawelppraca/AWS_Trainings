from typing import List, Dict, Tuple

from pyspark.sql import DataFrame
from pyspark.sql.functions import lit, to_timestamp, lower, expr

from etl.shared import DataRegion, ChildTableInfo, TableInfo

class SparkTransformMixin(object):

    DATA_REGION_COLUMN = "__data_region"
    SOURCE_SYSTEM_CODE_COLUMN = "__source_system_code"
    EXTRACTION_TIMESTAMP_COLUMN = "__extraction_date_time"
    LOAD_ID_COLUMN = "__load_id"
    TRACE_ID_COLUMN = "x_amzn_trace_id"
    

    def add_system_columns(self, source_df: DataFrame, column_values: dict) -> DataFrame:
        """
        Added the specified columns and values to the DataFrame
        """
        new_df = source_df
        for column_name, value in column_values.items():
            new_df = new_df.withColumn(column_name, lit(value))
                
        if SparkTransformMixin.EXTRACTION_TIMESTAMP_COLUMN in column_values:
            new_df = new_df.withColumn(SparkTransformMixin.EXTRACTION_TIMESTAMP_COLUMN, to_timestamp(SparkTransformMixin.EXTRACTION_TIMESTAMP_COLUMN, "yyyy-MM-dd HH:mm:ss"))

        return new_df
    

    def filter_data_frame_by_region(self, source_df: DataFrame, data_region: DataRegion) -> DataFrame:
        df_filtered = source_df.filter(lower(SparkTransformMixin.DATA_REGION_COLUMN) == data_region.lower())
        return df_filtered
    

    def merge_data_frames(self, base_table: Tuple[str, str], relationships: List[ChildTableInfo], dataframes: Dict[str, DataFrame]) -> DataFrame:

        merged_df = dataframes[base_table[0]]
        if base_table[1]:
            merged_df = merged_df.alias(base_table[1])

        for relationship in relationships:
            merged_df = merged_df.join(
                other=dataframes[relationship.table_name].alias(relationship.alias),
                on=expr(relationship.join_condition),
                how=relationship.join_type
            )

        return merged_df
    
    def build_extract_query(self, source_table: TableInfo, dataframes: Dict[str, DataFrame]) -> DataFrame:

        cols = [f"{source_table.alias}.*", SparkTransformMixin.DATA_REGION_COLUMN] if source_table.filter_by_region else [f"{source_table.alias}.*"]

        return self.merge_data_frames(
                    base_table=(source_table.name, source_table.alias), 
                    relationships=source_table.relationships,
                    dataframes=dataframes
                    ).select(cols)

           
