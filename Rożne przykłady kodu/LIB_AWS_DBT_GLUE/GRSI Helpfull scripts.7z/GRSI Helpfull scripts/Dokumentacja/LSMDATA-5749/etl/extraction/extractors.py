from typing import Dict, Optional

from pyspark.sql import SparkSession, DataFrame

from etl.shared import TableInfo
from etl.util import GlueLogger
from .base import BaseExtractor


class SparkExtractor(BaseExtractor):
    
    def __init__(
        self,
        environment: str,
        jdbc_conn_properties: dict
    ) -> None:
        super().__init__(
            environment = environment
        )
        self._jdbc_conn_properties = jdbc_conn_properties

    def _extract(self, 
                source_tables: Dict[str, TableInfo],
                spark: SparkSession,
                logger: GlueLogger,
            ) -> Dict[str, DataFrame]:
        
        results = {
            table: self._load_table(spark, table_info.table_path, logger) for table, table_info in source_tables.items()
        }

        return results
    
    def _load_table(self, spark: SparkSession, object_name: str, logger: GlueLogger) -> DataFrame:

        logger.info(f'Extracting table {object_name} from data source [{self._jdbc_conn_properties["url"]}]')

        df = (
                spark.read.format("jdbc")
                    .option("url", self._jdbc_conn_properties["url"])
                    .option("driver", self._jdbc_conn_properties["driver"])
                    .option("dbtable", object_name)
                    .option("user", self._jdbc_conn_properties["user"])
                    .option("password", self._jdbc_conn_properties["password"])
                    .load()
        )    

        return df
    

class S3Extractor(BaseExtractor):
    
    def __init__(
        self,
        environment: str,
        s3_bucket: str,
        s3_key_prefix: Optional[str]=None,
    ) -> None:
        super().__init__(
            environment = environment
        )
        self.s3_bucket = s3_bucket
        self.s3_key_prefix = s3_key_prefix

    def _extract(self, 
                source_tables: Dict[str, TableInfo],
                spark: SparkSession,
                logger: GlueLogger,
            ) -> Dict[str, DataFrame]:

        key_prefix = self._add_slash(self.s3_key_prefix) if self.s3_key_prefix else ""

        results = {}
        for table, table_info in source_tables.items():
            object_path = f"s3a://{self.s3_bucket}/{key_prefix}{table_info.table_path}"
            logger.info(f'Extracting table {table} from S3 [{object_path}]')
            source_df = spark.read.parquet(object_path)
            if table_info.ignore_columns:
                logger.info(f"Dropping source columns for table '{table}': {table_info.ignore_columns}...")
                selected_df = self._drop_columns(source_df=source_df, drop_column_list=table_info.ignore_columns)
                results[table] = selected_df
            else:
                results[table] = source_df

        return results
    
    def _add_slash(self, s):
        return s if s[-1] == "/" else s + "/"

class DeltaLakeExtractor(S3Extractor):
    
    def __init__(
        self,
        environment: str,
        s3_bucket: str,
        s3_key_prefix: Optional[str]=None
    ) -> None:
        super().__init__(
            environment = environment,
            s3_bucket = s3_bucket,
            s3_key_prefix = s3_key_prefix
        )
       

    def _extract(self, 
                source_tables: Dict[str, TableInfo],
                spark: SparkSession,
                logger: GlueLogger,
            ) -> Dict[str, DataFrame]:

        key_prefix = self._add_slash(self.s3_key_prefix) if self.s3_key_prefix else ""

        results = {}
        for table, table_info in source_tables.items():
            object_path = f"s3a://{self.s3_bucket}/{key_prefix}{table_info.table_path}"
            logger.info(f'Extracting table {table} from S3 [{object_path}]')
            source_df = spark.read.format("delta").load(object_path)
            if table_info.ignore_columns:
                logger.info(f"Dropping source columns for table '{table}': {table_info.ignore_columns}...")
                selected_df = self._drop_columns(source_df=source_df, drop_column_list=table_info.ignore_columns)
                results[table] = selected_df
            else:
                results[table] = source_df

        return results
    
    

            