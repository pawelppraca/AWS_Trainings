from typing import Dict, List

import boto3
from boto3.dynamodb.types import TypeSerializer, TypeDeserializer

from etl.shared import ColumnOrdering

class DynamoDbMixin:

    def _get_assumed_region_session(self, 
                                    aws_region: str,
                                    assumed_role_arn: str,
                                    assumed_session_name: str,
                                    ) -> boto3.session.Session:

        sts = boto3.client("sts")
        assume_response = sts.assume_role(
            RoleArn=assumed_role_arn, RoleSessionName=assumed_session_name
        )

        session = boto3.session.Session(
            region_name=aws_region,
            aws_access_key_id=assume_response["Credentials"]["AccessKeyId"],
            aws_secret_access_key=assume_response["Credentials"]["SecretAccessKey"],
            aws_session_token=assume_response["Credentials"]["SessionToken"],
        )
        return session

    def _put_item(self, boto_session: boto3.session.Session, dynamo_table: str, item: Dict) -> None:

        ddb_client = boto_session.client("dynamodb")
        #serializes Python data types to DynamoDB types
        serializer = TypeSerializer()
        dynamo_data = {k: serializer.serialize(v) for k,v in item.items()}

        ddb_client.put_item(TableName=dynamo_table,Item=dynamo_data)


    #TODO: Not tested due to cross-account role not having read permission on DynamoDB
    def _get_item(self, boto_session: boto3.session.Session, dynamo_table: str, key: Dict):

        ddb_client = boto_session.client("dynamodb")

        #Deserialize Response as Python dictionary
        deserializer = TypeDeserializer()
        response = ddb_client.get_item(TableName=dynamo_table, Key=key)

        item = {k: deserializer.deserialize(v) for k,v in response.items()}

        return item


class ColumnMappingDynamoDBWriter(DynamoDbMixin):

    def __init__(
        self,
        aws_region: str,
        assumed_role_arn: str,
        assumed_session_name: str,
        dynamo_table_name: str,
    ) -> None:
        self.aws_region = aws_region
        self.assumed_role_arn = assumed_role_arn
        self.assumed_session_name = assumed_session_name
        self.dynamo_table_name = dynamo_table_name


    #TODO: Add DynamoDB read access for cross-account role as this will be required for the LoadID
    #'Error: An error occurred (AccessDeniedException) when calling the GetItem operation: User: arn:aws:sts::866525145675:assumed-role/grsi-dp-glue-assume-ssm-role-eu-test/glueAssumeRole is not authorized to perform: 
    # #dynamodb:GetItem on resource: arn:aws:dynamodb:eu-west-1:866525145675:table/grsi-dp-column-order-table-eu-test because no identity-based policy allows the dynamodb:GetItem action'

    def get_column_mappings(self, target_table: str, target_schema: str) -> List[str]:

        response =  self._get_item(
            boto_session=self._get_assumed_region_session(self.aws_region, self.assumed_role_arn, self.assumed_session_name),
            dynamo_table=self.dynamo_table_name,
            key={
                'Table': {'S': target_table},
                'Schema': {'S': target_schema}
            }
        )

        return response['Item'].get('ColumnOrdering').split(',')

    def save_column_mappings(self, target_table: str, target_schema: str, columns: List[str]) -> None:

        co = ColumnOrdering(Table=target_table, Schema=target_schema, ColumnOrder=", ".join(columns))

        self._put_item(
            boto_session=self._get_assumed_region_session(self.aws_region, self.assumed_role_arn, self.assumed_session_name),
            dynamo_table=self.dynamo_table_name,
            item=co
        )
        


    



    
