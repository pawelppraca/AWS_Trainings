from typing import Optional, Dict

import boto3
from pyspark.sql import SparkSession, DataFrame

from .base import BaseWriter
from .util import ColumnMappingDynamoDBWriter
from etl.shared import TableInfo
from etl.util import GlueLogger

class S3Writer(BaseWriter):

    def __init__(
        self,
        s3_bucket: str,
        s3_tags: Dict[str, str],
        s3_key_prefix: Optional[str]=None,
        column_mapping_writer: Optional[ColumnMappingDynamoDBWriter]=None
    ) -> None:
        super().__init__(
            column_mapping_writer=column_mapping_writer
        )
        self.s3_bucket = s3_bucket
        self.s3_tags = s3_tags if s3_tags else {}
        self.s3_key_prefix = s3_key_prefix
    
    def _get_tags_as_url_query_string(self) -> str:
        return f"{'&'.join(f'{key}={value}' for key, value in self.s3_tags.items())}"
    
    def _add_slash(self, s):
        return s if s[-1] == "/" else s + "/"
    
    def write(self, 
                table_info: TableInfo,
                target_data_frame: DataFrame,
                spark: SparkSession,
                logger: GlueLogger,
                **kwargs
            ) -> None:


        key_prefix = self._add_slash(self.s3_key_prefix) if self.s3_key_prefix else ""
        table_path = f"{table_info.write_schema}/{table_info.write_name}"
        s3_path = f"s3a://{self.s3_bucket}/{key_prefix}{table_path}"
        
        logger.info(f"Starting to write table '{table_info.name}' to '{s3_path}'")
        target_data_frame.coalesce(1).write.parquet(s3_path, mode="overwrite")
        logger.info(f"Finished writing temporary files for '{table_info.name}'")
        
        if self._column_mapping_writer:
            logger.info(
                f"Writing column mappings for table: '{table_info.name}', "
                f"schema: '{table_info.write_schema} ', table write name: '{table_info.write_name}' "
                f"to DynamoDB table '{self._column_mapping_writer.dynamo_table_name}' "
                f"in AWS region '{self._column_mapping_writer.aws_region}'"
            )
            self._column_mapping_writer.save_column_mappings(table_info.write_name, table_info.write_schema, target_data_frame.columns)

        else:
            logger.info(f"Skipping writing column mappings for table '{table_info.name}' as no column writer is defined.")

        
        self._move_temporary_files(table_path, key_prefix, logger)
        logger.info(f"Finished processing temporary files for table '{table_info.name}'")
        
        
    def _move_temporary_files(self, table_path: str, key_prefix: str, logger: GlueLogger) -> None:
        # use boto3 to move output file back to our target key and ensure xray trace http header is propagated
        # find all the temporary files we just wrote
        s3_client = boto3.client("s3")
        folder_prefix = f"{key_prefix}{table_path}"
        temporary_files = s3_client.list_objects_v2(
            Bucket=self.s3_bucket, Prefix=folder_prefix
        )

        #copy to the new location and delete from the old
        try:
            for file in temporary_files["Contents"]:
                if file["Size"]:  # ignores empty folders
                    logger.info(f'Moving and renaming s3 object: {file["Key"]} in {self.s3_bucket}')
                    s3_client.copy_object(
                        CopySource={"Bucket": self.s3_bucket, "Key": file["Key"]},
                        BucketKeyEnabled=True,
                        Bucket=self.s3_bucket,
                        TaggingDirective="REPLACE",
                        Tagging=self._get_tags_as_url_query_string(),
                        Key=str(file["Key"]).replace(key_prefix, ""),
                    )
                    s3_client.delete_object(
                        Bucket=self.s3_bucket, Key=file["Key"]
                    )
        except KeyError:
            logger.info(f"No temporary objects found with key {folder_prefix}")