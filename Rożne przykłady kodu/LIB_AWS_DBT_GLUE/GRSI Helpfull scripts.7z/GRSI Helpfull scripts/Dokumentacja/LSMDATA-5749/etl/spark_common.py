from pyspark.sql import DataFrame

def get_df_string_repr(df: DataFrame, n=20, truncate=True, vertical=False):
    """Wrapper function for interacting with self._jdf.showString
        Can be used for debugging to return a DataFrame as a string.

        NOTE: DO NOT use with large dataframes as this can be a very costly operation
    """
    if isinstance(truncate, bool) and truncate:
        return df._jdf.showString(n, 20, vertical)
    else:
        return df._jdf.showString(n, int(truncate), vertical)