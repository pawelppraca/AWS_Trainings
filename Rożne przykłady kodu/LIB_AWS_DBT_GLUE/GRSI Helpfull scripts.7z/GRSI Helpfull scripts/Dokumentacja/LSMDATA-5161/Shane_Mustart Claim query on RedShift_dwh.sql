select  c.claim_number,
        c.claim_state
        , CONVERT(VARCHAR(10),c.date_of_loss)            as date_of_loss
        , ch.__merge_key                                as claim_handler
        , ISNULL(tt.transaction_type_code,'Unknown')    as transaction_type_code
        , ISNULL(cmt.__merge_key, 'Unknown')            as claim_movement_type
        , ri_type_code                                  as ri_code
        , isnull(ct.fiscal_date, '9999-12-31' )         as fiscal_date
        , isnull( fxo.currency_code, 'Unknown')         as original_currency_code
        , isnull( fxl.currency_code, 'Unknown')         as local_currency_code
        , ISNULL(to_char(ct.transaction_date, 'yyyymmdd'), '19000101')      as transaction_date
        , count(*)                                      as row_count
        , sum(isnull(ct.amount_original,0))             as amount_original
         , sum(isnull(ct.amount_local,0))               as amount_local

from dwh.claim  as c
left outer join dwh.claim_handler            as ch   on c.assigned_to_claim_handler_key = ch.claim_handler_key
left outer join dwh.claim_transaction        as ct   on ct.claim_key = c.claim_key
left outer join dwh.transaction_type         as tt   on ct.transaction_type_key = tt.transaction_type_key
left outer join dwh.claim_movement_type      as cmt  on cmt.claim_movement_type_key = ct.claim_movement_type_key
left outer join dwh.currency                 as fxo  on ct.original_currency_key = fxo.currency_key
left outer join dwh.currency                 as fxl  on ct.local_currency_key = fxl.currency_key
left outer join dwh.ri_code                  as ri   on ri.ri_code_key = ct.ri_code_key
--where c.claim_number not in ('AMSCAR000306116'        , 'LONPRO000339585','LONCOM000172467','LONCOM000177046','LONSPC000098291'       )
--where c.claim_state='Open'
--and CONVERT(VARCHAR(7),c.date_of_loss)='2021-01'
--and c.claim_number='DUSPC000008974'
group by 
c.claim_number,
        c.claim_state
        , CONVERT(VARCHAR(10),c.date_of_loss) 
        , ch.__merge_key
        , tt.transaction_type_code
        , cmt.__merge_key
        , ri_type_code
        , isnull(ct.fiscal_date, '9999-12-31' )
        , isnull( fxo.currency_code, 'Unknown')     
        , isnull( fxl.currency_code, 'Unknown') 
        , ISNULL(to_char(ct.transaction_date, 'yyyymmdd'), '19000101') 
;
