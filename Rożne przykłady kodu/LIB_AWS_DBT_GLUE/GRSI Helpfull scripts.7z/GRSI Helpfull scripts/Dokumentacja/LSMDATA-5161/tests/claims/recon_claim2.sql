{{ claim_recon( ref('claim') , 'isnull(stg.amount_original, 0) - isnull(dwh.amount_original,0) <> 0') }}
