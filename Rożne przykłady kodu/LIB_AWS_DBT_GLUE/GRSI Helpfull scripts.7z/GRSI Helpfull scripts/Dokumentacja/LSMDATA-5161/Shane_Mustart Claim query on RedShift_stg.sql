with cte_fx AS (
                select fiscalperiod, currencycode, rate 
                from transform.staging_genius_map_fxrates_genius
                where __data_region ='Europe'
                and fxratetypecode='GENIUS' 
                order by currencycode,fiscalperiod
),
cte_cc_tx AS (     
                select t1.claimid, t2.Ext_gwTransactionID, t1.Ext_DeductRecReductReason
                from transform.staging_claim_center_cc_transaction as t1
                inner join 
                        (       
                        select Ext_gwTransactionID, max(UpdateTime) as latest_update_time 
                        from transform.staging_claim_center_cc_transaction 
                        group by Ext_gwTransactionID ) as t2 on 
                                t1.Ext_gwTransactionID = t2.Ext_gwTransactionID 
                                and t1.UpdateTime = t2.latest_update_time
                )
                
select c.claim_number as claim_number,
         cs.[name]                                                                       as claim_state
        , CONVERT(VARCHAR(10),c.LossDate)                                                as date_of_loss
        , isnull( 'CLAIM_CENTER|' + convert(varchar, c.AssignedUserID), 'Unknown')      as claim_handler 
        , CASE WHEN ZKG3.trans_type_indicator = 0 THEN 'RSV'
                        WHEN ZKG3.trans_type_indicator = 1 THEN 'PMT'
                        ELSE 'Unknown' END                                              as transaction_type_code  
        ,  case when zkg3.claim_movement_type_1_code is null
               then 'Unknown'
               else 'GENIUS|'+ISNULL(ISNULL(zkg3.claim_movement_type_1_code,'NA') + '|' + ISNULL(zkg3.claim_movement_type_2_code,'NA') +'|' 
                       + ISNULL(nullif(UPPER(ded.[NAME]),''),'NA') , 'Unknown')  
               end                                                                      as claim_movement_type
        , case when zkg.ri_master_number=''       
               then zuma.master_minor_type_code 
               else  (CASE WHEN zkg.ri_master_number ISNULL THEN NULL ELSE 'CED' END )            
          end                                                                          as ri_code
        ,  isnull( 
                       to_date( 
                               convert( 
                                       varchar, ( (zkg.reporting_period + 190000)*100)+1 
                                      )
                               , 'yyyymmdd' )
                   , '9999-12-31'
                   )                                                                   as fiscal_date
        , isnull(fxo.currencycode, 'Unknown')                                          as original_currency_code
        , isnull(fxl.currencycode, 'Unknown')                                          as local_currency_code
        , CASE WHEN (
                    case when zkg.genius_user_id like 'ESB%' then zkg.entry_date else transaction_date end is null 
                  or case when zkg.genius_user_id like 'ESB%' then zkg.entry_date else transaction_date end =0
                     )
--               -- missing day and month
               THEN '19000101' 
                WHEN ( case when zkg.genius_user_id like 'ESB%' then zkg.entry_date else transaction_date end ) % 10000 = 0
                then convert(varchar(8), 19000101 + (case when zkg.genius_user_id like 'ESB%' then zkg.entry_date else transaction_date end)  )
--               -- missing day 
                WHEN ( case when zkg.genius_user_id like 'ESB%' then zkg.entry_date else transaction_date end ) % 100 = 0
                then convert(varchar(8), 19000001 + (case when zkg.genius_user_id like 'ESB%' then zkg.entry_date else transaction_date end)  )
                --invalid dates (19999999, 99999999)
                 WHEN ( case when zkg.genius_user_id like 'ESB%' then zkg.entry_date else transaction_date end ) in ('1999999', '999999')
                then convert(varchar(8), 19000101   )               

               ELSE convert(varchar(8), 19000000 + ( CASE WHEN ( case when zkg.genius_user_id like 'ESB%' then zkg.entry_date else transaction_date end) is not null 
                                               THEN (case when zkg.genius_user_id like 'ESB%' then zkg.entry_date else transaction_date end) ELSE '19000101' END ) )
               END AS transaction_date
--       
--        
        , count(*)                                                                      as row_count
        , convert(numeric(18,3),sum(ISNULL(zkg3.movement_amt_orig,0)))                             as amount_original
        , CONVERT(NUMERIC(38,4),SUM(case when isnull(ZKG3.trans_type_indicator,'1') = '0' 
                                        then ISNULL(zkg3.movement_amt_orig,0) * ISNULL(fxo.Rate,1) / ISNULL(fxl.Rate,1)    
                                       else     ISNULL(zkg3.movement_amt_acc,0) 
                                       end )      )                                     as amount_local

from            transform.staging_claim_center_cc_claim           as c
left outer join transform.staging_claim_center_cctl_claimstate    as cs   on c.[state] = cs.ID
left outer join transform.staging_genius_zkfa                     as zkfa on c.claim_number = zkfa.claim_number
left outer join transform.staging_genius_zkg                      as zkg  on zkfa.claim_master_code = zkg.claim_master_code
left outer join transform.staging_genius_zkg3                     as zkg3 on zkg.claim_master_code = zkg3.claim_master_code and zkg.claim_section_code = zkg3.claim_section_code and zkg.claim_trans_header_code = zkg3.claim_trans_header_code
left outer join transform.staging_genius_zuma  AS zuma ON zuma.master_number = zkg.policy_master_number and zuma.master_sequence = zkg.policy_master_sequence
left outer join cte_cc_tx       as t    on t.claimid = c.[id] AND zkg.claim_trans_ref = t.Ext_gwTransactionID
left outer join transform.staging_claim_center_cctl_Ext_DeductRecReductReason  AS ded ON ded.ID = t.Ext_DeductRecReductReason
left outer join cte_fx as fxo On fxo.FiscalPeriod =  isnull( to_char ( dateadd ( mm, -1, to_date( 
                               convert( 
                                       varchar, ( (zkg.reporting_period + 190000)*100)+1 
                                      )
                               , 'yyyymmdd' )  
                    )  
                    , 'YYYYMMDD')
                                                               , '99991231'
                                                             )  -- joins on the previous Fiscal Period
                                                                        AND  fxo.CurrencyCode = zkg.original_currency_code
                                                                
left outer join cte_fx as fxl On fxl.FiscalPeriod =  isnull( to_char ( dateadd ( mm, -1, to_date( 
                               convert( 
                                       varchar, ( (zkg.reporting_period + 190000)*100)+1 
                                      )
                               , 'yyyymmdd' )  
                    )  
                    , 'YYYYMMDD')
                                                               , '99991231'
                                                               )  -- joins on the previous Fiscal Period
                                                                        AND  fxl.CurrencyCode = zkg.accounting_currency_code
where 1=1
--********************    These criteria do not currently work as the below fields are redacted   **************************
-- *******************    Uncomment once these are unredacted
--and zkg.G0G0P2 IN ('1', '5','')   -- O/S Status     1 = O/S Confirmed 5 = Unapplicable
--AND zkg.G0CTHA IN ('1', '3')   -- ClTrHdr Authorisation Status  1 = Authorised,  3 = Not Applicable 
--AND ZKG3.G3E3F1 <> '2'   -- Amount retained flag
--**************************************************************************************************************************
group by
 c.claim_number,
                cs.[name]
                , CONVERT(VARCHAR(10),c.LossDate)
                , isnull('CLAIM_CENTER|' + convert(varchar, c.AssignedUserID), 'Unknown')
                , CASE WHEN ZKG3.trans_type_indicator = 0 THEN 'RSV'
                        WHEN ZKG3.trans_type_indicator = 1 THEN 'PMT'
                        ELSE 'Unknown' END
, case when zkg3.claim_movement_type_1_code is null
               then 'Unknown'
               else 'GENIUS|'+ISNULL(ISNULL(zkg3.claim_movement_type_1_code,'NA') + '|' + ISNULL(zkg3.claim_movement_type_2_code,'NA') +'|' 
                       + ISNULL(nullif(upper(ded.[NAME]),''),'NA') , 'Unknown')  
               end
, case when zkg.ri_master_number=''       
               then zuma.master_minor_type_code 
               else  (CASE WHEN zkg.ri_master_number ISNULL THEN NULL ELSE 'CED' END )            
          end 
, isnull( 
                       to_date( 
                               convert( 
                                       varchar, ( (zkg.reporting_period + 190000)*100)+1 
                                      )
                               , 'yyyymmdd' )
                   , '9999-12-31'
                   )
, fxo.currencycode 
, fxl.currencycode 
 , CASE WHEN (
                     case when zkg.genius_user_id like 'ESB%' then zkg.entry_date else transaction_date end is null 
                  or case when zkg.genius_user_id like 'ESB%' then zkg.entry_date else transaction_date end =0
                     )
               -- missing day and month
               THEN '19000101' 
                WHEN ( case when zkg.genius_user_id like 'ESB%' then zkg.entry_date else transaction_date end ) % 10000 = 0
                then convert(varchar(8), 19000101 + (case when zkg.genius_user_id like 'ESB%' then zkg.entry_date else transaction_date end)  )
               -- missing day 
                WHEN ( case when zkg.genius_user_id like 'ESB%' then zkg.entry_date else transaction_date end ) % 100 = 0
                then convert(varchar(8), 19000001 + (case when zkg.genius_user_id like 'ESB%' then zkg.entry_date else transaction_date end)  )
                --invalid dates (19999999, 99999999)
                 WHEN ( case when zkg.genius_user_id like 'ESB%' then zkg.entry_date else transaction_date end ) in ('1999999', '999999')
                then convert(varchar(8), 19000101   )               

               ELSE convert(varchar(8), 19000000 + ( CASE WHEN ( case when zkg.genius_user_id like 'ESB%' then zkg.entry_date else transaction_date end) is not null 
                                               THEN (case when zkg.genius_user_id like 'ESB%' then zkg.entry_date else transaction_date end) ELSE '19000101' END ) )
               END