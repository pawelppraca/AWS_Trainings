select 
        stg.claim_number                                                        as stg_claim_number
        , dwh.claim_number                                                      as dwh_claim_number,
         stg.claim_state
        , stg.date_of_loss
        , stg.claim_handler
        , stg.transaction_type_code
        , stg.claim_movement_type
        , dwh.claim_movement_type
        , stg.ri_code                                                           as stg_ri_code
        , dwh.ri_code                                                           as dwh_ri_code
        , stg.fiscal_date                                                       as stg_fiscal_date
        , dwh.fiscal_date                                                       as dwh_fiscal_date
        , stg.transaction_date                                                  as stg_transaction_date
        , dwh.transaction_date                                                  as dwh_transaction_date
        , stg.original_currency_code                                            as stg_original_currency_code
        , dwh.original_currency_code                                            as dwh_original_currency_code
        , stg.local_currency_code                                               as stg_local_currency_code
        , dwh.local_currency_code                                               as dwh_local_currency_code
        , stg.row_count                                                         as staging_count
        , dwh.row_count                                                         as dwh_count
        , isnull(stg.row_count, 0) - isnull(dwh.row_count,0)                    as difference_in_count
        , stg.amount_original                                                   as staging_amount_original
        , dwh.amount_original                                                   as dwh_amount_original
        , isnull(stg.amount_original, 0) - isnull(dwh.amount_original,0)        as difference_in_amount_original
        , stg.amount_local                                                      as stg_amount_local
        , dwh.amount_local                                                      as dwh_amount_local
        , isnull(stg.amount_local, 0) - isnull(dwh.amount_local,0)              as difference_in_amount_local
FROM {{  model_stg   }} AS stg
FULL OUTER JOIN {{ model_dwh}}
                                on stg.date_of_loss = dwh.date_of_loss
                                and stg.claim_state = dwh.claim_state
                                and stg.claim_handler = dwh.claim_handler
                                and stg.transaction_type_code = dwh.transaction_type_code
                                and stg.claim_movement_type = dwh.claim_movement_type
                                and isnull(stg.ri_code,'') = isnull(dwh.ri_code,'')
                                and stg.fiscal_date = dwh.fiscal_date
                                and stg.claim_number = dwh.claim_number
                                and stg.original_currency_code = dwh.original_currency_code
                                and stg.local_currency_code = dwh.local_currency_code
                                and stg.transaction_date = dwh.transaction_date
WHERE isnull(stg.amount_original, 0) - isnull(dwh.amount_original,0) <>0   --TEST_nr_1


-- or   isnull(stg.row_count, 0) - isnull(dwh.row_count,0) <>0 --test_nr_2
-- or   ABS(isnull(stg.amount_local, 0) - isnull(dwh.amount_local,0)) > 1  -- change this to adjust tolerances as required --test_nr_3

