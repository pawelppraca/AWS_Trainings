    select source_checksum.checksum AS source_checksum, target_checksum.checksum AS target_checksum
    from  source_checksum 
     JOIN target_checksum on  source_checksum.key_id = target_checksum.key_id
    where source_checksum.checksum != target_checksum.checksum