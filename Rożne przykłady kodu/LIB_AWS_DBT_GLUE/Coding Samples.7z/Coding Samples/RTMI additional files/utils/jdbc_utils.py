import re


from py4j.java_gateway import java_import


class JDBCConfig(object):
    def __init__(self, glue_context, spark_context):
        self._gc = glue_context
        self._sc = spark_context
        self._config = None
        self._url = None
        self._connection = None
        self.__java_imports()

    def __java_imports(self):
        java_import(self._sc._gateway.jvm, "java.sql.DriverManager")

    def __set_config(self, conn, db_name):
        _config = self._gc.extract_jdbc_conf(conn)
        self._config = {
            "url": _config.get("url"),
            "user": _config.get("user"),
            "password": _config.get("password"),
            "db_name": db_name,
        }

    def __set_url(self, target):
        self._url = target.format(**self._config)

    def __set_connection(self):
        self._connection = self._sc._gateway.jvm.DriverManager.getConnection(
            self._url, self._config.get("user"), self._config.get("password")
        )

    def extract(self, conn, target, db_name):
        self.__set_config(conn, db_name)
        self.__set_url(target)
        self.__set_connection()


class JDBCURLMismatchError(Exception):
    pass


class URLConfExtractor:
    def __init__(self, pattern: str) -> None:
        """Extracts information from the base JDBC URL for a given pattern"""
        self._pattern = pattern
        self._detector = re.compile(self._pattern, flags=re.UNICODE)

    def get_conf(self, url: str) -> dict:
        """Returns JDBC config data dictionary.

        Return:
            dict: JDBC config data dict.

        """
        return self._detector.match(url).groupdict()


class JDBCURLConfExtractor(URLConfExtractor):
    def __init__(self):
        """Extracts information for JDBC String given the JDBC pattern."""
        self._pattern = (
            r"(?P<protocol>jdbc):"
            "(?P<db_type>[\w]+)\:\/\/"
            "(?P<host>lsm\-dp\-rds\-(?P<app_env>(sandbox|sit|uat|test|qa|production))\.[\w]+\."
            "(?P<region>(us|eu)-(ea|we)st-(1|2))\.rds\.amazonaws\.com)\:"
            "(?P<port>[0-9]{4,5})\;"
            "(databaseName=((?P<database_name>[\w\_]+)\;))"
        )
        URLConfExtractor.__init__(self, self._pattern)


def get_jdbc_conf_data(url: str = None) -> dict:
    """Gets Config Data from the JDBC String.

    Args:
        url (str, optional): JDBC URL String. Defaults to None.

    Returns:
        dict: detected JDBC URL Components -
            1. protocol
            2. db_type
            3. host
            4. app_env
            5. region
            6. port
            7. database_name

    Examples:
        In []: JDBCURLConfExtractor().get_conf("jdbc:sqlserver://lsm-dp-hackathon-rds-sandbox.cvt6y767htpf.us-east-1.rds.amazonaws.com:1433;databaseName=WideWorldImporters;")
        Out[]:
            {
                'protocol': 'jdbc',
                'db_type': 'sqlserver',
                'host': 'lsm-dp-rds-sandbox.cvt6y767htpf.us-east-1.rds.amazonaws.com',
                'app_env': 'sandbox',
                'region': 'us-east-1',
                'port': '1433',
                'database_name': 'WideWorldImporters'
            }

    Raises:
        JDBCURLMismatchError: In case the passed URL does not comply with the REGEX pattern.

    """
    if not url:
        url = (
            "jdbc:sqlserver://"
            "lsm-dp-rds-sandbox.cvt6y767htpf.us-east-1.rds.amazonaws.com:"
            "1433;"
            "databaseName=WideWorldImporters;"
        )
    extractor = JDBCURLConfExtractor()
    try:
        return extractor.get_conf(url)
    except AttributeError:
        raise JDBCURLMismatchError(
            f"'{url}' is not compliant with REGEX=r'{extractor._pattern}'"
        )
