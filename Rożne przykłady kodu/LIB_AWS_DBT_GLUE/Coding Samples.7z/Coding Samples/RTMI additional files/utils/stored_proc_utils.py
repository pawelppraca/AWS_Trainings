from py4j.java_gateway import java_import


IP_ARGS_DT = {
    "String": str,
    "Int": int
}


def get_sp_func_signature(params_count):
    """Gets ',' separated string denoting the no. of params (?).

    Args:
        params_count (int): no. of params.

    Returns:
        str: stored proc function signature string.

    Raises:
        NotImplementedError: if params_count is 0 or None.

    Examples:
        In []: get_stored_proc_params_signature(1)
        Out[]: '?'

        In []: get_stored_proc_params_signature(2)
        Out[]: '?, ?'

        In []: get_stored_proc_params_signature(3)
        Out[]: '?, ?, ?'

    """
    if not params_count:
        raise NotImplementedError("'params_count' is 0!")
    return "?, ".join("" for _ in range(params_count)) + "?"


class StoredProcedure(object):
    def __init__(self, glue_context, spark_context):
        self._gc = glue_context
        self._sc = spark_context
        self._name = None
        self._query = None
        self._template = None
        self._args = None
        self._in_params = None
        self._out_params = None
        self._result = None
        self.__java_imports()
        self._out_dt = {
            "Int": self._sc._gateway.jvm.Types.INTEGER,
            "String": self._sc._gateway.jvm.Types.VARCHAR       
        }

    def __java_imports(self):
        java_import(self._sc._gateway.jvm, "java.sql.Types")
    
    def __set_query(self, template, qargs):
        self._template = template

        qargs.update({"params": get_sp_func_signature(qargs["params"])})
        self._args = qargs
        
        self._query = self._template.format(**self._args) 

    def __set_params(self, params):
        self._in_params = params["in"]
        self._out_params = params["out"]

    def __execute_query(self, conn):
        cstmt = conn.prepareCall(self._query)

        for i, f, v in self._in_params:
            getattr(cstmt, "set" + f)(int(i), IP_ARGS_DT[f](v))

        for i, f, v in self._out_params:
            getattr(cstmt, "registerOutParameter")(int(i), self._out_dt[f])

        cstmt.execute()

        self._result = {}
        for i, f, v in self._out_params:
            self._result[v] = getattr(cstmt, "get" + f)(int(i))

    
    def call(self, template, qargs, params, conn):
        self.__set_query(template, qargs)
        self.__set_params(params)
        self.__execute_query(conn)


