from boto3.session import Session
import boto3

ACCESS_KEY = '' #update your access
SECRET_KEY = '' #update your secret


session = Session(aws_access_key_id=ACCESS_KEY,
              aws_secret_access_key=SECRET_KEY)
s3 = session.resource('s3')
your_bucket = s3.Bucket('lsm-dp-ingestion-eu-test')

#string to search - update it
fileWildcard = "jr_5009d3d773530d0bf2f3069c34403c593546a857f353cfb9f0bb998836dc1c9b"
#folder on S3 bucket f.i. Genius/ZUMA/
s3folder = "sparklogs/"
#local folder where files will be downloaded
localFolder = '<local_path>/'

for s3_file in your_bucket.objects.filter(Prefix=s3folder):
    if s3_file.key.find(fileWildcard)!=-1: #returns only file which contains string defined in fileWildcard
        pathfile = localFolder+s3_file.key #set path: folder + file
        print(s3_file.key,pathfile.replace(s3folder, "")) 
        your_bucket.download_file(Key=s3_file.key, Filename=pathfile.replace("/sparklogs", "")) # remove part of s3 folder(Filename) and download file
    else:
        pass

#s3://lsm-dp-ingestion-eu-test/sparklogs/jr_5009d3d773530d0bf2f3069c34403c593546a857f353cfb9f0bb998836dc1c9b
#s3://lsm-dp-ingestion-eu-test/sparklogs/jr_ec7090b5d043dbd8526286bbf51a9d34e253a9a6425405eec6335f25112d4d4f
#s3://lsm-dp-ingestion-eu-test/Genius/ZUMA/part-00019-8c8e5187-5f82-4f26-942d-417250e40d18-c000.snappy.parquet