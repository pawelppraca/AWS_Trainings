"""
***************************************************************************
**
** File              : genius-get-companycode.py
** Version           : $Revision: 02.00.29 $
** Description       :
**
** Read the company codes from map_lgscompany,MasterKeys from S3
** creates CompanyCode DF 
**
** Called by  : None
**
** Parameters:
** In	: None
**
***************************************************************************
** Change History
** Revision:		Date:      Author:					Description:
** ----------		---------- ----------------------	---------------------------
** Version 10.00.21 12/10/2021 Priyanka L               Initial Version
** Version 01.00.22 12/01/2022 Priyanka L               Added script for 3 new tables
** Version 01.00.23 13/12/2023 Karol Jurek              Added script for new table - ZHET ( LSMDATA-4239 )
** Version 01.00.24 14/03/2024 Jacek Rybski             Added script for new table - ZHMN ( LSMDATA-2426 )
** Version 02.00.24 04/03/2024 Pawel Parasyn            Added new companies (SWEDEN and NORWAY) to Filter - LSMADATA-4561
** Version 02.00.25 11/04/2024 Karol Jurek              Added FXRates ( LSMDATA-4658)
** Version 02.00.26 07/05/2024 Karol Jurek              Added GenericColumnNames ( LSMDATA-3848)
** Version 02.00.27 17/05/2024 Jacek Rybski             Added new company BELGIUM to Filter (LSMDATA-4796)
** Version 02.00.28 13/06/2024 Pawel Parasyn            Added new product codes to load RI policy (LSMDATA-5120)
** Version 02.00.29 13/06/2024 Pawel Parasyn            Modified code to load RI policy (LSMDATA-5120)
***************************************************************************
"""

import constants
import logging

from awsglue.transforms import *
from pyspark.sql.types import datetime
from genius_name_address_queries import name_address_dict
from lsm_dp_dynamo_functions import read_dynamodb_controlkey
from typing import List, Dict


# https://forge.lmig.com/wiki/display/GSLITMI/Genius+Filters
lsm_companies = ["CHILE", "ARGNTA", "MLYON", "BRZAFFIL", "LIBSEGBR", "MLYOFF", "COLOMBIA", "COL", "LMLATAM", "CHL", 
                "BRASIL", "PERU", "ECUADOR", "LSILATAM", "LIUILATM", "LIBSEGPE", "MEXICO", "SING", "SOF", "AUS", "HK",
                "BENELUX", "BHAMUK", "BRISTLUK", "COLOGNUK", "DUBAI", "DUBUK", "GLASGOUK", "HAMBRGUK", "IRELC", "LEEDSUK",
                "LMUK", "MANUK", "MILANUK", "PARISUK", "SOEASTUK", "SPAIN", "SWISSUK", "VISIONUW", "IRE", "LUXUK",
                "NORWAY","SWEDEN","BELGIUM"]
lsm_products = ["EQUINE", "TPR", "TERROR" , "ENGNR", "HVY", "OFNRG", "ONNRG", "INLM", "INLMQ", "COC", "ONNRGQ",
                "OFNRGQ", "HVYQ", "ENGNRQ", "FAC", "QS", "SUR", "XSL", "FXL", "QS2", "QS3"]
lsm_departments = ["GLA", "GUA", "GUC", "GUD", "SD5"]
lsm_west_branches = ["3MIAMI", "5MIAMI", "4PAULO", "3PR"]

non_7_branch_products = ["INLM", "INLMQ"]


def get_cdc_lower_boundary(tablename):
    header_change_seq = read_dynamodb_controlkey("1", tablename)
    return header_change_seq


def get_zuma_cdc_boundary():
    return get_cdc_lower_boundary("ZUMA")


def get_sql_in(tables: List[str]) -> str:
    return "(" + ", ".join(map(lambda table: f"'{table}'", tables)) + ")"


def filter_zuma(df_zumasource):
    df_zuma_filtered = df_zumasource.filter(
        (
            df_zumasource.MACNCD.isin(lsm_companies)
            | df_zumasource.MAMAPC.isin(lsm_products)
            | df_zumasource.MADPCD.isin(lsm_departments)
            | df_zumasource.MAMABN.isin(lsm_west_branches)
        )
        &
        # LSMDATA-1771
        ~(df_zumasource.MAMAPC.isin("TPR") & df_zumasource.MACNCD.isin("III", "ISIC"))
        & (
            ~df_zumasource.MAMABN.startswith("7")
            | ~df_zumasource.MAMAPC.isin(non_7_branch_products)
        )
    )

    return df_zuma_filtered


def get_lsm_filter_sql(is_incremental=False):
    _log = ""
    if is_incremental:
        _log = "_log"

    return f"""WHERE (ZUMA{_log}.MACNCD IN {get_sql_in(lsm_companies)} OR ZUMA{_log}.MAMAPC IN {get_sql_in(lsm_products)} OR ZUMA{_log}.MADPCD IN {get_sql_in(lsm_departments)} OR ZUMA{_log}.MAMABN IN {get_sql_in(lsm_west_branches)})
AND NOT(ZUMA{_log}.MAMAPC = 'TPR' AND ZUMA{_log}.MACNCD IN ('III','ISIC'))
AND (LEFT(ZUMA{_log}.MAMABN, 1) <> '7' OR ZUMA{_log}.MAMAPC NOT IN {get_sql_in(non_7_branch_products)})"""


##########################################################################
# Create filter based on table name and extract mode
##########################################################################
def get_genius_filter(tablename, isfullload, table_cdc_upper_boundary=None, zuma_cdc_upper_boundary=None):
    if tablename in constants.ODS_Genius_Staight_Pull_Tables:
        return get_straight_pull_filter(tablename, isfullload, table_cdc_upper_boundary)

    if tablename in constants.Genius_ZUMA_orphan_tables:
        return get_zuma_orphan_table_filter(tablename, isfullload, table_cdc_upper_boundary=table_cdc_upper_boundary)

    if isfullload:
        lsm_filter = get_lsm_filter_sql()
        if tablename in constants.genius_partition_tables:
            return lsm_filter + ") as subq"
        return lsm_filter

    
    if tablename in ["ZUMA","COVERS"]:
        cdc_lower_boundary = get_cdc_lower_boundary("ZUMA")
        return f"WHERE ZUMA_log.header_change_seq > '{cdc_lower_boundary}' AND ZUMA_log.header_change_seq <= '{zuma_cdc_upper_boundary}'"
    elif tablename == "COVERS_ZURI":
        cdc_lower_boundary = get_cdc_lower_boundary("ZURI")
        return f"WHERE ZURI_log.header_change_seq > '{cdc_lower_boundary}' AND ZURI_log.header_change_seq <= '{zuma_cdc_upper_boundary}'"
    else:
        cdc_lower_boundary = get_cdc_lower_boundary(tablename)
        zuma_dynamo_upper_boundary = get_zuma_cdc_boundary()
        # ensures no missing records as boundary established before extract
        if table_cdc_upper_boundary < zuma_dynamo_upper_boundary:
            zuma_dynamo_upper_boundary = table_cdc_upper_boundary

        query = f"WHERE {tablename}_log.header_change_seq > '{cdc_lower_boundary}' AND {tablename}_log.header_change_seq <= '{zuma_dynamo_upper_boundary}'"
        return query


def get_straight_pull_filter(tablename, isfullload, table_cdc_upper_boundary):
    if isfullload:
        return ""
    return f"WHERE {tablename}_log.header_change_seq > '{get_cdc_lower_boundary(tablename)}' AND {tablename}_log.header_change_seq <= '{table_cdc_upper_boundary}'"


def get_zuma_orphan_table_filter(tablename, isfullload, is_delete_query=False, table_cdc_upper_boundary=None):
    log = ""
    if is_delete_query or (tablename == "ZSE5_orphan" and not isfullload):
        log = "_log"

    where_clause = f"WHERE ZSE5{log}.E5MANU = '' and ZSE5{log}.E5MASE = '' AND ZSE5{log}.E5CNCD IN ('BENELUX', 'BHAMUK', 'BRISTLUK', 'COLOGNUK', 'DUBAI', 'DUBUK', 'GLASGOUK', 'HAMBRGUK', 'IRELC', 'LEEDSUK', 'LMUK', 'MANUK', 'MILANUK', 'PARISUK', 'SOEASTUK', 'SPAIN', 'SWISSUK', 'VISIONUW', 'IRE', 'LUXUK', 'NORWAY', 'SWEDEN', 'BELGIUM')"
    if not isfullload:
        where_clause += " AND {table}_log.header_change_seq > '{min}' AND {table}_log.header_change_seq <= '{max}'".format(
            table=tablename.replace("_orphan", ""),
            min=get_cdc_lower_boundary(tablename),
            max=table_cdc_upper_boundary,
        )

    return where_clause


def get_geniusquery(tablename, isfullload, filter_change_filter=None, add_missing_policies=None, table_cdc_upper_boundary=None, zuma_cdc_upper_boundary=None):
    log_table = ""
    select_columns = ""
    is_incremental = (not isfullload and filter_change_filter is None)
    if is_incremental:
        log_table = "_log"
        select_columns = ",ZUMA.MAMANU,ZUMA.MAMASE"

    switcher = {
        "ZUMA": "SELECT ZUMA{log}.*,ZUMA{log}.MACNCD AS CompanyCode FROM Genius.ZUMA{log}".format(log=log_table),
        
        # claims
        "ZKFA": "SELECT ZKFA{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZKFA{log} INNER JOIN Genius.ZUMA ".format(log=log_table, extra_columns=select_columns) +
                "ON ZKFA{log}.FAFANU = ZUMA.MAMANU AND ZKFA{log}.FAFASE = ZUMA.MAMASE".format(log=log_table),
        "ZKFB": "SELECT ZKFB{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZKFB{log} INNER JOIN Genius.ZKFA ".format(log=log_table, extra_columns=select_columns) +
                    "ON ZKFB{log}.FBFANO = ZKFA.FAFANO INNER JOIN Genius.ZUMA ".format(log=log_table) +
                    "ON ZKFA.FAFANU = ZUMA.MAMANU AND ZKFA.FAFASE = ZUMA.MAMASE",
        "ZKG": "SELECT ZKG{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZKG{log} INNER JOIN Genius.ZKFB ".format(log=log_table, extra_columns=select_columns) +
                    "ON ZKG{log}.G0FANO = ZKFB.FBFANO AND ZKG{log}.G0FBCD = ZKFB.FBFBCD INNER JOIN Genius.ZKFA ".format(log=log_table) +
                    "ON ZKFB.FBFANO = ZKFA.FAFANO INNER JOIN Genius.ZUMA " +
                    "ON ZKFA.FAFANU = ZUMA.MAMANU AND ZKFA.FAFASE = ZUMA.MAMASE",
        "ZKG3": "SELECT ZKG3{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZKG3{log} INNER JOIN Genius.ZKG ON ZKG3{log}.G3FANO = ZKG.G0FANO ".format(log=log_table, extra_columns=select_columns) +
                    "AND ZKG3{log}.G3FBCD = ZKG.G0FBCD AND ZKG3{log}.G3F3CD = ZKG.G0F3CD INNER JOIN Genius.ZKFB ".format(log=log_table) +
                    "ON ZKG.G0FANO = ZKFB.FBFANO AND ZKG.G0FBCD = ZKFB.FBFBCD INNER JOIN Genius.ZKFA " +
                    "ON ZKFB.FBFANO = ZKFA.FAFANO INNER JOIN Genius.ZUMA " +
                    "ON ZKFA.FAFANU = ZUMA.MAMANU AND ZKFA.FAFASE = ZUMA.MAMASE",

        # name_address_company
        "ZUNI": "SELECT ZUNI{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZUNI{log} INNER JOIN Genius.ZUMA ".format(log=log_table, extra_columns=select_columns) +
                    "ON ZUNI{log}.NIMANU = ZUMA.MAMANU AND ZUNI{log}.NIMASE = ZUMA.MAMASE".format(log=log_table),
        "ZNNU": "SELECT DISTINCT ZNNU{log}.*{extra_columns} FROM Genius.ZNNU{log} INNER JOIN Genius.ZUNI ".format(log=log_table, extra_columns=select_columns) +
                    "ON ZNNU{log}.NUNACD = ZUNI.NINACD INNER JOIN Genius.ZUMA ".format(log=log_table) +
	                "ON ZUNI.NIMANU = ZUMA.MAMANU AND ZUNI.NIMASE = ZUMA.MAMASE",
        "ZNDX": "SELECT DISTINCT ZNDX{log}.*{extra_columns} FROM Genius.ZNDX{log} INNER JOIN Genius.ZUNI ".format(log=log_table, extra_columns=select_columns) +
                    "ON ZNDX{log}.DXNACD = ZUNI.NINACD INNER JOIN Genius.ZUMA ".format(log=log_table) +
                    "ON ZUNI.NIMANU = ZUMA.MAMANU AND ZUNI.NIMASE = ZUMA.MAMASE",
        "ZNNC": "SELECT DISTINCT ZNNC{log}.*{extra_columns} FROM Genius.ZNNC{log} INNER JOIN Genius.ZUNI ".format(log=log_table, extra_columns=select_columns) +
	                "ON ZNNC{log}.NCNACD = ZUNI.NINACD INNER JOIN Genius.ZUMA ".format(log=log_table) +
                    "ON ZUNI.NIMANU = ZUMA.MAMANU AND ZUNI.NIMASE = ZUMA.MAMASE",
        "ZNNA": "SELECT DISTINCT ZNNA{log}.*{extra_columns} FROM Genius.ZNNA{log} INNER JOIN Genius.ZUNI ".format(log=log_table, extra_columns=select_columns) +
	                "ON ZNNA{log}.NANACD = ZUNI.NINACD INNER JOIN Genius.ZUMA ".format(log=log_table) +
	                "ON ZUNI.NIMANU = ZUMA.MAMANU AND ZUNI.NIMASE = ZUMA.MAMASE",
        "ZNNZ": "SELECT DISTINCT ZNNZ{log}.*{extra_columns} FROM Genius.ZNNZ{log} INNER JOIN Genius.ZUNI ".format(log=log_table, extra_columns=select_columns) +
	                "ON ZNNZ{log}.NZNACD = ZUNI.NINACD INNER JOIN Genius.ZUMA ".format(log=log_table) +
	                "ON ZUNI.NIMANU = ZUMA.MAMANU AND ZUNI.NIMASE = ZUMA.MAMASE",
        "ZUBD": "SELECT DISTINCT ZUBD{log}.*{extra_columns} FROM Genius.ZUBD{log} INNER JOIN Genius.ZUNI ".format(log=log_table, extra_columns=select_columns) +
                    "ON ZUBD{log}.BDNACD = ZUNI.NINACD AND ZUBD{log}.BDISSQ = ZUNI.NIISSQ INNER JOIN Genius.ZUMA ".format(log=log_table) +
                    "ON ZUNI.NIMANU = ZUMA.MAMANU AND ZUNI.NIMASE = ZUMA.MAMASE",
        "ZNA": "SELECT DISTINCT ZNA{log}.*{extra_columns} FROM Genius.ZNA{log} INNER JOIN Genius.ZNNZ ".format(log=log_table, extra_columns=select_columns) +
	                "ON ZNA{log}.ADADCD = ZNNZ.NZADCD INNER JOIN Genius.ZNNA ".format(log=log_table) +
	                "ON ZNNZ.NZNACD = ZNNA.NANACD INNER JOIN Genius.ZUNI " +
	                "ON ZNNA.NANACD = ZUNI.NINACD INNER JOIN Genius.ZUMA " +
	                "ON ZUNI.NIMANU = ZUMA.MAMANU AND ZUNI.NIMASE = ZUMA.MAMASE",
        "ZNAQ": "SELECT DISTINCT ZNAQ{log}.*{extra_columns} FROM Genius.ZNAQ{log} INNER JOIN Genius.ZNNZ ".format(log=log_table, extra_columns=select_columns) +
                    "ON AQADCD = NZADCD INNER JOIN Genius.ZNNA " +
                    "ON NZNACD = NANACD INNER JOIN Genius.ZNNU ZNNU " +
                    "ON ZNNA.NANACD = ZNNU.NUNACD INNER JOIN Genius.ZUNI ZUNI " +
                    "ON ZNNU.NUNACD = ZUNI.NINACD AND ZNNU.NUNUCD = ZUNI.NINUCD INNER JOIN Genius.ZUMA ZUMA " +
                    "ON ZUNI.NIMANU = ZUMA.MAMANU AND ZUNI.NIMASE = ZUMA.MAMASE",

        # statistics
        "ZSE": "SELECT ZSE{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZSE{log} INNER JOIN Genius.ZUMA ".format(extra_columns=select_columns,log=log_table) +
                    "ON ZSE{log}.E0MANU = ZUMA.MAMANU AND ZSE{log}.E0MASE = ZUMA.MAMASE".format(log=log_table),
        "ZSE1": "SELECT ZSE1{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZSE1{log} INNER JOIN Genius.ZSE ".format(log=log_table, extra_columns=select_columns) +
                    "ON ZSE1{log}.E1E0CD = ZSE.E0E0CD INNER JOIN Genius.ZUMA ".format(log=log_table) +
                    "ON ZSE.E0MANU = ZUMA.MAMANU AND ZSE.E0MASE = ZUMA.MAMASE",
        "ZSE2": "SELECT ZSE2{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZSE2{log} INNER JOIN Genius.ZSE ".format(log=log_table, extra_columns=select_columns) +
                    "ON ZSE2{log}.E2E0CD = ZSE.E0E0CD INNER JOIN Genius.ZUMA ".format(log=log_table) +
	                "ON ZSE.E0MANU = ZUMA.MAMANU AND ZSE.E0MASE = ZUMA.MAMASE",
        "ZSE3": "SELECT ZSE3{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZSE3{log} INNER JOIN Genius.ZSE2 ".format(log=log_table, extra_columns=select_columns) +
                    "ON ZSE3{log}.E3E0CD = ZSE2.E2E0CD AND ZSE3{log}.E3E2CD = ZSE2.E2E2CD INNER JOIN Genius.ZSE ".format(log=log_table) +
                    "ON ZSE2.E2E0CD = ZSE.E0E0CD INNER JOIN Genius.ZUMA " +
                    "ON ZSE.E0MANU = ZUMA.MAMANU AND ZSE.E0MASE = ZUMA.MAMASE",
        "ZSE4": "SELECT ZSE4{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZSE4{log} INNER JOIN Genius.ZSE2 ".format(log=log_table, extra_columns=select_columns) +
	                "ON ZSE4{log}.E4E0CD = ZSE2.E2E0CD AND ZSE4{log}.E4E2CD = ZSE2.E2E2CD INNER JOIN Genius.ZSE ".format(log=log_table) +
	                "ON ZSE2.E2E0CD = ZSE.E0E0CD INNER JOIN Genius.ZUMA " +
                    "ON ZSE.E0MANU = ZUMA.MAMANU AND ZSE.E0MASE = ZUMA.MAMASE",
        # statistic_postings
        "ZSE5": "SELECT ZSE5{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZSE5{log} INNER JOIN Genius.ZUMA ".format(log=log_table, extra_columns=select_columns) +
                    "ON ZSE5{log}.E5MANU = ZUMA.MAMANU AND ZSE5{log}.E5MASE = ZUMA.MAMASE".format(log=log_table),
        "ZSM4": "SELECT ZSM4{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZSM4{log} INNER JOIN Genius.ZSE5 ".format(log=log_table, extra_columns=select_columns) +
                    "ON ZSM4{log}.M4MINB = ZSE5.E5MINB INNER JOIN Genius.ZUMA ".format(log=log_table) +
	                "ON ZSE5.E5MANU = ZUMA.MAMANU AND ZSE5.E5MASE = ZUMA.MAMASE",
        "ZAH":  "SELECT ZAH{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZAH{log} INNER JOIN Genius.ZSE5 ".format(log=log_table, extra_columns=select_columns) +
                    "ON ZAH{log}.HFMINB = ZSE5.E5MINB INNER JOIN Genius.ZUMA ".format(log=log_table) +
	                "ON ZSE5.E5MANU = ZUMA.MAMANU AND ZSE5.E5MASE = ZUMA.MAMASE",

        # statistic_postings_orphan
        "ZSE5_orphan": "SELECT ZSE5{log}.*,ZSE5{log}.E5CNCD AS CompanyCode FROM Genius.ZSE5{log}".format(log=log_table),
        "ZSM4_orphan": "SELECT ZSM4{log}.*,ZSE5.E5CNCD AS CompanyCode FROM Genius.ZSM4{log} INNER JOIN Genius.ZSE5 ".format(log=log_table) +
                        "ON ZSM4{log}.M4MINB = ZSE5.E5MINB".format(log=log_table),
        "ZAH_orphan": "SELECT ZAH{log}.*,ZSE5.E5CNCD AS CompanyCode FROM Genius.ZAH{log} INNER JOIN Genius.ZSE5 ".format(log=log_table) +
                        "ON ZAH{log}.HFMINB = ZSE5.E5MINB".format(log=log_table),

        # underwriting
        "ZUSK": "SELECT ZUSK{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZUSK{log} INNER JOIN Genius.ZUMA ".format(log=log_table, extra_columns=select_columns) +
	                "ON ZUSK{log}.SKMANU = ZUMA.MAMANU AND ZUSK{log}.SKMASE = ZUMA.MAMASE".format(log=log_table),
        "ZUTR": "SELECT ZUTR{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZUTR{log} INNER JOIN Genius.ZUMA ".format(log=log_table, extra_columns=select_columns) +
                    "ON ZUTR{log}.TRMANU = ZUMA.MAMANU AND ZUTR{log}.TRMASE = ZUMA.MAMASE".format(log=log_table),
        "ZUS": "SELECT ZUS{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZUS{log} INNER JOIN Genius.ZUMA ".format(log=log_table, extra_columns=select_columns) +
	                "ON ZUS{log}.SFMANU = ZUMA.MAMANU AND ZUS{log}.SFMASE = ZUMA.MAMASE".format(log=log_table),
        "ZUCO": "SELECT ZUCO{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZUCO{log} INNER JOIN Genius.ZUMA ".format(log=log_table, extra_columns=select_columns) +
                    "ON ZUCO{log}.COMANU = ZUMA.MAMANU AND ZUCO{log}.COMASE = ZUMA.MAMASE".format(log=log_table),
        "ZUDD": "SELECT ZUDD{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZUDD{log} INNER JOIN Genius.ZUMA ".format(log=log_table, extra_columns=select_columns) +
	                "ON ZUDD{log}.DDMANU = ZUMA.MAMANU AND ZUDD{log}.DDMASE = ZUMA.MAMASE".format(log=log_table),
        "ZURI": "SELECT ZURI{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZURI{log} INNER JOIN Genius.ZUMA ".format(log=log_table, extra_columns=select_columns) +
                    "ON ZURI{log}.RIMANU = ZUMA.MAMANU AND ZURI{log}.RIMASE = ZUMA.MAMASE".format(log=log_table),
        "ZUM": "SELECT ZUM{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZUM{log} INNER JOIN Genius.ZUMA ".format(log=log_table, extra_columns=select_columns) +
                    "ON ZUM{log}.M0MANU = ZUMA.MAMANU AND ZUM{log}.M0MASE = ZUMA.MAMASE".format(log=log_table),
        
        # participation
        "ZUGS": "SELECT ZUGS{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZUGS{log} INNER JOIN Genius.ZUMA ".format(log=log_table, extra_columns=select_columns) +
	                "ON ZUGS{log}.GSMANU = ZUMA.MAMANU AND ZUGS{log}.GSMASE = ZUMA.MAMASE".format(log=log_table),
        "ZUGP": "SELECT ZUGP{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZUGP{log} INNER JOIN Genius.ZUGS ".format(log=log_table, extra_columns=select_columns) +
	                "ON ZUGP{log}.GPGSGN  = ZUGS.GSGSGN INNER JOIN Genius.ZUMA ".format(log=log_table) +
                    "ON ZUGS.GSMANU = ZUMA.MAMANU AND ZUGS.GSMASE = ZUMA.MAMASE",
        "ZUSP": "SELECT ZUSP{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZUSP{log} INNER JOIN Genius.ZUGS ".format(log=log_table, extra_columns=select_columns) +
	                "ON ZUSP{log}.SPGSGN = ZUGS.GSGSGN INNER JOIN Genius.ZUMA ".format(log=log_table) +
	                "ON ZUGS.GSMANU = ZUMA.MAMANU AND ZUGS.GSMASE = ZUMA.MAMASE",

        #new_additions_2022
        "ZUDG": "SELECT ZUDG{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZUDG{log} INNER JOIN Genius.ZUMA ".format(log=log_table, extra_columns=select_columns) +
	                "ON ZUDG{log}.DGMANU = ZUMA.MAMANU AND ZUDG{log}.DGMASE = ZUMA.MAMASE".format(log=log_table),
        "ZUDV": "SELECT ZUDV{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZUDV{log} INNER JOIN Genius.ZUMA ".format(log=log_table, extra_columns=select_columns) +
                    "ON ZUDV{log}.DVMANU = ZUMA.MAMANU AND ZUDV{log}.DVMASE = ZUMA.MAMASE".format(log=log_table),
        #"ZKT8": "SELECT DISTINCT ZKT8{log}.*{extra_columns} FROM Genius.ZKT8{log} INNER JOIN Genius.ZUMA ".format(log=log_table, extra_columns=select_columns) +
        #            "ON ZKT8{log}.T8MABN = ZUMA.MAMABN".format(log=log_table),
        "DDEY": "SELECT DDEY{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.DDEY{log} INNER JOIN Genius.ZUMA ".format(log=log_table, extra_columns=select_columns) +
                    "ON DDEY{log}.EYAOCD = ZUMA.MAPORF".format(log=log_table),
        "ZUEL": "SELECT ZUEL{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZUEL{log} INNER JOIN Genius.ZUMA ".format(log=log_table, extra_columns=select_columns) +
                    "ON ZUEL{log}.ELMANU = ZUMA.MAMANU AND ZUEL{log}.ELMASE = ZUMA.MAMASE".format(log=log_table),
        "ZUD0": "SELECT ZUD0{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZUD0{log} INNER JOIN Genius.ZUMA ".format(log=log_table, extra_columns=select_columns) +
                    "ON ZUD0{log}.D0MANU = ZUMA.MAMANU AND ZUD0{log}.D0MASE = ZUMA.MAMASE".format(log=log_table),
        "ZUME": "SELECT ZUME{log}.*,ZUMA.MACNCD AS CompanyCode{extra_columns} FROM Genius.ZUME{log} INNER JOIN Genius.ZUMA ".format(log=log_table, extra_columns=select_columns) +
                    "ON ZUME{log}.MEMANU = ZUMA.MAMANU AND ZUME{log}.MEMASE = ZUMA.MAMASE".format(log=log_table),

        #No Filter
        "ZACB": "SELECT ZACB{log}.* FROM Genius.ZACB{log}".format(log=log_table),
        "ZHAA": "SELECT ZHAA{log}.* FROM Genius.ZHAA{log}".format(log=log_table),
        "ZHDP": "SELECT ZHDP{log}.* FROM Genius.ZHDP{log}".format(log=log_table),
        "ZHKT": "SELECT ZHKT{log}.* FROM Genius.ZHKT{log}".format(log=log_table),
        "ZABL": "SELECT ZABL{log}.*,ZABL{log}.BLCNCD AS CompanyCode FROM Genius.ZABL{log}".format(log=log_table),
        "ZHRB": "SELECT ZHRB{log}.* FROM Genius.ZHRB{log}".format(log=log_table),
        "ZHC1": "SELECT ZHC1{log}.* FROM Genius.ZHC1{log}".format(log=log_table),
        "ZHC2": "SELECT ZHC2{log}.* FROM Genius.ZHC2{log}".format(log=log_table),
        "ZHC3": "SELECT ZHC3{log}.* FROM Genius.ZHC3{log}".format(log=log_table),
        "ZSBU": "SELECT ZSBU{log}.*,ZSBU{log}.BUCNCD AS CompanyCode FROM Genius.ZSBU{log}".format(log=log_table),
        "ZPKS": "SELECT ZPKS{log}.* FROM Genius.ZPKS{log}".format(log=log_table),
        "ZHRT": "SELECT ZHRT{log}.* FROM Genius.ZHRT{log}".format(log=log_table),
        "ZKFO": "SELECT ZKFO{log}.* FROM Genius.ZKFO{log}".format(log=log_table),
        "ZACJ": "SELECT ZACJ{log}.* FROM Genius.ZACJ{log}".format(log=log_table),
        "ZUGK": "SELECT ZUGK{log}.* FROM Genius.ZUGK{log}".format(log=log_table),
        "ZUEV": "SELECT ZUEV{log}.* FROM Genius.ZUEV{log}".format(log=log_table),
        "ZHAV": "SELECT ZHAV{log}.* FROM Genius.ZHAV{log}".format(log=log_table),
        "ZHLV": "SELECT ZHLV{log}.* FROM Genius.ZHLV{log}".format(log=log_table),
        "ZHRY": "SELECT ZHRY{log}.* FROM Genius.ZHRY{log}".format(log=log_table),
        "ZHC4": "SELECT ZHC4{log}.* FROM Genius.ZHC4{log}".format(log=log_table),
        "ZNN8": "SELECT ZNN8{log}.* FROM Genius.ZNN8{log}".format(log=log_table),
        "ZPKC": "SELECT ZPKC{log}.* FROM Genius.ZPKC{log}".format(log=log_table),
        "ZPKL": "SELECT ZPKL{log}.* FROM Genius.ZPKL{log}".format(log=log_table),
        "ZPKN": "SELECT ZPKN{log}.* FROM Genius.ZPKN{log}".format(log=log_table),
        "ZUIE": "SELECT ZUIE{log}.* FROM Genius.ZUIE{log}".format(log=log_table),
        "ZUIF": "SELECT ZUIF{log}.* FROM Genius.ZUIF{log}".format(log=log_table),
        "ZUMK": "SELECT ZUMK{log}.* FROM Genius.ZUMK{log}".format(log=log_table),
        "ZNEU": "SELECT ZNEU{log}.* FROM Genius.ZNEU{log}".format(log=log_table),
        "ZHLH": "SELECT ZHLH{log}.* FROM Genius.ZHLH{log}".format(log=log_table),
        "ZUMY": "SELECT ZUMY{log}.* FROM Genius.ZUMY{log}".format(log=log_table),
        "ZHMJ": "SELECT ZHMJ{log}.* FROM Genius.ZHMJ{log}".format(log=log_table),        
        "ZHET": "SELECT ZHET{log}.* FROM Genius.ZHET{log}".format(log=log_table), 
        "ZKT8": "SELECT ZKT8{log}.* FROM Genius.ZKT8{log}".format(log=log_table), 
        "ZHMN": "SELECT ZHMN{log}.* FROM Genius.ZHMN{log}".format(log=log_table),

        #FullLoad
        #Set of columns required for the current process; Different approach Map.FXRates_Genius, Map.GenericColumnNames_Genius are not CDC tables;
        #Do not contains required columns;
        "FXRates": "SELECT *, GETDATE() as LastUpdatedDate, NULL AS header_change_seq FROM Map.FXRates_Genius",
        "GenericColumnNames": "SELECT *, GETDATE() as LastUpdatedDate, NULL AS header_change_seq FROM Map.GenericColumnNames_Genius",

        #RI Policies
        "COVERS": "SELECT ZUMA{log}.*,ZUMA{log}.MACNCD AS CompanyCode FROM GENIUS.ZUMA{log} ".format(log=log_table),
        "COVERS_ZURI": "SELECT RIMANU,RIMASE,RIRIMN,RIRIMS FROM GENIUS.ZURI{log} ".format(log=log_table),
    }
    query = switcher.get(tablename)
    query_filter = query + " {}".format(
        get_genius_filter(tablename, isfullload, table_cdc_upper_boundary, zuma_cdc_upper_boundary)
        if filter_change_filter is None
        else FilterChangeQuery().get_where_clause(**filter_change_filter)
    )
    if isfullload and tablename in constants.genius_partition_tables:
        query_filter = "(" + query_filter


    if add_missing_policies is not None and is_incremental:
        if tablename == "ZUMA":
            query_filter += " OR CONCAT(ZUMA{log}.MAMANU, ZUMA{log}.MAMASE) IN ({pols})".format(log=log_table, pols=add_missing_policies)
        elif tablename not in constants.ODS_Genius_Staight_Pull_Tables and tablename not in constants.Genius_ZUMA_orphan_tables:
            query_filter += " OR CONCAT(ZUMA.MAMANU, ZUMA.MAMASE) IN ({pols})".format(pols=add_missing_policies)

    return query_filter


def get_name_address_query(table_name):
    zuni_min_cdc = read_dynamodb_controlkey("0", "ZUNI")
    zuni_max_cdc = read_dynamodb_controlkey("1", "ZUNI")

    query = name_address_dict.get(table_name)
    if query is None:
        raise ValueError(f"Method not implemented for table: {table_name}")

    query += f""" {get_lsm_filter_sql()}
AND ZUNI_log.header_change_seq > '{zuni_min_cdc}' AND ZUNI_log.header_change_seq <= '{zuni_max_cdc}'"""

    return query


class FilterChangeInvalidFilterError(Exception):
    pass


class FilterChangeQuery:
    @staticmethod
    def is_not_valid_query(**kwargs: Dict[str, List]):
        return all(map(lambda tables: len(tables) == 0, kwargs.values()))

    def add_companies(self, companies: List[str]) -> str:
        return f"ZUMA.MACNCD IN {get_sql_in(companies)}"

    def add_products(self, products: List[str]) -> str:
        return f"ZUMA.MAMAPC IN {get_sql_in(products)}"

    def add_departments(self, departments: List[str]) -> str:
        return f"ZUMA.MADPCD IN {get_sql_in(departments)}"

    def add_branches(self, branches: List[str]) -> str:
        return f"ZUMA.MAMABN IN {get_sql_in(branches)}"

    def get_where_clause(self, **kwargs: Dict[str, List]) -> str:
        return "WHERE ZUMA.MAMAPC = 'TPR' AND ZUMA.MACNCD in ('III','ISIC')"

        if self.is_not_valid_query(**kwargs):
            raise FilterChangeInvalidFilterError("A filter must be applied for the filter change")

        return f"""WHERE ({
            " OR ".join(
                [
                    getattr(self, f"add_{_filter}")(tables)
                    for _filter, tables in kwargs.items()
                    if tables
                ]
            )})"""
