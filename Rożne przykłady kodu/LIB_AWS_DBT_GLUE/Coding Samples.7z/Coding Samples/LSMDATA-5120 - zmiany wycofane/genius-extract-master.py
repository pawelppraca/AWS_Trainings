"""
***************************************************************************
**
** File              : genius-extract-master.py
** Version           : $Revision: 01.00.00 $
** Description       :
**
** Read the Master keys for LSM policies from ZUMA_Log in Genius RDS and
** store them in dynamo masterlog table
**
** Called by  : None
**
** Parameters:
** In	: None
**
***************************************************************************
** Change History
** Revision:		Date:      Author:					Description:
** ----------		---------- ----------------------	---------------------------
** Version 01.00.00 12/06/2020 Priyanka L   			Initial version
** Version 01.00.01 24/06/2020 Surya Patnaik   			Add DynamoDB code to connect and build master table
** Version 01.00.02 16/07/2020 Surya Patnaik   			Enhance Master load job for both incremental and full load
** Version 01.00.03 21/09/2020 Surya Patnaik   			Add logic to trim spaces from source dataframe
** Version 01.00.03 26/02/2021 Priyanka L   			Reformated Code
** Version 01.00.04 20/06/2024 Pawel Parasyn   			LSMDATA-5120 - NonLSM Reinsurance Policies to LSM Policies (incremental only)
***************************************************************************
"""

import sys
import logging
import constants


from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.dynamicframe import DynamicFrame
from awsglue.job import Job
from pyspark.sql.functions import lit, concat, col, max as max_, when
from datetime import datetime as dt
from extract_utils import SparkExtractor


from genius_get_lookups import get_unique_records
from genius_query_generator import get_geniusquery, filter_zuma
from sns_error_notification_funcs import send_error_notification
from utility_funcs import (
    get_dataframe,
    write_data_frame_to_s3,
    log_etl,
    rename_policymasterfile,
)
from set_job_run_type import check_is_full_load, update_job_type
from lsm_dp_dynamo_functions import (
    get_dynamo_lookup,
    update_dynamodb_batch_masterkeys,
)

args = getResolvedOptions(
    sys.argv,
    [
        "JOB_NAME",
        "DB_NAME",
        "SOURCE_CONNECTION",
        "MISSING_POLICIES",
        "AWS_REGION",
        "ENVIRONMENT",
        "ACCOUNT_ID",
    ],
)
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# Logging Setup
MSG_FORMAT = "%(asctime)s %(levelname)s %(name)s: %(message)s"
DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S"
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT, level=logging.INFO)

region_name = args["AWS_REGION"]
db_name = args["DB_NAME"]
connection_name = args["SOURCE_CONNECTION"]
missing_policies_string = args["MISSING_POLICIES"]
account_id = args["ACCOUNT_ID"]

if missing_policies_string.lower() == "none":
    missing_policies_list = None
else:
    missing_policies_list = ",".join(
        f"'{i}'" for i in missing_policies_string.split(",")
    ).replace(" ", "")

app_env = args["ENVIRONMENT"]
dynamo_table = f"{constants.PolicyDynamoTableName}-{app_env}"
table_name = "ZUMA"

cover_products = ["FAC", "QS", "SUR", "XSL", "FXL", "QS2", "QS3"] #The same code like in genius_query_generator.py in filters

def get_master_lookup(df_source):
    # Get Master lookup keys for Incremental
    df_lookupkeys = df_source.select(
        concat(df_source.MAMANU, df_source.MAMASE).alias("pk")
    )
    df_master_keys = get_dynamo_lookup("1", df_lookupkeys, dynamo_table)
    df_master_keys.createOrReplaceTempView("df_lookup_keys")


def write_valid_keys_to_dynamo(df_source):
    df_lsmmaster = df_source.select(
        concat("MAMANU", "MAMASE").alias("pk"),
        col("LastUpdatedDate").alias("last_updated"),
        col("MACNCD").alias("company_code"),
        col("MAMAPC").alias("product_code"),
        lit("1").alias("isvalid"),
    )
    if df_lsmmaster.count() > 0:
        glueContext.write_dynamic_frame_from_options(
            frame=DynamicFrame.fromDF(df_lsmmaster, glueContext, "lsm_master"),
            connection_type="dynamodb",
            connection_options={
                "dynamodb.output.tableName": dynamo_table,
                "dynamodb.throughput.write.percent": "1.0",
            },
        )


def update_dynamo_non_lsm(df_incremental_nonlsm):
    get_master_lookup(df_incremental_nonlsm)
    df_nonlsm_updates = df_incremental_nonlsm.filter(
        df_incremental_nonlsm.header_change_oper == "U"
    )
    df_nonlsm_updates.createOrReplaceTempView("df_nonlsm_updates")
    df_incremental_shift = spark.sql(
        "SELECT u.* FROM df_nonlsm_updates u INNER JOIN df_lookup_keys k ON concat(u.MAMANU, u.MAMASE) = k.pk"
    )
    df_keys = df_incremental_shift.select(
        concat("MAMANU", "MAMASE").alias("pk"),
        col("LastUpdatedDate").alias("last_updated"),
        col("MACNCD").alias("company_code"),
        col("MAMAPC").alias("product_code"),
        lit("0").alias("isvalid"),
    )
    df_keys_count = df_keys.count()
    logging.info("Number of shift keys updated: {}".format(df_keys_count))
    if df_keys_count > 0:
        update_dynamodb_batch_masterkeys(dynamo_table, df_keys)
    return df_incremental_shift


def update_dynamo_keys_csv():
    df_policylookup = glueContext.create_dynamic_frame.from_options(
        connection_type="dynamodb",
        connection_options={
            "dynamodb.input.tableName": dynamo_table,
            "dynamodb.throughput.read.percent": "1.0",
            "dynamodb.splits": "96",
        },
    )
    df_deltaunion = df_policylookup.toDF().repartition(1)
    master_file_path = (
        f"{constants.UtilityBucket}-{app_env}/{constants.MasterFileFolder}"
    )
    df_deltaunion.write.mode("overwrite").option("header", "true").csv(master_file_path)
    rename_policymasterfile(f"lsm-dp-utility-eu-{app_env}")


try:
    is_full_load = check_is_full_load(constants.ddb_jobruntype_pk_value, table_name)
    source_jdbc_conf = glueContext.extract_jdbc_conf(connection_name)

    zuma_cdc_upper_boundary = None
    if not is_full_load:
        cdc_query = "SELECT MAX(ZUMA_log.header_change_seq) AS zuma_cdc_upper_boundary FROM Genius.ZUMA_log"
        df_cdc = (
            spark.read.format("jdbc")
            .option("url", f"{source_jdbc_conf.get('url')};database={db_name}")
            .option("driver", constants.SQL_SERVER_DRIVER)
            .option("query", cdc_query)
            .option("user", source_jdbc_conf.get("user"))
            .option("password", source_jdbc_conf.get("password"))
            .load()
        )
        zuma_cdc_upper_boundary = df_cdc.first().zuma_cdc_upper_boundary

    zuma_query = get_geniusquery(
        table_name,
        is_full_load,
        add_missing_policies=missing_policies_list,
        zuma_cdc_upper_boundary=zuma_cdc_upper_boundary,
    )
    df_source = get_dataframe(
        table_name=table_name,
        source_jdbc_conf=source_jdbc_conf,
        query=zuma_query,
        is_full_load=is_full_load,
    )

    # LSMDATA-5120 - Adding Reinsurance NonLSM Policies
    # Collect data ZUMA for Covers for Reinsurance Policies
    extractor = SparkExtractor(spark, source_jdbc_conf, db_name)

    table = "COVERS"
    covers_query = get_geniusquery(
        tablename = table,
        isfullload = is_full_load,
        add_missing_policies=missing_policies_list,
        zuma_cdc_upper_boundary=zuma_cdc_upper_boundary,
    )

    #Create Dataframe
    df_covers = get_dataframe(
        table_name=table,
        source_jdbc_conf=source_jdbc_conf,
        query=covers_query,
        is_full_load=is_full_load,
    ) 
    
    # Collect ZURI Data for Reinsurance Policies
    table = "COVERS_ZURI"
    covers_zuri_query = get_geniusquery(
        tablename = table,
        isfullload = is_full_load,        
        add_missing_policies=missing_policies_list,
        zuma_cdc_upper_boundary=zuma_cdc_upper_boundary,
    )
    
    #Create Dataframe
    df_covers_zuri = get_dataframe(
        table_name=table,
        source_jdbc_conf=source_jdbc_conf,
        query=covers_zuri_query,
        is_full_load=is_full_load,
    )

    # ENDOF - LSMDATA-5120 - Adding Reinsurance NonLSM Policies

    if is_full_load:
        df_maxtimestamp = (
            df_source.withColumn(
                "LastUpdatedDate", col("LastUpdatedDate").cast("timestamp")
            )
            .groupby()
            .agg(max_("LastUpdatedDate"))
        )
        max_last_updated_date = df_maxtimestamp.first()["max(LastUpdatedDate)"]
        cdc_query_full = f"SELECT MIN(ZUMA_log.header_change_seq) AS table_header_change_seq FROM Genius.ZUMA_log WHERE LastUpdatedDate = '{max_last_updated_date}'"
        df_cdc_full = (
            spark.read.format("jdbc")
            .option("url", f"{source_jdbc_conf.get('url')};database={db_name}")
            .option("driver", constants.SQL_SERVER_DRIVER)
            .option("query", cdc_query_full)
            .option("user", source_jdbc_conf.get("user"))
            .option("password", source_jdbc_conf.get("password"))
            .load()
        )
        table_header_change_seq = df_cdc_full.first().table_header_change_seq

        write_data_frame_to_s3(glueContext, df_source, table_name, app_env)
        write_valid_keys_to_dynamo(df_source)
        update_dynamo_keys_csv()
        update_job_type(constants.ddb_jobruntype_pk_value, table_name, "0")
        log_etl(table_header_change_seq, table_name, is_full_load)
    else:
        df_incremental_lsm_no_covers = filter_zuma(df_source)
        df_incremental_nonlsm = df_source.subtract(df_incremental_lsm_no_covers)

        # LSMDATA-5120 - Adding Reinsurance NonLSM Policies
        # Collect Reinsurance Policies base on ZURI for selected ProductCodes related to exited LSM Policies
        df_ri_policies = (
                df_incremental_lsm_no_covers.join(
                    df_covers_zuri,
                    ((df_covers_zuri.RIMANU == df_incremental_lsm_no_covers.MAMANU) & (df_covers_zuri.RIMASE == df_incremental_lsm_no_covers.MAMASE)) ,
                    how="inner",
                ).join(
                    df_covers,
                    ((df_covers_zuri.RIRIMN == df_covers.MAMANU) & (df_covers_zuri.RIRIMS == df_covers.MAMASE)) ,
                    how="inner",
                ).filter(
                    df_covers.MAMAPC.isin(cover_products) # Covers product Filter
                ).select(
                    df_covers["*"]
                )
        )

        # Collect only nonExisted in LSM_Policies (Reinsurance only)
        df_ri_policies_non_exists_in_lsm = (
            df_ri_policies.join(
                df_incremental_lsm_no_covers,
                ((df_ri_policies.MAMANU == df_incremental_lsm_no_covers.MAMANU) & (df_ri_policies.MAMASE == df_incremental_lsm_no_covers.MAMASE)),
                how="leftsemi",
            ).select(
                df_ri_policies["*"]
            )    
        )
        
        # Add RI Policies to list 
        df_incremental_lsm = df_incremental_lsm_no_covers.union(df_ri_policies_non_exists_in_lsm).distinct()
        
        # ENDOF LSMDATA-5120
        
        df_shifts = update_dynamo_non_lsm(df_incremental_nonlsm).withColumn(
            "header_change_oper", lit("D")
        )

        # get unique records for dynamo
        df_dynamo_incremental_unique = get_unique_records(
            df_incremental_lsm, table_name
        )
        df_dynamo_incremental = df_dynamo_incremental_unique.withColumn(
            "isvalid",
            when(
                df_dynamo_incremental_unique.header_change_oper != "D", lit("1")
            ).otherwise(lit("0")),
        )

        df_dynamo_incremental = df_dynamo_incremental.select(
            concat("MAMANU", "MAMASE").alias("pk"),
            col("LastUpdatedDate").alias("last_updated"),
            col("MACNCD").alias("company_code"),
            col("MAMAPC").alias("product_code"),
            col("isvalid"),
        )

        if len(df_dynamo_incremental.head(1)) > 0:
            glueContext.write_dynamic_frame_from_options(
                frame=DynamicFrame.fromDF(
                    df_dynamo_incremental, glueContext, "zuma_keys"
                ),
                connection_type="dynamodb",
                connection_options={
                    "dynamodb.output.tableName": dynamo_table,
                    "dynamodb.throughput.write.percent": "1.0",
                },
            )

        # write incrementals and shifts to s3
        df_incremental_lsm = df_incremental_lsm.unionByName(df_shifts)

        # Get Max Timestampand update ETL Logs
        if len(df_incremental_lsm.head(1)) > 0:
            df_cdc_upper_boundary = df_incremental_lsm.groupby().agg(
                max_("header_change_seq")
            )
            max_header_change_seq = df_cdc_upper_boundary.first()[
                "max(header_change_seq)"
            ]

            glueContext.write_dynamic_frame.from_options(
                frame=DynamicFrame.fromDF(df_incremental_lsm, glueContext, table_name),
                connection_type="s3",
                connection_options={
                    "path": f"{constants.IngestionBucket}-{app_env}/{constants.GeniusDestinationFolder}{table_name}/"
                },
                format="parquet",
            )

            update_dynamo_keys_csv()

            log_etl(max_header_change_seq, table_name)

except Exception as e:
    send_error_notification(
        "POLICY",
        args["JOB_NAME"],
        str(type(e)),
        str(e),
        region_name,
        app_env,
        account_id,
    )
    raise e

job.commit()
