# Usuwanie istniejącej sesji Glue Spark
aws glue delete-session --id lsm-dp-f97e2c9d-2906-4748-88d1-27aa0f397583 --profile superuser-test