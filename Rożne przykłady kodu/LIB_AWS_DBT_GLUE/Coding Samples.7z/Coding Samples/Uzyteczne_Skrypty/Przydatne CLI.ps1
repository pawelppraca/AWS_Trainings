
Na podstawie dokumentacji
https://libertymutual.atlassian.net/wiki/spaces/GSLITMI/pages/372574784/Useful+CLI+Commands

###############################################
### URUCHAMIAJ W CMD ######
###############################################

# Zatrzymywanie uruchomionej Step Function
#-------------------------------------------
aws stepfunctions stop-execution --execution-arn <<EXECUTION ARN>> --profile usertest

#<<EXECUTION ARN>> ARN skopiowanie z konkretnego uruchomienia funkcji np lsm-dp-etl-test (patrz: http://tinyurl.com/27bf2v86)
#przykład: - arn:aws:states:eu-west-1:866525145675:execution:lsm-dp-etl-test:genius_2024-02-05-11-28-41

## UWAGA!!! Credential dla Production może pobrać: Patryk, Irek, Sławek - z Cloudforge lsm-dp-user
# https://console.forge.lmig.com/artifact/9fac8b17-54c5-471c-a6b1-3575de210408/secrets

# Całe polecenie
aws stepfunctions stop-execution --execution-arn arn:aws:states:eu-west-1:866525145675:execution:lsm-dp-etl-test:genius_2024-02-05-11-28-41 --profile usertest

aws stepfunctions stop-execution --execution-arn arn:aws:states:eu-west-1:866525145675:execution:lsm-dp-extract-qa:etl_genius_2024-03-27-11-00-12 --profile userqa

aws stepfunctions stop-execution --execution-arn arn:aws:states:eu-west-1:866525145675:execution:lsm-dp-etl-qa:genius_2024-08-12-14-01-34 --profile userqa


aws stepfunctions stop-execution --execution-arn arn:aws:states:eu-west-1:238940011766:execution:lsm-dp-extract-production:etl_genius_2024-09-04-12-00-13 --profile user-production

aws stepfunctions stop-execution --execution-arn arn:aws:states:eu-west-1:238940011766:execution:lsm-dp-extract-production:etl_genius_2024-08-05-20-00-16 --profile user-admin-production


## Zatrzymanie APAC:
aws stepfunctions stop-execution --execution-arn  arn:aws:states:eu-west-1:238940011766:execution:lsm-dp-extract-production:etl_genius_2024-09-09-20-00-17   --profile user-production

#============================================================================================================================
# Uruchamianie Step Function - Ładowanie GENIUSa
#============================================================================================================================

# Uruchomienie całego GENIUS ETL
# SIT
aws lambda invoke --function-name lsm-dp-start-step-function-test --invocation-type Event --payload "{\"source\":\"lmre\",\"phase\":\"etl\",\"APACGeniusLoad\":\"\"}" --cli-binary-format raw-in-base64-out output.txt --profile usertest
# UAT
aws lambda invoke --function-name lsm-dp-start-step-function-qa --invocation-type Event --payload "{\"source\":\"genius\",\"phase\":\"etl\",\"APACGeniusLoad\":\"_APAC\"}" --cli-binary-format raw-in-base64-out output.txt --profile userqa


#PROD - START GENIUS ETL
aws lambda invoke --function-name lsm-dp-start-step-function-prod --invocation-type Event --payload "{\"source\":\"genius\",\"phase\":\"etl\",\"APACGeniusLoad\":0}" --cli-binary-format raw-in-base64-out output.txt --profile user-admin-production


# Uruchomienie Extraktu Geniusa
aws lambda invoke --function-name lsm-dp-start-step-function-test --invocation-type Event --payload "{\"source\":\"genius\",\"phase\":\"extract\"}" --cli-binary-format raw-in-base64-out output.txt --profile usertest


# RDS_Load z S3
#Development
aws lambda invoke --function-name lsm-dp-start-step-function-test --invocation-type Event --payload "{\"source\":\"genius\",\"phase\":\"rds-load\"}" --cli-binary-format raw-in-base64-out output.txt --profile usertest
#Staging
aws lambda invoke --function-name lsm-dp-start-step-function-test --invocation-type Event --payload "{\"source\":\"genius\",\"phase\":\"rds-load\"}" --cli-binary-format raw-in-base64-out output.txt --profile userqa





# Uruchamianie tylko DWH_LOAD z APAC 
#Development
aws lambda invoke --function-name lsm-dp-start-step-function-test --invocation-type Event --payload "{\"source\":\"genius\",\"phase\":\"dwh_load\",\"APACGeniusLoad\":1}" --cli-binary-format raw-in-base64-out output.txt --profile usertest

#Staging
aws lambda invoke --function-name lsm-dp-start-step-function-test --invocation-type Event --payload "{\"source\":\"genius\",\"phase\":\"dwh_load\",\"APACGeniusLoad\":1}" --cli-binary-format raw-in-base64-out output.txt --profile userqa


#pobranie plików z S3
aws s3 cp <<s3path>> "<<localfilepath>>"  

aws s3 cp s3://lsm-dp-ingestion-eu-test/Archive/Genius/ZUMA/part-00000-4986f511-10b2-4c12-a9c5-aed93fed833d-c000.snappy.parquet "C:\Temp\AWS_CLI"

LMRE
aws s3 cp s3://lsm-dp-analysis-eu-qa/daily_table_record_count/part-00000-ed3e524b-982b-4a69-ae1c-627e3ab70050-c000.snappy.parquet . --profile userqa

aws s3 cp s3://lsm-dp-ingestion-eu-qa/LMRE/CLAIMS/part-00000-b5f4cc88-b652-48ff-88ed-12a5f42a1b31-c000.snappy.parquet . --profile userqa

# Pobranie pliku Parquet do folderu z przeglądem w VSC i zmianą nazwy
aws s3 cp s3://lsm-dp-ingestion-eu-test/Genius/ZUMA/To_Process/part-00000-90a50c2e-9477-4153-860a-30815895f395-c000.snappy.parquet "C:\Users\n1601471\OneDrive - Liberty Mutual\Documents\Visual Studio Code\Coding Samples\Parquet\Genius\ZUMA_SIT_ONP_20240624.parquet" --profile usertest

aws s3 cp s3://lsm-dp-ingestion-eu-test/Genius/ZUMA_To_Process/part-00000-f356802c-8080-4ac3-848c-9b1e92d82cd4-c000.snappy.parquet "C:\Users\n1601471\OneDrive - Liberty Mutual\Documents\Visual Studio Code\Coding Samples\Parquet\Genius\RI_Test_20240628_2.parquet" --profile usertest

aws s3 cp s3://lsm-dp-ingestion-eu-qa/Genius/ZUMA/part-00000-12130dad-2b65-4933-b3fb-7046db7d2179-c000.snappy.parquet "C:\Users\n1601471\OneDrive - Liberty Mutual\Documents\Visual Studio Code\Coding Samples\Parquet\Genius" --profile userqa

aws s3 cp s3://lsm-dp-ingestion-eu-test/Archive/Genius/ZUMA/part-00000-4986f511-10b2-4c12-a9c5-aed93fed833d-c000.snappy.parquet "C:\Temp\AWS_CLI"

aws s3 cp s3://lsm-dp-ingestion-eu-test/sparklogs/jr_60c792f8cb5aaba343ed71204280b948bc6293708e1a9bf11aa5a96d33716966  "C:\Temp\AWS_CLI"

# Pobranie pliku S3 z Produckji
aws s3 cp  s3://lsm-dp-ingestion-eu-production/Archive/Genius/FXRates/part-00000-7a9b40a0-65bd-4e24-8e9e-8f311da2b977-c000.snappy.parquet "C:\Temp\AWS_CLI" --profile userproduction

aws s3 cp  s3://lsm-dp-ingestion-eu-test/sparklogs/jr_e13ad399a75b8b3f422631ec29bb7e2512c644f955d3bce92b3c45f19f65d968 "C:\Temp\AWS_CLI" --profile usertest


#Przeladowanie tabelki
#Wyczyszczenie tabelek i plików S3
aws glue start-job-run --job-name lsm-dp-reset-table-fullload-test --arguments "{\"--TABLE_NAME\":\"DDEY\", \"--MAP_TABLE\":\"Map_DiaryEntryDetails_DDEY\"}" --profile usertest

#Ręczne uruchomienie Loada
aws glue start-job-run --job-name lsm-dp-genius-extract-name-address-company-test --arguments "{\"--GROUP\":\"cleardown\"}" --profile usertest


#Ręczne zatrymanie Glue JOBA
aws glue batch-stop-job-run --job-name "lsm-dp-genius-extract-statistics-posting-qa" --job-run-id "jr_5587b3ba95857febfe7685efa117f939a13ca5539eaceda438b9980cd40a74c5" --profile userqa

aws glue stop-workflow-run --name <workflow-name> --run-id <run-id> # to nie działa, bo nie ma uprawnieniń do stop-workflow-run



#Kopiowanie
aws s3 cp s3://lsm-dp-utility-eu-test/Master/MasterKeys.csv "C:\Temp\AWS_CLI" --profile usertest


# Odpytanie DynamoDB
aws dynamodb execute-statement --statement \" SELECT top 10 * FROM lsm-dp-policy-lookup-qa \" ---profile userqa

# Utworzenie folderu S3
aws s3api put-object --bucket lsm-dp-ingestion-eu-test --key Genius/ZUMA/To_Process --profile usertest


#Usuniecie folderu
aws s3 rm s3://lsm-dp-ingestion-eu-test/Genius/ZUMA/To_Process  --profile usertest

# przenoszenie plikow

aws s3 mv <bucket_source> <backet_target> --recursive --exclude "*" --include "patern"

# Przednoszenie pliku w ramach jednego S3 pomiędzy folderami
aws s3 mv s3://lsm-dp-ingestion-eu-test/Genius/ZUMA/ s3://lsm-dp-ingestion-eu-test/Genius/ZUMA_To_Process/ --recursive --exclude "*" --include "*679aca68-8b2d-4126-8930-a0346f7542e8-c000.snappy.parquet" --profile usertest  # 24.06.2024 10:00 
aws s3 mv s3://lsm-dp-ingestion-eu-test/Genius/ZUMA/ s3://lsm-dp-ingestion-eu-test/Genius/ZUMA_To_Process/ --recursive --exclude "*" --include "*8c8e5187-5f82-4f26-942d-417250e40d18-c000.snappy.parquet" --profile usertest  # 23.06.2024 21:00
aws s3 mv s3://lsm-dp-ingestion-eu-test/Genius/ZUMA/ s3://lsm-dp-ingestion-eu-test/Genius/ZUMA_To_Process/ --recursive --exclude "*" --include "*0146b7f2-ad85-4fb8-befb-689570301e68-c000.snappy.parquet" --profile usertest  # 21.06.2024 21:00
aws s3 mv s3://lsm-dp-ingestion-eu-test/Genius/ZUMA/ s3://lsm-dp-ingestion-eu-test/Genius/ZUMA_To_Process/ --recursive --exclude "*" --include "*c91a8142-53f1-4cc4-af56-3fb643590842-c000.snappy.parquet" --profile usertest  # 21.06.2024 13:00

# Przednoszenie pliku w ramach jednego S3 pomiędzy folderami - odwrtonie do linijek wyżej
aws s3 mv s3://lsm-dp-ingestion-eu-test/Genius/ZUMA_To_Process/ s3://lsm-dp-ingestion-eu-test/Genius/ZUMA/ --recursive --exclude "*" --include "*c91a8142-53f1-4cc4-af56-3fb643590842-c000.snappy.parquet" --profile usertest  # 21.06.2024 13:00
aws s3 mv s3://lsm-dp-ingestion-eu-test/Genius/ZUMA_To_Process/ s3://lsm-dp-ingestion-eu-test/Genius/ZUMA/ --recursive --exclude "*" --include "*0146b7f2-ad85-4fb8-befb-689570301e68-c000.snappy.parquet" --profile usertest  # 21.06.2024 21:00
aws s3 mv s3://lsm-dp-ingestion-eu-test/Genius/ZUMA_To_Process/ s3://lsm-dp-ingestion-eu-test/Genius/ZUMA/ --recursive --exclude "*" --include "*8c8e5187-5f82-4f26-942d-417250e40d18-c000.snappy.parquet" --profile usertest  # 23.06.2024 21:00
aws s3 mv s3://lsm-dp-ingestion-eu-test/Genius/ZUMA_To_Process/ s3://lsm-dp-ingestion-eu-test/Genius/ZUMA/ --recursive --exclude "*" --include "*679aca68-8b2d-4126-8930-a0346f7542e8-c000.snappy.parquet" --profile usertest

#Usywanie plików

aws s3 rm s3://lsm-dp-ingestion-eu-test/Genius/ZUMA_To_Process/ --recursive --exclude "*" --include "*9be54a9d-9aad-4074-9500-e3e242771cb0-c000.snappy.parquet" --profile usertest


# SNS Subscription

aws sns subscribe --topic-arn arn:aws:sns:eu-west-1:866525145675:lsm-dp-stepfunction-sns-test --protocol email --notification-endpoint Pawel.Parasyn@liberty-it.co.uk --profile usertest

aws sns subscribe --topic-arn arn:aws:sns:eu-west-1:866525145675:lsm-dp-genius-sns-test --protocol email --notification-endpoint Pawel.Parasyn@liberty-it.co.uk --profile usertest


# Pobranie zawartości Roli

aws iam get-role --role-name LSM-DP-CloudTrail-Service-Role-production --profile user-production




#Copying CSV File
aws s3 cp s3://lsm-dp-utility-eu-test/Master/MasterKeys.csv "C:\Temp\AWS_CLI" --profile superuser-test

#Extracting data from Dynamo to txt file
aws dynamodb scan --table-name lsm-dp-cdc-log-test --output text --profile superuser-test >> C:\temp\AWS_CLI\lsm-dp-cdc-log-test.txt

aws dynamodb scan --table-name lsm-dp-zumascope-lookup-test --output text --profile superuser-test >> C:\temp\AWS_CLI\lsm-dp-zumascope-lookup-test.txt

aws dynamodb scan --table-name lsm-dp-policy-lookup-test --output text --profile superuser-test >> C:\temp\AWS_CLI\lsm-dp-policy-lookup-test.txt



# GRSI - Wczytanie pliku do Dataframe

# Utworzenie Bucketa
aws s3api create-bucket --bucket grsi-dp-dbt-pp-test --region eu-west-1 --profile superuser-test

# Utworzenie folderu S3
aws s3api put-object --bucket grsi-dp-ingestion-eu-test --key Genius/ZUMA/To_Process --profile usertest

# Utworzenie folderu S3
aws s3api put-object --bucket lsm-dp-ingestion-eu-test --key Genius/ZUMA_To_Process/test_temp --profile admin-user-test
aws s3api put-object --bucket lsm-dp-ingestion-eu-test --key /test_temp/ --profile admin-user-test

aws s3 rm s3://lsm-dp-ingestion-eu-test/test_temp/ --recursive --exclude "*" --include "test_temp" --profile admin-user-test


#kopiowanie pliku
aws s3 cp s3://lsm-dp-ingestion-eu-test/test_temp/part-00000-fa535fce-622c-46e6-9bc7-dd7399be9eda-c000.csv "C:\Temp\AWS_CLI" --profile admin-user-test

#Usuwanie pliku
aws s3 rm s3://lsm-dp-ingestion-eu-test/test_temp/ --recursive --exclude "*" --include "part-00000-870e1c31-6d4c-4559-8aa8-f2d4221c3256-c000.snappy.parquet " --profile admin-user-test

#Kopiowanie Parquet
aws s3 cp s3://lsm-dp-ingestion-eu-test/test_temp/coverage_row_counts/part-00000-98826f36-be88-4719-a419-fff8888c75b3-c000.snappy.parquet "C:\Users\n1601471\OneDrive - Liberty Mutual\Documents\Visual Studio Code\Coding Samples\Parquet\DBT_Results\coverage_row_counts" --profile admin-user-test
aws s3 cp s3://lsm-dp-ingestion-eu-test/test_temp/coverage_sums_deductible_amount/part-00000-8a2c69b5-21d9-4027-ba71-b6ede070b0ca-c000.snappy.parquet "C:\Users\n1601471\OneDrive - Liberty Mutual\Documents\Visual Studio Code\Coding Samples\Parquet\DBT_Results\coverage_sums_deductible_amount" --profile admin-user-test


# Usuwanie
aws s3 rm s3://lsm-dp-ingestion-eu-test/test_temp/coverage_row_counts/ --recursive --exclude "*" --include "part-00000-28216cdf-4b48-4536-a54f-980a4eeea91f-c000.snappy.parquet" --profile admin-user-test

aws s3 rm s3://lsm-dp-ingestion-eu-test/test_temp/coverage_sums_deductible_amount/ --recursive --exclude "*" --include "part-00000-2f42d1c3-72c5-467e-9b03-579b25422019-c000.snappy.parquet" --profile admin-user-test




