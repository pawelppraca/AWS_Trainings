import { config, grsiPrefix } from '@lmig/grsi-dp-shared-config-and-classes';
import { Aws, Duration } from 'aws-cdk-lib';
import { Role } from 'aws-cdk-lib/aws-iam';
import { Code, Function, LayerVersion, Runtime, Tracing } from 'aws-cdk-lib/aws-lambda';
import { NodejsFunction } from 'aws-cdk-lib/aws-lambda-nodejs';
import { ManagedPolicy, PolicyStatement } from 'aws-cdk-lib/aws-iam';
import { Queue, QueueAttributes } from 'aws-cdk-lib/aws-sqs';
import { Bucket } from 'aws-cdk-lib/aws-s3';
import { StackConfiguration } from 'bin/config';
import { Construct } from 'constructs';
import path = require('path');

export class TestingResources extends Construct {
    constructor(scope: Construct, id: string, stackConfig: StackConfiguration) {
        super(scope, id);

        const ingestionBucket = Bucket.fromBucketName(this, 'IngestionBucket', stackConfig.ingestionBucketName);

        const loadRole = Role.fromRoleName(this, 'load-role', stackConfig.ingestionLambdaRoleName);

        // AWS Managed layer for pandas
        const lambdaLayer = LayerVersion.fromLayerVersionArn(
            this,
            'pandas-layer',
            `arn:aws:lambda:${stackConfig.awsEnv.region}:336392948345:layer:AWSSDKPandas-Python311:4`,
        );

        // Note this integration test does not publish to our error notification topic;
        //   this is intentional.
        // If this test fails in Bamboo or running locally you will know as you should be watching it!
        //   Bamboo will visually show from red/green what the status is and GitHub will block
        //   block merging until it is resolved.
        // Emailing the team of an individuals development is noise and we only want to know about
        //   _real_ errors and exceptions emitted from the platform.

        new Function(this, 'integration-gest-load', {
            functionName: `${grsiPrefix}-integration-test-load-${stackConfig.regionEnv}`,
            runtime: Runtime.PYTHON_3_11,
            layers: [lambdaLayer],
            tracing: Tracing.ACTIVE,
            code: Code.fromAsset(path.join(__dirname, 'lambda/integration-test-load')),
            timeout: Duration.minutes(15),
            environment: {
                BUCKET_NAME: ingestionBucket.bucketName,
                FILE_MANIFEST_TABLE: stackConfig.fileManifestTableName,
                COLUMN_MAPPING_TABLE: [config.dynamoColumnMappingTableNamePrefix, config.regionEnv].join('-'),
                ORGANIZATION_ID: stackConfig.stackTags.organization_guid,
            },
            handler: 'integration_test_load.handler',
            role: loadRole,
        });

        const testingDeadLetterQueue = Queue.fromQueueArn(
            this,
            `unhappy-path-dead-letter-queue`,
            `arn:aws:sqs:${Aws.REGION}:${Aws.ACCOUNT_ID}:${stackConfig.testingDeadLetterQueueName}`,
        );

        const testUnhappyPathFunction = new NodejsFunction(this, 'testUnhappyPathFunction', {
            functionName: `${grsiPrefix}-unhappy-path-ingestion-alerting-test-${stackConfig.regionEnv}`,
            runtime: Runtime.NODEJS_18_X,
            memorySize: 128,
            timeout: Duration.minutes(2),
            entry: path.join(__dirname, 'lambda/unhappy-path-dlq/index.ts'),
            role: loadRole,
            tracing: Tracing.ACTIVE,
            environment: {
                BUCKET_NAME: ingestionBucket.bucketName,
                UNHAPPY_PATH_ALERTING_TEST_S3_KEY_PATH: stackConfig.unhappyPathIngestionAlertingTestS3KeyPath,
                TESTING_DEAD_LETTER_QUEUE_URL: testingDeadLetterQueue.queueUrl,
                COLUMN_MAPPING_TABLE: [config.dynamoColumnMappingTableNamePrefix, config.regionEnv].join('-'),
                ORGANIZATION_ID: stackConfig.stackTags.organization_guid,
                REDSHIFT_CLUSTER_NAME: `${stackConfig.grsiPrefix}-redshift-${stackConfig.regionEnv}`,
            },
        });
    }
}
