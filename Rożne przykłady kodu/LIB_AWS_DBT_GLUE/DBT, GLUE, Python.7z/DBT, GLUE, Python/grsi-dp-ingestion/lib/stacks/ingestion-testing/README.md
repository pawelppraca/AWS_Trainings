<h1 align="left">Integration Testing</h1>
<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->

- [Known Errors](#known-errors)
  - [Load failure](#load-failure)
  - [Cannot COPY into nonexistent table unhappy_path](#cannot-copy-into-nonexistent-table-unhappy_path)
    - [Schema / Spectrum Scan Error](#schema--spectrum-scan-error)
  - [S3 Keys with hyphens](#s3-keys-with-hyphens)
  - [S3 File with **missing** load_id](#s3-file-with-missing-load_id)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

## Known Errors

### Load failure

### Cannot COPY into nonexistent table unhappy_path

Table doesn't exist

#### Schema / Spectrum Scan Error

If the file schema is incorrect to the destination table you may see something like:

```text
"Error": "ERROR: Spectrum Scan Error\n  Detail: \n  -----------------------------------------------\n  error:  Spectrum Scan Error\n  code:      15007\n  context:   File 'https://urldefense.com/v3/__https://s3.us-east-1.amazonaws.com/grsi-dp-ingestion-us-development/test/integration_test/integration.parquet__;!!JJ-tOIoKdBzLSfV5jA!sPFBOb1f2v1VvvMns0Hrp6K26YG5c8KN-n93iMY0wNWUIpKhdhkp1FfUUEqpXKss3Df-x0JfvMLVoxRDfY6pMT0rcMlicHrtCcmOdw$ ' has an invalid version number.\n  query:     3467992\n  location:  dory_util.cpp:1579\n  process:   worker_thread [pid=15032]\n  -----------------------------------------------\n",
```
The email client wraps the bucket with `urldefense`, don't let that distract you; that won't appear in the AWS logs.

### S3 Keys with hyphens

A COPY send of this format containing a key as an underscore will throw a SQL syntax error. Table names should have underscores.

```text
COPY staging_test.unhappy-path
FROM 's3://grsi-dp-ingestion-us-development/test/unhappy-path/integration.parquet'
IAM_ROLE ''
FORMAT AS PARQUET            \n        
```

Example Error:

```text
"Error": "ERROR: syntax error at or near \"-\"\n  Position: 39",
```

### S3 File with **missing** load_id

Every object ingested should come with a load ID. Load IDs that are zero or negative integers are for testing. If there is no load ID it cannot be indexed in the manifest table which holds the record for all files ingested. The error message will look like the following:

```text
"errorMessage": "LoadID undefined",
```

