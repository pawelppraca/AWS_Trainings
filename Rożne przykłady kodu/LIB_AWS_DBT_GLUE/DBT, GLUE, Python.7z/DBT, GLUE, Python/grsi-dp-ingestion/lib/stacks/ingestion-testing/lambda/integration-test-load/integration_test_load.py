# Lambda function that will be responsible for the integration tests

import boto3
from botocore.exceptions import ClientError
from datetime import datetime
import json
import logging
from io import StringIO, BytesIO
import os
import pandas as pd
import pathlib
import sys
import threading
import time
from typing import Dict, Optional, Union, Callable
from urllib import parse
import uuid

# get env vars and default to dev if empty
MANIFEST_TABLE = os.getenv(
    "FILE_MANIFEST_TABLE", "grsi-dp-dynamodb-file-manifest-table-eu-development"
)
COLUMN_MAPPING_TABLE = os.getenv(
    "COLUMN_MAPPING_TABLE", "grsi-dp-column-order-table-eu-development"
)
BUCKET_NAME = os.getenv("BUCKET_NAME", "grsi-dp-ingestion-eu-development")
DESTINATION_S3_KEY = "staging_test/integration_test/integration_test.parquet"
S3_URI = f"s3://{BUCKET_NAME}/{DESTINATION_S3_KEY}"
ORGANIZATION_ID = os.getenv("ORGANIZATION_ID", "2326c977-2f8d-4d97-8f13-a7ca2fd5d5db")

logger = logging.getLogger()
logger.setLevel("INFO")


def handler(event, context):
    logger.info(f"event: {str(event)}")
    logger.info(f"context: {str(context)}")

    try:
        logger.info(f"Removing previous run's manifest entry to clear test state")
        manifest_table = boto3.resource("dynamodb").Table(MANIFEST_TABLE)
        manifest_table.delete_item(Key={"s3uri": S3_URI, "loadID": 0})

        current_datetime = datetime.now()
        current_date = get_date_str(current_datetime)
        logger.info(f"current_date: {current_date}")

        current_time = get_time_str(current_datetime)
        logger.info(f"current_time: {current_time}")

        uuid = generate_uuid()
        logger.info(f"generated_uuid: {uuid}")

        test_dataset = generate_test_dataset(
            date=current_date, time=current_time, uuid=uuid
        )

        # Add column mapping to dynamoDB
        column_mapping_table = boto3.resource("dynamodb").Table(COLUMN_MAPPING_TABLE)
        column_mapping_table.update_item(
            Key={"Table": "integration_test", "Schema": "staging_test"},
            UpdateExpression="set ColumnOrder = :co",
            ExpressionAttributeValues={":co": ", ".join(test_dataset.columns)},
        )

        parquet_buffer = BytesIO()
        test_dataset.to_parquet(parquet_buffer)

        logger.info(f"Upload/PUT integration test file: {S3_URI}")
        tags = {"load_id": "0", "organization_guid": ORGANIZATION_ID}
        boto3.client("s3").put_object(
            Body=parquet_buffer.getvalue(),
            Bucket=BUCKET_NAME,
            Key=DESTINATION_S3_KEY,
            Tagging=parse.urlencode(tags),
        )

        get_query_id_wait_time = 7
        logger.info(
            f"Sleep for {get_query_id_wait_time} seconds and check RedShiftDataAPI query ID from load lambda in manifest table"
        )
        time.sleep(get_query_id_wait_time)

        query_id = get_query_id(dynamodb_table=MANIFEST_TABLE)
        logger.info(f"Redshift query id: {query_id}")

        get_query_result_wait_time = 8
        logger.info(
            f"Sleep for {get_query_result_wait_time} to check COPY RedShiftDataAPI command result"
        )

        retry_count = 1
        retry_limit = 5
        while True:
            time.sleep(get_query_result_wait_time)
            logger.info(
                f"Get redshift COPY request outcome (STARTED/SUCCESS/ABORTED/FAILED) attempt: {retry_count}"
            )
            query_resp = get_query_resp(query_id=query_id)
            query_status = query_resp["Status"]
            logger.info(f"Redshift query status: {query_status}")

            if query_status != "STARTED" :
                break
            elif retry_count > retry_limit :
                logger.info(f"Retry limit reached, query status is still STARTED")
                break
            else:
                logger.info(f"Query status is STARTED, waiting {get_query_result_wait_time} for it to finish")
                retry_count += 1

        if query_status == "FINISHED":
            logger.info(f"Integration test passed.")
            resp = {
                "response_code": 200,
                "test_result": "SUCCESS",
                "query_status": query_status,
            }
            return resp

        else:
            logger.error(
                f"Integration test failed."
            )
            resp = {
                "response_code": 400,
                "test_result": "FAILED",
                "failure response": str(query_resp),
            }
            return resp

    except Exception as error:
        logger.error(error)
        resp = {
            "response_code": 400,
            "test_result": "FAILED",
            "failure response": str(error),
        }
        return resp


def get_date_str(current_datetime):
    return current_datetime.strftime("%y%d%m")


def get_time_str(current_datetime):
    return current_datetime.strftime("%H%M%S")


def generate_uuid():
    return uuid.uuid4().hex


def generate_test_dataset(date, time, uuid):
    truncated_uuid = uuid[0:6]
    df_test = pd.DataFrame(data={"col1": [date], "col2": [time], "col3": [truncated_uuid]})
    return df_test


def write_data_to_buffer_as_parquet(data):
    parquet_buffer = StringIO()
    data.to_parquet(parquet_buffer)
    return parquet_buffer


def get_query_id(dynamodb_table: Optional[str] = MANIFEST_TABLE) -> str:
    """
    Get the ID of the query performed.

    :param dynamodb_table: name of the dynamoDB table.
    :return: ID of the query
    """

    dynamodb = boto3.resource("dynamodb")
    table = dynamodb.Table(dynamodb_table)  # type: ignore
    logger.info(f"Get RedshiftDataAPI queryID from manifest for S3_URI: {S3_URI}")

    load_record = table.get_item(
        Key={
            "s3uri": S3_URI,
            "loadID": 0,
        }
    )
    logger.info(load_record)

    if "Item" in load_record:
        return load_record["Item"]["queryID"]
    else:
        error_msg = (
            "Likely Dynamo Key error: queryID not found.\n"
            "Check if the S3 bucket notification is configured to send s3 Key events to the forward lambda as a destination.\n"
            "Also check if the Redshift cluster is available"
        )
        logger.error(error_msg)
        raise Exception(error_msg)


def get_query_resp(query_id: str) -> Union[str, ClientError]:
    """
    Retrive the status of a query performed.

    The status can have the following values: FINISHED or FAILED.

    :param id: ID of the query from which we want to obtain the status
    :return: the status of query containing the ID provided to as an input param
    """

    redshift_client = boto3.client("redshift-data")

    try:
        resp = redshift_client.describe_statement(Id=query_id)
        logger.info(str(resp))
        return resp

    except ClientError as e:
        raise logger.error(e)


if __name__ == "__main__":
    handler(event={"running_local": "test"}, context={})
