// To parse this data:
//
//   import { Convert, LoadVerifyErrorContents } from "./file";
//
//   const loadVerifyErrorContents = Convert.toLoadVerifyErrorContents(json);
//
// These functions will throw an error if the JSON doesn't
// match the expected interface, even if the JSON is valid.

export interface LoadVerifyErrorContents {
    application: string;
    'detail-type': string;
    errorType: string;
    errorStatus: string;
    s3BucketName: string;
    s3Key: string;
    codebase: string;
    time: Date;
    source: string;
    version: string;
    region: string;
    id: string;
    resources: string[];
    detail: Detail;
}

export interface Detail {
    response: Response;
    lambdaContext: LambdaContext;
}

export interface LambdaContext {
    callbackWaitsForEmptyEventLoop: boolean;
    functionVersion: string;
    functionName: string;
    memoryLimitInMB: string;
    logGroupName: string;
    logStreamName: string;
    invokedFunctionArn: string;
    awsRequestId: string;
}

export interface Response {
    $metadata: Metadata;
    ClusterIdentifier: string;
    CreatedAt: Date;
    Duration: number;
    Error: string;
    HasResultSet: boolean;
    Id: string;
    QueryString: string;
    RedshiftPid: number;
    RedshiftQueryId: number;
    ResultRows: number;
    ResultSize: number;
    Status: string;
    UpdatedAt: Date;
}

export interface Metadata {
    httpStatusCode: number;
    requestId: string;
    attempts: number;
    totalRetryDelay: number;
}

// Converts JSON strings to/from your types
// and asserts the results of JSON.parse at runtime
export class Convert {
    public static toLoadVerifyErrorContents(json: string): LoadVerifyErrorContents {
        return cast(JSON.parse(json), r('LoadVerifyErrorContents'));
    }

    public static loadVerifyErrorContentsToJson(value: LoadVerifyErrorContents): string {
        return JSON.stringify(uncast(value, r('LoadVerifyErrorContents')), null, 2);
    }
}

function invalidValue(typ: any, val: any, key: any, parent: any = ''): never {
    const prettyTyp = prettyTypeName(typ);
    const parentText = parent ? ` on ${parent}` : '';
    const keyText = key ? ` for key "${key}"` : '';
    throw Error(`Invalid value${keyText}${parentText}. Expected ${prettyTyp} but got ${JSON.stringify(val)}`);
}

function prettyTypeName(typ: any): string {
    if (Array.isArray(typ)) {
        if (typ.length === 2 && typ[0] === undefined) {
            return `an optional ${prettyTypeName(typ[1])}`;
        } else {
            return `one of [${typ
                .map((a) => {
                    return prettyTypeName(a);
                })
                .join(', ')}]`;
        }
    } else if (typeof typ === 'object' && typ.literal !== undefined) {
        return typ.literal;
    } else {
        return typeof typ;
    }
}

function jsonToJSProps(typ: any): any {
    if (typ.jsonToJS === undefined) {
        const map: any = {};
        typ.props.forEach((p: any) => (map[p.json] = { key: p.js, typ: p.typ }));
        typ.jsonToJS = map;
    }
    return typ.jsonToJS;
}

function jsToJSONProps(typ: any): any {
    if (typ.jsToJSON === undefined) {
        const map: any = {};
        typ.props.forEach((p: any) => (map[p.js] = { key: p.json, typ: p.typ }));
        typ.jsToJSON = map;
    }
    return typ.jsToJSON;
}

function transform(val: any, typ: any, getProps: any, key: any = '', parent: any = ''): any {
    function transformPrimitive(typ: string, val: any): any {
        if (typeof typ === typeof val) return val;
        return invalidValue(typ, val, key, parent);
    }

    function transformUnion(typs: any[], val: any): any {
        // val must validate against one typ in typs
        const l = typs.length;
        for (let i = 0; i < l; i++) {
            const typ = typs[i];
            try {
                return transform(val, typ, getProps);
            } catch (_) {}
        }
        return invalidValue(typs, val, key, parent);
    }

    function transformEnum(cases: string[], val: any): any {
        if (cases.indexOf(val) !== -1) return val;
        return invalidValue(
            cases.map((a) => {
                return l(a);
            }),
            val,
            key,
            parent,
        );
    }

    function transformArray(typ: any, val: any): any {
        // val must be an array with no invalid elements
        if (!Array.isArray(val)) return invalidValue(l('array'), val, key, parent);
        return val.map((el) => transform(el, typ, getProps));
    }

    function transformDate(val: any): any {
        if (val === null) {
            return null;
        }
        const d = new Date(val);
        if (isNaN(d.valueOf())) {
            return invalidValue(l('Date'), val, key, parent);
        }
        return d;
    }

    function transformObject(props: { [k: string]: any }, additional: any, val: any): any {
        if (val === null || typeof val !== 'object' || Array.isArray(val)) {
            return invalidValue(l(ref || 'object'), val, key, parent);
        }
        const result: any = {};
        Object.getOwnPropertyNames(props).forEach((key) => {
            const prop = props[key];
            const v = Object.prototype.hasOwnProperty.call(val, key) ? val[key] : undefined;
            result[prop.key] = transform(v, prop.typ, getProps, key, ref);
        });
        Object.getOwnPropertyNames(val).forEach((key) => {
            if (!Object.prototype.hasOwnProperty.call(props, key)) {
                result[key] = transform(val[key], additional, getProps, key, ref);
            }
        });
        return result;
    }

    if (typ === 'any') return val;
    if (typ === null) {
        if (val === null) return val;
        return invalidValue(typ, val, key, parent);
    }
    if (typ === false) return invalidValue(typ, val, key, parent);
    let ref: any = undefined;
    while (typeof typ === 'object' && typ.ref !== undefined) {
        ref = typ.ref;
        typ = typeMap[typ.ref];
    }
    if (Array.isArray(typ)) return transformEnum(typ, val);
    if (typeof typ === 'object') {
        return typ.hasOwnProperty('unionMembers')
            ? transformUnion(typ.unionMembers, val)
            : typ.hasOwnProperty('arrayItems')
              ? transformArray(typ.arrayItems, val)
              : typ.hasOwnProperty('props')
                ? transformObject(getProps(typ), typ.additional, val)
                : invalidValue(typ, val, key, parent);
    }
    // Numbers can be parsed by Date but shouldn't be.
    if (typ === Date && typeof val !== 'number') return transformDate(val);
    return transformPrimitive(typ, val);
}

function cast<T>(val: any, typ: any): T {
    return transform(val, typ, jsonToJSProps);
}

function uncast<T>(val: T, typ: any): any {
    return transform(val, typ, jsToJSONProps);
}

function l(typ: any) {
    return { literal: typ };
}

function a(typ: any) {
    return { arrayItems: typ };
}

function u(...typs: any[]) {
    return { unionMembers: typs };
}

function o(props: any[], additional: any) {
    return { props, additional };
}

function m(additional: any) {
    return { props: [], additional };
}

function r(name: string) {
    return { ref: name };
}

const typeMap: any = {
    LoadVerifyErrorContents: o(
        [
            { json: 'application', js: 'application', typ: '' },
            { json: 'detail-type', js: 'detail-type', typ: '' },
            { json: 'errorType', js: 'errorType', typ: '' },
            { json: 'errorStatus', js: 'errorStatus', typ: '' },
            { json: 's3BucketName', js: 's3BucketName', typ: '' },
            { json: 's3Key', js: 's3Key', typ: '' },
            { json: 'codebase', js: 'codebase', typ: '' },
            { json: 'time', js: 'time', typ: Date },
            { json: 'source', js: 'source', typ: '' },
            { json: 'version', js: 'version', typ: '' },
            { json: 'region', js: 'region', typ: '' },
            { json: 'id', js: 'id', typ: '' },
            { json: 'resources', js: 'resources', typ: a('') },
            { json: 'detail', js: 'detail', typ: r('Detail') },
        ],
        false,
    ),
    Detail: o(
        [
            { json: 'response', js: 'response', typ: r('Response') },
            { json: 'lambdaContext', js: 'lambdaContext', typ: r('LambdaContext') },
        ],
        false,
    ),
    LambdaContext: o(
        [
            { json: 'callbackWaitsForEmptyEventLoop', js: 'callbackWaitsForEmptyEventLoop', typ: true },
            { json: 'functionVersion', js: 'functionVersion', typ: '' },
            { json: 'functionName', js: 'functionName', typ: '' },
            { json: 'memoryLimitInMB', js: 'memoryLimitInMB', typ: '' },
            { json: 'logGroupName', js: 'logGroupName', typ: '' },
            { json: 'logStreamName', js: 'logStreamName', typ: '' },
            { json: 'invokedFunctionArn', js: 'invokedFunctionArn', typ: '' },
            { json: 'awsRequestId', js: 'awsRequestId', typ: '' },
        ],
        false,
    ),
    Response: o(
        [
            { json: '$metadata', js: '$metadata', typ: r('Metadata') },
            { json: 'ClusterIdentifier', js: 'ClusterIdentifier', typ: '' },
            { json: 'CreatedAt', js: 'CreatedAt', typ: Date },
            { json: 'Duration', js: 'Duration', typ: 0 },
            { json: 'Error', js: 'Error', typ: '' },
            { json: 'HasResultSet', js: 'HasResultSet', typ: true },
            { json: 'Id', js: 'Id', typ: '' },
            { json: 'QueryString', js: 'QueryString', typ: '' },
            { json: 'RedshiftPid', js: 'RedshiftPid', typ: 0 },
            { json: 'RedshiftQueryId', js: 'RedshiftQueryId', typ: 0 },
            { json: 'ResultRows', js: 'ResultRows', typ: 0 },
            { json: 'ResultSize', js: 'ResultSize', typ: 0 },
            { json: 'Status', js: 'Status', typ: '' },
            { json: 'UpdatedAt', js: 'UpdatedAt', typ: Date },
        ],
        false,
    ),
    Metadata: o(
        [
            { json: 'httpStatusCode', js: 'httpStatusCode', typ: 0 },
            { json: 'requestId', js: 'requestId', typ: '' },
            { json: 'attempts', js: 'attempts', typ: 0 },
            { json: 'totalRetryDelay', js: 'totalRetryDelay', typ: 0 },
        ],
        false,
    ),
};
