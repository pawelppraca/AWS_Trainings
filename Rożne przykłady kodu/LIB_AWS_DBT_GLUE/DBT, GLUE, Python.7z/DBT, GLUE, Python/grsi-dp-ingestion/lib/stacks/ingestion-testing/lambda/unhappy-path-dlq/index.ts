import { DeleteObjectCommand, S3Client, PutObjectCommand, PutObjectCommandInput } from '@aws-sdk/client-s3';
import {
    DeleteMessageBatchCommand,
    Message,
    SQSClient,
    ReceiveMessageCommand,
    ReceiveMessageCommandInput,
    ReceiveMessageCommandOutput,
} from '@aws-sdk/client-sqs';
import {
    RedshiftClient,
    DescribeClustersCommand,
    DescribeClustersCommandInput,
    DescribeClustersCommandOutput,
} from '@aws-sdk/client-redshift';
import { Context, SQSEvent } from 'aws-lambda';
import * as AWSXRay from 'aws-xray-sdk';
import { LoadVerifyErrorContents } from './load-verify-error-contents';
import {
    DynamoDBClient,
    UpdateItemCommand,
    UpdateItemCommandInput,
    UpdateItemCommandOutput,
} from '@aws-sdk/client-dynamodb';

export const handler = async function (event: SQSEvent, context: Context) {
    console.info(event);
    console.info(context);
    const region: string = process.env.REGION!;
    const ingestionBucketName: string = process.env.BUCKET_NAME!;
    const unhappyPathIngestionAlertingTestS3KeyPath: string = process.env.UNHAPPY_PATH_ALERTING_TEST_S3_KEY_PATH!;
    const columnMappingTable = process.env.COLUMN_MAPPING_TABLE!;
    const organization_guid: string = process.env.ORGANIZATION_ID!;
    const testingDeadLetterQueueUrl: string = process.env.TESTING_DEAD_LETTER_QUEUE_URL!;
    const warehouseClusterName: string = process.env.REDSHIFT_CLUSTER_NAME!;

    let dynamoClient, s3Client, sqsClient, redshiftClient;
    if (!process.env.IS_OFFLINE) {
        // clients have the X-Ray instrumentation middleware added to their middleware stacks
        dynamoClient = AWSXRay.captureAWSv3Client(new DynamoDBClient({ region }));
        s3Client = AWSXRay.captureAWSv3Client(new S3Client({ region }));
        sqsClient = AWSXRay.captureAWSv3Client(new SQSClient({ region }));
        sqsClient = AWSXRay.captureAWSv3Client(new SQSClient({ region }));
        redshiftClient = AWSXRay.captureAWSv3Client(new RedshiftClient({ region }));
    } else {
        // for unit tests
        dynamoClient = new DynamoDBClient({ region });
        s3Client = new S3Client({ region });
        sqsClient = new SQSClient({ region });
        redshiftClient = new RedshiftClient({ region });
    }

    await checkRedshiftClusterIsActive(redshiftClient, warehouseClusterName);

    const testfileS3Key: string = buildS3Key(unhappyPathIngestionAlertingTestS3KeyPath);
    const testFunctionAwsRequestId: string = context.awsRequestId;

    const s3Tags: S3Tags = {
        load_id: -2, // -2 signifies unhappy path test ID
        organization_guid: organization_guid,
        testFunctionAwsRequestId: testFunctionAwsRequestId,
    };
    const s3TagString = s3TagsToString(s3Tags);

    const updateDynamoCommand: UpdateItemCommandInput = {
        TableName: columnMappingTable,
        Key: {
            Table: {
                S: 'unhappy_path',
            },
            Schema: {
                S: 'test',
            },
        },
        UpdateExpression: 'SET ColumnOrder = :co',
        ExpressionAttributeValues: {
            ':co': {
                S: '',
            },
        },
    };

    const columnMappingUpdateResponse: UpdateItemCommandOutput = await updateItemCommand(
        dynamoClient,
        updateDynamoCommand,
    );

    console.log(`Updated column mapping table: ${columnMappingUpdateResponse}`);

    await uploadTestFileToTriggerPipeline(s3Client, ingestionBucketName, testfileS3Key, s3TagString);

    const ReceiveMessageCommandParams: ReceiveMessageCommandInput = {
        AttributeNames: ['All'],
        MaxNumberOfMessages: 10,
        MessageAttributeNames: ['All'],
        QueueUrl: testingDeadLetterQueueUrl,
        WaitTimeSeconds: 20,
        VisibilityTimeout: 30,
    };
    let receivedMessages: ReceiveMessageCommandOutput;

    while (true) {
        receivedMessages = await sqsClient.send(new ReceiveMessageCommand(ReceiveMessageCommandParams));

        if (receivedMessages.Messages) {
            for (let message of receivedMessages.Messages) {
                if (await verifyTestFileFound(message, testfileS3Key)) {
                    await removeMessageFromQueue(sqsClient, message, testingDeadLetterQueueUrl);
                    await deleteTestFile(s3Client, ingestionBucketName, testfileS3Key);
                    return { 'DLQ Validation': 'Successful' };
                }
            }
        }
    }
};

async function checkRedshiftClusterIsActive(redshiftClient: any, targetClusterIdentifier: string) {
    const input: DescribeClustersCommandInput = {
        ClusterIdentifier: targetClusterIdentifier,
    };
    const command = new DescribeClustersCommand(input);
    const response: DescribeClustersCommandOutput = await redshiftClient.send(command);

    if (response.Clusters) {
        for (let cluster of response.Clusters) {
            if (cluster.ClusterIdentifier == targetClusterIdentifier && cluster.ClusterStatus != 'available') {
                throw new Error('Redshift cluster not available; likely remedy - turn it on!');
            }
        }
    } else {
        throw new Error('No Redshift clusters found');
    }
}

export function buildS3Key(unhappyPathIngestionAlertingTestS3KeyPath: string): string {
    unhappyPathIngestionAlertingTestS3KeyPath;
    const now = new Date();
    const datetime = now.toISOString();
    return `${unhappyPathIngestionAlertingTestS3KeyPath}/${datetime}.parquet`;
}

export interface S3Tags {
    load_id: number;
    organization_guid: string;
    testFunctionAwsRequestId: string;
}

export function s3TagsToString(s3Tags: S3Tags): string {
    return Object.entries(s3Tags)
        .map(([key, value]) => `${key}=${value}`)
        .join('&');
}

async function updateItemCommand(dynamoDBClient: DynamoDBClient, params: UpdateItemCommandInput) {
    const updateRecord = new UpdateItemCommand(params);
    try {
        return await dynamoDBClient.send(updateRecord);
    } catch (err) {
        throw `Error updating DynamoDB: ${err}`;
    }
}

async function uploadTestFileToTriggerPipeline(
    s3Client: any,
    ingestionBucketName: string,
    s3Key: string,
    s3TagString: string,
) {
    try {
        const unhappyPathTestFile: PutObjectCommandInput = {
            Body: 'filetoupload',
            Bucket: ingestionBucketName,
            Key: s3Key,
            Tagging: s3TagString,
        };

        await s3Client.send(new PutObjectCommand(unhappyPathTestFile));
        console.log(`Test file ${s3Key} uploaded`);
    } catch (err: any) {
        throw err;
    }
}

async function deleteTestFile(s3Client: any, ingestionBucketName: string, s3Key: string) {
    try {
        const command = new DeleteObjectCommand({
            Bucket: ingestionBucketName,
            Key: s3Key,
        });

        console.log(`Cleaning state, removing test file: ${s3Key}`);
        const response = await s3Client.send(command);
    } catch (err: any) {
        throw err;
    }
}

async function removeMessageFromQueue(sqsClient: any, message: Message, testingDeadLetterQueueUrl: string) {
    try {
        await sqsClient.send(
            new DeleteMessageBatchCommand({
                QueueUrl: testingDeadLetterQueueUrl,
                Entries: [
                    {
                        Id: message.MessageId,
                        ReceiptHandle: message.ReceiptHandle,
                    },
                ],
            }),
        );
    } catch (err: any) {
        throw err;
    }
}

async function verifyTestFileFound(message: Message, testfileS3Key: string): Promise<boolean> {
    try {
        console.log(message);
        const messageBody: LoadVerifyErrorContents = JSON.parse(message.Body as string);
        if (messageBody.s3Key == testfileS3Key) {
            console.log(`Test file ${testfileS3Key} found. Removing message from queue with ID ${message.MessageId}`);
            return true;
        } else {
            return false;
        }
    } catch (err: any) {
        throw err;
    }
}
