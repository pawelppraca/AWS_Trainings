<h1 align="left">Ingestion Integration Test</h1>
<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->

- [Running the test](#running-the-test)
- [Developing and running the Python test directly:](#developing-and-running-the-python-test-directly)
  - [Choosing the environment to run against](#choosing-the-environment-to-run-against)
- [Contributing? Format your code](#contributing-format-your-code)
- [Installation](#installation)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->


## Running the test

The integration test invokes a lambda which generates sample data, uploads it to the S3 ingestion bucket and later checks the status of the COPY statements against Redshift.

To run the test in the same way as in in Bamboo CI, you'll need AWS credentials for the appropriate environment and execute the following shell script:

```bash
export bamboo_forge_environment_key=development
export bamboo_forge_runtime_instance_location_key=eu-west-1
./scripts/integration_test/integration_test_load.sh 
```

This will also depend on your AWS config or default aws environment variables, make sure they match!

## Developing and running the Python test directly:

If you have not yet [installed the requirements](#installation), do so now.

```bash
source .venv/bin/activate
python3 lib/stacks/testing/lambda/integration-test-load/integration_test_load.py
```

Note: This test resolves the status of the COPY statement request, identifying if the command has finished or in a failed state. The COPY command was run by the Redshift Data API which generates a UUID associated with that instruction and can later be queried to attain that status. It can only be checked by the original role that executed the COPY command, thus if you are running this script from your machine you would need to adopt the lambda role for it to pass successfully, otherwise it will not find the ID. 

### Choosing the environment to run against

The test will default to using the EU Development environement, providing you have AWS credentials configured. If you are using another environment, update and export the following environment variables:

```bash
export FILE_MANIFEST_TABLE=grsi-dp-dynamodb-file-manifest-table-eu-development
export BUCKET_NAME=grsi-dp-ingestion-eu-development
export ORGANIZATION_ID=2326c977-2f8d-4d97-8f13-a7ca2fd5d5db
```

## Contributing? Format your code

```bash
black lib/stacks/testing/lambda/integration-test-load/integration_test_load.py
```


## Installation

1. (Install if necessary and) create a [virtual environment](https://packaging.python.org/en/latest/key_projects/#venv) to isolate the package version installation
1. Enter the venv
1. Install requirements
1. Run the program: [Back to top](#running-the-test)

```bash
python3 -m venv .venv
source .venv/bin/activate
pip3 install --requirement lib/stacks/testing/lambda/integration-test-load/requirements.txt
```
