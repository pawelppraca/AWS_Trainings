import { Aws, Duration, RemovalPolicy, Tags } from 'aws-cdk-lib';
import { AnyPrincipal, ArnPrincipal, PolicyStatement } from 'aws-cdk-lib/aws-iam';
import { Alias } from 'aws-cdk-lib/aws-kms';
import { BlockPublicAccess, Bucket, BucketEncryption, StorageClass } from 'aws-cdk-lib/aws-s3';
import { Construct } from 'constructs';
import { StackConfiguration } from '../../../bin/config';
import { Metric, Alarm, TreatMissingData } from 'aws-cdk-lib/aws-cloudwatch';
import { SnsAction } from 'aws-cdk-lib/aws-cloudwatch-actions';
import { Topic } from 'aws-cdk-lib/aws-sns';
import { config, grsiPrefix } from '@lmig/grsi-dp-shared-config-and-classes';
import { upperCase } from 'lodash';

export class SourceResources extends Construct {
    readonly kmsRemovalPolicy: RemovalPolicy;
    constructor(scope: Construct, id: string, stackConfig: StackConfiguration) {
        super(scope, id);

        const removalPolicy = isProd() ? RemovalPolicy.RETAIN : RemovalPolicy.DESTROY;

        const ingestionKmsKey = Alias.fromAliasName(
            this,
            'IngestionBucketKMSKey',
            `alias/grsi-dp-ingestion-key-${stackConfig.regionEnv}`,
        );

        const ingestionBucket = new Bucket(this, 'IngestionBucket', {
            bucketName: stackConfig.ingestionBucketName,
            encryption: BucketEncryption.KMS,
            encryptionKey: ingestionKmsKey,
            enforceSSL: true,
            removalPolicy: removalPolicy,
            blockPublicAccess: BlockPublicAccess.BLOCK_ALL,
            bucketKeyEnabled: true,
            lifecycleRules: [
                {
                    id: 'TransitionToGlacier',
                    enabled: true,
                    transitions: [
                        {
                            storageClass: StorageClass.GLACIER,
                            transitionAfter: Duration.days(30),
                        },
                    ],
                    expiration: Duration.days(90),
                },
            ],
        });
        Tags.of(ingestionBucket).add('dpmawsbackup', 'none');

        // Bucket policy to allow cdk generated BucketNotificationsHandler to add notification configuration;
        // typical use is to subscribe to eventBridge or the lambda notification forwarder (vai lamda destinations)
        ingestionBucket.addToResourcePolicy(
            new PolicyStatement({
                actions: ['s3:GetBucketNotification*', 's3:PutBucketNotification'],
                principals: [
                    new AnyPrincipal().withConditions({
                        ArnLike: {
                            // Allow generated BucketNotificationsHandler roles within within the grsi-dp codebase
                            'aws:PrincipalArn': `arn:aws:iam::${Aws.ACCOUNT_ID}:role/grsi-dp-*`,
                        },
                    }),
                ],
                resources: [ingestionBucket.bucketArn, `${ingestionBucket.bucketArn}/*`],
            }),
        );

        ingestionBucket.addToResourcePolicy(
            new PolicyStatement({
                principals: [
                    new AnyPrincipal().withConditions({
                        ArnLike: {
                            'aws:PrincipalArn': `arn:aws:iam::${Aws.ACCOUNT_ID}:role/${config.lambdaRoleName}`,
                        },
                    }),
                ],
                actions: ['s3:PutObject*'],
                resources: [`${ingestionBucket.bucketArn}/test/*`],
            }),
        );

        ingestionBucket.addToResourcePolicy(
            new PolicyStatement({
                actions: ['s3:PutObject*', 's3:GetObject*', 's3:DeleteObject*', 's3:ListBucket'],
                principals: [
                    new AnyPrincipal().withConditions({
                        ArnLike: {
                            'aws:PrincipalArn': `arn:aws:iam::${Aws.ACCOUNT_ID}:user/grsi-dp-developer-${stackConfig.regionEnv}`,
                        },
                    }),
                ],
                resources: [ingestionBucket.bucketArn, `${ingestionBucket.bucketArn}/*`],
            }),
        );

        ingestionBucket.addToResourcePolicy(
            new PolicyStatement({
                actions: ['s3:PutObject*', 's3:GetObject*', 's3:DeleteObject*', 's3:ListBucket'],
                principals: [
                    new AnyPrincipal().withConditions({
                        ArnLike: {
                            'aws:PrincipalArn': `arn:aws:iam::${Aws.ACCOUNT_ID}:role/grsi-dp-redshift-role-${stackConfig.regionEnv}`,
                        },
                    }),
                ],
                resources: [ingestionBucket.bucketArn, `${ingestionBucket.bucketArn}/*`],
            }),
        );

        ingestionBucket.addToResourcePolicy(
            new PolicyStatement({
                actions: ['s3:PutObject*', 's3:GetObject*', 's3:DeleteObject*', 's3:ListBucket'],
                principals: [
                    new ArnPrincipal(
                        `arn:aws:iam::${Aws.ACCOUNT_ID}:role/cloud-services/pipeline-deployment-guid-access`,
                    ),
                ],
                resources: [ingestionBucket.bucketArn, `${ingestionBucket.bucketArn}/*`],
            }),
        );

        ingestionBucket.addToResourcePolicy(
            new PolicyStatement({
                actions: ['s3:PutObject*', 's3:GetObject*', 's3:DeleteObject*', 's3:ListBucket'],
                principals: [
                    new AnyPrincipal().withConditions({
                        ArnLike: {
                            'aws:PrincipalArn': `arn:aws:iam::${Aws.ACCOUNT_ID}:role/${stackConfig.ingestionLambdaRoleName}`,
                        },
                    }),
                ],
                resources: [ingestionBucket.bucketArn, `${ingestionBucket.bucketArn}/*`],
            }),
        );

        config.awsRegionCodes.map((region) =>
            ingestionBucket.addToResourcePolicy(
                new PolicyStatement({
                    principals: [
                        new AnyPrincipal().withConditions({
                            ArnLike: {
                                'aws:PrincipalArn': `arn:aws:iam::${
                                    config.accountNumbers[config.environmentKey][upperCase(region)]
                                }:role/${config.extractionGlueRoleNames[upperCase(region)]}`,
                            },
                        }),
                    ],
                    actions: ['s3:PutObject*', 's3:GetObject*', 's3:DeleteObject*', 's3:ListBucket'],
                    resources: [ingestionBucket.bucketArn, `${ingestionBucket.bucketArn}/*`],
                }),
            ),
        );

        function isProd(): boolean {
            return stackConfig.environmentKey === 'production';
        }
    }
}
