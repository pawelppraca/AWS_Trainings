import binascii
import logging
import os
import sys
import time

import boto3
from aws_xray_sdk.core import patch_all, xray_recorder
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.conf import SparkConf


msg_format = "%(asctime)s %(levelname)s %(name)s: %(message)s"
datetime_format = "%Y-%m-%d %H:%M:%S"
logging.basicConfig(format=msg_format, datefmt=datetime_format)
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

class GlueJobUtil:

    @staticmethod
    def get_hadoop_fs_kms_config_from_ssm(
        app_env,
        assume_role_prefix,
        bucket,
        region,
        account_number,
        kms_key_ssm_param_prefix,
    ):
        """
        Static function to use Boto3 to assume cross-account role and retrieve SSM Parameter
        :param account_number:  Account number of the region that the Role to assume is in
        :param app_env: The Environment
        :param region: The AWS region, e.g. 'us-east-1' or 'eu-west-1'
        :param assume_role_prefix:  Role to use to do SSM Retrieval
        :param bucket:  Name of the bucket for config
        :param kms_key_ssm_param_prefix: Name of the SSM Parameter containing the desired KMS ARN value
        :return: List of Spark config tuples for desired bucket and environment
        """
        region_shortcode = region[0:2]  # 'us-east-1' > 'us'
        assume_role = f"arn:aws:iam::{account_number}:role/{assume_role_prefix}-{region_shortcode}-{app_env}"
        kms_key_ssm_param = "-".join(
            [kms_key_ssm_param_prefix, region_shortcode, app_env]
        )

        logger.info(f"Getting KMS Param {kms_key_ssm_param} using role {assume_role}")

        sts = boto3.client("sts")
        session = sts.assume_role(RoleArn=assume_role, RoleSessionName="glueAssumeRole")

        ssm = boto3.client(
            "ssm",
            region_name=region,
            aws_access_key_id=session["Credentials"]["AccessKeyId"],
            aws_secret_access_key=session["Credentials"]["SecretAccessKey"],
            aws_session_token=session["Credentials"]["SessionToken"],
        )

        ssm_response = ssm.get_parameter(Name=kms_key_ssm_param, WithDecryption=True)

        return [
            (
                f"spark.hadoop.fs.s3a.bucket.{bucket}-{region_shortcode}-{app_env}.server-side-encryption.key",
                ssm_response["Parameter"]["Value"],
            ),
            (
                f"spark.hadoop.fs.s3a.{bucket}-{region_shortcode}-{app_env}.server-side-encryption-algorithm",
                "SSE-KMS",
            ),
        ]

    @staticmethod
    def create_contexts(app_env, region_info, bucket, assume_role_prefix, kms_key_ssm_param_prefix, datalake_credentials):
        """
        Static Function to create SparkContext, GlueContext, SparkSession objects
        :return spark_context: SparkContext object
        :return glue_context: SparkContext object
        :return spark_session: SparkSession object
        """

        sparkConfig = [
            (
                "spark.hadoop.fs.s3a.server-side-encryption.key",
                "arn:aws:kms:us-east-1:988639011640:key/522c8a3b-547f-49f1-86a8-3c576c7d2994",
            ),
            (
                "spark.hadoop.fs.s3a.server-side-encryption-algorithm",
                "SSE-KMS",
            ), 
            (
                "spark.sql.catalog.spark_catalog",
                "org.apache.spark.sql.delta.catalog.DeltaCatalog",
            ), 
            (
                "spark.delta.logStore.class",
                "org.apache.spark.sql.delta.storage.S3SingleDriverLogStore",
            ),
            (
                "fs.s3a.access.key",
                datalake_credentials['AccessKeyId']
            ),
            (
                "fs.s3a.secret.key",
                datalake_credentials['SecretAccessKey']
            ),
            (
                "fs.s3a.session.token",
                datalake_credentials['SessionToken']
            ),
            (
                "fs.s3a.impl",
                "org.apache.hadoop.fs.s3a.S3AFileSystem"
            ),
            (
                "fs.s3a.credentials.provider",
                "org.apache.hadoop.fs.s3a.TemporaryAWSCredentialsProvider"
                # "com.amazonaws.auth.profile.ProfileCredentialsProvider"
            ),

        ]

        # Generate additional Spark config per bucket per region
        for r in region_info:
            sparkConfig.extend(
                GlueJobUtil.get_hadoop_fs_kms_config_from_ssm(
                    app_env=app_env,
                    assume_role_prefix=assume_role_prefix,
                    bucket=bucket,
                    region=r[0],
                    account_number=r[1],
                    kms_key_ssm_param_prefix=kms_key_ssm_param_prefix,
                )
            )
        config = SparkConf().setAll(sparkConfig)
        spark_context = SparkContext.getOrCreate(config)
        glue_context = GlueContext(spark_context)
        spark_context.setLogLevel("DEBUG")
        spark_session = glue_context.spark_session
        spark_session.sql("set spark.sql.parquet.int96RebaseModeInWrite=CORRECTED")
        spark_session.sql("set spark.sql.caseSensitive=false")
        logger.info("Glue context has been created successfully")

        logger.info(f"config: {config.getAll()}")
        logger.info(f"spark_context: {spark_context}")
        logger.info(f"glue_context: {glue_context}")
        logger.info(f"spark_session: {spark_session}")
        logger.info(f"spark_context.getConf(): {spark_context.getConf()}")

        return spark_context, glue_context, spark_session

    @staticmethod
    def create_logger(glue_context):
        logger = glue_context.get_logger()
        return logger


# def test_datalake(environment, credentials):        
#     s3=boto3.resource(
#         's3',
#         aws_access_key_id=credentials['AccessKeyId'],
#         aws_secret_access_key=credentials['SecretAccessKey'],
#         aws_session_token=credentials['SessionToken'],
#     )
    
#     sns_client = boto3.client(
#         'sns',
#         aws_access_key_id=credentials['AccessKeyId'],
#         aws_secret_access_key=credentials['SecretAccessKey'],
#         aws_session_token=credentials['SessionToken']
#     )
    
#     if environment in ['test', 'qa']: 
#         topic_arn = "arn:aws:sns:us-east-1:988639011640:grs-datalake-non-prod-data-pipeline-event-sns-topic"
    
#     elif environment == 'production':
#         topic_arn = "arn:aws:sns:us-east-1:177100477748:grs-datalake-prod-data-pipeline-event-sns-topic"
    
    
#     test_endpoint = "test@example.com"

#     # Subscribe the test endpoint
#     response = sns_client.subscribe(
#         TopicArn=topic_arn,
#         Protocol='email',  
#         Endpoint=test_endpoint
#     )
#     subscription_arn = response['SubscriptionArn']
#     logger.info(f"Successfully subscribed: {subscription_arn}")

#     return

def test_datalake(credentials):
    # s3=boto3.resource(
    #     's3',
    #     aws_access_key_id=credentials['AccessKeyId'],
    #     aws_secret_access_key=credentials['SecretAccessKey'],
    #     aws_session_token=credentials['SessionToken'],
    # )
    
    # bucket = s3.Bucket("grs-datalake-non-pro-bddhh3sy6i5cr8rsj35zi76xyoue4use1b-s3alias")
    logger.info(f"Test create dynamic frame")
    # files = []
    # for obj in bucket.objects.filter(Prefix='non-prod/distill-delta/genius/ZACJ/'):
    #     if '.snappy.parquet' in obj.key:
    #         logger.info(f"s3a://grs-datalake-non-pro-snwnzp4bfod7s4iou8r5rey4mwjhyuse1b-s3alias/{obj.key}")

    # df = spark_session.read.parquet(*files)
    # df = spark_session.read.format("delta").load("s3a://grs-datalake-non-pro-snwnzp4bfod7s4iou8r5rey4mwjhyuse1b-s3alias/non-prod/distill-delta/genius/ZACJ/zacj/")

    df = spark_session.read.format("delta").load("s3a://grs-datalake-non-pro-bddhh3sy6i5cr8rsj35zi76xyoue4use1b-s3alias/non-prod/distill-delta/genius/ZUMA/zuma/")
    
    print(f"""
                rows - {df.count()}
                columns - {df.columns}
                """)
    return


class XRayHelper:
    """
    provides all neccessary information to use xray with ecs hosted daemon in a glue job
    """

    VERSION = "1"
    DELIMITER = "-"

    def __init__(self, resource_arn_pattern: str) -> None:
        # Generate a random trace id
        self.start_time = int(time.time())
        self.__number = binascii.b2a_hex(os.urandom(12)).decode("utf-8")
        self.resource_arn_pattern = resource_arn_pattern
        self._ecs = boto3.client("ecs")

    def trace_id(self) -> str:
        """
        a trace id tracks the path of a request through your application.
        a trace collects all the segments generated by a single request.
        a trace id is required for a segment.
        """
        return "%s%s%s%s%s" % (
            XRayHelper.VERSION,
            XRayHelper.DELIMITER,
            format(self.start_time, "x"),
            XRayHelper.DELIMITER,
            self.__number,
        )

    def get_xray_daemon_ip(self) -> str:
        # return xray daemon ip from ecs
        cluster_arn = "".join(
            arn
            for arn in self._ecs.list_clusters()["clusterArns"]
            if self.resource_arn_pattern in arn
        )

        # get task arn for xray daemon then get that ip
        tasks = [
            arn
            for arn in self._ecs.list_tasks(cluster=cluster_arn)["taskArns"]
            if self.resource_arn_pattern in arn
        ]

        for task in self._ecs.describe_tasks(cluster=cluster_arn, tasks=tasks)["tasks"]:
            if "xray" in str.lower(task["containers"][0]["name"]):
                return task["containers"][0]["networkInterfaces"][0][
                    "privateIpv4Address"
                ]

    def main(self) -> None:
        logger.info("Starting job...")
        logger.info(f"Region: {self.region_name}")
        # set up xray to point to our daemon running in ecs
        xray_helper = XRayHelper(
            f"grsi-dp-ecs-cluster-{self.region_name[0:2]}-{self.app_env}"
        )
        xray_recorder.configure(
            sampling=False,
            service="Glue Job Extraction",
            daemon_address=f"{xray_helper.get_xray_daemon_ip()}:2000",
        )
        logger.info(f"X-Ray trace id: {xray_helper.trace_id()}")

        # enable aws xray tracing
        patch_all()
        xray_recorder.begin_segment(
            name=f"Glue Job Data Extraction: {self.job_name} {self.job_run_id}",
            traceid=xray_helper.trace_id(),
            sampling=True,
        )
        xray_recorder.end_subsegment()

        xray_recorder.end_segment()


if __name__ == "__main__":
    args = getResolvedOptions(
        sys.argv,
        [
            "JOB_NAME",
            "AWS_REGION",
            "ACCOUNT_ID",
            "ENVIRONMENT",
            "SOURCE_DATA_BUCKET",
            "INGESTION_BUCKET",
            "ORGANIZATION_GUID",
            "LM_TROUX_UID",
            "ARTIFACT_GUID",
            "DEPLOYMENT_GUID",
            "ID_TABLE",
            "ASSUME_ROLE_PREFIX",
            "KMS_KEY_SSM_PARAM_PREFIX",
            "US_ACCOUNT_NUMBER",
            "EU_ACCOUNT_NUMBER",
            "AP_ACCOUNT_NUMBER",
            "DATALAKE_CROSS_ACCOUNT_ROLE",
            # "DATALAKE_BUCKET",
        ],
    )
    sts = boto3.client('sts')
    time.sleep(5)
    session = sts.assume_role(RoleArn=args["DATALAKE_CROSS_ACCOUNT_ROLE"], RoleSessionName="datalakeAssumeRole")
    time.sleep(5)
    credentials=session['Credentials']
    (
        spark_context,
        glue_context,
        spark_session,
    ) = GlueJobUtil.create_contexts(
        region_info=[
            ("us-east-1", args["US_ACCOUNT_NUMBER"]),
            ("eu-west-1", args["EU_ACCOUNT_NUMBER"])
            # ("ap-southeast-2", args["AP_ACCOUNT_NUMBER"]),
        ],
        app_env=args["ENVIRONMENT"],
        bucket=args["INGESTION_BUCKET"],
        assume_role_prefix=args["ASSUME_ROLE_PREFIX"],
        kms_key_ssm_param_prefix=args["KMS_KEY_SSM_PARAM_PREFIX"],
        datalake_credentials=credentials
    )
    logger = GlueJobUtil.create_logger(glue_context)
    job = Job(glue_context)
    job.init(args["JOB_NAME"], args)
    try:
        if args["ENVIRONMENT"] == "development":
            logger.error("Dev environment, don't try datalake test")
        else:
            test_datalake(credentials)
    except Exception as e:
        logger.error(f"Error: {e}")
        raise e
    finally:
        job.commit()
