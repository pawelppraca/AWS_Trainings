from abc import ABC, abstractmethod
from typing import Dict
from .shared import TableInfo, FilterType, filter_dict, ExtractorType
from .util import GlueLogger
from pyspark.sql import DataFrame
from pyspark.sql.functions import expr
import boto3

class AbstractExtractor(ABC):
    @abstractmethod
    def extract(self, table_info: TableInfo) -> DataFrame:
        pass


class S3Extractor(AbstractExtractor):
    def __init__(
        self,
        spark_session,
        logger: GlueLogger,
        bucket_name: str,
        table_infos: Dict[str, TableInfo],
        filter_dataframes: Dict[FilterType, DataFrame],
        environment: str
    ) -> None:
        self.spark_session = spark_session
        self.logger = logger
        self.bucket_name = bucket_name
        self.table_infos = table_infos
        self.filter_dataframes = filter_dataframes
        self.environment = environment

    def _s3_extract_table(self, table_info: TableInfo) -> DataFrame:
        table_path = table_info.table_path
        if self.environment == 'production':
            datalake_environment = 'prod'
        else:
            datalake_environment = 'non-prod'
        
        object_path = f"s3a://{self.bucket_name}/{datalake_environment}/{table_path}"
        
        self.logger.info(
                f"Importing from datalake - {object_path}"
            )
        dataframe = self.spark_session.read.format("delta").load(object_path)
        columns_to_drop = ['year', 'month', 'day', 'schema_version', 'payload_id', 'LastUpdatedDate', 'dtlk_is_current', 'dtlk_processed_time', 'dtlk_processed_status']
        dataframe = dataframe.drop(*columns_to_drop)
        return dataframe.alias(table_info.alias)

    def _get_relation_data_frame(self, table_name: str) -> DataFrame:
        if table_name in filter_dict.keys():
            return self.filter_dataframes.get(filter_dict.get(table_name))

        return self._s3_extract_table(self.table_infos.get(table_name))

    def extract(self, table_info: TableInfo) -> DataFrame:
        self.logger.info(
            f"Extracting source table '{table_info.table_name}': "
            f"source='{table_info.source}', "
            f"database_name='{table_info.database_name}', "
            f"schema='{table_info.schema}', "
            f"table_name='{table_info.table_name}'"
        )

        data_frame = self._s3_extract_table(table_info)

        if data_frame.isEmpty():
            self.logger.info(
                f"Source table [{table_info.table_name}] has no (new) data."
            )
            return data_frame

        for child_table in table_info.relationships:
            relation_data_frame = self._get_relation_data_frame(child_table.table_name)
            self.logger.info(
                f"Joining base table [{table_info.table_name}] onto table [{child_table.table_name}]: {relation_data_frame}"
            )
            data_frame = data_frame.join(
                relation_data_frame,
                on=expr(child_table.join_condition),
                how=child_table.join_type,
            )

        cols = data_frame.select(f"{table_info.alias}.*")
        self.logger.info(f"Finished extracting table [{table_info.table_name}].")
        return cols


class Extractor:
    def __init__(
        self,
        glue_context,
        logger: GlueLogger,
        extractor_type: ExtractorType,
        data_source_name: str,
        table_infos: Dict[str, TableInfo],
        environment: str,
        filter_dataframes: Dict[FilterType, DataFrame] = None,
    ) -> None:
        self.extractor_type = extractor_type
        self.extractor = self._select_extractor(
            glue_context, logger, data_source_name, table_infos, filter_dataframes, environment
        )

    def _select_extractor(
        self,
        glue_context,
        logger: GlueLogger,
        data_source_name: str,
        table_infos: Dict[str, TableInfo],
        filter_dataframes: Dict[FilterType, DataFrame],
        environment
    ) -> AbstractExtractor:
        if self.extractor_type == ExtractorType.S3:
            return S3Extractor(
                glue_context, logger, data_source_name, table_infos, filter_dataframes, environment
            )
        elif self.extractor_type == ExtractorType.SPARK:
            raise NotImplementedError()
        else:
            raise NotImplementedError()

    def extract(self, table_info: TableInfo) -> DataFrame:
        return self.extractor.extract(table_info)
