import abc
from typing import Dict, Optional, List

from pyspark.sql import SparkSession, DataFrame

from etl.shared import TableInfo, TabularDataSet
from .util import ColumnMappingDynamoDBWriter
from etl.util import GlueLogger

class BaseWriter(metaclass=abc.ABCMeta):

    def __init__(
        self,
        column_mapping_writer: Optional[ColumnMappingDynamoDBWriter]=None
    ) -> None:
        self._column_mapping_writer = column_mapping_writer

    @abc.abstractmethod 
    def write(self, 
                table_info: TableInfo,
                target_data_frame: DataFrame,
                spark: SparkSession,
                logger: GlueLogger,
                **kwargs
                ) -> None:
        raise NotImplementedError("write is abstract")

class BaseExtractor(metaclass=abc.ABCMeta):
    
    def __init__(
        self,
        environment: str
    ) -> None:
        self.environment = environment
        self._datasets = {}
    
    
    def add_dataset(self, dataset_name: str, dataset: TabularDataSet) -> None:
        self._datasets[dataset_name] = dataset

    def _get_dataset_as_dataframe(self, dataset_name: str, spark: SparkSession) -> DataFrame:
        sc = spark.sparkContext
        return spark.read.json(sc.parallelize(self._datasets[dataset_name].rows))

    def extract(self, 
                source_tables: Dict[str, TableInfo],
                spark: SparkSession,
                logger: GlueLogger,
                ) -> Dict[str, DataFrame]:
        """
        Returns a set of table(s) from the data source as DataFrames
        :param source_tables: k,v pairs of tables and paths
        :param logger:  
        :param spark: Spark Session
        :return: dictionary of Data Frames
        """

        #Check all of the tables have a TableInfo defined
        for table, table_info in source_tables.items():
            if not table_info:
                raise ValueError(f"No table definition has been provided for source table '{table}'.")

        #First check if any of the requested tables are static datasets passed in to the extractor
        static_datasets = {k: self._get_dataset_as_dataframe(k, spark) for (k,v) in source_tables.items() if k in self._datasets}
        if len(static_datasets) > 0:
            logger.info(f"Extracting static dataset(s): {[*static_datasets.keys()]}")
        
        #Remove any tables that have already been loaded before extracting tables from the data source
        filtered_source_tables = {k: v for (k,v) in source_tables.items() if k not in static_datasets}

        return static_datasets | self._extract(filtered_source_tables, spark, logger)

    
    @abc.abstractmethod 
    def _extract(self, 
                source_tables: Dict[str, TableInfo],
                spark: SparkSession,
                logger: GlueLogger,
                ) -> Dict[str, DataFrame]:
        """
        Returns a set of table(s) from the data source as DataFrames
        :param source_tables: k, v pairs of tables and paths
        :param spark: Spark Session
        :param logger:  
        :return: dictionary of Data Frames
        """ 
        raise NotImplementedError("extract is abstract")
    
    def _drop_columns(self, source_df: DataFrame, drop_column_list: List[str]) -> DataFrame:
        new_df = source_df.drop(*drop_column_list)
        return new_df

class BaseDataFlow(metaclass=abc.ABCMeta):
    
    def __init__(
            self,
            extractor: BaseExtractor,
            writer: BaseWriter,
            spark: SparkSession,
            logger: GlueLogger,
            job_name: str,
    ) -> None:
        self.extractor = extractor
        self.writer = writer
        self.spark = spark
        self.logger = logger
        self.job_name = job_name
    

    @abc.abstractmethod 
    def run(self): 
        raise NotImplementedError("run is abstract")


    


