import {
    CloudWatchEncryptionMode,
    Code,
    Connection,
    ConnectionType,
    GlueVersion,
    Job,
    JobBookmarksEncryptionMode,
    JobExecutable,
    PythonVersion,
    S3EncryptionMode,
    SecurityConfiguration,
    WorkerType,
} from '@aws-cdk/aws-glue-alpha';
import { config, grsiPrefix, vpc } from '@lmig/grsi-dp-shared-config-and-classes';
import { Aws, Fn, RemovalPolicy, Tags } from 'aws-cdk-lib';
import { Port, SecurityGroup, Subnet } from 'aws-cdk-lib/aws-ec2';
import { EventField, Rule, RuleTargetInput } from 'aws-cdk-lib/aws-events';
import { SnsTopic } from 'aws-cdk-lib/aws-events-targets';
import { CfnCrawler, CfnDatabase, CfnTrigger } from 'aws-cdk-lib/aws-glue';
import {
    ArnPrincipal,
    CompositePrincipal,
    Effect,
    ManagedPolicy,
    Policy,
    PolicyDocument,
    PolicyStatement,
    Role,
    ServicePrincipal,
} from 'aws-cdk-lib/aws-iam';
import { Alias, Key } from 'aws-cdk-lib/aws-kms';
import { BlockPublicAccess, Bucket, BucketEncryption } from 'aws-cdk-lib/aws-s3';
import { Topic } from 'aws-cdk-lib/aws-sns';
import { Construct } from 'constructs';
import { StackConfiguration } from '../../../bin/config';
import { AttributeType, BillingMode, Table, TableEncryption } from 'aws-cdk-lib/aws-dynamodb';
import { Alarm, Metric, TreatMissingData } from 'aws-cdk-lib/aws-cloudwatch';
import { SnsAction } from 'aws-cdk-lib/aws-cloudwatch-actions';
import { SubnetCustomResource } from '@lmig/swa-cdk-core';

export class ExtractionResources extends Construct {
    constructor(scope: Construct, id: string, stackConfig: StackConfiguration) {
        super(scope, id);
        const logStreamPrefix = 'grsi-dp-glue-load-';
        const { environmentKey } = stackConfig;

        const glueKmsKey = Key.fromKeyArn(
            this,
            'GlueKeyLookup',
            Fn.importValue(config.glueScriptBucketKmsKeyExportName),
        );

        let glueScriptBucket;

        glueScriptBucket = new Bucket(this, 'GlueScriptBucket', {
            bucketName: `grsi-dp-glue-script-${stackConfig.regionEnv}`,
            encryption: BucketEncryption.KMS,
            encryptionKey: glueKmsKey,
            enforceSSL: true,
            removalPolicy: RemovalPolicy.DESTROY,
            blockPublicAccess: BlockPublicAccess.BLOCK_ALL,
            bucketKeyEnabled: true,
        });
        Tags.of(glueScriptBucket).add('dpmawsbackup', 'none');

        glueScriptBucket.addToResourcePolicy(
            new PolicyStatement({
                actions: ['s3:PutObjectTagging', 's3:PutObject'],
                principals: [
                    new ArnPrincipal(
                        `arn:aws:iam::${Aws.ACCOUNT_ID}:role/cloud-services/pipeline-deployment-guid-access`,
                    ),
                ],
                resources: [`arn:aws:s3:::${glueScriptBucket.bucketName}/*`],
                conditions: {
                    StringEquals: {
                        's3:RequestObjectTag/deployment_guid': stackConfig.stackTags.deployment_guid,
                    },
                    'ForAllValues:StringEquals': {
                        's3:RequestObjectTag/deployment_guid': ['${aws:PrincipalTag/deployment_guid}'],
                    },
                },
            }),
        );

        glueScriptBucket.addToResourcePolicy(
            new PolicyStatement({
                actions: ['s3:PutObjectTagging', 's3:PutObject'],
                principals: [
                    new ArnPrincipal(
                        `arn:aws:iam::${Aws.ACCOUNT_ID}:role/cloud-services/pipeline-deployment-guid-access`,
                    ),
                ],
                resources: [`arn:aws:s3:::${glueScriptBucket.bucketName}/*`],
                conditions: {
                    StringEquals: {
                        's3:RequestObjectTag/deployment_guid': stackConfig.stackTags.deployment_guid,
                    },
                    'ForAllValues:StringEquals': {
                        's3:RequestObjectTag/deployment_guid': ['${aws:PrincipalTag/deployment_guid}'],
                    },
                },
            }),
        );

        const dynamoKey = Key.fromKeyArn(this, 'DynamoKeyLookup', Fn.importValue(config.dynamoKmsKeyExportName));

        const idTable = new Table(this, 'dynamo-id-table', {
            tableName: `${grsiPrefix}-dynamodb-id-table-${environmentKey}`,
            encryption: TableEncryption.CUSTOMER_MANAGED,
            encryptionKey: dynamoKey,
            partitionKey: { name: 'Counter', type: AttributeType.STRING },
            removalPolicy: RemovalPolicy.DESTROY,
            billingMode: BillingMode.PAY_PER_REQUEST,
            pointInTimeRecovery: true,
        });

        Tags.of(idTable).add('dpmawsbackup', stackConfig.failSafeBackupTag);

        const topic = Topic.fromTopicArn(
            this,
            'NotificationTopic',
            `arn:aws:sns:${Aws.REGION}:${Aws.ACCOUNT_ID}:${grsiPrefix}-notification-topic-${stackConfig.regionEnv}`,
        );

        const extraction_error_alarm = new Alarm(this, 'Extraction Bucket Error Alarm', {
            metric: new Metric({
                namespace: `Extraction Bucket Error Alarm: ${stackConfig.regionEnv}`,
                metricName: 'errors',
                statistic: 'Sum',
            }),
            threshold: 0,
            evaluationPeriods: 1,
            datapointsToAlarm: 1,
            treatMissingData: TreatMissingData.NOT_BREACHING,
            alarmDescription: 'Detect errors',
            alarmName: `Extraction Bucket Error Alarm: ${stackConfig.regionEnv}`,
        });

        extraction_error_alarm.addAlarmAction(new SnsAction(topic));

        const extractionGlueRoleName = `${grsiPrefix}-extract-glue-role-${stackConfig.regionEnv}`;

        const glueJobRoleInlinePolicies: { [key: string]: PolicyDocument } = {
            s3Policy: new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        actions: ['s3:GetObject*', 's3:DeleteObject', 's3:PutObject*'],
                        resources: [
                            `arn:aws:s3:::${stackConfig.ingestionBucketNameBase}-*-${stackConfig.environmentKey}/*`,
                            `arn:aws:s3:::${stackConfig.historicLoadBucketName}/*`,
                        ],
                    }),
                    new PolicyStatement({
                        actions: ['s3:GetObject*'],
                        resources: [`${glueScriptBucket.bucketArn}/*`],
                    }),
                    new PolicyStatement({
                        actions: ['kms:Decrypt', 'kms:DescribeKey'],
                        resources: [glueKmsKey.keyArn],
                    }),
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        actions: ['kms:Decrypt', 'kms:Encrypt', 'kms:GenerateDataKey', 'kms:DescribeKey'],
                        resources: [
                            `arn:aws:kms:eu-west-1:${config.accountNumbers[environmentKey].EU}:key/*`,
                            `arn:aws:kms:us-east-1:${config.accountNumbers[environmentKey].US}:key/*`,
                            `arn:aws:kms:ap-southeast-2:${config.accountNumbers[environmentKey].AP}:key/*`,
                        ],
                        conditions: {
                            StringEquals: {
                                'aws:ResourceTag/lm_troux_uid': stackConfig.stackTags.lm_troux_uid,
                            },
                        },
                    }),
                ],
            }),
            logsPolicy: new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        actions: ['logs:*'],
                        resources: [
                            `arn:aws:logs:${Aws.REGION}:${Aws.ACCOUNT_ID}:log-group:grsi-dp*`,
                            `arn:aws:logs:${Aws.REGION}:${Aws.ACCOUNT_ID}:log-group:/aws-glue/*`,
                        ],
                    }),
                ],
            }),
            interactiveSession: new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        actions: ['iam:PassRole'],
                        resources: [`arn:aws:iam::${Aws.ACCOUNT_ID}:role/${extractionGlueRoleName}`],
                    }),
                ],
            }),
            ecsPolicy: new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        actions: ['ecs:ListClusters', 'ecs:ListTasks'],
                        resources: [`*`],
                    }),
                    new PolicyStatement({
                        actions: ['ecs:DescribeTasks'],
                        resources: [
                            `arn:aws:ecs:${Aws.REGION}:${Aws.ACCOUNT_ID}:task/grsi-dp-ecs-cluster-${stackConfig.regionEnv}/*`,
                        ],
                    }),
                ],
            }),
            stsPolicy: new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        actions: ['sts:AssumeRole'],
                        resources: [
                            `arn:aws:iam::*:role/${config.glueAssumeRoleNamePrefix}-*-${config.environmentKey}`,
                        ],
                    }),
                ],
            }),
            snsPolicy: new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        actions: ['sns:Publish'],
                        resources: [topic.topicArn],
                    }),
                ],
            }),
        };

        if (['test', 'non-production', 'qa', 'production'].includes(config.environmentKey)) {
            glueJobRoleInlinePolicies['datalakePolicy'] = new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        actions: ['sts:AssumeRole'],
                        resources: [
                            config.datalakeMapping[config.environmentKey][config.regionCode.toUpperCase()][
                                'crossAccountRole'
                            ],
                        ],
                    }),
                    new PolicyStatement({
                        actions: ['s3:GetObject*', 's3:ListBucket*'],
                        resources: [
                            'arn:aws:s3:us-east-1:988639011640:accesspoint/grs-datalake-non-prod-curated-grsi/*',
                            'arn:aws:s3:us-east-1:988639011640:accesspoint/grs-datalake-non-prod-curated-grsi',
                            'arn:aws:s3:us-east-1:988639011640:accesspoint/grs-datalake-non-pro-bddhh3sy6i5cr8rsj35zi76xyoue4use1b-s3alias',
                            'arn:aws:s3:us-east-1:988639011640:accesspoint/grs-datalake-non-pro-bddhh3sy6i5cr8rsj35zi76xyoue4use1b-s3alias/*',
                        ],
                    }),
                ],
            });
        }

        const glueJobRole = new Role(this, 'ExtractionGlueRole', {
            roleName: extractionGlueRoleName,
            assumedBy: new CompositePrincipal(new ServicePrincipal('glue.amazonaws.com')),
            managedPolicies: [
                ManagedPolicy.fromManagedPolicyArn(
                    this,
                    'AWSGlueServiceRole',
                    'arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole',
                ),
            ],
            inlinePolicies: glueJobRoleInlinePolicies,
        });

        glueJobRole.stack.tags.setTag('aws_iam_permission_boundary_exempt', ' ');

        idTable.grantReadWriteData(glueJobRole);

        const ingestionKey = Alias.fromAliasName(
            this,
            'ingestionKey-alias',
            `alias/grsi-dp-ingestion-key-${stackConfig.regionEnv}`,
        );

        const securityConfig = new SecurityConfiguration(this, 'SecurityConfiguration', {
            securityConfigurationName: `grsi-dp-security-config-${stackConfig.regionEnv}`,
            cloudWatchEncryption: {
                mode: CloudWatchEncryptionMode.KMS,
                kmsKey: ingestionKey,
            },
            jobBookmarksEncryption: {
                mode: JobBookmarksEncryptionMode.CLIENT_SIDE_KMS,
                kmsKey: ingestionKey,
            },
            s3Encryption: {
                mode: S3EncryptionMode.KMS,
            },
        });

        const historicDataBucket = Bucket.fromBucketName(this, 'sourceDataBucket', stackConfig.historicLoadBucketName);

        // CLAIM CENTER INFRA
        const claimCenterDatabase = new CfnDatabase(this, 'ClaimCenterDatabase', {
            catalogId: Aws.ACCOUNT_ID,
            databaseInput: {
                description: 'Claim Center',
                name: `grsi-dp-claim-center-${stackConfig.environmentKey}`,
            },
        });

        const crawlerName = `${grsiPrefix}-bilz-crawler-${stackConfig.environmentKey}`;

        let bilzConnName: string;
        // only deploy if connection is defined in grsi-dp-shared-config-and-classes/src/config.ts.
        // conditional required as bilz is not available in development
        if (config.bilzConnName[stackConfig.environmentKey] !== undefined && config.awsRegion == 'eu-west-1') {
            bilzConnName = config.bilzConnName[config.environmentKey];
            const crawler = new CfnCrawler(this, 'ClaimCenterCrawler', {
                crawlerSecurityConfiguration: securityConfig.securityConfigurationName,
                name: `grsi-dp-claim-center-crawler-${stackConfig.environmentKey}`,
                databaseName: claimCenterDatabase.ref,
                role: glueJobRole.roleArn,
                targets: {
                    jdbcTargets: [
                        {
                            connectionName: bilzConnName,
                            path: 'BI_LZ/ClaimCenter/%',
                        },
                        {
                            connectionName: bilzConnName,
                            path: 'BI_LZ/Genius/%',
                        },
                        {
                            connectionName: bilzConnName,
                            path: 'BI_LZ/Map/FXRates_Genius',
                        },
                    ],
                },
                schemaChangePolicy: {
                    updateBehavior: 'UPDATE_IN_DATABASE',
                    deleteBehavior: 'DEPRECATE_IN_DATABASE',
                },
                tags: {
                    lm_troux_uid: stackConfig.stackTags.lm_troux_uid,
                    organization_guid: stackConfig.stackTags.organization_guid,
                    deployment_guid: stackConfig.stackTags.deployment_guid,
                    lm_app: `aws-${stackConfig.artifactKey}`,
                    lm_app_env: stackConfig.environmentKey,
                    Name: stackConfig.stackNames.extraction,
                },
            });
            crawler.node.addDependency(glueJobRole);
        }

        const vpcLookup = new vpc(this, 'LookupVpc');

        const glueSecurityGroup = new SecurityGroup(this, 'SecurityGroup', {
            allowAllOutbound: true,
            description: 'Security Group to allow Glue to run in VPC',
            securityGroupName: `grsi-dp-glue-security-group-${stackConfig.regionEnv}`,
            vpc: vpcLookup.ivpc,
        });
        // Self referencing rule to allow Glue to talk to all its internal components
        // Needs commented out first deploy due to radar rule, then added in after
        glueSecurityGroup.addIngressRule(glueSecurityGroup, Port.allTcp(), 'self-referencing');

        let glueSubnet: SubnetCustomResource;

        if (config.awsRegion == 'ap-southeast-2') {
            glueSubnet = new SubnetCustomResource(this, 'DynamicSubnet', {
                az: '1',
                name: 'private',
                vpcId: vpcLookup.vpcId(),
            });
        } else {
            glueSubnet = new SubnetCustomResource(this, 'DynamicSubnet', {
                az: '1',
                name: 'private-dynamic',
                vpcId: vpcLookup.vpcId(),
            });
        }

        const vpcConnection = new Connection(this, 'Connection', {
            connectionName: `grsi-dp-vpc-connection-${stackConfig.regionEnv}`,
            type: ConnectionType.NETWORK,
            subnet: Subnet.fromSubnetAttributes(this, 'SubnetLookup', {
                subnetId: glueSubnet.subnetId(),
                availabilityZone: vpcLookup.availabilityZones[0],
            }),
            securityGroups: [glueSecurityGroup],
        });

        const extractJob = new Job(this, 'pySparkExtractJob', {
            role: glueJobRole,
            executable: JobExecutable.pythonEtl({
                pythonVersion: PythonVersion.THREE,
                glueVersion: GlueVersion.V4_0,
                script: Code.fromBucket(glueScriptBucket, 'scripts/main.py'),
                extraPythonFiles: [Code.fromBucket(glueScriptBucket, 'scripts/etl.zip')],
            }),
            jobName: `grsi-dp-extract-${stackConfig.environmentKey}`,
            description: 'Job to load region-separated data from Data source to regional S3 bucket',
            securityConfiguration: securityConfig,
            connections: [vpcConnection],
            workerType: WorkerType.G_1X,
            workerCount: 10,
            continuousLogging: {
                enabled: true,
                quiet: true,
                logStreamPrefix,
            },
            defaultArguments: {
                '--job-bookmark-option': 'job-bookmark-disable',
                '--enable-metrics': 'true',
                '--additional-python-modules': 'aws-xray-sdk==2.12.0',
                '--disable-proxy-v2': 'true', // https://docs.aws.amazon.com/glue/latest/dg/connection-VPC-disable-proxy.html
                '--AWS_REGION': Aws.REGION,
                '--ACCOUNT_ID': Aws.ACCOUNT_ID,
                '--ENVIRONMENT': stackConfig.environmentKey,
                '--SOURCE_DATA_BUCKET':
                    config.datalakeMapping[config.environmentKey][config.regionCode.toUpperCase()]['lakeBucket'],
                '--INGESTION_BUCKET': stackConfig.ingestionBucketNameBase,
                '--ORGANIZATION_GUID': stackConfig.stackTags.organization_guid,
                '--LM_TROUX_UID': stackConfig.stackTags.lm_troux_uid,
                '--ARTIFACT_GUID': stackConfig.stackTags.artifact_guid,
                '--DEPLOYMENT_GUID': stackConfig.stackTags.deployment_guid,
                '--ID_TABLE': idTable.tableName,
                '--US_ACCOUNT_NUMBER': config.accountNumbers[config.environmentKey]['US'],
                '--EU_ACCOUNT_NUMBER': config.accountNumbers[config.environmentKey]['EU'],
                '--AP_ACCOUNT_NUMBER': config.accountNumbers[config.environmentKey]['AP'],
                '--ASSUME_ROLE_PREFIX': config.glueAssumeRoleNamePrefix,
                '--KMS_KEY_SSM_PARAM_PREFIX': config.ingestionKmsKeySSMParamNamePrefix,
                '--DYNAMO_COLUMN_MAPPING_TABLE_NAME_PREFIX': config.dynamoColumnMappingTableNamePrefix,
                '--DATALAKE_CROSS_ACCOUNT_ROLE':
                    config.datalakeMapping[config.environmentKey][config.regionCode.toUpperCase()]['crossAccountRole'],
                '--datalake-formats': 'delta',
            },
        });

        if (config.awsRegion == 'us-east-1') {
            new CfnTrigger(this, 'GlueTrigger', {
                actions: [
                    {
                        jobName: extractJob.jobName,
                        securityConfiguration: securityConfig.securityConfigurationName,
                    },
                ],
                type: 'SCHEDULED',
                name: `grsi-dp-extract-trigger-${stackConfig.environmentKey}`,
                schedule: 'cron(30 15 26 06 ? 2024)',
                startOnCreation: true,
                tags: stackConfig.stackTags,
            });
        }

        new Rule(this, 'extract-event-rule', {
            description: 'Event Rule for state changes in extract job',
            ruleName: `${extractJob.jobName}-rule`,
            enabled: true,
            eventPattern: {
                source: ['aws.glue'],
                detailType: ['Glue Job State Change'],
                detail: {
                    state: ['SUCCEEDED', 'FAILED', 'TIMEOUT', 'STOPPED', 'ERROR'],
                    jobName: [extractJob.jobName],
                },
            },
            targets: [
                new SnsTopic(topic, {
                    message: RuleTargetInput.fromMultilineText(
                        `JOB NAME: ${EventField.fromPath('$.detail.jobName')}\nJOB ID: ${EventField.fromPath(
                            '$.detail.jobRunId',
                        )}\nSTATE: ${EventField.fromPath('$.detail.state')}\n${EventField.fromPath(
                            '$.detail.severity',
                        )}: ${EventField.fromPath('$.detail.message')}`,
                    ),
                }),
            ],
        });

        // Policy Infrastructure - Only needs to exist in EU
        if (config.awsRegion == 'eu-west-1') {
            const DWHConnection = new Connection(this, 'DWHConnection', {
                connectionName: `grsi-dp-dwh-policy-connection-${stackConfig.regionEnv}`,
                type: ConnectionType.JDBC,
                subnet: Subnet.fromSubnetAttributes(this, 'SubnetLookups', {
                    subnetId: glueSubnet.subnetId(),
                    availabilityZone: vpcLookup.availabilityZones[0],
                }),
                securityGroups: [glueSecurityGroup],
                properties: {
                    JDBC_CONNECTION_URL: `${stackConfig.dwhConnectionURL}`,
                    USERNAME: `${stackConfig.dwhUsername}`,
                    PASSWORD: `${stackConfig.dwhPassword}`,
                },
            });

            const policyExtractJob = new Job(this, 'pySparkPolicyExtractJob', {
                role: glueJobRole,
                executable: JobExecutable.pythonEtl({
                    pythonVersion: PythonVersion.THREE,
                    glueVersion: GlueVersion.V4_0,
                    script: Code.fromBucket(glueScriptBucket, 'scripts2.0/wr_extraction_job.py'),
                    extraPythonFiles: [Code.fromBucket(glueScriptBucket, 'scripts2.0/etl.zip')],
                }),
                jobName: `grsi-dp-policy-extract-${stackConfig.environmentKey}`,
                description: 'Job to load policy data from Data source to regional S3 bucket',
                securityConfiguration: securityConfig,
                connections: [vpcConnection],
                workerType: WorkerType.G_1X,
                workerCount: 10,
                continuousLogging: {
                    enabled: true,
                    quiet: true,
                    logStreamPrefix,
                },
                defaultArguments: {
                    '--job-bookmark-option': 'job-bookmark-disable',
                    '--enable-metrics': 'true',
                    '--additional-python-modules': 'aws-xray-sdk==2.12.0',
                    '--disable-proxy-v2': 'true', // https://docs.aws.amazon.com/glue/latest/dg/connection-VPC-disable-proxy.html
                    '--AWS_REGION': Aws.REGION,
                    '--ACCOUNT_ID': Aws.ACCOUNT_ID,
                    '--ENVIRONMENT': stackConfig.environmentKey,
                    '--GLUE_SCRIPT_BUCKET': glueScriptBucket.bucketName,
                    '--INGESTION_BUCKET': stackConfig.ingestionBucketNameBase,
                    '--SOURCE_DATA_BUCKET': historicDataBucket.bucketName,
                    '--ORGANIZATION_GUID': stackConfig.stackTags.organization_guid,
                    '--LM_TROUX_UID': stackConfig.stackTags.lm_troux_uid,
                    '--ARTIFACT_GUID': stackConfig.stackTags.artifact_guid,
                    '--DEPLOYMENT_GUID': stackConfig.stackTags.deployment_guid,
                    '--ID_TABLE': idTable.tableName,
                    '--US_ACCOUNT_NUMBER': config.accountNumbers[config.environmentKey]['US'],
                    '--EU_ACCOUNT_NUMBER': config.accountNumbers[config.environmentKey]['EU'],
                    '--ASSUME_ROLE_PREFIX': config.glueAssumeRoleNamePrefix,
                    '--DYNAMO_COLUMN_MAPPING_TABLE_NAME_PREFIX': config.dynamoColumnMappingTableNamePrefix,
                    '--KMS_KEY_SSM_PARAM_PREFIX': config.ingestionKmsKeySSMParamNamePrefix,
                    '--NOTIFICATION_TOPIC_ARN': topic.topicArn,
                    '--XRAY_ECS_RESOURCE_ARN': stackConfig.xrayEcsResourceArn,
                    '--DWH_GLUE_CONNECTION_NAME': stackConfig.dwhGlueConnectionName,
                },
            });
        }

        //only deploy to US as the data currently only exists in the US data lake
        if (config.awsRegion == 'us-east-1') {
            const datalakeExtractJob = new Job(this, 'pySparkDatalakeExtractJob', {
                role: glueJobRole,
                executable: JobExecutable.pythonEtl({
                    pythonVersion: PythonVersion.THREE,
                    glueVersion: GlueVersion.V4_0,
                    script: Code.fromBucket(glueScriptBucket, 'scripts2.0/datalake_extraction_job.py'),
                    extraPythonFiles: [Code.fromBucket(glueScriptBucket, 'scripts2.0/etl.zip')],
                }),
                jobName: `grsi-dp-datalake-extract-${stackConfig.environmentKey}`,
                description: 'Extract data from data lake and write to regional S3 bucket(s)',
                securityConfiguration: securityConfig,
                connections: [vpcConnection],
                workerType: WorkerType.G_1X,
                workerCount: 10,
                continuousLogging: {
                    enabled: true,
                    quiet: true,
                    logStreamPrefix,
                },
                defaultArguments: {
                    '--job-bookmark-option': 'job-bookmark-disable',
                    '--enable-metrics': 'true',
                    '--additional-python-modules': 'aws-xray-sdk==2.12.0',
                    '--disable-proxy-v2': 'true', // https://docs.aws.amazon.com/glue/latest/dg/connection-VPC-disable-proxy.html
                    '--AWS_REGION': Aws.REGION,
                    '--ACCOUNT_ID': Aws.ACCOUNT_ID,
                    '--ENVIRONMENT': stackConfig.environmentKey,
                    '--SOURCE_DATA_BUCKET':
                        config.datalakeMapping[config.environmentKey][config.regionCode.toUpperCase()]['lakeBucket'],
                    '--GLUE_SCRIPT_BUCKET': glueScriptBucket.bucketName,
                    '--INGESTION_BUCKET': stackConfig.ingestionBucketNameBase,
                    '--ORGANIZATION_GUID': stackConfig.stackTags.organization_guid,
                    '--LM_TROUX_UID': stackConfig.stackTags.lm_troux_uid,
                    '--ARTIFACT_GUID': stackConfig.stackTags.artifact_guid,
                    '--DEPLOYMENT_GUID': stackConfig.stackTags.deployment_guid,
                    '--ID_TABLE': idTable.tableName,
                    '--US_ACCOUNT_NUMBER': config.accountNumbers[config.environmentKey]['US'],
                    '--EU_ACCOUNT_NUMBER': config.accountNumbers[config.environmentKey]['EU'],
                    '--ASSUME_ROLE_PREFIX': config.glueAssumeRoleNamePrefix,
                    '--DYNAMO_COLUMN_MAPPING_TABLE_NAME_PREFIX': config.dynamoColumnMappingTableNamePrefix,
                    '--KMS_KEY_SSM_PARAM_PREFIX': config.ingestionKmsKeySSMParamNamePrefix,
                    '--NOTIFICATION_TOPIC_ARN': topic.topicArn,
                    '--XRAY_ECS_RESOURCE_ARN': stackConfig.xrayEcsResourceArn,
                    '--DATALAKE_CROSS_ACCOUNT_ROLE':
                        config.datalakeMapping[config.environmentKey][config.regionCode.toUpperCase()][
                            'crossAccountRole'
                        ],
                    '--datalake-formats': 'delta',
                },
            });
        }

        //only deploy to EU as the historical data r(from BILZ) is in the EU
        if (config.awsRegion == 'eu-west-1') {
            const historicalExtractJob = new Job(this, 'pySparkHistoricalExtractJob', {
                role: glueJobRole,
                executable: JobExecutable.pythonEtl({
                    pythonVersion: PythonVersion.THREE,
                    glueVersion: GlueVersion.V4_0,
                    script: Code.fromBucket(glueScriptBucket, 'scripts2.0/historical_extraction_job.py'),
                    extraPythonFiles: [Code.fromBucket(glueScriptBucket, 'scripts2.0/etl.zip')],
                }),
                jobName: `grsi-dp-historical-extract-${stackConfig.environmentKey}`,
                description: 'Extract data from S3 historical load bucket (BILZ) and write to regional S3 bucket(s)',
                securityConfiguration: securityConfig,
                connections: [vpcConnection],
                workerType: WorkerType.G_1X,
                workerCount: 10,
                continuousLogging: {
                    enabled: true,
                    quiet: true,
                    logStreamPrefix,
                },
                defaultArguments: {
                    '--job-bookmark-option': 'job-bookmark-disable',
                    '--enable-metrics': 'true',
                    '--additional-python-modules': 'aws-xray-sdk==2.12.0',
                    '--disable-proxy-v2': 'true', // https://docs.aws.amazon.com/glue/latest/dg/connection-VPC-disable-proxy.html
                    '--AWS_REGION': Aws.REGION,
                    '--ACCOUNT_ID': Aws.ACCOUNT_ID,
                    '--ENVIRONMENT': stackConfig.environmentKey,
                    '--SOURCE_DATA_BUCKET': historicDataBucket.bucketName,
                    '--GLUE_SCRIPT_BUCKET': glueScriptBucket.bucketName,
                    '--INGESTION_BUCKET': stackConfig.ingestionBucketNameBase,
                    '--ORGANIZATION_GUID': stackConfig.stackTags.organization_guid,
                    '--LM_TROUX_UID': stackConfig.stackTags.lm_troux_uid,
                    '--ARTIFACT_GUID': stackConfig.stackTags.artifact_guid,
                    '--DEPLOYMENT_GUID': stackConfig.stackTags.deployment_guid,
                    '--ID_TABLE': idTable.tableName,
                    '--US_ACCOUNT_NUMBER': config.accountNumbers[config.environmentKey]['US'],
                    '--EU_ACCOUNT_NUMBER': config.accountNumbers[config.environmentKey]['EU'],
                    '--ASSUME_ROLE_PREFIX': config.glueAssumeRoleNamePrefix,
                    '--DYNAMO_COLUMN_MAPPING_TABLE_NAME_PREFIX': config.dynamoColumnMappingTableNamePrefix,
                    '--KMS_KEY_SSM_PARAM_PREFIX': config.ingestionKmsKeySSMParamNamePrefix,
                    '--NOTIFICATION_TOPIC_ARN': topic.topicArn,
                    '--XRAY_ECS_RESOURCE_ARN': stackConfig.xrayEcsResourceArn,
                },
            });
        }

        if (!['production'].includes(config.environmentKey)) {
            const extractTableDefinitionJob = new Job(this, 'extractTableDefinitionJob', {
                role: glueJobRole,
                executable: JobExecutable.pythonEtl({
                    pythonVersion: PythonVersion.THREE,
                    glueVersion: GlueVersion.V4_0,
                    script: Code.fromBucket(glueScriptBucket, 'scripts/extract-table-definition.py'),
                }),
                jobName: `${grsiPrefix}-extract-table-definition-${stackConfig.environmentKey}`,
                description: 'Job to extract table definition',
                securityConfiguration: securityConfig,
                connections: [vpcConnection],
                workerType: WorkerType.G_1X,
                workerCount: 20,
                continuousLogging: {
                    enabled: true,
                    quiet: true,
                    logStreamPrefix: `${grsiPrefix}-extract-table-definition-`,
                },
                defaultArguments: {
                    '--job-bookmark-option': 'job-bookmark-disable',
                    '--enable-metrics': 'true',
                    '--additional-python-modules': 'aws-xray-sdk==2.12.0',
                    '--disable-proxy-v2': 'true', // https://docs.aws.amazon.com/glue/latest/dg/connection-VPC-disable-proxy.html
                    '--AWS_REGION': stackConfig.awsEnv.region as string,
                    '--ACCOUNT_ID': stackConfig.awsEnv.account as string,
                    '--APP_ENV': stackConfig.environmentKey,
                    '--ORGANIZATION_GUID': stackConfig.stackTags.organization_guid,
                    '--LM_TROUX_UID': stackConfig.stackTags.lm_troux_uid,
                    '--ARTIFACT_GUID': stackConfig.stackTags.artifact_guid,
                    '--DEPLOYMENT_GUID': stackConfig.stackTags.deployment_guid,
                },
            });

            new CfnTrigger(this, 'TableDefinitionGlueTrigger', {
                name: `grsi-dp-extract-table-definition-trigger-${stackConfig.environmentKey}`,
                type: 'CONDITIONAL',
                actions: [
                    {
                        jobName: extractTableDefinitionJob.jobName,
                        securityConfiguration: securityConfig.securityConfigurationName,
                    },
                ],
                predicate: {
                    conditions: [
                        {
                            logicalOperator: 'EQUALS',
                            crawlerName: crawlerName,
                            crawlState: 'SUCCEEDED',
                        },
                    ],
                    logical: 'ANY',
                },
                startOnCreation: true,
                tags: stackConfig.stackTags,
            });
        }

        const datalakeTestJob = new Job(this, 'pySparkDatalakeTestJob', {
            role: glueJobRole,
            executable: JobExecutable.pythonEtl({
                pythonVersion: PythonVersion.THREE,
                glueVersion: GlueVersion.V4_0,
                script: Code.fromBucket(glueScriptBucket, 'scripts/datalake-test.py'),
            }),
            jobName: `grsi-dp-datalake-test-${stackConfig.environmentKey}`,
            description: 'Job to load region-separated data from Data source to regional S3 bucket',
            securityConfiguration: securityConfig,
            connections: [vpcConnection],
            workerType: WorkerType.G_2X,
            workerCount: 5,
            continuousLogging: {
                enabled: true,
                quiet: true,
                logStreamPrefix,
            },
            defaultArguments: {
                '--job-bookmark-option': 'job-bookmark-disable',
                '--enable-metrics': 'true',
                '--enable-auto-scaling': 'true',
                '--additional-python-modules': 'aws-xray-sdk==2.12.0',
                '--disable-proxy-v2': 'true', // https://docs.aws.amazon.com/glue/latest/dg/connection-VPC-disable-proxy.html
                '--AWS_REGION': Aws.REGION,
                '--ACCOUNT_ID': Aws.ACCOUNT_ID,
                '--ENVIRONMENT': stackConfig.environmentKey,
                '--SOURCE_DATA_BUCKET': historicDataBucket.bucketName,
                '--INGESTION_BUCKET': stackConfig.ingestionBucketNameBase,
                '--ORGANIZATION_GUID': stackConfig.stackTags.organization_guid,
                '--LM_TROUX_UID': stackConfig.stackTags.lm_troux_uid,
                '--ARTIFACT_GUID': stackConfig.stackTags.artifact_guid,
                '--DEPLOYMENT_GUID': stackConfig.stackTags.deployment_guid,
                '--ID_TABLE': idTable.tableName,
                '--US_ACCOUNT_NUMBER': config.accountNumbers[config.environmentKey]['US'],
                '--EU_ACCOUNT_NUMBER': config.accountNumbers[config.environmentKey]['EU'],
                '--AP_ACCOUNT_NUMBER': config.accountNumbers[config.environmentKey]['AP'],
                '--ASSUME_ROLE_PREFIX': config.glueAssumeRoleNamePrefix,
                '--KMS_KEY_SSM_PARAM_PREFIX': config.ingestionKmsKeySSMParamNamePrefix,
                '--DATALAKE_CROSS_ACCOUNT_ROLE':
                    config.datalakeMapping[config.environmentKey][config.regionCode.toUpperCase()]['crossAccountRole'],
                '--DATALAKE_BUCKET':
                    config.datalakeMapping[config.environmentKey][config.regionCode.toUpperCase()]['lakeBucket'],
                '--datalake-formats': 'delta',
            },
        });
    }
}
