from typing import List, Dict, Optional
from copy import copy, deepcopy
from datetime import datetime

from pyspark.sql import SparkSession

from .base import BaseDataFlow, BaseExtractor, BaseWriter
from .xray import XrayTracerMixin
from etl.shared import DataRegion, SourceSystemInfo, TableInfo, DataFilterType
from etl.filtering.util import DataFilterFactory
from etl.filtering.transforms import SparkTransformMixin
from etl.util import GlueLogger, SNSHelper
from etl.spark_common import get_df_string_repr

class RegionalDataFlow(BaseDataFlow, SparkTransformMixin, XrayTracerMixin):

    def __init__(
        self,
        extractor: BaseExtractor,
        regional_writers: Dict[DataRegion, BaseWriter],
        spark: SparkSession,
        logger: GlueLogger,
        job_name: str,
        data_regions: List[DataRegion],
        source_systems: Dict[str, SourceSystemInfo],
        sns_topic: SNSHelper = None,
        enable_xray_tracing: bool=False,
        xray_settings: Optional[Dict[str, str]]=None
    ) -> None:
        super().__init__(
            extractor = extractor,
            writer = None,
            spark = spark,
            logger = logger,
            job_name = job_name
        )
        self.regional_writers = regional_writers
        self.data_regions = data_regions
        self.source_systems = source_systems
        self.enable_xray_tracing = enable_xray_tracing
        self.sns_topic = sns_topic
        self._xray_settings = xray_settings if enable_xray_tracing else {}
            
    
    def run(self):
        """
        Extracts data from source before applying regional data filtering and writing the data to the target region(s).
            1: Enumerate each source system
            2: Build and cache the filter data frames used to filter the source data by region
            3: Enumerate all the source tables for the specified source system
                3a: Extract any tables (other source tables or filter data frames) that are specified in the extract query for the target source table
                3b. Create a data frame using the extract query (data for ALL regions)
                3c. Add any meta-data columns
            4. Filter the data (if required) for each region and write the dataframe out to the specified destination (e.g. S3)
            4a. If the source table is flagged for filtering; filter the rows for the current region before writing the data
            4b. If no filtering is required; write ALL rows to each region
        """

        self.logger.info(f"Starting job '{self.job_name}'...")

        #TODO: Set load_id from DynamoDb
        load_id = 1

        if self.enable_xray_tracing:
            xray_traceid = self.start_xray_trace(resource_arn_pattern=self._xray_settings["xray_ecs_resource_arn"],
                                                service_name=self._xray_settings["service_name"],
                                                main_segment_name=self._xray_settings["main_segment_name"])
            self.logger.info(f"X-Ray TraceId: '{xray_traceid}'")
       
        #TODO: Add Xray trace sub_segment to load the filter data frames
        
        
        #Enumerate Source Systems
        data_frame_cache = {}
        for source_system in self.source_systems.values():
            
            if source_system.enabled:
                self.logger.info(f"Starting to process Source System: [{ source_system.name }]...")
                if self.enable_xray_tracing:                                             
                    self.start_sub_segment(f"Extract for source system: [{source_system.name}]")
            else:
                self.logger.info(f"SKIPPING: Source System: [{ source_system.name }] as system is disabled in config file.")
                continue

            enabled_source_tables = {table_name: table for (table_name, table) in source_system.source_tables.items() if table.enabled}

            #Create the filter data frames
            for data_filter_info in sorted(source_system.data_filters, key = lambda x: (x.order)):
                self.logger.info(f"Loading data filter: '{data_filter_info.filter_type}' for source system '{source_system.name}'...")       

                #Retrieve the TableInfo definition for each source table required for the filter
                filter_source_tables = {table_name: deepcopy(enabled_source_tables.get(table_name)) for table_name in data_filter_info.source_table_names}
                #Add reference datasets
                filter_source_tables = filter_source_tables | {dataset_name: TableInfo(name=dataset_name) for dataset_name in data_filter_info.reference_datasets}
                #Create the data frames
                self.logger.info(f"Extracting table(s) to build data filter '{data_filter_info.filter_type}': {[*filter_source_tables.keys()]}")
                data_frame_dict = self.extractor.extract(filter_source_tables, self.spark, self.logger)

                #Add any other filter data frames that are referenced by this filter
                data_frame_dict = data_frame_dict | {filter_name: data_frame_cache.get(filter_name) for filter_name in data_filter_info.dependent_filters}

                data_filter = DataFilterFactory.create_data_filter(data_filter_info.filter_type, copy(self.data_regions))
                df_filter = data_filter.get_data_frame(self.spark, data_frame_dict, self.logger).cache()
                data_frame_cache[data_filter.filter_name] = df_filter
                self.logger.info(f"Finished creating data filter '{data_filter_info.filter_type}'.")

                ###########################################################################################################################
                #Note: The dataframe has been cached (Dataframe API uses lazy caching, so it is only marked for caching until an action is triggered).
                #      The count operation will trigger an action, but this is ok as the filter dataframe will be used in subsequent join operations.
                self.logger.info(f"Total row count for filter '{data_filter.filter_name}' = {df_filter.count()}")
                self.logger.info(f"Filter dataframe '{data_filter.filter_name}' row counts grouped by region:")
                self.logger.info(get_df_string_repr(df_filter.groupBy("__data_region").count()))
                ############################################################################################################################

            #Enumerate source tables and write the data out to each region
            for source_table_name, source_table in enabled_source_tables.items():
                self.logger.info(f"Processing source table '{source_table_name}' from '{source_system.name}'...") 
                
                #Get a list of any other source tables (EXCLUDE filter tables) required to build the extract query for this source table
                tables_to_extract = {source_table_name: source_table}
                if source_table.relationships:
                    tables_to_extract = tables_to_extract | {child_table: enabled_source_tables.get(child_table) for child_table in source_table.get_child_tables(exclude=DataFilterType.list())}
                df_dict = self.extractor.extract(tables_to_extract, self.spark, self.logger)

                #Add any filter tables from the Data Frame cache that are referenced in the extract query
                df_dict = df_dict | {filter_table: data_frame_cache.get(filter_table) for filter_table in source_table.get_child_tables(include=DataFilterType.list())}

                self.logger.info(f"Building extract query for source table '{source_table_name}' from base tables {[*df_dict.keys()]}...") 
                df_merged = self.build_extract_query(source_table, df_dict)
                #Add system columns
                system_column_values = {
                    SparkTransformMixin.TRACE_ID_COLUMN: xray_traceid,
                    SparkTransformMixin.SOURCE_SYSTEM_CODE_COLUMN: source_table.source_system,
                    SparkTransformMixin.EXTRACTION_TIMESTAMP_COLUMN: datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    SparkTransformMixin.LOAD_ID_COLUMN: load_id,
                }
                df_results = self.add_system_columns(df_merged, system_column_values)

                #Logs a list of the columns and data types for debugging data type mismatches with RedShift.
                self.logger.info(f"Table Schema '{source_table_name}': {df_results.dtypes}")

                #TODO: Consider caching the DataFrame if we will be filtering it for >2 regions &/or we're doing lots of joins 
                #if len(self.data_regions) > 2 and len(source_table.relationships) > ?:
                #    df_results.cache()

                self.logger.info(f"Starting regional data filtering for table '{source_table_name}'...")
                for data_region in self.data_regions:
                    self.logger.info(f"Writing table '{source_table_name}' for data region '{data_region}'...")
                    if source_table.filter_by_region:
                        df_filtered_results = self.filter_data_frame_by_region(df_results, data_region)
                    else:
                        df_filtered_results = self.add_system_columns(df_results, {SparkTransformMixin.DATA_REGION_COLUMN: data_region})
                
                    #Add runtime params as extra tags
                    self.regional_writers[data_region].s3_tags["load_id"] = load_id
                    self.regional_writers[data_region].s3_tags["x_amzn_trace_id"] = xray_traceid
                    self.regional_writers[data_region].write(table_info=source_table, 
                                                             target_data_frame=df_filtered_results, 
                                                             spark=self.spark, 
                                                             logger=self.logger,
                                                             sns_topic=self.sns_topic,
                                                             xray_traceid=xray_traceid,
                                                             load_id=load_id)
                    self.logger.info(f"Table '{source_table_name}' exported successfully to region '{data_region}'.")

                self.logger.info(f"Finished processing source table '{source_table_name}'.") 


            if self.enable_xray_tracing: 
                self.end_sub_segment()
            self.logger.info(f"Finished processing Source System: [{ source_system.name }].")

        #End
        if self.enable_xray_tracing: 
            self.end_xray_trace()

        #Tidy up
        self.logger.info("De-allocating cached data frames...")
        for df in data_frame_cache.values():
            df.unpersist()

        self.logger.info("Job Finished!")   