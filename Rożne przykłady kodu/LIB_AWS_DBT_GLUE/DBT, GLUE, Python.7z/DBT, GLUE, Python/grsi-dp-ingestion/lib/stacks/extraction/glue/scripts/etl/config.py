import boto3
import json
from typing import Dict, List
from .shared import ChildTableInfo, FilterInfo, SourceSystemInfo, TableInfo

from pyspark.sql import DataFrame


class S3Config:
    def __init__(
        self,
        glue_context,
        glue_script_bucket_name,
    ) -> None:
        self.glue_context = glue_context
        self.bucket_name = glue_script_bucket_name
        self.s3_client = boto3.client("s3")

    def get_json_config(self, source: str):
        response = self.s3_client.get_object(
            Bucket=self.bucket_name, Key=f"config/{source}_extract.json"
        )
        content = response["Body"]
        return json.loads(content.read())

    def get_branch_codes(self) -> DataFrame:
        return self.glue_context.create_dynamic_frame.from_options(
            connection_type="s3",
            connection_options={
                "paths": [f"s3://{self.bucket_name}/config/branchcodes.csv"]
            },
            format="csv",
            format_options={
                "withHeader": True,
            },
        ).toDF()

    def get_genius_policy_filter_components(self) -> Dict[str, List]:
        genius_policy_filter_components = {}

        response = self.s3_client.get_object(
            Bucket=self.bucket_name, Key="config/genius_policy_filter_components.json"
        )
        content = response["Body"]
        genius_policy_filter_components = json.loads(content.read())
        return genius_policy_filter_components

    def get_claim_center_filter_components(self) -> Dict[str, List]:
        claim_center_filter_components = {}

        response = self.s3_client.get_object(
            Bucket=self.bucket_name, Key="config/claim_center_filter_components.json"
        )
        content = response["Body"]
        claim_center_filter_components = json.loads(content.read())
        return claim_center_filter_components

    def get_table_info_dict(self, source_system_name) -> Dict[str, TableInfo]:
        table_infos = {}

        def add_item(
            source, database_name, schema, name, write, alias, table_path, enabled, relationships
        ):
            table_infos[name] = TableInfo(
                source, database_name, schema, name, write, alias, table_path, enabled, relationships
            )

        table_data = self.get_json_config(source_system_name)
        source = table_data["source"]
        database_name = table_data["database_name"]
        schema = table_data["schema"]
        for table in table_data["tables"]:
            if database_name == "genius":
                prefix = table['name'].split('_')[0]
                schema_ref = table['name'].replace(prefix, prefix.upper())
                table_path = f"distill-delta/{database_name}/{schema_ref}/{table['name']}"
            else:
                table_path = f"distill-delta/{database_name}/{table['name']}/{table['name']}"

            relationships = []
            if "relationships" in table:
                for relationship in table["relationships"]:
                    relationships.append(
                        ChildTableInfo(
                            relationship["child_table"],
                            relationship["join_type"],
                            relationship["join_condition"],
                            relationship["alias"],
                        )
                    )

            add_item(
                source,
                database_name,
                schema,
                table["name"],
                table["write"],
                table["alias"],
                table_path,
                True if table["enabled"].lower() == "y" else False,
                relationships,
            )

        return table_infos

    def get_source_systems_info_dict(self) -> Dict[str, SourceSystemInfo]:
        source_system_infos = {}

        def add_item(name: str, enabled: bool, filters: List[FilterInfo]):
            source_system_infos[name] = SourceSystemInfo(name, enabled, filters)

        source_system_data = self.get_json_config("source_system")

        for source_system in source_system_data:
            filters = []
            if "filters" in source_system:
                for data_filter in source_system["filters"]:
                    filters.append(
                        FilterInfo(
                            data_filter["name"],
                            True if data_filter["enabled"].lower() == "y" else False,
                            data_filter["order"],
                        )
                    )

            add_item(
                source_system["name"],
                True if source_system["enabled"].lower() == "y" else False,
                filters,
            )
        return source_system_infos
