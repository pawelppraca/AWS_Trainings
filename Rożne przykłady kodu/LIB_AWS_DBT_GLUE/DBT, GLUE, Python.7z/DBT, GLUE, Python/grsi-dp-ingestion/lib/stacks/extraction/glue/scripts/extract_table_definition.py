import sys
import boto3

from abc import ABC, abstractmethod
from awsglue.context import GlueContext
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from datetime import datetime

glueContext = GlueContext(SparkContext.getOrCreate())
spark = glueContext.spark_session
spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")
spark.sql("set spark.sql.legacy.parquet.int96RebaseModeInWrite=CORRECTED")
spark.sql("set spark.sql.caseSensitive=false")
logger = glueContext.get_logger()

global_source_schema = "claimcenter"
global_table_name = "ccx_ext_ClaimEvent"

class Extractor(ABC):
    @abstractmethod
    def extract(self, table_name):
        pass

class SparkExtractor(Extractor):
    def __init__(self, spark, src_jdbc_conf, source_db):
        self.spark = spark
        self.src_jdbc_conf = src_jdbc_conf
        self.source_db = source_db

    def extract(self, extract_query):
        src_df = (
            self.spark.read.format("jdbc")
            .option("url", f'{self.src_jdbc_conf.get("url")};database={self.source_db}')
            .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
            .option("query", extract_query)
            .option("user", self.src_jdbc_conf.get("user"))
            .option("password", self.src_jdbc_conf.get("password"))
            .load()
        )
        return src_df

args = getResolvedOptions(
    sys.argv,
    [
        "JOB_NAME",
        "AWS_REGION",
        "ACCOUNT_ID",
        "APP_ENV",
    ],
)

environment = args["APP_ENV"]
region = args["AWS_REGION"]
acc_id = args["ACCOUNT_ID"]
bilz_connection = "GeniusAnalyticalRep-RDS-test"

s3 = boto3.resource("s3")
source_jdbc_conf = glueContext.extract_jdbc_conf(connection_name=bilz_connection)
source_db = "bi_lz"

def get_table_structure():
    table = f"{global_source_schema}.{global_table_name}"
    table_structure = extractor.extract(f"SELECT LOWER(c.name) AS column_name, t.Name data_type, c.max_length max_length, c.precision, c.scale, c.is_nullable, ISNULL(i.is_primary_key, 0) primary_key FROM sys.columns c INNER JOIN sys.types t ON c.user_type_id = t.user_type_id LEFT OUTER JOIN sys.index_columns ic ON ic.object_id = c.object_id AND ic.column_id = c.column_id LEFT OUTER JOIN sys.indexes i ON ic.object_id = i.object_id AND ic.index_id = i.index_id WHERE c.object_id = OBJECT_ID('{table}')")
    return table_structure.toPandas()

def get_col_type(data_type, max_length, precision, scale):    
    col_conversion = {
        'bit': 'boolean',
        'datetime2': 'timestamp',
        'varchar': f"{data_type}({max_length})",
        'decimal': f"{data_type}({precision},{scale})",
        'numeric': f"{data_type}({precision},{scale})",
        'geography' : 'varchar(255)'
    }
    return col_conversion.get(data_type,data_type)

def get_changeset_col_args(col_name, col_type, is_nullable, primary_key):
    constraint_str = f"""constraints:"""
    changeset_str = f"""- column:
            name: {col_name}
            type: {col_type}"""
    if primary_key:
        constraint_str = f"""{constraint_str}
                primaryKey: true"""
    if not is_nullable:
        constraint_str = f"""{constraint_str}
                nullable: false"""
    if primary_key or not is_nullable:
        changeset_str = f"""{changeset_str}
            {constraint_str}"""
    return changeset_str

def get_target_schema(source_schema):
    schema_naming = {
      'ClaimCenter': 'claim_center'      
    }
    return f"staging_{schema_naming.get(source_schema, source_schema)}"

def get_table_changeset(table_name, changeset_cols_str, schema_name, author):
    return f"""databaseChangeLog:
- changeSet:
    id: {table_name}-{datetime.now().strftime('%Y-%m-%d_%H:%M')}
    author: {author}
    changes:
    - dropTable:
        schemaName: {schema_name}
        tableName: {table_name}
    - createTable:
        schemaName: {schema_name}
        tableName: {table_name}
        columns: {changeset_cols_str}
        {add_default_col()}
---"""

def add_default_col():
    return f"""- column:
            name: x_amzn_trace_id
            type: varchar(36)
            defaultValue: temp_default
        - column:
            constraints:
                nullable: false
            name: __source_system_code
            type: varchar(255)
        - column:
            constraints:
                nullable: false
            name: __extraction_date_time
            type: timestamp
        - column:
            constraints:
                nullable: false
            name: __load_id
            type: bigint
        - column:
            constraints:
                nullable: false
            name: __data_region
            type: varchar(100)"""

extractor = SparkExtractor(spark, source_jdbc_conf, source_db)

target_db = f"grsi_dp_{environment}",
# source_schema = "claimcenter"
target_schema = "staging"
table_prefix = "claim_center"
# table_name = "ccx_ext_ClaimEvent"
author = "table_definition_glue_job"

source_table = f"{source_db}_{global_source_schema}_{global_table_name}"
s3_location = f"{source_db}/{table_prefix}/{global_table_name}/"

logger.info(f"Testing connection to: {global_source_schema}.{global_table_name}")

all_table_changesets = ''
logger.info(f"{global_source_schema}.{global_table_name}")  
tableDF = get_table_structure()
changeset_cols_str = ''
for index, row in tableDF.iterrows():
    col_type = get_col_type(row['data_type'],row['max_length'],row['precision'],row['scale'])
    changeset_col_args = get_changeset_col_args(row['column_name'], col_type, row['is_nullable'], row['primary_key'])
    changeset_cols_str = f"""{changeset_cols_str}
        {changeset_col_args}"""
    target_schema = get_target_schema(global_source_schema)

all_table_changesets = f"""{all_table_changesets}
{get_table_changeset(global_table_name, changeset_cols_str, target_schema, author)}"""

logger.info(all_table_changesets)
