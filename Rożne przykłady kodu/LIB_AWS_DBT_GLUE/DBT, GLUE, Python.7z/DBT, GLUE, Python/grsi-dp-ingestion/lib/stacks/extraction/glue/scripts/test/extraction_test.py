# Commenting this test out as we are holding off on glue/python testing 
# Keeping this for when that time comes rather than starting from scratch
# from mock import patch
# import pytest
# from pyspark.context import SparkContext
# from awsglue.context import GlueContext
# from awsglue.dynamicframe import DynamicFrame

# # from etl.extract import (
# #     Extractor,
# #     ExtractorType,
# #     S3Extractor,
# #     TableInfo,
# # )
# # from etl.write import S3Writer
# from etl.config import S3Config

# # from etl.xray import XRayHelper
# import boto3
# from moto import mock_s3
# from moto.server import ThreadedMotoServer
# import os
# import json

# SOURCE_BUCKET = "pytest-source-bucket"
# INGESTION_BUCKET = "pytest-ingestion-bucket"
# REGION = "eu-west-1"

# ORG_GUID = "org1234"
# TROUX_UID = "troux1234"
# DEPLOYMENT_GUID = "deploy1234"
# LOAD_ID = 1234


# @pytest.fixture(scope="session")
# def moto_server():
#     """
#     Function to start moto server
#     """
#     server = ThreadedMotoServer()
#     server.start()
#     yield server
#     server.stop()


# @pytest.fixture(scope="session")
# def s3_client(moto_server):
#     """
#     Function to create mock S3 infrastructure
#     """
#     with mock_s3():
#         s3_client = boto3.client(
#             "s3", region_name=REGION, endpoint_url="http://localhost:5000"
#         )
#         s3_client.create_bucket(
#             Bucket=INGESTION_BUCKET,
#             CreateBucketConfiguration={"LocationConstraint": REGION},
#         )
#         s3_client.create_bucket(
#             Bucket=SOURCE_BUCKET,
#             CreateBucketConfiguration={"LocationConstraint": REGION},
#         )
#         yield s3_client


# @pytest.fixture(scope="session")
# def spark_create(moto_server):
#     """Fixture for creating a spark context"""

#     spark_context = SparkContext()
#     glue_context = GlueContext(spark_context)
#     spark_session = glue_context.spark_session
#     spark_session.sql("set spark.sql.parquet.int96RebaseModeInWrite=CORRECTED")

#     hadoop_conf = spark_session._jsc.hadoopConfiguration()
#     hadoop_conf.set("fs.s3.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
#     hadoop_conf.set("fs.s3a.access.key", "mock")
#     hadoop_conf.set("fs.s3a.secret.key", "mock")
#     hadoop_conf.set("fs.s3a.endpoint", "http://localhost:5000")

#     yield spark_context, glue_context, spark_session,

#     if spark_context is not None:
#         spark_context.stop()


# @pytest.fixture(scope="session")
# def get_sample_dataframe(spark_create):
#     """
#     Function to create a sample dataframe
#     """
#     (
#         spark_context,
#         glue_context,
#         spark_session,
#     ) = spark_create
#     columns = [
#         "studentID",
#         "firstname",
#         "lastname",
#         "address",
#         "city",
#         "state",
#         "courseID",
#     ]
#     data = [
#         (1, "SD", "K", "ndqekjhew", "Pune", "MH", "123"),
#         (2, "PD", "A", "ndqekjhew", "Pune", "MH", "123"),
#         (3, "AJ", "S", "ndqekjhew", "Pune", "MH", "123"),
#     ]
#     df = spark_session.createDataFrame(data).toDF(*columns)
#     yield df


# def load_claim_center_json():
#     test_folder_root = os.path.dirname(os.path.abspath(__file__))
#     file = os.path.join(test_folder_root, "claim_center_extract.json")
#     f = open(file)
#     return json.load(f)


# def get_dynamic_frame_from_s3_ingestion(glue_context, path):
#     return glue_context.create_dynamic_frame.from_options(
#         connection_type="s3",
#         connection_options={"paths": [f"s3://{INGESTION_BUCKET}/{path}"]},
#         format="parquet",
#     )


# def write_dynamic_frame_to_s3_source(glue_context, path, data_frame):
#     glue_context.write_dynamic_frame.from_options(
#         frame=DynamicFrame.fromDF(data_frame, glue_context, "test").coalesce(1),
#         connection_type="s3",
#         connection_options={"path": f"s3://{SOURCE_BUCKET}/{path}"},
#         format="parquet",
#     )


# @pytest.mark.usefixtures("s3_client", "spark_create")
# @patch("etl.config.S3Config.get_json_config", return_value=load_claim_center_json())
# class TestS3Config:
#     def test_table_info_dict_table_length(mock_contexts, s3_client, spark_create):
#         (spark_context, glue_context, spark_session) = spark_create
#         s3Config = S3Config(glue_context, "pytest-bucket")
#         assert len(s3Config.get_table_info_dict("claim_center")) == 61

#     def test_table_info_dict_cc_claim(mock_contexts, s3_client, spark_create):
#         (spark_context, glue_context, spark_session) = spark_create
#         s3Config = S3Config(glue_context, "pytest-bucket")
#         cc_claim_table_info = s3Config.get_table_info_dict("claim_center").get(
#             "cc_claim"
#         )

#         assert cc_claim_table_info.source == "claim_center"
#         assert cc_claim_table_info.database_name == "gcc"
#         assert cc_claim_table_info.schema == "claim_center"
#         assert cc_claim_table_info.table_name == "cc_claim"
#         assert cc_claim_table_info.alias == "clm"

#     def test_table_info_dict_cc_claim_relationship(
#         mock_contexts, s3_client, spark_create
#     ):
#         (spark_context, glue_context, spark_session) = spark_create
#         s3Config = S3Config(glue_context, "pytest-bucket")
#         cc_claim_table_info = s3Config.get_table_info_dict("claim_center").get(
#             "cc_claim"
#         )

#         assert len(cc_claim_table_info.relationships) == 1

#         cc_claim_child_table = cc_claim_table_info.relationships[0]
#         assert cc_claim_child_table.table_name == "claims_filter"
#         assert cc_claim_child_table.join_type == "inner"
#         assert cc_claim_child_table.join_condition == "clm.id = claims_filter.claimid"
#         assert cc_claim_child_table.alias == "claims_filter"

#     def test_table_info_dict_multiple_relationships(
#         mock_contexts, s3_client, spark_create
#     ):
#         (spark_context, glue_context, spark_session) = spark_create
#         s3Config = S3Config(glue_context, "pytest-bucket")
#         cc_claim_table_info = s3Config.get_table_info_dict("claim_center").get(
#             "cc_policy"
#         )

#         assert len(cc_claim_table_info.relationships) == 2

#         cc_claim_child_table = cc_claim_table_info.relationships[0]
#         assert cc_claim_child_table.table_name == "cc_claim"
#         assert cc_claim_child_table.join_type == "inner"
#         assert cc_claim_child_table.join_condition == "pol.id = clm.policyid"
#         assert cc_claim_child_table.alias == "clm"

#         cc_claim_child_table = cc_claim_table_info.relationships[1]
#         assert cc_claim_child_table.table_name == "claims_filter"
#         assert cc_claim_child_table.join_type == "inner"
#         assert cc_claim_child_table.join_condition == "clm.id = claims_filter.claimid"
#         assert cc_claim_child_table.alias == "claims_filter"


# # @pytest.mark.usefixtures("s3_client", "spark_create", "get_sample_dataframe")
# # class TestS3Writer:
# #     def test_add_system_columns(mock_contexts, spark_create, get_sample_dataframe):
# #         (spark_context, glue_context, spark_session) = spark_create
# #         data_frame = get_sample_dataframe
# #         xray_helper = XRayHelper("test")
# #         s3_writer = S3Writer(
# #             glue_context,
# #             INGESTION_BUCKET,
# #             xray_helper,
# #             LOAD_ID,
# #             REGION,
# #             ORG_GUID,
# #             TROUX_UID,
# #             DEPLOYMENT_GUID,
# #         )
# #         source = "test_source"
# #         table_info = TableInfo(
# #             source, "test_db", "test_schema", "test_table_name", "test", True, []
# #         )
# #         data_frame = s3_writer.add_system_columns(table_info, data_frame)
# #         count = data_frame.count()

# #         assert (
# #             count
# #             == data_frame.filter(
# #                 data_frame["x_amzn_trace_id"] == xray_helper.trace_id()
# #             ).count()
# #         )
# #         assert (
# #             count
# #             == data_frame.filter(data_frame["__source_system_code"] == source).count()
# #         )
# #         assert count == data_frame.filter(data_frame["__load_id"] == LOAD_ID).count()
# #         assert count == data_frame.filter(data_frame["__data_region"] == REGION).count()
# #         # TODO add timestamp test

# #         d_types = dict(data_frame.dtypes)

# #         assert d_types["x_amzn_trace_id"] == "string"
# #         assert d_types["__source_system_code"] == "string"
# #         assert d_types["__load_id"] == "int"
# #         assert d_types["__data_region"] == "string"
# #         assert d_types["__extraction_date_time"] == "timestamp"

# # def test_write_to_s3(mock_contexts, spark_create, get_sample_dataframe):
# #     (spark_context, glue_context, spark_session) = spark_create
# #     data_frame = get_sample_dataframe
# #     xray_helper = XRayHelper("test")
# #     s3_writer = S3Writer(
# #         glue_context,
# #         INGESTION_BUCKET,
# #         xray_helper,
# #         LOAD_ID,
# #         REGION,
# #         ORG_GUID,
# #         TROUX_UID,
# #         DEPLOYMENT_GUID,
# #     )
# #     (source, table_name) = ("test_source", "test_table_name")
# #     table_info = TableInfo(
# #         source, "test_db", "test_schema", table_name, "test", True, []
# #     )
# #     s3_writer.write(table_info, data_frame)

# #     assert (
# #         get_dynamic_frame_from_s3_ingestion(
# #             glue_context, f"{source}/{table_name}"
# #         ).count()
# #         > 0
# #     )

# # def test_write_tags(mock_contexts, spark_create, get_sample_dataframe, s3_client):
# #     (spark_context, glue_context, spark_session) = spark_create
# #     # given
# #     data_frame = get_sample_dataframe
# #     xray_helper = XRayHelper("test")
# #     s3_writer = S3Writer(
# #         glue_context,
# #         INGESTION_BUCKET,
# #         xray_helper,
# #         LOAD_ID,
# #         REGION,
# #         ORG_GUID,
# #         TROUX_UID,
# #         DEPLOYMENT_GUID,
# #     )
# #     (source, table_name) = ("test_source", "test_tags")
# #     table_info = TableInfo(
# #         source, "test_db", "test_schema", table_name, "test", True, []
# #     )
# #     # when
# #     s3_writer.write(table_info, data_frame)

# #     temporary_files = s3_client.list_objects_v2(
# #         Bucket=INGESTION_BUCKET, Prefix=f"{source}/{table_name}"
# #     )
# #     temporary_file = temporary_files["Contents"][0]
# #     response = s3_client.get_object_tagging(
# #         Bucket=INGESTION_BUCKET, Key=temporary_file["Key"]
# #     )
# #     tag_set = {i["Key"]: i["Value"] for i in response["TagSet"]}

# #     # then
# #     assert tag_set["x_amzn_trace_id"] == xray_helper.trace_id()
# #     assert tag_set["organization_guid"] == ORG_GUID
# #     assert tag_set["lm_troux_uid"] == TROUX_UID
# #     assert tag_set["load_id"] == str(LOAD_ID)
# #     assert tag_set["deployment_guid"] == DEPLOYMENT_GUID

# # def test_write_with_no_rows(mock_contexts, spark_create, get_sample_dataframe):
# #     (spark_context, glue_context, spark_session) = spark_create
# #     xray_helper = XRayHelper("test")
# #     s3_writer = S3Writer(
# #         glue_context,
# #         INGESTION_BUCKET,
# #         xray_helper,
# #         LOAD_ID,
# #         REGION,
# #         ORG_GUID,
# #         TROUX_UID,
# #         DEPLOYMENT_GUID,
# #     )
# #     (source, table_name) = ("test_source", "test_no_rows")
# #     table_info = TableInfo(
# #         source, "test_db", "test_schema", table_name, "test", True, []
# #     )
# #     data_frame = get_sample_dataframe
# #     data_frame = data_frame.filter(data_frame.studentID == -1)

# #     s3_writer.write(table_info, data_frame)

# #     assert (
# #         get_dynamic_frame_from_s3_ingestion(
# #             glue_context, f"{source}/{table_name}"
# #         ).count()
# #         == 0
# #     )


# # @pytest.mark.usefixtures("s3_client", "spark_create", "get_sample_dataframe")
# # class TestS3Extractor:
# #     def test_extractor_factory_selector(mock_contexts, spark_create):
# #         (spark_context, glue_context, spark_session) = spark_create
# #         extractor = Extractor(glue_context, ExtractorType.S3, "test-bucket", None, None)
# #         assert isinstance(extractor.extractor, S3Extractor)

# #     def test_extract_from_s3(mock_contexts, spark_create, get_sample_dataframe):
# #         (spark_context, glue_context, spark_session) = spark_create
# #         # given
# #         (database_name, schema, table_name) = (
# #             "test_db",
# #             "test_schema",
# #             "test_table_name",
# #         )
# #         table_path = f"{database_name}/{schema}/{table_name}"
# #         table_info = TableInfo(
# #             "test_source", database_name, schema, table_name, "test", True, []
# #         )
# #         data_frame = get_sample_dataframe
# #         write_dynamic_frame_to_s3_source(glue_context, table_path, data_frame)

# #         s3_extractor = S3Extractor(glue_context, SOURCE_BUCKET, [table_info], None)

# #         # when
# #         dynamic_frame = s3_extractor.extract(table_info)

# #         # then
# #         assert dynamic_frame.count() == 3
# #         assert len(dynamic_frame.columns) == 7
