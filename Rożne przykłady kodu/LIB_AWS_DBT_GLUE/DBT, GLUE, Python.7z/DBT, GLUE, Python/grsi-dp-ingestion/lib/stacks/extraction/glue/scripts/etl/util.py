import logging
from awsglue.context import GlueContext
from pyspark.context import SparkContext
from pyspark.conf import SparkConf
import boto3

msg_format = "%(asctime)s %(levelname)s %(name)s: %(message)s"
datetime_format = "%Y-%m-%d %H:%M:%S"
logging.basicConfig(level=logging.INFO, format=msg_format, datefmt=datetime_format)
py_logger = logging.getLogger(__name__)


class GlueLogger:
    """
    wrapper class for the AWS Glue Logger to log any application-specific messages in the script
    that are sent in real time to the driver log stream.
    """

    def __init__(self, glue_context):
        self.logger = glue_context.get_logger()

    """
    Dynamically return underlying Method for Glue Logger with String Representation of args
    """

    def __getattr__(self, k):
        def wrapper(*args, **kwargs):
            return getattr(self.logger, k)(*[repr(a) for a in args], **kwargs)

        return wrapper


class GlueJobUtil:
    @staticmethod
    def get_region_code(region) -> str:
        """
        :param region: AWS region string e.g. 'us-east-1'
        :return: Region code e.g. 'us'
        """
        region_code = region[0:2]
        return region_code

    @staticmethod
    def get_assumed_region_session(
        app_env,
        assume_role_prefix,
        region,
        account_number,
    ) -> boto3.session.Session:
        """
        Assume the cross-account role and return a boto3 session for the corresponding region to create clients and resources
        :param account_number: Account number of the region that the Role to assume is in
        :param app_env: The Environment
        :param region: The AWS region, e.g. 'us-east-1' or 'eu-west-1'
        :param assume_role_prefix:  Role prefix to use  for assumption
        :return:
        """
        region_code = GlueJobUtil.get_region_code(region)
        assume_role = f"arn:aws:iam::{account_number}:role/{assume_role_prefix}-{region_code}-{app_env}"
        sts = boto3.client("sts")
        assume_response = sts.assume_role(
            RoleArn=assume_role, RoleSessionName="glueAssumeRole"
        )

        session = boto3.session.Session(
            region_name=region,
            aws_access_key_id=assume_response["Credentials"]["AccessKeyId"],
            aws_secret_access_key=assume_response["Credentials"]["SecretAccessKey"],
            aws_session_token=assume_response["Credentials"]["SessionToken"],
        )
        return session

    @staticmethod
    def get_hadoop_fs_kms_config_from_ssm(
        app_env, bucket, region, kms_key_ssm_param_prefix, boto_session
    ) -> list[tuple]:
        """
        Static function to use Boto3 to assume cross-account role and retrieve SSM Parameter
        :param boto_session:
        :param app_env: The Environment
        :param region: The AWS region, e.g. 'us-east-1' or 'eu-west-1'
        :param bucket:  Name of the bucket for config
        :param kms_key_ssm_param_prefix: Name of the SSM Parameter containing the desired KMS ARN value
        :return: List of Spark config tuples for desired bucket and environment
        """
        region_code = GlueJobUtil.get_region_code(region)

        kms_key_ssm_param = "-".join([kms_key_ssm_param_prefix, region_code, app_env])

        # The Glue Logger is not available at this point --> log to default python logger
        py_logger.info(
            f"Getting KMS Param {kms_key_ssm_param} for region {region_code}"
        )

        ssm = boto_session.client("ssm")
        ssm_response = ssm.get_parameter(Name=kms_key_ssm_param, WithDecryption=True)

        return [
            (
                f"spark.hadoop.fs.s3a.bucket.{bucket}-{region_code}-{app_env}.server-side-encryption.key",
                ssm_response["Parameter"]["Value"],
            ),
            (
                f"spark.hadoop.fs.s3a.{bucket}-{region_code}-{app_env}.server-side-encryption-algorithm",
                "SSE-KMS",
            ),
        ]
        
    @staticmethod
    def create_contexts(
        app_env: str,
        region_info: dict,
        bucket: str,
        assume_role_prefix: str,
        kms_key_ssm_param_prefix: str,
        datalake_bucket: str, 
        datalake_credentials: dict,
    ):
        """
        Static Function to create SparkContext, GlueContext, SparkSession objects
        :return spark_context: SparkContext object
        :return glue_context: SparkContext object
        :return spark_session: SparkSession object
        """
        sparkConfig = [
            (
                "spark.hadoop.fs.s3a.server-side-encryption.key",
                "",
            ),
            (
                "spark.hadoop.fs.s3a.server-side-encryption-algorithm",
                "SSE-KMS",
            ),
            (
                "spark.sql.catalog.spark_catalog",
                "org.apache.spark.sql.delta.catalog.DeltaCatalog",
            ), 
            (
                "spark.delta.logStore.class",
                "org.apache.spark.sql.delta.storage.S3SingleDriverLogStore",
            ), 
            (
                f"fs.s3a.bucket.{datalake_bucket}.access.key",
                datalake_credentials['AccessKeyId']
            ),
            (
                f"fs.s3a.bucket.{datalake_bucket}.secret.key",
                datalake_credentials['SecretAccessKey']
            ),
            (
                f"fs.s3a.bucket.{datalake_bucket}.session.token",
                datalake_credentials['SessionToken']
            ),
            (
                f"fs.s3a.bucket.{datalake_bucket}.assumed.role.credentials.provider",
                "org.apache.hadoop.fs.s3a.TemporaryAWSCredentialsProvider"
            ),
        ]

        # Generate additional Spark config per bucket per region
        for region, account_number in region_info.items():
            assumed_session = GlueJobUtil.get_assumed_region_session(
                app_env=app_env,
                region=region,
                assume_role_prefix=assume_role_prefix,
                account_number=account_number,
            )
            sparkConfig.extend(
                GlueJobUtil.get_hadoop_fs_kms_config_from_ssm(
                    app_env=app_env,
                    bucket=bucket,
                    region=region,
                    kms_key_ssm_param_prefix=kms_key_ssm_param_prefix,
                    boto_session=assumed_session,
                )
            )
        config = SparkConf().setAll(sparkConfig)
        spark_context = SparkContext.getOrCreate(config)
        glue_context = GlueContext(spark_context)
        spark_session = glue_context.spark_session
        spark_session.sql("set spark.sql.parquet.int96RebaseModeInWrite=CORRECTED")
        spark_session.sql("set spark.sql.caseSensitive=false")
        return spark_context, glue_context, spark_session

    @staticmethod
    def create_logger(glue_context):
        return GlueLogger(glue_context)
