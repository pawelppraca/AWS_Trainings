from typing import List, Dict

from pyspark.sql import SparkSession, DataFrame

from etl.shared import DataRegion
from etl.filtering.base import BaseDataFilter
from etl.util import GlueLogger


class WarehouseRepoDataFilter(BaseDataFilter):

    def __init__(
         self,
         filter_name: str,
         data_regions: List[DataRegion]
    ) -> None:
        
        super().__init__(
            filter_name=filter_name, 
            data_regions = data_regions
        )

    def get_data_frame(self, spark: SparkSession, source_data_frames: Dict[str, DataFrame], logger: GlueLogger) -> DataFrame:

        return source_data_frames.get("warehouse_repo_region_mappings")