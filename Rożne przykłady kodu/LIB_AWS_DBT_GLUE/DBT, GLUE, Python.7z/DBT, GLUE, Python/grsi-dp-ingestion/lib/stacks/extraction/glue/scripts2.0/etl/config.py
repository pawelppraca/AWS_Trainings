import json
from typing import List, Dict
from copy import copy

from .shared import (
    SourceSystemInfo, 
    TableInfo, 
    ChildTableInfo,
    FilterInfo,
    DataFilterType,
    TabularDataSet
)

class ConfigManager:

    @staticmethod
    def get_tabular_dataset_from_json(dataset_name: str, json_data: str) -> TabularDataSet:
        data_dict = json.loads(json_data)
        return TabularDataSet(name=dataset_name, rows=data_dict)

    @staticmethod
    def get_source_system_from_json(text: str) -> SourceSystemInfo:

        data = json.loads(text)

        return SourceSystemInfo(
            name = data['name'],
            enabled = True if data['enabled'].lower() == "y" else False,
            source_tables = ConfigManager.__get_source_tables_from_dict(data),
            data_filters = ConfigManager.__get_data_filters_from_dict(data)
        )
    
    @staticmethod
    def __get_source_tables_from_dict(data) -> Dict[str, TableInfo]:

        source_tables = {}
        source_system_name = data['name']
        for table in data['source_tables']:
            table_name = table['name']
            relationships = []
            if "relationships" in table:
                for relationship in table["relationships"]:
                    relationships.append(
                        ChildTableInfo(
                            relationship["child_table"],
                            relationship["join_type"],
                            relationship["join_condition"],
                            relationship["alias"],
                        )
                    )

            source_tables[table_name] = TableInfo(
                name = table_name,
                table_path = table['table_path'],
                write_name = table['write_name'],
                write_schema=table['write_schema'],
                source_system = source_system_name,
                alias = table['alias'],
                enabled = True if table['enabled'].lower() == "y" else False,
                filter_by_region = True if str(table.get('filter_by_region')).lower() == "y" else False,
                relationships = relationships,
                ignore_columns= copy(table['ignore_columns']) if "ignore_columns" in table else []
            )
 
        return source_tables
    
    @staticmethod
    def __get_data_filters_from_dict(data) -> List[FilterInfo]:

        data_filters = []
        for data_filter in data["filters"]:
            data_filters.append(
                FilterInfo(
                    filter_type = DataFilterType(data_filter["filter_type"]),
                    order = data_filter["order"],
                    source_table_names = copy(data_filter["source_table_names"]),
                    reference_datasets = copy(data_filter["reference_datasets"]),
                    dependent_filters = copy(data_filter["dependent_filters"])
                )
            )

        return data_filters
                

