from abc import ABC, abstractmethod
from datetime import datetime

import boto3
from awsglue.dynamicframe import DynamicFrame
from pyspark.sql import DataFrame
from pyspark.sql.functions import lit, to_timestamp
from .shared import TableInfo
from .xray import XRayHelper
from .util import GlueLogger
from .util import GlueJobUtil


class AbstractWriter(ABC):
    @abstractmethod
    def write(self, table_info: TableInfo, data_frame: DataFrame) -> None:
        pass


class S3Writer(AbstractWriter):
    def __init__(
        self,
        glue_context,
        logger: GlueLogger,
        bucket_name: str,
        xray_helper: XRayHelper,
        load_id: int,
        region_name: str,
        aws_region: str,
        app_env: str,
        organization_guid: str,
        lm_troux_uid: str,
        deployment_guid: str,
        ddb_column_mapping_table_prefix: str,
        region_account_mapping: dict,
        assume_role_prefix: str,
    ) -> None:
        self.glue_context = glue_context
        self.logger = logger
        self.bucket_name = bucket_name
        self.s3_client = boto3.client("s3")
        self.xray_helper = xray_helper
        self.xray_key_prefix = "_xray_temporary/"
        self.load_id = load_id
        self.region_name = region_name
        self.organization_guid = organization_guid
        self.lm_troux_uid = lm_troux_uid
        self.deployment_guid = deployment_guid
        self.ddb_column_mapping_table_prefix = ddb_column_mapping_table_prefix
        self.region_account_mapping = region_account_mapping
        self.aws_region = aws_region
        self.app_env = app_env
        self.assume_role_prefix = assume_role_prefix

    def _move_xray_temporary_files(self, table_path: str) -> None:
        # use boto3 to move output file back to our target key and ensure xray trace http header is propagated
        # find all the temporary files we just wrote
        folder_prefix = f"{self.xray_key_prefix}{table_path}/"
        temporary_files = self.s3_client.list_objects_v2(
            Bucket=self.bucket_name, Prefix=folder_prefix
        )

        self.logger.info(temporary_files)

        # copy to the new location and delete from the old
        try:
            for file in temporary_files["Contents"]:
                if file["Size"]:  # ignores empty folders
                    self.s3_client.copy_object(
                        CopySource={"Bucket": self.bucket_name, "Key": file["Key"]},
                        BucketKeyEnabled=True,
                        Bucket=self.bucket_name,
                        TaggingDirective="REPLACE",
                        Tagging=f"x_amzn_trace_id={self.xray_helper.trace_id()}"
                        f"&organization_guid={self.organization_guid}"
                        f"&lm_troux_uid={self.lm_troux_uid}"
                        f"&load_id={self.load_id}"
                        f"&deployment_guid={self.deployment_guid}",
                        Key=str(file["Key"]).replace(self.xray_key_prefix, ""),
                    )
                    self.s3_client.delete_object(
                        Bucket=self.bucket_name, Key=file["Key"]
                    )
        except KeyError:
            self.logger.info("No x-ray temporary objects found")

    def _write_dynamo_column_mappings(
        self,
        schema: str,
        table_name: str,
        columns: list,
        boto_session: boto3.Session,
        app_env: str,
        aws_region: str,
    ) -> None:
        self.logger.info(
            f"Writing DynamoDB table prefix {self.ddb_column_mapping_table_prefix} column mappings for "
            f"schema: {schema} and table: {table_name} "
            f"in region {aws_region} and env {app_env}"
        )
        ddb_client = boto_session.client("dynamodb")
        target_dynamo_table = "-".join(
            [
                self.ddb_column_mapping_table_prefix,
                GlueJobUtil.get_region_code(aws_region),
                app_env,
            ]
        )
        column_order_entry = ", ".join(columns)
        try:
            ddb_client.put_item(
                TableName=target_dynamo_table,
                Item={
                    "Table": {"S": table_name},
                    "Schema": {"S": schema},
                    "ColumnOrder": {"S": column_order_entry},
                },
            )
        except Exception as e:
            self.logger.error(
                f"Failed to write Column Mapping to DynamoDB with error: {e}"
            )

    def add_system_columns(
        self, table_info: TableInfo, data_frame: DataFrame
    ) -> DataFrame:
        data_frame = (
            data_frame.withColumn("x_amzn_trace_id", lit(self.xray_helper.trace_id()))
            .withColumn("__source_system_code", lit(table_info.source))
            .withColumn(
                "__extraction_date_time",
                lit(datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            )
            .withColumn(
                "__extraction_date_time",
                to_timestamp("__extraction_date_time", "yyyy-MM-dd HH:mm:ss"),
            )
            .withColumn("__load_id", lit(self.load_id))
            .withColumn("__data_region", lit(self.region_name))
        )
        return data_frame

    def write_filter_csv(self, data_frame, filter_name) -> None:
        self.logger.info(f"Writing filter data frame: {filter_name}")

        if data_frame.isEmpty():
            self.logger.info(f"Filter data frame has no data: {filter_name}!")

        self.glue_context.write_dynamic_frame.from_options(
            frame=DynamicFrame.fromDF(
                data_frame, self.glue_context, filter_name
            ).coalesce(1),
            connection_type="s3",
            connection_options={
                "path": f"s3a://{self.bucket_name}/filter_test/filters/{filter_name}"
            },
            format="csv",
        )

    def write(self, table_info: TableInfo, data_frame: DataFrame) -> None:
        self.logger.info(
            f"Writing table '{table_info.table_name}': "
            f"source='{table_info.source}', "
            f"database_name='{table_info.database_name}', "
            f"schema='{table_info.schema}', "
            f"table_name='{table_info.table_name}'"
            f"write_name='{table_info.write_name}'"
        )

        if data_frame.isEmpty():
            self.logger.info(f"Table [{table_info.table_name}] is empty!")
            return

        data_frame = self.add_system_columns(table_info, data_frame)
        table_path = f"{table_info.source}/{table_info.table_name}_temporary"

        # write with temporary x-ray key
        self.glue_context.write_dynamic_frame.from_options(
            frame=DynamicFrame.fromDF(
                data_frame, self.glue_context, table_info.table_name
            ).coalesce(1),
            connection_type="s3",
            connection_options={
                "path": f"s3a://{self.bucket_name}/{self.xray_key_prefix}{table_path}"
            },
            format="parquet",
        )
        self.logger.info(
            f"Finished writing temporary table files [{table_info.table_name}]."
        )
        assumed_boto_session = GlueJobUtil.get_assumed_region_session(
            app_env=self.app_env,
            account_number=self.region_account_mapping[self.aws_region],
            region=self.aws_region,
            assume_role_prefix=self.assume_role_prefix,
        )
        self._write_dynamo_column_mappings(
            schema=table_info.schema,
            table_name=table_info.write_name,
            columns=data_frame.columns,
            boto_session=assumed_boto_session,
            app_env=self.app_env,
            aws_region=self.aws_region,
        )
        self._move_xray_temporary_files(table_path)
        self.logger.info(
            f"Finished processing temporary files [{table_info.table_name}]."
        )
