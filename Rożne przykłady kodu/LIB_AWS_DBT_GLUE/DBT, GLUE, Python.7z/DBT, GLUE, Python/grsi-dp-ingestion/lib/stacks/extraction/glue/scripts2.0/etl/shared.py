from enum import Enum
from dataclasses import dataclass
from typing import List, Dict, Optional, Any, TypedDict

#Glue V4 Python Shell currently only supports python 3.9 - StrEnum was only added in python 3.11
class DataRegion(str, Enum):
    US = "USA"
    APAC = "APAC"
    LATAM = "LATAM"
    EUROPE = "Europe"

    def __str__(self):
        return self.value
    
    @classmethod
    def list(cls): 
        return list(map(lambda c: c.value, cls)) 

                                
class DataFilterType(str, Enum):
    GCC_CLAIM_FILTER = "gcc_claim_filter"
    GCC_CONTACT_FILTER = "gcc_contact_filter"
    GENIUS_POLICY_FILTER = "genius_policy_filter"
    WR_POLICY_FILTER = "wr_policy_filter"

    def __str__(self):
        return self.value
    
    @classmethod
    def list(cls): 
        return list(map(lambda c: c.value, cls)) 

@dataclass
class ChildTableInfo:
    table_name: str
    join_type: str
    join_condition: str
    alias: str

@dataclass
class TableInfo:
    name: str
    table_path: Optional[str] = None
    write_name: Optional[str] = None
    write_schema: Optional[str] = None
    source_system: Optional[str] = None
    enabled: Optional[bool] = True
    alias: Optional[str] = None
    filter_by_region: Optional[bool] = False
    relationships: Optional[List[ChildTableInfo]] = None
    ignore_columns: Optional[List[str]] = None
     
    def get_child_tables(self, 
                         include: Optional[List[str]]=[], 
                         exclude: Optional[List[str]]=[]) -> List[str]:
    
        """
        Returns a filtered list of child table names that are referenced in sql joins
        :param include: Only include valid table nmes on this list
        :param exclude: Optionally exclude specific tables
        :return: List of child table names
        """
        if not self.relationships:
            return []
        elif include:
            return [child_table.table_name for child_table in self.relationships if child_table.table_name in include if child_table.table_name not in exclude] 
        else:
            return [child_table.table_name for child_table in self.relationships if child_table.table_name not in exclude]


@dataclass
class FilterInfo:
    filter_type: DataFilterType
    order: int
    source_table_names: Optional[List[str]] = None
    reference_datasets: Optional[List[str]] = None
    dependent_filters: Optional[List[str]] = None

@dataclass
class SourceSystemInfo:
    name: str
    enabled: bool
    source_tables: Dict[str, TableInfo]
    data_filters: Optional[List[FilterInfo]] = None

    def __post_init__(self):
        self._validate()

    def _validate(self):
        """Validate the configuration data.  

        :raises ValueError: If the configuration fails validation.
        """
        if self.data_filters:
            for data_filter in self.data_filters:
                #Ensure the source_table_names specified in the filters are defined in the source_tables node.
                missing_tables = [table_name for table_name in data_filter.source_table_names if table_name not in self.source_tables]
                if missing_tables:
                    raise ValueError(
                        f"Error loading config data for Source System: '{self.name}', Data Filter: '{data_filter.filter_type}'. Source table(s): {missing_tables} are missing or disabled."
                    )
                elif data_filter.filter_type not in DataFilterType.list():
                    raise ValueError(
                        f"Error loading config data for Source System: '{self.name}', invalid data filter type: '{data_filter.filter_type}'"
                    )
                elif any(x not in DataFilterType.list() for x in data_filter.dependent_filters):
                    raise ValueError(
                        f"Error loading config data for Source System: '{self.name}', Data Filter: '{data_filter.filter_type}'.  One of the dependent data filter types is NOT valid {data_filter.dependent_filters}."
                    )


@dataclass
class TabularDataSet:
    name: str
    rows: List[Any]
    column_names: Optional[List[str]] = None

class ColumnOrdering(TypedDict): 
    Table: str 
    Schema: str
    ColumnOrder: str



