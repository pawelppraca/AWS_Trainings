from typing import Optional, Dict

import boto3
from pyspark.sql import SparkSession, DataFrame

from .base import BaseWriter
from .util import ColumnMappingDynamoDBWriter, DataframeOperations
from etl.shared import TableInfo
from etl.util import GlueLogger, SNSHelper

class S3Writer(BaseWriter):

    def __init__(
        self,
        s3_bucket: str,
        s3_tags: Dict[str, str],
        s3_key_prefix: Optional[str]=None,
        column_mapping_writer: Optional[ColumnMappingDynamoDBWriter]=None
    ) -> None:
        super().__init__(
            column_mapping_writer=column_mapping_writer
        )
        self.s3_bucket = s3_bucket
        self.s3_tags = s3_tags if s3_tags else {}
        self.s3_key_prefix = s3_key_prefix
    
    def _get_tags_as_url_query_string(self) -> str:
        return f"{'&'.join(f'{key}={value}' for key, value in self.s3_tags.items())}"
    
    def _add_slash(self, s):
        return s if s[-1] == "/" else s + "/"
    
    def write(self, 
                table_info: TableInfo,
                target_data_frame: DataFrame,
                spark: SparkSession,
                logger: GlueLogger,
                sns_topic: SNSHelper,
                **kwargs
            ) -> None:


        key_prefix = self._add_slash(self.s3_key_prefix) if self.s3_key_prefix else ""
        table_path = f"{table_info.write_schema}/{table_info.write_name}"
        s3_path = f"s3a://{self.s3_bucket}/{key_prefix}{table_path}"

        is_existing_table = False
        if self._column_mapping_writer:
            column_ordering_item = self._column_mapping_writer.get_item(table_info.write_name, table_info.write_schema)
            if column_ordering_item:
                is_existing_table = True
                target_data_frame = self._prepare_data_for_write(column_ordering_item, target_data_frame, table_info, logger, sns_topic)

        
        logger.info(f"Starting to write table '{table_info.name}' to '{s3_path}'")
        target_data_frame.coalesce(1).write.parquet(s3_path, mode="overwrite")
        logger.info(f"Finished writing temporary files for '{table_info.name}'")
        
        if self._column_mapping_writer:
            logger.info(
                f"Writing column mappings for table: '{table_info.name}', "
                f"schema: '{table_info.write_schema} ', table write name: '{table_info.write_name}' "
                f"to DynamoDB table '{self._column_mapping_writer.dynamo_table_name}' "
                f"in AWS region '{self._column_mapping_writer.aws_region}'"
            )
            self._column_mapping_writer.save_column_mappings(table_info.write_name, table_info.write_schema, target_data_frame.columns, is_existing_table)

        else:
            logger.info(f"Skipping writing column mappings for table '{table_info.name}' as no column writer is defined.")

        
        self._move_temporary_files(table_path, key_prefix, logger)
        logger.info(f"Finished processing temporary files for table '{table_info.name}'")
        
        
    def _move_temporary_files(self, table_path: str, key_prefix: str, logger: GlueLogger) -> None:
        # use boto3 to move output file back to our target key and ensure xray trace http header is propagated
        # find all the temporary files we just wrote
        s3_client = boto3.client("s3")
        folder_prefix = f"{key_prefix}{table_path}"
        temporary_files = s3_client.list_objects_v2(
            Bucket=self.s3_bucket, Prefix=folder_prefix
        )

        #copy to the new location and delete from the old
        try:
            for file in temporary_files["Contents"]:
                if file["Size"]:  # ignores empty folders
                    logger.info(f'Moving and renaming s3 object: {file["Key"]} in {self.s3_bucket}')
                    s3_client.copy_object(
                        CopySource={"Bucket": self.s3_bucket, "Key": file["Key"]},
                        BucketKeyEnabled=True,
                        Bucket=self.s3_bucket,
                        TaggingDirective="REPLACE",
                        Tagging=self._get_tags_as_url_query_string(),
                        Key=str(file["Key"]).replace(key_prefix, ""),
                    )
                    s3_client.delete_object(
                        Bucket=self.s3_bucket, Key=file["Key"]
                    )
        except KeyError:
            logger.info(f"No temporary objects found with key {folder_prefix}")


    def _prepare_data_for_write(self, column_ordering_item, target_data_frame: DataFrame, table_info: TableInfo, logger: GlueLogger, sns_topic: SNSHelper) -> DataFrame:
        if 'ColumnOrder' in column_ordering_item:
            existing_cols = [col.strip() for col in column_ordering_item.get('ColumnOrder').split(',')]
            logger.info(f"Existing columns in source table {table_info.name} : {existing_cols}")
            logger.info(f"Dataframe columns in source table {table_info.name} : {target_data_frame.columns}")

            new_cols = DataframeOperations._get_new_columns(existing_cols, target_data_frame)
            logger.info(f"New column(s) '{new_cols}' detected in source table {table_info.name}...")

            deleted_cols = DataframeOperations._get_deleted_columns(existing_cols, target_data_frame)

            # Check if new columns are in the redshift columns and remove columns to be dropped if they are 
            # in redshift
            if len(new_cols) > 0 and 'RedshiftColumns' in column_ordering_item:
                logger.info(f"Checking if new columns are in redshift...")
                redshift_columns = [col.strip() for col in column_ordering_item.get('RedshiftColumns').lower().split(',')]
                new_cols = [col for col in new_cols if col.lower() not in redshift_columns]
                logger.info(f"New column(s) '{new_cols}' not found in redshift...")

            if len(new_cols) > 0:
                logger.info(f"New column(s) '{new_cols}' detected in source table {table_info.name}...")

                logger.info(f"Sending notification of new columns to sns topic...")
                sns_topic.publish_message(
                    "New columns detected in source table",
                    f"New column(s) '{new_cols}' detected in source table '{table_info.name}'",
                )
                
                logger.info(f"Removing new column(s) '{new_cols}' to ensure consistency with redshift...")
                target_data_frame = target_data_frame.drop(*new_cols)  
            elif len(deleted_cols):
                logger.info(f"Removed column(s) '{deleted_cols}' detected in source table {table_info.name}...")
                
                logger.info(f"Sending notification of removed columns to sns topic...")
                sns_topic.publish_message(
                    "Removed columns detected in source table",
                    f"Removed column(s) '{deleted_cols}' detected in source table '{table_info.name}'",
                )
            else:
                logger.info(f"No new or removed columns detected in source table")

        return target_data_frame