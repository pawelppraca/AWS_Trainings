from abc import ABC, abstractmethod
from typing import Dict
from .shared import (
    DataRegion,
    data_region_dict,
    ExtractorType,
    FilterType,
    TableInfo,
    POLICY_FILTER,
    CLAIMS_FILTER,
    CONTACTS_FILTER,
)
from .extract import Extractor
from .config import S3Config
from .util import GlueLogger

from pyspark.sql import DataFrame
from pyspark.sql.functions import col, lower


class AbstractFilter(ABC):
    @abstractmethod
    def load_filter(self) -> DataFrame:
        pass


class Filter:
    @staticmethod
    def create_filter(
        glue_context,
        spark_session,
        logger: GlueLogger,
        extractor_type: ExtractorType,
        data_source_name: str,
        table_infos: Dict[str, TableInfo],
        app_env: str,
        filter_dataframes: Dict[FilterType, DataFrame],
        region_name: str,
        region_code: str,
        filter_type: FilterType,
    ) -> AbstractFilter:
        if filter_type == FilterType.CLAIMS:
            return ClaimsFilter(
                glue_context,
                spark_session,
                logger,
                extractor_type,
                data_source_name,
                {
                    k: table_infos.get(k)
                    for k in [
                        "cc_claim",
                        "cc_policy",
                        "cctl_ext_losscodeset",
                        "cctl_ext_product",
                        "cc_coverage",
                    ]
                },
                app_env,
                filter_dataframes,
                region_name,
                region_code,
            )

        elif filter_type == FilterType.CONTACTS:
            return ContactsFilter(
                glue_context,
                spark_session,
                logger,
                extractor_type,
                data_source_name,
                {
                    k: table_infos.get(k)
                    for k in [
                        "cc_user",
                        "cc_claim",
                        "cc_contact",
                        "cc_group",
                    ]
                },
                app_env,
                filter_dataframes,
                region_name,
                region_code,
            )

        elif filter_type == FilterType.POLICY:
            return PolicyFilter(
                glue_context,
                spark_session,
                logger,
                extractor_type,
                data_source_name,
                {k: table_infos.get(k) for k in ["zuma"]},
                app_env,
                filter_dataframes,
                region_name,
                region_code,
            )

        else:
            raise NotImplementedError()


class ClaimsFilter(AbstractFilter):
    def __init__(
        self,
        glue_context,
        spark_session,
        logger: GlueLogger,
        extractor_type: ExtractorType,
        data_source_name: str,
        table_infos: Dict[str, TableInfo],
        app_env: str,
        filter_dataframes: Dict[FilterType, DataFrame],
        region_name: str,
        region_code: str,
    ) -> None:
        self.glue_context = glue_context
        self.spark_session = spark_session
        self.logger = logger
        self.claims_filter_table_infos = table_infos
        self.app_env = app_env
        self.region_name = region_name
        self.region_code = region_code
        self.extractor = Extractor(
            spark_session,
            logger,
            extractor_type,
            data_source_name,
            table_infos,
            app_env,
        )

    def _set_full_extract_mode(self) -> None:
        for table_info in self.claims_filter_table_infos.values():
            table_info.relationships = []

    def load_filter(self) -> DataFrame:

        self.logger.info(
            f"Creating Claim Filter Data Frame for region [{self.region_name}] using source tables: {self.claims_filter_table_infos}"
        )

        self._set_full_extract_mode()
        branchcodes_alias = "bc"

        self.logger.info("Claim Filter: Loading reference data...")
        claim_center_filter_components = S3Config(
            self.glue_context, f"grsi-dp-glue-script-{self.region_code}-{self.app_env}"
        ).get_claim_center_filter_components()

        lsm_us_product_codes = claim_center_filter_components["lsm_us_product_codes"]
        lsm_us_class_of_business = claim_center_filter_components[
            "lsm_us_class_of_business"
        ]
        lsm_gts_dept_codes = claim_center_filter_components["lsm_gts_dept_codes"]

        clm_table_info = self.claims_filter_table_infos.get("cc_claim")
        pol_table_info = self.claims_filter_table_infos.get("cc_policy")
        losscodeset_table_info = self.claims_filter_table_infos.get(
            "cctl_ext_losscodeset"
        )
        product_table_info = self.claims_filter_table_infos.get("cctl_ext_product")
        cov_table_info = self.claims_filter_table_infos.get("cc_coverage")

        # TODO: Add Logging prefix e.g. Claim Filter to identify caller
        self.logger.info(
            f"Claim Filter: Loading source table [{clm_table_info.table_name}]"
        )
        df_cc_claim = self.extractor.extract(clm_table_info)
        self.logger.info(
            f"Claim Filter: Loading source table [{pol_table_info.table_name}]"
        )
        df_cc_policy = self.extractor.extract(pol_table_info)

        self.logger.info("Claim Filter: Loading LSM branch codes...")
        df_branchcodes = (
            S3Config(
                self.glue_context,
                f"grsi-dp-glue-script-{self.region_code}-{self.app_env}",
            )
            .get_branch_codes()
            .alias(branchcodes_alias)
        )

        if data_region_dict[self.region_name] == DataRegion.US:
            self.logger.info(
                f"Claim Filter: Loading source table [{losscodeset_table_info.table_name}]"
            )
            df_cctl_ext_losscodeset = (
                self.extractor.extract(losscodeset_table_info)
                .na.fill("")
                .alias(losscodeset_table_info.alias)
            )
            self.logger.info(
                f"Claim Filter: Loading source table [{product_table_info.table_name}]"
            )
            df_cctl_ext_product = (
                self.extractor.extract(product_table_info)
                .na.fill("")
                .alias(product_table_info.alias)
            )
            self.logger.info(
                f"Claim Filter: Loading source table [{cov_table_info.table_name}]"
            )
            df_cc_coverage = (
                self.extractor.extract(cov_table_info)
                .na.fill("")
                .alias(cov_table_info.alias)
            )

            df_claim_ids = (
                (
                    df_cc_claim.join(
                        df_cc_policy,
                        col(f"{clm_table_info.alias}.policyid")
                        == col(f"{pol_table_info.alias}.id"),
                        "inner",
                    )
                    .join(
                        df_branchcodes,
                        lower(col(f"{branchcodes_alias}.branch"))
                        == lower(col(f"{pol_table_info.alias}.ext_geniusbranchcode")),
                        "inner",
                    )
                    .join(
                        df_cctl_ext_losscodeset,
                        col(f"{clm_table_info.alias}.ext_losscodeset")
                        == col(f"{losscodeset_table_info.alias}.id"),
                        "left",
                    )
                    .join(
                        df_cctl_ext_product,
                        col(f"{product_table_info.alias}.id")
                        == col(f"{pol_table_info.alias}.ext_product"),
                        "left",
                    )
                    .join(
                        df_cc_coverage,
                        col(f"{pol_table_info.alias}.id")
                        == col(f"{cov_table_info.alias}.policyid"),
                        "left",
                    )
                    .where(
                        (
                            (lower(col(f"{branchcodes_alias}.region")) == "usa")
                            & lower(col(f"{product_table_info.alias}.typecode")).isin(
                                [pc.lower() for pc in lsm_us_product_codes]
                            )
                        )
                        | (
                            (lower(col(f"{branchcodes_alias}.region")) == "usa")
                            & lower(col(f"{cov_table_info.alias}.ext_sfc2cd")).isin(
                                [cob.lower() for cob in lsm_us_class_of_business]
                            )
                        )
                        | (
                            (lower(col(f"{branchcodes_alias}.region")) == "usa")
                            & lower(
                                col(f"{losscodeset_table_info.alias}.typecode")
                            ).isin([dc.lower() for dc in lsm_gts_dept_codes])
                        )
                    )
                )
                .select(col(f"{clm_table_info.alias}.id").alias("claimid"))
                .distinct()
                .alias(CLAIMS_FILTER)
                .cache()
            )
        elif self.region_name in data_region_dict.keys():
            df_claim_ids = (
                df_cc_claim.join(
                    df_cc_policy,
                    col(f"{clm_table_info.alias}.policyid")
                    == col(f"{pol_table_info.alias}.id"),
                    "inner",
                )
                .join(
                    df_branchcodes,
                    lower(col(f"{branchcodes_alias}.branch"))
                    == lower(col(f"{pol_table_info.alias}.ext_geniusbranchcode")),
                    "inner",
                )
                .where(
                    lower(col(f"{branchcodes_alias}.region"))
                    == self.region_name.lower()
                )
                .select(col(f"{clm_table_info.alias}.id").alias("claimid"))
                .distinct()
                .alias(CLAIMS_FILTER)
                .cache()
            )
        else:
            raise ValueError(f"Claim Filter: Unknown Region {self.region_name}")

        if df_claim_ids.isEmpty():
            self.logger.info("** Claim Filter data frame is empty! **")
        else:
            self.logger.info("Finished loading claim filter data.")

        return df_claim_ids


class ContactsFilter(AbstractFilter):
    def __init__(
        self,
        glue_context,
        spark_session,
        logger: GlueLogger,
        extractor_type: ExtractorType,
        data_source_name: str,
        table_infos: Dict[str, TableInfo],
        app_env: str,
        filter_dataframes: Dict[FilterType, DataFrame],
        region_name: DataRegion,
        region_code: str,
    ) -> None:
        self.glue_context = glue_context
        self.spark_session = spark_session
        self.logger = logger
        self.contacts_filter_table_infos = table_infos
        self.app_env = app_env
        self.filter_dataframes = filter_dataframes
        self.region_name = region_name
        self.region_code = region_code
        self.extractor = Extractor(
            spark_session,
            logger,
            extractor_type,
            data_source_name,
            table_infos,
            filter_dataframes,
            app_env,
        )

    def _set_full_extract_mode(self) -> None:
        for table_info in self.contacts_filter_table_infos.values():
            table_info.relationships = []

    def load_filter(self) -> DataFrame:
        self._set_full_extract_mode()

        self.logger.info(
            f"Creating Contact Filter Data Frame for region [{self.region_name}] using source tables: {self.contacts_filter_table_infos}"
        )

        usr_table_info = self.contacts_filter_table_infos.get("cc_user")
        clm_table_info = self.contacts_filter_table_infos.get("cc_claim")
        contact_table_info = self.contacts_filter_table_infos.get("cc_contact")
        group_table_info = self.contacts_filter_table_infos.get("cc_group")

        self.logger.info(
            f"Contacts Filter: Loading source table [{usr_table_info.table_name}]"
        )
        df_cc_user = self.extractor.extract(usr_table_info)
        self.logger.info(
            f"Contacts Filter: Loading source table [{clm_table_info.table_name}]"
        )
        df_cc_claim = self.extractor.extract(clm_table_info)
        self.logger.info(
            f"Contacts Filter: Loading source table [{contact_table_info.table_name}]"
        )
        df_cc_contact = self.extractor.extract(contact_table_info)
        self.logger.info(
            f"Contacts Filter: Loading source table [{group_table_info.table_name}]"
        )
        df_cc_group = self.extractor.extract(group_table_info)

        df_contact_usr_ids = (
            df_cc_user.join(
                df_cc_claim,
                col(f"{usr_table_info.alias}.id").isin(
                    col(f"{clm_table_info.alias}.createuserid"),
                    col(f"{clm_table_info.alias}.assigneduserid"),
                    col(f"{clm_table_info.alias}.updateuserid"),
                    col(f"{clm_table_info.alias}.assignedbyuserid"),
                    col(f"{clm_table_info.alias}.previoususerid"),
                ),
                "inner",
            )
            .join(
                df_cc_contact,
                col(f"{usr_table_info.alias}.contactid")
                == col(f"{contact_table_info.alias}.id"),
                "inner",
            )
            .join(
                self.filter_dataframes.get(FilterType.CLAIMS),
                col(f"{CLAIMS_FILTER}.claimid") == col(f"{clm_table_info.alias}.id"),
                "inner",
            )
            .select(col(f"{contact_table_info.alias}.id").alias("contactid"))
        )

        df_contact_supervisor_ids = (
            df_cc_claim.join(
                df_cc_group,
                col(f"{clm_table_info.alias}.assignedgroupid")
                == col(f"{group_table_info.alias}.id"),
                "inner",
            )
            .join(
                df_cc_contact,
                col(f"{contact_table_info.alias}.id")
                == col(f"{group_table_info.alias}.supervisorid"),
                "inner",
            )
            .join(
                self.filter_dataframes.get(FilterType.CLAIMS),
                col(f"{CLAIMS_FILTER}.claimid") == col(f"{clm_table_info.alias}.id"),
                "inner",
            )
            .select(col(f"{group_table_info.alias}.supervisorid").alias("contactid"))
        )

        df_contact_ids = (
            # union does not de-duplicate so distinct must be called
            df_contact_usr_ids.union(df_contact_supervisor_ids)
            .distinct()
            .alias(CONTACTS_FILTER)
            # TODO: cache in future if used by > 1 table
        )

        if df_contact_ids.isEmpty():
            self.logger.info("** Contact Filter data frame is empty! **")
        else:
            self.logger.info("Finished loading contact filter data.")

        return df_contact_ids


class PolicyFilter(AbstractFilter):
    def __init__(
        self,
        glue_context,
        spark_session,
        logger: GlueLogger,
        extractor_type: ExtractorType,
        data_source_name: str,
        table_infos: Dict[str, TableInfo],
        app_env: str,
        filter_dataframes: Dict[FilterType, DataFrame],
        region_name: str,
        region_code: str,
    ) -> None:
        self.glue_context = glue_context
        self.spark_session = spark_session
        self.logger = logger
        self.policy_filter_table_infos = table_infos
        self.app_env = app_env
        self.region_code = region_code
        if region_name == "US":
            self.region_name = "USA"
        else:
            self.region_name = region_name
        self.extractor = Extractor(
            spark_session, logger, extractor_type, data_source_name, table_infos, app_env
        )

    def _set_full_extract_mode(self) -> None:
        for table_info in self.policy_filter_table_infos.values():
            table_info.relationships = []

    def load_filter(self) -> DataFrame:

        # TODO: Standardise US region name
        if (
            self.region_name not in data_region_dict.keys()
            and self.region_name != "USA"
        ):
            raise ValueError(f"Unknown Region {self.region_name}")

        self.logger.info(
            f"Creating Policy Filter Data Frame for region [{self.region_name}] using source tables: {self.policy_filter_table_infos}"
        )

        self._set_full_extract_mode()
        branchcodes_alias = "bc"

        self.logger.info("Policy Filter: Loading reference data...")
        genius_policy_filter_components = S3Config(
            self.glue_context, f"grsi-dp-glue-script-{self.region_code}-{self.app_env}"
        ).get_genius_policy_filter_components()

        lsm_company_codes = genius_policy_filter_components["lsm_company_codes"]
        lsm_product_codes = genius_policy_filter_components["lsm_product_codes"]
        lsm_gts_dept_codes = genius_policy_filter_components["lsm_gts_dept_codes"]

        self.logger.info("Policy Filter: Loading LSM branch codes...")
        df_branchcodes = (
            S3Config(
                self.glue_context,
                f"grsi-dp-glue-script-{self.region_code}-{self.app_env}",
            )
            .get_branch_codes()
            .alias(branchcodes_alias)
        )

        zuma_table_info = self.policy_filter_table_infos.get("zuma")
        self.logger.info(
            f"Policy Filter: Loading source table [{zuma_table_info.table_name}]"
        )
        df_zuma = self.extractor.extract(zuma_table_info)

        df_zuma_keys = (
            df_zuma.join(
                df_branchcodes,
                lower(df_zuma.MAMABN) == lower(col(f"{branchcodes_alias}.branch")),
                "inner",
            )
            .where(
                (
                    (
                        lower(df_zuma.MACNCD).isin(
                            [cc.lower() for cc in lsm_company_codes]
                        )
                        | lower(df_zuma.MAMAPC).isin(
                            [pc.lower() for pc in lsm_product_codes]
                        )
                        | lower(df_zuma.MADPCD).isin(
                            [dc.lower() for dc in lsm_gts_dept_codes]
                        )
                    )
                    & ~(lower(df_zuma.MAMAPC).isin("INLM".lower()))
                    & ~(df_zuma.MAMABN.startswith("7"))
                    & ~(lower(df_zuma.MACNCD).isin("LSMA".lower(), "LSMB".lower()))
                )
                & (
                    lower(col(f"{branchcodes_alias}.region"))
                    == self.region_name.lower()
                )
            )
            .select(df_zuma.MAMANU, df_zuma.MAMASE)
            .distinct()
            .alias(POLICY_FILTER)
            .cache()
        )

        if df_zuma_keys.isEmpty():
            self.logger.info("** Policy Filter data frame is empty! **")
        else:
            self.logger.info("Finished loading policy filter data.")

        return df_zuma_keys
