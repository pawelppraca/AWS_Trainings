import copy
import json
import sys
import boto3
from aws_xray_sdk.core import patch_all, xray_recorder
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from etl import util, extract, xray, config, shared, write, data_filter
import multiprocessing

class Extraction:
    def __init__(
        self,
        glue_context,
        spark_context,
        spark_session,
        logger,
        args,
        region_account_mapping,
    ):
        """
        Constructor
        :param glue_context: GlueContext object
        :param spark_context: GlueContext object
        :param spark_session: SparkSession object
        """
        self.glue_context = glue_context
        self.spark_context = spark_context
        self.spark_session = spark_session
        self.logger = logger

        self.job_name = args["JOB_NAME"]
        self.job_run_id = args["JOB_RUN_ID"]
        self.app_env = args["ENVIRONMENT"]
        self.region_name = args["AWS_REGION"]
        self.source_data_bucket = args["SOURCE_DATA_BUCKET"]
        self.ingestion_bucket = args["INGESTION_BUCKET"]
        self.organization_guid = args["ORGANIZATION_GUID"]
        self.lm_troux_uid = args["LM_TROUX_UID"]
        # self.artifact_guid = args["ARTIFACT_GUID"]
        self.deployment_guid = args["DEPLOYMENT_GUID"]
        self.id_table = args["ID_TABLE"]
        self.region_code = util.GlueJobUtil.get_region_code(self.region_name).lower()

        self.s3_client = boto3.client("s3")
        self.ddb_column_mapping_table_prefix = args[
            "DYNAMO_COLUMN_MAPPING_TABLE_NAME_PREFIX"
        ]
        self.assume_role_prefix = args["ASSUME_ROLE_PREFIX"]
        self.region_account_mapping = region_account_mapping

    # TODO: move to s3 config
    def load_region_config(self):
        response = self.s3_client.get_object(
            Bucket=f"grsi-dp-glue-script-{self.region_code}-{self.app_env}",
            Key="config/data_regions.json",
        )
        content = response["Body"]
        return json.loads(content.read())

    # Hardcoded to return 1 until incremental loads are implemented
    def get_load_id(self):
        # load_id is incremented and returned from the counter which then propagates downstream
        # as load_id in object tagging
        # dynamodb = boto3.resource("dynamodb")
        # table = dynamodb.Table(self.id_table)
        # response = table.update_item(
        #     Key={"Counter": "counter"},
        #     UpdateExpression="ADD #id :val",
        #     ExpressionAttributeNames={"#id": "id"},
        #     ExpressionAttributeValues={":val": 1},
        #     ReturnValues="UPDATED_NEW",
        # )
        # id = response["Attributes"]["id"]
        # return id
        return 1

    def run_extraction(self) -> None:
        self.logger.info("Starting job...")
        self.logger.info(f"AWS Region: {self.region_name}")
        # set up xray to point to our daemon running in ecs
        xray_helper = xray.XRayHelper(
            f"grsi-dp-ecs-cluster-{self.region_code}-{self.app_env}"
        )
        xray_recorder.configure(
            sampling=False,
            service="Glue Job Extraction",
            daemon_address=f"{xray_helper.get_xray_daemon_ip()}:2000",
        )
        self.logger.info(f"X-Ray trace id: {xray_helper.trace_id()}")

        # enable aws xray tracing
        patch_all()
        xray_recorder.begin_segment(
            name=f"Glue Job Data Extraction: {self.job_name} {self.job_run_id}",
            traceid=xray_helper.trace_id(),
            sampling=True,
        )
        s3Config = config.S3Config(
            self.glue_context, f"grsi-dp-glue-script-{self.region_code}-{self.app_env}"
        )

        source_system_infos = s3Config.get_source_systems_info_dict()
        enabled_source_systems = {
            k: v for k, v in source_system_infos.items() if v.enabled
        }
        disabled_source_systems = {
            k: v for k, v in source_system_infos.items() if v.enabled is False
        }

        self.logger.info(
            f"The following source systems are NOT enabled: {disabled_source_systems}"
        )
        self.logger.info(f"Extracting Source Systems: {enabled_source_systems}")

        load_id = self.get_load_id()
        self.logger.info(f"Current Load Id: {load_id}")

        # TODO: Create DTO Class for Region like the other data structures.
        data_region_list = self.load_region_config()
        self.logger.info(f"Data Region List: {data_region_list}")

        # TODO: AL: Refactor so data is only extracted ONCE and then filtered for each region instead of extracting
        #      data for each region separately.
        for r in data_region_list:
            if r["enabled"] != "y":
                continue
            region_name = r["name"]
            region_code = util.GlueJobUtil.get_region_code(r["awsRegion"])

            self.logger.info(f"Processing target Data Region: [{region_name}]...")

            writer = write.S3Writer(
                # Glue stuff
                glue_context=self.glue_context,
                logger=self.logger,
                xray_helper=xray_helper,
                load_id=load_id,
                # Mapping stuff
                assume_role_prefix=self.assume_role_prefix,
                bucket_name=f"{self.ingestion_bucket}-{region_code}-{self.app_env}",
                ddb_column_mapping_table_prefix=self.ddb_column_mapping_table_prefix,
                # Region stuff
                region_name=region_name,
                aws_region=r["awsRegion"],
                region_account_mapping=self.region_account_mapping,
                app_env=self.app_env,
                # Tag stuff
                organization_guid=self.organization_guid,
                lm_troux_uid=self.lm_troux_uid,
                deployment_guid=self.deployment_guid,
            )
            pools=[]
            for source_system in enabled_source_systems.values():
                xray_recorder.begin_subsegment(
                    name=f"Extract for source system: [{source_system.name}]"
                )
                table_infos = s3Config.get_table_info_dict(source_system.name)

                filter_dataframes = {}
                enabled_filters = [
                    data_filter
                    for data_filter in source_system.filters
                    if data_filter.enabled
                ]
                enabled_filters.sort(key=lambda x: x.order)
                for enabled_filter in enabled_filters:
                    filter_type = shared.filter_dict[enabled_filter.name]
                    filter_dataframe = data_filter.Filter.create_filter(
                        self.glue_context,
                        self.spark_session,
                        self.logger,
                        shared.ExtractorType.S3,
                        self.source_data_bucket,
                        copy.deepcopy(table_infos),
                        self.app_env,
                        # will be empty initially but other filters can then use it to join filters together
                        filter_dataframes,
                        region_name,
                        self.region_code,
                        filter_type,
                    ).load_filter()
                    self.logger.info(
                        f"Filter [{enabled_filter.name}] Data Frame: {filter_dataframe}"
                    )
                    filter_dataframes[filter_type] = filter_dataframe
                    # writer.write_filter_csv(filter_dataframe, filter.name)

                extractor = extract.Extractor(
                    self.spark_session,
                    self.logger,
                    shared.ExtractorType.S3,
                    self.source_data_bucket,
                    table_infos,
                    self.app_env,
                    filter_dataframes,
                )
                enabled_table_infos = {
                    k: v for k, v in table_infos.items() if v.enabled
                }

                if not enabled_table_infos:
                    self.logger.info(
                        f"All tables are DISABLED for source system [{source_system.name}]"
                    )

                for table_info in enabled_table_infos.values():
                    pools.append([extractor, writer, table_info])
                
            with multiprocessing.pool.ThreadPool(processes=16) as tpool:
                tpool.map(multi_threaded_extraction, pools)
                xray_recorder.end_subsegment()
                self.logger.info(f"Finished processing Data Region: [{region_name}].")

        xray_recorder.end_segment()
        return

def multi_threaded_extraction(data):
    extractor = data[0]
    writer = data[1]
    table_info = data[2]
    
    data_frame = extractor.extract(table_info)
    writer.write(table_info, data_frame)
    return
    
def main():
    args = getResolvedOptions(
        sys.argv,
        [
            "JOB_NAME",
            "AWS_REGION",
            "ACCOUNT_ID",
            "ENVIRONMENT",
            "SOURCE_DATA_BUCKET",
            "INGESTION_BUCKET",
            "ORGANIZATION_GUID",
            "LM_TROUX_UID",
            "ARTIFACT_GUID",
            "DEPLOYMENT_GUID",
            "ID_TABLE",
            "ASSUME_ROLE_PREFIX",
            "KMS_KEY_SSM_PARAM_PREFIX",
            "US_ACCOUNT_NUMBER",
            "EU_ACCOUNT_NUMBER",
            "AP_ACCOUNT_NUMBER",
            "DYNAMO_COLUMN_MAPPING_TABLE_NAME_PREFIX",
            "DATALAKE_CROSS_ACCOUNT_ROLE",
        ],
    )
    sts = boto3.client("sts")
    datalake_session = sts.assume_role(RoleArn=args['DATALAKE_CROSS_ACCOUNT_ROLE'], RoleSessionName="datalakeAssumeRole")
    datalake_credentials = datalake_session['Credentials']

    region_account_mapping = {
        "us-east-1": args["US_ACCOUNT_NUMBER"],
        "eu-west-1": args["EU_ACCOUNT_NUMBER"],
        "ap-southeast-2": args["AP_ACCOUNT_NUMBER"],
    }
    (
        spark_context,
        glue_context,
        spark_session,
    ) = util.GlueJobUtil.create_contexts(
        region_info=region_account_mapping,
        app_env=args["ENVIRONMENT"],
        bucket=args["INGESTION_BUCKET"],
        assume_role_prefix=args["ASSUME_ROLE_PREFIX"],
        kms_key_ssm_param_prefix=args["KMS_KEY_SSM_PARAM_PREFIX"],
        datalake_bucket=args["SOURCE_DATA_BUCKET"],
        datalake_credentials=datalake_credentials,
    )
    logger = util.GlueJobUtil.create_logger(glue_context)
    logger.info("Glue context has been created successfully.")
    job = Job(glue_context)
    job.init(args["JOB_NAME"], args)
    extraction = Extraction(
        glue_context=glue_context,
        spark_context=spark_context,
        spark_session=spark_session,
        logger=logger,
        args=args,
        region_account_mapping=region_account_mapping,
    )
    try:
        if args["ENVIRONMENT"] == "development":
            logger.error("Dev environment, don't try to extract")
        else:
            extraction.run_extraction()
    except Exception as e:
        logger.error(f"Error: {e}")
        raise e
    finally:
        job.commit()


if __name__ == "__main__":
    main()
