from typing import Dict, List

import boto3
from boto3.dynamodb.types import TypeSerializer, TypeDeserializer

from etl.shared import ColumnOrdering

class DynamoDbMixin:

    def _get_assumed_region_session(self, 
                                    aws_region: str,
                                    assumed_role_arn: str,
                                    assumed_session_name: str,
                                    ) -> boto3.session.Session:

        sts = boto3.client("sts")
        assume_response = sts.assume_role(
            RoleArn=assumed_role_arn, RoleSessionName=assumed_session_name
        )

        session = boto3.session.Session(
            region_name=aws_region,
            aws_access_key_id=assume_response["Credentials"]["AccessKeyId"],
            aws_secret_access_key=assume_response["Credentials"]["SecretAccessKey"],
            aws_session_token=assume_response["Credentials"]["SessionToken"],
        )
        return session
    
    def _update_item(self, boto_session: boto3.session.Session, dynamo_table: str, item: dict) -> None:
        ddb_client = boto_session.client("dynamodb")

        ddb_client.update_item(
            TableName=dynamo_table,
            Key={
                'Table': {'S': item['Table']},
                'Schema': {'S': item['Schema']}
            },
            UpdateExpression="SET ColumnOrder = :co",
            ExpressionAttributeValues={
                ':co': {
                    'S': item['ColumnOrder']
                }
            }
        )

    def _put_item(self, boto_session: boto3.session.Session, dynamo_table: str, item: Dict) -> None:

        ddb_client = boto_session.client("dynamodb")
        #serializes Python data types to DynamoDB types
        serializer = TypeSerializer()
        dynamo_data = {k: serializer.serialize(v) for k,v in item.items()}

        ddb_client.put_item(TableName=dynamo_table,Item=dynamo_data)


    #TODO: Not tested due to cross-account role not having read permission on DynamoDB
    def _get_item(self, boto_session: boto3.session.Session, dynamo_table: str, key: Dict):

        ddb_client = boto_session.client("dynamodb")

        #Deserialize Response as Python dictionary
        deserializer = TypeDeserializer()
        response = ddb_client.get_item(TableName=dynamo_table, Key=key)

        if 'Item' in response:
            item = {k: deserializer.deserialize(v) for k, v in response['Item'].items()}
        else:
            item = {}

        return item


class ColumnMappingDynamoDBWriter(DynamoDbMixin):

    def __init__(
        self,
        aws_region: str,
        assumed_role_arn: str,
        assumed_session_name: str,
        dynamo_table_name: str,
    ) -> None:
        self.aws_region = aws_region
        self.assumed_role_arn = assumed_role_arn
        self.assumed_session_name = assumed_session_name
        self.dynamo_table_name = dynamo_table_name


    def get_item(self, target_table: str, target_schema: str) -> dict:
        return self._get_item(
            boto_session=self._get_assumed_region_session(self.aws_region, self.assumed_role_arn, self.assumed_session_name),
            dynamo_table=self.dynamo_table_name,
            key={
                'Table': {'S': target_table},
                'Schema': {'S': target_schema}
            }
        )

    def get_column_mappings(self, target_table: str, target_schema: str) -> List[str]:

        response =  self._get_item(
            boto_session=self._get_assumed_region_session(self.aws_region, self.assumed_role_arn, self.assumed_session_name),
            dynamo_table=self.dynamo_table_name,
            key={
                'Table': {'S': target_table},
                'Schema': {'S': target_schema}
            }
        )

        return response.get('ColumnOrder').split(',')

    def save_column_mappings(self, target_table: str, target_schema: str, columns: List[str], is_existing_table: bool) -> None:

        co = ColumnOrdering(Table=target_table, Schema=target_schema, ColumnOrder=", ".join(columns))

        if is_existing_table:
            self._update_item(
                boto_session=self._get_assumed_region_session(self.aws_region, self.assumed_role_arn, self.assumed_session_name),
                dynamo_table=self.dynamo_table_name,
                item=co
            )
        else:
            self._put_item(
                boto_session=self._get_assumed_region_session(self.aws_region, self.assumed_role_arn, self.assumed_session_name),
                dynamo_table=self.dynamo_table_name,
                item=co
            )


class DataframeOperations:

    @staticmethod
    def _get_new_columns(existing_cols: List[str], target_data_frame) -> List[str]:
        return list(set(target_data_frame.columns) - set(existing_cols))
    
    @staticmethod
    def _get_deleted_columns(existing_cols: List[str], target_data_frame) -> List[str]:
        return list(set(existing_cols) - set(target_data_frame.columns))
    
