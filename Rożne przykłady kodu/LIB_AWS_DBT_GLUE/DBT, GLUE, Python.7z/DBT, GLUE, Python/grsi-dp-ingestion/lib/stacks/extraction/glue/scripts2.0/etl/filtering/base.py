import abc
from typing import List, Dict

from pyspark.sql import SparkSession, DataFrame

from etl.shared import DataRegion
from etl.util import GlueLogger

class BaseDataFilter(metaclass=abc.ABCMeta):

    def __init__(
            self, 
            filter_name: str, 
            data_regions: List[DataRegion]
    ) -> None:
        self._filter_name = filter_name
        self._data_regions = data_regions

    
    @abc.abstractmethod
    def get_data_frame(self, spark: SparkSession, source_data_frames: Dict[str, DataFrame], logger: GlueLogger) -> DataFrame:
        raise NotImplementedError("get_data_frame is abstract")

    @property 
    def filter_name(self): 
        return self._filter_name 
    
    @property 
    def data_regions(self): 
        return self._data_regions
