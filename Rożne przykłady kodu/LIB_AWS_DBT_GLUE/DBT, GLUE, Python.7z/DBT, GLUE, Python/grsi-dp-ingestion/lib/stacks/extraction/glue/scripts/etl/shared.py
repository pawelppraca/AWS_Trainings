from enum import Enum
from typing import List

CLAIMS_FILTER = "claims_filter"
CONTACTS_FILTER = "contacts_filter"
POLICY_FILTER = "policy_filter"


class FilterType(Enum):
    CLAIMS = 1
    CONTACTS = 2
    POLICY = 3


filter_dict = {
    CLAIMS_FILTER: FilterType.CLAIMS,
    CONTACTS_FILTER: FilterType.CONTACTS,
    POLICY_FILTER: FilterType.POLICY,
}


class ExtractorType(Enum):
    S3 = 1
    SPARK = 2


class DataRegion(Enum):
    US = 1
    APAC = 2
    LATAM = 3
    EUROPE = 4


data_region_dict = {
    "US": DataRegion.US,
    "APAC": DataRegion.APAC,
    "LATAM": DataRegion.LATAM,
    "Europe": DataRegion.EUROPE,
}


class FilterInfo:
    def __init__(self, name: str, enabled: bool, order: int) -> None:
        self.name = name
        self.enabled = enabled
        self.order = order

    def __repr__(self):
        return (
            "FilterInfo("
            f"name='{self.name}', "
            f"enabled={self.enabled}, "
            f"order={self.order}"
            ")"
        )


class SourceSystemInfo:
    def __init__(self, name: str, enabled: bool, filters: List[FilterInfo]) -> None:
        self.name = name
        self.enabled = enabled
        self.filters = filters

    def __repr__(self):
        return (
            "SourceSystemInfo("
            f"name='{self.name}', "
            f"enabled={self.enabled}, "
            f"filters={self.filters!r}"
            ")"
        )


class ChildTableInfo:
    def __init__(self, table_name, join_type, join_condition, alias) -> None:
        self.table_name = table_name
        self.join_type = join_type
        self.join_condition = join_condition
        self.alias = alias

    def __repr__(self):
        return (
            "ChildTableInfo("
            f"table_name='{self.table_name}', "
            f"join_type='{self.join_type}', "
            f"join_condition='{self.join_condition}', "
            f"alias='{self.alias}'"
            ")"
        )


class TableInfo:
    def __init__(
        self,
        source: str,
        database_name: str,
        schema: str,
        table_name: str,
        write_name: str,
        alias: str,
        table_path: str,
        enabled: bool,
        relationships: List[ChildTableInfo],
    ) -> None:
        self.source = source
        self.database_name = database_name
        self.schema = schema
        self.table_name = table_name
        self.write_name = write_name
        self.alias = alias
        self.table_path = table_path
        self.enabled = enabled
        self.relationships = relationships

    def __repr__(self):
        return (
            "TableInfo("
            f"source='{self.source}', "
            f"database_name='{self.database_name}', "
            f"schema='{self.schema}', "
            f"table_name='{self.table_name}', "
            f"write_name='{self.table_name}', "
            f"alias='{self.alias}', "
            f"table_path='{self.table_path}', "
            f"enabled={self.enabled}, "
            f"relationships={self.relationships!r}"
            ")"
        )
