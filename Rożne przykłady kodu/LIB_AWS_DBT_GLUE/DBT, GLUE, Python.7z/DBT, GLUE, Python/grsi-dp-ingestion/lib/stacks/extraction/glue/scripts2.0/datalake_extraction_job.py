import sys

from awsglue.job import Job
from awsglue.utils import getResolvedOptions

from etl.shared import DataRegion
from etl.util import S3Helper, SNSHelper, GlueJobUtil, GlueLogger
from etl.config import ConfigManager
from etl.extraction.util import ColumnMappingDynamoDBWriter
from etl.extraction.extractors import DeltaLakeExtractor
from etl.extraction.writers  import S3Writer
from etl.extraction.dataflows import RegionalDataFlow


def main():

    #TODO: Remove any unused arguments; align with extraction.ts
    args = getResolvedOptions(
        sys.argv,
        [
             "JOB_NAME",
            "AWS_REGION",
            #"ACCOUNT_ID", --Not used
            "ENVIRONMENT",
            "SOURCE_DATA_BUCKET",
            "INGESTION_BUCKET",
            "ORGANIZATION_GUID",
            "LM_TROUX_UID",
            #"ARTIFACT_GUID", --Not used
            "DEPLOYMENT_GUID",
            #"ID_TABLE", --Code needs refactoring for multi-region (Load ID in Dynamo)
            "ASSUME_ROLE_PREFIX",
            "KMS_KEY_SSM_PARAM_PREFIX",
            "US_ACCOUNT_NUMBER",
            "EU_ACCOUNT_NUMBER",
            "DYNAMO_COLUMN_MAPPING_TABLE_NAME_PREFIX",
            "DATALAKE_CROSS_ACCOUNT_ROLE",
            #"DATALAKE_MANIFEST_TABLE",
            "GLUE_SCRIPT_BUCKET",
            "NOTIFICATION_TOPIC_ARN",
            "XRAY_ECS_RESOURCE_ARN",
        ],
    )

    ######################## JOB CONFIGURATION ######################################

    source_system_config = {
        "claim_center": "config/data_sources/claim_center_source_data_lake_distilled.json",
        "genius": "config/data_sources/genius_source_data_lake_distilled.json"
    }
    
    data_regions = [DataRegion.EUROPE]#, DataRegion.US]

    ######################## STATIC CONFIGURAION #####################################

    #TODO: Move to json config file e.g. "glue_job_config"
    ref_data_folder = "config/reference_data"
    assumed_session_name = "glueAssumeRole"

    aws_regional_settings = {
        DataRegion.US: {"aws_region": "us-east-1", "account_number": args["US_ACCOUNT_NUMBER"]},
        DataRegion.EUROPE: {"aws_region": "eu-west-1", "account_number": args["EU_ACCOUNT_NUMBER"]},
    }
 
    xray_settings={
            "xray_ecs_resource_arn": args["XRAY_ECS_RESOURCE_ARN"], 
            "service_name": "Warehouse Repo Extraction",
            "main_segment_name": f'Glue Job {args["JOB_NAME"]}: {args["JOB_RUN_ID"]}',
            "xray_s3_key_prefix": "_xray_temporary"
    }

    s3_tags = {
         "organization_guid": args["ORGANIZATION_GUID"],
         "lm_troux_uid": args["LM_TROUX_UID"],
         "deployment_guid": args["DEPLOYMENT_GUID"],
    }

    data_lake_environment_mappings = {
        "dev": "non-prod",
        "test": "non-prod",
        "qa": "non-prod",
        "production": "prod"
    }

    ##################################################################################

    # Create Contexts
    (
        spark_context,
        glue_context,
        spark_session,
    ) = GlueJobUtil.create_data_lake_contexts(
        app_env=args["ENVIRONMENT"],
        aws_region_account_mappings= {region_info.get("aws_region"): region_info.get("account_number") for data_region, region_info in aws_regional_settings.items()},        
        bucket_prefix=args["INGESTION_BUCKET"],
        assume_role_prefix=args["ASSUME_ROLE_PREFIX"],
        kms_key_ssm_param_prefix=args["KMS_KEY_SSM_PARAM_PREFIX"],
        datalake_cross_account_role=args["DATALAKE_CROSS_ACCOUNT_ROLE"],
        datalake_bucket=args["SOURCE_DATA_BUCKET"]
    )
    logger = GlueLogger(GlueJobUtil.create_logger(glue_context))
    logger.info("GlueContext has been created successfully.")
    
    #Load Config data
    s3_config = S3Helper(args["GLUE_SCRIPT_BUCKET"])
    logger.info(f"Loading configuration data for source systems: {source_system_config}")
    source_systems = {k: ConfigManager.get_source_system_from_json(s3_config.get_json_object(v)) for k,v in source_system_config.items()} 
    
    logger.info(f"Loading reference data from S3: '{s3_config.s3_bucket}/{ref_data_folder}'...")
    datasets = {}
    for filename in s3_config.list_objects(ref_data_folder):
        logger.info(f"Loading config file '{filename}'...")
        dataset_name = S3Helper.get_filename_from_path(filename)
        datasets[dataset_name] = ConfigManager.get_tabular_dataset_from_json(dataset_name, s3_config.get_json_object(filename)) 

    #Create Extractor and load the reference datasets
    logger.info("Initialising extractor...")
    extractor = DeltaLakeExtractor(environment=args["ENVIRONMENT"], 
                                   s3_bucket=args["SOURCE_DATA_BUCKET"],
                                   s3_key_prefix=data_lake_environment_mappings[args["ENVIRONMENT"]]
                                   )
    for (k,v) in datasets.items():
        extractor.add_dataset(k, v)

    #Create Writers for each Region
    logger.info("Initialising writers...")
    writers = {}
    for data_region in data_regions:
        aws_region = aws_regional_settings[data_region]["aws_region"]
        account_number = aws_regional_settings[data_region]["account_number"]
        ingestion_bucket = GlueJobUtil.get_ingestion_bucket_name(args["INGESTION_BUCKET"], aws_region, args["ENVIRONMENT"])
        ddb_column_writer = ColumnMappingDynamoDBWriter(
            aws_region=aws_region,
            assumed_role_arn=GlueJobUtil.get_assumed_role_arn(args["ASSUME_ROLE_PREFIX"], aws_region, account_number, args["ENVIRONMENT"]),
            assumed_session_name=assumed_session_name,
            dynamo_table_name=GlueJobUtil.get_ddb_column_mappings_table_name(args["DYNAMO_COLUMN_MAPPING_TABLE_NAME_PREFIX"], aws_region, args["ENVIRONMENT"])
        )
        logger.info(f"Initialising S3 writer for data region '{data_region}': S3 ingestion bucket '{ingestion_bucket}' in '{aws_region}'")
        writers[data_region] = S3Writer(s3_bucket=ingestion_bucket, 
                                        s3_tags=s3_tags, 
                                        column_mapping_writer=ddb_column_writer,
                                        s3_key_prefix=xray_settings["xray_s3_key_prefix"])
    
    sns_topic = SNSHelper(args["NOTIFICATION_TOPIC_ARN"])

    # Create Data Flow
    logger.info("Initialising data flow...")
    extraction = RegionalDataFlow(
        extractor = extractor,
        regional_writers=writers,
        spark=spark_session,
        logger = logger,
        job_name = args["JOB_NAME"],
        data_regions = data_regions,
        source_systems = source_systems,
        sns_topic = sns_topic,
        enable_xray_tracing=True,
        xray_settings=xray_settings
    )

    #Create Glue job
    job = Job(glue_context)
    job.init(args["JOB_NAME"], args)

    #Kick off extract
    try:
        if args["ENVIRONMENT"] == "development":
            logger.error("Dev environment, don't try to extract")
        else:
            extraction.run()
    except Exception as e:
        logger.error(f"Error: {e}")
        raise e
    finally:
        job.commit()

if __name__ == "__main__":
    main()