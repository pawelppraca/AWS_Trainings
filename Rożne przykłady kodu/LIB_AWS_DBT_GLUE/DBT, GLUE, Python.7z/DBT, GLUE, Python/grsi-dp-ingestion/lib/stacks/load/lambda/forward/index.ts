import { Context, S3Event } from 'aws-lambda';
import { EventBridgeClient, PutEventsCommand, PutEventsRequestEntry } from '@aws-sdk/client-eventbridge'; // ES Modules import
import { Detail } from '../load/S3PutEvent';
import * as AWSXRay from 'aws-xray-sdk';

export const handler = async function (event: S3Event, context: Context) {
    console.log(event);
    console.log(context);

    const targetEventBusName: string = process.env.TARGET_EVENT_BUS_NAME!;

    const events: PutEventsRequestEntry[] = [];

    for (const record of event.Records) {
        const s3Key: string = record.s3.object.key;
        // Process next record if we have a temporary key
        if (s3Key.indexOf('_temporary') >= 0) {
            continue;
        }

        const bucketName: string = record.s3.bucket.name;
        const eTag: string = record.s3.object.eTag;

        const detail: Detail = createEventDetail(bucketName, s3Key, eTag);
        events.push({
            Detail: JSON.stringify(detail),
            Resources: [record.s3.bucket.arn],
            DetailType: record.eventName,
            Source: record.eventSource,
            Time: new Date(record.eventTime),
            EventBusName: targetEventBusName,
        });
    }

    let client;
    if (!process.env.IS_OFFLINE) {
        client = AWSXRay.captureAWSv3Client(new EventBridgeClient());
    } else {
        // for unit tests
        client = new EventBridgeClient();
    }

    // Make sure we don't try to send an event of nothing, like when we have only temporary files
    if (events.length > 0) {
        try {
            const resp = await client.send(
                new PutEventsCommand({
                    Entries: events,
                }),
            );
            console.log(resp);
        } catch (error) {
            throw error;
        }
    }
};

export const createEventDetail = function (bucketName: string, s3Key: string, eTag: string): Detail {
    return {
        bucket: {
            name: bucketName,
        },
        object: {
            key: decodeURIComponent(s3Key), // required - decodes special characters back to their original string. Handles timestamps.
            etag: eTag,
        },
    };
};
