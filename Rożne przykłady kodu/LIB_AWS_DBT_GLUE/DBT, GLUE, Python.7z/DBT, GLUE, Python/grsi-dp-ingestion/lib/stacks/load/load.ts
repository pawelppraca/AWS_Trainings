import { config, grsiPrefix, PermissionsBoundaryType } from '@lmig/grsi-dp-shared-config-and-classes';
import { Aws, Duration, Fn, RemovalPolicy, Tags } from 'aws-cdk-lib';
import { AttributeType, BillingMode, Table, TableEncryption } from 'aws-cdk-lib/aws-dynamodb';
import * as events from 'aws-cdk-lib/aws-events';
import { Archive, Rule } from 'aws-cdk-lib/aws-events';
import { LambdaFunction } from 'aws-cdk-lib/aws-events-targets';
import {
    ArnPrincipal,
    CfnRole,
    Effect,
    ManagedPolicy,
    PolicyDocument,
    PolicyStatement,
    Role,
    ServicePrincipal,
} from 'aws-cdk-lib/aws-iam';
import { Alias, Key } from 'aws-cdk-lib/aws-kms';
import { Code, EventInvokeConfig, LayerVersion, Runtime, Tracing } from 'aws-cdk-lib/aws-lambda';
import { SnsDestination } from 'aws-cdk-lib/aws-lambda-destinations';
import { NodejsFunction } from 'aws-cdk-lib/aws-lambda-nodejs';
import { Bucket, EventType } from 'aws-cdk-lib/aws-s3';
import * as s3Notifications from 'aws-cdk-lib/aws-s3-notifications';
import { Topic, SubscriptionFilter } from 'aws-cdk-lib/aws-sns';
import { SqsSubscription } from 'aws-cdk-lib/aws-sns-subscriptions';
import { Queue } from 'aws-cdk-lib/aws-sqs';
import { Construct } from 'constructs';
import * as path from 'path';
import { StackConfiguration } from '../../../bin/config';
import * as lambdaEventSources from 'aws-cdk-lib/aws-lambda-event-sources';
import { Alarm, ComparisonOperator, Metric, TreatMissingData } from 'aws-cdk-lib/aws-cloudwatch';
import { SnsAction } from 'aws-cdk-lib/aws-cloudwatch-actions';
import { PermissionsBoundaryArnFromType } from '@lmig/swa-cdk-core';

export class LoadResources extends Construct {
    constructor(scope: Construct, id: string, stackConfig: StackConfiguration) {
        super(scope, id);

        const lmTrouxUidBoundary = ManagedPolicy.fromManagedPolicyArn(
            this,
            'lookupTrouxUidPb',
            PermissionsBoundaryArnFromType(PermissionsBoundaryType.trouxUuidAccess()),
        );

        // import encryption keys
        const dynamoKey = Key.fromKeyArn(this, 'DynamoKeyLookup', Fn.importValue(config.dynamoKmsKeyExportName));
        const sqsKey = Alias.fromAliasName(
            this,
            'SqsKeyLookup',
            `alias/${grsiPrefix}-sqs-key-${stackConfig.regionEnv}`,
        );
        const ingestionKey = Alias.fromAliasName(
            this,
            'IngestionKeyLookup',
            `alias/${grsiPrefix}-ingestion-key-${stackConfig.regionEnv}`,
        );
        const redshiftKey = Alias.fromAliasName(
            this,
            'RedshiftKeyLookup',
            `alias/${grsiPrefix}-redshift-key-${stackConfig.regionEnv}`,
        );
        const glueKey = Alias.fromAliasName(
            this,
            'GlueKeyLookup',
            `alias/${grsiPrefix}-glue-script-${stackConfig.environmentKey}`,
        );
        const s3Key = Alias.fromAliasName(
            this,
            'S3KeyLookup',
            `alias/${grsiPrefix}-source-data-${stackConfig.environmentKey}`,
        );

        //  error notification topic emails team of failures.
        //  Note: when creating new lambdas Publish both the lambda invocation and runtime failures
        const topic = Topic.fromTopicArn(
            this,
            'NotificationTopic',
            `arn:aws:sns:${Aws.REGION}:${Aws.ACCOUNT_ID}:${grsiPrefix}-notification-topic-${stackConfig.regionEnv}`,
        );

        // for lambda failures. Future state is to have an automated function to Redrive and process failure messages from dlq
        const dlq = new Queue(this, 'dead-letter-queue', {
            queueName: `${grsiPrefix}-load-dlq-${stackConfig.regionEnv}`,
            retentionPeriod: Duration.days(14),
            encryptionMasterKey: sqsKey,
            enforceSSL: true,
        });

        //  The dead letter queue should be subscribed to all grsi-dp lambdas that publish
        //    to the notifications topic. Failures will be captured on the dlq.
        // AWS services such as IAM and Amazon SNS use a distributed computing model called
        //    eventual consistency. Additions or changes to a subscription filter policy require
        //    up to 15 minutes to fully take effect.
        // https://docs.aws.amazon.com/sns/latest/dg/sns-subscription-filter-policies.html

        topic.addSubscription(
            new SqsSubscription(dlq, {
                rawMessageDelivery: true, // required to preserve the message attributes and not encapsulate the message
                filterPolicy: {
                    //filters on attributes not body
                    testEvent: SubscriptionFilter.stringFilter({
                        denylist: ['unhappy_path'], //ignore unhappy path test
                    }),
                },
            }),
        );

        const testDlq = new Queue(this, 'testing-dead-letter-queue', {
            queueName: stackConfig.testingDeadLetterQueueName,
            retentionPeriod: Duration.days(14),
            encryptionMasterKey: sqsKey,
            enforceSSL: true,
        });

        topic.addSubscription(
            new SqsSubscription(testDlq, {
                rawMessageDelivery: true, // required to preserve the message attributes and not encapsulate the message
                filterPolicy: {
                    //filters on attributes not body
                    s3Key: SubscriptionFilter.stringFilter({
                        matchPrefixes: ['test/unhappy_path'],
                    }),
                },
            }),
        );

        const customEventBus = new events.EventBus(this, 'eventBus', {
            eventBusName: `${grsiPrefix}-event-bus-${config.regionEnv}`,
        });

        ////////
        // x-ray cannot propagate the ID in s3 object created events to eventbridge. Instead we use a
        // lambda destination which forwards the s3 event to the bus and propagates the x-ray ID
        ////////
        const forwardLambdaRole = new Role(this, 'forward-lambda-role', {
            assumedBy: new ServicePrincipal('lambda.amazonaws.com'),
            roleName: `${grsiPrefix}-lambda-forward-bucket-notification-${stackConfig.regionEnv}`,
            managedPolicies: [ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole')],
            inlinePolicies: {
                forwardingPolicy: new PolicyDocument({
                    statements: [
                        new PolicyStatement({
                            actions: ['events:PutEvents'],
                            resources: [customEventBus.eventBusArn],
                        }),
                    ],
                }),
            },
        });

        const forwardLambda = new NodejsFunction(this, 'forward-lambda-function', {
            functionName: `${grsiPrefix}-forwarding-lambda-${stackConfig.regionEnv}`,
            runtime: Runtime.NODEJS_18_X,
            memorySize: 256,
            timeout: Duration.minutes(5),
            deadLetterTopic: topic,
            entry: path.join(__dirname, 'lambda/forward/index.ts'),
            role: forwardLambdaRole,
            tracing: Tracing.PASS_THROUGH,
            environment: {
                REGION: Aws.REGION,
                TARGET_EVENT_BUS_NAME: customEventBus.eventBusName,
            },
        });

        new EventInvokeConfig(this, 'forwardLambda-invocation-config', {
            function: forwardLambda,
            retryAttempts: 2,
            onFailure: new SnsDestination(topic),
        }).node.addDependency(topic);

        const ingestionBucket = Bucket.fromBucketName(this, 'IngestionBucket', stackConfig.ingestionBucketName);

        ingestionBucket.addEventNotification(
            EventType.OBJECT_CREATED,
            new s3Notifications.LambdaDestination(forwardLambda),
        );

        const ingestion_error_alarm = new Alarm(this, 'Ingestion Bucket Error Alarm', {
            metric: new Metric({
                namespace: `Ingestion Bucket Error Alarm: ${stackConfig.regionEnv}`,
                metricName: 'errors',
                statistic: 'Sum',
            }),
            threshold: 0,
            evaluationPeriods: 1,
            datapointsToAlarm: 1,
            treatMissingData: TreatMissingData.NOT_BREACHING,
            alarmDescription: 'Detect errors',
            alarmName: `Ingestion Bucket Error Alarm: ${stackConfig.regionEnv}`,
        });

        ingestion_error_alarm.addAlarmAction(new SnsAction(topic));

        const s3EventPattern = {
            source: ['aws:s3'],
            detailType: [
                'ObjectCreated',
                'ObjectCreated:Put',
                'ObjectCreated:Post',
                'ObjectCreated:Copy',
                'ObjectCreated:CompleteMultipartUpload',
            ],
            detail: {
                bucket: {
                    name: [ingestionBucket.bucketName],
                },
            },
        };

        const s3NotificationArchive = new Archive(this, 'ingestionBucketEventArchive', {
            eventPattern: s3EventPattern,
            sourceEventBus: customEventBus,
            archiveName: `grsi-dp-ingestion-archive-${stackConfig.regionEnv}`,
            description: `Used to reload from the ${ingestionBucket.bucketName} to ${config.grsiPrefix}-redshift-${stackConfig.regionEnv} by replaying S3 object created events and triggering the ingestion lambda`,
        });

        ////////
        // the following section is responsible for triggering the load from s3 into the redshift warehouse
        ////////

        // Lock table used during file loading / COPY into redshift (load lambda) for once
        // only delivery behavior
        const lockTable = new Table(this, 'dynamo-lock-table', {
            tableName: `${grsiPrefix}-dynamodb-lock-table-${stackConfig.regionEnv}`,
            encryption: TableEncryption.CUSTOMER_MANAGED,
            encryptionKey: dynamoKey,
            partitionKey: { name: 'eTag', type: AttributeType.STRING },
            removalPolicy: RemovalPolicy.DESTROY,
            billingMode: BillingMode.PAY_PER_REQUEST,
            timeToLiveAttribute: 'expiryTime',
            pointInTimeRecovery: true,
        });
        Tags.of(lockTable).add('dpmawsbackup', 'none');

        // Manifest table used as an audit log of all data transfered to redshift
        const fileManifestTable = new Table(this, 'dynamo-file-manifest-table', {
            tableName: stackConfig.fileManifestTableName,
            encryption: TableEncryption.CUSTOMER_MANAGED,
            encryptionKey: dynamoKey,
            partitionKey: { name: 's3uri', type: AttributeType.STRING },
            sortKey: { name: 'loadID', type: AttributeType.NUMBER },
            removalPolicy: RemovalPolicy.DESTROY,
            billingMode: BillingMode.PAY_PER_REQUEST,
            timeToLiveAttribute: 'timeToLive',
            pointInTimeRecovery: true,
        });

        fileManifestTable.addGlobalSecondaryIndex({
            indexName: 'x_amzn_trace_id',
            partitionKey: { name: 's3uri', type: AttributeType.STRING },
        });

        Tags.of(fileManifestTable).add('dpmawsbackup', stackConfig.failSafeBackupTag);

        // Copy Column Table used to provide column mapping for redshift COPY command
        const copyColumnTable = new Table(this, 'copy-column-table', {
            tableName: [config.dynamoColumnMappingTableNamePrefix, config.regionEnv].join('-'),
            encryption: TableEncryption.CUSTOMER_MANAGED,
            encryptionKey: dynamoKey,
            partitionKey: { name: 'Table', type: AttributeType.STRING },
            sortKey: { name: 'Schema', type: AttributeType.STRING },
            removalPolicy: RemovalPolicy.DESTROY,
            billingMode: BillingMode.PAY_PER_REQUEST,
            pointInTimeRecovery: true,
        });

        Tags.of(copyColumnTable).add('dpmawsbackup', 'none');

        // load lambda publishes a message about a recent 'COPY into redshift statement'
        // on to this queue for the verify lambda to check the ingestion status of the file
        const verifyRedshiftTimeout: Duration = Duration.seconds(300);
        const verifyRedshiftQueue = new Queue(this, 'verify-redshift-queue', {
            queueName: `${grsiPrefix}-verify-redshift-queue-${stackConfig.regionEnv}`,
            retentionPeriod: Duration.days(1),
            encryptionMasterKey: sqsKey,
            enforceSSL: true,
            visibilityTimeout: verifyRedshiftTimeout,
        });

        const ingestionLambdaRole = new Role(this, 'ingestion-lambda-role', {
            assumedBy: new ServicePrincipal('lambda.amazonaws.com'),
            roleName: stackConfig.ingestionLambdaRoleName,
            managedPolicies: [ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole')],
            inlinePolicies: {
                loadPolicy: new PolicyDocument({
                    statements: [
                        new PolicyStatement({
                            actions: ['redshift-data:ExecuteStatement'],
                            resources: [
                                `arn:aws:redshift:${Aws.REGION}:${Aws.ACCOUNT_ID}:cluster:${grsiPrefix}-redshift-${stackConfig.regionEnv}`,
                            ],
                        }),
                        new PolicyStatement({
                            actions: ['redshift-data:DescribeStatement', 'redshift-data:GetStatementResult'],
                            resources: ['*'],
                        }),
                        new PolicyStatement({
                            actions: ['redshift:GetClusterCredentialsWithIAM'],
                            resources: [
                                `arn:aws:redshift:${Aws.REGION}:${Aws.ACCOUNT_ID}:dbname:${grsiPrefix}-redshift-${stackConfig.regionEnv}/*`,
                            ],
                        }),
                        new PolicyStatement({
                            actions: ['sns:Publish'],
                            resources: [
                                `arn:aws:redshift:${Aws.REGION}:${Aws.ACCOUNT_ID}:dbname:${grsiPrefix}-redshift-${stackConfig.regionEnv}/*`,
                            ],
                        }),
                        new PolicyStatement({
                            actions: ['sqs:SendMessage'],
                            resources: [
                                `arn:aws:sqs:${Aws.REGION}:${Aws.ACCOUNT_ID}:${grsiPrefix}-verify-redshift-queue-${stackConfig.regionEnv}`,
                                `arn:aws:sqs:${Aws.REGION}:${Aws.ACCOUNT_ID}:${grsiPrefix}-load-dlq-${stackConfig.regionEnv}`,
                            ],
                        }),
                        new PolicyStatement({
                            actions: ['kms:Encrypt', 'kms:Decrypt', 'kms:DescribeKey'],
                            // CDK would automatically add this if the kms key was created in this stack
                            resources: [dynamoKey.keyArn, sqsKey.keyArn],
                        }),
                        new PolicyStatement({
                            actions: [
                                'kms:Encrypt*',
                                'kms:Decrypt*',
                                'kms:ReEncrypt*',
                                'kms:GenerateDatakey*',
                                'kms:Describe*',
                            ],
                            resources: [ingestionKey.keyArn, redshiftKey.keyArn, glueKey.keyArn, s3Key.keyArn],
                        }),
                        // Used by the integration test to tear down pervious test state
                        new PolicyStatement({
                            actions: ['dynamodb:DeleteItem'],
                            resources: [fileManifestTable.tableArn],
                        }),
                        new PolicyStatement({
                            actions: ['sqs:receivemessage', 'sqs:deletemessage'],
                            resources: [testDlq.queueArn],
                        }),
                        new PolicyStatement({
                            actions: ['redshift:DescribeClusters'],
                            resources: [`arn:aws:redshift:${Aws.REGION}:${Aws.ACCOUNT_ID}:cluster:*`],
                        }),
                    ],
                }),
            },
            // permissionsBoundary: lmTrouxUidBoundary,
        });

        const utilityLayer = new LayerVersion(this, 'utilityLayer', {
            compatibleRuntimes: [Runtime.NODEJS_16_X, Runtime.NODEJS_18_X],
            code: Code.fromAsset('lib/stacks/load/lambda/utils'),
            description: 'Shared utility code',
        });

        ingestionLambdaRole.stack.tags.setTag('aws_iam_permission_boundary_exempt', ' ');

        const loadLambda = new NodejsFunction(this, 'load-lambda-function', {
            functionName: `${grsiPrefix}-load-lambda-${stackConfig.regionEnv}`,
            runtime: Runtime.NODEJS_18_X,
            memorySize: 256,
            timeout: Duration.minutes(5),
            deadLetterTopic: topic,
            entry: path.join(__dirname, 'lambda/load/index.ts'),
            role: ingestionLambdaRole,
            tracing: Tracing.ACTIVE,
            layers: [utilityLayer],
            environment: {
                LOCK_TABLE: lockTable.tableName,
                FILE_MANIFEST_TABLE: fileManifestTable.tableName,
                COLUMN_ORDER_TABLE: copyColumnTable.tableName,
                AWS_ACCOUNT_ID: Aws.ACCOUNT_ID,
                REGION: Aws.REGION,
                CLUSTER_NAME: `${grsiPrefix}-redshift-${stackConfig.regionEnv}`,
                REDSHIFT_ROLE: `arn:aws:iam::${Aws.ACCOUNT_ID}:role/${grsiPrefix}-redshift-role-${stackConfig.regionEnv}`,
                REDSHIFT_DB: `grsi_dp_${stackConfig.regionCode}_${stackConfig.environmentKey}`,
                VERIFY_QUEUE_URL: verifyRedshiftQueue.queueUrl,
            },
        });
        loadLambda.node.addDependency(ingestionLambdaRole);

        lockTable.grantReadWriteData(loadLambda);
        fileManifestTable.grantReadWriteData(loadLambda);
        copyColumnTable.grantReadWriteData(loadLambda);

        new EventInvokeConfig(this, 'loadLambda-invocation-config', {
            function: loadLambda,
            // must be 0 as the first invocation sets the dynamo lock and any runtime failure
            // invokes a retry which will return gracefully due to the lock in progress
            // and prevents errors being thrown / no notifications sent
            retryAttempts: 0,
            onFailure: new SnsDestination(topic),
        }).node.addDependency(topic);

        dlq.addToResourcePolicy(
            new PolicyStatement({
                effect: Effect.ALLOW,
                resources: [dlq.queueArn],
                actions: ['sqs:SendMessage'],
                principals: [new ServicePrincipal('lambda.amazonaws.com')],
                conditions: {
                    ArnEquals: {
                        'aws:SourceArn': loadLambda.functionArn,
                    },
                },
            }),
        );

        // separate eventbridge message failure dlq from lambda dlq to separate
        // pipeline point of failure and make it simpler to extend redrive
        // functionality in the future
        // https://docs.aws.amazon.com/eventbridge/latest/userguide/eb-rule-dlq.html

        // Can test by removing EventBridge permissions to invoke the load lambda
        const eventbridgeDlq = new Queue(this, 'eventbridge-rule-dead-letter-queue', {
            queueName: `${grsiPrefix}-eventbridge-load-rule-dlq-${stackConfig.regionEnv}`,
            retentionPeriod: Duration.days(14),
            encryptionMasterKey: sqsKey,
            enforceSSL: true,
        });

        const loadRule = new Rule(this, 'load-rule', {
            eventPattern: s3EventPattern,
            ruleName: `${grsiPrefix}-load-rule-${stackConfig.regionEnv}`,
            targets: [
                new LambdaFunction(loadLambda, {
                    maxEventAge: Duration.hours(2),
                    retryAttempts: 2,
                    deadLetterQueue: eventbridgeDlq,
                }),
            ],
            eventBus: customEventBus,
        });

        eventbridgeDlq.addToResourcePolicy(
            new PolicyStatement({
                effect: Effect.ALLOW,
                resources: [eventbridgeDlq.queueArn],
                actions: ['sqs:SendMessage'],
                principals: [new ServicePrincipal('events.amazonaws.com')],
                conditions: {
                    ArnEquals: {
                        'aws:SourceArn': loadRule.ruleArn,
                    },
                },
            }),
        );

        // alert when a failed eventbridge message is added to the DLQ
        // the alarm will only trigger when there is a change of state
        const eventbridgeDlqAlarm = new Alarm(this, 'eventbridge-load-rule-dlq-alarm', {
            alarmName: `${grsiPrefix}-eventbridge-load-rule-dlq-${stackConfig.regionEnv}`,
            alarmDescription: `To notify when eventbridge load lamba rule fails and message is added to dlq. Downstream dlq publishes to sns notifications and team will be emailed`,
            metric: eventbridgeDlq.metricApproximateNumberOfMessagesVisible(),
            threshold: 1,
            evaluationPeriods: 1,
            comparisonOperator: ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD,
            treatMissingData: TreatMissingData.IGNORE,
        });

        const snsAction = new SnsAction(topic);
        eventbridgeDlqAlarm.addAlarmAction(snsAction);
        eventbridgeDlqAlarm.addOkAction(snsAction);

        ////////
        // after the load is triggered we must verify the file COPY command status in redshift, if it completed, failed etc
        ////////

        const verifyLambda = new NodejsFunction(this, 'verify-lambda-function', {
            functionName: `${grsiPrefix}-verify-lambda-${stackConfig.regionEnv}`,
            runtime: Runtime.NODEJS_18_X,
            memorySize: 256,
            timeout: Duration.minutes(5),
            deadLetterTopic: topic,
            entry: path.join(__dirname, 'lambda/verify-redshift-copy/index.ts'),
            role: ingestionLambdaRole,
            tracing: Tracing.ACTIVE,
            layers: [utilityLayer],
            environment: {
                // TODO: Need to confirm if file manifest will be in verify lambda
                FILE_MANIFEST_TABLE: fileManifestTable.tableName,
                REGION: Aws.REGION,
                CLUSTER_NAME: `${grsiPrefix}-redshift-${stackConfig.regionEnv}`,
                VERIFY_QUEUE_URL: verifyRedshiftQueue.queueUrl,
                DEAD_LETTER_QUEUE_URL: dlq.queueUrl,
                NOTIFICATION_TOPIC_ARN: topic.topicArn,
                TEST_OBJECT_KEY: stackConfig.unhappyPathIngestionAlertingTestS3KeyPath,
            },
        });

        new EventInvokeConfig(this, 'verifyLambda-invocation-config', {
            function: verifyLambda,
            retryAttempts: 2,
            onFailure: new SnsDestination(topic),
        }).node.addDependency(topic);

        const verifyQueueInterface = Queue.fromQueueArn(
            this,
            'verify-redshift-queue-interface',
            verifyRedshiftQueue.queueArn,
        );
        const verifyEventSource = new lambdaEventSources.SqsEventSource(verifyQueueInterface);
        verifyLambda.addEventSource(verifyEventSource);
        verifyLambda.node.addDependency(ingestionLambdaRole);
    }
}
