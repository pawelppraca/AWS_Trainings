export interface S3PutEvent {
    version?: string;
    id?: string;
    'detail-type'?: string;
    source?: string;
    account?: string;
    time?: Date;
    region?: string;
    resources?: string[];
    detail: Detail;
}

export interface Detail {
    version?: string;
    bucket: Bucket;
    object: Object; // eslint-disable-line
    'request-id'?: string;
    requester?: string;
    'source-ip-address'?: string;
    reason?: string;
}

export interface Bucket {
    name: string;
}

export interface Object {
    key: string;
    size?: number;
    etag: string;
    sequencer?: string;
}
