import { S3 } from 'aws-sdk';
import { S3Client, GetObjectTaggingCommand, PutObjectTaggingCommand, GetObjectTaggingOutput } from '@aws-sdk/client-s3';
import {
    PutItemCommand,
    PutItemCommandInput,
    DynamoDBClient,
    GetItemCommand,
    GetItemCommandInput,
} from '@aws-sdk/client-dynamodb';

export async function writeDynamodbRecord(dynamoDBClient: DynamoDBClient, params: PutItemCommandInput): Promise<any> {
    const recordLock = new PutItemCommand(params);
    try {
        const writeLock = await dynamoDBClient.send(recordLock);
        console.log(`DynamoDB: lock written for file: `, writeLock);
        return writeLock;
    } catch (err: any) {
        if (err.name == 'ConditionalCheckFailedException') {
            return err.name;
        }
        console.error(`Error in DynamoDB Put: ${err.toString()}`);
        throw err;
    }
}

export async function writeToManifest(dynamoDBClient: DynamoDBClient, params: PutItemCommandInput) {
    const writeRecord = new PutItemCommand(params);
    try {
        return await dynamoDBClient.send(writeRecord);
    } catch (err: any) {
        console.error(`Error in DynamoDB Put: ${err.toString()}`);
        throw err;
    }
}

export async function getS3Tags(S3Client: S3Client, bucket: string, key: string) {
    try {
        console.log(bucket, key);
        const getObjectTags = new GetObjectTaggingCommand({
            Bucket: bucket,
            Key: key,
        });
        return await S3Client.send(getObjectTags);
    } catch (err) {
        console.error('Error in getting s3 object tags');
        throw err;
    }
}

export async function tagS3Object(S3Client: S3Client, bucket: string, key: string, newTags: S3.TagSet) {
    try {
        const currentObjectTags: GetObjectTaggingOutput = await getS3Tags(S3Client, bucket, key);
        const putObjectTags = new PutObjectTaggingCommand({
            Bucket: bucket,
            Key: key,
            Tagging: {
                // Gets the current existing tags, updates them if they exist, add our new tags
                TagSet: [
                    ...new Map(
                        // if TagSet returned is undefined, pass empty array
                        [...(currentObjectTags.TagSet !== undefined ? currentObjectTags.TagSet : []), ...newTags].map(
                            (k) => [k.Key, k],
                        ),
                    ).values(),
                ],
            },
        });
        return await S3Client.send(putObjectTags);
    } catch (err) {
        console.error('Error in tagging s3 object');
        throw err;
    }
}
