<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->

- [Load](#load)
  - [Overview](#overview)
  - [Architecture](#architecture)
  - [Useful notes](#useful-notes)
    - [Use of eTag for locking](#use-of-etag-for-locking)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

# Load

## Overview

The load stack is responsible for the ingestion of data into Redshift that lands in the ingestion bucket. It works by creating an event when files arrive in S3, which triggers a lambda. This lambda will then run a COPY command on our Redshift instance to ingest this data into Redshift.

## Architecture

The full application architecture diagram can be found [here](https://lucid.app/lucidchart/f9b4de7e-f18f-4500-beb3-cad3bace6190/edit?invitationId=inv_974810a1-a06f-4303-a500-a885c74587a6&page=om-~DA0lPWC5#).

## Useful notes

### Use of eTag for locking

The eTag of the object in S3 is written to our locking table (DynamoDB) in order to ensure idempotent copies to Redshift. This is particularly important due to the at-least-once nature of events in S3. This eTag is NOT deterministic, so care must be taken to not write files to S3 more than once (though this is mitigated by truncating the table in Redshift before the COPY command is run).