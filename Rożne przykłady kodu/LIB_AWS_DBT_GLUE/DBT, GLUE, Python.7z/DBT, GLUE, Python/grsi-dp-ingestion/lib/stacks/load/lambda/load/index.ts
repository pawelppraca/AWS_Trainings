import {
    AttributeValue,
    DynamoDBClient,
    GetItemCommand,
    GetItemCommandInput,
    GetItemCommandOutput,
    UpdateItemCommand,
    UpdateItemCommandInput,
    UpdateItemCommandOutput,
} from '@aws-sdk/client-dynamodb';
import { SQSClient, SendMessageCommand } from '@aws-sdk/client-sqs';
import { S3Client, GetObjectTaggingCommand } from '@aws-sdk/client-s3';
// import { S3Client, GetObjectTaggingCommand, PutObjectTaggingCommand, GetObjectTaggingOutput } from '@aws-sdk/client-s3';
import { S3PutEvent } from './S3PutEvent';
import { Context } from 'aws-lambda';
import { getExpiryTime } from './util';
import {
    DescribeStatementCommand,
    DescribeStatementCommandInput,
    ExecuteStatementCommand,
    ExecuteStatementCommandOutput,
    GetStatementResultCommand,
    GetStatementResultCommandOutput,
    RedshiftDataClient,
} from '@aws-sdk/client-redshift-data';
import * as AWSXRay from 'aws-xray-sdk';
import { writeDynamodbRecord, writeToManifest, tagS3Object, getS3Tags } from '../utils/utils';

async function getItemCommand(dynamoDBClient: DynamoDBClient, params: GetItemCommandInput) {
    const getRecord = new GetItemCommand(params);
    try {
        return await dynamoDBClient.send(getRecord);
    } catch (err) {
        throw `Error using the get command from DynamoDB: ${err}`;
    }
}

async function updateItemCommand(dynamoDBClient: DynamoDBClient, params: UpdateItemCommandInput) {
    const updateRecord = new UpdateItemCommand(params);
    try {
        return await dynamoDBClient.send(updateRecord);
    } catch (err) {
        throw `Error updating DynamoDB: ${err}`;
    }
}

async function getStatementResult(
    redshiftDataClient: RedshiftDataClient,
    statementId: string,
): Promise<GetStatementResultCommandOutput> {
    return redshiftDataClient
        .send(
            new GetStatementResultCommand({
                Id: statementId,
            }),
        )
        .catch((err: Error) => {
            console.error(`${err.toString()}`);
            throw err;
        });
}

async function executeAndReturnQueryResult(
    redshiftDataClient: RedshiftDataClient,
    query: string,
    clusterIdentifier: string,
    databaseName: string,
): Promise<GetStatementResultCommandOutput> {
    console.log('Executing Query :', query);
    const executeResponse: ExecuteStatementCommandOutput = await executeRedshiftStatement(
        redshiftDataClient,
        query,
        clusterIdentifier,
        databaseName,
    );

    if (!executeResponse.Id) {
        throw new Error('Failed to execute statement');
    }

    const statementId = executeResponse.Id;

    console.log('Polling for Query Completion');
    let isFinished = false;
    let backoffTime = 1000;
    const checkQueryStatus = new DescribeStatementCommand({ Id: statementId });
    while (!isFinished) {
        const describeResponse = await redshiftDataClient.send(checkQueryStatus);

        if (describeResponse.Status === 'FINISHED') {
            isFinished = true;
        } else if (describeResponse.Status === 'FAILED' || describeResponse.Status === 'ABORTED') {
            throw new Error(`Query execution failed with status: ${describeResponse.Status}`);
        } else {
            console.log(`Current status: ${describeResponse.Status}. Waiting for 5 seconds before retrying...`);
            await new Promise((resolve) => setTimeout(resolve, backoffTime));
            backoffTime = Math.min(backoffTime * 2, 15000);
        }
    }

    console.log('Getting Query Result Output');
    const resultResponse: GetStatementResultCommandOutput = await getStatementResult(redshiftDataClient, statementId);
    console.log('Query Result Output Response:', JSON.stringify(resultResponse, null, 2));

    return resultResponse;
}

async function executeRedshiftStatement(
    redshiftDataClient: RedshiftDataClient,
    query: string,
    clusterIdentifier: string,
    databaseName: string,
): Promise<ExecuteStatementCommandOutput> {
    return redshiftDataClient
        .send(
            new ExecuteStatementCommand({
                Sql: query,
                ClusterIdentifier: clusterIdentifier,
                Database: databaseName,
            }),
        )
        .catch((err: Error) => {
            console.error(`${err.toString()}`);
            throw err;
        });
}

async function getLoadID(client: S3Client, bucket: string, key: string) {
    try {
        let loadID: string | undefined;
        console.log(bucket, key);
        const getObjectTags = new GetObjectTaggingCommand({
            Bucket: bucket,
            Key: key,
        });
        const tagResponse = await client.send(getObjectTags);
        tagResponse.TagSet?.forEach((tag) => {
            if (tag.Key == 'load_id') {
                loadID = tag.Value;
            }
        });
        if (loadID == undefined) {
            throw new ReferenceError('LoadID undefined');
        }
        return loadID;
    } catch (err: any) {
        throw err;
    }
}

function setRedshiftApiXrayWhitelist() {
    const redshiftWhiteList = {
        services: {
            redshiftdata: {
                operations: {
                    executeStatement: {
                        request_parameters: ['ClusterIdentifier', 'Database', 'DbUser', 'Sql'],
                        response_parameters: ['ClusterIdentifier', 'CreatedAt', 'Database', 'DbUser', 'Id'],
                    },
                },
            },
        },
    };

    AWSXRay.appendAWSWhitelist(redshiftWhiteList);
}

const csv = 'CSV';

function getRedshiftFormattedString(key: string) {
    const fileExtension: string = key.split('.').pop()!.toUpperCase();
    let redshiftFormatString: string;
    if (fileExtension == csv) {
        redshiftFormatString = csv;
    } else {
        redshiftFormatString = `FORMAT AS ${fileExtension}`;
    }
    return redshiftFormatString;
}

function getRedshiftIgnoreHeader(key: string) {
    const fileExtension: string = key.split('.').pop()!.toUpperCase();
    let redshiftIgnoreHeader: string;
    if (fileExtension == csv) {
        redshiftIgnoreHeader = `IGNOREHEADER 1`;
    } else {
        redshiftIgnoreHeader = ``;
    }
    return redshiftIgnoreHeader;
}

export const handler = async function (event: S3PutEvent, context: Context): Promise<void> {
    const lockTable = process.env.LOCK_TABLE;
    const fileManifestTable = process.env.FILE_MANIFEST_TABLE;
    const copyColumnTable = process.env.COLUMN_ORDER_TABLE;
    const region = process.env.REGION;
    if (!process.env.CLUSTER_NAME) throw new Error('Lambda env variable CLUSTER_NAME is undefined');
    if (!process.env.REDSHIFT_ROLE) throw new Error('Lambda env variable REDSHIFT_ROLE is undefined');
    if (!process.env.REDSHIFT_DB) throw new Error('Lambda env variable REDSHIFT_DB is undefined');
    const clusterName = process.env.CLUSTER_NAME;
    const redshiftRole = process.env.REDSHIFT_ROLE;
    const redshiftDB = process.env.REDSHIFT_DB;
    const verifyQueueUrl = process.env.VERIFY_QUEUE_URL;
    const xrayHeader: string = process.env._X_AMZN_TRACE_ID!;
    const traceID: string = xrayHeader.split(';').shift()!.split('=').pop()!;
    console.info(event);

    const key = event.detail.object.key;

    if (key.includes('_temporary')) {
        console.info(`Temporary file: ${key}, skipping`);
        return;
    }

    if (key.includes('_fail')) {
        const errorMsg = `Forced Failure ${key}`;
        console.error(errorMsg);
        throw Error(errorMsg);
    }

    let dynamoClient, redshiftDataClient, s3Client, sqsClient;
    if (!process.env.IS_OFFLINE) {
        setRedshiftApiXrayWhitelist();
        // clients have the X-Ray instrumentation middleware added to their middleware stacks
        dynamoClient = AWSXRay.captureAWSv3Client(new DynamoDBClient({ region }));
        redshiftDataClient = AWSXRay.captureAWSv3Client(new RedshiftDataClient({ region }));
        s3Client = AWSXRay.captureAWSv3Client(new S3Client({ region }));
        sqsClient = AWSXRay.captureAWSv3Client(new SQSClient({ region }));
    } else {
        // for unit tests
        dynamoClient = new DynamoDBClient({ region });
        redshiftDataClient = new RedshiftDataClient({ region });
        s3Client = new S3Client({ region });
        sqsClient = new SQSClient({ region });
    }

    const eTag = event.detail.object.etag;
    const bucketName = event.detail.bucket.name;
    const s3uri = `s3://${bucketName}/${key}`;

    const now = new Date();
    const lockCreatedAt = now.toISOString();
    const expirationMs: number = 60000 * 10; // 10 minutes
    const expiryTime = getExpiryTime(now, expirationMs);

    console.info('Writing to lock table');
    const lockResp = await writeDynamodbRecord(dynamoClient, {
        TableName: lockTable,
        ConditionExpression: 'attribute_not_exists(eTag)',
        Item: {
            eTag: { S: eTag },
            status: { S: 'loadingIntoRedshift' },
            lockCreatedAt: { S: lockCreatedAt },
            key: { S: key },
            expiryTime: { N: (expiryTime.getTime() / 1000).toString() },
        },
    }).catch((err: Error) => {
        console.error(`Error: ${err.name}: ${err.message}`);
        throw err;
    });

    if (lockResp == 'ConditionalCheckFailedException') {
        console.info('Already present in lock table: Aborting');
        return;
    }

    const redshiftFormatString = getRedshiftFormattedString(key);
    const redshiftIgnoreHeader = getRedshiftIgnoreHeader(key);

    // key.split('/') should be in format [targetSchemaName, tableName, fileName]
    const writeSchemaName = key.split('/')[0];
    const targetSchemaName = writeSchemaName;
    const tableName = key.split('/')[1];

    const truncateQuery = formTruncateCommand(targetSchemaName, tableName);
    console.log(truncateQuery);
    console.log('Executing truncate Query');
    const truncateResponse = await executeRedshiftStatement(redshiftDataClient, truncateQuery, clusterName, redshiftDB);
    console.log('Truncate Response:', truncateResponse);

    if (!process.env.IS_OFFLINE) {
        const segment = AWSXRay.getSegment();
        if (segment) {
            const subSegment = segment.addNewSubsegment('Truncate Redshift Tables');
            subSegment.addSqlData({
                sanitized_query: truncateQuery,
                database_type: 'Redshift',
                user: truncateResponse.DbUser,
            });
            subSegment.addAttribute('in_progress', false);
            subSegment.close();
        }
    }

    // Write to DynamoDB to update redshift columns

    // Read from redshift staging for column list
    const selectColumnsQuery = formSelectColumnsQuery(targetSchemaName, tableName);
    console.info('Getting column list from Redshift');
    const redshiftColumnQueryResult = await executeAndReturnQueryResult(
        redshiftDataClient,
        selectColumnsQuery,
        clusterName,
        redshiftDB,
    );
    const redshiftColumnNames = getColumnNames(redshiftColumnQueryResult);

    const updateDynamoCommand: UpdateItemCommandInput = {
        TableName: copyColumnTable,
        Key: {
            Table: {
                S: tableName,
            },
            Schema: {
                S: writeSchemaName,
            },
        },
        UpdateExpression: 'SET RedshiftColumns = :rc',
        ExpressionAttributeValues: {
            ':rc': {
                S: redshiftColumnNames,
            },
        },
    };

    console.info('Writing redshift column list to DynamoDB');
    const columnMappingUpdateResponse: UpdateItemCommandOutput = await updateItemCommand(
        dynamoClient,
        updateDynamoCommand,
    );

    console.info(`Write to Redshift columns response: ${(JSON.stringify(columnMappingUpdateResponse), null, 2)}`);

    const getDynamoCommand: GetItemCommandInput = {
        TableName: copyColumnTable,
        Key: {
            Table: {
                S: tableName,
            },
            Schema: {
                S: writeSchemaName,
            },
        },
    };

    let copyColumnOrder: string = '';
    console.info('Getting column mapping from DynamoDB (S3 parquet file)');
    const columnMappingResp: GetItemCommandOutput = await getItemCommand(dynamoClient, getDynamoCommand);

    if (columnMappingResp && columnMappingResp['Item']) {
        copyColumnOrder = ` (${columnMappingResp['Item']['ColumnOrder']['S']})`;
    }

    const copyQuery: string = formCopyQuery(
        targetSchemaName,
        tableName,
        copyColumnOrder,
        bucketName,
        key,
        redshiftRole,
        redshiftFormatString,
        redshiftIgnoreHeader,
    );

    console.info(copyQuery);
    console.info('Loading...');
    const copyResponse = await executeRedshiftStatement(redshiftDataClient, copyQuery, clusterName, redshiftDB);
    const queryID = copyResponse.Id as string;
    console.log('Copy Response:', copyResponse);
    const transactionTime = copyResponse.CreatedAt;

    if (!process.env.IS_OFFLINE) {
        const segment = AWSXRay.getSegment();
        if (segment) {
            const subSegment = segment.addNewSubsegment('Copy to Redshift Statement');
            subSegment.addSqlData({ sanitized_query: copyQuery, database_type: 'Redshift', user: copyResponse.DbUser });
            subSegment.addAttribute('in_progress', false);
            subSegment.close();
        }
    }
    const invokedFunctionArn = context.invokedFunctionArn;
    const awsRequestID = context.awsRequestId;

    let loadID: string | void;
    loadID = await getLoadID(s3Client, bucketName, key);
    console.info(`Load ID: ${loadID}`);

    // Needs to be updated and moved to file verification lambda in future
    const manifestItems: Record<string, AttributeValue> = {
        s3uri: { S: s3uri },
        // TODO: load_id casing is for consistency that originates from the glue job tag
        loadID: { N: loadID! },
        queryID: { S: queryID! },
        transactionTime: { S: transactionTime!.toISOString() },
        x_amzn_trace_id: { S: traceID },
        ingestionStatus: { S: 'unknown' },
        startTime: { S: transactionTime!.toISOString() },
        endTime: { S: 'unknown' },
        // redshiftTransactionID: { S: transactionID! },
        // redshiftCopyJobId: { S: copyJobId! },
        // redshiftUserID: { N: copyResponse.DbUser! },
        invokedFunctionArn: { S: invokedFunctionArn },
        awsRequestId: { S: awsRequestID },
        event: { S: JSON.stringify(event) },
        context: { S: JSON.stringify(context) },
        copyColumnOrder: { S: copyColumnOrder },
    };

    const manifestResp = await writeToManifest(dynamoClient, {
        TableName: fileManifestTable,
        Item: manifestItems,
    });
    console.log('Write to manifest response:', manifestResp);

    console.info(`Write to File Manifest successful: ${manifestResp.$metadata.httpStatusCode}`);

    await sqsClient
        .send(
            new SendMessageCommand({
                QueueUrl: verifyQueueUrl,
                MessageBody: JSON.stringify({
                    s3BucketName: bucketName,
                    s3Key: key,
                }),
                DelaySeconds: 30,
                MessageAttributes: {
                    DelaySeconds: {
                        DataType: 'String',
                        StringValue: '30',
                    },
                    queryID: {
                        DataType: 'String',
                        StringValue: queryID,
                    },
                    RunCount: {
                        DataType: 'String',
                        StringValue: '1',
                    },
                },
            }),
        )
        .then((resp) => console.log('Response from putting message on verify queue: ', resp))
        .catch((err) => {
            console.error('Error in putting message on verify queue');
            throw err;
        });

    const newTags = [
        {
            Key: 'lastHandledBy',
            Value: invokedFunctionArn,
        },
        {
            Key: 'awsRequestID',
            Value: awsRequestID,
        },
        {
            Key: 'redshiftAPIRequestID',
            Value: queryID,
        },
    ];

    const tagResponse = await tagS3Object(s3Client, bucketName, key, newTags).catch((err: Error) => {
        console.error(`${err.name}: ${err.message}`);
        throw err;
    });
    console.log('Tag Response:', tagResponse);
};

export const getColumnNames = function (statementResult: GetStatementResultCommandOutput): string {
    const columnNames: string[] = [];
    if (statementResult.Records) {
        statementResult.Records.forEach((record) => {
            columnNames.push(record[0].stringValue!);
        });
    }
    return columnNames.join(', ');
};

export const formTruncateCommand = function (targetSchemaName: string, tableName: string): string {
    const command: string = `CALL common.sp_truncate_table('${targetSchemaName}.${tableName}')`;
    if (command.includes(';')) {
        throw 'truncate command includes ";" rejecting for possible sql injection';
    }
    return command;
};

export const formCopyQuery = function (
    targetSchemaName: string,
    tableName: string,
    columns: string,
    bucketName: string,
    key: string,
    redshiftRole: string,
    redshiftFormatString: string,
    redshiftIgnoreHeader: string,
): string {
    const command: string = [
        `COPY ${targetSchemaName}.${tableName}${columns}`,
        `FROM 's3://${bucketName}/${key}'`,
        `IAM_ROLE '${redshiftRole}'`,
        `${redshiftFormatString}`,
        `${redshiftIgnoreHeader}`,
    ].join(' ');
    if (command.includes(';')) {
        throw 'copy query includes ";" rejecting for possible sql injection';
    }
    return command;
};

export const formSelectColumnsQuery = function (schemaName: string, tableName: string): string {
    const command: string = [
        `SELECT column_name`,
        `FROM INFORMATION_SCHEMA.COLUMNS`,
        `WHERE table_schema = '${schemaName}'`,
        `AND table_name = '${tableName}'`,
        `ORDER BY ordinal_position`,
    ].join(' ');
    if (command.includes(';')) {
        throw 'select query includes ";" rejecting for possible sql injection';
    }
    return command;
};
