import { S3 } from 'aws-sdk';
import { S3Client } from '@aws-sdk/client-s3';
import { SNSClient, MessageAttributeValue } from '@aws-sdk/client-sns';
import { SQSClient, SendMessageCommand } from '@aws-sdk/client-sqs';
import {
    DescribeStatementCommandInput,
    DescribeStatementCommandOutput,
    RedshiftDataClient,
} from '@aws-sdk/client-redshift-data';
import { Context, SQSEvent } from 'aws-lambda';
import * as AWSXRay from 'aws-xray-sdk';
import { SQSMessageAttributes } from 'aws-lambda/trigger/sqs';
import { tagS3Object } from '../utils/utils';
import { getVerifyResponse, publishMessageToErrorNotificationTopic } from './utils';

export const handler = async function (event: SQSEvent, context: Context) {
    const region = process.env.REGION;
    const awsAccountID = process.env.AWS_ACCOUNT_ID;
    const verifyQueueUrl = process.env.VERIFY_QUEUE_URL;
    const notificationTopicArn = process.env.NOTIFICATION_TOPIC_ARN;
    const testObjectKey = process.env.TEST_OBJECT_KEY!;
    const copyIntoRedshiftTagKey: string = 'copiedIntoRedshift';
    console.info(event);
    console.info(context);

    let redshiftDataClient, s3Client, sqsClient, snsClient;
    if (!process.env.IS_OFFLINE) {
        setRedshiftApiXrayWhitelist();
        // clients have the X-Ray instrumentation middleware added to their middleware stacks
        redshiftDataClient = AWSXRay.captureAWSv3Client(new RedshiftDataClient({ region }));
        s3Client = AWSXRay.captureAWSv3Client(new S3Client({ region }));
        sqsClient = AWSXRay.captureAWSv3Client(new SQSClient({ region }));
        snsClient = AWSXRay.captureAWSv3Client(new SNSClient({ region }));
    } else {
        // for unit tests
        redshiftDataClient = new RedshiftDataClient({ region });
        s3Client = new S3Client({ region });
        sqsClient = new SQSClient({ region });
        snsClient = new SNSClient({ region });
    }

    const invokedFunctionArn: string = context.invokedFunctionArn;
    const awsRequestID: string = context.awsRequestId;
    // TODO: Add in for manifest work
    // const xrayHeader: string = process.env._X_AMZN_TRACE_ID!;
    // const traceID: string = xrayHeader.split(';').shift()!.split('=').pop()!;
    for (let record of event.Records) {
        const attributes: SQSMessageAttributes = record.messageAttributes;
        const redshiftQuery = {
            Id: attributes['queryID'].stringValue! as unknown as string,
        } as DescribeStatementCommandInput;
        const runCount = parseInt(attributes['RunCount'].stringValue!);
        const body: messageBody = JSON.parse(record.body);
        const s3Key: string = body.s3Key;
        const s3BucketName: string = body.s3BucketName;
        const s3uri = `s3://${s3BucketName}/${s3Key}`;
        const newTags: S3.TagSet = [
            { Key: 'lastHandledBy', Value: invokedFunctionArn },
            { Key: 'awsRequestID', Value: awsRequestID },
        ];

        if (runCount > 5) {
            console.error(
                `Redshift query has reached 5 retries ID: ${redshiftQuery.Id}. Sending alert to team and info to DLQ`,
            );

            const runCountErrorBody = verificationRunCountMessage(
                runCount,
                context,
                s3BucketName,
                s3Key,
                awsAccountID,
                region,
            );
            const errorAttributesParams: ErrorAttributesParams = { s3Key, s3BucketName, context };
            const runCountErrorAttributes = errorAttributes(errorAttributesParams);
            publishMessageToErrorNotificationTopic(
                snsClient,
                notificationTopicArn,
                runCountErrorBody,
                runCountErrorAttributes,
            );

            newTags.push({ Key: copyIntoRedshiftTagKey, Value: 'RETRY_LIMIT_EXCEEDED' });

            const tagResponse = await tagS3Object(s3Client, s3BucketName, s3Key, newTags).catch((err: Error) => {
                console.error(`${err.name}: ${err.message}`);
                throw err;
            });

            console.info(`Tag Response: ${JSON.stringify(tagResponse)}`);

            continue;
        }

        let verificationResponse = await getVerifyResponse(redshiftQuery, redshiftDataClient).catch((err: Error) => {
            console.error(`${err.name}: ${err.message}`);
            throw err;
        });

        if (verificationResponse.Status) {
            newTags.push({ Key: copyIntoRedshiftTagKey, Value: verificationResponse.Status });
        }

        const tagResponse = await tagS3Object(s3Client, s3BucketName, s3Key, newTags).catch((err: Error) => {
            console.error(`${err.name}: ${err.message}`);
            throw err;
        });
        console.log('Tag Response:', tagResponse);

        let errorMessage: Record<string, any>;
        let verificationErrorAttributes: Record<string, MessageAttributeValue>;
        let errorAttributesParams: ErrorAttributesParams;

        switch (verificationResponse.Status) {
            case 'FINISHED':
                console.info(`Load completed successfully for ${s3uri}.`);
                continue;
            case 'ABORTED':
                console.error('Load aborted. ', 'Full response: ', verificationResponse);
                errorMessage = redshiftIngestionCopyErrorMessage(
                    verificationResponse,
                    context,
                    s3BucketName,
                    s3Key,
                    awsAccountID,
                    region,
                    testObjectKey,
                );
                errorAttributesParams = { s3Key, s3BucketName, context };
                verificationErrorAttributes = errorAttributes(errorAttributesParams);
                console.error(JSON.stringify(errorMessage, null, 4));
                await publishMessageToErrorNotificationTopic(
                    snsClient,
                    notificationTopicArn,
                    errorMessage,
                    verificationErrorAttributes,
                );
                continue;
            case 'FAILED':
                console.error(
                    'Load failed with error message: ',
                    verificationResponse.Error,
                    'Full response: ',
                    verificationResponse,
                );
                errorMessage = redshiftIngestionCopyErrorMessage(
                    verificationResponse,
                    context,
                    s3BucketName,
                    s3Key,
                    awsAccountID,
                    region,
                    testObjectKey,
                );
                errorAttributesParams = { s3Key, s3BucketName, context };
                verificationErrorAttributes = errorAttributes(errorAttributesParams);
                console.error(JSON.stringify(errorMessage, null, 1));
                await publishMessageToErrorNotificationTopic(
                    snsClient,
                    notificationTopicArn,
                    errorMessage,
                    verificationErrorAttributes,
                );
                continue;
        }

        const newDelaySeconds: number = runCount ** 5;

        await sqsClient
            .send(
                new SendMessageCommand({
                    QueueUrl: verifyQueueUrl,
                    MessageBody: JSON.stringify({
                        s3BucketName: s3BucketName,
                        s3Key: s3Key,
                    }),
                    DelaySeconds: newDelaySeconds,
                    MessageAttributes: {
                        DelaySeconds: {
                            DataType: 'String',
                            StringValue: newDelaySeconds.toString(),
                        },
                        queryID: {
                            DataType: 'String',
                            StringValue: redshiftQuery.Id,
                        },
                        RunCount: {
                            DataType: 'String',
                            StringValue: (runCount + 1).toString(),
                        },
                    },
                }),
            )
            .then((resp) => console.info('Response from putting message on verify queue: ', resp))
            .catch((err) => {
                console.error('Error in putting message on verify queue');
                throw err;
            });
    }
    console.info('Verify lambda completed');
    return;
};

function setRedshiftApiXrayWhitelist() {
    const redshiftWhiteList = {
        services: {
            redshiftdata: {
                operations: {
                    executeStatement: {
                        request_parameters: ['ClusterIdentifier', 'Database', 'DbUser', 'Sql'],
                        response_parameters: ['ClusterIdentifier', 'CreatedAt', 'Database', 'DbUser', 'Id'],
                    },
                },
            },
        },
    };

    AWSXRay.appendAWSWhitelist(redshiftWhiteList);
}

export function verificationRunCountMessage(
    runCount: number,
    context: Context,
    s3BucketName: string,
    s3Key: string,
    awsAccountID: string | undefined,
    awsRegion: string | undefined,
) {
    return {
        application: 'GRSI Warehouse',
        'detail-type': 'Ingestion Load Lambda Verification Run Count Exceeded',
        errorType: `Verification lambda run count exceeded ${runCount} retries`,
        errorStatus: `Check file load status`,
        s3BucketName: s3BucketName,
        s3Key: s3Key,
        codebase: 'grsi-dp-ingestion',
        time: new Date().toISOString(),
        source: 'aws.lambda',
        version: '0',
        account: awsAccountID,
        region: awsRegion,
        id: context.awsRequestId,
        resources: [context.invokedFunctionArn],
        detail: {
            lambdaContext: context,
        },
    };
}

export function redshiftIngestionCopyErrorMessage(
    response: DescribeStatementCommandOutput,
    context: Context,
    s3BucketName: string,
    s3Key: string,
    awsAccountID: string | undefined,
    awsRegion: string | undefined,
    testObjectKey: string,
): Record<string, any> {
    const errorMessage = {
        application: `GRSI Warehouse`,
        'detail-type': 'Lambda Ingestion Failure',
        errorType: 'Verification failure of Redshift File Load (COPY) from S3',
        errorStatus: `Load ${response.Status}`,
        s3BucketName: s3BucketName,
        s3Key: s3Key,
        codebase: 'grsi-dp-ingestion',
        time: new Date().toISOString(),
        source: 'aws.lambda',
        version: '0',
        account: awsAccountID,
        region: awsRegion,
        id: context.awsRequestId,
        resources: [context.invokedFunctionArn],
        detail: {
            response: response,
            lambdaContext: context,
        },
    };

    if (s3Key.includes('test/unhappy_path/')) {
        errorMessage.application = `GRSI Warehouse: TEST ALERT - NO ACTION REQUIRED`;
        errorMessage['detail-type'] = 'Lambda Ingestion Unhappy Path Test';
    }
    return errorMessage;
}

export function errorAttributes(errorAttributesParams: ErrorAttributesParams): Record<string, MessageAttributeValue> {
    const attributes = {
        s3Key: { DataType: 'String', StringValue: errorAttributesParams.s3Key },
        s3BucketName: { DataType: 'String', StringValue: errorAttributesParams.s3BucketName },
        verifyInvokedFunctionArn: {
            DataType: 'String',
            StringValue: errorAttributesParams.context.invokedFunctionArn,
        },
        verifyFunctionAwsRequestId: {
            DataType: 'String',
            StringValue: errorAttributesParams.context.awsRequestId,
        },
    };
    if (errorAttributesParams.s3Key.includes('test/unhappy_path/')) {
        Object.assign(attributes, {
            testEvent: {
                DataType: 'String',
                StringValue: 'unhappy_path',
            },
        });
    }

    return attributes;
}

interface ErrorAttributesParams {
    s3BucketName: string;
    s3Key: string;
    context: Context;
}

interface messageBody {
    s3BucketName: string;
    s3Key: string;
}
