export function getExpiryTime(date: Date, milliseconds: number): Date {
    const result = new Date(date);
    result.setMilliseconds(result.getMilliseconds() + milliseconds);

    return result;
}
