import { SNSClient, PublishCommand, PublishCommandOutput, MessageAttributeValue } from '@aws-sdk/client-sns';
import {
    DescribeStatementCommand,
    DescribeStatementCommandInput,
    DescribeStatementCommandOutput,
    RedshiftDataClient,
} from '@aws-sdk/client-redshift-data';

export async function getVerifyResponse(
    queryID: DescribeStatementCommandInput,
    redshift: RedshiftDataClient,
): Promise<DescribeStatementCommandOutput> {
    const command = new DescribeStatementCommand(queryID);
    const response = await redshift.send(command);
    console.info(`Describe Statement Response: ${JSON.stringify(response)}`);
    return response;
}

export async function publishMessageToErrorNotificationTopic(
    snsClient: SNSClient,
    notificationTopicArn: string | undefined,
    message: Record<string, any>,
    attributes: Record<string, MessageAttributeValue>,
): Promise<PublishCommandOutput> {
    try {
        const resp = await snsClient.send(
            new PublishCommand({
                Message: JSON.stringify(message),
                MessageAttributes: attributes,
                TopicArn: notificationTopicArn,
            }),
        );
        return resp;
    } catch (error) {
        console.error('SNS Error Channel Publish Failure');
        throw error;
    }
}
