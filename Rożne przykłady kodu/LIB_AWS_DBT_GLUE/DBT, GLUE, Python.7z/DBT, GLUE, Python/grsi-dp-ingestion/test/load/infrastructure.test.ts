import { LoadResources } from '../../lib/stacks/load/load';
import { App, Stack } from 'aws-cdk-lib';
import { Match, Template } from 'aws-cdk-lib/assertions';
import { StackConfiguration } from '../../bin/config';

let euStackConfiguration: StackConfiguration;
let usStackConfiguration: StackConfiguration;
let euTemplate: Template;
let usTemplate: Template;

beforeAll(() => {
    const usApp = new App();
    process.env.aws_region = 'us-east-1';
    usStackConfiguration = new StackConfiguration();
    const usTestStack = new Stack(usApp, 'LoadTestUS');
    new LoadResources(usTestStack, 'TestLoadUSResources', usStackConfiguration);
    usTemplate = Template.fromStack(usTestStack);

    console.log(process.env.aws_region);

    const euApp = new App();
    process.env.aws_region = 'eu-west-1';
    euStackConfiguration = new StackConfiguration();
    const euTestStack = new Stack(euApp, 'LoadTestEU');
    new LoadResources(euTestStack, 'TestLoadUSResources', euStackConfiguration);
    euTemplate = Template.fromStack(euTestStack);

    console.log(process.env.aws_region);
});

describe('dynamodb table', () => {
    test('should use kms encryption', () => {
        const expectedStatement = {
            SSESpecification: {
                KMSMasterKeyId: {
                    'Fn::ImportValue': 'grsi-dp-dynamo-key-eu-sandbox',
                },
                SSEEnabled: true,
                SSEType: 'KMS',
            },
        };

        testDynamoTableProps(expectedStatement);
    });

    test('should set appropriate partition key', () => {
        const expectedStatement = {
            KeySchema: [
                {
                    AttributeName: 'eTag',
                    KeyType: 'HASH',
                },
            ],
        };

        testDynamoTableProps(expectedStatement);
    });

    test('should have point in time recovery enabled', () => {
        const expectedStatement = {
            PointInTimeRecoverySpecification: {
                PointInTimeRecoveryEnabled: true,
            },
        };

        testDynamoTableProps(expectedStatement);
    });

    function testDynamoTableProps(expectedProps: Record<string, unknown>): void {
        usTemplate.hasResourceProperties('AWS::DynamoDB::Table', { ...expectedProps });
    }
});

describe('load lambda', () => {
    test('should use the right runtime', () => {
        const expectedStatement = {
            Runtime: 'nodejs18.x',
        };

        TestLoadUSLambdaProps(expectedStatement);
    });

    test('should have tracing activated', () => {
        const expectedStatement = {
            TracingConfig: {
                Mode: 'Active',
            },
        };

        TestLoadUSLambdaProps(expectedStatement);
    });

    function TestLoadUSLambdaProps(expectedProps: Record<string, unknown>): void {
        usTemplate.hasResourceProperties('AWS::Lambda::Function', { ...expectedProps });
    }
});

describe('lambda role', () => {
    test('should assume lambda service principal', () => {
        const expectedStatement = {
            AssumeRolePolicyDocument: {
                Statement: [
                    {
                        Action: 'sts:AssumeRole',
                        Effect: 'Allow',
                        Principal: {
                            Service: 'lambda.amazonaws.com',
                        },
                    },
                ],
                Version: '2012-10-17',
            },
        };
        testLambdaRoleProps(expectedStatement);
    });

    function testLambdaRoleProps(expectedProps: Record<string, unknown>): void {
        usTemplate.hasResourceProperties('AWS::IAM::Role', { ...expectedProps });
    }
});

describe('dead letter queue', () => {
    test('should use kms encryption', () => {
        const expectedStatement = {
            KmsMasterKeyId: {
                'Fn::Join': [
                    '',
                    [
                        'arn:',
                        {
                            Ref: 'AWS::Partition',
                        },
                        ':kms:',
                        { Ref: 'AWS::Region' },
                        ':',
                        { Ref: 'AWS::AccountId' },
                        ':alias/grsi-dp-sqs-key-eu-sandbox',
                    ],
                ],
            },
        };
        testQueueProps(expectedStatement);
    });

    test('should retain messages for fourteen days', () => {
        const expectedStatement = {
            MessageRetentionPeriod: 1209600, // 14 days in seconds
        };
        testQueueProps(expectedStatement);
    });

    function testQueueProps(expectedProps: Record<string, unknown>): void {
        usTemplate.hasResourceProperties('AWS::SQS::Queue', { ...expectedProps });
    }
});

describe('lambda invocation config', () => {
    test('should retry twice', () => {
        const expectedStatement = {
            MaximumRetryAttempts: 2,
        };

        testLambdaInvocationConfig(expectedStatement);
    });

    test('should specify the correct destination', () => {
        const expectedStatement = {
            DestinationConfig: {
                OnFailure: {
                    Destination: {
                        'Fn::Join': [
                            '',
                            [
                                'arn:aws:sns:',
                                {
                                    Ref: 'AWS::Region',
                                },
                                ':',
                                {
                                    Ref: 'AWS::AccountId',
                                },
                                ':grsi-dp-notification-topic-eu-sandbox',
                            ],
                        ],
                    },
                },
            },
        };

        testLambdaInvocationConfig(expectedStatement);
    });

    test('should specify the correct lambda function', () => {
        const expectedStatement = {
            FunctionName: {
                Ref: 'TestLoadUSResourcesloadlambdafunction9610F507',
            },
        };

        testLambdaInvocationConfig(expectedStatement);
    });

    function testLambdaInvocationConfig(expectedProps: Record<string, unknown>): void {
        usTemplate.hasResourceProperties('AWS::Lambda::EventInvokeConfig', { ...expectedProps });
    }
});

describe('Alarm Test', () => {
    test('should have error alarm', () => {
        const expectedStatement = {
            AlarmDescription: 'Detect errors',
            AlarmName: 'Ingestion Bucket Error Alarm: eu-sandbox',
            ComparisonOperator: 'GreaterThanOrEqualToThreshold',
            DatapointsToAlarm: 1,
            EvaluationPeriods: 1,
            MetricName: 'errors',
            Namespace: 'Ingestion Bucket Error Alarm: eu-sandbox',
            Period: 300,
            Statistic: 'Sum',
            Threshold: 0,
            TreatMissingData: 'notBreaching',
        };

        testCloudWatchAlarmProps(expectedStatement);
    });
    function testCloudWatchAlarmProps(expectedProps: Record<string, unknown>): void {
        usTemplate.hasResourceProperties('AWS::CloudWatch::Alarm', { ...expectedProps });
    }
});

describe('EventBridge rule', () => {
    test('should use the correct event pattern', () => {
        const expectedStatement = {
            EventPattern: {
                source: ['aws:s3'],
                'detail-type': [
                    'ObjectCreated',
                    'ObjectCreated:Put',
                    'ObjectCreated:Post',
                    'ObjectCreated:Copy',
                    'ObjectCreated:CompleteMultipartUpload',
                ],
                detail: {
                    bucket: {
                        name: ['grsi-dp-ingestion-eu-sandbox'],
                    },
                },
            },
        };

        testEventBridgeRuleProps(expectedStatement);
    });

    test('should use the correct targets', () => {
        const expectedStatement = {
            Targets: [
                {
                    Arn: {
                        'Fn::GetAtt': ['TestLoadUSResourcesloadlambdafunction9610F507', 'Arn'],
                    },
                    DeadLetterConfig: {
                        Arn: {
                            'Fn::GetAtt': ['TestLoadUSResourceseventbridgeruledeadletterqueue88FA9428', 'Arn'],
                        },
                    },
                },
            ],
        };

        testEventBridgeRuleProps(expectedStatement);
    });

    function testEventBridgeRuleProps(expectedProps: Record<string, unknown>): void {
        usTemplate.hasResourceProperties('AWS::Events::Rule', { ...expectedProps });
    }
});
