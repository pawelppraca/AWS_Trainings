import { getExpiryTime } from '../../../../lib/stacks/load/lambda/load/util';

export class MockDate extends Date {
    constructor() {
        super('1970-01-01T00:00:00.000Z');
    }
}

describe('Util', () => {
    it('should create a date with time in ms added on', () => {
        const result = getExpiryTime(new MockDate(), 60000 * 10);
        expect(result.toISOString()).toBe('1970-01-01T00:10:00.000Z');
    });
});
