/* eslint-disable */
import * as forwardLambda from '../../../../lib/stacks/load/lambda/forward';
// import createEventDetail from '../../../../lib/stacks/load/lambda/forward/index';

import { executeLambda } from '../../util/util';
import * as AWSXRay from 'aws-xray-sdk';

const errorSpy = jest.spyOn(console, 'error');

const mockEventBridgeSendFn = jest.fn();
jest.mock('@aws-sdk/client-eventbridge', () => {
    return {
        EventBridgeClient: jest.fn().mockImplementation(() => {
            return {
                send: mockEventBridgeSendFn,
            };
        }),
        PutEventsCommand: jest.requireActual('@aws-sdk/client-eventbridge').PutEventsCommand,
    };
});

const mockEvent = {
    Records: [
        {
            s3: {
                bucket: {
                    name: 'bucketName',
                    arn: 'bucketArn',
                },
                object: {
                    key: 'objectKey',
                    eTag: 'objectETag',
                },
            },
            eventName: 'eventName',
            eventSource: 'eventSource',
            eventTime: '1970-01-01T00:00:00.000Z',
        },
    ],
};

const mockTemporaryKeyEvent = {
    Records: [
        {
            s3: {
                bucket: {
                    name: 'bucketName',
                    arn: 'bucketArn',
                },
                object: {
                    key: 'key1/_temporary/file.parquet',
                    eTag: 'objectETag',
                },
            },
            eventName: 'eventName',
            eventSource: 'eventSource',
            eventTime: '1970-01-01T00:00:00.000Z',
        },
    ],
};

const mockSuccessResp = {
    status: 200,
};

describe('Forwarding Lambda', () => {
    beforeAll(() => {
        process.env.REGION = 'region';
    });

    beforeEach(() => {
        process.env.IS_OFFLINE = 'y';
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    it('should pass correct parameters to EventBridge put request', (done) => {
        mockEventBridgeSendFn.mockImplementation((params) => {
            expect(params.input.Entries[0].Detail).toEqual(
                JSON.stringify({
                    bucket: {
                        name: mockEvent.Records[0].s3.bucket.name,
                    },
                    object: {
                        key: decodeURIComponent(mockEvent.Records[0].s3.object.key),
                        etag: mockEvent.Records[0].s3.object.eTag,
                    },
                }),
            );
            expect(params.input.Entries[0].Resources).toEqual([mockEvent.Records[0].s3.bucket.arn]);
            expect(params.input.Entries[0].DetailType).toEqual(mockEvent.Records[0].eventName);
            expect(params.input.Entries[0].Source).toEqual(mockEvent.Records[0].eventSource);
            expect(params.input.Entries[0].Time).toEqual(new Date(mockEvent.Records[0].eventTime));
            return Promise.resolve(mockSuccessResp);
        });
        executeLambda(forwardLambda, mockEvent).then(() => {
            expect(mockEventBridgeSendFn).toHaveBeenCalled();
            done();
        });
    });

    it('should not call put events for a temporary key event', (done) => {
        executeLambda(forwardLambda, mockTemporaryKeyEvent).then(() => {
            expect(mockEventBridgeSendFn).toBeCalledTimes(0);
            done();
        });
    });

    it('should use x-ray for event-bridge client', (done) => {
        const mockCaptureAWSv3ClientFn = jest.fn();
        const xrayCaptureAWSv3ClientSpy = jest
            .spyOn(AWSXRay, 'captureAWSv3Client')
            .mockImplementation(mockCaptureAWSv3ClientFn);
        delete process.env.IS_OFFLINE;
        executeLambda(forwardLambda, mockEvent).catch(() => {
            expect(xrayCaptureAWSv3ClientSpy).toBeCalledTimes(1);
            done();
        });
    });
});

test('assertCreateEventDetail output with datetime s3Key', () => {
    const bucketName = 'grsi-dp-ingestion-eu-development';
    const s3Key = 'test/unhappy_path/2024-04-17T08:36:43.689Z.parquet';
    const eTag = 'fcf0117967e1f3fcec787756a11ab23c';

    const detail = forwardLambda.createEventDetail(bucketName, s3Key, eTag);

    const expectedDetail = {
        bucket: { name: 'grsi-dp-ingestion-eu-development' },
        object: { etag: 'fcf0117967e1f3fcec787756a11ab23c', key: 'test/unhappy_path/2024-04-17T08:36:43.689Z.parquet' },
    };

    expect(detail).toEqual(expectedDetail);
});

test('assertCreateEventDetail output with regular string s3Key', () => {
    const bucketName = 'grsi-dp-ingestion-eu-development';
    const s3Key = 'test/unhappy_path/fileXYZ.parquet';
    const eTag = 'fcf0117967e1f3fcec787756a11ab23c';

    const detail = forwardLambda.createEventDetail(bucketName, s3Key, eTag);

    const expectedDetail = {
        bucket: { name: 'grsi-dp-ingestion-eu-development' },
        object: { etag: 'fcf0117967e1f3fcec787756a11ab23c', key: 'test/unhappy_path/fileXYZ.parquet' },
    };

    expect(detail).toEqual(expectedDetail);
});
