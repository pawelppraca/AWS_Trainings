/* eslint-disable */
import * as loadLambda from '../../../../lib/stacks/load/lambda/load';
import { executeLambda } from '../../util/util';
import { S3PutEvent } from '../../../../lib/stacks/load/lambda/load/S3PutEvent';
import * as AWSXRay from 'aws-xray-sdk';
import { GetStatementResultCommandOutput, ExecuteStatementCommandOutput } from '@aws-sdk/client-redshift-data';
import { PutItemCommand } from '@aws-sdk/client-dynamodb';

const mockDate = new Date('1970-01-01T00:00:00.000Z');
const errorSpy = jest.spyOn(console, 'error');
const infoSpy = jest.spyOn(console, 'info');
const lockTableName = 'lockTable';
const etag = 'someHash';
const parquetKey = 'claim_center/cc_test/parquetFile.parquet';
const csvKey = 'claim_center/cc_test/csvfile.csv';
const expectedSchemeName = 'claim_center';
const expectedTableName = 'cc_test';
const bucket = {
    name: 'bucketName',
};

const mockParquetEvent: S3PutEvent = {
    detail: {
        bucket,
        object: {
            key: parquetKey,
            etag,
        },
    },
};

const mockCsvEvent: S3PutEvent = {
    detail: {
        bucket,
        object: {
            key: csvKey,
            etag,
        },
    },
};

const mockEventTemp: S3PutEvent = {
    detail: {
        bucket,
        object: {
            key: 'testKey_temporary',
            etag,
        },
    },
};

const mockEventFail: S3PutEvent = {
    detail: {
        bucket,
        object: {
            key: 'testKey_fail',
            etag,
        },
    },
};

const mockSuccessResp = {
    httpStatusCode: 200,
};

const mockCopyResp: ExecuteStatementCommandOutput = {
    $metadata: {
        httpStatusCode: 200,
    },
    Id: 'mockStatementId',
    CreatedAt: mockDate,
};

const mockFileManifestResp = {
    $metadata: {
        httpStatusCode: 200,
    },
};

const mockGetS3TagsResp = {
    TagSet: [
        {
            Key: 'load_id',
            Value: '1',
        },
    ],
};

const mockTagS3Object = jest.fn();
const mockDynamoWriteFn = jest.fn();
const mockWriteFileManifest = jest.fn();
const mockGetS3Tags = jest.fn();
jest.mock('../../../../lib/stacks/load/lambda/utils/utils', () => {
    return {
        writeDynamodbRecord: (...params: any[]) => mockDynamoWriteFn(params),
        tagS3Object: (...params: any[]) => mockTagS3Object(params),
        writeToManifest: (...params: any[]) => mockWriteFileManifest(params),
        getS3Tags: (...params: any[]) => mockGetS3Tags(params),
    };
});

const mockRedshiftSendFn = jest.fn();
jest.mock('@aws-sdk/client-redshift-data', () => {
    return {
        RedshiftDataClient: jest.fn().mockImplementation(() => {
            return {
                send: mockRedshiftSendFn,
            };
        }),
        ExecuteStatementCommand: jest.requireActual('@aws-sdk/client-redshift-data').ExecuteStatementCommand,
        GetStatementResultCommand: jest.requireActual('@aws-sdk/client-redshift-data').GetStatementResultCommand,
        DescribeStatementCommand: jest.requireActual('@aws-sdk/client-redshift-data').DescribeStatementCommand,
    };
});

const mockSendSQSMessageFn = jest.fn();
jest.mock('@aws-sdk/client-sqs', () => {
    return {
        SQSClient: jest.fn().mockImplementation(() => {
            return {
                send: mockSendSQSMessageFn,
            };
        }),
        SendMessageCommand: jest.requireActual('@aws-sdk/client-sqs').SendMessageCommand,
    };
});
const mockSendDynamoFn = jest.fn();
jest.mock('@aws-sdk/client-dynamodb', () => {
    return {
        DynamoDBClient: jest.fn().mockImplementation(() => {
            return {
                send: mockSendDynamoFn,
            };
        }),
        GetItemCommand: jest.requireActual('@aws-sdk/client-dynamodb').GetItemCommand,
        SendCommand: jest.requireActual('@aws-sdk/client-dynamodb').send,
        PutItemCommand: jest.requireActual('@aws-sdk/client-dynamodb').PutItemCommand,
    };
});

jest.mock('../../../../lib/stacks/load/lambda/load/util', () => {
    return {
        getExpiryTime: () => mockDate,
    };
});

describe('Load Lambda', () => {
    beforeAll(() => {
        process.env.LOCK_TABLE = lockTableName;
        process.env.REGION = 'region';
        process.env.CLUSTER_NAME = 'clusterName';
        process.env.REDSHIFT_DB = 'dbName';
        process.env.REDSHIFT_ROLE = 'iamRole';
        process.env._X_AMZN_TRACE_ID = '1-63441c4a-abcdef012345678912345678';
    });

    beforeEach(() => {
        mockRedshiftSendFn.mockImplementation((command) => {
            if (command instanceof jest.requireActual('@aws-sdk/client-redshift-data').ExecuteStatementCommand) {
                return Promise.resolve(mockCopyResp);
            } else if (
                command instanceof jest.requireActual('@aws-sdk/client-redshift-data').GetStatementResultCommand
            ) {
                return Promise.resolve({
                    $metadata: {
                        httpStatusCode: 200,
                    },
                    Records: [[{ stringValue: 'column1' }], [{ stringValue: 'column2' }], [{ stringValue: 'column3' }]],
                    ColumnMetadata: [],
                });
            } else if (
                command instanceof jest.requireActual('@aws-sdk/client-redshift-data').DescribeStatementCommand
            ) {
                return Promise.resolve({
                    $metadata: {
                        httpStatusCode: 200,
                    },
                    Id: 'mockStatementId',
                    CreatedAt: mockDate,
                });
            }
            return Promise.reject(new Error('Unknown command type'));
        });
        mockSendSQSMessageFn.mockImplementation(() => Promise.resolve(mockSuccessResp));
        mockDynamoWriteFn.mockImplementation(() => Promise.resolve(mockSuccessResp));
        mockSendDynamoFn.mockImplementation(() => Promise.resolve(mockSuccessResp));
        mockTagS3Object.mockImplementation(() => Promise.resolve(mockSuccessResp));
        mockWriteFileManifest.mockImplementation(() => Promise.resolve(mockFileManifestResp));
        mockGetS3Tags.mockImplementation(() => Promise.resolve(mockGetS3TagsResp));
        process.env.IS_OFFLINE = 'y';
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    describe('idempotency check', () => {
        it('should skip if the file is a temporary file', (done) => {
            executeLambda(loadLambda, mockEventTemp).then(() => {
                expect(infoSpy).toBeCalledWith('Temporary file: testKey_temporary, skipping');
                done();
            });
        });

        it('should throw an error if the file is a forced failure', (done) => {
            executeLambda(loadLambda, mockEventFail).catch((err) => {
                expect(errorSpy).toBeCalledWith('Forced Failure testKey_fail');
                expect(err.errorMessage).toEqual('Forced Failure testKey_fail');
                done();
            });
        });
    });

    describe('Redshift commands', () => {
        test('formTruncateCommand should create the valid query string', (done) => {
            const truncateQuery = loadLambda.formTruncateCommand(expectedSchemeName, expectedTableName);
            const expectedTruncateQuery = `CALL common.sp_truncate_table('claim_center.cc_test')`;
            expect(truncateQuery).toBe(expectedTruncateQuery);
            done();
        });

        test('formTruncateCommand should throw error when string contains ";"', () => {
            const expectedTableName = `cc_test'); drop table claim_center.cc_test;`;

            expect(() => {
                loadLambda.formTruncateCommand(expectedSchemeName, expectedTableName);
            }).toThrow('truncate command includes ";" rejecting for possible sql injection');
        });

        test('formCopyQuery should create the valid query string', (done) => {
            let columns = '';
            let redshiftRole = 'myRole';
            let redshiftFormatString = `FORMAT AS PARQUET`;
            let redshiftIgnoreHeader = '';

            const truncateQuery = loadLambda.formCopyQuery(
                expectedSchemeName,
                expectedTableName,
                columns,
                bucket.name,
                parquetKey,
                redshiftRole,
                redshiftFormatString,
                redshiftIgnoreHeader,
            );
            const expectedTruncateQuery =
                "COPY claim_center.cc_test FROM 's3://bucketName/claim_center/cc_test/parquetFile.parquet' IAM_ROLE 'myRole' FORMAT AS PARQUET ";
            expect(truncateQuery).toBe(expectedTruncateQuery);
            done();
        });

        test('formCopyQuery should throw error when string contains ";"', () => {
            let columns = '';
            let injectionSchemeName =
                " claim_center.cc_test FROM 's3://bucketName/claim_center/cc_test/parquetFile.parquet' IAM_ROLE 'myRole' FORMAT AS PARQUET; drop table claim_center.cc_test";
            let redshiftRole = 'myRole';
            let redshiftFormatString = `FORMAT AS PARQUET`;
            let redshiftIgnoreHeader = '';

            expect(() => {
                loadLambda.formCopyQuery(
                    injectionSchemeName,
                    expectedTableName,
                    columns,
                    bucket.name,
                    parquetKey,
                    redshiftRole,
                    redshiftFormatString,
                    redshiftIgnoreHeader,
                );
            }).toThrow('copy query includes ";" rejecting for possible sql injection');
        });

        it('should log an error when the truncate query fails', (done) => {
            mockRedshiftSendFn.mockRejectedValue('Execute Statement Error');
            executeLambda(loadLambda, mockParquetEvent).catch(() => {
                expect(mockRedshiftSendFn).toHaveBeenCalledTimes(1);
                expect(errorSpy).toHaveBeenCalledWith('Execute Statement Error');
                done();
            });
        });
    });

    describe('getColumnNames', () => {
        it('should return column names as a comma-separated string', () => {
            const mockResult: GetStatementResultCommandOutput = {
                $metadata: {
                    httpStatusCode: 200,
                },
                Records: [[{ stringValue: 'column1' }], [{ stringValue: 'column2' }], [{ stringValue: 'column3' }]],
                ColumnMetadata: [],
            };
            const columnNames = loadLambda.getColumnNames(mockResult);
            expect(columnNames).toBe('column1, column2, column3');
        });

        it('should return an empty string if no records are found', () => {
            const mockResult: GetStatementResultCommandOutput = {
                $metadata: {
                    httpStatusCode: 200,
                },
                Records: [],
                ColumnMetadata: [],
            };
            const columnNames = loadLambda.getColumnNames(mockResult);
            expect(columnNames).toBe('');
        });
    });

    describe('formSelectColumnsQuery', () => {
        it('should create a valid query string', () => {
            const schemaName = 'testSchema';
            const tableName = 'testTable';
            const query = loadLambda.formSelectColumnsQuery(schemaName, tableName);
            const expectedQuery = [
                `SELECT column_name`,
                `FROM INFORMATION_SCHEMA.COLUMNS`,
                `WHERE table_schema = 'testSchema'`,
                `AND table_name = 'testTable'`,
                `ORDER BY ordinal_position`,
            ].join(' ');
            expect(query).toBe(expectedQuery);
        });

        it('should throw an error if query contains ";"', () => {
            const schemaName = 'testSchema;';
            const tableName = 'testTable';
            expect(() => {
                loadLambda.formSelectColumnsQuery(schemaName, tableName);
            }).toThrow('select query includes ";" rejecting for possible sql injection');
        });
    });

    describe('Get load ID', () => {
        it('should give correct logging if it succeeds', () => {
            executeLambda(loadLambda, mockParquetEvent).then(() => {
                expect(infoSpy).toBeCalledWith('Load ID: 1');
            });
        });
    });

    describe('X-Ray', () => {
        const mockCaptureAWSv3ClientFn = jest.fn();
        const mockXrayAppendAWSWhitelistFn = jest.fn();
        const xrayCaptureAWSv3ClientSpy = jest
            .spyOn(AWSXRay, 'captureAWSv3Client')
            .mockImplementation(mockCaptureAWSv3ClientFn);
        const xrayAppendAWSWhitelistSpy = jest
            .spyOn(AWSXRay, 'appendAWSWhitelist')
            .mockImplementation(mockXrayAppendAWSWhitelistFn);

        beforeEach(() => {
            mockCaptureAWSv3ClientFn.mockImplementation(() => Promise.resolve('Success'));
            mockXrayAppendAWSWhitelistFn.mockImplementation(() => Promise.resolve('Success'));
            delete process.env.IS_OFFLINE;
        });

        afterEach(() => {
            jest.clearAllMocks();
        });

        it('should call captureAWSv3Client 4 times for v3 clients in use - Redshift, DynamoDB, S3, SQS', (done) => {
            executeLambda(loadLambda, mockParquetEvent).catch(() => {
                expect(xrayCaptureAWSv3ClientSpy).toBeCalledTimes(4);
                done();
            });
        });

        it('should call appendWhiteList for Redshift Data Execute Statement', (done) => {
            executeLambda(loadLambda, mockParquetEvent).catch(() => {
                expect(xrayAppendAWSWhitelistSpy).toBeCalledTimes(1);
                const json = {
                    services: {
                        redshiftdata: {
                            operations: {
                                executeStatement: {
                                    request_parameters: ['ClusterIdentifier', 'Database', 'DbUser', 'Sql'],
                                    response_parameters: ['ClusterIdentifier', 'CreatedAt', 'Database', 'DbUser', 'Id'],
                                },
                            },
                        },
                    },
                };
                expect(xrayAppendAWSWhitelistSpy).toBeCalledWith(json);
                done();
            });
        });
    });
});
