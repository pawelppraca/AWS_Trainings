/* eslint-disable */
import * as verifyLambda from '../../../../lib/stacks/load/lambda/verify-redshift-copy';
import { executeLambda } from '../../util/util';
import * as AWSXRay from 'aws-xray-sdk';

const mockDate = new Date('1970-01-01T00:00:00.000Z');
const errorSpy = jest.spyOn(console, 'error');
const infoSpy = jest.spyOn(console, 'info');
const lockTableName = 'lockTable';
const etag = 'someHash';
const key = 'claim_center/cc_test/parquetFile';
const s3BucketName = 'bucketName';
const s3Key = 'key';
const expectedTableName = 'cc_test';
const bucket = {
    name: 'bucketName',
};

interface SQSEvent {
    Records: SQSRecord[];
}

interface SQSRecord {
    messageId: string;
    body: string;
    messageAttributes: SQSMessageAttributes;
}

interface SQSMessageAttribute {
    stringValue?: string | undefined;
}
interface SQSMessageAttributes {
    [name: string]: SQSMessageAttribute;
}

interface SendMessageCommand {
    QueueUrl: string;
    MessageBody: string;
}

const mockSuccessResp = {
    httpStatusCode: 200,
};

interface DescribeStatementCommandInput {
    Id: string;
}

const queryId: DescribeStatementCommandInput = {
    Id: 'TestId',
};

interface DescribeStatementCommandOutput {
    Status: string;
    Error?: string;
}

const verifyStartedResponse: DescribeStatementCommandOutput = {
    Status: 'STARTED',
};

const verifyExceededResponse: DescribeStatementCommandOutput = {
    Status: 'RETRY_LIMIT_EXCEEDED',
};

const verifySuccessResponse: DescribeStatementCommandOutput = {
    Status: 'FINISHED',
};

const verifyAbortedResponse: DescribeStatementCommandOutput = {
    Status: 'ABORTED',
};

const verifyAbortedMessage = {
    application: 'GRSI Warehouse: TEST ALERT - NO ACTION REQUIRED',
    'detail-type': 'Lambda Ingestion Unhappy Path Test',
    errorType: 'Verification failure of Redshift File Load (COPY) from S3',
    errorStatus: 'Load FAILED',
    s3BucketName: 'grsi-dp-ingestion-us-development',
    s3Key: 'test/unhappy_path/integration.parquet',
    codebase: 'grsi-dp-ingestion',
    time: '2024-03-20T13:21:22.302Z',
    source: 'aws.lambda',
    version: '0',
    region: 'us-east-1',
    id: 'ec6496eb-2d6c-569d-ab12-c89fc8631143',
    resources: ['arn:aws:lambda:us-east-1:373258796386:function:grsi-dp-verify-lambda-us-development'],
    detail: {
        response: {
            $metadata: {
                httpStatusCode: 200,
                requestId: '04394768-0b2b-44f5-ac2f-42d2b23ed3c6',
                attempts: 1,
                totalRetryDelay: 0,
            },
            ClusterIdentifier: 'grsi-dp-redshift-us-development',
            CreatedAt: '2024-03-20T13:20:50.111Z',
            Duration: -1,
            Error: 'ERROR: Cannot COPY into nonexistent table unhappy_path',
            HasResultSet: false,
            Id: 'b33821ee-d4e9-4657-b8cd-7405baa0e09f',
            QueryString:
                "\\n            COPY staging_test.unhappy_path\\n            FROM 's3://grsi-dp-ingestion-us-development/test/unhappy_path/integration.parquet'\\n            IAM_ROLE ''\\n            FORMAT AS PARQUET\\n            \\n        ",
            RedshiftPid: 1073914184,
            RedshiftQueryId: -1,
            ResultRows: -1,
            ResultSize: -1,
            Status: 'FAILED',
            UpdatedAt: '2024-03-20T13:20:50.550Z',
        },
        lambdaContext: {
            callbackWaitsForEmptyEventLoop: true,
            functionVersion: '$LATEST',
            functionName: 'grsi-dp-verify-lambda-us-development',
            memoryLimitInMB: '256',
            logGroupName: '/aws/lambda/grsi-dp-verify-lambda-us-development',
            logStreamName: '2024/03/20/[$LATEST]c028c6e88b0e449e9c43a9a0c468a6e3',
            invokedFunctionArn: 'arn:aws:lambda:us-east-1:373258796386:function:grsi-dp-verify-lambda-us-development',
            awsRequestId: 'ec6496eb-2d6c-569d-ab12-c89fc8631143',
        },
    },
};

const verifyFailedResponse: DescribeStatementCommandOutput = {
    Status: 'FAILED',
    Error: 'Failed Response Error',
};

const mockDLQEvent: SendMessageCommand = {
    QueueUrl: 'deadLetterQueueUrl',
    MessageBody: JSON.stringify({
        Message: `Adding redshift query response to dead letter queue in state: `,
        Response: 'response',
    }),
};

const mocksnsEvent: SendMessageCommand = {
    QueueUrl: 'deadLetterQueueUrl',
    MessageBody: JSON.stringify({
        Message: `Adding redshift query response to dead letter queue in state: `,
        Response: 'response',
    }),
};

const mockSQSEntryEvent: SQSEvent = {
    Records: [
        {
            messageId: 'messageIdTest',
            body: JSON.stringify({
                s3BucketName: 'bucketName',
                s3Key: 'key',
            }),
            messageAttributes: {
                RunCount: {
                    stringValue: '1',
                },
                queryID: {
                    stringValue: 'TestId',
                },
            },
        },
    ],
};

const mockRunCountExceededSQSEntryEvent: SQSEvent = {
    Records: [
        {
            messageId: 'messageIdTest',
            body: JSON.stringify({
                s3BucketName: 'bucketName',
                s3Key: 'key',
            }),
            messageAttributes: {
                RunCount: {
                    stringValue: '6',
                },
                queryID: {
                    stringValue: 'TestId',
                },
            },
        },
    ],
};

const mockRedshiftDescribeFn = jest.fn();
jest.mock('@aws-sdk/client-redshift-data', () => {
    return {
        RedshiftDataClient: jest.fn().mockImplementation(() => {
            return {
                send: mockRedshiftDescribeFn,
            };
        }),
        DescribeStatementCommand: jest.requireActual('@aws-sdk/client-redshift-data').DescribeStatementCommand,
    };
});

const mockSendSQSMessageFn = jest.fn();
jest.mock('@aws-sdk/client-sqs', () => {
    return {
        SQSClient: jest.fn().mockImplementation(() => {
            return {
                send: mockSendSQSMessageFn,
            };
        }),
        SendMessageCommand: jest.requireActual('@aws-sdk/client-sqs').SendMessageCommand,
    };
});

const mockgetVerifyResponse = jest.fn();

const mockinsertVerifyResponseIntoDLQ = jest.fn();
jest.mock('../../../../lib/stacks/load/lambda/verify-redshift-copy/utils', () => {
    return {
        insertVerifyResponseIntoDLQ: (...params: any[]) => mockinsertVerifyResponseIntoDLQ(params),
        getVerifyResponse: (...params: any[]) => mockgetVerifyResponse(params),
    };
});

const redshiftIngestionCopyErrorMessage = jest.fn();

const mockpublishMessageToErrorNotificationTopic = jest.fn();
jest.mock('../../../../lib/stacks/load/lambda/verify-redshift-copy/utils', () => {
    return {
        publishMessageToErrorNotificationTopic: (...params: any[]) =>
            mockpublishMessageToErrorNotificationTopic(params),
        getVerifyResponse: (...params: any[]) => mockgetVerifyResponse(params),
    };
});

const mockTagS3Object = jest.fn();
jest.mock('../../../../lib/stacks/load/lambda/utils/utils', () => {
    return {
        tagS3Object: (...params: any[]) => mockTagS3Object(params),
    };
});

describe('Verify Lambda', () => {
    beforeAll(() => {
        process.env.REGION = 'region';
        process.env._X_AMZN_TRACE_ID = '1-63441c4a-abcdef012345678912345678';
    });

    beforeEach(() => {
        mockRedshiftDescribeFn.mockImplementation(() => Promise.resolve(mockSuccessResp));
        mockSendSQSMessageFn.mockImplementation(() => Promise.resolve(mockSuccessResp));
        mockTagS3Object.mockImplementation(() => Promise.resolve(mockSuccessResp));
        process.env.IS_OFFLINE = 'y';
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    describe('Tag files in S3', () => {
        beforeEach(() => {
            mockgetVerifyResponse.mockImplementation(() => Promise.resolve(verifyStartedResponse));
        });
        it('should call s3 tagging one time', (done) => {
            mockTagS3Object.mockImplementation(() => {
                return Promise.resolve(mockSuccessResp);
            });
            executeLambda(verifyLambda, mockSQSEntryEvent).then(() => {
                expect(mockTagS3Object).toHaveBeenCalledTimes(1);
                done();
            });
        });

        it('should log an error when there is an error with s3 tagging', (done) => {
            mockTagS3Object.mockRejectedValue({
                name: 'S3TaggingError',
                message: 'S3 Tagging Error has occurred',
            });
            executeLambda(verifyLambda, mockSQSEntryEvent).catch((err) => {
                expect(mockTagS3Object).toHaveBeenCalledTimes(1);
                expect(errorSpy).toHaveBeenCalledWith(`${err.name}: ${err.message}`);
                done();
            });
        });
    });

    describe('Add message to SQS', () => {
        it('should give error when verify function fails - started response', (done) => {
            mockgetVerifyResponse.mockRejectedValue({
                name: 'Redshift Query Error',
                message: 'Redshift Query Error has occurred',
            });
            executeLambda(verifyLambda, mockSQSEntryEvent).catch((err) => {
                expect(errorSpy).toHaveBeenCalledWith(`${err.name}: ${err.message}`);
                done();
            });
        });

        it('should call SQS one time - started response', (done) => {
            mockgetVerifyResponse.mockImplementation(() => Promise.resolve(verifyStartedResponse));
            mockSendSQSMessageFn.mockImplementation(() => {
                return Promise.resolve(verifyStartedResponse);
            });
            executeLambda(verifyLambda, mockSQSEntryEvent).then(() => {
                expect(mockTagS3Object).toHaveBeenCalledTimes(1);
                expect(mockSendSQSMessageFn).toHaveBeenCalledTimes(1);
                done();
            });
        });

        it('should log an error when there is an error with SQS function', (done) => {
            mockSendSQSMessageFn.mockRejectedValue({
                name: 'SQS Error',
                message: 'SQS Error has occurred',
            });
            executeLambda(verifyLambda, mockSQSEntryEvent).catch((err) => {
                expect(mockSendSQSMessageFn).toHaveBeenCalledTimes(1);
                expect(errorSpy).toHaveBeenCalledWith('Error in putting message on verify queue');
                done();
            });
        });
    });
});

describe('Check all verify status', () => {
    it('verify response: "FINISHED" - should tag S3 object one time', (done) => {
        mockgetVerifyResponse.mockImplementation(() => Promise.resolve(verifySuccessResponse));
        mockTagS3Object.mockImplementation(() => {
            return Promise.resolve(verifySuccessResponse);
        });
        executeLambda(verifyLambda, mockSQSEntryEvent).then(() => {
            expect(mockTagS3Object).toHaveBeenCalledTimes(1);
            expect(infoSpy).toBeCalledWith('Load completed successfully for s3://bucketName/key.');
            done();
        });
    });
    afterEach(() => {
        jest.clearAllMocks();
    });

    it('verify response: "ABORTED" - should tag S3 object one time', (done) => {
        mockgetVerifyResponse.mockImplementation(() => Promise.resolve(verifyAbortedResponse));
        mockTagS3Object.mockImplementation(() => {
            return Promise.resolve(verifyAbortedResponse);
        });
        mockpublishMessageToErrorNotificationTopic.mockImplementation(() => Promise.resolve());
        executeLambda(verifyLambda, mockSQSEntryEvent).then(() => {
            expect(mockTagS3Object).toHaveBeenCalledTimes(1);
            done();
        });
    });
    afterEach(() => {
        jest.clearAllMocks();
    });

    it('verify response: "FAILED" - should tag S3 object one time', (done) => {
        mockgetVerifyResponse.mockImplementation(() => Promise.resolve(verifyAbortedResponse));
        mockTagS3Object.mockImplementation(() => {
            return Promise.resolve(verifyAbortedResponse);
        });
        mockpublishMessageToErrorNotificationTopic.mockImplementation(() => Promise.resolve());
        executeLambda(verifyLambda, mockSQSEntryEvent).then(() => {
            expect(mockTagS3Object).toHaveBeenCalledTimes(1);
            done();
        });
    });
    afterEach(() => {
        jest.clearAllMocks();
    });

    it('should tag S3 object one time - Exceeded run count', (done) => {
        mockTagS3Object.mockImplementation(() => {
            return Promise.resolve(queryId);
        });
        executeLambda(verifyLambda, mockRunCountExceededSQSEntryEvent).then(() => {
            expect(mockTagS3Object).toHaveBeenCalledTimes(1);
            expect(errorSpy).toBeCalledWith(
                `Redshift query has reached 5 retries ID: ${queryId.Id}. Sending alert to team and info to DLQ`,
            );
            done();
        });
    });

    it('should throw S3 tagging error - Exceeded run count tagging error', (done) => {
        mockTagS3Object.mockRejectedValue({
            name: 'S3TaggingError',
            message: 'S3 Tagging Error has occurred',
        });
        executeLambda(verifyLambda, mockRunCountExceededSQSEntryEvent).catch((err) => {
            expect(mockTagS3Object).toHaveBeenCalledTimes(1);
            expect(errorSpy).toHaveBeenCalledWith(`${err.name}: ${err.message}`);
            done();
        });
    });
});
