/* eslint-disable */
import * as lambdaLocal from 'lambda-local';

export function executeLambda(lambdaFunc: any, event: any) {
    return lambdaLocal.execute({
        event,
        lambdaFunc,
    });
}
