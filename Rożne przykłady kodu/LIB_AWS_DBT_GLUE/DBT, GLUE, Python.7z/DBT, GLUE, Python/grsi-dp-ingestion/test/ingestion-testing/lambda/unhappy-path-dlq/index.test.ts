/* eslint-disable */

import * as testUnhappyPath from '../../../../lib/stacks/ingestion-testing/lambda/unhappy-path-dlq/index';
import * as lambdaLocal from 'lambda-local';
import { expect, test } from '@jest/globals';

export function executeLambda(lambdaFunc: any, event: any) {
    return lambdaLocal.execute({
        event,
        lambdaFunc,
    });
}

test('asserts3TagsToString output', () => {
    const tags = {
        load_id: -2,
        organization_guid: '2326c977-2f8d-4d97-8f13-a7ca2fd5d5db',
        testFunctionAwsRequestId: 'ba72f281-94b8-46e0-a655-ab415801f3d8',
    };
    const expectedTagString =
        'load_id=-2&organization_guid=2326c977-2f8d-4d97-8f13-a7ca2fd5d5db&testFunctionAwsRequestId=ba72f281-94b8-46e0-a655-ab415801f3d8';
    expect(testUnhappyPath.s3TagsToString(tags)).toBe(expectedTagString);
});
