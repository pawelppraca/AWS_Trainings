import { ExtractionResources } from '../../lib/stacks/extraction/extraction';
import { App, Stack } from 'aws-cdk-lib';
import { Template } from 'aws-cdk-lib/assertions';
import { StackConfiguration } from '../../bin/config';

const stackConfiguration = new StackConfiguration();
let template: Template;
const sandbox = 'sandbox';

beforeAll(() => {
    const app = new App();
    const testStack = new Stack(app, 'ExtractionServiceTest');
    new ExtractionResources(testStack, 'TestExtractionServiceResources', stackConfiguration);

    template = Template.fromStack(testStack);
});

describe('S3 bucket', () => {
    test('should use kms encryption', () => {
        const expectedStatement = {
            BucketEncryption: {
                ServerSideEncryptionConfiguration: [
                    {
                        BucketKeyEnabled: true,
                        ServerSideEncryptionByDefault: {
                            KMSMasterKeyID: {
                                'Fn::ImportValue': 'grsi-dp-glue-script-key-sandbox',
                            },
                            SSEAlgorithm: 'aws:kms',
                        },
                    },
                ],
            },
            BucketName: 'grsi-dp-glue-script-eu-sandbox',
            PublicAccessBlockConfiguration: {
                BlockPublicAcls: true,
                BlockPublicPolicy: true,
                IgnorePublicAcls: true,
                RestrictPublicBuckets: true,
            },
        };
        template.hasResourceProperties('AWS::S3::Bucket', expectedStatement);
    });
});

describe('Table Definition Glue Job', () => {
    it('should reference s3 bucket for scripts', () => {
        const expectedStatement = {
            Command: {
                ScriptLocation: {
                    'Fn::Join': [
                        '',
                        [
                            's3://',
                            {
                                Ref: 'TestExtractionServiceResourcesGlueScriptBucket64251B5E',
                            },
                            '/scripts/extract-table-definition.py',
                        ],
                    ],
                },
            },
            Name: 'grsi-dp-extract-table-definition-sandbox',
        };
        template.hasResourceProperties('AWS::Glue::Job', expectedStatement);
    });

    it('should use vpc connection', () => {
        const expectedStatement = {
            Connections: {
                Connections: [
                    {
                        Ref: 'TestExtractionServiceResourcesConnection7BD8C4E4',
                    },
                ],
            },
        };
        template.hasResourceProperties('AWS::Glue::Job', expectedStatement);
    });
});

describe('Glue Job', () => {
    it('should reference s3 bucket for scripts', () => {
        const expectedStatement = {
            Command: {
                ScriptLocation: {
                    'Fn::Join': [
                        '',
                        [
                            's3://',
                            {
                                Ref: 'TestExtractionServiceResourcesGlueScriptBucket64251B5E',
                            },
                            '/scripts/main.py',
                        ],
                    ],
                },
            },
            Name: 'grsi-dp-extract-sandbox',
        };
        template.hasResourceProperties('AWS::Glue::Job', expectedStatement);
    });

    it('should use vpc connection', () => {
        const expectedStatement = {
            Connections: {
                Connections: [
                    {
                        Ref: 'TestExtractionServiceResourcesConnection7BD8C4E4',
                    },
                ],
            },
        };
        template.hasResourceProperties('AWS::Glue::Job', expectedStatement);
    });
});

describe('Datalake Test Glue Job', () => {
    it('should reference s3 bucket for scripts', () => {
        const expectedStatement = {
            Command: {
                ScriptLocation: {
                    'Fn::Join': [
                        '',
                        [
                            's3://',
                            {
                                Ref: 'TestExtractionServiceResourcesGlueScriptBucket64251B5E',
                            },
                            '/scripts/datalake-test.py',
                        ],
                    ],
                },
            },
            Name: 'grsi-dp-datalake-test-sandbox',
        };
        template.hasResourceProperties('AWS::Glue::Job', expectedStatement);
    });

    it('should use vpc connection', () => {
        const expectedStatement = {
            Connections: {
                Connections: [
                    {
                        Ref: 'TestExtractionServiceResourcesConnection7BD8C4E4',
                    },
                ],
            },
        };
        template.hasResourceProperties('AWS::Glue::Job', expectedStatement);
    });
});

describe('Glue Security Group', () => {
    it('should allow outbound traffic', () => {
        const expectedStatement = {
            GroupName: 'grsi-dp-glue-security-group-eu-sandbox',
            SecurityGroupEgress: [
                {
                    CidrIp: '0.0.0.0/0',
                    Description: 'Allow all outbound traffic by default',
                    IpProtocol: '-1',
                },
            ],
        };
        template.hasResourceProperties('AWS::EC2::SecurityGroup', expectedStatement);
    });

    it('should have a self-referencing rule', () => {
        const expectedStatement = {
            FromPort: 0,
            GroupId: {
                'Fn::GetAtt': ['TestExtractionServiceResourcesSecurityGroup1DD3A232', 'GroupId'],
            },
            IpProtocol: 'tcp',
            SourceSecurityGroupId: {
                'Fn::GetAtt': ['TestExtractionServiceResourcesSecurityGroup1DD3A232', 'GroupId'],
            },
            ToPort: 65535,
        };
        template.hasResourceProperties('AWS::EC2::SecurityGroupIngress', expectedStatement);
    });
});

describe('Alarm Test', () => {
    test('should have error alarm', () => {
        const expectedStatement = {
            AlarmDescription: 'Detect errors',
            AlarmName: `Extraction Bucket Error Alarm: eu-sandbox`,
            ComparisonOperator: 'GreaterThanOrEqualToThreshold',
            DatapointsToAlarm: 1,
            EvaluationPeriods: 1,
            MetricName: 'errors',
            Namespace: 'Extraction Bucket Error Alarm: eu-sandbox',
            Period: 300,
            Statistic: 'Sum',
            Threshold: 0,
            TreatMissingData: 'notBreaching',
        };

        testCloudWatchAlarmProps(expectedStatement);
    });
    function testCloudWatchAlarmProps(expectedProps: Record<string, unknown>): void {
        template.hasResourceProperties('AWS::CloudWatch::Alarm', { ...expectedProps });
    }
});

describe('Notification Event Rule', () => {
    it('should target notification SNS when glue job has state change', () => {
        const expectedStatement = {
            EventPattern: {
                source: ['aws.glue'],
                'detail-type': ['Glue Job State Change'],
                detail: {
                    state: ['SUCCEEDED', 'FAILED', 'TIMEOUT', 'STOPPED', 'ERROR'],
                },
            },
            State: 'ENABLED',
            Targets: [
                {
                    Arn: {
                        'Fn::Join': [
                            '',
                            [
                                'arn:aws:sns:',
                                {
                                    Ref: 'AWS::Region',
                                },
                                ':',
                                {
                                    Ref: 'AWS::AccountId',
                                },
                                ':grsi-dp-notification-topic-eu-sandbox',
                            ],
                        ],
                    },
                },
            ],
        };
        template.hasResourceProperties('AWS::Events::Rule', expectedStatement);
    });
});

describe('dynamodb table', () => {
    test('should use kms encryption', () => {
        const expectedStatement = {
            SSESpecification: {
                KMSMasterKeyId: {
                    'Fn::ImportValue': 'grsi-dp-dynamo-key-eu-sandbox',
                },
                SSEEnabled: true,
                SSEType: 'KMS',
            },
        };

        testDynamoTableProps(expectedStatement);
    });

    test('should set appropriate partition key', () => {
        const expectedStatement = {
            KeySchema: [
                {
                    AttributeName: 'Counter',
                    KeyType: 'HASH',
                },
            ],
        };

        testDynamoTableProps(expectedStatement);
    });

    test('should have point in time recovery enabled', () => {
        const expectedStatement = {
            PointInTimeRecoverySpecification: {
                PointInTimeRecoveryEnabled: true,
            },
        };

        testDynamoTableProps(expectedStatement);
    });

    function testDynamoTableProps(expectedProps: Record<string, unknown>): void {
        template.hasResourceProperties('AWS::DynamoDB::Table', { ...expectedProps });
    }
});
