import { SourceResources } from '../../lib/stacks/source/source';
import { App, Stack } from 'aws-cdk-lib';
import { Match, Template } from 'aws-cdk-lib/assertions';
import { StackConfiguration } from '../../bin/config';

let euStackConfiguration: StackConfiguration;
let usStackConfiguration: StackConfiguration;
let euTemplate: Template;
let usTemplate: Template;

beforeAll(() => {
    const usApp = new App();
    process.env.aws_region = 'us-east-1';
    usStackConfiguration = new StackConfiguration();
    const usTestStack = new Stack(usApp, 'SourceTestUS');
    new SourceResources(usTestStack, 'TestSourceUSResources', usStackConfiguration);
    usTemplate = Template.fromStack(usTestStack);

    console.log(process.env.aws_region);

    const euApp = new App();
    process.env.aws_region = 'eu-west-1';
    euStackConfiguration = new StackConfiguration();
    const euTestStack = new Stack(euApp, 'LoadTestEU');
    new SourceResources(euTestStack, 'TestLoadUSResources', euStackConfiguration);
    euTemplate = Template.fromStack(euTestStack);

    console.log(process.env.aws_region);
});

describe('ingestion S3 bucket', () => {
    test('should use KMS encryption', () => {
        const expectedStatement = {
            BucketEncryption: {
                ServerSideEncryptionConfiguration: [
                    {
                        BucketKeyEnabled: true,
                        ServerSideEncryptionByDefault: {
                            KMSMasterKeyID: {
                                'Fn::Join': [
                                    '',
                                    [
                                        'arn:',
                                        {
                                            Ref: 'AWS::Partition',
                                        },
                                        ':kms:',
                                        {
                                            Ref: 'AWS::Region',
                                        },
                                        ':',
                                        {
                                            Ref: 'AWS::AccountId',
                                        },
                                        ':alias/grsi-dp-ingestion-key-eu-sandbox',
                                    ],
                                ],
                            },
                            SSEAlgorithm: 'aws:kms',
                        },
                    },
                ],
            },
        };

        testS3BucketProps(expectedStatement);
    });

    function testS3BucketProps(expectedProps: Record<string, unknown>): void {
        usTemplate.hasResourceProperties('AWS::S3::Bucket', { ...expectedProps });
    }
});
