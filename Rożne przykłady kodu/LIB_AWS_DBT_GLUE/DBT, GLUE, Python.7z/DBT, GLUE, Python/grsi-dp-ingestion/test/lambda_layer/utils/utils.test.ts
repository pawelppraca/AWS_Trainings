import { DynamoDBClient, PutItemCommand } from '@aws-sdk/client-dynamodb';
import { tagS3Object, writeDynamodbRecord, writeToManifest } from '../../../lib/stacks/load/lambda/utils/utils';
import { S3Client } from '@aws-sdk/client-s3';

const errorSpy = jest.spyOn(console, 'error');

const mockDynamoSendFn = jest.fn();
jest.mock('@aws-sdk/client-dynamodb', () => {
    return {
        DynamoDBClient: jest.fn().mockImplementation(() => {
            return {
                send: mockDynamoSendFn,
            };
        }),
        PutItemCommand: jest.requireActual('@aws-sdk/client-dynamodb').PutItemCommand,
    };
});

const mockS3TaggingSendFn = jest.fn();
jest.mock('@aws-sdk/client-s3', () => {
    return {
        S3Client: jest.fn().mockImplementation(() => {
            return {
                send: mockS3TaggingSendFn,
            };
        }),
        PutObjectTaggingCommand: jest.requireActual('@aws-sdk/client-s3').PutObjectTaggingCommand,
        GetObjectTaggingCommand: jest.requireActual('@aws-sdk/client-s3').GetObjectTaggingCommand,
    };
});

const mockDynamoClient = new DynamoDBClient();

const mockS3Client = new S3Client();

const mockPutItemCommandInput = {
    TableName: 'mockTableName',
    Item: {},
};

const mockSuccessResp = {
    status: 200,
};

const mockFailResp = {
    status: 400,
};

const mockGetTags = {
    TagSet: [
        {
            Key: 'mockExistingTag',
            Value: 'baz',
        },
    ],
};

const mockTagSet = [
    {
        Key: 'mockTag1',
        Value: 'foo',
    },
    {
        Key: 'mockTag2',
        Value: 'bar',
    },
];

const mockTagS3Input = {
    TagSet: [
        {
            Key: 'mockExistingTag',
            Value: 'baz',
        },
        {
            Key: 'mockTag1',
            Value: 'foo',
        },
        {
            Key: 'mockTag2',
            Value: 'bar',
        },
    ],
};

const mockBucketName = 'bucketName';

const mockKey = 'someFileName';

describe('Lambda Layer', () => {
    describe('Write to lock table', () => {
        afterEach(() => {
            jest.clearAllMocks();
        });

        it('should return response if put is successful', async () => {
            mockDynamoSendFn.mockImplementation(() => {
                return Promise.resolve(mockSuccessResp);
            });
            const resp = await writeDynamodbRecord(mockDynamoClient, mockPutItemCommandInput);
            expect(resp).toBe(mockSuccessResp);
        });

        it('should return error name if conditional check fails', async () => {
            mockDynamoSendFn.mockRejectedValue({
                name: 'ConditionalCheckFailedException',
            });
            const resp = await writeDynamodbRecord(mockDynamoClient, mockPutItemCommandInput).catch(() => {});
            expect(resp).toBe('ConditionalCheckFailedException');
        });

        it('should log an error if put fails', (done) => {
            mockDynamoSendFn.mockRejectedValue({
                name: 'SomeError',
            });
            writeDynamodbRecord(mockDynamoClient, mockPutItemCommandInput).catch((err) => {
                expect(errorSpy).toHaveBeenCalledWith(`Error in DynamoDB Put: ${err.toString()}`);
                done();
            });
        });
    });

    describe('Write to manifest', () => {
        afterEach(() => {
            jest.clearAllMocks();
        });

        it('should return response if put is successful', async () => {
            mockDynamoSendFn.mockImplementation(() => {
                return Promise.resolve(mockSuccessResp);
            });
            const resp = await writeToManifest(mockDynamoClient, mockPutItemCommandInput);
            expect(resp).toBe(mockSuccessResp);
        });

        it('should log an error if put fails', (done) => {
            mockDynamoSendFn.mockRejectedValue({
                name: 'SomeError',
            });
            writeToManifest(mockDynamoClient, mockPutItemCommandInput).catch((err) => {
                expect(errorSpy).toHaveBeenCalledWith(`Error in DynamoDB Put: ${err.toString()}`);
                done();
            });
        });
    });

    describe('Tag s3 object', () => {
        afterEach(() => {
            jest.clearAllMocks();
        });

        it('should combine existing and new tag sets', async () => {
            mockS3TaggingSendFn
                .mockImplementationOnce(() => {
                    return Promise.resolve(mockGetTags);
                })
                .mockImplementationOnce((params) => {
                    expect(params.input.Tagging.TagSet).toEqual(mockTagS3Input.TagSet);
                    return Promise.resolve(mockSuccessResp);
                });
            const resp = await tagS3Object(mockS3Client, mockBucketName, mockKey, mockTagSet);
            expect(resp).toBe(mockSuccessResp);
        });

        it('should log an error if tagging fails', async () => {
            mockS3TaggingSendFn
                .mockImplementationOnce(() => {
                    return Promise.resolve(mockGetTags);
                })
                .mockRejectedValueOnce(() => {
                    return Promise.resolve(mockFailResp);
                });
            await tagS3Object(mockS3Client, mockBucketName, mockKey, mockTagSet).catch(() => {});
            expect(errorSpy).toHaveBeenCalledWith('Error in tagging s3 object');
        });

        it('work properly if get tagging fails', async () => {
            mockS3TaggingSendFn
                .mockImplementationOnce(() => {
                    return Promise.resolve({
                        TagSet: undefined,
                    });
                })
                .mockImplementationOnce(() => {
                    return Promise.resolve(mockTagSet);
                });
            const resp = await tagS3Object(mockS3Client, mockBucketName, mockKey, mockTagSet).catch(() => {});
            expect(resp).toBe(mockTagSet);
        });
    });
});
