#!/bin/bash

# Check required env vars are set
if [ -z "$bamboo_forge_runtime_instance_location_key" ]; then
  echo "bamboo_forge_runtime_instance_location_key environment variable is not set, set it with 'export bamboo_forge_runtime_instance_location_key=eu-west-1'"
  exit 1
fi

if [ -z "$bamboo_forge_environment_key" ]; then
  echo "bamboo_forge_environment_key environment variable is not set, set it with 'export bamboo_forge_environment_key=development'"
  exit 1
fi

REGIONENV=${bamboo_forge_runtime_instance_location_key%%-*}-$bamboo_forge_environment_key

FUNCTION=grsi-dp-unhappy-path-ingestion-alerting-test-$REGIONENV

echo "Running integration test from ./scripts/integration_test/load-unhappy-path-alerting.sh"
echo -e "Function $FUNCTION\n"

echo -e "Cleaning up output and state from any previous test runs:"

echo -e " - Removing any previous ./response.json outputs\n"
if [  -f ./response.json ]; then
  rm ./response.json
fi

echo -e "Invoking test lambda..."
# Lambda response written to file, CLI response (None) written to /dev/null 
aws lambda invoke --function-name $FUNCTION --query 'Payload' --cli-read-timeout 0 --output=text response.json > /dev/null
echo -e "Test complete, results below:\n"

output=$(< response.json)

if [ "$output" = '{"DLQ Validation":"Successful"}' ]; then
  echo -e "SUCCESS. lambda output: \n$output\n"
  exit 0
else
  echo -e "ERROR. lambda output: \n$output\n"
  exit 1
fi


