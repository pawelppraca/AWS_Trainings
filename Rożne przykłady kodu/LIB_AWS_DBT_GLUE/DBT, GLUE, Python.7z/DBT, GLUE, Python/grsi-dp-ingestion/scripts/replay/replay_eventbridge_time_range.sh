#!/usr/bin/env bash
run_delay=10

START_TIME=$1
END_TIME=$2

REGIONENV=${AWS_DEFAULT_REGION%%-*}-$bamboo_forge_environment_key

# Set the archive name
# Refer to load.ts#280 for 'archiveName' property in Archive
archive_name="grsi-dp-ingestion-archive-$REGIONENV"
bus_name="grsi-dp-event-bus-$REGIONENV"
	
# Check if we have our AWS Environment Variables set
if [ -z "$AWS_DEFAULT_REGION" ]; then
  echo "AWS_DEFAULT_REGION environment variable is not set, set it with 'export AWS_DEFAULT_REGION=myregion'"
  exit 1
fi
if [ -z "$AWS_DEFAULT_ACCOUNT" ]; then
  echo "AWS_DEFAULT_ACCOUNT environment variable is not set, set it with 'export AWS_DEFAULT_ACCOUNT=01233452542'"
  exit 1
fi

if [ -z "$bamboo_forge_environment_key" ]; then
  echo "bamboo_forge_environment_key environment variable is not set, set it with 'export bamboo_forge_environment_key=development'"
  exit 1
fi

if [ -z "$START_TIME" ]; then
  echo "START_TIME  is not set, pass it as the first argument in an ISO8601 date format (1970-01-01T00:00:00)"
  exit 1
fi

if [ -z "$END_TIME" ]; then
  echo "END_TIME environment variable is not set, set it with 'export AWS_DEFAULT_ACCOUNT=01233452542'"
  exit 1
fi

if [[ $START_TIME > $END_TIME ]]; then
  echo "END_TIME is before your START_TIME, check your input arguments"
  exit 1;
fi

ArchiveArn=$(aws events describe-archive --archive-name $archive_name --query "ArchiveArn" --output text)

echo -e "\nGoing to replay the events between $START_TIME and $END_TIME for EventBridge archive:\n$ArchiveArn\n\nCTRL-C to abort\n"

# Increment run_delay by 1 to simplify loop logic
((++run_delay))
while ((--run_delay >= 1)); do
  echo "Running in $run_delay seconds"
  sleep 1
done


# Send replay to EventBridge
aws events start-replay --cli-input-json "$(cat << JSON
{
  "ReplayName": "grsi-dp-replay-$(uuidgen)",
  "Description": "Event replay for datetime $START_TIME to $END_TIME",
  "EventSourceArn": "arn:aws:events:$AWS_DEFAULT_REGION:$AWS_DEFAULT_ACCOUNT:archive/$archive_name",
  "EventStartTime": "$START_TIME",
  "EventEndTime": "$END_TIME",
  "Destination": {
    "Arn": "arn:aws:events:$AWS_DEFAULT_REGION:$AWS_DEFAULT_ACCOUNT:event-bus/$bus_name"
  }
}
JSON
)"