#!/usr/bin/env bash
run_delay=10

# Function to convert an S3 URI to a Bucket and Key
parse_s3_uri() {
  # Update Internal File Separator in this scope to handle cases when our S3 URI has spaces in it
  IFS="~~~"

  local s3_uri="$1"
  local s3_uri_no_protocol=${s3_uri#s3://}
  local bucket_name=${s3_uri_no_protocol%%/*}
  local key_name=${s3_uri_no_protocol#*/}
  echo "$bucket_name" "$key_name"
}

s3_uri_to_replay=$1

if [ -z "$s3_uri_to_replay" ]; then
  echo "S3 URI To Replay not provided, use it as the first argument"
  exit 1
fi
# Check if we have our AWS Environment Variables set
if [ -z "$AWS_DEFAULT_REGION" ]; then
  echo "AWS_DEFAULT_REGION environment variable is not set, set it with 'export AWS_DEFAULT_REGION=myregion'"
  exit 1
fi
if [ -z "$AWS_DEFAULT_ACCOUNT" ]; then
  echo "AWS_DEFAULT_ACCOUNT environment variable is not set, set it with 'export AWS_DEFAULT_ACCOUNT=01233452542'"
  exit 1
fi

echo -e "\nCreating event for $s3_uri_to_replay in $run_delay seconds...\n\nCTRL-C to abort\n"
# Get the bucket and key from the parsing function
read -r bucket key < <(parse_s3_uri "$s3_uri_to_replay")

# Increment run_delay by 1 to simplify loop logic
((++run_delay))
while ((--run_delay >= 1)); do
  echo "Running in $run_delay seconds"
  sleep 1
done

# Get our attributes from the existing S3 File for replaying
x_amzn_trace_id=$(aws --profile saml s3api get-object-tagging \
  --bucket "$bucket" \
  --key "$key" \
  --query "TagSet[?Key=='x_amzn_trace_id'].Value" \
  --output text)
echo -e "\nXRay trace ID to replay is: $x_amzn_trace_id"

eTag=$(aws --profile saml s3api head-object \
  --bucket "$bucket" \
  --key "$key" \
  --query "ETag" \
  --output text | tr -d '"')
echo "File eTag to replay is: $eTag"

ContentLength=$(aws --profile saml s3api head-object \
  --bucket "$bucket" \
  --key "$key" \
  --query "ContentLength" \
  --output text)
echo -e "File ContentLength to replay is: $ContentLength\n"

# Create ISO-8601 datetime
run_time=$(date +"%Y-%m-%dT%H:%M:%S")

# Build our event detail
detail=$(
cat << DETAIL
  \"version\": \"0\",
  \"bucket\": {
    \"name\": \"$bucket\"
  },
  \"object\": {
    \"key\": \"$key\",
    \"size\": \"$ContentLength\",
    \"etag\": \"$eTag\"
  },
  \"replay\": \"true\"
DETAIL
)

# Send the replay to eventbridge
aws events put-events --cli-input-json "$(cat << JSON
 {
   "Entries": [
     {
       "Time": "$run_time",
       "Source": "aws:s3",
       "Resources": [
         "arn:aws:s3:::$bucket"
       ],
       "Detail": "{$(echo "$detail" | tr -d '\n')}",
       "DetailType": "ObjectCreated",
       "EventBusName": "arn:aws:events:$AWS_DEFAULT_REGION:$AWS_DEFAULT_ACCOUNT:event-bus/default",
       "TraceHeader": "Root=$x_amzn_trace_id;Sampled=1"
     }
   ]
 }
JSON
)"
