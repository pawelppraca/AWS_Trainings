import { Key } from 'aws-cdk-lib/aws-kms';
import { Construct } from 'constructs';
import { StackConfiguration } from '../../bin/config';
import { config, KmsUtil } from '@lmig/grsi-dp-shared-config-and-classes';
import {
  AccountRootPrincipal,
  AnyPrincipal,
  Effect,
  PolicyDocument,
  PolicyStatement,
  ServicePrincipal,
} from 'aws-cdk-lib/aws-iam';

export class KmsResources extends Construct {
  constructor(scope: Construct, id: string, stackConfig: StackConfiguration) {
    super(scope, id);

    const kmsUtil = new KmsUtil(stackConfig.environmentKey);

    const sourceBucketEncryptionKey = new Key(this, 'SourceS3Key', {
      enableKeyRotation: kmsUtil.shouldEnableKeyRotation(),
      alias: stackConfig.bucketKeyAlias,
      removalPolicy: kmsUtil.getRemovalPolicy(),
      policy: new PolicyDocument({
        statements: [
          new PolicyStatement({
            effect: Effect.ALLOW,
            resources: ['*'],
            actions: ['kms:*'],
            principals: [new AccountRootPrincipal()],
          }),
          new PolicyStatement({
            effect: Effect.ALLOW,
            resources: ['*'],
            actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
            principals: [
              new AnyPrincipal().withConditions({
                ArnLike: {
                  'aws:PrincipalArn': `arn:aws:iam::${stackConfig.awsEnv.account as string}:user/${
                    config.supportUserName
                  }`,
                },
              }),
            ],
          }),
          // Enable the ingestion glue role to read this
          new PolicyStatement({
            effect: Effect.ALLOW,
            resources: ['*'],
            actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
            principals: [
              new AnyPrincipal().withConditions({
                ArnLike: {
                  'aws:PrincipalArn': `arn:aws:iam::${stackConfig.awsEnv.account as string}:role/${
                    config.extractionGlueRoleName
                  }`,
                },
              }),
            ],
          }),
          new PolicyStatement({
            effect: Effect.ALLOW,
            resources: ['*'],
            actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
            principals: [
              new AnyPrincipal().withConditions({
                ArnLike: {
                  'aws:PrincipalArn': `arn:aws:iam::${stackConfig.awsEnv.account as string}:user/${
                    stackConfig.glueUserName
                  }`,
                },
              }),
            ],
          }),
          new PolicyStatement({
            effect: Effect.ALLOW,
            resources: ['*'],
            actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
            principals: [
              new AnyPrincipal().withConditions({
                ArnLike: {
                  'aws:PrincipalArn': `arn:aws:iam::${stackConfig.awsEnv.account as string}:role/${
                    stackConfig.glueJobRoleName
                  }`,
                },
              }),
            ],
          }),
          new PolicyStatement({
            effect: Effect.ALLOW,
            resources: ['*'],
            actions: ['kms:Encrypt*', 'kms:Decrypt*', 'kms:ReEncrypt*', 'kms:GenerateDataKey', 'kms:Describe*'],
            principals: [new ServicePrincipal(`logs.${stackConfig.awsEnv.region as string}.amazonaws.com`)],
          }),
        ],
      }),
    });
  }
}
