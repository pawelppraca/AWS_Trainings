import { Alias } from 'aws-cdk-lib/aws-kms';
import { Construct } from 'constructs';
import { StackConfiguration } from '../../bin/config';
import {
  Effect,
  ManagedPolicy,
  PolicyDocument,
  PolicyStatement,
  Role,
  ServicePrincipal,
  User,
} from 'aws-cdk-lib/aws-iam';
import {
  config,
  grsiPrefix,
  LmCdkApplyCustomPermissionsBoundaryToStack,
  vpc,
} from '@lmig/grsi-dp-shared-config-and-classes';
import { Port, SecurityGroup, Subnet } from 'aws-cdk-lib/aws-ec2';
import { CfnCrawler, CfnDatabase, CfnTrigger } from 'aws-cdk-lib/aws-glue';
import {
  CloudWatchEncryptionMode,
  Code,
  Connection,
  ConnectionType,
  GlueVersion,
  Job,
  JobBookmarksEncryptionMode,
  JobExecutable,
  PythonVersion,
  S3EncryptionMode,
  SecurityConfiguration,
  WorkerType,
} from '@aws-cdk/aws-glue-alpha';
import { Bucket } from 'aws-cdk-lib/aws-s3';
import {
  ApplyTagsToResourceCustomResource,
  LmPermissionsBoundaryType,
  SecretPapiRotateIamUserAccessKeysCustomResource,
} from '@lmig/swa-cdk-core';
import { Aspects, Stack, Tags } from 'aws-cdk-lib';
import { PermissionsBoundary } from 'aws-cdk-lib/aws-iam';
import { ApplyTagsToResourceAspect } from '@lmig/lm-aws-cdk';

export class GlueResources extends Construct {
  constructor(scope: Construct, id: string, stackConfig: StackConfiguration) {
    super(scope, id);

    // Map non-prod to test
    const bilzEnv: string = config.environmentKey == 'non-production' ? 'test' : config.environmentKey;

    // Set up our vars here, since
    const bilzConnName: string = config.bilzConnName[config.environmentKey];
    const crawlerTriggerName = `${grsiPrefix}-historic-load-crawler-trigger-${stackConfig.environmentKey}`;
    const jobTriggerName = `${grsiPrefix}-historic-load-job-trigger-${stackConfig.environmentKey}`;
    const historicLoadDatabaseName = `${grsiPrefix}-historic-load-db-${stackConfig.environmentKey}`;
    const vpcConnectionName = `${grsiPrefix}-historic-load-vpc-connection-${stackConfig.environmentKey}`;
    const glueJobName = `${grsiPrefix}-historic-load-${stackConfig.environmentKey}`;

    const glueKey = Alias.fromAliasName(this, 'lookupGlueKeyAlias', stackConfig.bucketKeyAlias);

    const lmTrouxUidBoundary = ManagedPolicy.fromManagedPolicyName(
      this,
      'CloudServicesPbLmTrouxUidAccess',
      `cloud-services/${LmPermissionsBoundaryType.TROUX_UUID}`,
    );

    const historicLoadGluePB = new ManagedPolicy(this, 'serviceUserLmigPBActionsPolicy', {
      managedPolicyName: stackConfig.glueJobPBName,
      path: '/permission-boundary/',
      statements: [
        new PolicyStatement({
          actions: ['s3:GetObject*', 's3:DeleteObject', 's3:PutObject*'],
          resources: [`arn:aws:s3:::${stackConfig.historicDataBucketName}/*`],
        }),
        new PolicyStatement({
          actions: ['s3:GetObject*'],
          resources: [`arn:aws:s3:::${stackConfig.glueScriptBucketName}/*`],
        }),
        new PolicyStatement({
          actions: ['kms:Decrypt', 'kms:DescribeKey'],
          resources: [glueKey.keyArn],
        }),
        new PolicyStatement({
          actions: ['logs:*'],
          resources: [
            `arn:aws:logs:${stackConfig.awsEnv.region as string}:${
              stackConfig.awsEnv.account as string
            }:log-group:grsi-dp*`,
            `arn:aws:logs:${stackConfig.awsEnv.region as string}:${
              stackConfig.awsEnv.account as string
            }:log-group:/aws-glue/*`,
          ],
        }),
        new PolicyStatement({
          actions: [
            'Glue:GetSecurityConfiguration*',
            's3:GetBucketLocation',
            's3:ListBucket',
            's3:ListAllMyBuckets',
            's3:GetBucketAcl',
            'ec2:DescribeVpcEndpoints',
            'ec2:DescribeRouteTables',
            'ec2:CreateNetworkInterface',
            'ec2:DeleteNetworkInterface',
            'ec2:DescribeNetworkInterfaces',
            'ec2:DescribeSecurityGroups',
            'ec2:DescribeSubnets',
            'ec2:DescribeVpcAttribute',
            'iam:ListRolePolicies',
            'iam:GetRole',
            'iam:GetRolePolicy',
            'cloudwatch:PutMetricData',
          ],
          resources: ['*'],
        }),
        new PolicyStatement({
          actions: ['s3:GetObject'],
          resources: ['arn:aws:s3:::crawler-public*', 'arn:aws:s3:::aws-glue-*'],
        }),
        new PolicyStatement({
          actions: ['logs:CreateLogGroup', 'logs:CreateLogStream', 'logs:PutLogEvents'],
          resources: ['arn:aws:logs:*:*:*:/aws-glue/*'],
        }),
        new PolicyStatement({
          actions: ['ec2:CreateTags', 'ec2:DeleteTags'],
          conditions: {
            'ForAllValues:StringEquals': {
              'aws:TagKeys': ['aws-glue-service-resource'],
            },
          },
          resources: [
            'arn:aws:ec2:*:*:network-interface/*',
            'arn:aws:ec2:*:*:security-group/*',
            'arn:aws:ec2:*:*:instance/*',
          ],
        }),
        new PolicyStatement({
          actions: ['glue:StartJobRun', 'glue:BatchStopJobRun'],
          resources: [
            `arn:aws:glue:${stackConfig.awsEnv.region as string}:${
              stackConfig.awsEnv.account as string
            }:job/${glueJobName}`,
          ],
        }),
        new PolicyStatement({
          actions: ['glue:*Database*', 'glue:*Table*'],
          resources: [
            `arn:aws:glue:${stackConfig.awsEnv.region as string}:${
              stackConfig.awsEnv.account as string
            }:database/${historicLoadDatabaseName}`,
            `arn:aws:glue:${stackConfig.awsEnv.region as string}:${
              stackConfig.awsEnv.account as string
            }:table/${historicLoadDatabaseName}/*`,
            'arn:aws:glue:*:*:catalog',
            'arn:aws:glue:*:*:catalog/*',
          ],
        }),
        new PolicyStatement({
          actions: ['glue:StartTrigger', 'glue:UpdateTrigger'],
          resources: [
            `arn:aws:glue:${stackConfig.awsEnv.region as string}:${
              stackConfig.awsEnv.account as string
            }:trigger/${crawlerTriggerName}`,
            `arn:aws:glue:${stackConfig.awsEnv.region as string}:${
              stackConfig.awsEnv.account as string
            }:trigger/${jobTriggerName}`,
          ],
        }),
        new PolicyStatement({
          actions: ['Glue:GetConnection'],
          resources: [
            `arn:aws:glue:${config.awsRegion}:${config.awsAccount}:connection/GeniusAnalyticalRep-RDS-${bilzEnv}`,
            `arn:aws:glue:${config.awsRegion}:${config.awsAccount}:catalog`,
            `arn:aws:glue:${config.awsRegion}:${config.awsAccount}:catalog/*`,
            `arn:aws:glue:${config.awsRegion}:${config.awsAccount}:connection/${vpcConnectionName}`,
          ],
        }),
      ],
    });

    Tags.of(historicLoadGluePB).add('aws_iam_permission_boundary_exempt', 'CustomAwaitingApproval');
    Tags.of(historicLoadGluePB).add('deployment_guid', config.stackTags.deployment_guid);

    new ApplyTagsToResourceCustomResource(this, 'TagServiceUserLmigPBActions', {
      resource: historicLoadGluePB,
      tags: {},
    }).node.addDependency(historicLoadGluePB);

    const glueJobRole = new Role(this, 'HistoricLoadGlueRole', {
      roleName: stackConfig.glueJobRoleName,
      assumedBy: new ServicePrincipal('glue.amazonaws.com'),
      managedPolicies: [
        ManagedPolicy.fromManagedPolicyArn(
          this,
          'AWSGlueServiceRole',
          'arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole',
        ),
      ],
      inlinePolicies: {
        s3Policy: new PolicyDocument({
          statements: [
            new PolicyStatement({
              actions: ['s3:GetObject*', 's3:DeleteObject', 's3:PutObject*'],
              resources: [`arn:aws:s3:::${stackConfig.historicDataBucketName}/*`],
            }),
            new PolicyStatement({
              actions: ['s3:GetObject*'],
              resources: [`arn:aws:s3:::${stackConfig.glueScriptBucketName}/*`],
            }),
            new PolicyStatement({
              actions: ['kms:Decrypt', 'kms:DescribeKey'],
              resources: [glueKey.keyArn],
            }),
          ],
        }),
        logsPolicy: new PolicyDocument({
          statements: [
            new PolicyStatement({
              actions: ['logs:*'],
              resources: [
                `arn:aws:logs:${stackConfig.awsEnv.region as string}:${
                  stackConfig.awsEnv.account as string
                }:log-group:grsi-dp*`,
                `arn:aws:logs:${stackConfig.awsEnv.region as string}:${
                  stackConfig.awsEnv.account as string
                }:log-group:/aws-glue/*`,
              ],
            }),
          ],
        }),
      },
    });

    glueJobRole.stack.tags.setTag('aws_iam_permission_boundary_exempt', 'CUSTOM');
    Tags.of(glueJobRole).add('deployment_guid', config.stackTags.deployment_guid);
    glueJobRole.node.addDependency(historicLoadGluePB);
    PermissionsBoundary.of(glueJobRole).apply(historicLoadGluePB);

    const vpcLookup = new vpc(this, 'LookupVpc');

    const glueSecurityGroup = new SecurityGroup(this, 'SecurityGroup', {
      allowAllOutbound: true,
      description: 'Security Group to allow Glue to run in VPC',
      securityGroupName: `${grsiPrefix}-historic-loads-glue-security-group-${stackConfig.environmentKey}`,
      vpc: vpcLookup.ivpc,
    });
    // Self referencing rule to allow Glue to talk to all its internal components
    glueSecurityGroup.addIngressRule(glueSecurityGroup, Port.allTcp(), 'self-referencing');
    const vpcConnection = new Connection(this, 'Connection', {
      connectionName: vpcConnectionName,
      type: ConnectionType.NETWORK,
      subnet: Subnet.fromSubnetAttributes(this, 'SubnetLookup', {
        subnetId: vpcLookup.subnetIds[0],
        availabilityZone: vpcLookup.availabilityZones[0],
      }),
      securityGroups: [glueSecurityGroup],
    });

    new ApplyTagsToResourceCustomResource(this, 'TagVPCConnection', {
      resource: vpcConnection,
      tags: {},
    }).node.addDependency(vpcConnection);

    const securityConfig: SecurityConfiguration = new SecurityConfiguration(this, 'SecurityConfiguration', {
      securityConfigurationName: `${grsiPrefix}-historic-loads-security-config-${stackConfig.environmentKey}`,
      cloudWatchEncryption: {
        mode: CloudWatchEncryptionMode.KMS,
        kmsKey: glueKey,
      },
      jobBookmarksEncryption: {
        mode: JobBookmarksEncryptionMode.CLIENT_SIDE_KMS,
        kmsKey: glueKey,
      },
      s3Encryption: {
        mode: S3EncryptionMode.KMS,
        kmsKey: glueKey,
      },
    });

    // CLAIM CENTER INFRA
    const historicLoadDatabase = new CfnDatabase(this, 'HistoricLoadDatabase', {
      catalogId: config.awsAccount,
      databaseInput: {
        description: 'Historic Load DB with BILZ Info',
        name: historicLoadDatabaseName,
      },
    });

    const crawlerName = `${grsiPrefix}-bilz-crawler-${stackConfig.environmentKey}`;
    // only deploy if connection is defined in grsi-dp-shared-config-and-classes/src/config.ts
    // conditional required as bilz is not available in development
    if (bilzConnName !== undefined) {
      const crawler = new CfnCrawler(this, 'bilzCrawler', {
        crawlerSecurityConfiguration: securityConfig.securityConfigurationName,
        name: crawlerName,
        databaseName: historicLoadDatabase.ref,
        role: glueJobRole.roleArn,
        targets: {
          jdbcTargets: [
            {
              connectionName: bilzConnName,
              path: 'BI_LZ/ClaimCenter/%',
            },
            {
              connectionName: bilzConnName,
              path: 'BI_LZ/Genius/%',
            },
            {
              connectionName: bilzConnName,
              path: 'BI_LZ/Map/FXRates_Genius',
            },
          ],
        },
        schemaChangePolicy: {
          updateBehavior: 'UPDATE_IN_DATABASE',
          deleteBehavior: 'DEPRECATE_IN_DATABASE',
        },
        tags: {
          lm_troux_uid: stackConfig.stackTags.lm_troux_uid,
          organization_guid: stackConfig.stackTags.organization_guid,
          deployment_guid: stackConfig.stackTags.deployment_guid,
          lm_app: `aws-${stackConfig.artifactKey}`,
          lm_app_env: stackConfig.environmentKey,
          Name: stackConfig.stackNames.extraction,
        },
      });
      crawler.node.addDependency(glueJobRole);
    }

    const glueScriptBucket = Bucket.fromBucketName(this, 'lookupGlueScriptBucket', stackConfig.glueScriptBucketName);
    const historicDataBucket = Bucket.fromBucketName(
      this,
      'lookupHistoricDataBucket',
      stackConfig.historicDataBucketName,
    );

    const historicLoadJob = new Job(this, 'historicLoadJob', {
      role: glueJobRole,
      executable: JobExecutable.pythonEtl({
        pythonVersion: PythonVersion.THREE,
        glueVersion: GlueVersion.V4_0,
        script: Code.fromBucket(glueScriptBucket, '/cc-historic-load.py'),
      }),
      jobName: glueJobName,
      description: 'Job to load historic BI-LZ data to S3 bucket',
      securityConfiguration: securityConfig,
      connections: [vpcConnection],
      workerType: WorkerType.G_1X,
      workerCount: 20,
      continuousLogging: {
        enabled: true,
        quiet: true,
        logStreamPrefix: `${grsiPrefix}-historic-load-`,
      },
      defaultArguments: {
        '--job-bookmark-option': 'job-bookmark-disable',
        '--enable-metrics': 'true',
        '--additional-python-modules': 'aws-xray-sdk==2.12.0',
        '--disable-proxy-v2': 'true', // https://docs.aws.amazon.com/glue/latest/dg/connection-VPC-disable-proxy.html
        '--AWS_REGION': stackConfig.awsEnv.region as string,
        '--ACCOUNT_ID': stackConfig.awsEnv.account as string,
        '--APP_ENV': stackConfig.environmentKey,
        '--HISTORIC_DATA_BUCKET': historicDataBucket.bucketName,
        '--HISTORIC_DBNAME': historicLoadDatabaseName,
        // Tags for output files
        '--ORGANIZATION_GUID': `${stackConfig.stackTags.organization_guid}`,
        '--LM_TROUX_UID': `${stackConfig.stackTags.lm_troux_uid}`,
        '--ARTIFACT_GUID': `${stackConfig.stackTags.artifact_guid}`,
        '--DEPLOYMENT_GUID': `${stackConfig.stackTags.deployment_guid}`,
      },
    });

    // Trigger to be interfaced with glue user for scheduling crawler run
    const crawlerTrigger = new CfnTrigger(this, 'historicCrawlerTrigger', {
      name: crawlerTriggerName,
      type: 'SCHEDULED',
      schedule: 'cron(0 1 22 DEC ? 2024)',
      actions: [
        {
          crawlerName: crawlerName,
        },
      ],
      // While it may seem like this will force it to run immediately, really it just makes the trigger available
      startOnCreation: true,
    });

    // Trigger depending on successful crawler, to kick off the job run.
    const jobTrigger = new CfnTrigger(this, 'historicGlueJobTrigger', {
      name: jobTriggerName,
      type: 'CONDITIONAL',
      actions: [
        {
          jobName: historicLoadJob.jobName,
          securityConfiguration: securityConfig.securityConfigurationName,
        },
      ],
      predicate: {
        conditions: [
          {
            logicalOperator: 'EQUALS',
            crawlerName: crawlerName,
            crawlState: 'SUCCEEDED',
          },
        ],
        logical: 'ANY',
      },
      // While it may seem like this will force it to run immediately, really it just makes the trigger available
      startOnCreation: true,
    });

    // For running the glue job
    const glueUser = new User(this, 'glueUser', {
      userName: stackConfig.glueUserName,
      permissionsBoundary: lmTrouxUidBoundary,
    });
    // glueUser.stack.tags.setTag('aws_iam_permission_boundary_exempt', 'CUSTOM');

    glueUser.addToPolicy(
      new PolicyStatement({
        actions: ['iam:GetRole', 'iam:PassRole'],
        resources: [glueJobRole.roleArn],
      }),
    );

    glueUser.addToPolicy(
      new PolicyStatement({
        actions: ['glue:StartJobRun', 'glue:BatchStopJobRun'],
        resources: [historicLoadJob.jobArn],
      }),
    );

    glueUser.addToPolicy(
      new PolicyStatement({
        actions: ['glue:StartCrawler'],
        resources: [
          `arn:aws:glue:${stackConfig.awsEnv.region as string}:${
            stackConfig.awsEnv.account as string
          }:crawler/${crawlerName}`,
        ],
      }),
    );

    glueUser.addToPolicy(
      new PolicyStatement({
        actions: ['glue:StartTrigger', 'glue:UpdateTrigger'],
        resources: [
          `arn:aws:glue:${stackConfig.awsEnv.region as string}:${stackConfig.awsEnv.account as string}:trigger/${
            crawlerTrigger.ref
          }`,
          `arn:aws:glue:${stackConfig.awsEnv.region as string}:${stackConfig.awsEnv.account as string}:trigger/${
            jobTrigger.ref
          }`,
        ],
      }),
    );

    const glueUserCreds = new SecretPapiRotateIamUserAccessKeysCustomResource(this, 'GlueUserAccessKeys', {
      userName: glueUser.userName,
      secretName: glueUser.userName,
      papiIndex: config.secrets.papiIndex,
      vaultToken: config.secrets.vaultToken,
    });
    glueUserCreds.node.addDependency(glueUser);
  }
}
