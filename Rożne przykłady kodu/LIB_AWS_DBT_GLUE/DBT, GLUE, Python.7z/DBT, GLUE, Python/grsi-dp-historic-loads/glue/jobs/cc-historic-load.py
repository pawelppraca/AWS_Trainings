import sys
import boto3
# import logging

from awsglue.context import GlueContext
from awsglue.dynamicframe import DynamicFrame
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql.functions import lit
from pyspark.sql.types import StructType, StructField, StringType
from collections import defaultdict

glueContext = GlueContext(SparkContext.getOrCreate())
spark = glueContext.spark_session
spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")
spark.sql("set spark.sql.legacy.parquet.int96RebaseModeInWrite=CORRECTED")
spark.sql("set spark.sql.caseSensitive=false")
logger = glueContext.get_logger()

# msg_format = "%(asctime)s %(levelname)s %(name)s: %(message)s"
# datetime_format = "%Y-%m-%d %H:%M:%S"
# logging.basicConfig(format=msg_format, datefmt=datetime_format)
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.DEBUG)

args = getResolvedOptions(
    sys.argv,
    [
        "JOB_NAME",
        "AWS_REGION",
        "ACCOUNT_ID",
        "APP_ENV",
        "HISTORIC_DATA_BUCKET",
        "HISTORIC_DBNAME",
    ],
)

environment = args["APP_ENV"]
region = args["AWS_REGION"]
acc_id = args["ACCOUNT_ID"]
historic_data_bucket = args["HISTORIC_DATA_BUCKET"]
claimscenter_dbname = args["HISTORIC_DBNAME"]

s3 = boto3.resource("s3")
bucket = s3.Bucket(historic_data_bucket)

cc_tables = [
    "cc_activity",
    "cc_activitypattern",
    "cc_address",
    "cc_catastrophe",
    "cc_check",
    "cc_claim",
    "cc_claim_log",
    "cc_contact",
    "cc_coverage",
    "cc_exposure",
    "cc_exposure_log",
    "cc_ext_claimevent",
    "cc_group",
    "cc_history",
    "cc_incident",
    "cc_matter",
    "cc_parentgroup",
    "cc_policy",
    "cc_subrogation",
    "cc_subrogationsummary",
    "cc_transaction",
    "cc_transactionset",
    "cc_user",
    "cctl_activitycategory",
    "cctl_activitystatus",
    "cctl_claimanttype",
    "cctl_claimclosedoutcometype",
    "cctl_claimsecuritytype",
    "cctl_claimstate",
    "cctl_claimtier",
    "cctl_country",
    "cctl_coveragetype",
    "cctl_currency",
    "cctl_customhistorytype",
    "cctl_ecfacknowledgementstatus_ext",
    "cctl_ecfacklevelcode_ext",
    "cctl_ecfcauseoflosscode_ext",
    "cctl_ecfclaimtransactiontype_ext",
    "cctl_exposureclosedoutcometype",
    "cctl_exposuretype",
    "cctl_exposurestate",
    "cctl_ext_apacjurisdiction",
    "cctl_ext_apracol",
    "cctl_ext_aprainjury",
    "cctl_ext_apralitcodes",
    "cctl_ext_cargo",
    "cctl_ext_claimsorganization",
    "cctl_ext_collcode3_pi",
    "cctl_ext_coverageindicatorpr",
    "cctl_ext_deductibletype",
    "cctl_ext_deductrecreductreason",
    "cctl_ext_handledby",
    "cctl_ext_handlingtype",
    "cctl_ext_isojurisdictionstate",
    "cctl_ext_isolosslocation",
    "cctl_ext_isseveritycode",
    "cctl_ext_losscodeset",
    "cctl_ext_lossevent",
    "cctl_ext_policycovsectionusa",
    "cctl_ext_policyorigin",
    "cctl_ext_proceedingspr",
    "cctl_ext_proceedingtype",
    "cctl_ext_product",
    "cctl_ext_projecttype",
    "cctl_ext_typeofwork2",
    "cctl_extclaimtype",
    "cctl_extcollcode",
    "cctl_extcollcode2",
    "cctl_extcollcode3",
    "cctl_extcollcode4",
    "cctl_extcollcode5",
    "cctl_extcoverageindicator",
    "cctl_extcyberconsideration",
    "cctl_extinjuredpersontype",
    "cctl_extransomwareaspect",
    "cctl_extregulatorycode",
    "cctl_extseverity",
    "cctl_faultrating",
    "cctl_historytype",
    "cctl_howreportedtype",
    "cctl_isostatus",
    "cctl_largelossnotificationstat",
    "cctl_lmclasscode_syn",
    "cctl_lmmessage_ext",
    "cctl_lmmessagetype_ext",
    "cctl_paymentmethod",
    "cctl_personrelationtype",
    "cctl_priority",
    "cctl_state",
    "cctl_subrogationstatus",
    "cctl_underwritingcompanytype",
    "ccx_ecfmessagerspack_ext",
    "ccx_ext_claimevent",
    "ccx_lmmessage_ext",
]
genius_tables = [
    "gyllsmbf",
    "zacj",
    "zara",
    "zhc2",
    "zhmj",
    "zhmn",
    "zkfa",
    "zkfb",
    "zkfo",
    "zkg",
    "zkg3",
    "zkt8",
    "znna",
    "znnc",
    "zpks",
    "zuco",
    "zuma",
    "zus",
    "zusk",
]

map_tables = ["fxrates_genius"]

# Remove this section when we need to stop redacting PII again
cols_to_redact_mapping = {
    # cc_details
    "cc_activity": [
        "description",
        "shortsubject",
        "subject"
    ],
    "cc_address": [
        "addressline1",
        "addressline1kanji",
        "addressline2",
        "addressline3",
        "city",
        "citydenorm",
        "description",
        "ext_addressline4",
        "ext_addressline5",
        "ext_state",
        "ext_city",
        "postalcodedenorm",
        "postalcode",
        "state"
    ],
    "cc_check": [
        "bankaccountnumber",
        "bankaccountnumbersize40",
        "bankname",
        "ext_iban"
    ],
    "cc_claim": [
        "bankaccountnumber",
        "bankaccountnumbersize40",
        "bankname",
        "description",
        "ext_coll1descother",
        "ext_coll2descother",
        "ext_coll3descother",
        "ext_coll4descother",
        "ext_efileurl",
        "ext_generalclaimnote",
        "ext_matter",
        "ext_title",
        "firedeptinfo",
        "policedeptinfo"
    ],
    "cc_claim_log": [
        "description",
        "ext_efileurl",
        "ext_generalclaimnote",
        "ext_title",
        "ext_matter",
        "firedeptinfo",
        "policedeptinfo"
    ],
    "cc_contact": [
        "cellphone",
        "cmsclaimnumberpel",
        "dateofbirth",
        "emailaddress1",
        "emailaddress2",
        "employeenumber",
        "employeesecurityid",
        "ext_effectivedate",
        "faxphone",
        "firstnamedenorm",
        "formername",
        "gender",
        "greencardnumber",
        "lastnamedenorm",
        "licensenumber",
        "medicallicense",
        "middlename",
        "name",
        "namedenorm",
        "passportnumber",
        "taxid",
        "visanumber"
    ],
    "cc_evaluation": [
        "ext_comments",
        "ext_currentstateanalysis",
        "ext_exposureresolanalysis",
        "ext_nasnote",
        "ext_notetoactuaries",
        "ext_reasonadded",
        "ext_reservechangeexp"
    ],
    "cc_history": ["description"],
    "cc_incident": [
        "assessmentcomment",
        "descother",
        "description",
        "extdamagetxt",
        "lossdesc"
    ],
    "cc_matter": [
        "ext_dispositionreason",
        "ext_excesscarrier",
        "name"
    ],
    "cc_policy": ["ext_policytitle"],
    "cc_transaction": ["comments"],
    "ccx_ecfcontactmarcket_ext": [
        "contactemail_syn",
        "contactname_syn",
        "contactphone_syn"
    ],
    "ccx_lmmessage_ext": [
        "brokeremail",
        "claimant",
        "contactemail",
        "contacttelephone",
        "leadcontactemail",
        "leadcontactname",
        "lossdescription",
        "privatefootnote",
        "riskdescription",
        "xcscontactemail_syn"
    ],
    # genius_details
    "zara": [
        "rab323",
        "rabnzb",
        "rag0py",
        "raoqcd",
        "raprt1",
        "raprt2",
        "ratalv",
        "ratalw",
        "ratalz",
        "rataom"
    ],
    "zkfa": [
        "fafaar",
        "fafab1",
        "fafab2",
        "fafatl"
    ],
    "zkfb": ["fbfbtl"],
    "zkg": [
        "g0g0b2",
        "g0g0bd",
        "g0g0cd",
        "g0g0np",
        "g0g0or",
        "g0g0td",
        "g0g0tr"
    ],
    "zkt8": ["t8t8un"],
    "zuma": ["mamati"],
    "zus": ["sfsftl"],
    "zusk": ["sksktl"],
    # map_details
    "fxrates_genius": [
        "code",
        "currencycode",
        "fxratetypecode"
        ],
}
cols_to_redact = defaultdict(list, cols_to_redact_mapping)
# End section for removal
genius_details = {
    "source_db": "bi_lz",
    "target_db": f"grsi_dp_{environment}",
    "source_schema": "genius",
    "target_schema": "staging",
    "table_prefix": "genius",
    "table_names": genius_tables,
}
cc_details = {
    "source_db": "bi_lz",
    "target_db": f"grsi_dp_{environment}",
    "source_schema": "claimcenter",
    "target_schema": "staging",
    "table_prefix": "claim_center",
    "table_names": cc_tables,
}

map_details = {
    "source_db": "bi_lz",
    "target_db": f"grsi_dp_{environment}",
    "source_schema": "map",
    "target_schema": "staging",
    "table_prefix": "genius",
    "table_names": map_tables,
    "map_prefix": "map_",
}

bi_lz_schemas = [genius_details, cc_details, map_details]

for schema in bi_lz_schemas:
    for table in schema["table_names"]:
        source_table = f"{schema['source_db']}_{schema['source_schema']}_{table}"
        s3_location = f"{schema['source_db']}/{schema['table_prefix']}/{schema['map_prefix'] if schema == map_details else ''}{table}/"
        logger.info(f"Loading {source_table}")

        logger.info(f"Deleting existing file, if it exists for {table}")
        for obj in bucket.objects.filter(Prefix=s3_location):
            s3.Object(historic_data_bucket, obj.key).delete()
            logger.info(f"{obj.key} deleted")

        logger.info(f"Extracting {table}")
        dynamic_frame = glueContext.create_dynamic_frame.from_catalog(
            database=claimscenter_dbname, table_name=source_table
        )

        df = dynamic_frame.toDF()
        if df.isEmpty():
            logger.info(f"ERROR: No data was extracted from {table}!")
            continue

        logger.info(f"Finished extracting {table}")

        # Remove this section when we need PII again
        for col_name, col_type in df.dtypes:
            if (
                    col_type == "string"
                    and col_name.lower() in cols_to_redact[table]
            ):
                logger.info(f"Redacting column: {col_name} from table: {table}")
                df = df.withColumn(col_name, lit("X"))
            elif (
                        col_type == "int"
                        and col_name.lower() in cols_to_redact[table]
            ):
                logger.info(f"Redacting column: {col_name} from table: {table}")
                df = df.withColumn(col_name, lit(-1))
        logger.info(f"PII redacted for {table}")
        dynamic_frame = DynamicFrame.fromDF(df, glueContext, "dataframe_to_dynframe")
        # End section for removal

        target_location = f"s3://{historic_data_bucket}/{schema['source_db']}/{schema['table_prefix']}/{schema['map_prefix'] if schema == map_details else ''}{table}/"

        logger.info(f"Writing {table}")
        glueContext.write_dynamic_frame.from_options(
            frame=dynamic_frame.coalesce(1),
            connection_type="s3",
            connection_options={"path": target_location},
            format="parquet",
        )
        logger.info(f"{table} finished, {df.count()} rows written")


# For testing purposes
def create_empty_df():
    return spark.createDataFrame(
        [],
        StructType(
            [
                StructField("firstname", StringType(), True),
            ]
        ),
    )
