import { Construct } from 'constructs';
import { BlockPublicAccess, Bucket, IBucket, BucketEncryption, StorageClass } from 'aws-cdk-lib/aws-s3';
import { StackConfiguration } from '../../bin/config';
import { RemovalPolicy, Tags, Duration } from 'aws-cdk-lib';
import { Alias } from 'aws-cdk-lib/aws-kms';
import { AnyPrincipal, ArnPrincipal, PolicyStatement } from 'aws-cdk-lib/aws-iam';
import { config, grsiPrefix } from '@lmig/grsi-dp-shared-config-and-classes';

export class S3Resources extends Construct {
  constructor(scope: Construct, id: string, stackConfig: StackConfiguration) {
    super(scope, id);

    const bucketKey = Alias.fromAliasName(this, 'lookupBucketKeyAlias', stackConfig.bucketKeyAlias);

    const glueScriptBucket: IBucket = new Bucket(this, 'GlueScriptBucket', {
      bucketName: stackConfig.glueScriptBucketName,
      encryption: BucketEncryption.KMS,
      encryptionKey: bucketKey,
      enforceSSL: true,
      removalPolicy: RemovalPolicy.DESTROY,
      blockPublicAccess: BlockPublicAccess.BLOCK_ALL,
      bucketKeyEnabled: true,
    });
    Tags.of(glueScriptBucket).add('dpmawsbackup', 'none');

    glueScriptBucket.addToResourcePolicy(
      new PolicyStatement({
        actions: ['s3:PutObjectTagging', 's3:PutObject'],
        principals: [
          new ArnPrincipal(
            `arn:aws:iam::${stackConfig.awsEnv.account as string}:role/cloud-services/pipeline-deployment-guid-access`,
          ),
        ],
        resources: [`arn:aws:s3:::${glueScriptBucket.bucketName}/*`],
        conditions: {
          StringEquals: {
            's3:RequestObjectTag/deployment_guid': stackConfig.stackTags.deployment_guid,
          },
          'ForAllValues:StringEquals': {
            's3:RequestObjectTag/deployment_guid': ['${aws:PrincipalTag/deployment_guid}'],
          },
        },
      }),
    );

    // Import the bucket if required based on the config flag otherwise create it
    const historicDataBucket: IBucket = stackConfig.importExistingHistoricDataBucket
      ? Bucket.fromBucketName(this, 'SourceDataBucket', stackConfig.historicDataBucketName)
      : new Bucket(this, 'SourceDataBucket', {
          bucketName: stackConfig.historicDataBucketName,
          encryption: BucketEncryption.KMS,
          encryptionKey: bucketKey,
          enforceSSL: true,
          removalPolicy: RemovalPolicy.RETAIN,
          blockPublicAccess: BlockPublicAccess.BLOCK_ALL,
          bucketKeyEnabled: true,
          versioned: true,
          lifecycleRules: [
            {
              id: 'TransitionToGlacier',
              enabled: true,
              transitions: [
                {
                  storageClass: StorageClass.GLACIER,
                  transitionAfter: Duration.days(30),
                },
              ],
              expiration: Duration.days(90),
            },
          ],
        });

    Tags.of(historicDataBucket).add('dpmawsbackup', stackConfig.sourceRegionFailSafeBackupTag);
    // Enable the ingestion glue role to read this data
    historicDataBucket.addToResourcePolicy(
      new PolicyStatement({
        actions: ['s3:Get*'],
        principals: [
          new AnyPrincipal().withConditions({
            ArnLike: {
              'aws:PrincipalArn': `arn:aws:iam::${stackConfig.awsEnv.account as string}:role/${
                config.extractionGlueRoleName
              }`,
            },
          }),
        ],
        resources: [historicDataBucket.arnForObjects('*'), historicDataBucket.bucketArn],
      }),
    );

    historicDataBucket.addToResourcePolicy(
      new PolicyStatement({
        actions: ['s3:Get*', 's3:Delete*', 's3:Put*'],
        principals: [
          new AnyPrincipal().withConditions({
            ArnLike: {
              'aws:PrincipalArn': `arn:aws:iam::${stackConfig.awsEnv.account as string}:role/${
                stackConfig.glueJobRoleName
              }`,
            },
          }),
        ],
        resources: [historicDataBucket.arnForObjects('*'), historicDataBucket.bucketArn],
      }),
    );

    historicDataBucket.addToResourcePolicy(
      new PolicyStatement({
        actions: ['s3:Get*', 's3:Delete*', 's3:Put*'],
        principals: [
          new AnyPrincipal().withConditions({
            ArnLike: {
              'aws:PrincipalArn': `arn:aws:iam::${
                stackConfig.awsEnv.account as string
              }:role/${grsiPrefix}-extract-glue-role-${stackConfig.environmentKey}`,
            },
          }),
        ],
        resources: [historicDataBucket.arnForObjects('*'), historicDataBucket.bucketArn],
      }),
    );
  }
}
