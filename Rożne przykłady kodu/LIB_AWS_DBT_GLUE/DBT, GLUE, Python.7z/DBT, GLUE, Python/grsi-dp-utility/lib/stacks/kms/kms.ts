import {
    config,
    KmsUtil,
    PermissionsBoundaryType,
    SecureStringParameter,
    SecureStringParameterTier,
    ISecureStringParameterProperties,
} from '@lmig/grsi-dp-shared-config-and-classes';
import { Aws, CfnOutput } from 'aws-cdk-lib';
import { LmPermissionsBoundaryType, PermissionsBoundaryArnFromType } from '@lmig/swa-cdk-core';
import {
    AnyPrincipal,
    ArnPrincipal,
    CompositePrincipal,
    Effect,
    ManagedPolicy,
    PolicyDocument,
    PolicyStatement,
    Role,
    ServicePrincipal,
} from 'aws-cdk-lib/aws-iam';
import { Key } from 'aws-cdk-lib/aws-kms';
import { Construct } from 'constructs';
import { StackConfiguration } from '../../../bin/config';

export class KmsResources extends Construct {
    constructor(scope: Construct, id: string, stackConfig: StackConfiguration) {
        super(scope, id);

        const kmsUtil = new KmsUtil(config.environmentKey);

        const snsKey = new Key(this, 'SnsKey', {
            enableKeyRotation: kmsUtil.shouldEnableKeyRotation(),
            alias: `alias/${config.grsiPrefix}-notification-sns-key-${config.regionEnv}`,
            removalPolicy: kmsUtil.getRemovalPolicy(),
            policy: new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:*'],
                        principals: [
                            new ArnPrincipal(`arn:aws:iam::${Aws.ACCOUNT_ID}:root`),
                            new ServicePrincipal('events.amazonaws.com'),
                            new ServicePrincipal('sns.amazonaws.com'),
                            new ServicePrincipal('cloudwatch.amazonaws.com'),
                            new ServicePrincipal('lambda.amazonaws.com'),
                            new ServicePrincipal('glue.amazonaws.com'),
                        ],
                    }),
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
                        principals: [
                            new AnyPrincipal().withConditions({
                                ArnLike: {
                                    'aws:PrincipalArn': `arn:aws:iam::${Aws.ACCOUNT_ID}:role/${config.lambdaRoleName}`,
                                },
                            }),
                        ],
                    }),
                ],
            }),
        });
        new CfnOutput(this, 'SnsKmsOutput', {
            exportName: stackConfig.snsKmsKeyExportName,
            value: snsKey.keyArn,
            description: 'SNS KMS Key ARN',
        });

        const dbtBucketKey = new Key(this, 'DbtBucketKey', {
            enableKeyRotation: kmsUtil.shouldEnableKeyRotation(),
            alias: `alias/${config.grsiPrefix}-dbt-key-${config.regionEnv}`,
            removalPolicy: kmsUtil.getRemovalPolicy(),
            policy: new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:*'],
                        principals: [new ArnPrincipal(`arn:aws:iam::${Aws.ACCOUNT_ID}:root`)],
                    }),
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:GenerateDataKey'],
                        principals: [
                            new ArnPrincipal(
                                `arn:aws:iam::${Aws.ACCOUNT_ID}:role/cloud-services/pipeline-deployment-guid-access`,
                            ),
                        ],
                    }),
                ],
            }),
        });
        new CfnOutput(this, 'DbtKmsOutput', {
            exportName: config.dbtKmsKeyExportName,
            value: dbtBucketKey.keyArn,
            description: 'dbt KMS Key ARN',
        });

        const redshiftKey = new Key(this, 'RedshiftKey', {
            enableKeyRotation: kmsUtil.shouldEnableKeyRotation(),
            alias: `alias/${config.grsiPrefix}-redshift-key-${config.regionEnv}`,
            removalPolicy: kmsUtil.getRemovalPolicy(),
            policy: new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:*'],
                        principals: [new ArnPrincipal(`arn:aws:iam::${Aws.ACCOUNT_ID}:root`)],
                    }),
                ],
            }),
        });
        new CfnOutput(this, 'RedshiftKmsOutput', {
            exportName: config.redshiftKmsKeyExportName,
            value: redshiftKey.keyArn,
            description: 'Redshift KMS Key ARN',
        });

        const rdsKey = new Key(this, 'RdsKey', {
            enableKeyRotation: kmsUtil.shouldEnableKeyRotation(),
            alias: `alias/${config.grsiPrefix}-rds-key-${config.regionEnv}`,
            removalPolicy: kmsUtil.getRemovalPolicy(),
            policy: new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:*'],
                        principals: [new ArnPrincipal(`arn:aws:iam::${Aws.ACCOUNT_ID}:root`)],
                    }),
                ],
            }),
        });
        if (config.environmentKey != 'production') {
            rdsKey.addToResourcePolicy(
                new PolicyStatement({
                    principals: [
                        new AnyPrincipal().withConditions({
                            ArnLike: {
                                'aws:PrincipalArn': `arn:aws:iam::${Aws.ACCOUNT_ID}:user/${stackConfig.developerUserName}`,
                            },
                        }),
                    ],
                    actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
                    resources: ['*'],
                }),
            );
        }
        new CfnOutput(this, 'RdsKeyOutput', {
            exportName: config.rdsKmsKeyExportName,
            value: rdsKey.keyArn,
            description: 'RDS KMS Key ARN',
        });

        const ingestionKmsKey = new Key(this, 'IngestionBucketKMSKey', {
            enableKeyRotation: kmsUtil.shouldEnableKeyRotation(),
            alias: `alias/${config.grsiPrefix}-ingestion-key-${config.regionEnv}`,
            removalPolicy: kmsUtil.getRemovalPolicy(),
            policy: new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        principals: [new ArnPrincipal(`arn:aws:iam::${Aws.ACCOUNT_ID}:root`)],
                        actions: ['kms:*'],
                        resources: ['*'],
                    }),
                    new PolicyStatement({
                        principals: [new ServicePrincipal(`logs.${config.awsRegion}.amazonaws.com`)],
                        actions: [
                            'kms:Encrypt*',
                            'kms:Decrypt*',
                            'kms:ReEncrypt*',
                            'kms:GenerateDatakey*',
                            'kms:Describe*',
                        ],
                        resources: ['*'],
                    }),
                    new PolicyStatement({
                        principals: [
                            new ArnPrincipal(
                                `arn:aws:iam::${Aws.ACCOUNT_ID}:role/cloud-services/pipeline-deployment-guid-access`,
                            ),
                        ],
                        actions: ['kms:Encrypt', 'kms:GenerateDatakey'],
                        resources: ['*'],
                    }),
                    new PolicyStatement({
                        principals: [
                            new AnyPrincipal().withConditions({
                                ArnLike: {
                                    'aws:PrincipalArn': `arn:aws:iam::${Aws.ACCOUNT_ID}:role/${config.grsiPrefix}-redshift-role-${config.regionEnv}`,
                                },
                            }),
                        ],
                        actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
                        resources: ['*'],
                    }),
                    new PolicyStatement({
                        principals: [
                            new AnyPrincipal().withConditions({
                                ArnLike: {
                                    'aws:PrincipalArn': `arn:aws:iam::${config.accountNumbers[config.environmentKey]['EU']}:role/${config.extractionGlueRoleNames['EU']
                                        }`,
                                },
                            }),
                        ],
                        actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
                        resources: ['*'],
                    }),
                    new PolicyStatement({
                        principals: [
                            new AnyPrincipal().withConditions({
                                ArnLike: {
                                    'aws:PrincipalArn': `arn:aws:iam::${config.accountNumbers[config.environmentKey]['US']}:role/${config.extractionGlueRoleNames['US']
                                        }`,
                                },
                            }),
                        ],
                        actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
                        resources: ['*'],
                    }),
                    new PolicyStatement({
                        principals: [
                            new AnyPrincipal().withConditions({
                                ArnLike: {
                                    'aws:PrincipalArn': `arn:aws:iam::${config.accountNumbers[config.environmentKey]['AP']}:role/${config.extractionGlueRoleNames['AP']
                                        }`,
                                },
                            }),
                        ],
                        actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
                        resources: ['*'],
                    }),
                    new PolicyStatement({
                        principals: [
                            new AnyPrincipal().withConditions({
                                ArnLike: {
                                    'aws:PrincipalArn': `arn:aws:iam::${Aws.ACCOUNT_ID}:role/${config.lambdaRoleName}`,
                                },
                            }),
                        ],
                        actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
                        resources: ['*'],
                    }),
                ],
            }),
        });
        if (config.environmentKey != 'production') {
            ingestionKmsKey.addToResourcePolicy(
                new PolicyStatement({
                    principals: [
                        new AnyPrincipal().withConditions({
                            ArnLike: {
                                'aws:PrincipalArn': `arn:aws:iam::${Aws.ACCOUNT_ID}:user/${stackConfig.developerUserName}`,
                            },
                        }),
                    ],
                    actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
                    resources: ['*'],
                }),
            );
        }
        new CfnOutput(this, 'IngestionBucketKmsOutput', {
            exportName: `${config.grsiPrefix}-ingestion-key-${config.regionEnv}`,
            value: ingestionKmsKey.keyId,
            description: `Ingestion Bucket ${config.regionEnv} KMS Key ID`,
        });

        const glueScriptBucketKmsKey = new Key(this, 'GlueKmsKey', {
            enableKeyRotation: kmsUtil.shouldEnableKeyRotation(),
            alias: `alias/${config.grsiPrefix}-glue-script-${config.environmentKey}`,
            removalPolicy: kmsUtil.getRemovalPolicy(),
            policy: new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:*'],
                        principals: [new ArnPrincipal(`arn:aws:iam::${Aws.ACCOUNT_ID}:root`)],
                    }),
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:GenerateDataKey'],
                        principals: [
                            new AnyPrincipal().withConditions({
                                ArnLike: {
                                    'aws:PrincipalArn': `arn:aws:iam::${Aws.ACCOUNT_ID}:user/${stackConfig.developerUserName}`,
                                },
                            }),
                        ],
                    }),
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:GenerateDataKey'],
                        principals: [
                            new ArnPrincipal(
                                `arn:aws:iam::${Aws.ACCOUNT_ID}:role/cloud-services/pipeline-deployment-guid-access`,
                            ),
                        ],
                    }),
                ],
            }),
        });
        new CfnOutput(this, 'GlueKmsKeyOutput', {
            exportName: config.glueScriptBucketKmsKeyExportName,
            value: glueScriptBucketKmsKey.keyArn,
            description: 'GlueScriptBucket KMS Key ARN',
        });

        // Set up SSM Parameter and IAM Role to be assumed by Glue Job for ingestion
        const ingestionKeyParamProps: ISecureStringParameterProperties = {
            parameterName: `${config.ingestionKmsKeySSMParamNamePrefix}-${config.regionEnv}`,
            secureValue: ingestionKmsKey.keyArn,
            description: `${Aws.REGION} Ingestion KMS Key ARN`,
            parameterTier: SecureStringParameterTier.STANDARD,
            paramTags: stackConfig.stackTags,
            // Use glue script bucket key since it's deployed to all regions and already scoped to the glue job
            encryptionKey: glueScriptBucketKmsKey,
        };

        // eslint-disable-next-line @typescript-eslint/no-unsafe-argument,@typescript-eslint/no-unused-vars
        const ingestionKeyParam = new SecureStringParameter(
            this,
            `grsi-dp-${id}-ssm-key-param`,
            ingestionKeyParamProps,
        );

        const glueTrustPrincipal = new CompositePrincipal(
            new AnyPrincipal().withConditions({
                StringLike: {
                    'aws:PrincipalArn': `arn:aws:iam::${config.accountNumbers[config.environmentKey].EU}:role/${config.grsiPrefix}-extract-glue-role-eu-${config.environmentKey}`,
                },
            }),
            new AnyPrincipal().withConditions({
                StringLike: {
                    'aws:PrincipalArn': `arn:aws:iam::${config.accountNumbers[config.environmentKey].US}:role/${config.grsiPrefix}-extract-glue-role-us-${config.environmentKey}`,
                },
            }),
            new ServicePrincipal('glue.amazonaws.com'),
        );

        const dynamoKmsKey = new Key(this, 'DynamoKey', {
            enableKeyRotation: kmsUtil.shouldEnableKeyRotation(),
            alias: `alias/${config.grsiPrefix}-dynamo-key-${config.regionEnv}`,
            removalPolicy: kmsUtil.getRemovalPolicy(),
            policy: new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:*'],
                        principals: [new ArnPrincipal(`arn:aws:iam::${Aws.ACCOUNT_ID}:root`)],
                    }),
                    new PolicyStatement({
                        principals: [
                            new AnyPrincipal().withConditions({
                                ArnLike: {
                                    'aws:PrincipalArn': `arn:aws:iam::${Aws.ACCOUNT_ID}:user/${stackConfig.developerUserName}`,
                                },
                            }),
                        ],
                        actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
                        resources: ['*'],
                    }),
                    new PolicyStatement({
                        principals: [
                            new AnyPrincipal().withConditions({
                                ArnLike: {
                                    'aws:PrincipalArn': `arn:aws:iam::${Aws.ACCOUNT_ID}:role/${config.grsiPrefix}-extract-glue-role-${config.regionEnv}`,
                                },
                            }),
                        ],
                        actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
                        resources: ['*'],
                    }),
                ],
            }),
        });

        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const glueAssumeRole: Role = new Role(this, 'glueAssumeSSMParamRole', {
            roleName: `${config.glueAssumeRoleNamePrefix}-${config.regionEnv}`,
            description: 'Role for Glue to Assume to retrieve SSM Params',
            inlinePolicies: {
                policy: new PolicyDocument({
                    statements: [
                        new PolicyStatement({
                            sid: 'EnableSSMParamGet',
                            actions: ['ssm:GetParameter'],
                            resources: [
                                `arn:aws:ssm:${Aws.REGION}:${Aws.ACCOUNT_ID}:parameter/${config.ingestionKmsKeySSMParamNamePrefix}-${config.regionEnv}`,
                            ],
                        }),
                        new PolicyStatement({
                            sid: 'EnableKMSKeyUsageToDecryptParam',
                            actions: ['kms:Decrypt'],
                            resources: [glueScriptBucketKmsKey.keyArn],
                        }),
                        new PolicyStatement({
                            actions: ['kms:Encrypt', 'kms:Decrypt', 'kms:DescribeKey'],
                            resources: [dynamoKmsKey.keyArn],
                        }),
                        new PolicyStatement({
                            actions: ['dynamodb:PutItem', 'dynamodb:GetItem', 'dynamodb:UpdateItem'],
                            resources: [
                                `arn:aws:dynamodb:${Aws.REGION}:${Aws.ACCOUNT_ID}:table/${config.dynamoColumnMappingTableNamePrefix}-${config.regionEnv}`,
                            ],
                        }),
                    ],
                }),
            },
            assumedBy: glueTrustPrincipal,
            permissionsBoundary: ManagedPolicy.fromManagedPolicyArn(
                this,
                `${id}-getTrouxPbArn`,
                PermissionsBoundaryArnFromType(PermissionsBoundaryType.trouxUuidAccess() as LmPermissionsBoundaryType),
            ),
        });

        new CfnOutput(this, 'DynamoKeyOutput', {
            exportName: config.dynamoKmsKeyExportName,
            value: dynamoKmsKey.keyArn,
            description: 'Dynamo KMS Key ARN',
        });

        new Key(this, 'SourceS3Key', {
            enableKeyRotation: kmsUtil.shouldEnableKeyRotation(),
            alias: `alias/${config.grsiPrefix}-source-data-${config.environmentKey}`,
            removalPolicy: kmsUtil.getRemovalPolicy(),
            policy: new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:*'],
                        principals: [new ArnPrincipal(`arn:aws:iam::${Aws.ACCOUNT_ID}:root`)],
                    }),
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
                        principals: [
                            new AnyPrincipal().withConditions({
                                ArnLike: {
                                    'aws:PrincipalArn': `arn:aws:iam::${Aws.ACCOUNT_ID}:user/${stackConfig.developerUserName}`,
                                },
                            }),
                        ],
                    }),
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
                        principals: [
                            new AnyPrincipal().withConditions({
                                ArnLike: {
                                    'aws:PrincipalArn': `arn:aws:iam::${Aws.ACCOUNT_ID}:role/${config.grsiPrefix}-extract-glue-role-${config.regionEnv}`,
                                },
                            }),
                        ],
                    }),
                ],
            }),
        });

        new Key(this, 'SQSKey', {
            enableKeyRotation: kmsUtil.shouldEnableKeyRotation(),
            alias: `alias/${config.grsiPrefix}-sqs-key-${config.regionEnv}`,
            removalPolicy: kmsUtil.getRemovalPolicy(),
            policy: new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:*'],
                        principals: [new ArnPrincipal(`arn:aws:iam::${Aws.ACCOUNT_ID}:root`)],
                    }),
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
                        principals: [
                            new AnyPrincipal().withConditions({
                                ArnLike: {
                                    'aws:PrincipalArn': `arn:aws:iam::${Aws.ACCOUNT_ID}:role/${config.grsiPrefix}-*-${config.environmentKey}`,
                                },
                            }),
                        ],
                    }),
                    //  Allow the producer (SNS notification channel) access to the SQS Key
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
                        principals: [new ServicePrincipal('sns.amazonaws.com')],
                    }),
                ],
            }),
        });
    }
}
