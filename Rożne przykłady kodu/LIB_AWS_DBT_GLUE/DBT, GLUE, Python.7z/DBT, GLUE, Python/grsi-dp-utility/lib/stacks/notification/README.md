<h1 align="left">Alerting via SNS Notification Topic</h1>
<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->


<!-- END doctoc generated TOC please keep comment here to allow auto update -->


This utility forms the backbone of our monitoring and alerting.

All possible error channels should be subscribed to the topic in this directory.

To add more recipients to recieve alert emails, add them to `alertAddresses` in `lib/stacks/notification/notification.ts`. If you are developing new features you may way to add yourself to `devAddresses` to not spam other engineers with failure notifications.

SNS delivery logging has been enabled to aid debugging when messages fail to be published to subscribers. You can find the log group here: `CloudWatch > Log groups > sns/<region>/<account>/grsi-dp-notification-topic-<regionEnv>/<Failure||Success>`

You will receive a confirmation email which should be accepted using the CLI with removal protection. For simplicity a script has been included where if you pass the confirmation link (from the email) as a command line argument, you can confirm the subsciption whilst setting the authentication flag as a requirement for unsubscribing ([further info here](https://repost.aws/knowledge-center/prevent-unsubscribe-all-sns-topic)).

WARNING: If you unsubscribe from a topic, everyone will be unsubscribed. Do not do this.

To subscribe/unsubscribe for each region and environment you'll need to get the [Dev user creds from cloudforge](https://console.forge.lmig.com/artifact/b0fac370-c7aa-4659-a349-8a8e4c29e519/secrets).

Stick them in your `~/.aws/credentials` file and export that profile, ie:

```bash
export AWS_DEFAULT_PROFILE=dev
```

Then you can run the confirmation script.

Set the var `CONFIRMATION_URL` to that of the confirmation link wrapped in quotes and run as follows:

```bash
CONFIRMATION_URL='https://urldefense.com/v3/__https://sns.eu-west-1.amazonaws.com/confirmation.html?TopicArn=<yourTopicArn>&Token=<UUID1>?&Endpoint=your.email@libertyglobalgroup.com__;!!<UUID2>'
```

```bash
lib/stacks/notification/subscribe.sh $CONFIRMATION_URL
```

Repeat this process for test and production EU and US (and any other environments that exist).


If you have followed this process and try to unsubscribe from notification emails by clicking an unsubscribe link you should see the following error:

![unsubscribe-error](./aws-unsubscribe-error.png)

This is a good sign and you'll have to purposefully use the AWS CLI to unsubscribe.