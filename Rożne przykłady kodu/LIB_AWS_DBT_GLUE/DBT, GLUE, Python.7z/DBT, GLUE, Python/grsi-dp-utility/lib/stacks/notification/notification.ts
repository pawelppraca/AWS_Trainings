import { config, grsiPrefix } from '@lmig/grsi-dp-shared-config-and-classes';
import { Fn } from 'aws-cdk-lib';
import { Effect, ManagedPolicy, PolicyStatement, Role, ServicePrincipal } from 'aws-cdk-lib/aws-iam';
import { Key } from 'aws-cdk-lib/aws-kms';
import { LoggingProtocol, Topic } from 'aws-cdk-lib/aws-sns';
import { EmailSubscription } from 'aws-cdk-lib/aws-sns-subscriptions';
import { Construct } from 'constructs';
import { StackConfiguration } from '../../../bin/config';

export class NotificationResources extends Construct {
    constructor(scope: Construct, id: string, stackConfig: StackConfiguration) {
        super(scope, id);

        const topic = new Topic(this, 'NotificationTopic', {
            enforceSSL: true,
            topicName: config.notificationTopicName,
            masterKey: Key.fromKeyArn(this, 'SnsKeyLookup', Fn.importValue(stackConfig.snsKmsKeyExportName)),
        });

        const topicLoggingRole = new Role(this, 'topicLoggingRole', {
            assumedBy: new ServicePrincipal('sns.amazonaws.com'),
            roleName: `${grsiPrefix}-sns-logging-${config.regionEnv}`,
            managedPolicies: [ManagedPolicy.fromAwsManagedPolicyName('CloudWatchFullAccess')],
        });

        topic.addLoggingConfig({
            protocol: LoggingProtocol.SQS,
            failureFeedbackRole: topicLoggingRole,
            successFeedbackRole: topicLoggingRole,
            successFeedbackSampleRate: 50,
        });

        //  Allow most services to publish to our sns error notification channel
        topic.addToResourcePolicy(
            new PolicyStatement({
                actions: ['SNS:Publish'],
                effect: Effect.ALLOW,
                principals: [
                    new ServicePrincipal('events.amazonaws.com'),
                    new ServicePrincipal('sns.amazonaws.com'),
                    new ServicePrincipal('sqs.amazonaws.com'),
                    new ServicePrincipal('cloudwatch.amazonaws.com'),
                    new ServicePrincipal('cloudtrail.amazonaws.com'),
                    new ServicePrincipal('lambda.amazonaws.com'),
                    new ServicePrincipal('glue.amazonaws.com'),
                ],
                resources: [topic.topicArn],
            }),
        );

        //  Confirm your subsciption using lib/stacks/notification/subscribe.sh $CONFIRMATION_URL
        //  You can obtain the $CONFIRMATION_URL from email amazon will send after deployment
        //  Further info here https://repost.aws/knowledge-center/prevent-unsubscribe-all-sns-topic

        // WARNING: Do not click any unsubscribe emails for this Topic or you will unsubscribe everyone!
        const devAddresses: string[] = [];

        const alertAddressesNonProd: string[] = ['GRSI_DP_AWS_Support_NonProd@libertymutual.com'];

        const alertAddressesProd: string[] = ['GRSI_DP_AWS_Support_Prod@libertymutual.com'];

        if (stackConfig.environmentKey == 'production') {
            alertAddressesProd.forEach((address) => {
                topic.addSubscription(new EmailSubscription(address));
            });
        } else if (stackConfig.environmentKey == 'development') {
            devAddresses.forEach((address) => {
                topic.addSubscription(new EmailSubscription(address));
            });
        } else {
            alertAddressesNonProd.forEach((address) => {
                topic.addSubscription(new EmailSubscription(address));
            });
        }
    }
}
