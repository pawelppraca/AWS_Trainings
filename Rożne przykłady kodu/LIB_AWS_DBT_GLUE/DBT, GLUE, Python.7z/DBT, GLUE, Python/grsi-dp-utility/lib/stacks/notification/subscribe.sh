#!/usr/bin/env bash

# use: lib/stacks/notification/subscribe.sh $CONFIRMATION_URL

CONFIRMATION_URL=$1


if [ -z "$CONFIRMATION_URL" ]; then
  echo "CONFIRMATION_URL is not set, retrieve it from the confirmation email sent by AWS and pass it as the first argument"
  exit 1
fi

if [ -z "$AWS_DEFAULT_REGION" ]; then
  echo "AWS_DEFAULT_REGION environment variable is not set, set it with 'export AWS_DEFAULT_REGION=myregion'"
  exit 1
fi

TopicArn=$(sed 's/.*TopicArn\\=//; s/\\&Token.*//' <<< $CONFIRMATION_URL)
echo -e "TopicArn: $TopicArn\n"

Token=$(sed 's/.*&Token\\=//; s/\\&Endpoint.*//' <<< $CONFIRMATION_URL)
echo -e "Token: $Token\n"

aws sns confirm-subscription --token $Token --topic-arn $TopicArn  --authenticate-on-unsubscribe true --region $AWS_DEFAULT_REGION