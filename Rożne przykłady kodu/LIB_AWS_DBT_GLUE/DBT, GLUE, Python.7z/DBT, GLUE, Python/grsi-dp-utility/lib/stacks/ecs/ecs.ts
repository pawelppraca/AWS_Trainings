import { vpc, config } from '@lmig/grsi-dp-shared-config-and-classes';
import { Cluster } from 'aws-cdk-lib/aws-ecs';
import { Construct } from 'constructs';
import { StackConfiguration } from '../../../bin/config';

export class EcsResources extends Construct {
    // eslint-disable-next-line  @typescript-eslint/no-unused-vars
    constructor(scope: Construct, id: string, stackConfig: StackConfiguration) {
        super(scope, id);

        const vpcLookup = new vpc(this, 'LookupVpc');

        new Cluster(this, 'EcsCluster', {
            clusterName: config.ecsClusterName,
            vpc: vpcLookup.ivpc,
        });
    }
}
