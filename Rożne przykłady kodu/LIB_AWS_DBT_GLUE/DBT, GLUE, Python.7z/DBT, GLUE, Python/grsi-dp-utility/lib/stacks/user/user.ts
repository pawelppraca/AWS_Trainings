import { ApplyTagsToResourceCustomResource, SecretPapiRotateIamUserAccessKeysCustomResource } from '@lmig/swa-cdk-core';
import { Effect, ManagedPolicy, PermissionsBoundary, PolicyStatement, User } from 'aws-cdk-lib/aws-iam';
import { Construct } from 'constructs';
import { StackConfiguration } from '../../../bin/config';
import { Aws, Tags } from 'aws-cdk-lib';
import { config, grsiPrefix } from '@lmig/grsi-dp-shared-config-and-classes';

export class UserResources extends Construct {
    static readonly serviceUserPolicyName: string = `${grsiPrefix}-service-user-policy-${config.regionEnv}`;
    static readonly serviceUserPbPolicyName: string = `${grsiPrefix}-service-user-policy-custom-actions-${config.regionEnv}`;
    static readonly supportUserName: string = `${grsiPrefix}-support-user-${config.regionEnv}`;

    constructor(scope: Construct, id: string, stackConfig: StackConfiguration) {
        super(scope, id);

        const serviceUserPolicy = new ManagedPolicy(this, 'serviceUserPolicy', {
            managedPolicyName: UserResources.serviceUserPolicyName,
            statements: [
                // Useful for invoking integration test ad-hoc
                new PolicyStatement({
                    actions: ['lambda:InvokeFunction'],
                    resources: [
                        `arn:aws:lambda:${Aws.REGION}:${Aws.ACCOUNT_ID}:function:${grsiPrefix}-*-${stackConfig.regionEnv}`,
                    ],
                }),

                new PolicyStatement({
                    actions: ['events:ListEventBuses', 'events:ListRules', 'events:ListReplays', 'events:ListArchives'],
                    resources: [
                        `arn:aws:events:${Aws.REGION}:${Aws.ACCOUNT_ID}:event-bus/*`,
                        `arn:aws:events:${Aws.REGION}:${Aws.ACCOUNT_ID}:rule/*`,
                        `arn:aws:events:${Aws.REGION}:${Aws.ACCOUNT_ID}:replay/*`,
                        `arn:aws:events:${Aws.REGION}:${Aws.ACCOUNT_ID}:archive/*`,
                    ],
                }),

                new PolicyStatement({
                    actions: ['glue:StartJobRun', 'glue:BatchStopJobRun'],
                    resources: [
                        `arn:aws:glue:${Aws.REGION}:${Aws.ACCOUNT_ID}:job/${grsiPrefix}-*-${config.environmentKey}`,
                    ],
                }),
                new PolicyStatement({
                    actions: ['glue:StartCrawler', 'glue:StopCrawler'],
                    resources: [
                        `arn:aws:glue:${Aws.REGION}:${Aws.ACCOUNT_ID}:crawler/${grsiPrefix}-*-${config.environmentKey}`,
                    ],
                }),

                // Required for sns email subscription confirmation with IAM, see [here](https://github.com/lmigtech/grsi-dp-utility/blob/dev/lib/stacks/notification/README.md)
                // for more details
                new PolicyStatement({
                    actions: ['SNS:ListSubscriptions'],
                    // Required as List needs access to all topics
                    resources: [`arn:aws:sns:${Aws.REGION}:${Aws.ACCOUNT_ID}:*`],
                }),

                new PolicyStatement({
                    actions: [
                        'SNS:ConfirmSubscription',
                        'SNS:GetSubscriptionAttributes',
                        'SNS:Unsubscribe',
                        'SNS:ListSubscriptionsByTopic',
                    ],
                    resources: [`arn:aws:sns:${Aws.REGION}:${Aws.ACCOUNT_ID}:${grsiPrefix}*`],
                }),
            ],
        });

        const serviceUserLmigPBActionsPolicy = new ManagedPolicy(this, 'serviceUserLmigPBActionsPolicy', {
            managedPolicyName: UserResources.serviceUserPbPolicyName,
            path: '/permission-boundary/',
            statements: [
                new PolicyStatement({
                    actions: ['iam:PassRole'],
                    resources: [`arn:aws:iam::${Aws.ACCOUNT_ID}:role/${config.dbtFargateRoleName}`],
                }),
                new PolicyStatement({
                    actions: ['ecs:RunTask', 'ecs:DescribeTasks'],
                    resources: [
                        `arn:aws:ecs:${Aws.REGION}:${Aws.ACCOUNT_ID}:task-definition/${grsiPrefix}-*`,
                        `arn:aws:ecs:${Aws.REGION}:${Aws.ACCOUNT_ID}:task/${grsiPrefix}-ecs-cluster-${config.regionEnv}/*`,
                    ],
                }),

                new PolicyStatement({
                    actions: [
                        'events:CancelReplay',
                        'events:DescribeReplay',
                        'events:DescribeArchive',
                        'events:StartReplay',
                    ],
                    resources: [
                        `arn:aws:events:${Aws.REGION}:${Aws.ACCOUNT_ID}:replay/${grsiPrefix}*`,
                        `arn:aws:events:${Aws.REGION}:${Aws.ACCOUNT_ID}:archive/${grsiPrefix}*`,
                        `arn:aws:events:${Aws.REGION}:${Aws.ACCOUNT_ID}:event-bus/${grsiPrefix}-event-bus-${config.regionEnv}`,
                    ],
                }),

                new PolicyStatement({
                    actions: ['glue:StartJobRun', 'glue:BatchStopJobRun'],
                    resources: [
                        `arn:aws:glue:${Aws.REGION}:${Aws.ACCOUNT_ID}:job/${grsiPrefix}-*-${config.environmentKey}`,
                    ],
                }),

                new PolicyStatement({
                    actions: ['iam:GetRole', 'iam:PassRole'],
                    resources: [
                        `arn:aws:iam::${Aws.ACCOUNT_ID}:role/${grsiPrefix}-extract-glue-role-${config.regionEnv}`,
                        `arn:aws:iam::${Aws.ACCOUNT_ID}:role/${grsiPrefix}-*-${config.regionEnv}`,
                    ],
                }),

                new PolicyStatement({
                    resources: [
                        'arn:aws:ec2:::network-interface/',
                        'arn:aws:ec2:::security-group/',
                        'arn:aws:ec2:::instance/*',
                    ],
                    actions: ['ec2:CreateTags', 'ec2:DeleteTags'],
                    conditions: {
                        'ForAllValues:StringEquals': {
                            'aws:TagKeys': 'aws-glue-service-resource',
                        },
                    },
                    effect: Effect.ALLOW,
                }),
                new PolicyStatement({
                    actions: [
                        'glue:CreateSession',
                        'glue:GetSession',
                        'glue:StopSession',
                        'glue:GetStatement',
                        'glue:RunStatement',
                        'glue:CancelStatement',
                        'glue:TagResource',
                    ],
                    resources: [`arn:aws:glue:${Aws.REGION}:${Aws.ACCOUNT_ID}:session/*`],
                }),
                new PolicyStatement({
                    actions: [
                        'SNS:ConfirmSubscription',
                        'SNS:GetSubscriptionAttributes',
                        'SNS:Unsubscribe',
                        'SNS:ListSubscriptionsByTopic',
                    ],
                    resources: [`arn:aws:sns:${Aws.REGION}:${Aws.ACCOUNT_ID}:${grsiPrefix}*`],
                }),
            ],
        });

        const supportUser = new User(this, 'SupportUser', {
            userName: UserResources.supportUserName,
            managedPolicies: [serviceUserPolicy, serviceUserLmigPBActionsPolicy],
        });

        supportUser.node.addDependency(serviceUserPolicy);
        supportUser.node.addDependency(serviceUserLmigPBActionsPolicy);
        PermissionsBoundary.of(supportUser).apply(serviceUserLmigPBActionsPolicy);
        Tags.of(supportUser).add('aws_iam_permission_boundary_exempt', 'CustomAwaitingApproval');

        new ApplyTagsToResourceCustomResource(this, 'TagServiceUser', {
            resource: serviceUserPolicy,
            tags: {},
        }).node.addDependency(serviceUserPolicy);
        new ApplyTagsToResourceCustomResource(this, 'TagServiceUserLmigPBActions', {
            resource: serviceUserLmigPBActionsPolicy,
            tags: {},
        }).node.addDependency(serviceUserLmigPBActionsPolicy);

        const supportUserCreds = new SecretPapiRotateIamUserAccessKeysCustomResource(this, 'SupportUserAccessKeys', {
            userName: supportUser.userName,
            secretName: supportUser.userName,
            papiIndex: config.secrets.papiIndex,
            vaultToken: config.secrets.vaultToken,
        });
        supportUserCreds.node.addDependency(supportUser);

        if (config.environmentKey != 'production') {
            // user for doing local development such as running interactive glue sessions
            const developer = new User(this, 'Developer', {
                userName: `${stackConfig.developerUserName}`,
                managedPolicies: [serviceUserPolicy, serviceUserLmigPBActionsPolicy],
            });
            developer.node.addDependency(serviceUserPolicy);
            developer.node.addDependency(serviceUserLmigPBActionsPolicy);
            developer.stack.tags.setTag('aws_iam_permission_boundary_exempt', 'true');

            developer.addToPolicy(
                new PolicyStatement({
                    actions: ['redshift:ModifyScheduledAction'],
                    resources: [`*`],
                }),
            );

            developer.addToPolicy(
                new PolicyStatement({
                    actions: ['redshift:Describe*'],
                    resources: [`arn:aws:redshift:${Aws.REGION}:${Aws.ACCOUNT_ID}:cluster:*`],
                }),
            );

            developer.addToPolicy(
                new PolicyStatement({
                    actions: ['redshift:ResumeCluster', 'redshift:PauseCluster'],
                    resources: [
                        `arn:aws:redshift:${Aws.REGION}:${Aws.ACCOUNT_ID}:cluster:${grsiPrefix}-redshift-${stackConfig.regionEnv}`,
                    ],
                }),
            );

            developer.addToPolicy(
                new PolicyStatement({
                    actions: ['redshift:GetClusterCredentials'],
                    resources: [
                        `arn:aws:redshift:${Aws.REGION}:${Aws.ACCOUNT_ID}:dbuser:${grsiPrefix}-redshift-${stackConfig.regionEnv}/*`,
                        `arn:aws:redshift:${Aws.REGION}:${Aws.ACCOUNT_ID}:dbname:${grsiPrefix}-redshift-${stackConfig.regionEnv}/grsi_dp_${config.regionCode}_${config.environmentKey}`,
                    ],
                }),
            );

            developer.addToPolicy(
                new PolicyStatement({
                    actions: [
                        's3:PutObject*',
                        's3:GetObject*',
                        's3:DeleteObject*',
                        's3:GetObjectTagging',
                        's3:ListBucket',
                    ],
                    resources: [
                        `arn:aws:s3:::${grsiPrefix}-*-${config.environmentKey}`,
                        `arn:aws:s3:::${grsiPrefix}-*-${config.environmentKey}/*`,
                    ],
                }),
            );

            developer.addToPolicy(
                new PolicyStatement({
                    actions: ['s3:ListAllMyBuckets'],
                    resources: [`arn:aws:s3:::*`],
                }),
            );

            //  grsi dp dynamo tables do not contain PII. At time of writing they are for locking (with a record TTL) & manifest for
            // tracking when a file was ingested. This is only violated if the filename includes PII (which would be dumb, dont do that)
            developer.addToPolicy(
                new PolicyStatement({
                    actions: ['dynamodb:ListTables'],
                    resources: [`*`],
                }),
            );

            developer.addToPolicy(
                new PolicyStatement({
                    actions: [
                        'dynamodb:BatchGetItem',
                        'dynamodb:BatchWriteItem',
                        'dynamodb:ConditionCheckItem',
                        'dynamodb:PutItem',
                        'dynamodb:DescribeTable',
                        'dynamodb:DeleteItem',
                        'dynamodb:GetItem',
                        'dynamodb:Scan',
                        'dynamodb:Query',
                        'dynamodb:UpdateItem',
                        'dynamodb:ListTables',
                    ],
                    resources: [`arn:aws:dynamodb:${Aws.REGION}:${Aws.ACCOUNT_ID}:table/${grsiPrefix}*`],
                }),
            );

            const developerCreds = new SecretPapiRotateIamUserAccessKeysCustomResource(this, 'DeveloperAccessKeys', {
                userName: developer.userName,
                secretName: developer.userName,
                papiIndex: config.secrets.papiIndex,
                vaultToken: config.secrets.vaultToken,
            });
            developerCreds.node.addDependency(developer);
        }
    }
}
