<h1 align="left">Support User</h1>
<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->

- [Common Tasks](#common-tasks)
  - [Trigger dbt - Running an ECS TASK](#trigger-dbt---running-an-ecs-task)
  - [Running the integration test - Invoke Lambda](#running-the-integration-test---invoke-lambda)
  - [Replay Events](#replay-events)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->


You may find most of your needs met with the JIT role. In general we want to avoid utilising a Service User where possible as it is a path that can lead to [Permission Escalation](https://docs.aws.amazon.com/wellarchitected/latest/financial-services-industry-lens/aws-identity-and-access-management-iam.html). However from how lmig AWS accounts are set up they are overly restrictive and prevent ordinary non sensivite day to day tasks. This is where the JIT role in [Public Cloud](https://publiccloud.lmig.com/cloud_applications/31368?tab=overview) _should_ come in and elevates our permissions in non prod and production. Even so, it is still now powerful enough to do all of what we need, for example Starting an ECS Task. We use ECS to run dbt and deploy the data warehouse model to Redshift. Should you need to run dbt and trigger that ECS task, you can use the Support User along with adapting the following command.

# Common Tasks

## Trigger dbt - Running an ECS TASK

You'll to get the networking config from describing the task:

Dev EU

```bash
aws ecs describe-tasks --cluster  'grsi-dp-ecs-cluster-eu-development' --tasks 'arn:aws:ecs:eu-west-1:303081787871:task/grsi-dp-ecs-cluster-eu-development/649985d37b644ebfa038d3cbab8efb7e'
```

Test EU

```bash
aws ecs describe-tasks --cluster 'grsi-dp-ecs-cluster-eu-test' --tasks 'arn:aws:ecs:eu-west-1:866525145675:task/grsi-dp-ecs-cluster-eu-test/90fa59427b8e44c0b50f1ab3bd82dca1'
```

Then adapt the following to your environment and region:

Dev EU

```bash
aws ecs run-task \
    --cluster 'grsi-dp-ecs-cluster-eu-development' \
    --task-definition 'grsi-dp-dbt-fargate-eu-development' \
    --network-configuration '{ "awsvpcConfiguration": { "assignPublicIp":"DISABLED", "securityGroups": ["sg-0b1f092f35dc9690c"], "subnets": ["subnet-00d5234530c25e9e4"]}}' \
    --launch-type="FARGATE"
```

Test EU

```bash
aws ecs run-task \
    --cluster 'grsi-dp-ecs-cluster-eu-test' \
    --task-definition 'grsi-dp-dbt-fargate-eu-test' \
    --network-configuration '{ "awsvpcConfiguration": { "assignPublicIp":"DISABLED", "securityGroups": ["sg-09b21a8ce2df024ad"], "subnets": ["subnet-02c70ec7d45c71968"]}}' \
    --launch-type="FARGATE"
```

## Running the integration test - Invoke Lambda

```bash
aws lambda invoke --function-name grsi-dp-integration-test-load-eu-development --query 'Payload' --cli-read-timeout 0 --output=text response.json > /dev/null
```

## Replay Events 

[Full instructions here](https://github.com/lmigtech/grsi-dp-ingestion/blob/dev/scripts/replay/README.md)

