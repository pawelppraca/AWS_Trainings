import os
from airflow import DAG
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from datetime import datetime, timedelta

env_key = os.environ["ENVIRONMENT_KEY"]
region_code = os.environ["AWS_REGION"][:2]

# Define default arguments
default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

# Define the DAG
dag = DAG(
    "policy_extract_dag",
    default_args=default_args,
    description="DAG to trigger policy data extract Glue job",
    schedule_interval=None,
    start_date=datetime(2025, 1, 1),
    catchup=False,
)

# Define the Glue job run step
job_run = GlueJobOperator(
    task_id="job_run",
    job_name=f"grsi-dp-policy-extract-{env_key}",
    job_desc="trigger policy extract",
    region_name="eu-west-1",
    iam_role_name=f"grsi-dp-glue-extract-role-{region_code}-{env_key}",
    num_of_dpus=1,
    dag=dag,
)

# Define the task order
job_run
