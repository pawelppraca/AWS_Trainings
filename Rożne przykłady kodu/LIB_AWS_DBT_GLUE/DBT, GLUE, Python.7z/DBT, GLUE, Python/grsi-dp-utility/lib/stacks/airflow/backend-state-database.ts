import { vpc, config } from '@lmig/grsi-dp-shared-config-and-classes';
import { Construct } from 'constructs';
import { StackConfiguration } from '../../../bin/config';
import { Key } from 'aws-cdk-lib/aws-kms';
import {
    RandomCustomResource,
    RdsMasterSecretActionType,
    RdsMasterSecretType,
    SecretPapiRdsMasterCustomResource,
} from '@lmig/swa-cdk-core';
import { Peer, Port, SecurityGroup, InstanceType } from 'aws-cdk-lib/aws-ec2';
import {
    SubnetGroup,
    DatabaseInstance,
    DatabaseInstanceEngine,
    PostgresEngineVersion,
    Credentials,
    StorageType,
} from 'aws-cdk-lib/aws-rds';
import { CfnOutput, SecretValue, Fn, Duration, Tags, Aws } from 'aws-cdk-lib';
import { Role, ServicePrincipal, PolicyStatement, PolicyDocument, Effect } from 'aws-cdk-lib/aws-iam';

export class AirflowBackendDatabaseResources extends Construct {
    private readonly airflowPort: number = 8080;
    constructor(scope: Construct, id: string, stackConfig: StackConfiguration) {
        super(scope, id);
        const rdsPostgresPort = 5432;
        const databaseName = `airflow`;
        const adminUsername = `grsiadmin`;
        const roleName = `${stackConfig.artifactKey}-airflow-rds-role-${config.regionEnv}`;

        const kmsKey = Key.fromKeyArn(
            this,
            'KmsLookup',
            Fn.importValue(`${config.grsiPrefix}-rds-key-${config.regionEnv}`),
        );

        const vpcSubnetGroup = config.subnetMapping[config.environmentKey][config.regionCode.toUpperCase()];
        const vpcLookup = new vpc(this, 'VpcLookup', vpcSubnetGroup);

        const subnetGroup = new SubnetGroup(this, 'AirflowSubnetGroup', {
            description: 'Airflow private subnet group',
            vpc: vpcLookup.ivpc,
            subnetGroupName: `${stackConfig.artifactKey}-airflow-subnet-group-${config.regionEnv}`,
            vpcSubnets: {
                subnets: vpcLookup.iSubnet,
            },
        });

        const rdsSecGroup = new SecurityGroup(this, `${stackConfig.artifactKey}-rds-sec-group-${config.regionEnv}`, {
            securityGroupName: `${stackConfig.artifactKey}-sec-group-${config.regionEnv}`,
            vpc: vpcLookup.ivpc,
            description: 'GRSI RDS Security Group',
        });

        rdsSecGroup.addIngressRule(Peer.ipv4('10.0.0.0/8'), Port.tcp(rdsPostgresPort));
        rdsSecGroup.addIngressRule(
            Peer.ipv4('10.225.201.0/25'),
            Port.tcp(rdsPostgresPort),
            'Allow secret management access',
        );
        rdsSecGroup.addIngressRule(
            Peer.ipv4('10.225.201.128/25'),
            Port.tcp(rdsPostgresPort),
            'Allow secret management access',
        );
        rdsSecGroup.addIngressRule(
            Peer.ipv4('10.225.203.128/25'),
            Port.tcp(rdsPostgresPort),
            'Allow secret management access',
        );
        rdsSecGroup.addIngressRule(
            Peer.ipv4('10.237.12.0/22'),
            Port.tcp(rdsPostgresPort),
            'Allow secret management access',
        );
        rdsSecGroup.addIngressRule(
            Peer.ipv4('10.237.16.0/22'),
            Port.tcp(rdsPostgresPort),
            'Allow secret management access',
        );
        rdsSecGroup.addIngressRule(
            Peer.ipv4('10.237.20.0/22'),
            Port.tcp(rdsPostgresPort),
            'Allow secret management access',
        );

        const random = new RandomCustomResource(this, 'grsi-dp-random-rds-secret', {
            length: 32,
            updateOnDeployment: true,
        });

        const rdsAdminPassword = 'superSecretDbPass' + random.random();
        const rdsAdminPasswordSecret = SecretValue.unsafePlainText(rdsAdminPassword);

        const rdsRole = new Role(this, `${stackConfig.artifactKey}-airflow-rds-role`, {
            roleName: roleName,
            assumedBy: new ServicePrincipal('rds.amazonaws.com'),
            inlinePolicies: {
                KMSPolicy: new PolicyDocument({
                    statements: [
                        new PolicyStatement({
                            effect: Effect.ALLOW,
                            actions: [
                                'kms:Encrypt*',
                                'kms:Decrypt*',
                                'kms:ReEncrypt*',
                                'kms:GenerateDatakey*',
                                'kms:Describe*',
                            ],
                            resources: [kmsKey.keyArn],
                        }),
                    ],
                }),
                logsPolicy: new PolicyDocument({
                    statements: [
                        new PolicyStatement({
                            actions: ['logs:*'],
                            resources: [`arn:aws:logs:${Aws.REGION}:${Aws.ACCOUNT_ID}:log-group:${config.grsiPrefix}*`],
                        }),
                    ],
                }),
            },
        });

        const rdsInstance = new DatabaseInstance(this, 'AirflowPostgresBackendInstance', {
            engine: DatabaseInstanceEngine.postgres({
                version: PostgresEngineVersion.VER_16_2,
            }),
            instanceIdentifier: `${config.grsiPrefix}-airflow-postgres-backend-${config.regionEnv}`,
            vpc: vpcLookup.ivpc,
            allowMajorVersionUpgrade: false,
            autoMinorVersionUpgrade: false,
            backupRetention: Duration.days(7),
            cloudwatchLogsExports: ['postgresql', 'upgrade'],
            credentials: Credentials.fromPassword(adminUsername, rdsAdminPasswordSecret),
            databaseName: databaseName,
            domainRole: rdsRole,
            instanceType: new InstanceType('t4g.micro'),
            multiAz: true,
            parameters: {
                'rds.force_admin_logging_level': 'log',
            },
            port: rdsPostgresPort,
            publiclyAccessible: false,
            iamAuthentication: true,
            securityGroups: [rdsSecGroup],
            storageEncrypted: true,
            storageEncryptionKey: kmsKey,
            subnetGroup: subnetGroup,
            storageType: StorageType.GP3,
        });

        new CfnOutput(this, 'airflowBackendRdsID', {
            exportName: `${config.grsiPrefix}-airflow-backend-rds-resource-id-${config.regionEnv}`,
            value: rdsInstance.instanceResourceId!,
        });

        new CfnOutput(this, 'airflowBackendRdsHostOutput', {
            exportName: `${config.grsiPrefix}-airflow-backend-rds-host-${config.regionEnv}`,
            value: rdsInstance.dbInstanceEndpointAddress,
        });

        new CfnOutput(this, 'airflowBackendRdsPortOutput', {
            exportName: `${config.grsiPrefix}-airflow-backend-rds-port-${config.regionEnv}`,
            value: rdsInstance.dbInstanceEndpointPort,
        });
        new CfnOutput(this, 'airflowBackendRdsUserOutput', {
            exportName: `${config.grsiPrefix}-airflow-backend-rds-user-${config.regionEnv}`,
            value: adminUsername,
        });
        new CfnOutput(this, 'airflowBackendRdsDatabaseNameOutput', {
            exportName: `${config.grsiPrefix}-airflow-backend-rds-database-name-${config.regionEnv}`,
            value: databaseName,
        });

        Tags.of(rdsInstance).add('lm_app', config.stackTags.lm_app);
        Tags.of(rdsInstance).add('deployment_guid', config.stackTags.deployment_guid);
        Tags.of(rdsInstance).add('lm_troux_uid', config.stackTags.lm_troux_uid);
        Tags.of(rdsInstance).add('organization_guid', config.stackTags.organization_guid);
        Tags.of(rdsInstance).add('dpmawsbackup', stackConfig.sourceRegionFailSafeBackupTag);

        new SecretPapiRdsMasterCustomResource(
            this,
            `${stackConfig.artifactKey}-airflow-rds-creds-to-vault-${config.regionEnv}`,
            {
                action: RdsMasterSecretActionType.CREATE,
                updateOnDeployment: true,
                dBInstanceKey: rdsInstance.instanceIdentifier,
                vaultToken: config.secrets.vaultToken,
                secretType: RdsMasterSecretType.POSTGRESQL,
                papiIndex: config.secrets.papiIndex,
                dBConnectionUrl:
                    'postgresql://' +
                    adminUsername +
                    ':' +
                    rdsAdminPassword +
                    '@' +
                    rdsInstance.dbInstanceEndpointAddress +
                    ':' +
                    rdsInstance.dbInstanceEndpointPort +
                    '/' +
                    databaseName,
            },
        );
    }
}
