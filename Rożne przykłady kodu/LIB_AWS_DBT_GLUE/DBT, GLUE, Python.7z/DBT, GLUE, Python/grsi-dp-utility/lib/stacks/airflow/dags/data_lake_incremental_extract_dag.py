import os
from airflow import DAG
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
from datetime import datetime, timedelta
from creds import create_aws_connection, assume_role

env_key = os.environ["ENVIRONMENT_KEY"]
region_code = os.environ["AWS_REGION"][:2]
us_account = os.environ["ACCOUNT_NUMBER_US"]

# Define default arguments
default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

# Define the DAG
dag = DAG(
    "data_lake_incremental_extract_dag",
    default_args=default_args,
    description="DAG to trigger incremental data extract Glue job",
    start_date=datetime(2025, 1, 1),
    schedule=None,
    max_active_runs=1,
    catchup=False,
)

role_arn = f"arn:aws:iam::{us_account}:role/grsi-dp-extract-glue-role-us-{env_key}"
role_session_name = "airflow_session"
aws_access_key_id, aws_secret_access_key, aws_session_token = assume_role(
    role_arn, role_session_name
)

aws_conn_id = "dynamic_aws_conn"
region_name = "us-east-1"

create_aws_connection(
    aws_conn_id,
    aws_access_key_id,
    aws_secret_access_key,
    aws_session_token,
    region_name,
)

# Define the Glue job run step
job_run = GlueJobOperator(
    task_id="job_run",
    job_name=f"grsi-dp-datalake-incremental-{env_key}",
    job_desc="trigger incremental extract from data lake",
    region_name="us-east-1",
    iam_role_name=f"grsi-dp-extract-glue-role-us-{env_key}",
    num_of_dpus=1,
    aws_conn_id=aws_conn_id,
    dag=dag,
)

# Define the task order
job_run
