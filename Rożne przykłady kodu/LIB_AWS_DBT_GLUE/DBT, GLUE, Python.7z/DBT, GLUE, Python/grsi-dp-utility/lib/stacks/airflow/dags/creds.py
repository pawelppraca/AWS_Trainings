import boto3
import json

from airflow.hooks.base import BaseHook
from airflow.models import Connection
from airflow import settings


def create_aws_connection(
    conn_id, aws_access_key_id, aws_secret_access_key, aws_session_token, region_name
):
    conn = Connection(
        conn_id=conn_id,
        conn_type="aws",
        login=aws_access_key_id,
        password=aws_secret_access_key,
        extra=json.dumps(
            {"aws_session_token": aws_session_token, "region_name": region_name}
        ),
    )
    session = settings.Session()
    existing_conn = (
        session.query(Connection).filter(Connection.conn_id == conn_id).first()
    )
    if existing_conn:
        session.delete(existing_conn)
        session.commit()
    session.add(conn)
    session.commit()


# Perform STS assume role call
def assume_role(role_arn, role_session_name):
    client = boto3.client("sts")
    response = client.assume_role(RoleArn=role_arn, RoleSessionName=role_session_name)
    credentials = response["Credentials"]
    return (
        credentials["AccessKeyId"],
        credentials["SecretAccessKey"],
        credentials["SessionToken"],
    )


def get_aws_credentials(aws_conn_id):
    connection = BaseHook.get_connection(aws_conn_id)
    extras = connection.extra_dejson
    return {
        "aws_access_key_id": connection.login,
        "aws_secret_access_key": connection.password,
        "aws_session_token": extras.get("aws_session_token"),
    }
