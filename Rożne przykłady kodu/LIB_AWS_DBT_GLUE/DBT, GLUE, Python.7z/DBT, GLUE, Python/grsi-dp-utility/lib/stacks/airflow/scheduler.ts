/* eslint-disable */
import { Aws, aws_elasticloadbalancingv2, Fn, CfnOutput, Tags } from 'aws-cdk-lib';
import {
    config,
    ISecureStringParameterProperties,
    SecureStringParameter,
    SecureStringParameterTier,
    vpc,
} from '@lmig/grsi-dp-shared-config-and-classes';
import { Construct } from 'constructs';
import { StackConfiguration } from '../../../bin/config';
import { SecurityGroup, Subnet, SubnetSelection } from 'aws-cdk-lib/aws-ec2';
import { NetworkLoadBalancedFargateService } from 'aws-cdk-lib/aws-ecs-patterns';
import { StringParameter } from 'aws-cdk-lib/aws-ssm';
import { AwsSecretsManagerCustomResource, CnameCustomResource, SecretPapiCustomResource } from '@lmig/swa-cdk-core';
import { Role } from 'aws-cdk-lib/aws-iam';
import {
    Cluster,
    ContainerImage,
    FargateTaskDefinition,
    LogDrivers,
    Protocol,
    Secret as EcsSecret,
    Volume,
} from 'aws-cdk-lib/aws-ecs';
import { AccessPoint, FileSystem } from 'aws-cdk-lib/aws-efs';
import * as logs from 'aws-cdk-lib/aws-logs';
import { Key } from 'aws-cdk-lib/aws-kms';
import * as crypto from 'crypto';
import { NetworkLoadBalancer } from 'aws-cdk-lib/aws-elasticloadbalancingv2';
import { Secret } from 'aws-cdk-lib/aws-secretsmanager';

export class AirflowSchedulerResources extends Construct {
    // eslint-disable-next-line  @typescript-eslint/no-unused-vars
    constructor(scope: Construct, id: string, stackConfig: StackConfiguration) {
        super(scope, id);

        const ElbSubnetId = stackConfig.elbSubnets[stackConfig.environmentKey];

        const kmsKey = Key.fromKeyArn(
            this,
            'KmsLookup',
            Fn.importValue(`${config.grsiPrefix}-rds-key-${config.regionEnv}`),
        );

        const airflowSchedulerHealthCheckPort: number = 80;
        const airflowSchedulerPort: number = 81;
        // It's normally 8974 but DO NOT TOUCH THIS! as there's likely a liberty firewall rule
        // that was nuking all the requests and the NLB healthchecks will fail, ripping down the
        // scheduler service

        const dagDirectory: string = `${stackConfig.airflowSharedDirectory}/dags`;
        const logDirectory: string = `${stackConfig.airflowSharedDirectory}/logs`;

        const clusterResourceID = Fn.importValue(
            `${config.grsiPrefix}-airflow-backend-rds-resource-id-${config.regionEnv}`,
        );

        const airflowUsername = Fn.importValue(`${config.grsiPrefix}-airflow-application-username-${config.regionEnv}`);
        const rdsAirflowDbUserArn: string = `arn:aws:rds-db:${Aws.REGION}:${Aws.ACCOUNT_ID}:dbuser:${clusterResourceID}/${airflowUsername}`;

        const databaseHost = Fn.importValue(`${config.grsiPrefix}-airflow-backend-rds-host-${config.regionEnv}`);
        const databaseName = Fn.importValue(
            `${config.grsiPrefix}-airflow-backend-rds-database-name-${config.regionEnv}`,
        );

        const sqlAlchemyConnectionString: string = [
            'postgresql+psycopg2rdsiam://',
            airflowUsername,
            '@',
            databaseHost,
            '/',
            databaseName,
            '?rds_sslrootcert=true&sslmode=verify-full',
        ].join('');

        const airflowTaskRole = Role.fromRoleName(
            this,
            'airflowTaskRole',
            `${config.grsiPrefix}-airflow-task-role-${config.regionEnv}`,
        );

        const vpcSubnetGroup = config.subnetMapping[config.environmentKey][config.regionCode.toUpperCase()];
        const vpcLookup = new vpc(this, 'VpcLookup', vpcSubnetGroup);

        const cluster = Cluster.fromClusterAttributes(this, 'lookupCluster', {
            clusterName: config.ecsClusterName,
            vpc: vpcLookup.ivpc,
        });

        const airflowSecurityGroupID = Fn.importValue(
            `${config.grsiPrefix}-airflow-SecurityGroup-id-${config.regionEnv}`,
        );
        const airflowSecurityGroup = SecurityGroup.fromSecurityGroupId(
            this,
            'airflowSecurityGroup',
            airflowSecurityGroupID,
            {},
        );

        const efsDagBagID = Fn.importValue(`${config.grsiPrefix}-airflow-efsDagBag-id-${config.regionEnv}`);

        const efsDagBag = FileSystem.fromFileSystemAttributes(this, 'efsDagBag', {
            fileSystemId: efsDagBagID,
            securityGroup: airflowSecurityGroup,
        });

        const efsAccessPointID = Fn.importValue(`${config.grsiPrefix}-airflow-efsAccessPoint-id-${config.regionEnv}`);
        const efsAccessPoint = AccessPoint.fromAccessPointId(this, 'efsAccessPoint', efsAccessPointID);

        const dagBagVolume: Volume = {
            name: 'dagBag',
            efsVolumeConfiguration: {
                fileSystemId: efsDagBag.fileSystemId,
                transitEncryption: 'ENABLED',
                authorizationConfig: {
                    accessPointId: efsAccessPoint.accessPointId,
                    iam: 'ENABLED',
                },
            },
        };

        //////
        // TLS/SSL
        //////

        // Get Private key for Airflow TLS
        const airflowTLSKeySecretName: string = `airflow-certificate-key-${config.regionEnv}`;
        const privateKeySecretKey: string = 'private-key';

        // Get TLS Private Key for SSL
        const airflowTLSKeyDetails = new SecretPapiCustomResource(this, 'getTlsKeyClientDetails', {
            action: 'get',
            papiIndex: stackConfig.secrets.papiIndex,
            secretType: 'generic',
            updateOnDeployment: true,
            vaultToken: stackConfig.secrets.vaultToken,
            secretData: {
                [airflowTLSKeySecretName]: [privateKeySecretKey],
            },
        });

        // Parse the response from above
        const airflowTLSPrivateKey: string = airflowTLSKeyDetails
            .getAtt(`${airflowTLSKeySecretName}.${privateKeySecretKey}`)
            .toString();

        const tlsKeyParamName: string = `${config.grsiPrefix}-airflow-tls-${config.regionEnv}`;

        // Create a SecureString Parameter to pass the private key to the container securely
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const tlsKeyParam: SecureStringParameter = new SecureStringParameter(this, 'createTlsParam', <
            ISecureStringParameterProperties
            >{
                secureValue: airflowTLSPrivateKey,
                parameterName: tlsKeyParamName,
                parameterTier: SecureStringParameterTier.STANDARD,
                paramTags: config.stackTags,
                encryptionKey: kmsKey,
            });
        tlsKeyParam.node.addDependency(airflowTLSKeyDetails);

        const tlsPrivateKey = EcsSecret.fromSsmParameter(
            StringParameter.fromSecureStringParameterAttributes(this, 'getTlsKeyParam', {
                parameterName: tlsKeyParamName,
                encryptionKey: kmsKey,
            }),
        );

        ////
        // Airflow tasks
        ///

        // Scheduler
        const airflowSchedulerTaskDefinition = new FargateTaskDefinition(this, 'airflowSchedulerTaskDefinition', {
            cpu: 4096,
            memoryLimitMiB: 8192,
            taskRole: airflowTaskRole,
            executionRole: airflowTaskRole,
            family: `${config.grsiPrefix}-airflow-scheduler-${config.regionEnv}`,
        });
        airflowSchedulerTaskDefinition.addVolume(dagBagVolume);

        const airflowAdminPwd = crypto.randomBytes(256).toString('hex');

        new SecretPapiCustomResource(this, 'grsi-dp-airflow-admin-pwd-to-vault', {
            action: 'store',
            secretType: 'generic',
            replaceSecretIfExists: true,
            updateOnDeployment: true,
            secretData: {
                [`${config.grsiPrefix}-airflow-admin-${config.regionEnv}`]: {
                    'admin-password': airflowAdminPwd,
                },
            },
        });

        const hashedPwd = hashPwd(airflowAdminPwd);

        const dbHost = Fn.importValue(`${config.grsiPrefix}-airflow-backend-rds-host-${config.regionEnv}`);
        const dbPort = Fn.importValue(`${config.grsiPrefix}-airflow-backend-rds-port-${config.regionEnv}`);
        const dbName = Fn.importValue(`${config.grsiPrefix}-airflow-backend-rds-database-name-${config.regionEnv}`);

        const storeAwsSecret = new AwsSecretsManagerCustomResource(this, 'StoreAwsSecret', {
            targetKeyId: kmsKey.keyId,
            secretName: `grsi-dp-dbt-airflow-secret-${config.regionEnv}`,
            accessForPrincipalArns: [airflowTaskRole.roleArn],
            secretDescription: 'credentials to access redshift cluster',
            secretsToStore: 'all',
        });

        const dbtSecret = Secret.fromSecretCompleteArn(this, 'DbtSecret', storeAwsSecret.secretArn());
        const secretKeyEU = `grsi-dp-redshift-eu-${stackConfig.environmentKey}`;
        const secretKeyUS = `grsi-dp-redshift-us-${stackConfig.environmentKey}`;
        const secretKeyAP = `grsi-dp-redshift-ap-${stackConfig.environmentKey}`;
        const accessType = 'deploy';

        const airflowSchedulerContainer = airflowSchedulerTaskDefinition.addContainer('airflowContainerImage', {
            image: ContainerImage.fromRegistry(stackConfig.airflowImageLmigRegistryAddress),
            logging: LogDrivers.awsLogs({
                streamPrefix: `${config.grsiPrefix}/airflow-scheduler/`,
                logRetention: logs.RetentionDays.ONE_WEEK,
            }),
            secrets: {
                TLS_PRIVATE_KEY: tlsPrivateKey,
                DB_HOST_EU: EcsSecret.fromSecretsManager(dbtSecret, `${secretKeyEU}.${accessType}.host`),
                DB_PORT_EU: EcsSecret.fromSecretsManager(dbtSecret, `${secretKeyEU}.${accessType}.port`),
                DB_NAME_EU: EcsSecret.fromSecretsManager(dbtSecret, `${secretKeyEU}.${accessType}.database_name`),
                DB_HOST_US: EcsSecret.fromSecretsManager(dbtSecret, `${secretKeyUS}.${accessType}.host`),
                DB_PORT_US: EcsSecret.fromSecretsManager(dbtSecret, `${secretKeyUS}.${accessType}.port`),
                DB_NAME_US: EcsSecret.fromSecretsManager(dbtSecret, `${secretKeyUS}.${accessType}.database_name`),
                DB_HOST_AP: EcsSecret.fromSecretsManager(dbtSecret, `${secretKeyAP}.${accessType}.host`),
                DB_PORT_AP: EcsSecret.fromSecretsManager(dbtSecret, `${secretKeyAP}.${accessType}.port`),
                DB_NAME_AP: EcsSecret.fromSecretsManager(dbtSecret, `${secretKeyAP}.${accessType}.database_name`),
            },
            environment: {
                TASK_TYPE: 'SCHEDULER',
                AWS_REGION: Aws.REGION,
                AIRFLOW__SCHEDULER__ENABLE_HEALTH_CHECK: 'True',
                AIRFLOW__LOGGING__WORKER_LOG_SERVER_PORT: String(airflowSchedulerPort),
                AIRFLOW__SCHEDULER__SCHEDULER_HEALTH_CHECK_SERVER_PORT: String(airflowSchedulerHealthCheckPort),
                AIRFLOW__DATABASE__SQL_ALCHEMY_CONN: sqlAlchemyConnectionString,
                AIRFLOW__CORE__DAGS_FOLDER: dagDirectory,
                AIRFLOW__CORE__BASE_LOG_FOLDER: logDirectory,
                AIRFLOW__CORE__EXECUTOR: 'LocalExecutor',
                AIRFLOW_ADMIN_PWD: hashedPwd,
                PGHOST: dbHost,
                PGPORT: dbPort,
                PGUSER: 'airflow',
                PGDATABASE: dbName,
                ENVIRONMENT_KEY: config.environmentKey,
                ACCOUNT_NUMBER_EU: config.accountNumbers[config.environmentKey].EU,
                ACCOUNT_NUMBER_US: config.accountNumbers[config.environmentKey].US,
                ACCOUNT_NUMBER_AP: config.accountNumbers[config.environmentKey].AP,
                DEBUG: 'false',
            },
            // To allow non-root user to bind to port 80, they must be opened. Fargate does not support the linux
            // parameter NET_BIND_SERVICE at this time.
            systemControls: [
                {
                    namespace: 'net.ipv4.ip_unprivileged_port_start',
                    value: '0',
                },
            ],
        });

        airflowSchedulerContainer.addPortMappings({
            containerPort: airflowSchedulerPort,
            protocol: Protocol.TCP,
        });

        airflowSchedulerContainer.addPortMappings({
            containerPort: 81,
            protocol: Protocol.TCP,
        });

        airflowSchedulerContainer.addPortMappings({
            containerPort: airflowSchedulerHealthCheckPort,
            protocol: Protocol.TCP,
        });

        airflowSchedulerContainer.addMountPoints({
            readOnly: false,
            containerPath: stackConfig.airflowSharedDirectory,
            sourceVolume: dagBagVolume.name,
        });

        airflowSchedulerTaskDefinition.obtainExecutionRole();

        const schedulerNlb = new NetworkLoadBalancer(this, 'airflowSchedulerNlb', {
            vpc: vpcLookup.ivpc,
            deletionProtection: false,
            vpcSubnets: {
                subnets: [Subnet.fromSubnetId(this, 'schedulerNLBSubnet', ElbSubnetId)],
            },
        });
        Tags.of(schedulerNlb).add('nlb_passthrough', 'true');

        const airflowSchedulerNlbService = new NetworkLoadBalancedFargateService(
            this,
            'airflowSchedulerAlbFargateService',
            {
                cluster: cluster,
                loadBalancer: schedulerNlb,
                publicLoadBalancer: false,
                assignPublicIp: false,
                listenerPort: airflowSchedulerPort,
                circuitBreaker: {
                    enable: true,
                    rollback: true,
                },
                desiredCount: 1,
                securityGroups: [airflowSecurityGroup],
                serviceName: `${config.grsiPrefix}-airflow-scheduler-${config.regionEnv}`,
                taskDefinition: airflowSchedulerTaskDefinition,
            },
        );

        airflowSchedulerNlbService.targetGroup.configureHealthCheck({
            path: '/health',
            port: String(airflowSchedulerHealthCheckPort),
            protocol: aws_elasticloadbalancingv2.Protocol.HTTP,
        });

        const targetGroup = airflowSchedulerNlbService.targetGroup.node
            .defaultChild as aws_elasticloadbalancingv2.CfnTargetGroup;
        targetGroup.addPropertyOverride('Port', 8974);
        Tags.of(targetGroup).add('nlb_passthrough', 'true');

        airflowSchedulerNlbService.node.addDependency(airflowSchedulerTaskDefinition);
        airflowSchedulerNlbService.node.addDependency(airflowSecurityGroup);

        const schedulerCName: string = `scheduler.${stackConfig.environmentKey}.zeus.lmig.com`;

        new CnameCustomResource(this, `schedulerCNameRecord`, {
            cNAME: schedulerCName,
            dnsName: airflowSchedulerNlbService.loadBalancer.loadBalancerDnsName,
            updateOnDeployment: true,
        });

        new CfnOutput(this, 'airflowSchedulerCnameOutput', {
            exportName: `${config.grsiPrefix}-airflow-scheduler-cName-dns-record-${config.regionEnv}`,
            value: schedulerCName,
        });
    }
}

function hashPwd(pwd: string) {
    const saltLength = 16; // Translates to a length of 32 when hex encoded
    const salt = crypto.randomBytes(saltLength).toString('hex');
    const iterations = 260000;
    const keylen = 32; // Translates to a length of 64 when hex encoded
    const digest = 'sha256';
    const hash = crypto.pbkdf2Sync(pwd, salt, iterations, keylen, digest);
    const encodedHash = hash.toString('hex');
    return `pbkdf2:${digest}:${iterations}$${salt}$${encodedHash}`;
}
