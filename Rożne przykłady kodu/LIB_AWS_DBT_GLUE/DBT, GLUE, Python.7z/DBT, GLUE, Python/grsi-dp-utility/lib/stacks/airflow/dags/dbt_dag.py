import os

import boto3
from airflow import DAG
from airflow.decorators import task
from airflow.utils.log.secrets_masker import mask_secret
from datetime import datetime, timedelta
from creds import create_aws_connection, assume_role, get_aws_credentials

env_key = os.environ["ENVIRONMENT_KEY"]
deployed_region = os.environ["AWS_REGION"][:2]
regions = {
    "EU": {"region": "eu-west-1", "account": os.environ["ACCOUNT_NUMBER_EU"]},
    "US": {"region": "us-east-1", "account": os.environ["ACCOUNT_NUMBER_US"]},
    "AP": {"region": "ap-southeast-2", "account": os.environ["ACCOUNT_NUMBER_AP"]},
}
warehouse_tables = [
    "risk",
    "broker",
    "coverage",
    "geography",
]

dbt_bucket_name = f"grsi-dp-dbt-{deployed_region}-{env_key}"

default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 0,
    "retry_delay": timedelta(minutes=5),
}

with DAG(
    "dbt_dag",
    default_args=default_args,
    description="DAG to trigger dbt run",
    schedule_interval=None,
    start_date=datetime(2025, 1, 1),
    params={"EU": True, "US": True, "AP": True},
    catchup=False,
) as dag:

    @task
    def get_enabled_regions(**context):
        return [key for key in context["params"] if context["params"][key]]

    @task
    def assume_role_and_get_env_variables(region):
        mask_secret("aws_secret_access_key")
        mask_secret("aws_session_token")
        role_arn = f"arn:aws:iam::{regions[region]['account']}:role/grsi-dp-redshift-role-{region.lower()}-{env_key}"
        aws_access_key_id, aws_secret_access_key, aws_session_token = assume_role(
            role_arn, role_session_name=f"airflow_session_{region}"
        )
        aws_conn_id = f"dynamic_aws_conn_{region}"
        create_aws_connection(
            conn_id=aws_conn_id,
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
            aws_session_token=aws_session_token,
            region_name=regions[region]["region"],
        )
        return {
            "aws_conn_id": aws_conn_id,
            "host": os.environ[f"DB_HOST_{region.upper()}"],
            "name": os.environ[f"DB_NAME_{region.upper()}"],
            "port": os.environ[f"DB_PORT_{region.upper()}"],
            "region": regions[region]["region"],
            "region_code": region,
        }

    @task.bash
    def run_dbt(dbt_env_vars):
        mask_secret("aws_secret_access_key")
        mask_secret("aws_session_token")
        aws_credentials = get_aws_credentials(dbt_env_vars["aws_conn_id"])
        region_code = dbt_env_vars["region_code"]
        return f"""
        aws s3 cp s3://{dbt_bucket_name}/ . --recursive
        export AWS_ACCESS_KEY_ID={aws_credentials["aws_access_key_id"]}
        export AWS_SECRET_ACCESS_KEY={aws_credentials["aws_secret_access_key"]}
        export AWS_SESSION_TOKEN={aws_credentials["aws_session_token"]}
        export DB_HOST={dbt_env_vars["host"]}
        export DB_NAME={dbt_env_vars["name"]}
        export DB_PORT={dbt_env_vars["port"]}
        export REDSHIFT_CLUSTER_ID=grsi-dp-redshift-{region_code.lower()}-{env_key}
        export REGION={dbt_env_vars["region"]}
        export ENVIRONMENT={env_key}
        dbt deps --project-dir grsi_dp_dwh
        echo "STARTING DBT RUN IN {region_code}"
        dbt seed --project-dir grsi_dp_dwh && dbt run --full-refresh --project-dir grsi_dp_dwh --exclude "datashare_test" grsi_dp_dwh.reconciliation
        """

    @task.bash
    def run_reconciliations(dbt_env_vars, model):
        mask_secret("aws_secret_access_key")
        mask_secret("aws_session_token")
        aws_credentials = get_aws_credentials(dbt_env_vars["aws_conn_id"])
        region_code = dbt_env_vars["region_code"]
        return f"""
        aws s3 cp s3://{dbt_bucket_name}/ . --recursive
        export AWS_ACCESS_KEY_ID={aws_credentials["aws_access_key_id"]}
        export AWS_SECRET_ACCESS_KEY={aws_credentials["aws_secret_access_key"]}
        export AWS_SESSION_TOKEN={aws_credentials["aws_session_token"]}
        export DB_HOST={dbt_env_vars["host"]}
        export DB_NAME={dbt_env_vars["name"]}
        export DB_PORT={dbt_env_vars["port"]}
        export REDSHIFT_CLUSTER_ID=grsi-dp-redshift-{region_code.lower()}-{env_key}
        export REGION={dbt_env_vars["region"]}
        export ENVIRONMENT={env_key}
        dbt deps --project-dir grsi_dp_dwh
        echo "STARTING RECONCILIATIONS IN {region_code} FOR {model}"
        dbt test -s {model} --project-dir grsi_dp_dwh
        dbt run -s tag:recon_{model} --project-dir grsi_dp_dwh
        """

    enabled_regions = get_enabled_regions()
    env_vars = assume_role_and_get_env_variables.expand(region=enabled_regions)
    run_dbt_task = run_dbt.expand(dbt_env_vars=env_vars)

    for table in warehouse_tables:
        reconciliations = (
            run_reconciliations.override(task_id=f"{table}_reconciliation")
            .partial(model=table)
            .expand(dbt_env_vars=env_vars)
        )
        env_vars >> reconciliations
        run_dbt_task >> reconciliations

    env_vars >> run_dbt_task
