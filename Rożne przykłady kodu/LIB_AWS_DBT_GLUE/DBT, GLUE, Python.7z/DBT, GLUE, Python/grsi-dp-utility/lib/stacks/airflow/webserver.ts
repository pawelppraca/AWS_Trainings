/* eslint-disable */
import { Aws, aws_elasticloadbalancingv2, Fn, Tags } from 'aws-cdk-lib';
import { config, vpc } from '@lmig/grsi-dp-shared-config-and-classes';
import { Construct } from 'constructs';
import { StackConfiguration } from '../../../bin/config';
import { SecurityGroup, Subnet } from 'aws-cdk-lib/aws-ec2';
import { NetworkLoadBalancedFargateService } from 'aws-cdk-lib/aws-ecs-patterns';
import { StringParameter } from 'aws-cdk-lib/aws-ssm';
import { CnameCustomResource, SecretPapiCustomResource } from '@lmig/swa-cdk-core';
import { Role } from 'aws-cdk-lib/aws-iam';
import {
    Cluster,
    ContainerImage,
    FargateTaskDefinition,
    LogDrivers,
    Protocol,
    Secret,
    Volume,
} from 'aws-cdk-lib/aws-ecs';
import { AccessPoint, FileSystem } from 'aws-cdk-lib/aws-efs';
import * as logs from 'aws-cdk-lib/aws-logs';
import { Key } from 'aws-cdk-lib/aws-kms';
import { NetworkLoadBalancer } from 'aws-cdk-lib/aws-elasticloadbalancingv2';

export class AirflowWebserverResources extends Construct {
    // eslint-disable-next-line  @typescript-eslint/no-unused-vars
    constructor(scope: Construct, id: string, stackConfig: StackConfiguration) {
        super(scope, id);

        const ElbSubnetId = stackConfig.elbSubnets[stackConfig.environmentKey];

        const kmsKey = Key.fromKeyArn(
            this,
            'KmsLookup',
            Fn.importValue(`${config.grsiPrefix}-rds-key-${config.regionEnv}`),
        );

        const airflowSchedulerPort: number = 81;
        const tlsPort: number = 443;

        const dagDirectory: string = `${stackConfig.airflowSharedDirectory}/dags`;
        const logDirectory: string = `${stackConfig.airflowSharedDirectory}/logs`;

        const airflowUsername = Fn.importValue(`${config.grsiPrefix}-airflow-application-username-${config.regionEnv}`);
        const databaseHost = Fn.importValue(`${config.grsiPrefix}-airflow-backend-rds-host-${config.regionEnv}`);
        const databaseName = Fn.importValue(
            `${config.grsiPrefix}-airflow-backend-rds-database-name-${config.regionEnv}`,
        );

        const sqlAlchemyConnectionString: string = [
            'postgresql+psycopg2rdsiam://',
            airflowUsername,
            '@',
            databaseHost,
            '/',
            databaseName,
            '?rds_sslrootcert=true&sslmode=verify-full',
        ].join('');

        const airflowTaskRole = Role.fromRoleName(
            this,
            'airflowTaskRole',
            `${config.grsiPrefix}-airflow-task-role-${config.regionEnv}`,
        );

        const vpcSubnetGroup = config.subnetMapping[config.environmentKey][config.regionCode.toUpperCase()];
        const vpcLookup = new vpc(this, 'VpcLookup', vpcSubnetGroup);

        const cluster = Cluster.fromClusterAttributes(this, 'lookupCluster', {
            clusterName: config.ecsClusterName,
            vpc: vpcLookup.ivpc,
        });

        const airflowSecurityGroupID = Fn.importValue(
            `${config.grsiPrefix}-airflow-SecurityGroup-id-${config.regionEnv}`,
        );
        const airflowSecurityGroup = SecurityGroup.fromSecurityGroupId(
            this,
            'airflowSecurityGroup',
            airflowSecurityGroupID,
            {},
        );

        const efsDagBagID = Fn.importValue(`${config.grsiPrefix}-airflow-efsDagBag-id-${config.regionEnv}`);

        const efsDagBag = FileSystem.fromFileSystemAttributes(this, 'efsDagBag', {
            fileSystemId: efsDagBagID,
            securityGroup: airflowSecurityGroup,
        });

        const efsAccessPointID = Fn.importValue(`${config.grsiPrefix}-airflow-efsAccessPoint-id-${config.regionEnv}`);
        const efsAccessPoint = AccessPoint.fromAccessPointId(this, 'efsAccessPoint', efsAccessPointID);

        const dagBagVolume: Volume = {
            name: 'dagBag',
            efsVolumeConfiguration: {
                fileSystemId: efsDagBag.fileSystemId,
                transitEncryption: 'ENABLED',
                authorizationConfig: {
                    accessPointId: efsAccessPoint.accessPointId,
                    iam: 'ENABLED',
                },
            },
        };

        //////
        // SSO
        //////
        const airflowIdpSecretName: string = 'airflow-idp';
        const clientIdSecretKey: string = 'id';

        // Get client ID for SSO
        const airflowIdpClientDetails = new SecretPapiCustomResource(this, 'getSsoClientDetails', {
            action: 'get',
            papiIndex: stackConfig.secrets.papiIndex,
            secretType: 'generic',
            updateOnDeployment: true,
            vaultToken: stackConfig.secrets.vaultToken,
            secretData: {
                [airflowIdpSecretName]: [clientIdSecretKey],
            },
        });

        // Parse the response from above
        const airflowSsoClientId: string = airflowIdpClientDetails
            .getAtt(`${airflowIdpSecretName}.${clientIdSecretKey}`)
            .toString();

        const tlsKeyParamName: string = `${config.grsiPrefix}-airflow-tls-${config.regionEnv}`;

        const tlsPrivateKey = Secret.fromSsmParameter(
            StringParameter.fromSecureStringParameterAttributes(this, 'getTlsKeyParam', {
                parameterName: tlsKeyParamName,
                encryptionKey: kmsKey,
            }),
        );

        ////
        // Airflow tasks
        ///

        // Webserver
        const airflowWebserverTaskDefinition = new FargateTaskDefinition(this, 'airflowWebserverTaskDefinition', {
            cpu: 4096,
            memoryLimitMiB: 8192,
            taskRole: airflowTaskRole,
            family: `${config.grsiPrefix}-airflow-webserver-${config.regionEnv}`,
        });

        airflowWebserverTaskDefinition.addVolume(dagBagVolume);

        const schedulerCName: string = Fn.importValue(
            `${config.grsiPrefix}-airflow-scheduler-cName-dns-record-${config.regionEnv}`,
        );
        // const schedulerCName: string = `http://scheduler.${stackConfig.environmentKey}.zeus.lmig.com:8793`;
        const schedulerHost: string = `http://${schedulerCName}`;

        const airflowWebserverContainer = airflowWebserverTaskDefinition.addContainer('airflowContainerImage', {
            image: ContainerImage.fromRegistry(stackConfig.airflowImageLmigRegistryAddress),
            logging: LogDrivers.awsLogs({
                streamPrefix: `${config.grsiPrefix}/airflow-webserver/`,
                logRetention: logs.RetentionDays.ONE_WEEK,
            }),
            secrets: {
                TLS_PRIVATE_KEY: tlsPrivateKey,
            },
            environment: {
                TASK_TYPE: 'WEBSERVER',
                AWS_REGION: Aws.REGION,
                AIRFLOW__DATABASE__SQL_ALCHEMY_CONN: sqlAlchemyConnectionString,
                AIRFLOW__CORE__DAGS_FOLDER: dagDirectory,
                AIRFLOW__CORE__BASE_LOG_FOLDER: logDirectory,
                AIRFLOW__WEBSERVER__WORKERS: '2',
                AIRFLOW__CORE__EXECUTOR: 'LocalExecutor',
                AIRFLOW__LOGGING__WORKER_LOG_SERVER_PORT: String(airflowSchedulerPort),
                ENVIRONMENT_KEY: config.environmentKey,
                DEBUG: 'false',
                // Variables for SSO
                CLIENT_ID: airflowSsoClientId,
            },
            // To allow non-root user to bind to port 80, they must be opened. Fargate does not support the linux
            // parameter NET_BIND_SERVICE at this time.
            systemControls: [
                {
                    namespace: 'net.ipv4.ip_unprivileged_port_start',
                    value: '0',
                },
            ],
        });

        airflowWebserverContainer.addPortMappings({
            containerPort: tlsPort,
            protocol: Protocol.TCP,
        });

        airflowWebserverContainer.addPortMappings({
            containerPort: airflowSchedulerPort,
            protocol: Protocol.TCP,
        });

        airflowWebserverContainer.addMountPoints({
            readOnly: false,
            containerPath: stackConfig.airflowSharedDirectory,
            sourceVolume: dagBagVolume.name,
        });

        airflowWebserverTaskDefinition.obtainExecutionRole();

        const webserverNlb = new NetworkLoadBalancer(this, 'airflowWebserverNlb', {
            vpc: vpcLookup.ivpc,
            deletionProtection: false,
            vpcSubnets: {
                subnets: [Subnet.fromSubnetId(this, 'webserverNLBSubnet', ElbSubnetId)],
            },

        });
        Tags.of(webserverNlb).add('nlb_passthrough', 'true');

        const airflowNlbService = new NetworkLoadBalancedFargateService(this, 'airflowWebserverAlbFargateService', {
            cluster: cluster,
            loadBalancer: webserverNlb,
            publicLoadBalancer: false,
            assignPublicIp: false,
            listenerPort: tlsPort,
            circuitBreaker: {
                enable: true,
                rollback: true,
            },
            desiredCount: 1,
            securityGroups: [airflowSecurityGroup],
            serviceName: `${config.grsiPrefix}-airflow-webserver-${config.regionEnv}`,
            taskDefinition: airflowWebserverTaskDefinition,
        });

        const targetGroup = airflowNlbService.targetGroup.node
            .defaultChild as aws_elasticloadbalancingv2.CfnTargetGroup;
        Tags.of(targetGroup).add('nlb_passthrough', 'true');

        airflowNlbService.node.addDependency(airflowWebserverTaskDefinition);
        airflowNlbService.node.addDependency(airflowSecurityGroup);

        // Set our CNames so Airflow is accessible via nice domains
        const airflowDesiredCNames: string[] = [`${stackConfig.environmentKey}.zeus.lmig.com`];

        // If it's production, add an extra special one without a prefix.
        if (stackConfig.environmentKey == 'production') {
            airflowDesiredCNames.push('zeus.lmig.com');
        }

        for (const desiredCName of airflowDesiredCNames) {
            new CnameCustomResource(this, `createCNameRecord-${desiredCName}`, {
                cNAME: desiredCName,
                dnsName: airflowNlbService.loadBalancer.loadBalancerDnsName,
                updateOnDeployment: true,
            });
        }
    }
}
