import os

import boto3
from airflow import DAG
from airflow.decorators import task
from datetime import datetime, timedelta

env_key = os.environ["ENVIRONMENT_KEY"]
region = os.environ["AWS_REGION"]
crawler_name = f"grsi-dp-bilz-crawler-{env_key}"

default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

with DAG(
    "trigger_bilz_dag",
    default_args=default_args,
    description="DAG to trigger bilz crawler",
    schedule_interval=None,
    start_date=datetime(2025, 1, 1),
    catchup=False,
) as dag:

    @task
    def start_bilz_crawler():
        client = boto3.client("glue", region)
        client.start_crawler(Name=crawler_name)

    start_crawler = start_bilz_crawler()
