import { CdkCustomResourceEvent, CdkCustomResourceResponse, Context } from 'aws-lambda';
import { Client, ClientConfig } from 'pg';

export const handler = async (event: CdkCustomResourceEvent, context: Context): Promise<CdkCustomResourceResponse> => {
    console.info('Object Created Context:', JSON.stringify(context));

    const databaseHost = event.ResourceProperties.databaseHost as string;
    const databasePort = event.ResourceProperties.databasePort as number;
    const databaseUser = event.ResourceProperties.databaseUser as string;
    const databasePassphrase = event.ResourceProperties.databasePassphrase as string;
    const databaseName = event.ResourceProperties.databaseName as string;
    const airflowApplicationUserName = event.ResourceProperties.airflowApplicationUserName as string;
    const physicalResourceId = 'grsi-dp-airflow-database-backend-pg-user';

    try {
        const pgClientParams: ClientConfig = {
            host: databaseHost,
            port: databasePort,
            user: databaseUser,
            database: databaseName,
            password: databasePassphrase,
            ssl: true,
        };

        const client = new Client(pgClientParams);
        await client.connect();

        const createUserIfNotExists: string = [
            `DO $$`,
            `BEGIN`,
            `CREATE USER ${airflowApplicationUserName};`,
            `EXCEPTION WHEN duplicate_object THEN RAISE NOTICE '%, skipping', SQLERRM USING ERRCODE = SQLSTATE;`,
            `END`,
            `$$;`,
        ].join('\r\n');

        const grantRdsIam: string = `GRANT RDS_IAM TO ${airflowApplicationUserName}`;
        const grantDatabase: string = `GRANT ALL ON DATABASE ${databaseName} TO ${airflowApplicationUserName}`;
        const grantSchema: string = `GRANT ALL ON SCHEMA PUBLIC TO ${airflowApplicationUserName}`;

        console.log(createUserIfNotExists, await client.query(createUserIfNotExists));
        console.log(grantRdsIam, await client.query(grantRdsIam));
        console.log(grantDatabase, await client.query(grantDatabase));
        console.log(grantSchema, await client.query(grantSchema));

        await client.end();

        return {
            StackId: event.StackId,
            PhysicalResourceId: physicalResourceId,
            LogicalResourceId: event.LogicalResourceId,
            RequestId: event.RequestId,
            Status: 'SUCCESS',
        };
    } catch (e) {
        console.error(e as Error);
        return {
            StackId: event.StackId,
            PhysicalResourceId: physicalResourceId,
            LogicalResourceId: event.LogicalResourceId,
            RequestId: event.RequestId,
            Status: 'FAILED',
            Reason: (e as Error).message,
        };
    }
};
