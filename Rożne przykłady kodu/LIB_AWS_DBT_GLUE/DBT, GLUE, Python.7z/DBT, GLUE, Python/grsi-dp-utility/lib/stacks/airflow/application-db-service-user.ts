import { vpc as vpcLookup, config } from '@lmig/grsi-dp-shared-config-and-classes';
import { StackConfiguration } from '../../../bin/config';
import { Construct } from 'constructs';
import {
    Effect,
    ManagedPolicy,
    PermissionsBoundary,
    PolicyStatement,
    Role,
    ServicePrincipal,
} from 'aws-cdk-lib/aws-iam';
import { Aws, CfnOutput, CustomResource, Duration, RemovalPolicy, Tags } from 'aws-cdk-lib';
import { NodejsFunction } from 'aws-cdk-lib/aws-lambda-nodejs';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as path from 'path';
import { Provider } from 'aws-cdk-lib/custom-resources';
import { SecurityGroup, SubnetType } from 'aws-cdk-lib/aws-ec2';
import * as logs from 'aws-cdk-lib/aws-logs';
import { SecretPapiCustomResource } from '@lmig/swa-cdk-core';

export class AirflowDatabaseUserBackingResources extends Construct {
    static readonly createUserFunctionName: string = `${config.grsiPrefix}-create-airflow-database-user-${config.regionEnv}`;

    constructor(scope: Construct, id: string, stackConfig: StackConfiguration) {
        super(scope, id);

        const vpcSubnetGroup = config.subnetMapping[config.environmentKey][config.regionCode.toUpperCase()];
        const accountVpc = new vpcLookup(this, 'VpcLookup', vpcSubnetGroup);

        const lambdaSecurityGroup = new SecurityGroup(this, 'lambdaSecurityGroup', {
            vpc: accountVpc.ivpc,
        });

        const lambdaRole = new Role(this, 'lambdaRole', {
            roleName: `${stackConfig.artifactKey}-airflow-database-user-role-${stackConfig.regionEnv}`,
            assumedBy: new ServicePrincipal('lambda.amazonaws.com'),
            managedPolicies: [
                ManagedPolicy.fromManagedPolicyArn(
                    this,
                    'getLambdaAttachPolicyArn',
                    'arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole',
                ),
                ManagedPolicy.fromManagedPolicyArn(
                    this,
                    'allowLambdaVpcAccess',
                    'arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole',
                ),
            ],
        });

        const getRdsTokenPolicy = new ManagedPolicy(this, 'getRdsTokenPolicy', {
            managedPolicyName: `${config.grsiPrefix}-airflow-user-custom-resource-${config.regionEnv}`,
            path: '/permission-boundary/',
            statements: [
                new PolicyStatement({
                    effect: Effect.ALLOW,
                    actions: [
                        'ec2:DescribeNetworkInterfaces',
                        'ec2:CreateNetworkInterface',
                        'ec2:DeleteNetworkInterface',
                    ],
                    resources: ['*'],
                }),
                new PolicyStatement({
                    effect: Effect.ALLOW,
                    actions: ['logs:CreateLogGroup', 'logs:CreateLogStream', 'logs:PutLogEvents'],
                    resources: ['*'],
                }),
            ],
        });

        lambdaRole.node.addDependency(getRdsTokenPolicy);
        PermissionsBoundary.of(lambdaRole).apply(getRdsTokenPolicy);
        Tags.of(lambdaRole).add('aws_iam_permission_boundary_exempt', 'CustomAwaitingApproval');

        const lambdaEnvironment = {
            region: Aws.REGION,
            accountId: Aws.ACCOUNT_ID,
            deployment_guid: stackConfig.stackTags.deployment_guid,
            artifact_guid: stackConfig.stackTags.artifactGuid,
            organization_guid: stackConfig.stackTags.organizationGuid,
            lm_troux_uid: stackConfig.stackTags.lm_troux_uid,
        };

        const dataProtectionPolicy = new logs.DataProtectionPolicy({
            name: 'grsi-airflow-backend-custom-resource-backing-protection',
            description: 'Hide the undesireable',
            identifiers: [new logs.CustomDataIdentifier('databasePassphrase', '"databasePassphrase":\\s{0,}\\S{1,}')],
        });

        const crLogGroup = new logs.LogGroup(this, 'grsi-dp-airflow-custom-resource', {
            dataProtectionPolicy: dataProtectionPolicy,
            retention: logs.RetentionDays.FIVE_DAYS,
            removalPolicy: RemovalPolicy.DESTROY,
        });

        const createAirflowUserBackingFunction = new NodejsFunction(this, 'createAirflowUserBackingFunction', {
            functionName: AirflowDatabaseUserBackingResources.createUserFunctionName,
            runtime: lambda.Runtime.NODEJS_18_X,
            memorySize: 512,
            timeout: Duration.minutes(5),
            entry: path.join(__dirname, 'create-db-user/index.ts'),
            environment: lambdaEnvironment,
            role: lambdaRole,
            vpc: accountVpc.ivpc,
            vpcSubnets: accountVpc.ivpc.selectSubnets({
                subnetType: SubnetType.PRIVATE_WITH_EGRESS,
            }),
            securityGroups: [lambdaSecurityGroup],
            logGroup: crLogGroup,
        });
        createAirflowUserBackingFunction.node.addDependency(lambdaRole, lambdaSecurityGroup);
    }
}

export class AirflowDatabaseUserDeploymentResources extends Construct {
    static readonly airflowApplicationUserName: string = `airflow`;
    // eslint-disable-next-line  @typescript-eslint/no-unused-vars
    constructor(scope: Construct, id: string, stackConfig: StackConfiguration) {
        super(scope, id);

        const createAirflowUserBackingFunction = lambda.Function.fromFunctionAttributes(
            this,
            'external-lambda-from-arn',
            {
                functionArn: `arn:aws:lambda:${Aws.REGION}:${Aws.ACCOUNT_ID}:function:${AirflowDatabaseUserBackingResources.createUserFunctionName}`,
                sameEnvironment: true,
            },
        );

        const dataProtectionPolicy = new logs.DataProtectionPolicy({
            name: 'grsi-airflow-rds-backend-custom-resource-protection',
            description: 'Hide the undesireable',
            identifiers: [new logs.CustomDataIdentifier('databasePassphrase', '"databasePassphrase":\\s{0,}\\S{1,}')],
        });

        const crLogGroup = new logs.LogGroup(this, 'grsi-dp-airflow-custom-resource', {
            dataProtectionPolicy: dataProtectionPolicy,
            retention: logs.RetentionDays.ONE_DAY,
            removalPolicy: RemovalPolicy.DESTROY,
        });

        const createAirflowUserProvider = new Provider(this, 'createAirflowUserProvider', {
            onEventHandler: createAirflowUserBackingFunction,
            logGroup: crLogGroup,
        });

        const databaseRegion: string = Aws.REGION;

        const dBInstanceKey = `${config.grsiPrefix}-airflow-postgres-backend-${config.regionEnv}`;

        const papiSqlAlchemyConnectionStringSecret = new SecretPapiCustomResource(
            this,
            'getPapiSqlAlchemyConnectionString',
            {
                action: 'get',
                papiIndex: config.secrets.papiIndex,
                secretType: 'postgresql-dynamic',
                updateOnDeployment: true,
                vaultToken: config.secrets.vaultToken,
                dBInstanceKey: dBInstanceKey,
                access: 'deploy',
            },
        );

        const databaseUser = papiSqlAlchemyConnectionStringSecret.getAtt(`${dBInstanceKey}.deploy.username`).toString();
        const databasePassphrase = papiSqlAlchemyConnectionStringSecret
            .getAtt(`${dBInstanceKey}.deploy.password`)
            .toString();
        const databaseHost = papiSqlAlchemyConnectionStringSecret.getAtt(`${dBInstanceKey}.deploy.host`).toString();
        const databasePort = papiSqlAlchemyConnectionStringSecret.getAtt(`${dBInstanceKey}.deploy.port`).toString();
        const databaseName = papiSqlAlchemyConnectionStringSecret
            .getAtt(`${dBInstanceKey}.deploy.database_name`)
            .toString();

        const createAirflowUserCustomResource = new CustomResource(this, 'createAirflowUserCustomResource', {
            resourceType: 'Custom::CreateAirflowDatabaseUser',
            serviceToken: createAirflowUserProvider.serviceToken,
            properties: {
                databaseUser: databaseUser,
                databasePassphrase: databasePassphrase,
                databaseHost: databaseHost,
                databaseRegion: databaseRegion,
                databasePort: databasePort,
                databaseName: databaseName,
                airflowApplicationUserName: AirflowDatabaseUserDeploymentResources.airflowApplicationUserName,
                _: Date.now(),
            },
        });

        createAirflowUserCustomResource.node.addDependency(createAirflowUserProvider);

        new CfnOutput(this, 'airflowApplicationUsernameOutput', {
            exportName: `${config.grsiPrefix}-airflow-application-username-${config.regionEnv}`,
            value: AirflowDatabaseUserDeploymentResources.airflowApplicationUserName,
        }).node.addDependency(createAirflowUserCustomResource);
    }
}
