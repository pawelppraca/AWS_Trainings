/* eslint-disable */
import { Aws, CfnOutput, Fn, RemovalPolicy, Tags } from 'aws-cdk-lib';
import { config, vpc } from '@lmig/grsi-dp-shared-config-and-classes';
import { Construct } from 'constructs';
import { StackConfiguration } from '../../../bin/config';
import { Peer, Port, SecurityGroup } from 'aws-cdk-lib/aws-ec2';
import { BlockPublicAccess, Bucket, BucketEncryption } from 'aws-cdk-lib/aws-s3';
import {
    ArnPrincipal,
    Effect,
    ManagedPolicy,
    PermissionsBoundary,
    PolicyDocument,
    PolicyStatement,
    Role,
    ServicePrincipal,
} from 'aws-cdk-lib/aws-iam';
import { AccessPoint, FileSystem } from 'aws-cdk-lib/aws-efs';
import { Key } from 'aws-cdk-lib/aws-kms';

export class AirflowBackendStorageAndFargateRoleResources extends Construct {
    // eslint-disable-next-line  @typescript-eslint/no-unused-vars
    constructor(scope: Construct, id: string, stackConfig: StackConfiguration) {
        super(scope, id);

        const kmsKey = Key.fromKeyArn(
            this,
            'KmsLookup',
            Fn.importValue(`${config.grsiPrefix}-rds-key-${config.regionEnv}`),
        );
        const dbtKmsKey = Key.fromKeyArn(this, 'KeyLookup', Fn.importValue(config.dbtKmsKeyExportName));

        const tlsPort: number = 443;
        const efsPort: number = 2049;
        const airflowSchedulerPort: number = 8793;
        const airflowSchedulerHealthCheckPort: number = 8974;

        const airflowSharedPath: string = stackConfig.airflowSharedDirectory;

        const clusterResourceID = Fn.importValue(
            `${config.grsiPrefix}-airflow-backend-rds-resource-id-${config.regionEnv}`,
        );

        const airflowUsername = Fn.importValue(`${config.grsiPrefix}-airflow-application-username-${config.regionEnv}`);
        const rdsAirflowDbUserArn: string = `arn:aws:rds-db:${Aws.REGION}:${Aws.ACCOUNT_ID}:dbuser:${clusterResourceID}/${airflowUsername}`;

        const vpcSubnetGroup = config.subnetMapping[config.environmentKey][config.regionCode.toUpperCase()];
        const vpcLookup = new vpc(this, 'VpcLookup', vpcSubnetGroup);

        const airflowSecurityGroup = new SecurityGroup(this, 'airflowSecurityGroup', {
            allowAllOutbound: false,
            description: 'Security Group to Allow Subnets to access airflow container',
            securityGroupName: `${config.grsiPrefix}-airflow-sg-${config.regionEnv}`,
            vpc: vpcLookup.ivpc,
        });

        new CfnOutput(this, 'airflowSecurityGroupOutput', {
            exportName: `${config.grsiPrefix}-airflow-SecurityGroup-id-${config.regionEnv}`,
            value: airflowSecurityGroup.securityGroupId!,
        });

        airflowSecurityGroup.addIngressRule(Peer.ipv4('10.0.0.0/8'), Port.tcp(80));
        airflowSecurityGroup.addIngressRule(Peer.ipv4('10.0.0.0/8'), Port.tcp(airflowSchedulerPort));
        airflowSecurityGroup.addIngressRule(Peer.ipv4('10.0.0.0/8'), Port.tcp(airflowSchedulerHealthCheckPort));

        airflowSecurityGroup.addIngressRule(airflowSecurityGroup, Port.tcp(80));
        airflowSecurityGroup.addIngressRule(airflowSecurityGroup, Port.tcp(airflowSchedulerPort));
        airflowSecurityGroup.addIngressRule(airflowSecurityGroup, Port.tcp(airflowSchedulerHealthCheckPort));

        for (const subnetCIDR of vpcLookup.subnetCIDRs) {
            airflowSecurityGroup.addIngressRule(Peer.ipv4(subnetCIDR), Port.tcp(tlsPort));
        }

        // Open egress since SGs are stateful
        // Especially required to dial out to sts.windows.net for SSO
        airflowSecurityGroup.addEgressRule(Peer.ipv4('0.0.0.0/0'), Port.allTcp());

        // Allow inbound HTTP requests to connect to webserver (users logging into airflow app), providing they are proxied through the VPC (zscaler)
        airflowSecurityGroup.addIngressRule(Peer.ipv4('10.0.0.0/8'), Port.tcp(tlsPort));
        airflowSecurityGroup.addIngressRule(airflowSecurityGroup, Port.tcp(80));

        const airflowTaskRole = new Role(this, 'airflowTaskRole', {
            roleName: `${config.grsiPrefix}-airflow-task-role-${config.regionEnv}`,
            assumedBy: new ServicePrincipal('ecs-tasks.amazonaws.com'),
        });

        const efsDagBag = new FileSystem(this, 'efsDagBag', {
            vpc: vpcLookup.ivpc,
            securityGroup: airflowSecurityGroup,
            removalPolicy: RemovalPolicy.DESTROY,
            fileSystemPolicy: new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        principals: [new ServicePrincipal('elasticfilesystem.amazonaws.com')],
                        effect: Effect.DENY,
                        actions: ['elasticfilesystem:ClientMount', 'elasticfilesystem:ClientWrite', 'elasticfilesystem:ClientRootAccess'],
                        resources: ['*'],
                        conditions: {
                            Bool: {
                                'aws:SecureTransport': 'false',
                            },
                        },
                    }),
                    new PolicyStatement({
                        principals: [new ServicePrincipal('elasticfilesystem.amazonaws.com')],
                        effect: Effect.ALLOW,
                        actions: ['elasticfilesystem:ClientMount', 'elasticfilesystem:ClientWrite', 'elasticfilesystem:ClientRootAccess'],
                        resources: ['*'],
                        conditions: {
                            Bool: {
                                'elasticfilesystem:AccessedViaMountTarget': 'true',
                            },
                        },
                    }),
                ],
            }),
        });
        new CfnOutput(this, 'airflowFileSystemOutput', {
            exportName: `${config.grsiPrefix}-airflow-efsDagBag-id-${config.regionEnv}`,
            value: efsDagBag.fileSystemId!,
        });

        efsDagBag.connections.allowInternally(Port.tcp(efsPort));

        const efsVolumeAccessPoint = new AccessPoint(this, 'efsVolumeAccessPoint', {
            fileSystem: efsDagBag,
            path: airflowSharedPath,
            createAcl: {
                ownerUid: '50000',
                ownerGid: '0',
                permissions: '777',
            },
            posixUser: {
                uid: '50000',
                gid: '0',
            },
        });
        new CfnOutput(this, 'airflowEfsVolumeAccessPointIdOutput', {
            exportName: `${config.grsiPrefix}-airflow-efsAccessPoint-id-${config.regionEnv}`,
            value: efsVolumeAccessPoint.accessPointId!,
        });

        ////
        // Fargate Task role
        ////

        const dbtBucketNames = `${config.grsiPrefix}-dbt-*-${config.environmentKey}`;

        const allowAcmListPolicy = new PolicyStatement({
            sid: 'allowAcmListCert',
            actions: ['acm:ListCertificates'],
            resources: ['*'],
        });
        airflowTaskRole.addToPolicy(allowAcmListPolicy);

        const allowAcmGetPolicy = new PolicyStatement({
            sid: 'allowAcmGetCert',
            actions: ['acm:GetCertificate'],
            resources: [`arn:aws:acm:${Aws.REGION}:${Aws.ACCOUNT_ID}:certificate/*`],
            conditions: {
                StringEquals: {
                    'aws:ResourceTag/deployment_guid': stackConfig.deploymentGuid,
                },
            },
        });
        airflowTaskRole.addToPolicy(allowAcmGetPolicy);

        const dbGenerateSessionTokenPolicy = new PolicyStatement({
            effect: Effect.ALLOW,
            actions: ['rds-db:connect'],
            resources: [rdsAirflowDbUserArn],
        });
        airflowTaskRole.addToPolicy(dbGenerateSessionTokenPolicy);

        const EfsPolicy = new PolicyStatement({
            actions: [
                'elasticfilesystem:ClientRootAccess',
                'elasticfilesystem:ClientWrite',
                'elasticfilesystem:ClientMount',
                'elasticfilesystem:DescribeMountTargets',
            ],
            resources: [
                `arn:aws:elasticfilesystem:${Aws.REGION}:${Aws.ACCOUNT_ID}:file-system/${efsDagBag.fileSystemId}`,
            ],
        });

        airflowTaskRole.addToPolicy(EfsPolicy);

        airflowTaskRole.addToPolicy(
            new PolicyStatement({
                effect: Effect.DENY,
                actions: [
                    'elasticfilesystem:ClientMount',
                    'elasticfilesystem:ClientRootAccess',
                    'elasticfilesystem:ClientWrite',
                ],
                resources: ['*'],
                conditions: {
                    Bool: {
                        'aws:SecureTransport': 'false',
                    },
                },
            }),
        );

        airflowTaskRole.addToPolicy(
            new PolicyStatement({
                effect: Effect.ALLOW,
                actions: [
                    'elasticfilesystem:ClientMount',
                    'elasticfilesystem:ClientRootAccess',
                    'elasticfilesystem:ClientWrite',
                ],
                resources: ['*'],
                conditions: {
                    Bool: {
                        'elasticfilesystem:AccessedViaMountTarget': 'true',
                    },
                },
            }),
        );

        const s3KmsPolicy = new PolicyStatement({
            actions: ['kms:Encrypt*', 'kms:Decrypt*', 'kms:ReEncrypt*', 'kms:GenerateDatakey*', 'kms:Describe*'],
            resources: [kmsKey.keyArn],
        });
        airflowTaskRole.addToPolicy(s3KmsPolicy);

        const assumeRolePolicy = new PolicyStatement({
            actions: ['sts:AssumeRole'],
            resources: [
                `arn:aws:iam::${config.accountNumbers[config.environmentKey].US}:role/grsi-dp-extract-glue-role-us-${config.environmentKey}`,
                `arn:aws:iam::${config.accountNumbers[config.environmentKey].US}:role/${config.grsiPrefix}-extract-glue-role-us-${config.environmentKey}`,
                `arn:aws:iam::${config.accountNumbers[config.environmentKey].US}:role/${config.grsiPrefix}-redshift-role-us-${config.environmentKey}`,
                `arn:aws:iam::${config.accountNumbers[config.environmentKey].EU}:role/${config.grsiPrefix}-redshift-role-eu-${config.environmentKey}`,
                `arn:aws:iam::${config.accountNumbers[config.environmentKey].AP}:role/${config.grsiPrefix}-redshift-role-ap-${config.environmentKey}`,
            ],
        });

        airflowTaskRole.addToPolicy(assumeRolePolicy);

        const gluePolicy = new PolicyStatement({
            actions: ['glue:GetJob', 'glue:StartJobRun', 'glue:BatchStopJobRun', 'glue:GetJobRun'],
            resources: [
                `arn:aws:glue:*:${config.accountNumbers[config.environmentKey].EU}:job/${config.grsiPrefix}-*-${config.environmentKey}`,
                `arn:aws:glue:us-east-1:${config.accountNumbers[config.environmentKey].US}:job/${config.grsiPrefix}-*-${config.environmentKey}`,
                `arn:aws:glue:ap-southeast-2:${config.accountNumbers[config.environmentKey].AP}:job/${config.grsiPrefix}-*-${config.environmentKey}`,
            ],
        });
        airflowTaskRole.addToPolicy(gluePolicy);

        const crawlerName = `${config.grsiPrefix}-bilz-crawler-${stackConfig.environmentKey}`;
        const crawlerPolicy = new PolicyStatement({
            actions: ['glue:StartCrawler'],
            resources: [
                `arn:aws:glue:${stackConfig.awsEnv.region as string}:${stackConfig.awsEnv.account as string
                }:crawler/${crawlerName}`,
            ],
        });
        airflowTaskRole.addToPolicy(crawlerPolicy);

        const lambdaPolicy = new PolicyStatement({
            actions: ['lambda:InvokeFunction'],
            resources: [
                `arn:aws:lambda:eu-west-1:${config.accountNumbers[stackConfig.environmentKey].EU}:function:${config.grsiPrefix}-fargate-trigger-lambda-eu-${config.environmentKey}`,
                `arn:aws:lambda:us-east-1:${config.accountNumbers[stackConfig.environmentKey].US}:function:${config.grsiPrefix}-fargate-trigger-lambda-us-${config.environmentKey}`,
                `arn:aws:lambda:ap-southeast-2:${config.accountNumbers[stackConfig.environmentKey].AP}:function:${config.grsiPrefix}-fargate-trigger-lambda-ap-${config.environmentKey}`,
            ],
        });
        airflowTaskRole.addToPolicy(lambdaPolicy);

        const redshiftCredsPolicy = new PolicyStatement({
            actions: ['redshift:GetClusterCredentials'],
            resources: [
                `arn:aws:redshift:eu-west-1:${config.accountNumbers[stackConfig.environmentKey].EU}:dbname:${config.grsiPrefix}-redshift-*-${stackConfig.environmentKey}/*`,
                `arn:aws:redshift:eu-west-1:${config.accountNumbers[stackConfig.environmentKey].EU}:dbuser:${config.grsiPrefix}-redshift-*-${stackConfig.environmentKey}/admin`,
                `arn:aws:redshift:us-east-1:${config.accountNumbers[stackConfig.environmentKey].US}:dbname:${config.grsiPrefix}-redshift-*-${stackConfig.environmentKey}/*`,
                `arn:aws:redshift:us-east-1:${config.accountNumbers[stackConfig.environmentKey].US}:dbuser:${config.grsiPrefix}-redshift-*-${stackConfig.environmentKey}/admin`,
                `arn:aws:redshift:ap-southeast-2:${config.accountNumbers[stackConfig.environmentKey].AP}:dbname:${config.grsiPrefix}-redshift-*-${stackConfig.environmentKey}/*`,
                `arn:aws:redshift:ap-southeast-2:${config.accountNumbers[stackConfig.environmentKey].AP}:dbuser:${config.grsiPrefix}-redshift-*-${stackConfig.environmentKey}/admin`,
            ],
        });
        airflowTaskRole.addToPolicy(redshiftCredsPolicy);

        const redshiftDataPolicy = new PolicyStatement({
            actions: ['redshift-data:DescribeStatement', 'redshift-data:ExecuteStatement'],
            resources: [
                `arn:aws:redshift:${Aws.REGION}:${Aws.ACCOUNT_ID}:cluster:${config.grsiPrefix}-redshift-*-${stackConfig.environmentKey}`,
            ],
        });
        airflowTaskRole.addToPolicy(redshiftDataPolicy);

        const dbtKeyPolicy = new PolicyStatement({
            actions: ['kms:Decrypt'],
            resources: [`arn:aws:kms:${Aws.REGION}:${Aws.ACCOUNT_ID}:key/${dbtKmsKey.keyId}`],
        });
        airflowTaskRole.addToPolicy(dbtKeyPolicy);

        const dbtSecretPolicy = new PolicyStatement({
            actions: ['secretsmanager:GetSecretValue', 'secretsmanager:DescribeSecret'],
            resources: [
                `arn:aws:secretsmanager:${Aws.REGION}:${Aws.ACCOUNT_ID}:secret:grsi-dp-dbt-secret-${config.regionEnv}-*`,
            ],
            effect: Effect.ALLOW,
        });
        airflowTaskRole.addToPolicy(dbtSecretPolicy);

        const ssmPolicy = new PolicyStatement({
            actions: ['ssm:GetParameters'],
            resources: [`arn:aws:ssm:${Aws.REGION}:${Aws.ACCOUNT_ID}:parameter/${config.grsiPrefix}-airflow-tls-${config.regionEnv}`],
        })
        airflowTaskRole.addToPolicy(ssmPolicy);

        const airflowDagBucket = new Bucket(this, 'airflowDagBucket', {
            bucketName: `${config.grsiPrefix}-airflow-dags-${stackConfig.regionEnv}`,
            encryption: BucketEncryption.KMS,
            encryptionKey: kmsKey,
            enforceSSL: true,
            removalPolicy: RemovalPolicy.DESTROY,
            blockPublicAccess: BlockPublicAccess.BLOCK_ALL,
            bucketKeyEnabled: true,
        });

        const syncBucketFargatePolicy = new PolicyStatement({
            actions: ['s3:ListBucket', 's3:GetObject*', 's3:PutObject', 's3:DeleteObject'],
            resources: [airflowDagBucket.bucketArn, airflowDagBucket.arnForObjects('*')],
        });
        airflowTaskRole.addToPolicy(syncBucketFargatePolicy);

        const dbtBucketPolicy = new PolicyStatement({
            actions: ['s3:GetObject*', 's3:ListBucket'],
            resources: [`arn:aws:s3:::${dbtBucketNames}/*`, `arn:aws:s3:::${dbtBucketNames}`],
        })
        airflowTaskRole.addToPolicy(dbtBucketPolicy);

        airflowDagBucket.addToResourcePolicy(
            new PolicyStatement({
                actions: ['s3:ListBucket', 's3:GetObject*', 's3:PutObject', 's3:DeleteObject'],
                principals: [airflowTaskRole],
                resources: [airflowDagBucket.bucketArn, airflowDagBucket.arnForObjects('*')],
            }),
        );

        airflowDagBucket.addToResourcePolicy(
            new PolicyStatement({
                actions: ['s3:PutObjectTagging', 's3:PutObject'],
                principals: [
                    new ArnPrincipal(
                        `arn:aws:iam::${Aws.ACCOUNT_ID}:role/cloud-services/pipeline-deployment-guid-access`,
                    ),
                ],
                resources: [airflowDagBucket.arnForObjects('*')],
                conditions: {
                    StringEquals: {
                        's3:RequestObjectTag/deployment_guid': stackConfig.stackTags.deployment_guid,
                    },
                    'ForAllValues:StringEquals': {
                        's3:RequestObjectTag/deployment_guid': ['${aws:PrincipalTag/deployment_guid}'],
                    },
                },
            }),
        );

        airflowDagBucket.addToResourcePolicy(
            new PolicyStatement({
                actions: ['s3:ListBucket'],
                principals: [
                    new ArnPrincipal(
                        `arn:aws:iam::${Aws.ACCOUNT_ID}:role/cloud-services/pipeline-deployment-guid-access`,
                    ),
                ],
                resources: [airflowDagBucket.bucketArn],
            }),
        );
        airflowDagBucket.addToResourcePolicy(
            new PolicyStatement({
                actions: ['s3:DeleteObject'],
                principals: [
                    new ArnPrincipal(
                        `arn:aws:iam::${Aws.ACCOUNT_ID}:role/cloud-services/pipeline-deployment-guid-access`,
                    ),
                ],
                resources: [airflowDagBucket.arnForObjects('*')],
            }),
        );

        const getRdsTokenPolicyPB = new ManagedPolicy(this, 'getRdsTokenPolicy', {
            managedPolicyName: `${config.grsiPrefix}-airflow-db-connect-${config.regionEnv}`,
            path: '/permission-boundary/',
            statements: [
                new PolicyStatement({
                    effect: Effect.ALLOW,
                    actions: ['logs:CreateLogGroup', 'logs:CreateLogStream', 'logs:PutLogEvents'],
                    resources: ['*'],
                }),
                dbGenerateSessionTokenPolicy,
                allowAcmListPolicy,
                allowAcmGetPolicy,
                syncBucketFargatePolicy,
                s3KmsPolicy,
                gluePolicy,
                crawlerPolicy,
                lambdaPolicy,
                redshiftCredsPolicy,
                EfsPolicy,
                assumeRolePolicy,
                dbtBucketPolicy,
                dbtKeyPolicy,
                dbtSecretPolicy,
                ssmPolicy,
            ],
        });

        Tags.of(airflowTaskRole).add('aws_iam_permission_boundary_exempt', 'CustomAwaitingApproval');
        airflowTaskRole.node.addDependency(getRdsTokenPolicyPB);
        PermissionsBoundary.of(airflowTaskRole).apply(getRdsTokenPolicyPB);
    }
}