import { config, vpc } from '@lmig/grsi-dp-shared-config-and-classes';
import {
    FargateTaskDefinition,
    ContainerImage,
    LogDrivers,
    Protocol,
    Cluster,
    FargateService,
} from 'aws-cdk-lib/aws-ecs';
import { Role, ServicePrincipal, ManagedPolicy } from 'aws-cdk-lib/aws-iam';
import { SecurityGroup, Peer, Port } from 'aws-cdk-lib/aws-ec2';
import { Construct } from 'constructs';
import { StackConfiguration } from '../../../bin/config';
import * as logs from 'aws-cdk-lib/aws-logs';

export class XrayResources extends Construct {
    private readonly xRayDaemonPort: number = 2000;

    constructor(scope: Construct, id: string, stackConfig: StackConfiguration) {
        super(scope, id);

        const vpcLookup = new vpc(this, 'LookupVpc');

        const xrayTaskRole = new Role(this, 'xrayTaskRole', {
            roleName: `${config.grsiPrefix}-xray-daemon-role-${stackConfig.regionEnv}`,
            assumedBy: new ServicePrincipal('ecs-tasks.amazonaws.com'),
            managedPolicies: [
                // Write permissions for using the X-Ray daemon to upload segment documents and telemetry to the X-Ray API.
                // Includes read permissions to get sampling rules and report sampling results.
                ManagedPolicy.fromManagedPolicyArn(
                    this,
                    'getXrayManagedPolicy',
                    'arn:aws:iam::aws:policy/AWSXRayDaemonWriteAccess',
                ),
            ],
        });

        const xrayTaskDefinition = new FargateTaskDefinition(this, 'xrayTaskDefinition', {
            cpu: 256,
            memoryLimitMiB: 512,
            taskRole: xrayTaskRole,
            family: `${config.grsiPrefix}-xray-daemon-fargate-${config.regionEnv}`,
        });

        const xrayContainerImage = xrayTaskDefinition.addContainer('XRayDaemon', {
            image: ContainerImage.fromRegistry(config.xrayContainerImageTag),
            logging: LogDrivers.awsLogs({
                streamPrefix: `${config.grsiPrefix}/xray-daemon/`,
                logRetention: logs.RetentionDays.ONE_WEEK,
            }),
            environment: {
                AWS_REGION: config.awsRegion,
            },
        });

        xrayContainerImage.addPortMappings(
            {
                containerPort: this.xRayDaemonPort,
                hostPort: this.xRayDaemonPort,
                protocol: Protocol.UDP,
            },
            {
                containerPort: this.xRayDaemonPort,
                hostPort: this.xRayDaemonPort,
                protocol: Protocol.TCP,
            },
        );
        xrayTaskDefinition.obtainExecutionRole();

        const xraySecurityGroup = new SecurityGroup(this, 'xRayDaemonSecurityGroup', {
            allowAllOutbound: true,
            description: 'Security Group to Allow Subnets to access XRay Daemon',
            securityGroupName: `${config.grsiPrefix}-xray-sg-${config.regionEnv}`,
            vpc: vpcLookup.ivpc,
        });

        // Open up the XRay Daemon to the VPC Subnets
        for (const subnetCIDR of vpcLookup.subnetCIDRs) {
            xraySecurityGroup.addIngressRule(Peer.ipv4(subnetCIDR), Port.tcp(this.xRayDaemonPort));
            xraySecurityGroup.addIngressRule(Peer.ipv4(subnetCIDR), Port.udp(this.xRayDaemonPort));
        }

        const cluster = Cluster.fromClusterAttributes(this, 'lookupCluster', {
            clusterName: config.ecsClusterName,
            vpc: vpcLookup.ivpc,
        });

        new FargateService(this, 'xrayService', {
            cluster: cluster,
            desiredCount: 1,
            securityGroups: [xraySecurityGroup],
            serviceName: `${config.grsiPrefix}-xray-daemon-${config.regionEnv}`,
            taskDefinition: xrayTaskDefinition,
        });
    }
}
