# Generic CloudFormation Starter Project

## Description

This project serves as a starting point for developers looking to create applications that leverages CloudFormation. It includes a generic CloudFormation template with Custom Resources, as well as a basic configuration file for the Forge Manifest Processor task.

## Project Structure

**cloudformation** - contains CloudFormation templates and Forge Files for the Forge Manifest Processor Task<br>

## Related Resources

- [Getting Started With AWS CI/CD Pipelines](https://libertymutual.atlassian.net/wiki/spaces/ETSPC/pages/335316058/Getting+Started+With+AWS+CI+CD+Pipelines)
- [Forge Manifest Processor Task](https://libertymutual.atlassian.net/wiki/spaces/CLOUDFORGE/pages/291768298/Forge+Manifest+Processor+Task)
- [CloudFormation Pipeline Automation](https://libertymutual.atlassian.net/wiki/spaces/CLOUDFORGE/pages/291768564/CloudFormation+Pipeline+Automation)
- [Sample Actions Package Workflow](https://github.com/lmigtech/publiccloud-cft-starter-example/blob/main/.github/workflows/package-main.yml)
- [Sample Actions Deploy Workflow](https://github.com/lmigtech/publiccloud-cft-starter-example/blob/main/.github/workflows/sandbox-deploy.yml)
