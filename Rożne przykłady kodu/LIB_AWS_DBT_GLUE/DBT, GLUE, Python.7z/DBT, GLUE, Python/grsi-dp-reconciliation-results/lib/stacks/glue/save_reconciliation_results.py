import sys
import boto3
from json import loads
from pathlib import Path
import pandas as pd

from awsglue.context import GlueContext
from awsglue.dynamicframe import DynamicFrame
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import SparkSession


def main():

    #TODO: Remove any unused arguments; align with extraction.ts
    # args = getResolvedOptions(
    #     sys.argv,
    #     [
    #          "JOB_NAME",
    #         "AWS_REGION",
    #         "ENVIRONMENT",
    #         "INGESTION_BUCKET",
    #         "ORGANIZATION_GUID",
    #         "LM_TROUX_UID",
    #         "DEPLOYMENT_GUID",
    #         "ASSUME_ROLE_PREFIX",
    #         "KMS_KEY_SSM_PARAM_PREFIX",
    #         "US_ACCOUNT_NUMBER",
    #         "EU_ACCOUNT_NUMBER",
    #         "DATALAKE_CROSS_ACCOUNT_ROLE",
    #         "GLUE_SCRIPT_BUCKET",
    #         "XRAY_ECS_RESOURCE_ARN",
    #     ],
    # )

    # xray_settings={
    #         "xray_ecs_resource_arn": args["XRAY_ECS_RESOURCE_ARN"], 
    #         "service_name": "Warehouse Repo Extraction",
    #         "main_segment_name": f'Glue Job {args["JOB_NAME"]}: {args["JOB_RUN_ID"]}',
    #         "xray_s3_key_prefix": "_xray_temporary"
    # }

    # s3_tags = {
    #      "organization_guid": args["ORGANIZATION_GUID"],
    #      "lm_troux_uid": args["LM_TROUX_UID"],
    #      "deployment_guid": args["DEPLOYMENT_GUID"],
    # }



    # # Create Contexts
    # spark = SparkSession.builder
    
    # redshift_url = 
    
    # logger = GlueLogger(GlueJobUtil.create_logger(glue_context))
    # logger.info("GlueContext has been created successfully.")
    