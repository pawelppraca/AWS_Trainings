package forge;

import com.lmig.forge.bamboo.specs.patterns.PipelineConfiguration;

public class PipelineParameters {
  /**
   * DO NOT MODIFY THIS CLASS. It will be regenerated systematically by the CloudForge Console.
   * If you want to add additional environments, please do so through the Console.
   *
   * Note: any changes made to plan or deployment permissions within your pipeline spec will be reset to match
   * what exist in the Console. To make any changes to permissions, please do so through the Console.
   *
   **/

  private static final String GENERATED_AT = "Wed, 13 Nov 2024 12:15:45 GMT";

  public static final PipelineConfiguration PIPELINE_CONFIGURATION = PipelineConfiguration.builder()
    .artifactGuid("08229420-d1b2-4c9e-bb68-5a15d347e2c4")
    .build();
}
