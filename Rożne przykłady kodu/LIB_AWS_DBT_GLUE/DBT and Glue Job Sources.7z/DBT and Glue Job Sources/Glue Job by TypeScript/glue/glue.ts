import { Construct } from 'constructs';
import { StackConfiguration } from '../../../bin/config';
import {
    ArnPrincipal,
    Effect,
    ManagedPolicy,
    PolicyDocument,
    PolicyStatement,
    Role,
    ServicePrincipal,
    AnyPrincipal,
} from 'aws-cdk-lib/aws-iam';
import { config, grsiPrefix, vpc, KmsUtil } from '@lmig/grsi-dp-shared-config-and-classes';
import { Port, SecurityGroup, Subnet } from 'aws-cdk-lib/aws-ec2';
import {
    Code,
    Connection,
    ConnectionType,
    GlueVersion,
    Job,
    JobExecutable,
    PythonVersion,
    WorkerType,
    CloudWatchEncryptionMode,
    JobBookmarksEncryptionMode,
    S3EncryptionMode,
    SecurityConfiguration,
} from '@aws-cdk/aws-glue-alpha';

import { BlockPublicAccess, Bucket, IBucket, BucketEncryption } from 'aws-cdk-lib/aws-s3';
import { RemovalPolicy } from 'aws-cdk-lib';
import { ApplyTagsToResourceCustomResource } from '@lmig/swa-cdk-core';
import { Tags } from 'aws-cdk-lib';
import { Key } from 'aws-cdk-lib/aws-kms';
import { AttributeType, Billing, TableEncryptionV2, TableV2 } from 'aws-cdk-lib/aws-dynamodb';

export class SaveReconResources extends Construct {
    constructor(scope: Construct, id: string, stackConfig: StackConfiguration) {
        super(scope, id);

        // Set up our vars here, since
        const vpcConnectionName = `${grsiPrefix}-save-recon-vpc-connection-${stackConfig.environmentKey}`;
        const glueJobName = `${grsiPrefix}-save-recon-GlueJob-${stackConfig.environmentKey}`;

        const kmsUtil = new KmsUtil(config.environmentKey);

        //Key for S3 Bucket for Glue Script
        const warehouseScriptBucketKey = new Key(this, 'WarehosueScriptBucketKey', {
            description: 'KMS Key for Warehouse Script Bucket',
            enableKeyRotation: kmsUtil.shouldEnableKeyRotation(),
            alias: `alias/${config.grsiPrefix}-warehouse-script-key-${config.regionEnv}`,
            removalPolicy: kmsUtil.getRemovalPolicy(),
            policy: new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:*'],
                        principals: [new ArnPrincipal(`arn:aws:iam::${stackConfig.awsEnv.account}:root`)],
                    }),
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:GenerateDataKey'],
                        principals: [
                            new ArnPrincipal(
                                `arn:aws:iam::${stackConfig.awsEnv.account}:role/cloud-services/pipeline-deployment-guid-access`,
                            ),
                            new ArnPrincipal(
                                `arn:aws:iam::${stackConfig.awsEnv.account as string}:user/aws-dp-admin-user/lsm-dp-admin-user-test`,
                            ),
                        ],
                    }),
                ],
            }),
        });

        //S3 Bucket for Glue Script
        const warehouseScriptBucket: IBucket = new Bucket(this, 'WarehouseScriptBucket', {
            bucketName: stackConfig.glueScriptBucketName,
            encryption: BucketEncryption.KMS,
            encryptionKey: warehouseScriptBucketKey,
            removalPolicy: RemovalPolicy.DESTROY,
            blockPublicAccess: BlockPublicAccess.BLOCK_ALL,
            bucketKeyEnabled: true,
        });

        //Add write privileges to Bamboo
        warehouseScriptBucket.addToResourcePolicy(
            new PolicyStatement({
                actions: ['s3:PutObjectTagging', 's3:PutObject'],
                principals: [
                    new ArnPrincipal(
                        `arn:aws:iam::${stackConfig.awsEnv.account as string}:role/cloud-services/pipeline-deployment-guid-access`,
                    ),
                ],
                resources: [`arn:aws:s3:::${warehouseScriptBucket.bucketName}/*`],
                conditions: {
                    StringEquals: {
                        's3:RequestObjectTag/deployment_guid': stackConfig.stackTags.deployment_guid,
                    },
                    'ForAllValues:StringEquals': {
                        's3:RequestObjectTag/deployment_guid': ['${aws:PrincipalTag/deployment_guid}'],
                    },
                },
            }),
        );
        //Add read/write  privileges to Admin User
        warehouseScriptBucket.grantReadWrite(
            new AnyPrincipal().withConditions({
                ArnLike: {
                    'aws:PrincipalArn': `arn:aws:iam::${stackConfig.awsEnv.account as string}:user/aws-dp-admin-user/lsm-dp-admin-user-test`,
                },
            }),
        );

        //Bucket S3 for Data (temporary, data should be stored in ingestion Bucket)
        //Key for Bucket
        const saveReconDataBucketKey = new Key(this, 'SaveReconDataBucketKey', {
            description: 'KMS Key for Save Reconciliation Data Script Bucket',
            enableKeyRotation: kmsUtil.shouldEnableKeyRotation(),
            alias: `alias/${config.grsiPrefix}-save-recon-data-key-${config.regionEnv}`,
            removalPolicy: kmsUtil.getRemovalPolicy(),
            policy: new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:*'],
                        principals: [new ArnPrincipal(`arn:aws:iam::${stackConfig.awsEnv.account}:root`)],
                    }),
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:GenerateDataKey'],
                        principals: [
                            new ArnPrincipal(
                                `arn:aws:iam::${stackConfig.awsEnv.account}:role/cloud-services/pipeline-deployment-guid-access`,
                            ),
                        ],
                    }),
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
                        principals: [
                            new AnyPrincipal().withConditions({
                                ArnLike: {
                                    'aws:PrincipalArn': `arn:aws:iam::${stackConfig.awsEnv.account as string}:role/${stackConfig.glueJobRoleName}`,
                                },
                            }),
                        ],
                    }),
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
                        principals: [
                            new AnyPrincipal().withConditions({
                                ArnLike: {
                                    'aws:PrincipalArn': `arn:aws:iam::${stackConfig.awsEnv.account as string}:user/${stackConfig.glueUserName}`,
                                },
                            }),
                        ],
                    }),
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
                        principals: [
                            new AnyPrincipal().withConditions({
                                ArnLike: {
                                    'aws:PrincipalArn': `arn:aws:iam::${stackConfig.awsEnv.account as string}:user/${config.supportUserName}`,
                                },
                            }),
                        ],
                    }),
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: [
                            'kms:Encrypt*',
                            'kms:Decrypt*',
                            'kms:ReEncrypt*',
                            'kms:GenerateDataKey',
                            'kms:Describe*',
                        ],
                        principals: [new ServicePrincipal(`logs.${stackConfig.awsEnv.region as string}.amazonaws.com`)],
                    }),
                ],
            }),
        });

        //S3 Bucket
        const saveReconDataBucket: IBucket = new Bucket(this, 'SaveReconDataBucket', {
            bucketName: stackConfig.SaveReconDataBucketName,
            encryption: BucketEncryption.KMS,
            encryptionKey: saveReconDataBucketKey,
            removalPolicy: RemovalPolicy.DESTROY,
            blockPublicAccess: BlockPublicAccess.BLOCK_ALL,
            bucketKeyEnabled: true,
        });
        //Add read/write priviliges for Glue Job
        saveReconDataBucket.grantReadWrite(
            new AnyPrincipal().withConditions({
                ArnLike: {
                    'aws:PrincipalArn': `arn:aws:iam::${stackConfig.awsEnv.account as string}:role/${stackConfig.glueJobRoleName}`,
                },
            }),
        );
        //Add read/write priviliges for Admin user
        saveReconDataBucket.grantReadWrite(
            new AnyPrincipal().withConditions({
                ArnLike: {
                    'aws:PrincipalArn': `arn:aws:iam::${stackConfig.awsEnv.account as string}:user/aws-dp-admin-user/lsm-dp-admin-user-test`,
                },
            }),
        );
        //Add read/write priviliges for assumed role
        saveReconDataBucket.grantReadWrite(
            new AnyPrincipal().withConditions({
                ArnLike: {
                    'aws:PrincipalArn': `arn:aws:sts::${stackConfig.awsEnv.account as string}:assumed-role/${stackConfig.glueJobRoleName}`,
                },
            }),
        );

        saveReconDataBucket.grantReadWrite(
            new AnyPrincipal().withConditions({
                ArnLike: {
                    'aws:PrincipalArn': `arn:aws:iam::${stackConfig.awsEnv.account as string}:role/${stackConfig.glueJobRoleName}`,
                },
            }),
        );
        //Add read/write priviliges for Admin user
        //DynamoDB Table
        //const dynamoKey = Key.fromKeyArn(this, 'DynamoKeyLookup', Fn.importValue(config.dynamoKmsKeyExportName));

        //Key for Dynamo
        const dynamoTableKey = new Key(this, 'SaveReconDataDynamoTableKey', {
            description: 'KMS Key for Save Reconciliation Data DynamoTable',
            enableKeyRotation: kmsUtil.shouldEnableKeyRotation(),
            alias: `alias/${config.grsiPrefix}-save-recon-dynamo-table-key-${config.regionEnv}`,
            removalPolicy: kmsUtil.getRemovalPolicy(),
            policy: new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:*'],
                        principals: [new ArnPrincipal(`arn:aws:iam::${stackConfig.awsEnv.account}:root`)],
                    }),
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
                        principals: [
                            new AnyPrincipal().withConditions({
                                ArnLike: {
                                    'aws:PrincipalArn': `arn:aws:iam::${stackConfig.awsEnv.account as string}:user/aws-dp-admin-user/lsm-dp-admin-user-test`,
                                },
                            }),
                        ],
                    }),
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
                        principals: [
                            new AnyPrincipal().withConditions({
                                ArnLike: {
                                    'aws:PrincipalArn': `arn:aws:iam::${stackConfig.awsEnv.account as string}:user/${config.supportUserName}`,
                                },
                            }),
                        ],
                    }),
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
                        principals: [
                            new AnyPrincipal().withConditions({
                                ArnLike: {
                                    'aws:PrincipalArn': `arn:aws:iam::${stackConfig.awsEnv.account as string}:user/${stackConfig.glueUserName}`,
                                },
                            }),
                        ],
                    }),
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        resources: ['*'],
                        actions: ['kms:GenerateDataKey', 'kms:Decrypt'],
                        principals: [
                            new AnyPrincipal().withConditions({
                                ArnLike: {
                                    'aws:PrincipalArn': `arn:aws:iam::${stackConfig.awsEnv.account as string}:role/${stackConfig.glueJobRoleName}`,
                                },
                            }),
                        ],
                    }),
                ],
            }),
        });

        const inlineDynamoPolicy = new PolicyDocument({
            statements: [
                new PolicyStatement({
                    actions: ['dynamodb:*'],
                    resources: [
                        `arn:aws:dynamodb:${stackConfig.awsEnv.region as string}:${stackConfig.awsEnv.account as string}:table/${stackConfig.DynamoDbHeaderTableName}`,
                    ],
                    principals: [
                        new AnyPrincipal().withConditions({
                            ArnLike: {
                                'aws:PrincipalArn': `arn:aws:sts::${stackConfig.awsEnv.account as string}:assumed-role/lm-federate-saml-read_only/*`,
                            },
                        }),
                    ],
                    effect: Effect.ALLOW,
                }),
                new PolicyStatement({
                    actions: ['dynamodb:*'],
                    resources: [
                        `arn:aws:dynamodb:${stackConfig.awsEnv.region as string}:${stackConfig.awsEnv.account as string}:table/${stackConfig.DynamoDbHeaderTableName}`,
                    ],
                    principals: [
                        new ArnPrincipal(
                            `arn:aws:iam::${stackConfig.awsEnv.account as string}:user/aws-dp-admin-user/lsm-dp-admin-user-test`,
                        ),
                    ],
                    effect: Effect.ALLOW,
                }),
            ],
        });

        const saveReconHeaderTable = new TableV2(this, 'save-recon-header-table', {
            tableName: stackConfig.DynamoDbHeaderTableName,
            partitionKey: { name: 'header_key', type: AttributeType.NUMBER },
            sortKey: { name: 'header_time_stamp', type: AttributeType.STRING },
            removalPolicy: RemovalPolicy.DESTROY,
            encryption: TableEncryptionV2.customerManagedKey(dynamoTableKey),
            billing: Billing.onDemand(),
            pointInTimeRecovery: true,
            resourcePolicy: inlineDynamoPolicy,
        });

        //Add read/write priviliges for Admin user
        saveReconHeaderTable.grantReadWriteData(
            new ArnPrincipal(
                `arn:aws:iam::${stackConfig.awsEnv.account as string}:user/aws-dp-admin-user/lsm-dp-admin-user-test`,
            ),
        );
        saveReconHeaderTable.grantFullAccess(
            new ArnPrincipal(
                `arn:aws:iam::${stackConfig.awsEnv.account as string}:user/aws-dp-admin-user/lsm-dp-admin-user-test`,
            ),
        );
        //Add read/write priviliges for Console User
        saveReconHeaderTable.grantReadWriteData(
            new AnyPrincipal().withConditions({
                ArnLike: {
                    'aws:PrincipalArn': `arn:aws:sts::${stackConfig.awsEnv.account as string}:assumed-role/lm-federate-saml-read_only/*`,
                },
            }),
        );
        //Add read/write priviliges for assumed role
        saveReconHeaderTable.grantReadWriteData(
            new AnyPrincipal().withConditions({
                ArnLike: {
                    'aws:PrincipalArn': `arn:aws:sts::${stackConfig.awsEnv.account as string}:assumed-role/${stackConfig.glueJobRoleName}`,
                },
            }),
        );

        saveReconHeaderTable.grantFullAccess(
            new AnyPrincipal().withConditions({
                ArnLike: {
                    'aws:PrincipalArn': `arn:aws:sts::${stackConfig.awsEnv.account as string}:assumed-role/lm-federate-saml-read_only/*`,
                },
            }),
        );

        //Inline Policies for Glue Job Role
        const glueJobRoleInlinePolicies: { [key: string]: PolicyDocument } = {
            s3Policy: new PolicyDocument({
                //Policies for S3 Buckets
                statements: [
                    new PolicyStatement({
                        actions: ['s3:GetObject*', 's3:DeleteObject*', 's3:PutObject*'],
                        resources: [`arn:aws:s3:::${stackConfig.SaveReconDataBucketName}/*`],
                        effect: Effect.ALLOW,
                    }),
                    new PolicyStatement({
                        actions: ['s3:GetObject*'],
                        resources: [`arn:aws:s3:::${stackConfig.glueScriptBucketName}/*`],
                        effect: Effect.ALLOW,
                    }),
                    new PolicyStatement({
                        actions: ['s3:ListBucket'],
                        resources: [
                            `arn:aws:s3:::${stackConfig.glueScriptBucketName}`,
                            `arn:aws:s3:::${stackConfig.SaveReconDataBucketName}`,
                        ],
                        effect: Effect.ALLOW,
                    }),
                    new PolicyStatement({
                        actions: ['kms:Decrypt', 'kms:DescribeKey'],
                        resources: [saveReconDataBucketKey.keyArn, warehouseScriptBucketKey.keyArn],
                        effect: Effect.ALLOW,
                    }),
                    new PolicyStatement({
                        effect: Effect.ALLOW,
                        actions: ['kms:Decrypt', 'kms:Encrypt', 'kms:GenerateDataKey', 'kms:DescribeKey'],
                        resources: [
                            `arn:aws:kms:eu-west-1:${config.accountNumbers[stackConfig.environmentKey].EU}:key/*`,
                            `arn:aws:kms:us-east-1:${config.accountNumbers[stackConfig.environmentKey].US}:key/*`,
                            `arn:aws:kms:ap-southeast-2:${config.accountNumbers[stackConfig.environmentKey].AP}:key/*`,
                        ],
                        conditions: {
                            StringEquals: {
                                'aws:ResourceTag/lm_troux_uid': stackConfig.stackTags.lm_troux_uid,
                            },
                        },
                    }),
                ],
            }),
            logsPolicy: new PolicyDocument({
                //Logging POlicy
                statements: [
                    new PolicyStatement({
                        actions: ['logs:*'],
                        resources: [
                            `arn:aws:logs:${stackConfig.awsEnv.region as string}:${
                                stackConfig.awsEnv.account as string
                            }:log-group:grsi-dp*`,
                            `arn:aws:logs:${stackConfig.awsEnv.region as string}:${
                                stackConfig.awsEnv.account as string
                            }:log-group:/aws-glue/*`,
                        ],
                        effect: Effect.ALLOW,
                    }),
                ],
            }),
            RedShiftPolicy: new PolicyDocument({
                //Redhiift Policy
                statements: [
                    new PolicyStatement({
                        actions: ['redshift-data:ExecuteStatement'],
                        resources: [
                            `arn:aws:redshift:${stackConfig.awsEnv.region as string}:${stackConfig.awsEnv.account as string}:cluster:${grsiPrefix}-redshift-${stackConfig.regionEnv}/*`,
                        ],
                        effect: Effect.ALLOW,
                    }),
                    new PolicyStatement({
                        actions: ['redshift-data:DescribeStatement'],
                        resources: [
                            `arn:aws:redshift:${stackConfig.awsEnv.region as string}:${stackConfig.awsEnv.account as string}:cluster:${grsiPrefix}-redshift-${stackConfig.regionEnv}/*`,
                        ],
                        effect: Effect.ALLOW,
                    }),
                    new PolicyStatement({
                        actions: ['redshift:GetClusterCredentialsWithIAM'],
                        resources: [
                            `arn:aws:redshift:${stackConfig.awsEnv.region as string}:${stackConfig.awsEnv.account as string}:dbname:${grsiPrefix}-${stackConfig.regionEnv}/*`,
                        ],
                        effect: Effect.ALLOW,
                    }),
                    new PolicyStatement({
                        actions: ['kms:Encrypt', 'kms:Decrypt', 'kms:DescribeKey'],
                        resources: [
                            `arn:aws:redshift:${stackConfig.awsEnv.region as string}:${stackConfig.awsEnv.account as string}:dbname:${grsiPrefix}-${stackConfig.regionEnv}/*`,
                        ],
                        effect: Effect.ALLOW,
                    }),
                    new PolicyStatement({
                        actions: ['redshift:GetClusterCredentials'],
                        resources: [
                            `arn:aws:redshift:${stackConfig.awsEnv.region as string}:${stackConfig.awsEnv.account as string}:cluster:${grsiPrefix}-redshift-${stackConfig.regionEnv}/*`,
                            `arn:aws:redshift:${stackConfig.awsEnv.region as string}:${stackConfig.awsEnv.account as string}:dbgroup:${grsiPrefix}-redshift-${stackConfig.regionEnv}/*`,
                            `arn:aws:redshift:${stackConfig.awsEnv.region as string}:${stackConfig.awsEnv.account as string}:dbuser:*/*`,
                            `arn:aws:redshift:${stackConfig.awsEnv.region as string}:${stackConfig.awsEnv.account as string}:dbname:${grsiPrefix}-redshift-${stackConfig.regionEnv}/${stackConfig.RedshiftDBname}`,
                        ],
                        effect: Effect.ALLOW,
                    }),
                    new PolicyStatement({
                        actions: ['redshift:DescribeClusters'],
                        resources: [`*`],
                        effect: Effect.ALLOW,
                    }),
                ],
            }),
            stsPolicy: new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        actions: ['sts:AssumeRole'],
                        resources: [
                            `arn:aws:iam::*:role/${config.glueAssumeRoleNamePrefix}-*-${config.environmentKey}`,
                        ],
                    }),
                ],
            }),
            dynamoPolicy: new PolicyDocument({
                statements: [
                    new PolicyStatement({
                        actions: ['kms:Encrypt', 'kms:Decrypt', 'kms:DescribeKey'],
                        resources: [dynamoTableKey.keyArn],
                    }),
                    new PolicyStatement({
                        actions: ['dynamodb:PutItem', 'dynamodb:GetItem', 'dynamodb:Query'],
                        resources: [
                            `arn:aws:dynamodb:${stackConfig.awsEnv.region as string}:${stackConfig.awsEnv.account as string}:table/${stackConfig.DynamoDbHeaderTableName}`,
                        ],
                    }),
                ],
            }),
        };

        //Role to allow access Glue to S3 Bucket and RedShift
        const glueJobRole = new Role(this, 'SaveReconGlueJobRole', {
            roleName: stackConfig.glueJobRoleName,
            description: 'Glue Job role to extract dbt Results Data to S3 bucket.',
            assumedBy: new ServicePrincipal('glue.amazonaws.com'),
            managedPolicies: [
                ManagedPolicy.fromManagedPolicyArn(
                    this,
                    'AWSGlueServiceRole',
                    'arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole',
                ),
            ],
            inlinePolicies: glueJobRoleInlinePolicies,
        });

        glueJobRole.stack.tags.setTag('aws_iam_permission_boundary_exempt', 'CUSTOM');
        Tags.of(glueJobRole).add('deployment_guid', config.stackTags.deployment_guid);

        //Assign rights to Buckets
        warehouseScriptBucket.grantReadWrite(glueJobRole);
        saveReconDataBucket.grantReadWrite(glueJobRole);

        //Assign rights to DynamoTable
        saveReconHeaderTable.grantReadWriteData(glueJobRole);

        const redshiftRole = new Role(this, 'RedShiftRole', {
            roleName: stackConfig.RedShiftAccessRoleName,
            assumedBy: new ServicePrincipal('redshift.amazonaws.com'),
            inlinePolicies: {
                RedShiftPolicy: new PolicyDocument({
                    statements: [
                        new PolicyStatement({
                            actions: [
                                'redshift:GetClusterCredentials',
                                'redshift:DescribeClusters',
                                'redshift:ExecuteQuery',
                                'redshift:Select',
                            ],
                            resources: [
                                `arn:aws:redshift:${stackConfig.awsEnv.region as string}:${stackConfig.awsEnv.account as string}:cluster:${grsiPrefix}-redshift-${stackConfig.regionEnv}/*`,
                                `arn:aws:redshift:${stackConfig.awsEnv.region as string}:${stackConfig.awsEnv.account as string}:dbgroup:${grsiPrefix}-redshift-${stackConfig.regionEnv}/*`,
                                `arn:aws:redshift:${stackConfig.awsEnv.region as string}:${stackConfig.awsEnv.account as string}:dbuser:*/*`,
                                `arn:aws:redshift:${stackConfig.awsEnv.region as string}:${stackConfig.awsEnv.account as string}:dbname:${grsiPrefix}-redshift-${stackConfig.regionEnv}/${stackConfig.RedshiftDBname}`,
                            ],
                            effect: Effect.ALLOW,
                        }),
                    ],
                }),
                s3Policy: new PolicyDocument({
                    statements: [
                        new PolicyStatement({
                            actions: ['s3:GetObject*', 's3:DeleteObject', 's3:PutObject*', 's3:ListBucket*'],
                            resources: [`arn:aws:s3:::${stackConfig.SaveReconDataBucketName}/*`],
                            effect: Effect.ALLOW,
                        }),
                    ],
                }),
            },
        });

        glueJobRole.node.addDependency(redshiftRole);

        const vpcLookup = new vpc(this, 'LookupVpc');

        const glueSecurityGroup = new SecurityGroup(this, 'SecurityGroup', {
            allowAllOutbound: true,
            description: 'Security Group to allow Glue to run in VPC',
            securityGroupName: `${grsiPrefix}-save-recon-glue-security-group-${stackConfig.environmentKey}`,
            vpc: vpcLookup.ivpc,
        });

        // Self referencing rule to allow Glue to talk to all its internal components
        glueSecurityGroup.addIngressRule(glueSecurityGroup, Port.allTcp(), 'self-referencing');

        const vpcConnection = new Connection(this, 'SaveReconVPCConnection', {
            connectionName: vpcConnectionName,
            type: ConnectionType.NETWORK,
            subnet: Subnet.fromSubnetAttributes(this, 'SaveReconSubnetLookup', {
                subnetId: vpcLookup.subnetIds[0],
                availabilityZone: vpcLookup.availabilityZones[0],
            }),
            securityGroups: [glueSecurityGroup],
        });

        new ApplyTagsToResourceCustomResource(this, 'TagVPCConnection', {
            resource: vpcConnection,
            tags: {},
        }).node.addDependency(vpcConnection);

        // LSMDATA-6349
        const securityConfig: SecurityConfiguration = new SecurityConfiguration(this, 'SecurityConfiguration', {
            securityConfigurationName: `${grsiPrefix}-save-recon-security-config-${stackConfig.environmentKey}`,
            cloudWatchEncryption: {
                mode: CloudWatchEncryptionMode.KMS,
                kmsKey: saveReconDataBucketKey,
            },
            jobBookmarksEncryption: {
                mode: JobBookmarksEncryptionMode.CLIENT_SIDE_KMS,
                kmsKey: saveReconDataBucketKey,
            },
            s3Encryption: {
                mode: S3EncryptionMode.KMS,
                kmsKey: saveReconDataBucketKey,
            },
        });


        //const SaveReconGlueJob =
        new Job(this, 'SaveReconGlueJob2', {
            role: glueJobRole,
            executable: JobExecutable.pythonEtl({
                pythonVersion: PythonVersion.THREE,
                glueVersion: GlueVersion.V4_0,
                script: Code.fromBucket(warehouseScriptBucket, 'job_scripts/save_reconciliation_results.py'),
            }),
            jobName: glueJobName,
            description: 'Job to extract dbt Results Data to S3 bucket to reconciliation schema',
            securityConfiguration: securityConfig,
            connections: [vpcConnection],
            workerType: WorkerType.G_1X,
            workerCount: 2,
            continuousLogging: {
                enabled: true,
                quiet: true,
                logStreamPrefix: `${grsiPrefix}-save-recon-`,
            },
            sparkUI: { enabled: true }, //Enable Spark UI
            defaultArguments: {
                '--job-bookmark-option': 'job-bookmark-disable',
                '--enable-metrics': 'true',
                '--additional-python-modules': 'aws-xray-sdk==2.12.0',
                '--disable-proxy-v2': 'true', // https://docs.aws.amazon.com/glue/latest/dg/connection-VPC-disable-proxy.html
                '--ENVIRONMENT': stackConfig.environmentKey,
                '--AWS_REGION': stackConfig.awsEnv.region as string,
                '--ACCOUNT_ID': stackConfig.awsEnv.account as string,
                '--APP_ENV': stackConfig.environmentKey,

                '--DESTINATION_DATA_BUCKET': saveReconDataBucket.bucketName,
                '--DESTINATION_FOLDER': stackConfig.DestinationFolder,
                '--REDSHIFT_HOSTNAME': stackConfig.RedshiftHostname,
                '--REDSHIFT_PORT': stackConfig.RedshiftPort,
                '--REDSHIFT_DBNAME': stackConfig.RedshiftDBname,
                '--GRSIPREFIX': `${grsiPrefix}`,
                '--IAM_ROLE': `${config.lambdaRoleName}`,
                '--REDSHIFT_CONNECTION_NAME': stackConfig.RedshiftGlueConnectionName,
                '--HEADERDYNAMO_TABLE': stackConfig.DynamoDbHeaderTableName,
                //'--REDSHIFT_HOSTNAME': stackConfig.RedshiftHostname,
                //'--REDSHIFT_PORT': stackConfig.RedshiftPort,

                // Tags for output files
                '--ORGANIZATION_GUID': `${stackConfig.stackTags.organization_guid}`,
                '--LM_TROUX_UID': `${stackConfig.stackTags.lm_troux_uid}`,
                '--ARTIFACT_GUID': `${stackConfig.stackTags.artifact_guid}`,
                '--DEPLOYMENT_GUID': `${stackConfig.stackTags.deployment_guid}`,
            },
        });





        // const redshiftConnection = new Connection(this, 'RedshiftConnection', {
        //     connectionName: stackConfig.RedshiftGlueConnectionName,
        //     type: ConnectionType.JDBC,
        //     properties: {
        //         //HOST: stackConfig.RedshiftHostname,
        //         //PORT: stackConfig.RedshiftPort,
        //         IAM_ROLE: `arn:aws:iam::${stackConfig.awsEnv.account}:role/${config.lambdaRoleName}`,
        //     },
        //     // subnet: Subnet.fromSubnetAttributes(this, 'SaveReconSubnetRedShiftLookup', {
        //     //     subnetId: vpcLookup.subnetIds[0],
        //     //     availabilityZone: vpcLookup.availabilityZones[0],
        //     // }),
        //     // securityGroups: [glueSecurityGroup],
        // });

        // glueJobRole.node.addDependency(redshiftConnection);

        // const securityConfig: SecurityConfiguration = new SecurityConfiguration(this, 'SecurityConfiguration', {
        //     securityConfigurationName: `${grsiPrefix}-save-recon-security-config-${stackConfig.environmentKey}`,
        //     cloudWatchEncryption: {
        //         mode: CloudWatchEncryptionMode.KMS,
        //         kmsKey: SaveReconDataBucketKey,
        //     },
        //     jobBookmarksEncryption: {
        //         mode: JobBookmarksEncryptionMode.CLIENT_SIDE_KMS,
        //         kmsKey: SaveReconDataBucketKey,
        //     },
        //     s3Encryption: {
        //         mode: S3EncryptionMode.KMS,
        //         kmsKey: SaveReconDataBucketKey,
        //     },
        // });

        // const lmTrouxUidBoundary = ManagedPolicy.fromManagedPolicyName(
        //     this,
        //     'CloudServicesPbLmTrouxUidAccess',
        //     `cloud-services/${LmPermissionsBoundaryType.TROUX_UUID}`,
        // );

        // //Add Permission Boundary
        // const SaveReconGluePB = new ManagedPolicy(this, 'serviceUserLmigPBActionsPolicy', {
        //     managedPolicyName: stackConfig.glueJobPBName,
        //     path: '/permission-boundary/',
        //     statements: [
        //         new PolicyStatement({
        //             actions: ['s3:GetObject*', 's3:DeleteObject', 's3:PutObject*'],
        //             resources: [`arn:aws:s3:::${stackConfig.SaveReconDataBucketName}/*`],
        //         }),
        //         new PolicyStatement({
        //             actions: ['s3:GetObject*'],
        //             resources: [`arn:aws:s3:::${stackConfig.glueScriptBucketName}/*`],
        //         }),
        //         new PolicyStatement({
        //             actions: ['kms:Decrypt', 'kms:DescribeKey'],
        //             resources: [glueKey.keyArn],
        //         }),
        //         new PolicyStatement({
        //             actions: ['logs:*'],
        //             resources: [
        //                 `arn:aws:logs:${stackConfig.awsEnv.region as string}:${
        //                     stackConfig.awsEnv.account as string
        //                 }:log-group:grsi-dp*`,
        //                 `arn:aws:logs:${stackConfig.awsEnv.region as string}:${
        //                     stackConfig.awsEnv.account as string
        //                 }:log-group:/aws-glue/*`,
        //             ],
        //         }),
        //         new PolicyStatement({
        //             actions: [
        //                 'Glue:GetSecurityConfiguration*',
        //                 's3:GetBucketLocation',
        //                 's3:ListBucket',
        //                 's3:ListAllMyBuckets',
        //                 's3:GetBucketAcl',
        //                 'ec2:DescribeVpcEndpoints',
        //                 'ec2:DescribeRouteTables',
        //                 'ec2:CreateNetworkInterface',
        //                 'ec2:DeleteNetworkInterface',
        //                 'ec2:DescribeNetworkInterfaces',
        //                 'ec2:DescribeSecurityGroups',
        //                 'ec2:DescribeSubnets',
        //                 'ec2:DescribeVpcAttribute',
        //                 'iam:ListRolePolicies',
        //                 'iam:GetRole',
        //                 'iam:GetRolePolicy',
        //                 'cloudwatch:PutMetricData',
        //             ],
        //             resources: ['*'],
        //         }),
        //         new PolicyStatement({
        //             actions: ['s3:GetObject'],
        //             resources: ['arn:aws:s3:::crawler-public*', 'arn:aws:s3:::aws-glue-*'],
        //         }),
        //         new PolicyStatement({
        //             actions: ['logs:CreateLogGroup', 'logs:CreateLogStream', 'logs:PutLogEvents'],
        //             resources: ['arn:aws:logs:*:*:*:/aws-glue/*'],
        //         }),
        //         new PolicyStatement({
        //             actions: ['ec2:CreateTags', 'ec2:DeleteTags'],
        //             conditions: {
        //                 'ForAllValues:StringEquals': {
        //                     'aws:TagKeys': ['aws-glue-service-resource'],
        //                 },
        //             },
        //             resources: [
        //                 'arn:aws:ec2:*:*:network-interface/*',
        //                 'arn:aws:ec2:*:*:security-group/*',
        //                 'arn:aws:ec2:*:*:instance/*',
        //             ],
        //         }),
        //         new PolicyStatement({
        //             actions: ['glue:StartJobRun', 'glue:BatchStopJobRun'],
        //             resources: [
        //                 `arn:aws:glue:${stackConfig.awsEnv.region as string}:${
        //                     stackConfig.awsEnv.account as string
        //                 }:job/${glueJobName}`,
        //             ],
        //         }),
        //         // new PolicyStatement({
        //         //   actions: ['glue:*Database*', 'glue:*Table*'],
        //         //   resources: [
        //         //     `arn:aws:glue:${stackConfig.awsEnv.region as string}:${
        //         //       stackConfig.awsEnv.account as string
        //         //     }:database/${SaveReconLoadDatabaseName}`,
        //         //     `arn:aws:glue:${stackConfig.awsEnv.region as string}:${
        //         //       stackConfig.awsEnv.account as string
        //         //     }:table/${SaveReconLoadDatabaseName}/*`,
        //         //     'arn:aws:glue:*:*:catalog',
        //         //     'arn:aws:glue:*:*:catalog/*',
        //         //   ],
        //         // }),
        //         // new PolicyStatement({
        //         //   actions: ['glue:StartTrigger', 'glue:UpdateTrigger'],
        //         //   resources: [
        //         //     `arn:aws:glue:${stackConfig.awsEnv.region as string}:${
        //         //       stackConfig.awsEnv.account as string
        //         //     }:trigger/${crawlerTriggerName}`,
        //         //     `arn:aws:glue:${stackConfig.awsEnv.region as string}:${
        //         //       stackConfig.awsEnv.account as string
        //         //     }:trigger/${jobTriggerName}`,
        //         //   ],
        //         // }),
        //         new PolicyStatement({
        //             actions: ['Glue:GetConnection'],
        //             resources: [
        //                 `arn:aws:glue:${config.awsRegion}:${config.awsAccount}:connection/GeniusAnalyticalRep-RDS-${SaveReconEnv}`,
        //                 `arn:aws:glue:${config.awsRegion}:${config.awsAccount}:catalog`,
        //                 `arn:aws:glue:${config.awsRegion}:${config.awsAccount}:catalog/*`,
        //                 `arn:aws:glue:${config.awsRegion}:${config.awsAccount}:connection/${vpcConnectionName}`,
        //             ],
        //         }),
        //     ],
        // });

        // Tags.of(SaveReconGluePB).add('aws_iam_permission_boundary_exempt', 'CustomAwaitingApproval');
        // Tags.of(SaveReconGluePB).add('deployment_guid', config.stackTags.deployment_guid);

        // new ApplyTagsToResourceCustomResource(this, 'TagServiceUserLmigPBActions', {
        //     resource: SaveReconGluePB,
        //     tags: {},
        // }).node.addDependency(SaveReconGluePB);

        // glueJobRole.node.addDependency(SaveReconGluePB);
        // PermissionsBoundary.of(glueJobRole).apply(SaveReconGluePB);

        // // Importing Redshift Cluster
        // const RedShiftCluster = Redshift.Cluster.fromClusterAttributes(this, 'ExistingRedshiftCluster', {
        //     clusterName: 'my-existing-cluster',
        //     clusterEndpointAddress: stackConfig.RedshiftHostname,
        //     clusterEndpointPort: 5439,
        //     iamRoles: [RedshiftRole.roleArn],
        // });

        //RedshiftAlfa.Cluster.fromClusterAttributes

        //AssignRole to Redshift
        //Redshift.Cluster.
        // RedShiftCluster.node.addDependency(
        //     RedshiftRole
        // )

        // glueScriptBucket.addToResourcePolicy(
        //     new PolicyStatement({
        //         actions: ['s3:PutObject', 's3:ListBucket', 's3:GetObject*'],
        //         principals: [
        //             new ArnPrincipal(
        //                 `arn:aws:iam::${stackConfig.awsEnv.account}:role/cloud-services/pipeline-deployment-guid-access`,
        //             ),
        //         ],
        //         resources: [`arn:aws:s3:::${stackConfig.glueScriptBucketName}/*`],
        //         conditions: {
        //             StringEquals: {
        //                 's3:RequestObjectTag/deployment_guid': stackConfig.stackTags.deployment_guid,
        //             },
        //             'ForAllValues:StringEquals': {
        //                 's3:RequestObjectTag/deployment_guid': ['${aws:PrincipalTag/deployment_guid}'],
        //             },
        //         },
        //     }),
        // );

        // const RedshiftConnection = new Connection(this, 'Connection', {
        //     connectionName: RedshiftConnName,
        //     type: ConnectionType.JDBC,
        //     subnet: Subnet.fromSubnetAttributes(this, 'RedShiftSubnetLookup', {
        //         subnetId: vpcLookup.subnetIds[0],
        //         availabilityZone: vpcLookup.availabilityZones[0],
        //     }),
        //     securityGroups: [glueSecurityGroup],
        //     properties: {
        //         REDSHIFT_HOST: `${stackConfig.RedshiftHostname}`,
        //         REDSHIFT_PORT: `${stackConfig.RedshiftPort}`,
        //         // USERNAME: `${stackConfig.RedshiftUserName}`,
        //         // PASSWORD: `${stackConfig.RedshiftPassword}`,
        //     },
        // });

        // Job Trigger - temporary not
        // const jobTrigger = new CfnTrigger(this, 'SaveReconGlueJobTrigger', {
        //   name: jobTriggerName,
        //   type: 'CONDITIONAL',
        //   actions: [
        //     {
        //       jobName: SaveReconLoadJob.jobName,
        //       securityConfiguration: securityConfig.securityConfigurationName,
        //     },
        //   ],
        //   predicate: {
        //     conditions: [
        //       {
        //         logicalOperator: 'EQUALS',
        //         crawlerName: crawlerName,
        //         crawlState: 'SUCCEEDED',
        //       },
        //     ],
        //     logical: 'ANY',
        //   },
        //   // While it may seem like this will force it to run immediately, really it just makes the trigger available
        //   startOnCreation: true,
        // });

        //For running the glue job
        // const glueUser = new User(this, 'glueUser', {
        //     userName: stackConfig.glueUserName,
        //     permissionsBoundary: lmTrouxUidBoundary,
        // });
        // glueUser.stack.tags.setTag('aws_iam_permission_boundary_exempt', 'CUSTOM');

        // glueUser.addToPolicy(
        //     new PolicyStatement({
        //         actions: ['iam:GetRole', 'iam:PassRole'],
        //         resources: [glueJobRole.roleArn],
        //     }),
        // );

        // glueUser.addToPolicy(
        //     new PolicyStatement({
        //         actions: ['glue:StartJobRun', 'glue:BatchStopJobRun'],
        //         resources: [SaveReconGlueJob.jobArn],
        //     }),
        // );

        // glueUser.addToPolicy(
        //   new PolicyStatement({
        //     actions: ['glue:StartCrawler'],
        //     resources: [
        //       `arn:aws:glue:${stackConfig.awsEnv.region as string}:${
        //         stackConfig.awsEnv.account as string
        //       }:crawler/${crawlerName}`,
        //     ],
        //   }),
        // );

        // glueUser.addToPolicy(
        //   new PolicyStatement({
        //     actions: ['glue:StartTrigger', 'glue:UpdateTrigger'],
        //     resources: [
        //       `arn:aws:glue:${stackConfig.awsEnv.region as string}:${stackConfig.awsEnv.account as string}:trigger/${
        //         crawlerTrigger.ref
        //       }`,
        //       `arn:aws:glue:${stackConfig.awsEnv.region as string}:${stackConfig.awsEnv.account as string}:trigger/${
        //         jobTrigger.ref
        //       }`,
        //     ],
        //   }),
        // );

        // const glueUserCreds = new SecretPapiRotateIamUserAccessKeysCustomResource(this, 'GlueUserAccessKeys', {
        //     userName: glueUser.userName,
        //     secretName: glueUser.userName,
        //     papiIndex: config.secrets.papiIndex,
        //     vaultToken: config.secrets.vaultToken,
        // });
        // glueUserCreds.node.addDependency(glueUser);
    }
}
