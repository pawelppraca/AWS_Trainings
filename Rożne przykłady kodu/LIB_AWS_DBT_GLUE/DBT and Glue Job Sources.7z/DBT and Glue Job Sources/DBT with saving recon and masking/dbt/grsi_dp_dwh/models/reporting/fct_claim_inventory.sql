{{
    generate_cte([
        {"table": "claim", "alias": "claim", "columns": ["claim_key","policy_key","date_claim_created"]},
        {"table": "claim_profile_history", "alias": "claim_profile_history", "columns": ["claim_key","current_claim_status_key","previous_claim_status_key","current_claim_handler_key","__effective_from_date"]},
        {"table": "claim_status", "alias": "claim_status_source", "columns": ["claim_status_key","claim_status"]}
    ])
}},
inventory as (
    select
        claim.policy_key,
        claim.claim_key,
        cph.current_claim_handler_key,
        cph.__effective_from_date as movement_date,
        case
            when claim.date_claim_created is not null then 1
            else 0
        end as claims_created_count,
        case
            when cph.__effective_from_date is not null and crnt_clm_sts.claim_status = 'Opened' then 1
            else 0
        end as claims_opened_count,
        case
            when cph.__effective_from_date is not null and crnt_clm_sts.claim_status = 'Closed' then 1
            else 0
        end as claims_closed_count,
        case
            when cph.__effective_from_date is not null and crnt_clm_sts.claim_status = 'Reopened' then 1
            else 0
        end as claims_reopened_count
    from claim
    inner join claim_profile_history as cph
        on claim.claim_key = cph.claim_key
    inner join claim_status_source as crnt_clm_sts
        on cph.current_claim_status_key = crnt_clm_sts.claim_status_key
),
final as (
    select
        row_number() over (order by movement_date)::bigint as id,
        inventory.policy_key as dim_policy_key,
        inventory.claim_key as dim_claim_key,
        inventory.current_claim_handler_key as dim_claim_handler_key,
        {{ get_date_key('movement_date') }} as movement_date_key,
        inventory.claims_created_count,
        inventory.claims_opened_count,
        inventory.claims_closed_count,
        inventory.claims_reopened_count
    from inventory
)
select *
from final