{{
    generate_cte(
        [
            {"table": "location_id", "alias": "location_id"}
        ]
    )
}},
final AS (
    select
        location_id_key,
        location_id,
        claim_key,
        __source_system_code,
        __data_region,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'location_id_key']) }} as __global_location_id_key
    from location_id
)
select *
from final