{{ generate_staging_model('staging_reference', 'zhc2_missing_values') }}
