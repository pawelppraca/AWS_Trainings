{{
    generate_cte(
        [
            {"table": "staging_warehouse_repository_limits", "alias": "limits", 
                "columns": [
                    "limitkey",
                    "policykey",
                    "originalcurrencycode",
                    "qualifiercode",
                    "qualifiername",
                    "limitoriginalcurrency",
                    "premium",
                    "deductibleoriginalcurrency",
					"_currentflag",
					"_effectivefrom",
					"_effectiveto",
					"_lastaction",
                    "_mergekey",
                    "_sequencenumber",
                    "_mergekey_policies",
                    "_sourcesystemcode"
                    ]
            },
            {"table": "staging_warehouse_repository_policies", "alias": "risk", "columns": ["policykey"]}
        ]
    )
}},
cvrg_src as (
    select
        'Unknown'        as coverage_number,
        limits.limitkey                as wr_limitkey,
        limits.policykey               as wr_policykey,
	    limits.originalcurrencycode	as coverage_currency_code,
	    limits.qualifiercode			as coverage_code,
	    limits.qualifiername			as coverage_name,
	    limits.limitoriginalcurrency	as coverage_whole_limit,
	    limits.premium				    as coverage_whole_premium,
	    limits.deductibleoriginalcurrency  as deductible_amount,
		limits._currentflag,
		limits._effectivefrom,
		limits._effectiveto,
		limits._lastaction,
        limits._mergekey,
        limits._sequencenumber,
	    limits._mergekey_policies,
	    limits._sourcesystemcode as __source_system_code,
        limits.__extraction_date_time,
        limits.__load_id,
        limits.__data_region,
        right(left(replace(limits._mergekey, '][', '|'), 29), 28) as __merge_key,
        right(left(replace(limits._mergekey_policies, '][', '|'), 25), 24) as __mergekey_policies
    from limits as limits
    inner join risk as risk
    on limits.policykey = risk.policykey
    qualify row_number() over (partition by limits._mergekey order by limits._sequencenumber desc) = 1
),
final as (
    select
	    coverage_currency_code,
	    coverage_code,
	    coverage_name,
	    coverage_whole_limit,
	    coverage_whole_premium,
	    deductible_amount,
        __mergekey_policies as __risk_merge_key,
		_currentflag,
		_effectivefrom,
		_effectiveto,
		_lastaction,
        _mergekey,
        _sequencenumber,
	    _mergekey_policies,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region,
        __merge_key,
        row_number() over (partition by __merge_key order by __extraction_date_time desc) as __record_version,
        wr_limitkey,
        wr_policykey,
        coverage_number
    from cvrg_src
)
select *
from final