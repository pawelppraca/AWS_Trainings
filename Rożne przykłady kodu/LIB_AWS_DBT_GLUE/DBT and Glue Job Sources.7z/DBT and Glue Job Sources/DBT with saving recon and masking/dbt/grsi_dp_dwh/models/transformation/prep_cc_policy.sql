{{
    generate_cte(
        [
            {"table": "staging_claim_center_cc_policy", "alias": "cc_policy"},
        ], override_error_check=True
    )
}},
final as (
    SELECT 
        *,
        UPPER(split_part(ext_policyreference,'-', 1))::varchar(6) as policy_master_number,
        split_part(ext_policyreference,'-', 2)::varchar(3) as policy_master_sequence,
        'GENIUS'::VARCHAR(255) as __policy_source_system_code
    FROM cc_policy
)
select *
from final
