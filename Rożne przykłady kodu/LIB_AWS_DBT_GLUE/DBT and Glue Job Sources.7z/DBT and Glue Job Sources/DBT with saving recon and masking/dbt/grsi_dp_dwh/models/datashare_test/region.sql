
{% if env_var('REGION') == 'eu-west-1' %}
    {{ config(post_hook="alter datashare grsi_dp_eu_{{env_var('ENVIRONMENT')}}_eu add table datashare_test.region;") }}
{% else %}
    {{ config(post_hook="alter datashare grsi_dp_us_{{env_var('ENVIRONMENT')}}_us add table datashare_test.region;") }}
{% endif %}

select
'{{env_var("REGION","REGION_NOT_FOUND")}}'::varchar as regions