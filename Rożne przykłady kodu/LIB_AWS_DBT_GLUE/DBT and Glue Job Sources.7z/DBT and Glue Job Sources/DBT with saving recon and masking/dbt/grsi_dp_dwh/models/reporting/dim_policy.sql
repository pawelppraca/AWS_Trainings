{{
    generate_cte(
        [
            {"table": "policy", "alias": "policy"}
        ]
    )
}},
final as (
    select
		policy_key,
		broker_key,
		branch_code,
		product_name,
		underwriter_code,
		underwriter_name,
		uw_assistant_code,
		uw_assistant_name,
		risk_engineer_code,
		risk_engineer_name,
		uw_office_key,
		wr_broker_key,
		broker_contact_name,
		inception_date_key,
		policy_status,
		policy_status_detail_code,
		policy_status_detail,
		attachment_type_code,
		attachment_type,
		new_business_renewal,
		direct_assumed,
		lead_or_follow,
		expiry_date,
		policy_master_number,
		policy_sequence_number,
		policy_number,
		policy_reference,
		policy_title,
		policy_written_date_key,
		program_name,
		project_name,
		reassured_name,
		reassured_code,
		lgs_company,
		lgs_company_code,
		year_of_account,
		leader_name,
		leader_policy_ref,
		leader_administers_premiums_flag,
		leader_administers_claims_flag,
        wr_policy_detail_key,
        __source_system_code,
        __data_region,
        __merge_key,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'policy_key']) }} as __global_policy_key
    from policy
)
select *
from final