{{
    generate_cte(
        [
            {"table": "prep_claim_power_generation_final", "alias": "prep_claim_power_generation_final"},
        ]
    )
}},
source_data AS (
    
    select  
        ROW_NUMBER() OVER (ORDER BY __extraction_date_time)::bigint AS claim_power_generation_key,
        *
    from prep_claim_power_generation_final
    where __record_version = 1
),
{{
    generate_unknown_member_cte(
        target_model="prep_claim_power_generation_final",
        surrogate_key_column="claim_power_generation_key"
    )
}},
final AS (
    select * from source_data
    union all
    select * from unknown_member
)
select *
from final

