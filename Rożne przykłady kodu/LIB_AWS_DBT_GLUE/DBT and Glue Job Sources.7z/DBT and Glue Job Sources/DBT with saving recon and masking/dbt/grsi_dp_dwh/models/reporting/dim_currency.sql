{{
    generate_cte(
        [
            {"table": "currency", "alias": "currency"}
        ]
    )
}},
final AS (
    
    select
        currency_key,
        currency_code,
        currency_name,
        __source_system_code,
        __data_region,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'currency_key']) }} as __global_currency_key
    from currency

)
select *
from final