{{
    generate_cte(
        [
            {"table": "prep_loss_location_final", "alias": "prep_loss_location_final"},
        ]
    )
}},
source_data as (
    select
        row_number() over (order by __extraction_date_time)::bigint as loss_location_key,
        prep_loss_location_final.*
    from prep_loss_location_final
    where __record_version = 1
),
{{
    generate_unknown_member_cte(
        target_model="prep_loss_location_final",
        surrogate_key_column="loss_location_key"
    )
}},
loss_locations as (
    select * from source_data
    union all
    select * from unknown_member
),
final as (
    select
        loss_location_key,
        address_line_1,
        address_line_2,
        address_line_3,
        address_line_4,
        address_line_5,
        city,
        state_name,
        country_name,
        post_code,
        __source_system_code,
        __data_region,
        __merge_key
    from loss_locations
)
select *
from final

