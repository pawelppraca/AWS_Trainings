
{{
    generate_cte(
        [
            {"table": "staging_claim_center_cc_catastrophe", "alias": "catastrophe_source", "columns":["id","pcscatastrophenumber","name","description","catastrophevalidfrom","catastrophevalidto","__data_region","__source_system_code","__extraction_date_time","__load_id"]}
        ]
    )
}},
final as (
    select
        pcscatastrophenumber as catastrophe_code,
        name as catastrophe_name,
        description as catastrophe_description,
        catastrophevalidfrom as catastrophe_valid_from,
        catastrophevalidto as catastrophe_valid_to,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region,
        {{
                    generate_merge_key(
                        [
                            "__source_system_code",
                            "id::text"
                        ],
                    )
                }} as __merge_key,
        row_number() over (
                partition by __merge_key order by __extraction_date_time desc
            ) as __record_version
    from catastrophe_source
)
select *
from final