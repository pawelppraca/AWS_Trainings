{{
    generate_cte(
        [
            {"table": "prep_cc_history_claim", "alias": "cc_history", "columns":["claimid", "type", "exposureid", "eventtimestamp", "userid", "matterid"]},
            {"table": "staging_claim_center_cc_claim", "alias": "cc_claim", "columns":["id", "claim_number", "policyid", "state", "createuserid", "createtime", "updatetime", "retired"]},
            {"table": "staging_claim_center_cc_claim_log", "alias": "cc_claim_log", "columns":["id", "claimnumber", "createuserid", "createtime", "updatetime", "beanversion", "state", "policyid", "retired"]},
            {"table": "staging_claim_center_cctl_historytype", "alias": "history_type", "columns":["id", "name"]},
            {"table": "staging_claim_center_cc_policy", "alias": "cc_policy", "columns":["id", "policynumber", "ext_policyorigin", "verified"]},
            {"table": "staging_claim_center_cctl_ext_policyorigin", "alias": "policy_origin", "columns":["id", "name"]},
            {"table": "staging_claim_center_cc_user", "alias": "cc_user", "columns":["id", "contactid"]},
            {"table": "staging_claim_center_cc_contact", "alias": "cc_contact", "columns":["id", "publicid", "firstname", "lastname"]},
        ]
    )
}},
policy AS (
        SELECT
                cc_policy.*
        FROM cc_policy
        LEFT JOIN policy_origin
                ON cc_policy.__load_id = policy_origin.__load_id
                AND NVL(cc_policy.ext_policyorigin,'10001') = policy_origin.id
        WHERE UPPER(LEFT(TRIM(cc_policy.policynumber), 7)) <> 'PLCY-CC'
        AND UPPER(policy_origin."name") <> 'IRIS'
),
claim AS (
        SELECT
                cc_claim.*
        FROM cc_claim
        WHERE cc_claim."state" <> 1
),
claim_log AS (
         SELECT
                cc_claim_log.*
        FROM cc_claim_log
),
tpa_contacts AS (
        SELECT 
                u.id AS user_id,
                c.publicid,
                c.firstname,
                c.lastname,
                c.__source_system_code
        FROM cc_contact c
        INNER JOIN cc_user u
                ON c.__load_id = u.__load_id
                AND c.id = u.contactid
        WHERE UPPER(LEFT(TRIM(c.firstname), 3)) = 'TPA'
        OR UPPER(LEFT(TRIM(c.lastname), 3)) = 'TPA'
        OR UPPER(TRIM(c.firstname)) = 'LONDON MARKET'
),
history_events AS (
        SELECT
                'cc_history' AS query_source,
                cc_history.claimid AS claim_id,
                claim.claim_number AS claim_number,
                UPPER(history_type."name") AS claim_status,
                cc_history.eventtimestamp as event_timestamp,
                cc_history.userid as posted_by_user_id,
                cc_history.__source_system_code,
                cc_history.__extraction_date_time,
                cc_history.__load_id,
                cc_history.__data_region
        FROM cc_history
        INNER JOIN history_type
                ON cc_history.__load_id = history_type.__load_id
                AND cc_history."type" = history_type.id
        LEFT JOIN claim
                ON cc_history.__load_id = claim.__load_id
                AND cc_history.claimid = claim.id
        WHERE cc_history."type" IN (15, 10, 18)
),
log_open_events AS (
        SELECT 
                'claim_log' AS query_source,
                current_claim.id AS claim_id,
                current_claim.claimnumber AS claim_number,
                'OPENED' AS claim_status,
                CASE WHEN previous_policy.verified = 0
                        THEN current_claim.createtime
                        ELSE current_claim.updatetime END as event_timestamp,
                current_claim.createuserid AS posted_by_user_id,
                current_claim.__source_system_code,
                current_claim.__extraction_date_time,
                current_claim.__load_id,
                current_claim.__data_region
        FROM claim_log AS current_claim
        INNER JOIN claim_log AS previous_claim
                ON current_claim.__load_id = previous_claim.__load_id
                AND current_claim.ID = previous_claim.ID
                AND current_claim.beanversion = previous_claim.beanversion + 1 
        INNER JOIN policy AS current_policy
                ON current_claim.__load_id = current_policy.__load_id
                AND current_claim.policyid = current_policy.id
        INNER JOIN policy AS previous_policy
                ON previous_claim.__load_id = previous_policy.__load_id
                AND previous_claim.policyid = previous_policy.id      
        WHERE NVL(current_claim.retired,0) = 0
        AND current_claim."state" <> 1
        AND (
                (previous_claim."state" = 1 AND current_policy.verified = 1) 
                OR 
                (current_policy.verified = 1 AND previous_policy.verified = 0)
        ) 
),
tpa_open_events AS (
        SELECT
                'tpa' AS query_source,
                claim.id AS claim_id,
                claim.claim_number,
                'OPENED' AS claim_status,
                claim.createtime as event_timestamp,
                claim.createuserid AS posted_by_user_id,
                claim.__source_system_code,
                claim.__extraction_date_time,
                claim.__load_id,
                claim.__data_region
        FROM claim
        INNER JOIN policy
                ON claim.__load_id = policy.__load_id
                AND claim.policyid = policy.id 
        INNER JOIN tpa_contacts
                ON claim.createuserid = tpa_contacts.user_id
        WHERE claim.retired = 0
),
all_open_events AS (
        SELECT 
                *,
                1 AS _precedence
        FROM history_events
        WHERE claim_status = 'OPENED' 
        UNION ALL
        SELECT 
                *,
                2 AS _precedence
        FROM log_open_events
        UNION ALL
        SELECT 
                *,
                3 AS _precedence
        FROM tpa_open_events
),
open_events AS (
        SELECT
                query_source,
                claim_id,
                claim_number,
                claim_status,
                event_timestamp,
                posted_by_user_id,
                row_number() over (partition by __load_id, claim_id order by date_trunc('second', event_timestamp) asc, _precedence ASC) as event_number,
                __source_system_code,
                __extraction_date_time,
                __load_id,
                __data_region
        FROM all_open_events
),
final AS (
        SELECT 
                query_source,
                claim_id,
                claim_number,
                claim_status,
                event_timestamp,
                posted_by_user_id,
                __source_system_code,
                __extraction_date_time,
                __load_id,
                __data_region
        FROM open_events
        WHERE event_number = 1
        UNION
        SELECT 
                query_source,
                claim_id,
                claim_number,
                claim_status,
                event_timestamp,
                posted_by_user_id,
                __source_system_code,
                __extraction_date_time,
                __load_id,
                __data_region
        FROM history_events
        WHERE claim_status <> 'OPENED'    
)
SELECT 
        claim_id,
        claim_number,
        claim_status,
        event_timestamp,
        posted_by_user_id,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region
FROM final