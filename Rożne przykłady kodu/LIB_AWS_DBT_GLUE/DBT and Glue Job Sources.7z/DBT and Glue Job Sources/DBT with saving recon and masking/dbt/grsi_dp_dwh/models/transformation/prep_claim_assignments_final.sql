{{
    generate_cte(
        [
            {"table": "staging_claim_center_cc_claim_log", "alias": "cc_claim_log", "columns":["id", "claimnumber", "assigneduserid", "assignedbyuserid", "assignedgroupid", "updatetime"]}
        ]
    )
}},
final AS (
        SELECT
                {{
                        generate_merge_key(
                                [
                                "__source_system_code",
                                "claimnumber",
                                ], preserve_nulls=True
                )
                }} as __claim_merge_key,
                {{
                        generate_merge_key(
                                [
                                "__source_system_code",
                                "assigneduserid",
                                ], preserve_nulls=True
                )
                }} as __assigned_to_merge_key,
                {{
                        generate_merge_key(
                                [
                                "__source_system_code",
                                "assignedbyuserid",
                                ], preserve_nulls=True
                )
                }} as __assigned_by_merge_key,
                {{
                        generate_merge_key(
                                [
                                "__source_system_code",
                                "assignedgroupid",
                                ], preserve_nulls=True
                ) 
                }} as __assigned_group_merge_key,
                updatetime AS event_timestamp,
                __source_system_code,
                __extraction_date_time,
                __load_id,
                __data_region
        FROM cc_claim_log
)
SELECT *
FROM final