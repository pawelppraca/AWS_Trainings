{{
    generate_cte(
        [
            {"table": "claim_handler", "alias": "claim_handler"}
        ]
    )
}},
final AS (
    
    select
        claim_handler_key, 
        first_name, 
        last_name, 
        full_name, 
        __source_system_code,
        __data_region,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'claim_handler_key']) }} as __global_claim_handler_key
    from claim_handler

)
select *
from final