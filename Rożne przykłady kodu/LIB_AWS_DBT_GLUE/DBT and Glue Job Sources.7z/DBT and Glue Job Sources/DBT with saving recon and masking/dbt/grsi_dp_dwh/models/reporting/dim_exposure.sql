{{
    generate_cte(
        [
            {"table": "exposure", "alias": "exposure"}
        ]
    )
}},
final AS (

    select
        exposure_key,
        claim_key,
        coverage_key,
        exposure_currency_code_key,
        created_by_claim_handler_key,
        assigned_to_claim_handler_key,
        assigned_by_claim_handler_key,
        updated_by_claim_handler_key,
        assigned_group_key,
        exposure_number,
        claimant,
        claimant_type,
        exposure_closed_outcome,
        exposure_created_date,
        {{ get_date_key('exposure_created_date') }} as exposure_created_date_key,
        exposure_type,
        exposure_description,
        iso_jurisdiction,
        iso_status,
        loss_transfer_flag,
        exposure_state,
        __source_system_code,
        __data_region,
        __merge_key,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'exposure_key']) }} as __global_exposure_key
    from exposure
)
select *
from final