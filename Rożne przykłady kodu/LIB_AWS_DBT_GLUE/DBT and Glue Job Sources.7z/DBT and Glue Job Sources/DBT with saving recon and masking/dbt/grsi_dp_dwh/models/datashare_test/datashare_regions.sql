select * from {{ ref('region') }}

union all

{% if env_var('REGION') == 'eu-west-1' %}
    select * from grsi_dp_datashare_us_{{env_var("ENVIRONMENT")}}.datashare_test.region
{% else %}
    select * from grsi_dp_datashare_eu_{{env_var("ENVIRONMENT")}}.datashare_test.region
{% endif %}