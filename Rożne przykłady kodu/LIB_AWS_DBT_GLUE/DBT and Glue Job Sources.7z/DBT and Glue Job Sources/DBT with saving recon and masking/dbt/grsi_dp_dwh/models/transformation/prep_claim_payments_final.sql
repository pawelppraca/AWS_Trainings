{{
    generate_cte(
        [
            {"table": "staging_genius_zara", "alias": "genius_payment_request", "columns":["payment_surrogate_num","request_currency_code","payment_date","payment_type_code","payment_status","payment_ref","payee_name_code","claim_master_code","claim_section_code","claim_trans_header_code","created_user","payment_amount","__data_region","__source_system_code","__extraction_date_time","__load_id"]},
            {"table": "staging_genius_zkfa", "alias": "genius_clm_master", "columns":["claim_master_code", "claim_master_number", "claim_master_seq", "claim_number"]},
            {"table": "staging_genius_zkg", "alias": "genius_clm_trans_header", "columns":["payee_name_code","claim_master_code","claim_section_code","claim_trans_header_code","posting_date","genius_user_id","transaction_type_code","original_currency_code","claim_trans_ref","policy_master_number","policy_master_sequence","outstanding_status","authorisation_status","__data_region","__source_system_code","__extraction_date_time","__load_id"]},
            {"table": "staging_genius_zkg3", "alias": "genius_clm_trans_amt", "columns":["claim_master_code","claim_section_code","claim_trans_header_code","movement_amt_orig","trans_type_indicator","claim_movement_type_1_code","clm_order","amount_retained_flag","__load_id"]},
            {"table": "staging_genius_zkt8", "alias": "genius_users_table", "columns":["full_name","user_id"]},
            {"table": "staging_genius_znna", "alias": "genius_names", "columns":["name_code","list_name"]},
            {"table": "staging_genius_znnc", "alias": "genius_company_detail", "columns":["company_name_code","legal_name"]},
            {"table": "staging_genius_zuma", "alias": "genius_master_underwriting", "columns":["master_number","master_sequence"]},
            {"table": "prep_claim_filtered", "alias": "cc_claim", "columns":["id", "claim_number","retired"]},
            {"table": "staging_claim_center_cc_activity", "alias": "cc_activity", "columns":["claimid","assignmentdate","closedate","transactionsetid","retired","assigneduserid"]},
            {"table": "staging_claim_center_cc_address", "alias": "cc_address", "columns":["id","country"]},
            {"table": "staging_claim_center_cc_check", "alias": "cc_check", "columns":["id", "ext_invoicereceiptdate","ext_datepaymentreceivedpt","retired","paymentmethod","invoicenumber","mailtoaddress","mailingaddressid","ext_dateinvoicereceived"]},
            {"table": "staging_claim_center_cc_contact", "alias": "cc_contact", "columns":["id","retired","publicid"]},
            {"table": "staging_claim_center_cctl_country", "alias": "country", "columns":["id","name"]},
            {"table": "staging_claim_center_cctl_paymentmethod", "alias": "payment_method", "columns":["id","name"]},
            {"table": "staging_claim_center_cc_transaction", "alias": "cc_transaction", "columns":["checkid","createuserid","claimid","ext_gwtransactionid","ext_tdupayment","retired","transactionsetid","updatetime"]},
            {"table": "staging_claim_center_cc_transactionset", "alias": "cc_transactionset", "columns":["id","claimid","retired","approvaldate"]},
            {"table": "staging_claim_center_cc_user", "alias": "cc_user", "columns":["id","retired","contactid"]},
        ]
    )
}},
cc_clm_trans as (
    select
        claims.id as claimid,
        claims.claim_number,
        transactions.ext_gwtransactionid,
        transactions.createuserid,
        transactions.transactionsetid,
        transactions.checkid,
        transactions.__load_id,
        claims.__source_system_code
    from cc_claim as claims
    left outer join cc_transaction as transactions
        on transactions.claimid = claims.id
        and transactions.__load_id = claims.__load_id
        and claims.retired=0
    where transactions.ext_gwtransactionid is not null
        and transactions.ext_tdupayment is not null
        and transactions.retired = 0
    qualify row_number()
        over (partition by claims.id, transactions.ext_gwtransactionid order by transactions.updatetime desc) = 1
),
transactions as (
    select
        cc_clm_trans.claim_number,
        cc_clm_trans.ext_gwtransactionid,
        contact.publicid,
        transaction_set.approvaldate as paymentapproveddate,
        activity.assignmentdate as date_payment_sent_to_handler_for_review,
        activity.closedate as date_handler_advised_processor_to_process_payment,
        final_approve_contact.lastname +', '+final_approve_contact.firstname as final_approver,
        checks.ext_datepaymentreceivedpt as date_payment_received_by_processor,
        checks.ext_dateinvoicereceived as date_invoice_received,
        transaction_set.approvaldate as payment_approved_date,
        checks.invoicenumber as payee_ref,
        checks.mailtoaddress as payee_address,
        country.name as payee_location,
        payment_method.name as payment_method,
        cc_clm_trans.__source_system_code
    from cc_clm_trans
    left outer join cc_user
        on cc_clm_trans.createuserid = cc_user.id
        and cc_user.retired=0
    left outer join cc_contact as contact
        on cc_user.contactid = contact.id
        and cc_clm_trans.__load_id = cc_user.__load_id
        and contact.retired=0
    left join cc_transactionset as transaction_set
        on cc_clm_trans.claimid = transaction_set.claimid
        and cc_clm_trans.transactionsetid=transaction_set.id
        and cc_clm_trans.__load_id = transaction_set.__load_id
        and transaction_set.retired = 0
    left outer join cc_activity as activity
        on  activity.transactionsetid = transaction_set.id
        and cc_clm_trans.__load_id = activity.__load_id
        and activity.retired = 0
    left join cc_check as checks
        on cc_clm_trans.checkid = checks.id
        and cc_clm_trans.__load_id = checks.__load_id
        and checks.retired = 0
    left join payment_method
        on payment_method.id = checks.paymentmethod
    left join cc_address as address
        on address.id = checks.mailingaddressid
        and cc_clm_trans.__load_id = address.__load_id
    left outer join cc_user as final_approve_user
        on activity.assigneduserid = final_approve_user.id
        and cc_user.retired=0
	left outer join staging_claim_center_bilz.cc_contact as final_approve_contact
        on final_approve_user.contactid =	final_approve_contact.id
        and contact.retired=0
    left join country
        on address.country = country.id
),
payments as (
    select
        nvl(company_detail.legal_name, genius_names.list_name) as payee_name,
        case when coalesce (company_detail.legal_name, genius_names.list_name, null) is null then true else false end as payment_flag,
       {{ convert_genius_date_to_iso("pymnt_rqst.payment_date") }} as payment_posted_date,
        case
            when pymnt_rqst.payment_type_code = 'ACC' then 'A/C Entry'
            when pymnt_rqst.payment_type_code = 'CCQ' then 'Computer Cheque'
            when pymnt_rqst.payment_type_code = 'MAN' then 'Manual Cheque'
            when pymnt_rqst.payment_type_code = 'TDU' then 'TDU'
            else pymnt_rqst.payment_type_code end as payment_type,
        pymnt_rqst.payment_amount as total_payment_amount,
        pymnt_rqst.created_user as created_by_claim_handler_key,
        transactions.date_invoice_received,
        transactions.date_payment_received_by_processor,
        transactions.date_payment_sent_to_handler_for_review,
        transactions.date_handler_advised_processor_to_process_payment,
        transactions.payment_approved_date,
        transactions.final_approver,
        transactions.payment_method,
        transactions.payee_ref,
        transactions.payee_address,
        transactions.payee_location,
        ('GENIUS|' || pymnt_rqst.payment_surrogate_num) as __merge_key,
        {{ generate_merge_key(["pymnt_rqst.request_currency_code"]) }} as __currency_merge_key,
        ('CLAIM_CENTER|' || clm_mstr.claim_number) as __claim_merge_key,
        pymnt_rqst.__data_region,
        pymnt_rqst.__source_system_code,
        pymnt_rqst.__extraction_date_time,
        pymnt_rqst.__load_id
    from genius_payment_request as pymnt_rqst
    left outer join genius_clm_trans_header as clm_trns_hdr
        on pymnt_rqst.claim_master_code = clm_trns_hdr.claim_master_code
        and pymnt_rqst.claim_section_code = clm_trns_hdr.claim_section_code
        and pymnt_rqst.claim_trans_header_code = clm_trns_hdr.claim_trans_header_code
    inner join genius_clm_master as clm_mstr
        on clm_mstr.claim_master_code = clm_trns_hdr.claim_master_code
    left outer join transactions
        on transactions.claim_number = clm_mstr.claim_number
        and clm_trns_hdr.claim_trans_ref = transactions.ext_gwtransactionid
    left outer join genius_master_underwriting as mstr_undrwrt
        on mstr_undrwrt.master_number = clm_trns_hdr.policy_master_number
        and mstr_undrwrt.master_sequence = clm_trns_hdr.policy_master_sequence
    left outer join genius_company_detail as company_detail
        on pymnt_rqst.payee_name_code = company_detail.company_name_code
    left outer join genius_names
        on pymnt_rqst.payee_name_code = genius_names.name_code
    left outer join genius_users_table as genius_users
        on pymnt_rqst.created_user = genius_users.user_id
    left join payment_method
        on payment_method.id = transactions.payment_method
    where clm_trns_hdr.outstanding_status in ('1', '5', '')
        and clm_trns_hdr.authorisation_status in ('1', '3')
),
recoveries as (
    select
        coalesce(company_detail.legal_name, genius_names.list_name, null) as payee_name,
        case when coalesce (company_detail.legal_name, genius_names.list_name, null) is null then true else false end as payment_flag,
        {{ convert_genius_date_to_iso("clm_trns_hdr.posting_date") }},
        'Recovery' as payment_type,
        trans_amt.movement_amt_orig as total_payment_amount,
        clm_trns_hdr.genius_user_id as created_by_claim_handler_key,
        transactions.date_invoice_received,
        transactions.date_payment_received_by_processor,
        transactions.date_payment_sent_to_handler_for_review,
        transactions.date_handler_advised_processor_to_process_payment,
        transactions.payment_approved_date,
        transactions.final_approver,
        transactions.payment_method,
        transactions.payee_ref,
        transactions.payee_address,
        transactions.payee_location,
        'GENIUSREC|'+convert(varchar(10),clm_trns_hdr.claim_master_code)+'|'+convert(varchar(10),clm_trns_hdr.claim_section_code)+'|'+convert(varchar(10),clm_trns_hdr.claim_trans_header_code) as __merge_key,
        {{ generate_merge_key(["clm_trns_hdr.original_currency_code"]) }} as __currency_merge_key,
        ('CLAIM_CENTER|' || clm_mstr.claim_number) as __claim_merge_key,
        clm_trns_hdr.__data_region,
        clm_trns_hdr.__source_system_code,
        clm_trns_hdr.__extraction_date_time,
        clm_trns_hdr.__load_id
    from genius_clm_trans_header as clm_trns_hdr
    left join genius_clm_master as clm_mstr
        on clm_trns_hdr.claim_master_code = clm_mstr.claim_master_code
    left join transactions
        on  clm_mstr.claim_number = transactions.claim_number
    left outer join genius_company_detail as company_detail
        on clm_trns_hdr.payee_name_code = company_detail.company_name_code
    left outer join genius_names
        on clm_trns_hdr.payee_name_code = genius_names.name_code
    left outer join genius_users_table
        on clm_trns_hdr.genius_user_id = genius_users_table.user_id
    left join genius_clm_trans_amt as trans_amt
        on clm_trns_hdr.claim_master_code = trans_amt.claim_master_code
        and clm_trns_hdr.claim_section_code = trans_amt.claim_section_code
        and clm_trns_hdr.claim_trans_header_code = trans_amt.claim_trans_header_code
    where trans_amt.trans_type_indicator = 1
        and trans_amt.clm_order <> '2'
        and trans_amt.claim_movement_type_1_code = 'REC'
),
payments_union as(
    select * from payments
    union all
    select * from recoveries
),
final as (
    select
        payee_name,
        payment_flag,
        payment_posted_date,
        payment_type,
        total_payment_amount,
        created_by_claim_handler_key,
        date_invoice_received,
        date_payment_received_by_processor,
        date_payment_sent_to_handler_for_review,
        date_handler_advised_processor_to_process_payment,
        payment_approved_date,
        final_approver,
        payment_method,
        payee_ref,
        payee_address,
        payee_location,
        __currency_merge_key,
        __claim_merge_key,
        __merge_key,
        __data_region,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        row_number() over (
                partition by __merge_key order by __extraction_date_time desc
            ) as __record_version
    from payments_union
)
select *
from final