{{
    generate_cte(
        [
            {"table": "prep_cc_policy", "alias": "cc_policy", "columns":["id", "policy_master_number", "policy_master_sequence", "policynumber"]},
            {"table": "staging_genius_zkg3", "alias": "genius_clm_trans_amt", "columns":["claim_master_code", "claim_section_code", "claim_trans_header_code", "trans_type_indicator", "claim_movement_type_1_code", "claim_movement_type_2_code", "movement_amt_orig", "movement_amt_acc", "movement_amt_base", "amount_retained_flag"]},
            {"table": "staging_genius_zkg", "alias": "genius_clm_trans_header", "columns":["claim_master_code", "claim_section_code", "claim_trans_header_code", "claim_trans_ref", "posting_date", "reporting_period", "entry_date", "transaction_date", "accounting_currency_code", "original_currency_code", "policy_master_number", "policy_master_sequence", "ri_master_number", "ri_master_sequence", "genius_user_id","outstanding_status","authorisation_status"]},
            {"table": "staging_genius_zkfa", "alias": "genius_clm_master", "columns":["claim_master_code", "claim_master_number", "claim_master_seq", "claim_number"]},
            {"table": "staging_genius_zuma", "alias": "genius_policy_master", "columns":["master_number", "master_sequence", "master_minor_type_code"]},
            {"table": "staging_genius_zara", "alias": "genius_payment_request", "columns":["claim_master_code", "claim_section_code", "claim_trans_header_code", "created_user", "lastupdateddate","payment_surrogate_num","payment_sequence"]},
            {"table": "staging_claim_center_cc_claim", "alias": "cc_claim", "columns":["id", "claim_number","policyid","ext_policyreference"]},
            {"table": "staging_claim_center_cc_exposure", "alias": "cc_exposure", "columns":["id", "claimid"]},
            {"table": "staging_claim_center_cc_transaction", "alias": "cc_transaction", "columns":["id", "claimid", "ext_gwtransactionid", "ext_deductrecreductreason", "createuserid", "updatetime"]},
            {"table": "staging_claim_center_cctl_ext_deductrecreductreason", "alias": "cc_recovery_reasons", "columns":["id", "name"]},
            {"table": "staging_warehouse_repository_policies", "alias": "repo_policy", "columns": ["policyreference","policykey","_mergekey"]},
            {"table": "staging_warehouse_repository_limits", "alias": "repo_limits", "columns": ["policykey","_mergekey"]}
        ]
    )
}},
cc_clm_trans as (
    select
        ct.id,
        clm.claim_number,
        exp.id as exposure_id,
        ct.ext_gwtransactionid,
        ct.ext_deductrecreductreason,
        ct.createuserid,
        plcy.__policy_source_system_code,
        right(left(replace(repo_policy._mergekey, '][', '|'), 25), 24) as __risk_merge_key,
        right(left(replace(repo_limits._mergekey, '][', '|'), 29), 28) as __coverage_merge_key,
        ct.__load_id,
        clm.__source_system_code as __claim_source_system_code
    from cc_transaction as ct
    inner join cc_claim as clm
        on ct.claimid = clm.id and ct.__load_id = clm.__load_id
    inner join cc_exposure as exp
        on clm.id = exp.claimid
        and clm.__load_id = exp.__load_id
    left outer join cc_policy as plcy
        on clm.policyid = plcy.id
        and clm.__load_id = plcy.__load_id
    left outer join repo_policy
        on repo_policy.policyreference = clm.ext_policyreference
    left outer join repo_limits
        on repo_limits.policykey = repo_policy.policykey
    where ct.ext_gwtransactionid is not null
    qualify row_number() 
        over (partition by clm.id, ct.ext_gwtransactionid order by  ct.updatetime desc) = 1 
),
payment_request as (
    select
        claim_master_code,
        claim_section_code,
        claim_trans_header_code,
        payment_surrogate_num,
        created_user,
        __load_id
    from genius_payment_request as pymnt_rqst
    qualify row_number()
        over (partition by pymnt_rqst.claim_master_code, pymnt_rqst.claim_section_code, pymnt_rqst.claim_trans_header_code order by pymnt_rqst.payment_sequence desc) = 1
),
trans_header as (
    select
        hdr.claim_master_code,
        hdr.claim_section_code,
        hdr.claim_trans_header_code,
        hdr.claim_trans_ref,
        hdr.posting_date,
        hdr.reporting_period,
        hdr.accounting_currency_code,
        hdr.original_currency_code,
        hdr.policy_master_number,
        hdr.policy_master_sequence,
        hdr.ri_master_number,
        hdr.ri_master_sequence,
        hdr.genius_user_id,
        hdr.outstanding_status,
        hdr.authorisation_status,
        hdr.__source_system_code,
        hdr.__extraction_date_time,
        hdr.__load_id,
        hdr.__data_region,
        case
            when upper(left(hdr.genius_user_id, 3)) = 'ESB'
            then hdr.entry_date
            else hdr.transaction_date
        end as transaction_date,
        genius_clm.claim_number
    from genius_clm_trans_header as hdr
    inner join genius_clm_master as genius_clm
        on hdr.claim_master_code = genius_clm.claim_master_code
        and hdr.__load_id = genius_clm.__load_id
    --Filter out any claim transactions in Genius that have no matching claim in Claim Center
    inner join cc_claim
        on  genius_clm.claim_number = cc_claim.claim_number
        and genius_clm.__load_id = cc_claim.__load_id
),
claims_transaction_base as (
    select
        trans_hdr.claim_number,
        trans_hdr.claim_trans_ref,
        cc_clm_trans.exposure_id,
        case
            when nullif(trans_hdr.ri_master_number, '') is null
            then policy.master_minor_type_code
            else 'CED'
        end as ri_code,
        case
            trans_amt.trans_type_indicator when 1 then 'PMT' else 'RSV'
        end as transaction_type,
        trans_amt.trans_type_indicator,
        trans_hdr.claim_master_code,
        trans_hdr.claim_section_code,
        trans_hdr.claim_trans_header_code,
        pay_request.payment_surrogate_num,
        coalesce(
                cast(cc_clm_trans.createuserid as varchar(255)),
                pay_request.created_user,
                trans_hdr.genius_user_id
            ) as created_by,
        trans_amt.claim_movement_type_1_code,
        trans_amt.claim_movement_type_2_code,
        nvl(nullif(trim(cc_recovery_reasons."name"), ''), 'NA') as recovery_reason,
        trans_hdr.accounting_currency_code as local_currency_code,
        trans_hdr.original_currency_code,
        'USD'::text as group_currency_code,
        {{ convert_genius_date_to_iso("trans_hdr.posting_date") }} as posting_date,
        {{ convert_genius_date_to_iso("trans_hdr.transaction_date") }} as transaction_date,
        to_date(((190000 + reporting_period) * 100 + 1), 'yyyymmdd') as fiscal_date,
        trans_amt.movement_amt_orig as trans_amount_original,
        trans_amt.movement_amt_acc as trans_amount_local,
        trans_amt.movement_amt_base as trans_amount_group,
        case
            trans_amt.trans_type_indicator
            when 1
            then trans_amt.movement_amt_orig
            else 0
        end as paid_amount_original,
        case
            trans_amt.trans_type_indicator
            when 0
            then trans_amt.movement_amt_orig
            else 0
        end as outstanding_amount_original,
        case when len(trans_hdr.ri_master_number) > 1
            then {{ generate_merge_key(["trans_hdr.ri_master_number","trans_hdr.ri_master_sequence"]) }}
            else 'NA'
        end as __ri_agreement_merge_key,
        cc_clm_trans.__risk_merge_key,
        cc_clm_trans.__coverage_merge_key,
        trans_hdr.__source_system_code,
        trans_hdr.__extraction_date_time,
        trans_hdr.__load_id,
        trans_hdr.__data_region,
--      not every claim in genius is also in CC so make sure where there is no match set to CLAIM_CENTER to generate valid merge key
        coalesce(cc_clm_trans.__claim_source_system_code, 'CLAIM_CENTER') as __claim_source_system_code
    from trans_header as trans_hdr
    inner join
        genius_clm_trans_amt as trans_amt
        on trans_hdr.claim_master_code = trans_amt.claim_master_code
        and trans_hdr.claim_section_code = trans_amt.claim_section_code
        and trans_hdr.claim_trans_header_code = trans_amt.claim_trans_header_code
        and trans_hdr.__load_id = trans_amt.__load_id
    left outer join
        cc_clm_trans
        on trans_hdr.claim_number = cc_clm_trans.claim_number
        and trans_hdr.claim_trans_ref = cc_clm_trans.ext_gwtransactionid
        and trans_hdr.__load_id = cc_clm_trans.__load_id
    left outer join
        cc_recovery_reasons
        on cc_clm_trans.ext_deductrecreductreason = cc_recovery_reasons.id
        and cc_clm_trans.__load_id = cc_recovery_reasons.__load_id
    left outer join
        genius_policy_master as policy
        on trans_hdr.policy_master_number = policy.master_number
        and trans_hdr.policy_master_sequence = policy.master_sequence
        and trans_hdr.__load_id = policy.__load_id
    left outer join
        payment_request as pay_request
        on trans_amt.claim_master_code = pay_request.claim_master_code
        and trans_amt.claim_section_code = pay_request.claim_section_code
        and trans_amt.claim_trans_header_code = pay_request.claim_trans_header_code
        and trans_amt.__load_id = pay_request.__load_id
    where
        trans_hdr.outstanding_status IN ('1', '5','')
        and trans_hdr.authorisation_status IN ('1', '3')
        and trans_amt.amount_retained_flag <> '2'
),
final as (
    select
        claim_number,
        claim_trans_ref,
        ri_code,
        transaction_type,
        recovery_reason,
        original_currency_code,
        local_currency_code,
        group_currency_code,
        posting_date,
        transaction_date,
        fiscal_date,
        dateadd(month, -1, fiscal_date)::date as previous_fiscal_date,
        trans_amount_original,
        trans_amount_local,
        trans_amount_group,
        paid_amount_original,
        outstanding_amount_original,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region,
        {{generate_merge_key(["__claim_source_system_code", "claim_number"])}} as __claim_merge_key,
        {{generate_merge_key(["__claim_source_system_code", "exposure_id"])}} as __exposure_merge_key,
        __risk_merge_key,
        __coverage_merge_key,
        __ri_agreement_merge_key,
        case
            when trans_type_indicator = 1 and claim_movement_type_1_code = 'REC'
                then 'GENIUSREC|'+
                convert(varchar(10),claim_master_code)+'|'+
                convert(varchar(10),claim_section_code)+'|'+
                convert(varchar(10),claim_trans_header_code)
            when payment_surrogate_num is not null
                then ('GENIUS|' || convert(varchar(100), payment_surrogate_num))
            else 'NA'
        end as __claim_payments_merge_key,
        {{generate_merge_key([
                    "__source_system_code",
                    "claim_movement_type_1_code",
                    "claim_movement_type_2_code",
                    "recovery_reason"
        ])}} as __claim_movement_type_merge_key,
        {{generate_merge_key(["ri_code"])}} as __ri_code_merge_key,
        {{generate_merge_key(["transaction_type"])}} as __transaction_type_merge_key,
        {{generate_merge_key(["__source_system_code","created_by"])}}  as __created_by_claim_handler_merge_key,
        {{ generate_merge_key(['original_currency_code']) }} as __original_currency_merge_key,
        {{ generate_merge_key(['local_currency_code']) }} as __local_currency_merge_key,
        {{ generate_merge_key(['group_currency_code']) }} as __group_currency_merge_key
    from claims_transaction_base
)
select *
from final

