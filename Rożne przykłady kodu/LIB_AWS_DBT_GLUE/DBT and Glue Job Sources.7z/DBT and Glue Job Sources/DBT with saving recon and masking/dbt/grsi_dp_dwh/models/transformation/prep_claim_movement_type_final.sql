{{
    generate_cte(
        [
            {"table": "staging_claim_center_cctl_ext_deductrecreductreason", "alias": "deduct_recovery_reason", "columns":["id", "name"]},
            {"table": "staging_genius_zkfo", "alias": "zkfo", "columns":["fofncd", "fofosd", "fofocd"]},
            {"table": "staging_claim_center_cc_transaction", "alias": "cc_transaction", "columns":["ext_deductrecreductreason"]}
        ]
    )
}},
meta_data as (
   
    select
        __load_id,
        __source_system_code,
        __data_region,
        max(__extraction_date_time) as __extraction_date_time
    from zkfo
    group by __load_id, __source_system_code, __data_region

),
cost_types as (

    select distinct
        __load_id,
        __source_system_code,
        __data_region,
        fofncd as cost_type_code,
        case
            cost_type_code
            when 'IND'
            then 'Indemnity'
            when 'FEE'
            then 'Fee'
            when 'REC'
            then 'Recovery'
            else 'NA'
        end as cost_type_description
    from zkfo

),
cost_categories as (

    select distinct
        __load_id,
        __source_system_code,
        __data_region,
        fofocd as cost_category_code,
        fofosd as cost_category_description
    from zkfo

),
trans_recovery_reasons as (

    select distinct ext_deductrecreductreason, __load_id, __source_system_code, __data_region 
    from cc_transaction

),
recovery_reasons as (

    select
        t.__load_id,
        t.__source_system_code,
        t.__data_region,
        nvl(nullif(trim(ded.name), ''), 'NA') as ded_recovery_rdctn_reason
    from trans_recovery_reasons as t
    inner join
        deduct_recovery_reason as ded
        on t.ext_deductrecreductreason = ded.id
        and t.__load_id = ded.__load_id

),
claim_movement_type as (

    select
        cc.__load_id,
        cc.__source_system_code,
        cc.__data_region,
        cc.cost_category_code,
        cc.cost_category_description,
        ct.cost_type_code,
        ct.cost_type_description,
        rr.ded_recovery_rdctn_reason
    from cost_categories cc
    cross join cost_types ct
    cross join recovery_reasons rr
    where cc.__load_id = ct.__load_id 
    and ct.__load_id = rr.__load_id

),
join_meta_data as (

    select
        res.cost_category_code,
        res.cost_category_description,
        res.cost_type_code,
        res.cost_type_description,
        res.ded_recovery_rdctn_reason,
        res.__source_system_code,
        m.__extraction_date_time,
        res.__load_id,
        res.__data_region,
        {{
            generate_merge_key(
                [
                    "res.__source_system_code",
                    "res.cost_type_code",
                    "res.cost_category_code",
                    "res.ded_recovery_rdctn_reason",
                ],
            )
        }} as __merge_key
    from claim_movement_type res
    inner join
        meta_data m
        on res.__load_id = m.__load_id
        and res.__source_system_code = m.__source_system_code

),
final as (

    select
        row_number() over (
            partition by __merge_key order by __extraction_date_time desc
        ) as __record_version,
        cost_category_code,
        cost_category_description,
        cost_type_code,
        cost_type_description,
        ded_recovery_rdctn_reason,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region,
        __merge_key
    from join_meta_data
    
)
select *
from final
