{{
    generate_cte(
        [
            {"table": "prep_location_id_final", "alias": "prep_location_id_final"},
            {"table": "claim", "alias": "claim", "columns":["claim_key","__merge_key"]},
        ]
    )
}},
source_data as (
    select
        row_number() over (order by __extraction_date_time)::bigint as location_id_key,
        prep_location_id_final.*
    from prep_location_id_final
    where __record_version = 1
),
{{
    generate_unknown_member_cte(
        target_model="prep_location_id_final",
        surrogate_key_column="location_id_key"
    )
}},
location_ids as (
    select * from source_data
    union all
    select * from unknown_member
),
final as (
    select
        location_id_key,
        location_id,
        {{ get_unknown_member_key("claim.claim_key") }} as claim_key,
        location_ids.__source_system_code,
        location_ids.__data_region
    from location_ids
    left join claim
        on claim.__merge_key = location_ids.__claim_merge_key
)
select *
from final

