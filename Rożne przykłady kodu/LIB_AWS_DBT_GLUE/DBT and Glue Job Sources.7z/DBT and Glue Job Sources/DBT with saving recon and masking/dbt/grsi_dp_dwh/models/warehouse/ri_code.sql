{{
    generate_cte(
        [
            {"table": "prep_ri_code_final", "alias": "prep_ri_code_final"}
        ]
    )
}},
source_data AS (
    
    select  
        ROW_NUMBER() OVER (ORDER BY __extraction_date_time)::bigint AS ri_code_key,
        *
    from prep_ri_code_final
    where __record_version = 1
),
{{
    generate_unknown_member_cte(
        target_model="prep_ri_code_final",
        surrogate_key_column="ri_code_key"
    )
}},
final AS (

    select * from source_data
    union all
    select * from unknown_member
)
select 
      ri_code_key,
      ri_type_code,
      ri_type,
      ri_group,
    __source_system_code,
    __extraction_date_time,
    __load_id,
    __data_region,
    __merge_key
from final