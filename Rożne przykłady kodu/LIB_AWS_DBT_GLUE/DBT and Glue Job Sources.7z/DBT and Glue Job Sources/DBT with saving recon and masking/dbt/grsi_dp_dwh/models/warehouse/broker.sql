{{
    generate_cte(
        [
            {"table": "prep_broker_final", "alias": "prep_broker_final"}
        ]
    )
}},
source_data AS (
    
    select  
        ROW_NUMBER() OVER (ORDER BY __extraction_date_time)::bigint AS broker_key,
        *
    from prep_broker_final
    where __record_version = 1
),
{{
    generate_unknown_member_cte(
        target_model="prep_broker_final",
        surrogate_key_column="broker_key"
    )
}},
final AS (

    select * from source_data
    union all
    select * from unknown_member
)
select 
    broker_key,
    broker_code,
    broker_name,
    broker_state,
    broker_country,
    __source_system_code,
    __extraction_date_time,
    __load_id,
    __data_region,
    __merge_key,
    wr_broker_key
from final

