{{
    generate_cte(
        [
            {"table": "claim_construction", "alias": "claim_construction"}
        ]
    )
}},
final AS (

    select
        claim_construction_key,
        phase_of_operation,
        project_phase,
        project_delivery_type,
        __source_system_code,
        __data_region,
        __merge_key,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'claim_construction_key']) }} as __global_claim_construction_key
    from claim_construction

)
select *
from final