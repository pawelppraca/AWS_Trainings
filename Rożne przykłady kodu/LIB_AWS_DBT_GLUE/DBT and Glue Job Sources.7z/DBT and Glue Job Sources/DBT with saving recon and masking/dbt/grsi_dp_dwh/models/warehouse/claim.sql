{{ 
    generate_cte([
        {"table": "prep_claim_final", "alias": "prep_claim_final"},
        {"table": "claim_handler", "alias": "claim_handler", "columns": ["claim_handler_key"]},
        {"table": "claim_handler_group", "alias": "claim_handler_group", "columns": ["claim_handler_group_key"]},
        {"table": "policy", "alias": "policy", "columns":["policy_key","__merge_key"]},
        {"table": "catastrophe", "alias": "catastrophe", "columns":["catastrophe_key","__merge_key"]},
        {"table": "loss_location", "alias": "loss_location", "columns":["loss_location_key","__merge_key"]},
        {"table": "claim_apra", "alias": "claim_apra", "columns":["claim_apra_key","__merge_key"]},
        {"table": "claim_power_generation", "alias": "claim_power_generation", "columns":["claim_power_generation_key","__merge_key"]},
        {"table": "claim_construction", "alias": "claim_construction", "columns":["claim_construction_key","__merge_key"]}
    ])
}},
source_data as (
    select row_number() over (order by __extraction_date_time)::bigint as claim_key, 
    *
    from prep_claim_final
    where __record_version = 1
),
{{
    generate_unknown_member_cte(
        target_model="prep_claim_final",
        surrogate_key_column="claim_key"
    )
}},
all_claims as (

    select *
    from source_data
    union all
    select *
    from unknown_member
),
final as (
    select
        claim.claim_key,
        {{ get_unknown_member_key("policy.policy_key") }} as policy_key,
        {{ get_unknown_member_key("catastrophe.catastrophe_key")}} as catastrophe_key,
        {{ get_unknown_member_key("loss_location.loss_location_key")}} as loss_location_key,
        {{ get_unknown_member_key("claim_power_generation.claim_power_generation_key") }} as claim_power_generation_key,
        {{ get_unknown_member_key("claim_construction.claim_construction_key") }} as claim_construction_key,
        {{ get_unknown_member_key("claim_apra.claim_apra_key") }} as claim_apra_key,
        {{ get_unknown_member_key("created_by_ch.claim_handler_key") }} as created_by_claim_handler_key,
        {{ get_unknown_member_key("assigned_ch.claim_handler_key") }} as assigned_to_claim_handler_key,
        {{ get_unknown_member_key("assigned_by_ch.claim_handler_key") }} as assigned_by_claim_handler_key,
        {{ get_unknown_member_key("updated_by_ch.claim_handler_key") }} as updated_by_claim_handler_key,
        {{ get_unknown_member_key("assigned_group.claim_handler_group_key") }} as assigned_group_key,
        claim.claim_number, 
        claim.event_name, 
        claim.event_description,
        claim.event_code,
        claim.assigned_date, 
        claim.date_claim_created, 
        claim.date_of_loss, 
        claim.date_reported, 
        claim.loss_location, 
        claim.additional_exposure_unverified, 
        claim.alternate_claim_number, 
        claim.claim_description, 
        claim.claim_state, 
        claim.claim_tier, 
        claim.claim_title, 
        claim.claim_type, 
        claim.date_claim_closed, 
        claim.date_last_flagged, 
        claim.date_last_revalued, 
        claim.date_last_updated, 
        claim.date_received, 
        claim.flagged_reason, 
        claim.ground_up_loss_bi_usd, 
        claim.ground_up_loss_pd_usd, 
        claim.ground_up_loss_total_usd, 
        claim.handled_by, 
        claim.in_suit_flag, 
        claim.insurer_risk_reference, 
        claim.is_severity, 
        claim.large_loss_report_flag, 
        claim.post_close_payment_made, 
        claim.reinsurance_reportable, 
        claim.severity, 
        claim.special_claim_permission, 
        claim.tpa_claim_number, 
        claim.unique_claim_reference, 
        claim.cause_of_loss1, 
        claim.cause_of_loss2, 
        claim.cause_of_loss3, 
        claim.cause_of_loss4, 
        claim.cause_of_loss5, 
        claim.cause_of_loss1_other_description, 
        claim.cause_of_loss2_other_description, 
        claim.cause_of_loss3_other_description, 
        claim.cause_of_loss4_other_description, 
        claim.syndicate_cause_code, 
        claim.loss_code_group, 
        claim.cyber_consideration, 
        claim.cyber_consideration_other, 
        claim.ransomware_aspect, 
        claim.claims_organisation,
        claim.syndicate_id,
        claim.fast_track, 
        claim.coverage_indicator, 
        claim.deductible_type, 
        claim.fault_rating, 
        claim.claim_handling_type, 
        claim.claim_how_reported, 
        claim.large_loss_notification_status, 
        claim.iso_loss_location, 
        claim.loss_event, 
        claim.reported_by_type, 
        claim.cargo_type, 
        claim.batched_claim_flag, 
        claim.claim_proceedings_type, 
        claim.subrogation_status,
        claim.block_file,
        claim.loss_fund,
        claim.general_claim_note,
        claim.vulnerable_customer,
        claim.date_coverage_letter_issued,
        claim.external_reference,
        claim.claim_involving_minor_flag,
        claim.multiple_coverages_flag,
        claim.claim_closure_reason,
        claim.latest_ecf_transaction_type,
        claim.__source_system_code,
        claim.__extraction_date_time, 
        claim.__load_id, 
        claim.__data_region, 
        claim.__merge_key 
    from all_claims as claim
    left join claim_handler AS created_by_ch
        on claim.__created_by_merge_key = created_by_ch.__merge_key
    left join claim_handler AS assigned_ch
        on claim.__assigned_to_merge_key = assigned_ch.__merge_key
    left join claim_handler AS assigned_by_ch
        on claim.__assigned_by_merge_key = assigned_by_ch.__merge_key
    left join claim_handler AS updated_by_ch
        on claim.__updated_by_merge_key = updated_by_ch.__merge_key
    left join claim_handler_group AS assigned_group   
        on claim.__assigned_group_merge_key = assigned_group.__merge_key
    left join policy 
        on policy.__merge_key = claim.__policy_merge_key
    left join catastrophe
        on claim.__catastrophe_merge_key = catastrophe.__merge_key
    left join claim_power_generation
        on claim.__claim_power_generation_merge_key = claim_power_generation.__merge_key
    left join loss_location
        on claim.__loss_location_merge_key = loss_location.__merge_key
    left join claim_apra
        on claim.__claim_apra_merge_key = claim_apra.__merge_key
    left join claim_construction
        on claim.__claim_construction_merge_key = claim_construction.__merge_key
)
select *
from final
