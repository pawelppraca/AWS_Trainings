{{ generate_staging_model('staging_reference', 'rtmi_claim_status') }}
