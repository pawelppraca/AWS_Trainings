{{
    generate_cte(
        [
            {"table": "staging_reference_rtmi_claim_status", "alias": "rtmi_claim_status_source", "columns":["claimstatus"]}
        ]
    )
}},
final as (

    select
        row_number() over (
            partition by __merge_key order by __extraction_date_time desc
        ) as __record_version,
        claimstatus as claim_status,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region,
        {{
            generate_merge_key(
                [
                    "claimstatus",
                ],
            )
        }} as __merge_key
    from rtmi_claim_status_source

)
select *
from final
