{{
    generate_cte(
        [
            {"table": "date_dimension", "alias": "dates"}
        ]
    )
}},
final AS (
    
    select
        date_key, 
        date_day, 
        day_number_of_week, 
        english_day_name_of_week, 
        day_number_of_month, 
        day_number_of_year, 
        week_number_of_year, 
        english_month_name, 
        english_full_month_name, 
        english_month_year, 
        month_number_of_year, 
        calendar_year_month, 
        calendar_quarter, 
        calendar_year, 
        calendar_semester, 
        is_last_day_of_month, 
        liberty_fiscal_period,
        liberty_fiscal_year,
        lmie_fiscal_period,
        lmie_fiscal_year, 
        __source_system_code,
        date_key as __global_date_key
    from dates

)
select *
from final