{{
    generate_cte(
        [
            {"table": "staging_genius_zacj", "alias": "zacj", "columns":["cjcucd"]}
        ]
    )
}},
currencies as (
    --TODO: interim solution until RTMI is integrated as a data source
    SELECT DISTINCT
        cjcucd as currency_code,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region
    FROM zacj

),
final as (

    select
        row_number() over (
            partition by __merge_key order by __extraction_date_time desc
        ) as __record_version,
        UPPER(currency_code) as currency_code,
        'NOT IMPLEMENTED YET' as currency_name,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region,
        {{ generate_merge_key(['currency_code']) }} as __merge_key
    from currencies
)
select *
from final
