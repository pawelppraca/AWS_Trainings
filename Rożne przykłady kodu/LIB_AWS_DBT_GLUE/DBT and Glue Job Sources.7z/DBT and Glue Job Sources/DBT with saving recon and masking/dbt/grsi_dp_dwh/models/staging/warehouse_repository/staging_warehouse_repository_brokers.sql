{{ generate_staging_model('staging_warehouse_repository', 'brokers') }}

