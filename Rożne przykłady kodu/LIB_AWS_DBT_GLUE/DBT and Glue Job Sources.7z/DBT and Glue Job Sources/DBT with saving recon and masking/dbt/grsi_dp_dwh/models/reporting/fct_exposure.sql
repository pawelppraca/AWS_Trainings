{{
    generate_cte(
        [
            {"table": "dim_claim", "alias": "claim", "columns": ["claim_key", "policy_key"]},
            {"table": "dim_exposure", "alias": "exposure"},
            {"table": "dim_exposure_history", "alias": "exposure_history", "columns": ["__effective_from_date", "exposure_key", "exposure_status", "previous_exposure_status"]},
            {"table": "risk", "alias": "risk", "columns": ["risk_key", "policy_key"]},
        ]
    )
}},

exposure_with_movement_date AS (
    select
        exposure.*,
        exposure_history.__effective_from_date,
        exposure_history.exposure_status,
        exposure_history.previous_exposure_status,
        {{ get_date_key("exposure_history.__effective_from_date") }} as movement_date_key
    from exposure
    inner join exposure_history
        on exposure.exposure_key = exposure_history.exposure_key
),

measures AS (
    select
        exposure_with_movement_date.*,
        case
            when exposure_with_movement_date.exposure_status ilike 'Open' and exposure_with_movement_date.previous_exposure_status = 'Unknown' then 1
            else 0
        end as exposures_created_count,
        case
            when exposure_with_movement_date.exposure_status ilike 'Closed' then 1
            else 0
        end as exposures_closed_count,
        case
            when exposure_with_movement_date.exposure_status ilike 'Reopened' then 1
            else 0
        end as exposures_reopened_count
    from exposure_with_movement_date
),

final AS (
    select
        claim.policy_key,
        measures.claim_key,
        measures.movement_date_key,
        measures.exposure_key,
        measures.coverage_key,
        risk.risk_key,
        measures.exposure_status,
        measures.previous_exposure_status,
        measures.exposures_created_count,
        measures.exposures_closed_count,
        measures.exposures_reopened_count
    from measures
    inner join claim
        on claim.claim_key = measures.claim_key
    inner join risk
        on claim.policy_key = risk.policy_key
    where measures.exposure_status <> measures.previous_exposure_status
    group by
        claim.policy_key,
        measures.claim_key,
        measures.movement_date_key,
        measures.exposure_key,
        measures.coverage_key,
        risk.risk_key,
        measures.exposure_status,
        measures.previous_exposure_status,
        measures.exposures_created_count,
        measures.exposures_closed_count,
        measures.exposures_reopened_count
)
select *
from final