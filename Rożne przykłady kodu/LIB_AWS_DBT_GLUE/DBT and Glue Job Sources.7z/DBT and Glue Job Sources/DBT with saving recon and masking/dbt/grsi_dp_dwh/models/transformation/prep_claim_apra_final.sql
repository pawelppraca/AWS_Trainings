
{{
    generate_cte(
        [
            {"table": "staging_claim_center_cctl_ext_aprainjury", "alias": "aprainjury", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_apracol", "alias": "apracol", "columns": ["id", "description"]},
            {"table": "staging_claim_center_cctl_ext_apacjurisdiction", "alias": "apacjurisdiction", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_apralitcodes", "alias": "apralitigationcodes", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cctl_extregulatorycode", "alias": "apraregulatorycodes", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cc_claim", "alias": "claim", "columns": ["id", "ext_aprainjury", "ext_apracol", "ext_apacjurisdiction", "ext_apralitcodes", "ext_regulatorycode"]}
        ]
    )
}},

meta_data as (
   
    select
        __load_id,
        __source_system_code,
        __data_region,
        max(__extraction_date_time) as __extraction_date_time
    from apraregulatorycodes
    group by __load_id, __source_system_code, __data_region

),
claim_apra AS (
    SELECT	DISTINCT
		ISNULL(ai.name, 'NA')				AS apra_injury
		, ISNULL(ac.description, 'NA')		AS apra_col
		, ISNULL(aj.name, 'NA')				AS apra_jurisdiction
		, ISNULL(al.name, 'NA')				AS apra_litigation
		, ISNULL(ar.name, 'NA')				AS apra_regulatory
        , c.__source_system_code
        , c.__load_id
        , c.__data_region
    FROM
        claim AS c
        LEFT JOIN aprainjury            AS ai ON ai.ID = c.Ext_APRAinjury
        LEFT JOIN apracol               AS ac ON ac.ID = c.Ext_APRAcol
        LEFT JOIN apacjurisdiction      AS aj ON aj.ID = c.Ext_APACJurisdiction
        LEFT JOIN apralitigationcodes   AS al ON al.ID = c.Ext_APRAlitCodes
        LEFT JOIN apraregulatorycodes   AS ar ON ar.ID = c.Ext_RegulatoryCode
    GROUP BY 
        ISNULL(ai.name, 'NA')
        , ISNULL(ac.description, 'NA')
        , ISNULL(aj.name, 'NA')
        , ISNULL(al.name, 'NA')
        , ISNULL(ar.name, 'NA')
        , c.__source_system_code
        , c.__load_id
        , c.__data_region
),
join_meta_data AS (
    SELECT
        claim_apra.apra_injury,
        claim_apra.apra_col,
        claim_apra.apra_jurisdiction,
        claim_apra.apra_litigation,
        claim_apra.apra_regulatory,
        claim_apra.__source_system_code,
        meta_data.__extraction_date_time,
        claim_apra.__load_id,
        claim_apra.__data_region
    FROM claim_apra
    INNER JOIN meta_data
    ON claim_apra.__load_id = meta_data.__load_id
    AND claim_apra.__source_system_code = meta_data.__source_system_code
    AND claim_apra.__data_region = meta_data.__data_region
),
final AS (
    SELECT
        apra_injury,
        apra_col,
        apra_jurisdiction,
        apra_litigation,
        apra_regulatory,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region,
        {{
            generate_merge_key(
                [
                    "__source_system_code",
                    "apra_injury",
                    "apra_col",
                    "apra_jurisdiction",
                    "apra_litigation",
                    "apra_regulatory",
                ]
            )
        }} AS __merge_key,
        row_number() OVER (
                PARTITION BY __merge_key ORDER BY __extraction_date_time DESC
        ) AS __record_version
    FROM join_meta_data
)
SELECT *
FROM final