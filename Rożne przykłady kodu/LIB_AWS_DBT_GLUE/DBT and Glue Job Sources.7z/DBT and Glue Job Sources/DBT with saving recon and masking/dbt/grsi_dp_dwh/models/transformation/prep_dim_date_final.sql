{{
    generate_cte(
        [
            {"table": "staging_dim_date", "alias": "date_source", "columns":["date_day"]},
        ]
    )
}},
final as (

    select
        date_day::date,
        date_part('dayofweek', date_day)::int as day_number_of_week,
        to_char(date_day, 'Day') as english_day_name_of_week,
        date_part('day', date_day)::int as day_number_of_month,
        date_part('dayofyear', date_day)::int as day_number_of_year,
        date_part('week', date_day)::int as week_number_of_year,
        to_char(date_day, 'Mon') as english_month_name,
        to_char(date_day, 'Month') as english_full_month_name,
        to_char(date_day, 'Mon')
        || ' '
        || to_char(date_day, 'YYYY') as english_month_year,
        date_part('month', date_day)::int as month_number_of_year,
        (to_char(date_day, 'YYYY') || to_char(date_day, 'MM'))::int
        as calendar_year_month,
        date_part('quarter', date_day)::int as calendar_quarter,
        date_part('year', date_day)::int as calendar_year,
        case
            when date_part('quarter', date_day) <= 2 then 1 else 2
        end as calendar_semester,
        case
            when last_day(date_day) = trunc(date_day) then true else false
        end as is_last_day_of_month,
--         coalesce(liberty_fp.period, '') as liberty_fiscal_period,
--         coalesce(left(liberty_fp.period, 4), '') as liberty_fiscal_year,
--         coalesce(lmie_fp.period, '') as lmie_fiscal_period,
--         coalesce(left(lmie_fp.period, 4), '') as lmie_fiscal_year,
        'Unknown' as liberty_fiscal_period,
        'Unknown' as liberty_fiscal_year,
        'Unknown' as lmie_fiscal_period,
        'Unknown' as lmie_fiscal_year,
        __source_system_code,
        __extraction_date_time,
        __load_id
    from date_source
--     left outer join fiscal_period_source liberty_fp
--         on date_source.date_day >= liberty_fp.libertyperiodstartdate
--         and date_source.date_day <= liberty_fp.libertyperiodenddate
--     left outer join fiscal_period_source lmie_fp
--         on date_source.date_day >= lmie_fp.libertyperiodstartdate
--         and date_source.date_day <= lmie_fp.libertyperiodenddate
)
select *
from final
