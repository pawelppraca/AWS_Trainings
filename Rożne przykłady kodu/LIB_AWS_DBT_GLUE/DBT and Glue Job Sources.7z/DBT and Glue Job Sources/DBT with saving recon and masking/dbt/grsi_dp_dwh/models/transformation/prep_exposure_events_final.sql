{{
    generate_cte(
        [
            {"table": "prep_exposure_status_history", "alias": "exposure_status_events"},
            {"table": "prep_cc_history_exposure", "alias": "cc_history", "columns":["exposureid", "eventtimestamp", "userid", "type"]}
        ]
    )
}},

assignment_events as (
        select
                exposureid as exposure_id,
                eventtimestamp as event_timestamp,
                userid as posted_by_user_id,
                __source_system_code,
                __extraction_date_time,
                __load_id,
                __data_region
        from cc_history
        where type = 4
        and exposureid is not null
),
all_events as (
        select
                nvl(e1.exposure_id, e2.exposure_id) as exposure_id,
                e1.exposure_status,
                nvl(e1.event_timestamp, e2.event_timestamp) as event_timestamp,
                nvl(e1.posted_by_user_id, e2.posted_by_user_id) as posted_by_user_id,
                nvl(e1.__source_system_code, e2.__source_system_code) as __source_system_code,
                nvl(e1.__extraction_date_time, e2.__extraction_date_time) as __extraction_date_time,
                nvl(e1.__load_id, e2.__load_id) as __load_id,
                nvl(e1.__data_region, e2.__data_region) as __data_region
        from exposure_status_events e1
        full outer join assignment_events e2
                on  e1.__load_id = e2.__load_id
                and e1.exposure_id = e2.exposure_id
                and e1.event_timestamp = e2.event_timestamp
),
final as (
        select
                {{
                        generate_merge_key(
                                [
                                "__source_system_code",
                                "exposure_id",
                                ], preserve_nulls=true
                )
                }} as __exposure_merge_key,
                ({{
                        generate_merge_key(
                                [
                                "exposure_status"
                                ], preserve_nulls=true
                )
                }}) as __exposure_status_merge_key,
                event_timestamp,
                 {{
                        generate_merge_key(
                                [
                                "__source_system_code",
                                "posted_by_user_id",
                                ], preserve_nulls=true
                )
                }} as __posted_by_merge_key,
                __source_system_code,
                __extraction_date_time,
                __load_id,
                __data_region
        from all_events
)
select *
from final