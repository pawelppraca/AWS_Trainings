{{
    generate_cte(
        [
            {"table": "coverage", "alias": "coverage", "columns": ["coverage_key","coverage_code","risk_key","__merge_key"]},
            {"table": "claim", "alias": "claim", "columns": ["claim_key","policy_key","__merge_key"]},
            {"table": "claim_handler", "alias": "claim_handler", "columns": ["claim_handler_key"]},
            {"table": "claim_handler_group", "alias": "claim_handler_group", "columns": ["claim_handler_group_key"]},
            {"table": "currency", "alias": "currency", "columns": ["currency_key","__merge_key"]},
            {"table": "policy", "alias": "policy", "columns": ["policy_key"]},
            {"table": "prep_business_class_defintion", "alias": "bsns_cls_def"},
            {"table": "prep_exposure_final", "alias": "prep_exposure_final"},
            {"table": "risk", "alias": "risk", "columns": ["lob_description","policy_key","risk_key","risk_number"]},
        ]
    )
}},
source_data AS (
    select  
        ROW_NUMBER() OVER (ORDER BY __extraction_date_time)::bigint AS exposure_key,
        *
    from prep_exposure_final
    where __record_version = 1
),
{{
    generate_unknown_member_cte(
        target_model="prep_exposure_final",
        surrogate_key_column="exposure_key"
    )
}},
exposures as (
    select * from source_data
    union all
    select * from unknown_member
),
coverage_link_prep as (
    select
        coverage.coverage_key,
        coverage.__merge_key,
        risk.risk_number,
        coverage.coverage_code,
        bsns_cls_def.class_long_name
    from coverage
    left join risk
        on risk.risk_key = coverage.risk_key
    left join bsns_cls_def
        on bsns_cls_def.class_short_name = risk.lob_description
),
final as (
    select
        exposures.exposure_key,
        {{ get_unknown_member_key("claim.claim_key")}} as claim_key,
        {{ get_unknown_member_key("coverage.coverage_key")}} as coverage_key,
        {{ get_unknown_member_key("currency.currency_key") }} as exposure_currency_code_key,
        {{ get_unknown_member_key("created_by_ch.claim_handler_key") }} as created_by_claim_handler_key,
        {{ get_unknown_member_key("assigned_ch.claim_handler_key") }} as assigned_to_claim_handler_key,
        {{ get_unknown_member_key("assigned_by_ch.claim_handler_key") }} as assigned_by_claim_handler_key,
        {{ get_unknown_member_key("updated_by_ch.claim_handler_key") }} as updated_by_claim_handler_key,
        {{ get_unknown_member_key("assigned_group.claim_handler_group_key") }} as assigned_group_key,
        exposures.exposure_number,
        exposures.claimant,
        exposures.claimant_type,
        exposures.exposure_closed_outcome,
        exposures.exposure_created_date,
        exposures.exposure_type,
        exposures.exposure_description,
        exposures.iso_jurisdiction,
        exposures.iso_status,
        exposures.loss_transfer_flag,
        exposures.exposure_state,
        exposures.__source_system_code,
        exposures.__extraction_date_time,
        exposures.__load_id,
        exposures.__data_region,
        exposures.__merge_key
        from exposures
        left join claim
            on exposures.__claim_merge_key = claim.__merge_key
        left join currency
            on exposures.__currency_merge_key = currency.__merge_key
        left join claim_handler as created_by_ch
            on exposures.__created_by_merge_key = created_by_ch.__merge_key
        left join claim_handler as assigned_ch
            on exposures.__assigned_to_merge_key = assigned_ch.__merge_key
        left join claim_handler as assigned_by_ch
            on exposures.__assigned_by_merge_key = assigned_by_ch.__merge_key
        left join claim_handler as updated_by_ch
            on exposures.__updated_by_merge_key = updated_by_ch.__merge_key
        left join claim_handler_group as assigned_group
            on exposures.__assigned_group_merge_key = assigned_group.__merge_key
        left join coverage_link_prep as coverage
            on left(exposures.section_detail,3) = right(coverage.risk_number, 3)
            and exposures.coverage_code = coverage.coverage_code
            and upper(exposures.class_long_name) = upper(coverage.class_long_name)
            and exposures.__coverage_merge_key = coverage.__merge_key
)
select *
from final

