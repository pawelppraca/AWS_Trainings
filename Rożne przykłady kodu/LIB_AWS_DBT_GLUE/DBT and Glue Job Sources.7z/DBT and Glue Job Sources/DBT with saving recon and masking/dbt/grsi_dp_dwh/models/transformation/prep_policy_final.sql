{{
    generate_cte(
        [
            {"table": "staging_warehouse_repository_policies", "alias": "policy_source", "columns": ["PolicyKey", "PolicyDetailKey","BranchCode","ProductName","UnderwriterCode","UnderwriterName","UWAssistantCode","UWAssistantName","RiskEngineerCode","RiskEngineerName","UWOfficeKey","BrokerKey","BrokerContactName","InceptionDate","PolicyStatus","PolicyStatusDetailCode","PolicyStatusDetail","AttachementTypecode","AttachmentType","NewBusinessRenewal","DirectAssumed","LeadOrFollow","ExpiryDate","PolicyMasterNumber","PolicyReference","PolicyRenewalNumber","PolicyTitle","PolicyWrittenDate","ProgramName","ProjectName","SurplusLines","InsuredName","InsuredNameCode","ReassuredName","ReassuredNameCode","LGSCompany","LGSCompanyCode","YearOfAccount","LeaderName","LeaderPolicyRef","LeaderAdministersPremiumsFlag","LeaderAdministersClaimsFlag","_MergeKey","_sourcesystemcode","_currentflag"]}
        ]
    )
}},
policy_list as (
	select 
		policydetailkey,
		policymasternumber,
		PolicyRenewalNumber,
		_sourcesystemcode,
		max(policykey) as policykey
	from policy_source
	where _currentflag = 1
	group by policydetailkey, policymasternumber, PolicyRenewalNumber, _sourcesystemcode
),
policies as (

	select
		policymasternumber as policy_master_number,
		(REPLICATE('0', 3-LEN(PolicyRenewalNumber)) || PolicyRenewalNumber::text)::nchar(3) as policy_sequence_number,
		_sourcesystemcode as __source_system_code,
		policydetailkey as wr_policy_detail_key,
		policykey
	from policy_list

),
final as (

	SELECT 
			src.BranchCode as branch_code,
			src.ProductName as product_name,
			src.UnderwriterCode as underwriter_code,
			src.UnderwriterName as underwriter_name,
			src.UWAssistantCode as uw_assistant_code,
			src.UWAssistantName as uw_assistant_name,
			src.RiskEngineerCode as risk_engineer_code,
			src.RiskEngineerName as risk_engineer_name,
			src.UWOfficeKey as uw_office_key,
			src.BrokerKey as wr_broker_key,
			src.BrokerContactName as broker_contact_name,
			--ClaimTriggerCode,		--ZUMA.ClaimTriggerCode/Name needs to be added to dbo.PolicyDetails - LSMDATA-5173
			--ClaimTriggerName,
			src.InceptionDate AS inception_date_key,
			src.PolicyStatus as policy_status,
			src.PolicyStatusDetailCode as policy_status_detail_code,
			src.PolicyStatusDetail as policy_status_detail,
			src.AttachementTypecode as attachment_type_code,
			src.AttachmentType as attachment_type,
			src.NewBusinessRenewal as new_business_renewal,
			src.DirectAssumed as direct_assumed,
			--[FACIndicator],	--this is Risk-level attribute
			src.LeadOrFollow as lead_or_follow,
			src.ExpiryDate as expiry_date,
			pol.policy_master_number,
			pol.policy_sequence_number,
			src.PolicyReference AS policy_number,
			src.PolicyReference as policy_reference,
			src.PolicyTitle as policy_title,
			src.PolicyWrittenDate AS policy_written_date_key,
			src.ProgramName as program_name,
			src.ProjectName as project_name,
			src.SurplusLines as surplus_lines,	--PJD missing for dummy policies, causing duplicates with NULL/<<Unknown>>, solved with ctePJD
			src.InsuredName as insured_name, 	  --data issue/duplication on BI_LZ
			src.InsuredNameCode as insured_code,  --data issue/duplication on BI_LZ
			src.ReassuredName as reassured_name,
			src.ReassuredNameCode as reassured_code,
			src.LGSCompany as lgs_company,
			src.LGSCompanyCode as lgs_company_code,
			src.YearOfAccount as year_of_account,
			--AffiliateCode,	--needs to be added to PolicyDetails, all data is available in ODS_GENIUS - LSMDATA-5174
			--Affiliated	--needs to be added to PolicyDetails, all data is available in ODS_GENIUS - LSMDATA-5174
			src.LeaderName as leader_name,
			src.LeaderPolicyRef as leader_policy_ref,
			src.LeaderAdministersPremiumsFlag as leader_administers_premiums_flag,
			src.LeaderAdministersClaimsFlag as leader_administers_claims_flag,
			src._currentflag,
			{{ generate_merge_key(["pol.__source_system_code", "src.BrokerKey"]) }} as __broker_merge_key,
			pol.__source_system_code,
			src.__extraction_date_time,
			src.__load_id,
			src.__data_region,
			{{
				generate_merge_key(
					[
						"pol.__source_system_code",
						"pol.policy_master_number",
						"pol.policy_sequence_number"

					]
				)
			}} as __merge_key,
			row_number() over (
				partition by __merge_key order by src.__extraction_date_time desc
			) as __record_version,
			pol.wr_policy_detail_key
		from policies as pol
		inner join policy_source as src
        	on pol.policykey = src.policykey
		
)
select *
from final