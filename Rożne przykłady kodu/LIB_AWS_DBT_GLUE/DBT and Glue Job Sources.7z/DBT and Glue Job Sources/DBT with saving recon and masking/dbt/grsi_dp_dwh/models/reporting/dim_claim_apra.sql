{{
    generate_cte(
        [
            {"table": "claim_apra", "alias": "claim_apra"}
        ]
    )
}},
final AS (

    select
        claim_apra_key,
        apra_injury,
        apra_col,
        apra_jurisdiction,
        apra_litigation,
        apra_regulatory,
        __source_system_code,
        __data_region,
        __merge_key,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'claim_apra_key']) }} as __global_claim_apra_key
    from claim_apra

)
select *
from final