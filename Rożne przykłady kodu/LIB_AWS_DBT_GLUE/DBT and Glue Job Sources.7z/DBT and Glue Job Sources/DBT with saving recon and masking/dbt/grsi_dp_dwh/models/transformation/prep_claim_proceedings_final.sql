{{
    generate_cte(
        [
            {"table": "staging_claim_center_cctl_country", "alias": "country", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cctl_state", "alias": "state", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cctl_resolutiontype", "alias": "resolution", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cctl_mattercourtdistrict", "alias": "mattercourtdistrict", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cctl_mattercourttype", "alias": "mattercourttype", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cctl_legalspecialty", "alias": "legalspecialty", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cctl_mattertype", "alias": "mattertype", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cctl_primarycausetype", "alias": "primarycausetype", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cc_contact", "alias": "contact", "columns": ["id", "name", "publicid"]},
            {"table": "staging_claim_center_cc_matter", "alias": "matter", "columns": ["claimid", "name", "country", "ext_state", "assignedbyuserid", "assigneduserid", "assignedgroupid", "createuserid", "casenumber",  "arbitrationdate", "defenseapptdate", "finalsettledate", "hearingdate", "mediationdate", "assignmentdate", "closedate", "createtime", "trialdate", "filedate", "senttodefensedate", "servicedate", "adDamnumAmount", "punitiveamount", "punitivedamages", "responsedue", "responsefiled", "resolution", "courtdistrict", "subrorelated", "addamnumspecified", "ext_courttype", "docketnumber", "finallegalcost", "finalsettlecost", "legalspecialty", "mattertype", "primarycause"]},
            {"table": "staging_claim_center_cc_policy", "alias": "policy", "columns": ["id"]},
            {"table": "staging_claim_center_cc_user", "alias": "cc_user", "columns": ["id", "contactid"]},
            {"table": "staging_claim_center_cc_group", "alias": "cc_group", "columns": ["id", "name"]},
            {"table": "prep_claim_filtered", "alias": "claim", "columns": ["id", "claim_number", "policyid"]}
        ]
    )
}},
claim_proceedings as (
    
    select
    c.id    as claim_key,					
    right(con2.publicid , len(con2.publicid) - charindex(':', con2.publicid ))  as proceeding_assigned_by_claim_handler_key,			
    right(con1.publicid , len(con1.publicid) - charindex(':', con1.publicid ))  as proceeding_assigned_to_claim_handler_key,			
    g.id    as proceeding_assigned_to_claim_handler_group_key,	
    right(con.publicid , len(con.publicid) - charindex(':', con.publicid ))     as proceeding_created_by_claim_handler_group_key,
    cm.casenumber   as case_number,
    cccountry.name	as proceeding_country_name,
    ss.name			as proceeding_state_name,
    cm.arbitrationdate	as arbitration_date,
    cm.defenseapptdate	as defense_appointed_date,
    cm.finalsettledate	as final_settlement_date,
    cm.hearingdate      as hearing_date,
    cm.mediationdate    as mediation_date,
    cm.assignmentdate   as proceeding_assignment_date,
    cm.closedate        as proceeding_close_date,
    cm.createtime       as proceeding_created_date,
    coalesce (cm.trialdate, cm.mediationdate, cm.arbitrationdate, cm.hearingdate) as proceeding_date,
    cm.filedate     as proceeding_start_date,
    cm.senttodefensedate as sent_to_defense_date,
    cm.servicedate  as service_date,
    cm.trialdate    as trial_date,
    cm.addamnumamount   as addamnum_amount,
    cm.punitiveamount   as punitive_damages_amount,
    cm.punitivedamages  as punitive_damages_flag,
    cm.responsedue      as response_due,
    cm.responsefiled    as response_filed,
    (case 
    when 
        coalesce (cm.trialdate, cm.mediationdate, cm.arbitrationdate, cm.hearingdate) < dateadd(day, -90, getdate()) 
        then 'past > 90 days' 
    when 
        coalesce (cm.trialdate, cm.mediationdate, cm.arbitrationdate, cm.hearingdate) >= dateadd(day, -90, getdate()) and
        coalesce (cm.trialdate, cm.mediationdate, cm.arbitrationdate, cm.hearingdate) < getdate()
        then 'past <= 90 days'
    when 
        coalesce (cm.trialdate, cm.mediationdate, cm.arbitrationdate, cm.hearingdate) >= getdate() and
        coalesce (cm.trialdate, cm.mediationdate, cm.arbitrationdate, cm.hearingdate) < dateadd(day, 90, getdate())
        then 'upcoming <= 90 days'
    when 
        coalesce (cm.trialdate, cm.mediationdate, cm.arbitrationdate, cm.hearingdate) >= dateadd(day, 90, getdate())
        then 'upcoming > 90 days'
    else 
        'na'
    end) as proceeding_date_flag,
    rt.name     as proceeding_resolution,
    cmd.name    as proceeding_state,
    cm.subrorelated as proceeding_subro_flag,
    cm.name as proceeding_title,
    cm.addamnumspecified    as addamnum_specified,
    cmd.name    as court_district, 
    ct.name as court_type,
    cm.docketnumber as docket_number,
    cm.finallegalcost   as final_legal_cost,
    cm.finalsettlecost  as final_settlement_cost,
    ls.name as legal_specialty,
    mt.name as matter_type,
    pct.name    as primary_cause,
    c.claim_number,
    c.__source_system_code  as __claim_source_system_code,
    cm.__source_system_code,
    cm.__extraction_date_time,
    cm.__load_id,
    cm.__data_region

    from  matter    as cm 
    left join claim as c on c.id = cm.claimid
    left join mattercourtdistrict   as cmd on cmd.id = cm.courtdistrict
    left join mattercourttype   as ct on ct.id = cm.ext_courttype
    left join legalspecialty    as ls on ls.id = cm.legalspecialty
    left join mattertype    as mt on mt.id = cm.mattertype
    left join policy    as p on p.id = c.policyid
    left join primarycausetype  as pct on pct.id = cm.primarycause
    left join cc_user   as u on cm.createuserid	= u.id
    left join contact   as con on u.contactid = con.id
    left join cc_user   as u1 on cm.assigneduserid	= u1.id
    left join contact   as con1	on u1.contactid	= con1.id
    left join cc_group  as g on cm.assignedgroupid	= g.id
    left join cc_user   as u2 on cm.assignedbyuserid = u2.id
    left join contact   as con2 on u2.contactid	= con2.id
    left join resolution    as rt on rt.id = cm.resolution
    left outer join country as cccountry on cccountry.id = cm.country
    left outer join state   as ss on ss.id = cm.ext_state
),

final as (

    select
    cp.claim_key,
    cp.proceeding_assigned_by_claim_handler_key,
    cp.proceeding_assigned_to_claim_handler_key,
    cp.proceeding_assigned_to_claim_handler_group_key,
    cp.proceeding_created_by_claim_handler_group_key,
    cp.proceeding_country_name,
    cp.proceeding_state_name,
    cp.case_number,
    cp.arbitration_date,
    cp.defense_appointed_date,
    cp.final_settlement_date,
    cp.hearing_date,
    cp.mediation_date,
    cp.proceeding_assignment_date,
    cp.proceeding_close_date,
    cp.proceeding_created_date,
    cp.proceeding_date,
    cp.proceeding_start_date,
    cp.sent_to_defense_date,
    cp.service_date,
    cp.trial_date,
    cp.addamnum_amount,
    cp.punitive_damages_amount,
    cp.punitive_damages_flag,
    cp.response_due,
    cp.response_filed,
    cp.proceeding_date_flag,
    cp.proceeding_resolution,
    cp.proceeding_state,
    cp.proceeding_subro_flag,
    cp.proceeding_title,
    cp.addamnum_specified,
    cp.court_district,
    cp.court_type,
    cp.docket_number,
    cp.final_legal_cost,
    cp.final_settlement_cost,
    cp.legal_specialty,
    cp.matter_type,
    cp.primary_cause,
    {{generate_merge_key(["__claim_source_system_code", "claim_number"])}} as __claim_merge_key,
    {{generate_merge_key(["__source_system_code","proceeding_assigned_by_claim_handler_key"])}} as __assigned_by_claim_handler_merge_key,
    {{generate_merge_key(["__source_system_code","proceeding_assigned_to_claim_handler_key"])}} as __assigned_to_claim_handler_merge_key,
    {{generate_merge_key(["__source_system_code", "proceeding_assigned_to_claim_handler_group_key"])}} as __assigned_to_claim_handler_group_merge_key,
    {{generate_merge_key(["__source_system_code", "proceeding_created_by_claim_handler_group_key"])}} as __created_by_claim_handler_group_merge_key,
    {{generate_merge_key(["__source_system_code", "claim_key"])}} as __merge_key,
    cp.__source_system_code,
    cp.__extraction_date_time,
    cp.__load_id,
    cp.__data_region,
    row_number() over (
            partition by __merge_key order by __extraction_date_time desc
    ) as __record_version
    from claim_proceedings as cp
)

select * 
from final