{{
    generate_cte(
        [
            {"table": "coverage", "alias": "coverage"}
        ]
    )
}},
final as (
    select
        coverage_key,
        risk_key,
	    coverage_currency_code,
	    coverage_code,
	    coverage_name,
	    coverage_whole_limit,
	    coverage_whole_premium,
	    deductible_amount,
        wr_limitkey,
        wr_policykey,
        coverage_number,
        case
            when coverage_code = 'X001'
                then coverage_whole_limit
            else 0.00
        End As excess_of,
        __source_system_code,
        __data_region,
        __merge_key,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'coverage_key']) }} as __global_coverage_key
    from coverage
)
select *
from final