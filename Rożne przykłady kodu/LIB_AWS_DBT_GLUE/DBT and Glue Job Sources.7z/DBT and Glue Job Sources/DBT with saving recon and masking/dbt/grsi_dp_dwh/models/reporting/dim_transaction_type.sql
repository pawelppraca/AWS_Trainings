{{
    generate_cte(
        [
            {"table": "transaction_type", "alias": "trans_type"}
        ]
    )
}},
final AS (
    
    select
        transaction_type_key, 
        transaction_type_code, 
        transaction_type_name, 
        transaction_type_description, 
        transaction_type_category, 
        payment_type, 
        __source_system_code,
        __data_region,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'transaction_type_key']) }} as __global_transaction_type_key
    from trans_type

)
select *
from final