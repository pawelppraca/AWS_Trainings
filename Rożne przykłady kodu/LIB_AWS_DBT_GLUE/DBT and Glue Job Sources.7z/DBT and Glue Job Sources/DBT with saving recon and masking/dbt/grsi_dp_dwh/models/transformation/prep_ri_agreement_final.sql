
{{
    generate_cte(
        [
            {"table": "staging_genius_zuma", "alias": "genius_master_underwriting", "columns":["master_reference","master_number","master_sequence","master_title","master_minor_type_code","inception_date","expiry_date","master_major_type_code","master_product_code","inwards_outwards_flag"]},
            {"table": "staging_genius_zhmj", "alias": "genius_master_major_type", "columns":["master_major_type_desc","master_major_type_code"]},
            {"table": "staging_genius_zhmn", "alias": "genius_master_minor_type", "columns":["master_minor_type_desc","master_minor_type_code"]},
            {"table": "staging_genius_zpks", "alias": "genius_product_version_name", "columns":["product_long_name","product_code"]}
        ]
    )
}},
final as (
    select
	    mstr_undrwrt.master_reference as ri_agreement_genius,
        upper(ltrim(rtrim(
            case
                when not mstr_undrwrt.master_reference like 't%' or charindex('-', mstr_undrwrt.master_reference) = 0
                then cast(mstr_undrwrt.master_reference as nvarchar(20))
                else left(mstr_undrwrt.master_reference, 5) + substring(mstr_undrwrt.master_reference, charindex('-', mstr_undrwrt.master_reference), 10)
            end
        ))) as ri_agreement,
        left(ltrim(rtrim(mstr_undrwrt.master_title)),100) as ri_agreement_title,
        mst_mnr_typ.master_minor_type_desc as ri_class,
        mstr_undrwrt.master_minor_type_code as ri_class_code,
        {{ convert_genius_date_to_iso("mstr_undrwrt.expiry_date") }} as expiry_date,
        {{ convert_genius_date_to_iso("mstr_undrwrt.inception_date") }} as inception_date,
        mst_mjr_typ.master_major_type_desc as ri_type,
        mstr_undrwrt.master_major_type_code as ri_type_code,
        prdct_vrsn_nm.product_long_name as treaty_fac_description,
        mstr_undrwrt.master_product_code as treaty_fac_code,
        {{ generate_merge_key(["mstr_undrwrt.master_number","mstr_undrwrt.master_sequence"]) }} as __merge_key,
        mstr_undrwrt.__source_system_code,
        mstr_undrwrt.__extraction_date_time,
        mstr_undrwrt.__load_id,
        mstr_undrwrt.__data_region,
        row_number() over (
                partition by __merge_key order by mstr_undrwrt.__extraction_date_time desc
        ) as __record_version
    from genius_master_underwriting as mstr_undrwrt
    left outer join genius_master_major_type as mst_mjr_typ on mstr_undrwrt.master_major_type_code = mst_mjr_typ.master_major_type_code
    left outer join genius_master_minor_type as mst_mnr_typ on mstr_undrwrt.master_minor_type_code = mst_mnr_typ.master_minor_type_code
    left outer join genius_product_version_name as prdct_vrsn_nm on mstr_undrwrt.master_product_code = prdct_vrsn_nm.product_code
    where mstr_undrwrt.inwards_outwards_flag = '2'
)
select *
from final