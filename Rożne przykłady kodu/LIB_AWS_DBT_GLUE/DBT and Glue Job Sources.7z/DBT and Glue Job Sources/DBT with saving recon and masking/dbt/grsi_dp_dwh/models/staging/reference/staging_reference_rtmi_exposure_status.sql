{{ generate_staging_model('staging_reference', 'rtmi_exposure_status') }}
