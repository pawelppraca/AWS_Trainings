{{
    generate_cte(
        [
            {"table": "catastrophe", "alias": "catastrophe"}
        ]
    )
}},
final AS (

    select
        catastrophe_key,
        catastrophe_code,
        catastrophe_name,
        catastrophe_description,
        catastrophe_valid_from,
        catastrophe_valid_to,
        __source_system_code,
        __data_region,
        __merge_key,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'catastrophe_key']) }} as __global_catastrophe_key
    from catastrophe

)
select *
from final