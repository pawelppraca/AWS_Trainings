{{
    generate_cte(
        [
            {"table": "prep_claim_storage_final", "alias": "claim_storage"},
            {"table": "claim", "alias": "claim", "columns": ["claim_key", "__merge_key"]}
        ]
    )
}},
source_data AS (
    
    select  
        ROW_NUMBER() OVER (ORDER BY storage.__extraction_date_time)::bigint AS claim_storage_key,
        {{ get_unknown_member_key("c.claim_key") }} as claim_key,
        storage_type,
        storage_box_number,
        storage_notes,
        storage.record_retention_date,
        storage.destruction_date,
        storage.date_sent_to_storage,
        storage.__source_system_code,
        storage.__extraction_date_time,
        storage.__load_id,
        storage.__data_region,
        storage.__merge_key
    from claim_storage as storage
    left outer join claim as c on c.__merge_key = storage.__claim_merge_key
),
{{
    generate_unknown_member_cte(
        target_model="prep_claim_storage_final",
        surrogate_key_column="claim_storage_key"
    )
}},
modified_unknown_member as (
    select 
        claim_storage_key,
        null as claim_key,
        storage_type,
        storage_box_number,
        storage_notes,
        '{{ get_unknown_member_date() }}'::date as record_retention_date,
        '{{ get_unknown_member_date() }}'::date as destruction_date,
        '{{ get_unknown_member_date() }}'::date as date_sent_to_storage,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region,
        __merge_key
    from unknown_member
),
final AS (
    select * from source_data
    union all
    select * from modified_unknown_member
)
select *
from final