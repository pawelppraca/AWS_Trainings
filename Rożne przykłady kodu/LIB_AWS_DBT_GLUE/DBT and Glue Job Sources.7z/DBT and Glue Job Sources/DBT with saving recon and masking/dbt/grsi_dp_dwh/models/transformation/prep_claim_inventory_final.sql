
{{
    generate_cte(
        [
            {"table": "prep_cc_policy", "alias": "policy_source", "columns":["id","policy_master_number", "policy_master_sequence"]},
            {"table": "prep_claim_filtered", "alias": "filtered_claim", "columns":["id","claim_number","policyid","state","retired","createuserid","assigneduserid","assignedbyuserid","updateuserid","assignedgroupid"]},
            {"table": "staging_claim_center_cc_history", "alias": "history_source", "columns":["eventtimestamp","claimid","type","customtype","exposureid","matterid"]},
            {"table": "staging_claim_center_cctl_customhistorytype", "alias": "custom_history_type", "columns":["id","name","description"]},
            {"table": "staging_claim_center_cctl_historytype", "alias": "history_type", "columns":["id","name","description"]}
        ]
    )
}},
final as (
    select
        history.eventtimestamp as inventory_movement_date,
        case
            when history_type.id = 11
                then custom_history_type.name
            else
                history_type.name
        end as inventory_type,
        case
            when history_type.id = 11
                then custom_history_type.description
            else history_type.description
        end as inventory_description,
        {{ generate_merge_key(["claim.__source_system_code", "claim_number"]) }} as __claim_merge_key,
        {{ generate_merge_key(["__policy_source_system_code","policy_master_number", "policy_master_sequence"])}} as __policy_merge_key,
        {{ generate_merge_key(["claim.__source_system_code", "createuserid"]) }} as __created_by_merge_key,
        {{ generate_merge_key(["claim.__source_system_code", "assigneduserid"]) }} as __assigned_to_merge_key,
        {{ generate_merge_key(["claim.__source_system_code", "assignedbyuserid"]) }} as __assigned_by_merge_key,
        {{ generate_merge_key(["claim.__source_system_code", "updateuserid"]) }} as __updated_by_merge_key,
        {{ generate_merge_key(["claim.__source_system_code", "assignedgroupid"]) }} as __assigned_group_merge_key,
        {{ generate_merge_key(["claim.__source_system_code", "__claim_merge_key","__policy_merge_key","inventory_movement_date","inventory_type"]) }} as __merge_key,
        history.__source_system_code,
        history.__extraction_date_time,
        history.__load_id,
        history.__data_region,
        row_number() over (
            partition by __merge_key order by history.__extraction_date_time desc
        ) as __record_version
    from history_source as history
    inner join filtered_claim as claim
        on history.claimid = claim.id
    inner join policy_source as policy
        on claim.policyid = policy.id
    left outer join history_type
        on history_type.id = history.type
    left outer join custom_history_type
        on custom_history_type.id = history.customtype
    where claim.state <> 1
        and claim.retired = 0
        and history.exposureid is null
        and history.matterid is null
        and (history_type.id in (10, 15, 18, 21, 9) or
            (history_type.id = 11 and custom_history_type.id in ( 10003, 10004, 10007, 10014, 10015, 10016, 10019, 10021, 10018)))
)
select *
from final