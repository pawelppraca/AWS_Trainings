{{
    generate_cte(
        [
            {"table": "prep_claim_filtered", "alias": "claim", "columns":["id", "claim_number", "ext_storageboxnum", "ext_storagenotes", "ext_recordretdate", "ext_destructiondate", "storagedate", "storagetype"]},
            {"table": "staging_claim_center_cctl_storagetype", "alias": "storage", "columns": ["id", "name"]}
        ]
    )
}},
final AS (
    SELECT
        ISNULL(st.name, 'NA') AS storage_type,
        ISNULL(c.ext_storageboxnum, 'NA') as storage_box_number,
        ISNULL(c.ext_storagenotes, 'NA') as storage_notes,
        ISNULL(TO_CHAR(CAST(c.ext_recordretdate AS TIMESTAMP), 'YYYY-MM-DD'), '1900-01-01')::date AS record_retention_date,
        ISNULL(TO_CHAR(CAST(c.ext_destructiondate AS TIMESTAMP), 'YYYY-MM-DD'), '1900-01-01')::date AS destruction_date,
        ISNULL(TO_CHAR(CAST(c.storagedate AS TIMESTAMP), 'YYYY-MM-DD'), '1900-01-01')::date AS date_sent_to_storage,
        c.__source_system_code,
        c.__extraction_date_time,
        c.__load_id,
        c.__data_region,
        {{ generate_merge_key(
            [
                "c.__source_system_code",
                "claim_number"
            ]
        ) }} as __claim_merge_key,
        {{ generate_merge_key(
            [
                "c.__source_system_code",
                "c.id"
            ]
        ) 
        }} as __merge_key
    FROM claim AS c
    LEFT OUTER JOIN storage AS st ON c.storagetype = st.id
)
select * 
from final
