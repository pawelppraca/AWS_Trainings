{{
    generate_cte(
        [
            {"table": "ri_agreement", "alias": "ri_agreement"}
        ]
    )
}},
final AS (

    select
        ri_agreement_key,
        ri_agreement_genius,
        ri_agreement,
        ri_agreement_title,
        ri_class,
        ri_class_code,
        expiry_date,
        inception_date,
        ri_type,
        ri_type_code,
        treaty_fac_description,
        treaty_fac_code,
        __source_system_code,
        __data_region,
        __merge_key,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'ri_agreement_key']) }} as __global_ri_agreement_key
    from ri_agreement

)
select *
from final