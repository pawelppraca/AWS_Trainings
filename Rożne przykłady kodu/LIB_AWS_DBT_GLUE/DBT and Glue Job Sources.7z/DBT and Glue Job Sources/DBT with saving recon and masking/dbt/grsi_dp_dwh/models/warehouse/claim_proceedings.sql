{{
    generate_cte(
        [
            {"table": "prep_claim_proceedings_final", "alias": "claim_proceedings"},
            {"table": "claim", "alias": "claim", "columns":["claim_key","assigned_group_key","__merge_key"]},
            {"table": "claim_handler", "alias": "claim_handler", "columns":["claim_handler_key","__merge_key"]},
            {"table": "claim_handler_group", "alias": "claim_handler_group", "columns":["claim_handler_group_key","__merge_key"]}
        ]
    )
}},
source_data AS (
    SELECT
        row_number() over (order by claim_proceedings.__extraction_date_time)::bigint as claim_proceedings_key,
        *
    from claim_proceedings
    where claim_proceedings.__record_version = 1
),
{{
    generate_unknown_member_cte(
        target_model="prep_claim_proceedings_final",
        surrogate_key_column="claim_proceedings_key"
    )
}},
claim_proceedings_unknown AS (
    select * from source_data
    union all
    select * from unknown_member
),
final AS (
    SELECT
        cp.claim_proceedings_key,
        {{ get_unknown_member_key("claim.claim_key") }} as claim_key,
        {{ get_unknown_member_key("assigned_by.claim_handler_key") }} as proceeding_assigned_by_claim_handler_key,
        {{ get_unknown_member_key("assigned_to.claim_handler_key") }} as proceeding_assigned_to_claim_handler_key,
        {{ get_unknown_member_key("assigned_to_group.claim_handler_group_key") }} as proceeding_assigned_to_claim_handler_group_key,
        {{ get_unknown_member_key("created_by_group.claim_handler_group_key") }} as proceeding_created_by_claim_handler_group_key,
        cp.proceeding_country_name,
        cp.proceeding_state_name,
        cp.case_number,
        cp.arbitration_date,
        cp.defense_appointed_date,
        cp.final_settlement_date,
        cp.hearing_date,
        cp.mediation_date,
        cp.proceeding_assignment_date,
        cp.proceeding_close_date,
        cp.proceeding_created_date,
        cp.proceeding_date,
        cp.proceeding_start_date,
        cp.sent_to_defense_date,
        cp.service_date,
        cp.trial_date,
        cp.addamnum_amount,
        cp.punitive_damages_amount,
        cp.punitive_damages_flag,
        cp.response_due,
        cp.response_filed,
        cp.proceeding_date_flag,
        cp.proceeding_resolution,
        cp.proceeding_state,
        cp.proceeding_subro_flag,
        cp.proceeding_title,
        cp.addamnum_specified,
        cp.court_district,
        cp.court_type,
        cp.docket_number,
        cp.final_legal_cost,
        cp.final_settlement_cost,
        cp.legal_specialty,
        cp.matter_type,
        cp.primary_cause,
        cp.__source_system_code,
        cp.__extraction_date_time,
        cp.__load_id,
        cp.__data_region,
        cp.__merge_key,
        cp.__extraction_date_time as __effective_from_date,
        CAST('9999-12-31' as timestamp) AS __effective_to_date,
        true as __is_current
    from claim_proceedings_unknown as cp
    left join claim on claim.__merge_key = cp.__claim_merge_key
    left join claim_handler as assigned_by on assigned_by.__merge_key = cp.__assigned_by_claim_handler_merge_key
    left join claim_handler as assigned_to on assigned_to.__merge_key = cp.__assigned_to_claim_handler_merge_key
    left join claim_handler_group as assigned_to_group on assigned_to_group.__merge_key = cp.__assigned_to_claim_handler_group_merge_key
    left join claim_handler_group as created_by_group on created_by_group.__merge_key = cp.__created_by_claim_handler_group_merge_key
)
select *
from final