{{
    generate_cte(
        [
            {"table": "prep_geography_final", "alias": "prep_geography_final"}
        ]
    )
}},
source_data AS (
    
    select  
        ROW_NUMBER() OVER (ORDER BY __extraction_date_time)::bigint AS geography_key,
        *
    from prep_geography_final
    where __record_version = 1
),
{{
    generate_unknown_member_cte(
        target_model="prep_geography_final",
        surrogate_key_column="geography_key"
    )
}},
final AS (

    select * from source_data
    union all
    select * from unknown_member
)
select 
    geography_key,
    state_code,
    state_name,
    country_name,
    country_code,
    city_county_code,
    city_county_name,
    iso_state_code,
    iso_state_name,
    iso_country_code,
    iso_country_name,
    region_code,
    region_name,
    sub_region_code,
    sub_region_name,
    __source_system_code,
    __extraction_date_time,
    __load_id,
    __data_region,
    __merge_key,
    wr_area_key
from final