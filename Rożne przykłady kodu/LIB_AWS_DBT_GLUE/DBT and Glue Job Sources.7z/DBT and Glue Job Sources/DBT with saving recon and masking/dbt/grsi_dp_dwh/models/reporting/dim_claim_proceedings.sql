{{
    generate_cte(
        [
            {"table": "claim_proceedings", "alias": "claim_proceedings"}
        ]
    )
}},
final AS (

    select
        claim_proceedings_key,
        proceeding_country_name,
        proceeding_state_name,
        case_number,
        addamnum_amount,
        punitive_damages_amount,
        punitive_damages_flag,
        proceeding_date_flag,
        proceeding_resolution,
        proceeding_state,
        proceeding_subro_flag,
        proceeding_title,
        addamnum_specified,
        court_district,
        court_type,
        docket_number,
        final_legal_cost,
        final_settlement_cost,
        legal_specialty,
        matter_type,
        primary_cause,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'claim_proceedings_key']) }} as __global_claim_proceedings_key
    from claim_proceedings

)
select *
from final