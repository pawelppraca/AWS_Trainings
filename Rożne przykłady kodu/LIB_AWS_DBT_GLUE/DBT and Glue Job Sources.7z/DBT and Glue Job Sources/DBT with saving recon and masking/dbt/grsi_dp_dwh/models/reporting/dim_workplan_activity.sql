{{
    generate_cte(
        [
            {"table": "workplan_activity", "alias": "wrk_act_src"}
        ]
    )
}},

unique_workplan_activity as (
    select distinct
        activity_status,
        activity_priority,
        activity_type,
        activity_pattern_subject,
        activity_description
    from wrk_act_src
),

final as (

    select
        row_number() over (order by __merge_key)::bigint as dim_workplan_activity_key,
        activity_status,
        activity_priority,
        activity_type,
        activity_pattern_subject,
        activity_description,
        {{ generate_merge_key([
            "activity_status", 
            "activity_priority", 
            "activity_type", 
            "activity_pattern_subject", 
            "activity_description"
        ]) }} as __merge_key
    from unique_workplan_activity
)

select *
from final