{{
    generate_cte(
        [
            {"table": "staging_claim_center_cc_claim", "alias": "claim"},
            {"table": "staging_claim_center_cctl_claimstate", "alias": "clm_state", "columns":["id", "name"]},
        ], override_error_check=True
    )
}},

final as (
    select claim.*
    from claim
    inner join clm_state
        on claim."state" = clm_state.id 
        and claim.__load_id = clm_state.__load_id
    where NVL(LOWER(clm_state."name"), '') != 'draft'
)
select *
from final