{{
    generate_cte(
        [
            {"table": "staging_claim_center_cc_group", "alias": "groups", "columns":["id", "supervisorid", "name"]},
            {"table": "staging_claim_center_cc_contact", "alias": "contacts", "columns":["id", "firstname", "lastname"]},
            {"table": "staging_claim_center_cc_parentgroup", "alias": "group_hierarchy", "columns":["id", "ownerid", "foreignentityid"]}
        ]
    )
}},

    claim_handler_group as (
        select
            grp.name,
            nullif(nvl(con.firstname || ' ', '') || nvl(con.lastname, ''), '') as supervisor_name,
            grp.id as group_id,
            parent_grp.id as parent_group_id,
            grp.__source_system_code,
            grp.__extraction_date_time,
            grp.__load_id,
            grp.__data_region,
             {{
                generate_merge_key(
                    [
                        "grp.__source_system_code",
                        "grp.id::text"
                    ],
                )
            }} as __merge_key
        from groups grp
        left join
            contacts con on grp.supervisorid = con.id and grp.__load_id = con.__load_id
        left join
            group_hierarchy gh on grp.id = gh.ownerid and grp.__load_id = gh.__load_id
        left join
            groups parent_grp
            on gh.foreignentityid = parent_grp.id
            and gh.__load_id = parent_grp.__load_id
    ),

    final as (
        select
            row_number() over (
                partition by __merge_key order by __extraction_date_time desc
            ) as __record_version,
            name,
            supervisor_name,
            group_id,
            parent_group_id,
            __source_system_code,
            __extraction_date_time,
            __load_id,
            __data_region,
            __merge_key
        from claim_handler_group
    )

select *
from final
