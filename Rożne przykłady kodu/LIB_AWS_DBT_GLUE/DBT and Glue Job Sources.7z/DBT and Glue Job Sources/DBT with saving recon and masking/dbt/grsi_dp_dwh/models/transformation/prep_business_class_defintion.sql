
{{
    generate_cte(
        [
            {"table": "staging_genius_zhc2", "alias": "bsns_cls_def", "columns":["class_short_name","class_long_name"]},
            {"table": "staging_reference_zhc2_missing_values", "alias": "bsns_cls_def_missing_values", "columns":["c2c2ds","c2c2sd"]}
        ]
    )
}},
final as (
    select distinct
        class_short_name,
        class_long_name
    from (
        select
            class_short_name,
            class_long_name
        from bsns_cls_def
        union
        select
            c2c2ds as class_short_name,
            c2c2sd as class_long_name
        from bsns_cls_def_missing_values)
    as result
)
select *
from final