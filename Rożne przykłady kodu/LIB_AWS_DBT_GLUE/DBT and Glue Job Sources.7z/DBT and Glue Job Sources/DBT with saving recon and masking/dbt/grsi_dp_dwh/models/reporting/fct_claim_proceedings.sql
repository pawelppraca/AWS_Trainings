{{
    generate_cte(
        [
            {"table": "claim_proceedings", "alias": "claim_proceedings"},
            {"table": "dim_policy", "alias": "policy", "columns": ["policy_key"]},
        ]
    )
}},

measures AS (
    SELECT
        cp.claim_proceedings_key,
        cp.claim_key,
        cp.proceeding_assigned_by_claim_handler_key,
        cp.proceeding_assigned_to_claim_handler_key,
        cp.proceeding_assigned_to_claim_handler_group_key,
        cp.proceeding_created_by_claim_handler_group_key,
        {{ get_date_key('cp.arbitration_date') }} as arbitration_date_key,
        {{ get_date_key('cp.defense_appointed_date') }} as defense_appointed_date_key,
        {{ get_date_key('cp.final_settlement_date') }} as final_settlement_date_key,
        {{ get_date_key('cp.hearing_date') }} as hearing_date_key,
        {{ get_date_key('cp.mediation_date') }} as mediation_date_key,
        {{ get_date_key('cp.proceeding_assignment_date') }} as proceeding_assignment_date_key,
        {{ get_date_key('cp.proceeding_close_date') }} as proceeding_close_date_key,
        {{ get_date_key('cp.proceeding_created_date') }} as proceeding_created_date_key,
        {{ get_date_key('cp.proceeding_date') }} as proceeding_date_key,
        {{ get_date_key('cp.proceeding_start_date') }} as proceeding_start_date_key,
        {{ get_date_key('cp.sent_to_defense_date') }} as sent_to_defense_date_key,
        {{ get_date_key('cp.service_date') }} as service_date_key,
        {{ get_date_key('cp.trial_date') }} as trial_date_key,
        {{ get_date_key('cp.response_due') }} as response_due_date_key,
        {{ get_date_key('cp.response_filed') }} as response_filed_date_key,
        case when cp.claim_proceedings_key = -1 then 0 else 1 end as claims_in_proceedings_count,
        __source_system_code,
        __load_id,
        __data_region,
        __merge_key,
        __effective_from_date,
        __effective_to_date,
        __is_current
    FROM claim_proceedings AS cp
),

final AS (
    SELECT
        p.policy_key,
        measures.*
    FROM measures
    INNER JOIN policy AS p
        ON measures.claim_key = p.policy_key
)

SELECT *
FROM final
