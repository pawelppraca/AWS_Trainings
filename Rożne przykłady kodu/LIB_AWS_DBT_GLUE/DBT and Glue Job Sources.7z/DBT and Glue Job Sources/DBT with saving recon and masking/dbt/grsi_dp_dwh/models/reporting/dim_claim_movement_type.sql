{{
    generate_cte(
        [
            {"table": "claim_movement_type", "alias": "claim_movement_type"}
        ]
    )
}},
final AS (
    
    select
        claim_movement_type_key, 
        cost_category_code, 
        cost_category_description, 
        cost_type_code, 
        cost_type_description, 
        ded_recovery_rdctn_reason, 
        __source_system_code,
        __data_region,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'claim_movement_type_key']) }} as __global_claim_movement_type_key
    from claim_movement_type

)
select *
from final