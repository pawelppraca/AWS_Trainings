{{
    generate_cte(
        [
            {"table": "prep_ri_agreement_final", "alias": "prep_ri_agreement_final"},
        ]
    )
}},
source_data AS (
    
    select  
        ROW_NUMBER() OVER (ORDER BY __extraction_date_time)::bigint AS ri_agreement_key,
        *
    from prep_ri_agreement_final
    where __record_version = 1
),
{{
    generate_unknown_member_cte(
        target_model="prep_ri_agreement_final",
        surrogate_key_column="ri_agreement_key"
    )
}},
final AS (
    select * from source_data
    union all
    select * from unknown_member
)
select
    ri_agreement_key,
    ri_agreement_genius,
    ri_agreement,
    ri_agreement_title,
    ri_class,
    ri_class_code,
    expiry_date,
    inception_date,
    ri_type,
    ri_type_code,
    treaty_fac_description,
    treaty_fac_code,
    __source_system_code,
    __extraction_date_time,
    __load_id,
    __data_region,
    __merge_key
from final

