{{
    generate_cte(
        [
            {"table": "loss_location", "alias": "loss_location"}
        ]
    )
}},
final AS (
    select
        address_line_1,
        address_line_2,
        address_line_3,
        address_line_4,
        address_line_5,
        city,
        state_name,
        country_name,
        post_code,
        __source_system_code,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'loss_location_key']) }} as __global_loss_location_key
    from loss_location
)
select *
from final