{{
    generate_cte(
        [
            {"table": "claim_inventory", "alias": "claim_inventory"}
        ]
    )
}},
final as (
    select
        claim_inventory_key,
        {{ get_date_key('inventory_movement_date') }} as inventory_movement_date,
        inventory_type,
        inventory_description,
        claim_key,
        policy_key,
        created_by_claim_handler_key,
        assigned_to_claim_handler_key,
        assigned_by_claim_handler_key,
        updated_by_claim_handler_key,
        assigned_group_key,
        __source_system_code,
        __data_region,
        __merge_key,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'claim_inventory_key']) }} as __global_claim_inventory_key
    from claim_inventory
)
select *
from final