{{
    generate_cte(
        [
            {"table": "claim", "alias": "claim", "columns": ["claim_key", "policy_key"]},
            {"table": "claim_handler", "alias": "claim_handler", "columns": ["claim_handler_key", "full_name"]},
            {"table": "claim_handler_group", "alias": "ch_group", "columns": ["claim_handler_group_key", "name"]},
            {"table": "exposure", "alias": "exposure"},
            {"table": "exposure_profile_history", "alias": "eph"},
            {"table": "exposure_status", "alias": "exposure_status", "columns": ["exposure_status_key", "exposure_status"]},
            {"table": "policy", "alias": "policy", "columns": ["policy_key"]},
        ]
    )
}},
final AS (
    
    select
        eph.exposure_profile_history_key as exposure_history_key,
        exposure.exposure_key,
        policy.policy_key,
        exposure.created_by_claim_handler_key,
        --TODO: Remove these keys from dwh.claim as should be using claim_profile_history --> agree logic with BAs
        --claim.assigned_to_claim_handler_key, 
        --claim.assigned_group_key, 
        exposure.assigned_by_claim_handler_key,
        exposure.updated_by_claim_handler_key,
        created_by_ch.full_name as created_by_claim_handler,
        updated_by_ch.full_name as updated_by_claim_handler,
        exposure_status.exposure_status as exposure_status,
        prev_exposure_status.exposure_status as previous_exposure_status,
        current_ch.full_name as claim_handler,
        previous_ch.full_name as previous_claim_handler,
        NVL(current_ch.full_name, 'UNKNOWN') || ' (' || to_char(eph.__effective_from_date, 'DD/MM/YYYY')  || ' - '
                || CASE WHEN eph.__is_current is true THEN 'Current' ELSE to_char(eph.__effective_to_date, 'DD/MM/YYYY')  END
                || ')' as claim_handler_version, 
        ch_group.name as claim_handler_group,
        previous_ch_group.name as previous_claim_handler_group, 
        NVL(ch_group.name, 'UNKNOWN') || ' (' || to_char(eph.__effective_from_date, 'DD/MM/YYYY')  || ' - '
                || CASE WHEN eph.__is_current is true THEN 'Current' ELSE to_char(eph.__effective_to_date, 'DD/MM/YYYY')  END
                || ')' as claim_handler_group_version,       
        eph.__event_sequence_number,
        eph.__is_current,
        eph.__effective_from_date,
        eph.__effective_to_date,
        exposure.__source_system_code,
        exposure.__data_region,
        {{ dbt_utils.generate_surrogate_key(['exposure.__data_region', 'exposure.exposure_key']) }} as __global_exposure_key
    from exposure
    left join claim
        on exposure.claim_key = claim.claim_key
    left join policy
        on claim.policy_key = policy.policy_key
    inner join eph
        on exposure.exposure_key = eph.exposure_key
    left join exposure_status
        on eph.current_exposure_status_key = exposure_status.exposure_status_key
    left join exposure_status as prev_exposure_status
        on eph.previous_exposure_status_key = prev_exposure_status.exposure_status_key
    left join claim_handler as current_ch
        on eph.current_claim_handler_key = current_ch.claim_handler_key
    left join claim_handler as previous_ch
        on eph.previous_claim_handler_key = previous_ch.claim_handler_key
    left join ch_group
        on eph.current_claim_handler_group_key = ch_group.claim_handler_group_key
    left join ch_group as previous_ch_group
        on eph.previous_claim_handler_group_key = previous_ch_group.claim_handler_group_key
    left join claim_handler as created_by_ch
        on exposure.created_by_claim_handler_key = created_by_ch.claim_handler_key
    left join claim_handler as updated_by_ch
        on exposure.updated_by_claim_handler_key = updated_by_ch.claim_handler_key
)
select *
from final