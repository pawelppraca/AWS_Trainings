{{
    generate_cte(
        [
            {"table": "prep_coverage_final", "alias": "prep_coverage"},
            {"table": "risk", "alias": "dwh_risk", "columns": ["risk_key"]}
        ]
    )
}},
source_data AS (
    
    select  
        ROW_NUMBER() OVER (ORDER BY __extraction_date_time)::bigint AS coverage_key,
        *
    from prep_coverage
    where __record_version = 1
),
{{
    generate_unknown_member_cte(
        target_model="prep_coverage_final",
        surrogate_key_column="coverage_key"
    )
}},
coverage AS (

    select * from source_data
    union all
    select * from unknown_member
),
final as (
select 
    cov.coverage_key,    
    {{get_unknown_member_key("risk.risk_key")}} as risk_key,
	cov.coverage_currency_code,
	cov.coverage_code,
	cov.coverage_name,
	cov.coverage_whole_limit,
	cov.coverage_whole_premium,
	cov.deductible_amount,
    cov.__source_system_code,
    cov.__extraction_date_time,
    cov.__load_id,
    cov.__data_region,
    cov.__merge_key,
    cov.wr_limitkey,
    cov.wr_policykey,
    cov.coverage_number
from coverage cov
left join dwh_risk as risk
    on cov.__risk_merge_key = risk.__merge_key
)
select *
from final