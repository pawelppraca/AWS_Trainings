{{
    generate_cte(
        [
            {"table": "staging_claim_center_cc_claim", "alias": "claim", "columns":["id","claim_number","policyid"]},
            {"table": "staging_claim_center_cc_exposure", "alias": "cc_exposure", "columns":["id", "state","claimid","__load_id"]},
            {"table": "staging_claim_center_cc_history", "alias": "cc_history", "columns":["exposureid", "publicid", "userid", "beanversion", "customtype", "claimid", "type", "subtype", "id", "description", "eventtimestamp", "matterid", "transactionsetid", "subrogationid", "assigneduserid"]},
            {"table": "staging_claim_center_cc_policy", "alias": "cc_policy", "columns":["id", "policynumber", "ext_policyorigin", "verified"]},
            {"table": "staging_claim_center_cctl_ext_policyorigin", "alias": "policy_origin", "columns":["id", "name"]}
        ]
    )
}},
policy as (

        select
                cc_policy.*
        from cc_policy
        left join policy_origin
                on nvl(cc_policy.ext_policyorigin,'10001') = policy_origin.id 
                and cc_policy.__load_id = policy_origin.__load_id
        where upper(left(trim(cc_policy.policynumber), 7)) <> 'PLCY-CC'
        and upper(policy_origin."name") <> 'IRIS'

),
exposure as (
        select
            cc_exposure.*
        from cc_exposure
        where cc_exposure."state" <> 1
),
final as (

        select
              cc_history.*
        from cc_history
        inner join claim
                on cc_history.claimid = claim.id
                and cc_history.__load_id = claim.__load_id
        inner join policy
                on policy.id = claim.policyid
                and claim.__load_id = policy.__load_id
        inner join exposure
                on exposure.claimid = claim.id
                and exposure.__load_id = claim.__load_id
        where cc_history.exposureid is not null
            and cc_history.matterid is null
)
select *
from final
