{{
    generate_cte(
        [
            {"table": "staging_warehouse_repository_areas", "alias": "areas_source", "columns":["AreaKey", "AreaCode","AreaName","ISOStateCode","ISOStateName","ISOAreaCode","ISOAreaName","RegionCode","RegionName","SubRegionCode","SubRegionName","_MergeKey","_sourcesystemcode"]}
        ]
    )
}},

final as (
    select
        areacode as state_code,
        areaname as state_name,
        areaname as country_name,
        areacode as country_code,
        areacode as city_county_code,
        areaname as city_county_name,
        isostatecode as iso_state_code,
        isostatename as iso_state_name,
        isoareacode as iso_country_code,
        isoareaname as iso_country_name,
        regioncode as region_code,
        regionname as region_name,
        subregioncode as sub_region_code,
        subregionname as sub_region_name,
        _sourcesystemcode as __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region,
         --TODO: Use the WR surrogate key for now, but change to the proper Genius merge key _sourcesystemcode|areacode when repointing to Data Lake.
        {{
                generate_merge_key(
                    [
                        "_sourcesystemcode",
                        "areakey::text"
                    ],
                )
            }} as __merge_key,
        row_number() over (
                partition by __merge_key order by __extraction_date_time desc
            ) as __record_version,
        areakey as wr_area_key
from areas_source
)

select *
from final
