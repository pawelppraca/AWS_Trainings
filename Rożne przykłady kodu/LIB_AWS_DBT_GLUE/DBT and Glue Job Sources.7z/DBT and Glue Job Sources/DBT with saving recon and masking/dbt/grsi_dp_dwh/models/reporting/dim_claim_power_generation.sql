{{
    generate_cte(
        [
            {"table": "claim_power_generation", "alias": "claim_power_generation"}
        ]
    )
}},
final AS (

    select
        claim_power_generation_key,
        equipment_type,
        manufacturer,
        model_number,
        model_variant,
        technology_type,
        __source_system_code,
        __data_region,
        __merge_key,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'claim_power_generation_key']) }} as __global_claim_power_generation_key
    from claim_power_generation

)
select *
from final