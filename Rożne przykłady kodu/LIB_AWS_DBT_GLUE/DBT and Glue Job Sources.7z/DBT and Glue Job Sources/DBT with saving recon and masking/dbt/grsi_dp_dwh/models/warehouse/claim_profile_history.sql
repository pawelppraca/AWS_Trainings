{{
    generate_cte(
        [
            {"table": "prep_claim_events_final", "alias": "events_source"},
            {"table": "prep_claim_assignments_final", "alias": "assignments_source"},
            {"table": "claim", "alias": "claim", "columns": ["claim_key"]},
            {"table": "claim_handler", "alias": "claim_handler", "columns": ["claim_handler_key"]},
            {"table": "claim_handler_group", "alias": "claim_handler_group", "columns": ["claim_handler_group_key"]},
            {"table": "claim_status", "alias": "claim_status", "columns": ["claim_status_key"]}
        ]
    )
}},
--Map the merge keys to SKs
events as (
    select
        --Handle NULL claim keys here to avoid using functions in the join condition when joining with assignments and events
        {{ get_unknown_member_key("claim.claim_key") }} as claim_key,
        claim_status.claim_status_key,
        claim_handler.claim_handler_key as posted_by_claim_handler_key, --Not currently used
        events.event_timestamp,
        events.__source_system_code,
        events.__extraction_date_time,
        events.__load_id,
        events.__data_region 
    from events_source as events
    left join claim
        on events.__claim_merge_key = claim.__merge_key
    left join claim_handler
        on events.__posted_by_merge_key = claim_handler.__merge_key
    left join claim_status
        on events.__claim_status_merge_key = claim_status.__merge_key
),
--Map the merge keys to SKs
assignments as (
    SELECT
        --Handle NULL claim keys here to avoid using functions in the join condition when joining with assignments and events
        {{ get_unknown_member_key("claim.claim_key") }} as claim_key,
        assigned_to_ch.claim_handler_key as assigned_to_claim_handler_key,
        assigned_by_ch.claim_handler_key as assigned_by_claim_handler_key,
        groups.claim_handler_group_key as assigned_claim_handler_group_key,
        assignments.event_timestamp,
        assignments.__source_system_code,
        assignments.__extraction_date_time,
        assignments.__load_id,
        assignments.__data_region
    FROM assignments_source as assignments
    left join claim
        on assignments.__claim_merge_key = claim.__merge_key
    left join claim_handler as assigned_to_ch
        on assignments.__assigned_to_merge_key = assigned_to_ch.__merge_key
    left join claim_handler as assigned_by_ch
        on assignments.__assigned_by_merge_key = assigned_by_ch.__merge_key
    left join claim_handler_group as groups
        on assignments.__assigned_group_merge_key = groups.__merge_key
    --Compute earliest occurrence of each assignment as there could be multiple assignments for the same person on different dates
    qualify row_number()
    over (partition by 
            claim_key, 
            assigned_to_claim_handler_key, 
            assigned_by_claim_handler_key,
            assigned_claim_handler_group_key, 
            assignments.__source_system_code, 
            assignments.__extraction_date_time, 
            assignments.__load_id, 
            assignments.__data_region 
         order by assignments.event_timestamp asc) = 1   
),
all_events as (
    select
        claim_key,
        claim_status_key,
        NULL as assigned_to_claim_handler_key,
        NULL as assigned_claim_handler_group_key,
        date_trunc('second', event_timestamp) as event_timestamp,
        __source_system_code, 
        __extraction_date_time, 
        __load_id, 
        __data_region 
    from events
    union
    select
        claim_key,
        NULL as claim_status_key,
        assigned_to_claim_handler_key,
        assigned_claim_handler_group_key,
        date_trunc('second', event_timestamp) as event_timestamp,
        __source_system_code, 
        __extraction_date_time, 
        __load_id, 
        __data_region
    from assignments
),
--fill in missing values
cph_base as (
    select
        claim_key,
        COALESCE(
                claim_status_key,
                LAST_VALUE(claim_status_key) ignore nulls over(partition by claim_key
                            order by event_timestamp, claim_status_key asc rows between unbounded preceding and current row)
        ) as current_claim_status_key,
        COALESCE(
                assigned_to_claim_handler_key,
                LAST_VALUE(assigned_to_claim_handler_key) ignore nulls over(partition by claim_key
                            order by event_timestamp, assigned_to_claim_handler_key asc rows between unbounded preceding and current row)
        ) as current_claim_handler_key,
        COALESCE(
                assigned_claim_handler_group_key,
                LAST_VALUE(assigned_claim_handler_group_key) ignore nulls over(partition by claim_key
                            order by event_timestamp, assigned_claim_handler_group_key asc rows between unbounded preceding and current row)
        ) as current_claim_handler_group_key,
        event_timestamp,
        __source_system_code, 
        __extraction_date_time, 
        __load_id, 
        __data_region
    from all_events
),
--Remove any duplicate events from final list
cph_dedup as (
    select *
    from cph_base as cph_base
    qualify row_number()
    over (partition by 
            claim_key, 
            current_claim_status_key, 
            current_claim_handler_key,
            current_claim_handler_group_key, 
            event_timestamp,
            __load_id
         order by event_timestamp asc) = 1  
),
cph_final as (
    select
        row_number() over (order by __extraction_date_time)::bigint as claim_profile_history_key,
        claim_key, 
        current_claim_status_key, 
        current_claim_handler_key,
        current_claim_handler_group_key,
        ROW_NUMBER() OVER(PARTITION BY claim_key ORDER BY event_timestamp ASC) AS __event_sequence_number,
        event_timestamp as __effective_from_date,
        COALESCE(
            DATEADD(millisecond, -1,
                        lead(event_timestamp, 1) IGNORE NULLS OVER (
                            PARTITION BY claim_key
                            ORDER BY event_timestamp ASC
                        )
            ), '9999-12-31' 
        ) AS __effective_to_date,
        CASE WHEN lead(event_timestamp, 1) IGNORE NULLS OVER (
                PARTITION BY claim_key 
                ORDER BY event_timestamp ASC) IS NULL 
        THEN true ELSE false END AS __is_current,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region 
    from cph_dedup
),
cph as (
    SELECT
        current_cph.claim_profile_history_key,
        current_cph.claim_key,
        {{ get_unknown_member_key("current_cph.current_claim_status_key") }} as current_claim_status_key,
        {{ get_unknown_member_key("previous_cph.current_claim_status_key") }} as previous_claim_status_key,
        {{ get_unknown_member_key("current_cph.current_claim_handler_key") }} as current_claim_handler_key,
        {{ get_unknown_member_key("previous_cph.current_claim_handler_key") }} as previous_claim_handler_key,
        {{ get_unknown_member_key("current_cph.current_claim_handler_group_key") }} as current_claim_handler_group_key,
        {{ get_unknown_member_key("previous_cph.current_claim_handler_group_key") }} as previous_claim_handler_group_key,
        current_cph.__event_sequence_number,
        current_cph.__effective_from_date,
        current_cph.__effective_to_date,
        current_cph.__is_current,
        current_cph.__source_system_code,
        current_cph.__extraction_date_time,
        current_cph.__load_id,
        current_cph.__data_region 
    FROM cph_final as current_cph
    LEFT JOIN cph_final as previous_cph
        ON current_cph.claim_key = previous_cph.claim_key
        AND current_cph.__event_sequence_number = previous_cph.__event_sequence_number + 1
),
--TODO: Refactor to use a macro and avoid using hard-coded values..
--CPH doesn't follow the standard pattern so can't use the generate_unknown_member_cte
unknown_member as (
    SELECT
        {{ get_unknown_member_key("null") }} as claim_profile_history_key,
        {{ get_unknown_member_key("null") }} as claim_key,
        {{ get_unknown_member_key("null") }} as current_claim_status_key,
        {{ get_unknown_member_key("null") }} as previous_claim_status_key,
        {{ get_unknown_member_key("null") }} as current_claim_handler_key,
        {{ get_unknown_member_key("null") }} as previous_claim_handler_key,
        {{ get_unknown_member_key("null") }} as current_claim_handler_group_key,
        {{ get_unknown_member_key("null") }} as previous_claim_handler_group_key,
        1 as __event_sequence_number,
        '19000101'::timestamp as __effective_from_date,
        '99991231'::timestamp as __effective_to_date,
        true as __is_current,
        'Unknown'::varchar as __source_system_code,
        '19000101'::timestamp as __extraction_date_time,
        0 as __load_id,
        'Unknown'::varchar as __data_region
),
final as (
    select * from cph
    union 
    select * from unknown_member
)
select *
from final 
