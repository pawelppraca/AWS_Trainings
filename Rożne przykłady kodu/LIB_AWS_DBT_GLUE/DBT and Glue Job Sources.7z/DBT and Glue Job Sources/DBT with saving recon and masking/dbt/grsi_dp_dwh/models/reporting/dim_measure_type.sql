
WITH src AS (

    -----------------------------------------------------------------------------------
    SELECT
        1::bigint AS measure_type_key,
        'PAID_IND_GROSS' AS measure_type_code,
        'Paid Indemnity Gross' AS measure_type_name

    UNION ALL

    SELECT
        2 AS measure_type_key,
        'PAID_FEE_GROSS' AS measure_type_code,
        'Paid Fees Gross' AS measure_type_name

    UNION ALL

    SELECT
        3 AS measure_type_key,
        'PAID_GST_GROSS' AS measure_type_code,
        'Paid GST Gross' AS measure_type_name

    -----------------------------------------------------------------------------------

    UNION ALL

    SELECT
        4 AS measure_type_key,
        'OS_IND_GROSS' AS measure_type_code,
        'Outstanding Indemnity Gross' AS measure_type_name

    UNION ALL

    SELECT
        5 AS measure_type_key,
        'OS_FEE_GROSS' AS measure_type_code,
        'Outstanding Fees Gross' AS measure_type_name

    UNION ALL

    SELECT
        6 AS measure_type_key,
        'OS_REC_GROSS' AS measure_type_code,
        'Outstanding Recovery Gross' AS measure_type_name

    UNION ALL

    SELECT
        7 AS measure_type_key,
        'PAID_REC_GROSS' AS measure_type_code,
        'Paid Recovery Gross' AS measure_type_name

    UNION ALL

    SELECT
        8 AS measure_type_key,
        'PAID_IND_CEDED' AS measure_type_code,
        'Paid Indemnity Ceded' AS measure_type_name

    UNION ALL

    SELECT
        9 AS measure_type_key,
        'PAID_FEE_CEDED' AS measure_type_code,
        'Paid Fees Ceded' AS measure_type_name

    UNION ALL

    SELECT
        10 AS measure_type_key,
        'OS_FEE_CEDED' AS measure_type_code,
        'Outstanding Fees Ceded' AS measure_type_name

    UNION ALL

    SELECT
        11 AS measure_type_key,
        'OS_REC_CEDED' AS measure_type_code,
        'Outstanding Recovery Ceded' AS measure_type_name
        
    -------------------------- Derived Measures -------------------------------------

    UNION ALL

    SELECT
        12 AS measure_type_key,
        'TOTAL_OS_GROSS' AS measure_type_code,
        'Total Outstanding Gross' AS measure_type_name
    
    UNION ALL

    SELECT
        13 AS measure_type_key,
        'TOTAL_PAID_GROSS' AS measure_type_code,
        'Total Paid Gross' AS measure_type_name

    UNION ALL

    SELECT
        14 AS measure_type_key,
        'TOTAL_INCURRED_GROSS' AS measure_type_code,
        'Total Incurred Gross' AS measure_type_name

),

final AS (

    SELECT 
        measure_type_key,
        measure_type_code,
        measure_type_name
    FROM src


)
SELECT *
FROM final
