{{
    generate_cte([
        {"table": "claim", "alias": "claim"},
        {"table": "claim_handler", "alias": "claim_handler"},
        {"table": "claim_payments", "alias": "claim_payments", "columns": ["claim_payments_key","__merge_key"]},
        {"table": "claim_profile_history", "alias": "cph", "columns": ["claim_profile_history_key", "claim_key"]},
        {"table": "claim_movement_type", "alias": "claim_movement_type"},
        {"table": "coverage", "alias": "coverage", "columns": ["coverage_key","__merge_key"]},
        {"table": "currency", "alias": "currency"},
        {"table": "exchange_rates", "alias": "exchange_rates", "columns": ["exchange_rate", "exchange_rate_type", "exchange_rate_from_date", "from_currency_code", "to_currency_code"]},
        {"table": "exposure", "alias": "exposure", "columns": ["exposure_key","__merge_key"]},
        {"table": "prep_claim_transaction_final", "alias": "prep_claim_transaction_final"},
        {"table": "ri_code", "alias": "ri_code"},
        {"table": "ri_agreement", "alias": "ri_agreement", "columns": ["ri_agreement_key","__merge_key"]},
        {"table": "risk", "alias": "risk", "columns": ["risk_key","__merge_key"]},
        {"table": "transaction_type", "alias": "transaction_type"}
    ])
}},

claim_trans_source as (
    select
        row_number() over (order by __extraction_date_time)::bigint as claim_transaction_key,
        claim_number,
        claim_trans_ref,
        ri_code,
        transaction_type,
        recovery_reason,
        posting_date,
        transaction_date,
        fiscal_date,
        previous_fiscal_date,
        original_currency_code,
        local_currency_code,
        group_currency_code,
        trans_amount_original,
        trans_amount_local,
        trans_amount_group,
        paid_amount_original,
        outstanding_amount_original,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region,
        __claim_merge_key,
        __exposure_merge_key,
        __risk_merge_key,
        __coverage_merge_key,
        __claim_movement_type_merge_key,
        __claim_payments_merge_key,
        __ri_code_merge_key,
        __ri_agreement_merge_key,
        __transaction_type_merge_key,
        __created_by_claim_handler_merge_key,
        __original_currency_merge_key,
        __local_currency_merge_key,
        __group_currency_merge_key
    from prep_claim_transaction_final
),

claim_transaction as (
    select
        claim_trans.claim_transaction_key,
        {{ get_unknown_member_key("claim.claim_key") }} as claim_key,
        {{ get_unknown_member_key("exposure.exposure_key") }} as exposure_key,
        {{ get_unknown_member_key("risk.risk_key") }} as risk_key,
        {{ get_unknown_member_key("coverage.coverage_key") }} as coverage_key,
        {{ get_unknown_member_key("claim_movement_type.claim_movement_type_key") }} as claim_movement_type_key,
        {{ get_unknown_member_key("claim_payments.claim_payments_key") }} as claim_payments_key,
        {{ get_unknown_member_key("ri_code.ri_code_key") }} as ri_code_key,
        {{ get_unknown_member_key("ri_agreement.ri_agreement_key") }} as ri_agreement_key,
        {{ get_unknown_member_key("transaction_type.transaction_type_key") }} as transaction_type_key,
        {{ get_unknown_member_key("claim_handler.claim_handler_key") }} as created_by_claim_handler_key,
        {{ get_unknown_member_key("original_currency.currency_key") }} as original_currency_key,
        {{ get_unknown_member_key("local_currency.currency_key") }} as local_currency_key,
        {{ get_unknown_member_key("group_currency.currency_key") }} as group_currency_key,
        claim_trans.posting_date,
        claim_trans.transaction_date,
        claim_trans.fiscal_date,
        claim_trans.trans_amount_original::numeric(38,4) AS amount_original,
        (CASE claim_trans.transaction_type
            WHEN 'RSV' THEN TRUNC(claim_trans.trans_amount_original * fx_rate_local.exchange_rate, 2)
            WHEN 'PMT' THEN claim_trans.trans_amount_local
            ELSE NULL END)::numeric(38,4) AS amount_local,
        (CASE claim_trans.transaction_type
            WHEN 'RSV' THEN TRUNC(claim_trans.trans_amount_original * fx_rate_group.exchange_rate, 2)
            WHEN 'PMT' THEN claim_trans.trans_amount_group
            ELSE NULL END)::numeric(38,4) AS amount_group,
        claim_trans.paid_amount_original::numeric(38,4) as paid_amount_original,
        TRUNC(claim_trans.paid_amount_original * fx_rate_local.exchange_rate, 2)::numeric(38,4) AS paid_amount_local,
        TRUNC(claim_trans.paid_amount_original * fx_rate_group.exchange_rate, 2)::numeric(38,4) AS paid_amount_group,
        claim_trans.outstanding_amount_original::numeric(38,4) as outstanding_amount_original,
        TRUNC(claim_trans.outstanding_amount_original * fx_rate_local.exchange_rate, 2)::numeric(38,4) AS outstanding_amount_local,
        TRUNC(claim_trans.outstanding_amount_original * fx_rate_group.exchange_rate, 2)::numeric(38,4) AS outstanding_amount_group,
        claim_trans.__source_system_code,
        claim_trans.__extraction_date_time,
        claim_trans.__load_id,
        claim_trans.__data_region
    from claim_trans_source as claim_trans
    left join exchange_rates AS fx_rate_local
        on fx_rate_local.exchange_rate_type = 'GENIUS'
        and claim_trans.previous_fiscal_date = fx_rate_local.exchange_rate_from_date
        and claim_trans.original_currency_code = fx_rate_local.from_currency_code
        and claim_trans.local_currency_code = fx_rate_local.to_currency_code
    left join exchange_rates AS fx_rate_group
        on fx_rate_group.exchange_rate_type = 'genius'
        and claim_trans.previous_fiscal_date = fx_rate_group.exchange_rate_from_date
        and claim_trans.original_currency_code = fx_rate_group.from_currency_code
        and claim_trans.group_currency_code = fx_rate_group.to_currency_code
    left join claim
        on claim_trans.__claim_merge_key = claim.__merge_key
    left join claim_movement_type
        on claim_trans.__claim_movement_type_merge_key = claim_movement_type.__merge_key
    left join ri_code
        on claim_trans.__ri_code_merge_key = ri_code.__merge_key
    left join transaction_type
        on claim_trans.__transaction_type_merge_key = transaction_type.__merge_key
    left join claim_handler
        on claim_trans.__created_by_claim_handler_merge_key  = claim_handler.__merge_key
    left join currency as original_currency
        on claim_trans.__original_currency_merge_key = original_currency.__merge_key
    left join currency as local_currency
        on claim_trans.__local_currency_merge_key = local_currency.__merge_key
    left join currency as group_currency
        on claim_trans.__group_currency_merge_key = group_currency.__merge_key
    left join ri_agreement
        on claim_trans.__ri_agreement_merge_key = ri_agreement.__merge_key
    left join risk
        on  claim_trans.__risk_merge_key = risk.__merge_key
    left join coverage
        on claim_trans.__coverage_merge_key = coverage.__merge_key
    left join claim_payments
        on claim_trans.__claim_payments_merge_key = claim_payments.__merge_key
    left join exposure
        on claim_trans.__exposure_merge_key = exposure.__merge_key
),
final as (

    select 
        ct.claim_transaction_key, 
        ct.claim_key,
        ct.exposure_key,
        ct.risk_key,
        ct.coverage_key,
        {{ get_unknown_member_key("cph.claim_profile_history_key") }} as claim_profile_history_key,
        ct.claim_movement_type_key,
        ct.claim_payments_key,
        ct.ri_agreement_key,
        ct.ri_code_key,
        ct.transaction_type_key, 
        ct.created_by_claim_handler_key,
        ct.original_currency_key, 
        ct.local_currency_key, 
        ct.group_currency_key, 
        ct.posting_date, 
        ct.transaction_date, 
        ct.fiscal_date, 
        ct.amount_original, 
        ct.amount_local, 
        ct.amount_group, 
        ct.paid_amount_original, 
        ct.paid_amount_local, 
        ct.paid_amount_group, 
        ct.outstanding_amount_original, 
        ct.outstanding_amount_local, 
        ct.outstanding_amount_group, 
        ct.__source_system_code, 
        ct.__extraction_date_time, 
        ct.__load_id, 
        ct.__data_region
    from claim_transaction as ct
    --Find the CPH record that was effective on the date of the transaction
    left join cph
        on ct.claim_key = cph.claim_key 
        --Transaction dates in Genius have no time element
        and ct.transaction_date between TRUNC(cph.__effective_from_date) and TRUNC(cph.__effective_to_date)
    --Use the latest cph record as there could be multiple matches with no time element
    qualify row_number() 
        over (partition by  ct.claim_transaction_key order by cph.__event_sequence_number desc) = 1 
)
select *
from final
