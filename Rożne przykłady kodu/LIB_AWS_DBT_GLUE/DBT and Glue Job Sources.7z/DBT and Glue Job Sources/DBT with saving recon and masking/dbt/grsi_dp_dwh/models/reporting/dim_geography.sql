{{
    generate_cte(
        [
            {"table": "geography", "alias": "geography"}
        ]
    )
}},
final as (
    select
        geography_key,
        state_code,
        state_name,
        country_name,
        country_code,
        city_county_code,
        city_county_name,
        iso_state_code,
        iso_state_name,
        iso_country_code,
        iso_country_name,
        region_code,
        region_name,
        sub_region_code,
        sub_region_name,
        wr_area_key,
        __source_system_code,
        __data_region,
        __merge_key,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'geography_key']) }} as __global_geography_key
    from geography
)
select *
from final