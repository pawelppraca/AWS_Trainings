{{
    generate_cte(
        [
            {"table": "staging_warehouse_repository_policies", "alias": "risk", 
				"columns": [
					"policykey",
					"areakey",
					"industrycode",
					"industryname",
					"riskshare",
					"lobcode",
					"lobdescription",
					"departmentcode",
					"riskdescription",
					"sectiontypecode",
					"facindicator",
					"policymasternumber",
					"policyrenewalnumber",
					"_currentflag",
					"_effectivefrom",
					"_effectiveto",
					"_lastaction",
					"_mergekey",
					"_sequencenumber",
					"_sourcesystemcode"
					]
			}
        ]
    )
}},

risk_src as (
    select
		r.policykey			as wr_policykey,
		r.areakey				as wr_areakey,
		r.industrycode		as industry_code,
		r.industryname		as industry_name,
		r.riskshare			as risk_share,
		r.lobcode				as lob_code,
		r.lobdescription		as lob_description,
		r.departmentcode		as department_code,
		r.riskdescription		as risk_description,
		r.sectiontypecode		as section_type_code,
		r.sectiontypecode		as section_type,
		r.facindicator		as fac_indicator,
		SPLIT_PART(r._mergekey, '][', 4) || '-' || LEFT(SPLIT_PART(r._mergekey, '][', 5), LENGTH(SPLIT_PART(r._mergekey, '][', 5)) - 1) as risk_number,
		policymasternumber as policy_master_number,
		(REPLICATE('0', 3-LEN(PolicyRenewalNumber)) || PolicyRenewalNumber::text)::nchar(3) as policy_sequence_number,
		r._currentflag,
		r._effectivefrom,
		r._effectiveto,
		r._lastaction,
		r._mergekey,
		r._sequencenumber,
		r._sourcesystemcode as __source_system_code,
        r.__extraction_date_time,
        r.__load_id,
        r.__data_region,
		SUBSTRING(
        	REPLACE(r._mergekey, '][', '|'), 
        	2, 
        	LENGTH(REPLACE(r._mergekey, '][', '|')) - 2
    	) as __merge_key
    from risk as r
	qualify row_number() over (partition by r._mergekey order by r._sequencenumber desc) = 1
),
final as (
    select
		industry_code,
		industry_name,
		risk_share,
		lob_code,
		lob_description,
		department_code,
		risk_description,
		section_type_code,
		section_type,
		fac_indicator,
		risk_number,
		{{ generate_merge_key(["__source_system_code", "wr_areakey"]) }} as __geography_merge_key,
		{{ generate_merge_key(["__source_system_code", "policy_master_number", "policy_sequence_number"])}} as __policy_merge_key,
		_currentflag,
		_effectivefrom,
		_effectiveto,
		_lastaction,
		_mergekey,
		_sequencenumber,
		__source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region,
		__merge_key,
		row_number() over (partition by __merge_key order by __extraction_date_time desc) as __record_version,
		wr_policykey
    from risk_src
)
select *
from final
