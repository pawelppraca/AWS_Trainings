{{ generate_staging_model('staging_reference', 'rtmi_ri_code') }}
