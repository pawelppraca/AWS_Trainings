{{
    generate_cte(
        [
            {"table": "prep_claim_handler_final", "alias": "prep_claim_handler_final"}
        ]
    )
}},
source_data AS (
    
    select  
        ROW_NUMBER() OVER (ORDER BY __extraction_date_time)::bigint AS claim_handler_key,
        *
    from prep_claim_handler_final
    where __record_version = 1
),
{{
    generate_unknown_member_cte(
        target_model="prep_claim_handler_final",
        surrogate_key_column="claim_handler_key"
    )
}},
final AS (

    select * from source_data
    union all
    select * from unknown_member
)
select 
    claim_handler_key,
    first_name,
    last_name,
    --Temp code: Display the Merge Key as the Names are redacted
    __merge_key as full_name, 
    __source_system_code,
    __extraction_date_time,
    __load_id,
    __data_region,
    __merge_key
from final