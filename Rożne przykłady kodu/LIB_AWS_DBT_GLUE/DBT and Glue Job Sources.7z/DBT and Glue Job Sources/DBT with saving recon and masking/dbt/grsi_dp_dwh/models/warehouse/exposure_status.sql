{{
    generate_cte(
        [
            {"table": "prep_exposure_status_final", "alias": "prep_exposure_status_final"}
        ]
    )
}},
source_data AS (
    
    select  
        row_number() over (order by __extraction_date_time)::bigint as exposure_status_key,
        *
    from prep_exposure_status_final
    where __record_version = 1
),
{{
    generate_unknown_member_cte(
        target_model="prep_exposure_status_final",
        surrogate_key_column="exposure_status_key"
    )
}},
final AS (

    select * from source_data
    union all
    select * from unknown_member
)
select 
    exposure_status_key,
    exposure_status,
    __source_system_code,
    __extraction_date_time,
    __load_id,
    __data_region,
    __merge_key
from final