{{
    generate_cte(
        [
            {"table": "prep_catastrophe_final", "alias": "prep_catastrophe_final"},
        ]
    )
}},
source_data AS (
    
    select  
        ROW_NUMBER() OVER (ORDER BY __extraction_date_time)::bigint AS catastrophe_key,
        *
    from prep_catastrophe_final
    where __record_version = 1
),
{{
    generate_unknown_member_cte(
        target_model="prep_catastrophe_final",
        surrogate_key_column="catastrophe_key"
    )
}},
final AS (
    select * from source_data
    union all
    select * from unknown_member
)
select *
from final

