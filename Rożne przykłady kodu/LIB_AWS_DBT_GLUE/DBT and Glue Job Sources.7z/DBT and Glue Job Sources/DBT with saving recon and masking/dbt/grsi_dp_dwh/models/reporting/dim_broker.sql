{{
    generate_cte(
        [
            {"table": "broker", "alias": "broker"}
        ]
    )
}},
final as (
    select
        broker_key,
        broker_code,
        broker_name,
        broker_state,
        broker_country,
        wr_broker_key,
        __source_system_code,
        __data_region,
        __merge_key,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'broker_key']) }} as __global_broker_key
    from broker
)
select *
from final