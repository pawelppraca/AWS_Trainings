{{
    generate_cte(
        [
            {"table": "claim_handler_group", "alias": "grp"}
        ]
    )
}},
final AS (
    
    select
        grp.claim_handler_group_key, 
        grp.name,
        grp.supervisor_name, 
        grp.parent_claim_handler_group_key, 
        parent_grp.name as parent_group_name,
        grp.__source_system_code,
        grp.__data_region,
        {{ dbt_utils.generate_surrogate_key(['grp.__data_region', 'grp.claim_handler_group_key']) }} as __global_claim_handler_group_key
    from grp
    left join grp as parent_grp
        on grp.parent_claim_handler_group_key = parent_grp.claim_handler_group_key

)
select *
from final