{{
    generate_cte(
        [
            {"table": "prep_claim_payments_final", "alias": "prep_claim_payments_final"},
            {"table": "currency", "alias": "currency", "columns": ["currency_key","__merge_key"]},
            {"table": "claim", "alias": "claim", "columns": ["claim_key","__merge_key"]}
        ]
    )
}},
source_data AS (
    
    select  
        ROW_NUMBER() OVER (ORDER BY __extraction_date_time)::bigint AS claim_payments_key,
        *
    from prep_claim_payments_final
    where __record_version = 1
),
{{
    generate_unknown_member_cte(
        target_model="prep_claim_payments_final",
        surrogate_key_column="claim_payments_key"
    )
}},
claim_payments AS (
    select * from source_data
    union all
    select * from unknown_member
),
final as (
    select
        claim_payments_key,
        {{ get_unknown_member_key("claim.claim_key") }} as claim_key,
        {{ get_unknown_member_key("currency.currency_key") }} as payment_currency_code_key,
        payee_name,
        payment_flag,
        payment_posted_date,
        payment_type,
        total_payment_amount,
        created_by_claim_handler_key,
        date_invoice_received,
        date_payment_received_by_processor,
        date_payment_sent_to_handler_for_review,
        date_handler_advised_processor_to_process_payment,
        payment_approved_date,
        final_approver,
        payment_method,
        payee_ref,
        payee_address,
        payee_location,
        claim_payments.__merge_key,
        claim_payments.__data_region,
        claim_payments.__source_system_code,
        claim_payments.__extraction_date_time,
        claim_payments.__load_id
    from claim_payments
    left join currency
        on claim_payments.__currency_merge_key = currency.__merge_key
    left join claim
        on claim_payments.__claim_merge_key = claim.__merge_key
)
select *
from final

