{{
    generate_cte(
        [
            {"table": "prep_risk_final", "alias": "prep_risk"},
            {"table": "geography", "alias": "dwh_geography", "columns": ["geography_key"]},
            {"table": "policy", "alias": "dwh_policy", "columns": ["policy_key"]}
        ]
    )
}},
source_data as (
    
    select  
        ROW_NUMBER() OVER (ORDER BY __extraction_date_time)::bigint AS risk_key,
        *
    from prep_risk
    where __record_version = 1
),
{{
    generate_unknown_member_cte(
        target_model="prep_risk_final",
        surrogate_key_column="risk_key"
    )
}},
risk as (

    select * from source_data
    union all
    select * from unknown_member
),
final as (

    select 
        risk.risk_key,
        {{ get_unknown_member_key("pol.policy_key") }} as policy_key,
        {{ get_unknown_member_key("geog.geography_key") }} as geography_key,
        risk.industry_code,
        risk.industry_name,
        risk.risk_share,
        risk.lob_code,
        risk.lob_description,
        risk.department_code,
        risk.risk_description,
        risk.section_type_code,
        risk.section_type,
        risk.fac_indicator,
        risk.risk_number,
        risk.__source_system_code,
        risk.__extraction_date_time,
        risk.__load_id,
        risk.__data_region,
        risk.__merge_key,
        risk.wr_policykey
    from risk
    left join dwh_policy as pol
        on risk.__policy_merge_key = pol.__merge_key
    left join dwh_geography as geog
        on risk.__geography_merge_key = geog.__merge_key
)
select *
from final