{{
    generate_cte(
        [
            {"table": "prep_claim_handler_group_final", "alias": "prep_claim_handler_group_final"}
        ]
    )
}},
source_data AS (
    
    select  
        ROW_NUMBER() OVER (ORDER BY __extraction_date_time)::bigint AS claim_handler_group_key,
        *
    from prep_claim_handler_group_final
    where __record_version = 1
),
{{
    generate_unknown_member_cte(
        target_model="prep_claim_handler_group_final",
        surrogate_key_column="claim_handler_group_key"
    )
}},
ch_group as (

    select * from source_data
    union all
    select * from unknown_member
),
final as (

    select
        grp.claim_handler_group_key,
        grp.name,
        grp.supervisor_name,
        parent_group.claim_handler_group_key as parent_claim_handler_group_key,
        grp.__source_system_code,
        grp.__extraction_date_time,
        grp.__load_id,
        grp.__data_region,
        grp.__merge_key
    from ch_group as grp
    left join ch_group as parent_group
        on grp.parent_group_id = parent_group.group_id
)
select 
    claim_handler_group_key,
    name,
    supervisor_name,
    parent_claim_handler_group_key,
    __source_system_code,
    __extraction_date_time,
    __load_id,
    __data_region,
    __merge_key
from final