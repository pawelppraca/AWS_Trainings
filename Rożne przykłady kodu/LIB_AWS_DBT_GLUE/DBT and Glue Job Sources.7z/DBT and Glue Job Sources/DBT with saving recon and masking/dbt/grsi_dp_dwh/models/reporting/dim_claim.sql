{{
    generate_cte(
        [
            {"table": "claim", "alias": "claim"},
            {"table": "claim_profile_history", "alias": "cph"},
            {"table": "claim_status", "alias": "claim_status", "columns": ["claim_status_key", "claim_status"]},
            {"table": "claim_handler", "alias": "claim_handler", "columns": ["claim_handler_key", "full_name"]},
            {"table": "claim_handler_group", "alias": "ch_group", "columns": ["claim_handler_group_key", "name"]},
        ]
    )
}},
final AS (
    
    select
        claim.claim_key, 
        claim.policy_key,
        claim.created_by_claim_handler_key, 
        --TODO: Remove these keys from dwh.claim as should be using claim_profile_history --> agree logic with BAs
        --claim.assigned_to_claim_handler_key, 
        --claim.assigned_group_key, 
        claim.assigned_by_claim_handler_key, 
        claim.updated_by_claim_handler_key, 
        claim.catastrophe_key,
        claim.claim_power_generation_key,
        claim.claim_construction_key,
        claim.claim_apra_key,
        claim.loss_location_key,
        claim.claim_number, 
        claim.event_name, 
        claim.event_description,
        claim.event_code,
        claim.assigned_date, 
        claim.date_claim_created, 
        claim.date_of_loss, 
        claim.date_reported, 
        claim.loss_location, 
        claim.additional_exposure_unverified, 
        claim.alternate_claim_number, 
        claim.claim_description, 
        claim.claim_state, 
        claim.claim_tier, 
        claim.claim_title, 
        claim.claim_type, 
        claim.date_claim_closed,
        claim.date_last_flagged, 
        claim.date_last_revalued, 
        claim.date_last_updated, 
        claim.date_received, 
        claim.flagged_reason, 
        claim.ground_up_loss_bi_usd, 
        claim.ground_up_loss_pd_usd, 
        claim.ground_up_loss_total_usd, 
        claim.handled_by, 
        claim.in_suit_flag, 
        claim.insurer_risk_reference, 
        claim.is_severity, 
        claim.large_loss_report_flag, 
        claim.post_close_payment_made, 
        claim.reinsurance_reportable, 
        claim.severity, 
        claim.special_claim_permission, 
        claim.tpa_claim_number, 
        claim.unique_claim_reference, 
        claim.cause_of_loss1, 
        claim.cause_of_loss2, 
        claim.cause_of_loss3, 
        claim.cause_of_loss4, 
        claim.cause_of_loss5, 
        claim.cause_of_loss1_other_description, 
        claim.cause_of_loss2_other_description, 
        claim.cause_of_loss3_other_description, 
        claim.cause_of_loss4_other_description, 
        claim.syndicate_cause_code, 
        claim.loss_code_group, 
        claim.cyber_consideration, 
        claim.cyber_consideration_other, 
        claim.ransomware_aspect, 
        claim.claims_organisation, 
        claim.syndicate_id, 
        claim.fast_track, 
        claim.coverage_indicator, 
        claim.deductible_type, 
        claim.fault_rating, 
        claim.claim_handling_type, 
        claim.claim_how_reported, 
        claim.large_loss_notification_status, 
        claim.iso_loss_location, 
        claim.loss_event, 
        claim.reported_by_type, 
        claim.cargo_type, 
        claim.batched_claim_flag, 
        claim.claim_proceedings_type, 
        claim.subrogation_status,
        claim.block_file,
        claim.loss_fund,
        claim.general_claim_note,
        claim.vulnerable_customer,
        claim.date_coverage_letter_issued,
        claim.external_reference,
        claim.claim_involving_minor_flag,
        claim.multiple_coverages_flag,
        claim.claim_closure_reason,
        claim.latest_ecf_transaction_type,
        claim_status.claim_status as claim_status,
        current_ch.full_name as current_claim_handler,
        ch_group.name as claim_handler_group,
        created_by_ch.full_name as created_by_claim_handler,
        updated_by_ch.full_name as updated_by_claim_handler,
        claim.__source_system_code,
        claim.__data_region,
        {{ dbt_utils.generate_surrogate_key(['claim.__data_region', 'claim.claim_key']) }} as __global_claim_key,
        {{ get_date_key('claim.date_claim_created') }} as date_claim_created_key
    from claim 
    left join cph 
        on claim.claim_key = cph.claim_key
        and cph.__is_current is true
    left join claim_status
        on cph.current_claim_status_key = claim_status.claim_status_key
    left join claim_handler as current_ch
        on cph.current_claim_handler_key = current_ch.claim_handler_key
    left join ch_group
        on cph.current_claim_handler_group_key = ch_group.claim_handler_group_key
    left join claim_handler as created_by_ch
        on claim.created_by_claim_handler_key = created_by_ch.claim_handler_key
    left join claim_handler as updated_by_ch
        on claim.updated_by_claim_handler_key = updated_by_ch.claim_handler_key
    where
        upper(coalesce(claim.claim_closure_reason, '')) not in ('VOID', 'VOID - CLAIM WITHDRAWN', 'INCOMPLETE')
)
select *
from final
