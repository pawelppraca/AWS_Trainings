{{ config(materialized="table") }}

with
    meta_data as (
        select
            'SYSTEM' as __source_system_code,
            sysdate as __extraction_date_time,
            {{ get_current_load_id() }}::bigint as __load_id
    ),

    dates as (
        {{
            dbt_utils.date_spine(
                start_date="to_date('19500101', 'yyyymmdd')",
                datepart="day",
                end_date="to_date(to_char(dateadd(year, 41, current_date), 'YYYY') || '0101', 'YYYYMMDD')",
            )
        }}
    ),

    final as (
        select
            dates.date_day,
            meta_data.__source_system_code,
            meta_data.__extraction_date_time,
            meta_data.__load_id
        from dates, meta_data
    )

select *
from final
