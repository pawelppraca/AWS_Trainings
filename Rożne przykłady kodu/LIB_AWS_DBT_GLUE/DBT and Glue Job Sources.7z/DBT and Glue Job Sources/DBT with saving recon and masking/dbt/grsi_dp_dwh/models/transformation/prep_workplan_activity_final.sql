{{
    generate_cte(
        [
            {"table": "staging_claim_center_cc_activity", "alias": "activity", "columns":["id","assignmentdate","closedate","createtime","description","targetdate","escalationdate",
            "activitypatternid","claimid","assignedbyuserid","assigneduserid","closeuserid","createuserid","priority","status","updateuserid",
            "__source_system_code","__extraction_date_time","__load_id","__data_region"]},
            {"table": "staging_claim_center_cctl_priority", "alias": "priority", "columns":["name","priority"]},
            {"table": "staging_claim_center_cctl_activitystatus", "alias": "activity_status", "columns":["id","description"]},
            {"table": "staging_claim_center_cc_activitypattern", "alias": "activity_pattern", "columns":["id","subject","category"]},
            {"table": "staging_claim_center_cctl_activitycategory", "alias": "activity_category", "columns":["id","name"]},
            {"table": "prep_claim_filtered", "alias": "claim", "columns":["id","claim_number","state","policyid","assignedgroupid"]},
            {"table": "prep_cc_policy", "alias": "cc_policy", "columns":["id", "policy_master_number", "policy_master_sequence"]},

        ]
    )
}},
workplan_activity as (
    SELECT
    activity.id,
    activity.assignmentdate as activity_assignment_date,
    activity.createtime as activity_created_date,
    activity.closedate as activity_closed_date,
    activity.targetdate as activity_due_date,
    activity.escalationdate as activity_escalation_date,
    activity_status.description as activity_status,
    activity_category.name as activity_type,
    activity_pattern.subject as activity_pattern_subject,
    activity.description as activity_description,
    activity.assignedbyuserid,
    activity.assigneduserid,
    activity.closeuserid,
    activity.createuserid,
    activity.updateuserid,
    activity.__source_system_code,
    activity.__extraction_date_time,
    activity.__load_id,
    activity.__data_region,
    priority.name as activity_priority,
    claim.claim_number,
    claim.assignedgroupid,
    claim.__source_system_code as __claim_source_system_code,
    cc_policy.__policy_source_system_code,
    cc_policy.policy_master_number,
    cc_policy.policy_master_sequence
    from activity
    inner join claim on claim.id = activity.claimid and claim.__load_id = activity.__load_id
    left join priority on priority.priority = activity.priority  and priority.__load_id = activity.__load_id
    left join activity_status on activity_status.id = activity.status  and activity_status.__load_id = activity.__load_id
    left join activity_pattern on activity_pattern.id = activity.activitypatternid  and activity_pattern.__load_id = activity.__load_id
    left join activity_category on activity_category.id = activity_pattern.category  and activity_category.__load_id = activity_pattern.__load_id
    left join cc_policy on cc_policy.id = claim.policyid  and cc_policy.__load_id = claim.__load_id
),

final as (
    SELECT
        activity_assignment_date,
        activity_created_date,
        activity_closed_date,
        activity_due_date,
        activity_escalation_date,
        activity_status,
        activity_type,
        activity_pattern_subject,
        activity_description,
        activity_priority,
        {{generate_merge_key(["__policy_source_system_code","policy_master_number", "policy_master_sequence"])}} as __policy_merge_key,
        {{generate_merge_key(["__claim_source_system_code","claim_number"])}} as __claim_merge_key,
        {{generate_merge_key(["__claim_source_system_code", "assignedgroupid"]) }} as __claim_handler_group_merge_key,
        {{generate_merge_key(["__source_system_code","assignedbyuserid"])}} as __assigned_by_claim_handler_merge_key,
        {{generate_merge_key(["__source_system_code","assigneduserid"])}} as __assigned_to_claim_handler_merge_key,
        {{generate_merge_key(["__source_system_code","closeuserid"])}} as __closed_by_claim_handler_merge_key,
        {{generate_merge_key(["__source_system_code","createuserid"],)}} as __created_by_claim_handler_merge_key,
        {{generate_merge_key(["__source_system_code","updateuserid"])}} as __updated_by_claim_handler_merge_key,
        __source_system_code,
         __extraction_date_time,
        __load_id,
        __data_region,
        {{ generate_merge_key(["__source_system_code", "id"])}} as __merge_key,
        row_number() over (
            partition by __merge_key order by __extraction_date_time desc
        ) as __record_version
    from workplan_activity
)
SELECT * FROM final