{{
    generate_cte(
        [
            {"table": "staging_claim_center_cc_history", "alias": "cc_history", "columns":["exposureid", "publicid", "userid", "beanversion", "customtype", "claimid", "type", "subtype", "id", "description", "eventtimestamp", "matterid", "transactionsetid", "subrogationid", "assigneduserid"]},
            {"table": "staging_claim_center_cc_claim", "alias": "cc_claim", "columns":["id", "policyid", "claim_number", "state"]},
            {"table": "staging_claim_center_cc_policy", "alias": "cc_policy", "columns":["id", "policynumber", "ext_policyorigin", "verified"]},
            {"table": "staging_claim_center_cctl_ext_policyorigin", "alias": "policy_origin", "columns":["id", "name"]},
        ]
    )
}},
policy as (

        select
                cc_policy.*
        from cc_policy
        left join policy_origin
                on nvl(cc_policy.ext_policyorigin,'10001') = policy_origin.id 
                and cc_policy.__load_id = policy_origin.__load_id
        where upper(left(trim(cc_policy.policynumber), 7)) <> 'PLCY-CC'
        and upper(policy_origin."name") <> 'IRIS'

),
claim as (

        select
                cc_claim.*
        from cc_claim
        where cc_claim."state" <> 1
),
final as (

        select
              cc_history.*,
              claim.claim_number
        from cc_history
        inner join claim
                on cc_history.claimid = claim.id
                and cc_history.__load_id = claim.__load_id
        inner join policy
                on claim.policyid = policy.id
                and claim.__load_id = policy.__load_id
        where cc_history.exposureid is null
        and cc_history.matterid is null

)
select *
from final
