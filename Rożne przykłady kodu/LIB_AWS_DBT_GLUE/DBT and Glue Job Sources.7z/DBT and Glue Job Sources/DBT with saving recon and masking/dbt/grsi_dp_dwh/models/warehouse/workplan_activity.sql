{{  
    config ( 
        materialized='incremental', 
        dist='auto',
        sort='workplan_activity_key',
        unique_key='workplan_activity_key', 
        incremental_strategy='merge',
        on_schema_change='append_new_columns'
    ) 

}} 


{% set column_list = get_scd_columns(model.name, none) -%}
{% set scd1_columns = get_scd_columns(model.name, 1) -%}
{% set scd2_columns = get_scd_columns(model.name, 2) -%}
{% set surrogate_key_column = get_surrogate_key_column(model.name) -%}

{{ log("\nModel Name: " ~ model.name ~ ", Incremental Refresh: " ~ is_incremental(), info=true) }}
{{ log("\nModel Name: " ~ model.name ~ ", SCD1 Column List: " ~ scd1_columns, info=true) }}
{{ log("\nModel Name: " ~ model.name ~ ", SCD2 Column List: " ~ scd2_columns, info=true) }}

{{
    generate_cte(
        [
            {"table": "prep_workplan_activity_final", "alias": "workplan_activity"},
            {"table": "claim", "alias": "claim", "columns":["claim_key","assigned_group_key","__merge_key"]},
            {"table": "policy", "alias": "policy", "columns":["policy_key","__merge_key"]},
            {"table": "claim_handler", "alias": "claim_handler", "columns":["claim_handler_key","__merge_key"]}
        ]
    )
}},

src AS (
    SELECT
        row_number() over (order by workplan_activity.__extraction_date_time)::bigint as {{surrogate_key_column}},
        {{ get_unknown_member_key("claim.claim_key") }} as claim_key,
        {{ get_unknown_member_key("policy.policy_key") }} as policy_key,
        {{ get_unknown_member_key("claim.assigned_group_key") }} as claim_handler_group_key,
        {{ get_unknown_member_key("assigned_by.claim_handler_key") }} as assigned_by_claim_handler_key,
        {{ get_unknown_member_key("assigned_to.claim_handler_key") }} as assigned_to_claim_handler_key,
        {{ get_unknown_member_key("closed_by.claim_handler_key") }} as closed_by_claim_handler_key,
        {{ get_unknown_member_key("created_by.claim_handler_key") }} as created_by_claim_handler_key,
        {{ get_unknown_member_key("updated_by.claim_handler_key") }} as updated_by_claim_handler_key,
        workplan_activity.activity_assignment_date,
        workplan_activity.activity_created_date,
        workplan_activity.activity_closed_date,
        workplan_activity.activity_due_date,
        workplan_activity.activity_escalation_date,
        workplan_activity.activity_status,
        workplan_activity.activity_priority,
        workplan_activity.activity_type,
        workplan_activity.activity_pattern_subject,
        workplan_activity.activity_description,
        workplan_activity.__source_system_code,
        workplan_activity.__extraction_date_time,
        workplan_activity.__load_id,
        workplan_activity.__data_region,
        workplan_activity.__merge_key,
        1 as __event_sequence_number,
        workplan_activity.__extraction_date_time as __effective_from_date,
        CAST('9999-12-31' as timestamp) AS __effective_to_date,
        true as __is_current,
        {{ dbt_utils.generate_surrogate_key(scd1_columns) }} as __scd1_hash,
        {{ dbt_utils.generate_surrogate_key(scd2_columns) }} as __scd2_hash,
        'I' as __last_action, 
        'Initial Load' as __action_desc
    from workplan_activity
    left join claim on claim.__merge_key = workplan_activity.__claim_merge_key
    left join policy on policy.__merge_key = workplan_activity.__policy_merge_key
    left join claim_handler as assigned_by on assigned_by.__merge_key = workplan_activity.__assigned_by_claim_handler_merge_key
    left join claim_handler as assigned_to on assigned_to.__merge_key = workplan_activity.__assigned_to_claim_handler_merge_key
    left join claim_handler as updated_by on updated_by.__merge_key = workplan_activity.__updated_by_claim_handler_merge_key
    left join claim_handler as closed_by on closed_by.__merge_key = workplan_activity.__closed_by_claim_handler_merge_key
    left join claim_handler as created_by on created_by.__merge_key = workplan_activity.__created_by_claim_handler_merge_key
),

{% if is_incremental() %}

    --Calculate the last SK value to be used as offset; gaps in the numbering is fine so long as there are no key clashes. 
    --Integer values aren't guaranteed to be sequential due to parallel processing in RedShift
     max_sk as (
        select 0 + COALESCE(max( {{surrogate_key_column}} ), 0) as max_val from {{ this }}
    ),

    staged_delta as (

        select
            tgt.{{surrogate_key_column}} as current_record_sk,
            -----------------------------Dimension Attributes----------------------------------
            {%- for column in column_list %}
            src.{{ column | trim }},
            {%- endfor %}
            ----------------------------Meta-data Columns-----------------------------------------
            src.__source_system_code,
            src.__extraction_date_time,
            src.__load_id,
            src.__data_region,
            src.__merge_key,
            -----------------------------------------------------------------------------------------------------------------
            --Preserve the existing meta-data values as they are needed for type 1 updates; they're recalculated for inserts
            -----------------------------------------------------------------------------------------------------------------
            COALESCE(tgt.__event_sequence_number, 0) AS __event_sequence_number,
            src.__effective_from_date as __src_effective_from_date,
            tgt.__effective_from_date as __tgt_effective_from_date,
            -----------------------------------
            src.__scd1_hash,
            src.__scd2_hash,
            case when tgt.__merge_key IS NULL then 'I'
                --SCD1
                when (src.__scd1_hash <> tgt.__scd1_hash
                        and src.__scd2_hash = tgt.__scd2_hash) then 'U'
                --SCD2
                when (src.__scd2_hash <> tgt.__scd2_hash) then 'I' 
                else 'No changes'
            end as __last_action,
            case when tgt.__merge_key IS NULL then 'New Record'
                --SCD1
                when (src.__scd1_hash <> tgt.__scd1_hash
                        and src.__scd2_hash = tgt.__scd2_hash) then 'SCD1 Update'
                --SCD2
                when (src.__scd2_hash <> tgt.__scd2_hash) then 'SCD2 Insert' 
                else 'No changes'
            end as __action_desc
        from src
        left join {{ this }} as tgt
            on src.__merge_key = tgt.__merge_key
            and tgt.__is_current is true
    ),
    
    --These rows are updated (depending on incremental strategy)
    updates as (

        --Case #1: Handle dim records with an effective date in the past
        --Case #2: Type 1 overwite for changes to other columns
        select 
            current_record_sk as {{surrogate_key_column}},
            -----------------------------Dimension Attributes----------------------------------
            {%- for column in column_list %}
            {{ column | trim }},
            {%- endfor %}
            ----------------------------Meta-data Columns-----------------------------------------
            __source_system_code,
            __extraction_date_time,
            __load_id,
            __data_region,
            __merge_key,
            __event_sequence_number,
            __tgt_effective_from_date as __effective_from_date,
            __scd1_hash,
            __scd2_hash,
            __last_action,
            __action_desc
        from staged_delta
        where __last_action = 'U'
           
    ),

    --Scenario 1: New row
    --Scenario 2: An SCD Type 2 attribute has changed on an existing  row
    inserts as (
        
        select 
            max_sk.max_val + ROW_NUMBER() OVER (ORDER BY __extraction_date_time) AS {{surrogate_key_column}},
            -----------------------------Dimension Attributes----------------------------------
            {%- for column in column_list %}
            {{ column | trim }},
            {%- endfor %}
            ----------------------------Meta-data Columns-----------------------------------------
            __source_system_code,
            __extraction_date_time,
            __load_id,
            __data_region,
            __merge_key,
            __event_sequence_number,            
            __src_effective_from_date as __effective_from_date,
            __scd1_hash,
            __scd2_hash,
            __last_action,
            __action_desc
        from staged_delta
        , max_sk
        where __last_action = 'I'
    ),

    --Need to update the meta-data values for the existing "current" record
    reloads as (

        select 
            tgt.{{surrogate_key_column}},
           -----------------------------Dimension Attributes----------------------------------
            {%- for column in column_list %}
            tgt.{{ column | trim }},
            {%- endfor %}
            ----------------------------Meta-data Columns-----------------------------------------
            tgt.__source_system_code,
            tgt.__extraction_date_time,
            tgt.__load_id,
            tgt.__data_region,
            tgt.__merge_key,
            tgt.__event_sequence_number,
            tgt.__effective_from_date,
            tgt.__scd1_hash,
            tgt.__scd2_hash,
            'U' as __last_action,
            'Updated meta-data' as __action_desc
        from {{ this }} as tgt 
        --This join will give you the SK for the existing "current" record for Type2 updates
        inner join staged_delta as stg
            on  tgt.{{surrogate_key_column}} = NVL(stg.current_record_sk, -99999)
        where stg.__last_action = 'I'
    ),

    final as (
    
        select * from updates 
        UNION ALL
        select * from inserts
        UNION ALL
        select * from reloads
    )

{% else %}

    final as (
        select * 
        from src
    )

{% endif %}

select
    {{surrogate_key_column}},
    -----------------------------Dimension Attributes----------------------------------
    {%- for column in column_list %}
    {{ column | trim }},
    {%- endfor %}
    ----------------------------Meta-data Columns-----------------------------------------
    __source_system_code,
    __extraction_date_time,
    __load_id,
    __data_region,
    __merge_key,
    --Need to assign last ESN for each merge key and then add row number to give new ESN
    --Use the SK column to order the rows chronologically in case there is an existing and new row with the same effective date
    (__event_sequence_number - 1) + ROW_NUMBER() OVER(PARTITION BY __merge_key ORDER BY __effective_from_date, {{surrogate_key_column}} ASC) AS __event_sequence_number,
    __effective_from_date,
    COALESCE(
         DATEADD(millisecond, -1,
                    lead(__effective_from_date, 1) IGNORE NULLS OVER (
                          PARTITION BY __merge_key 
                           ORDER BY __effective_from_date ASC
                    )
        ), '9999-12-31' 
    ) AS __effective_to_date,
    CASE WHEN lead(__effective_from_date, 1) IGNORE NULLS OVER (
                PARTITION BY __merge_key 
                ORDER BY __effective_from_date ASC) IS NULL 
        THEN true ELSE false END as __is_current,
    __scd1_hash,
    __scd2_hash,
    __last_action,
   SYSDATE as __last_updated,
   --This column is primarily for debugging to check which rows have been updated following an incremental refresh
   __action_desc
from final