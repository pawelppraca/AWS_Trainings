{{
    generate_cte(
        [
            {"table": "staging_claim_center_cc_claim", "alias": "claim", "columns":["id", "policyid"]},
            {"table": "staging_claim_center_cc_contact", "alias": "cc_contact", "columns":["id", "publicid", "firstname", "lastname"]},
            {"table": "staging_claim_center_cc_exposure", "alias": "cc_exposure", "columns":["id", "claimid", "state", "createuserid", "createtime", "updatetime", "retired"]},
            {"table": "staging_claim_center_cc_exposure_log", "alias": "cc_exposure_log", "columns":["id", "claimid", "createuserid", "createtime", "updatetime", "beanversion", "state", "retired"]},
            {"table": "staging_claim_center_cc_policy", "alias": "cc_policy", "columns":["id", "policynumber", "ext_policyorigin", "verified"]},
            {"table": "staging_claim_center_cc_user", "alias": "cc_user", "columns":["id", "contactid"]},
            {"table": "staging_claim_center_cctl_ext_policyorigin", "alias": "policy_origin", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_historytype", "alias": "history_type", "columns":["id", "name"]},
            {"table": "prep_cc_history_exposure", "alias": "cc_history", "columns":["claimid", "type", "exposureid", "eventtimestamp", "userid", "matterid"]}
        ]
    )
}},
policy as (
        select
                cc_policy.*
        from cc_policy
        left join policy_origin
                on cc_policy.__load_id = policy_origin.__load_id
                and nvl(cc_policy.ext_policyorigin,'10001') = policy_origin.id
        where upper(left(trim(cc_policy.policynumber), 7)) <> 'PLCY-CC'
        and upper(policy_origin."name") <> 'IRIS'
),
exposure as (
    select
        cc_exposure.*
    from cc_exposure
    where cc_exposure."state" <> 1
),
exposure_log as (
    select
        cc_exposure_log.*
    from cc_exposure_log
),
tpa_contacts as (
    select
        users.id as user_id,
        contact.publicid,
        contact.firstname,
        contact.lastname,
        contact.__source_system_code
    from cc_contact  as contact
    inner join cc_user as users
        on contact.__load_id = users.__load_id
        and contact.id = users.contactid
    where upper(left(trim(contact.firstname), 3)) = 'TPA'
    or upper(left(trim(contact.lastname), 3)) = 'TPA'
    or upper(trim(contact.firstname)) = 'LONDON MARKET'
),
history_events as (
    select
        'cc_history' as query_source,
        cc_history.exposureid as exposure_id,
        upper(history_type."name") as exposure_status,
        cc_history.eventtimestamp as event_timestamp,
        cc_history.userid as posted_by_user_id,
        cc_history.__source_system_code,
        cc_history.__extraction_date_time,
        cc_history.__load_id,
        cc_history.__data_region
    from cc_history
    inner join history_type
        on cc_history.__load_id = history_type.__load_id
        and cc_history."type" = history_type.id
    left join exposure
        on cc_history.__load_id = exposure.__load_id
        and cc_history.exposureid = exposure.id
    where cc_history."type" in (15, 10, 18)
),
log_open_events as (
    select
        'exposure_log' as query_source,
        current_exposure.id as exposure_id,
        'OPENED' as exposure_status,
        case when previous_policy.verified = 0
                then current_exposure.createtime
                else current_exposure.updatetime end as event_timestamp,
        current_exposure.createuserid as posted_by_user_id,
        current_exposure.__source_system_code,
        current_exposure.__extraction_date_time,
        current_exposure.__load_id,
        current_exposure.__data_region
    from exposure_log as current_exposure
    inner join exposure_log as previous_exposure
        on current_exposure.__load_id = previous_exposure.__load_id
        and current_exposure.id = previous_exposure.id
        and current_exposure.beanversion = previous_exposure.beanversion + 1
    inner join claim as current_claim
        on current_exposure.claimid = current_claim.id
        and current_exposure.__load_id = current_claim.__load_id
    inner join claim as previous_claim
        on previous_exposure.claimid = previous_claim.id
        and previous_exposure.__load_id = previous_claim.__load_id
    inner join policy as current_policy
        on current_claim.__load_id = current_policy.__load_id
        and current_claim.policyid = current_policy.id
    inner join policy as previous_policy
        on previous_claim.__load_id = previous_policy.__load_id
        and previous_claim.policyid = previous_policy.id
    where nvl(current_exposure.retired,0) = 0
    and current_exposure."state" <> 1
    and ((previous_exposure."state" = 1 and current_policy.verified = 1) or
        (current_policy.verified = 1 and previous_policy.verified = 0))
),
tpa_open_events AS (
    select
        'tpa' as query_source,
        exposure.id as claim_id,
        'OPENED' as exposure_status,
        exposure.createtime as event_timestamp,
        exposure.createuserid as posted_by_user_id,
        exposure.__source_system_code,
        exposure.__extraction_date_time,
        exposure.__load_id,
        exposure.__data_region
    from exposure
    inner join claim
        on exposure.__load_id = claim.__load_id
        and exposure.claimid = claim.id
    inner join policy
        on claim.__load_id = policy.__load_id
        and claim.policyid = policy.id
    inner join tpa_contacts
        on exposure.createuserid = tpa_contacts.user_id
    where exposure.retired = 0
),
all_open_events as (
    select
        *,
        1 as _precedence
    from history_events
    where exposure_status = 'OPENED'
    union all
    select
        *,
        2 as _precedence
    from log_open_events
    union all
    select
        *,
        3 as _precedence
    from tpa_open_events
),
open_events AS (
        SELECT
                query_source,
                exposure_id,
                exposure_status,
                event_timestamp,
                posted_by_user_id,
                row_number() over (partition by __load_id, exposure_id order by date_trunc('second', event_timestamp) asc, _precedence ASC) as event_number,
                __source_system_code,
                __extraction_date_time,
                __load_id,
                __data_region
        FROM all_open_events
),
final AS (
        SELECT 
                query_source,
                exposure_id,
                exposure_status,
                event_timestamp,
                posted_by_user_id,
                __source_system_code,
                __extraction_date_time,
                __load_id,
                __data_region
        FROM open_events
        WHERE event_number = 1
        UNION
        SELECT 
                query_source,
                exposure_id,
                exposure_status,
                event_timestamp,
                posted_by_user_id,
                __source_system_code,
                __extraction_date_time,
                __load_id,
                __data_region
        FROM history_events
        WHERE exposure_status <> 'Opened'
)
SELECT
        exposure_id,
        exposure_status,
        event_timestamp,
        posted_by_user_id,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region
FROM final