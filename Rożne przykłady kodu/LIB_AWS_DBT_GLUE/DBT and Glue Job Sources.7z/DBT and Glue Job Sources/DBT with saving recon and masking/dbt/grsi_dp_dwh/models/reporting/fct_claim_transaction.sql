{{ config({
    "alias": "fct_claim_transaction"
    })
}}

{%- set derived_measures = [
    {
        "measure_type_code":"TOTAL_PAID_GROSS",
        "base_measures":["PAID_IND_GROSS", "PAID_FEE_GROSS"]
    },
    {
        "measure_type_code":"TOTAL_OS_GROSS",
        "base_measures":["OS_IND_GROSS", "OS_FEE_GROSS"]
    },
    {
        "measure_type_code":"TOTAL_INCURRED_GROSS",
        "base_measures":["PAID_IND_GROSS", "PAID_FEE_GROSS", "PAID_REC_GROSS", "OS_IND_GROSS", "OS_FEE_GROSS"] 
    }
]
-%}

{{
    generate_cte(
        [
            {"table": "fct_claim_transaction_base", "alias": "base_measures"},
            {"table": "dim_measure_type", "alias": "measure_type"},
        ],
        include_meta_data_columns=false
    )
}},
derived_measures AS (
    {% for measure in derived_measures %}
    SELECT
        claim_key, 
        claim_profile_history_key,
        {{ get_unknown_member_key("null") }} as claim_movement_type_key, --Measure is at higher grain so field is n/a 
        ri_code_key,
        transaction_type_key, 
        '{{ measure.measure_type_code }}' as measure_type_code, 
        transaction_date_key, 
        posting_date_key, 
        fiscal_date_key, 
        original_currency_key,
        local_currency_key,
        group_currency_key,
        SUM(CASE WHEN {{ generate_sql_in_condition('measure_type_code', measure.base_measures) }}
                 THEN amount_original ELSE 0.0 END) as amount_original,
        SUM(CASE WHEN {{ generate_sql_in_condition('measure_type_code', measure.base_measures) }}
                 THEN amount_local ELSE 0.0 END) as amount_local, 
        SUM(CASE WHEN {{ generate_sql_in_condition('measure_type_code', measure.base_measures) }}
                 THEN amount_group ELSE 0.0 END) as amount_group
    FROM base_measures
    GROUP BY 
        claim_key, 
        claim_profile_history_key,
        ri_code_key,
        transaction_type_key, 
        measure_type_code,  
        transaction_date_key, 
        posting_date_key, 
        fiscal_date_key,
        original_currency_key,
        local_currency_key,
        group_currency_key

    {% if not loop.last %}
    UNION ALL
    {% endif -%}
  {% endfor %}
),

all_measures AS (

    SELECT
        claim_key, 
        claim_profile_history_key,
        claim_movement_type_key, 
        ri_code_key,
        transaction_type_key, 
        measure_type_code, 
        transaction_date_key, 
        posting_date_key, 
        fiscal_date_key, 
        original_currency_key,
        local_currency_key,
        group_currency_key,
        amount_original, 
        amount_local, 
        amount_group 
    FROM base_measures

    UNION ALL

    SELECT
        claim_key, 
        claim_profile_history_key,
        claim_movement_type_key, 
        ri_code_key,
        transaction_type_key, 
        measure_type_code, 
        transaction_date_key, 
        posting_date_key, 
        fiscal_date_key,
        original_currency_key,
        local_currency_key,
        group_currency_key,
        amount_original, 
        amount_local, 
        amount_group 
    FROM derived_measures

),
final as (

    select 
        a.claim_key, 
        a.claim_profile_history_key as claim_history_key,
        a.claim_movement_type_key, 
        a.ri_code_key,
        a.transaction_type_key, 
        m.measure_type_key, 
        a.transaction_date_key, 
        a.posting_date_key, 
        a.fiscal_date_key,
        a.original_currency_key,
        a.local_currency_key,
        a.group_currency_key,
        a.amount_original, 
        a.amount_local, 
        a.amount_group 
    from all_measures as a
    left join measure_type as m
        on a.measure_type_code = m.measure_type_code
)

SELECT *
FROM final 