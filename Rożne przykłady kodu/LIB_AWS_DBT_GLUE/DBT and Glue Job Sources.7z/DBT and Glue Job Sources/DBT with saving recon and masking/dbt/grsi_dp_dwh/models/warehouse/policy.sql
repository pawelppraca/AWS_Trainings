{{
    generate_cte(
        [
            {"table": "prep_policy_final", "alias": "prep_policy_final"},
			{"table": "broker", "alias": "dwh_broker", "columns": ["broker_key"]}
        ]
    )
}},
source_data AS (
    
    select  
        ROW_NUMBER() OVER (ORDER BY __extraction_date_time)::bigint AS policy_key,
        *
    from prep_policy_final
    where __record_version = 1
),
{{
    generate_unknown_member_cte(
        target_model="prep_policy_final",
        surrogate_key_column="policy_key"
    )
}},
policies AS (

    select * from source_data
    union all
    select * from unknown_member
),
final AS (
	select 
		policies.policy_key,
		{{ get_unknown_member_key("brk.broker_key") }} as broker_key,
		policies.branch_code,
		policies.product_name,
		policies.underwriter_code,
		policies.underwriter_name,
		policies.uw_assistant_code,
		policies.uw_assistant_name,
		policies.risk_engineer_code,
		policies.risk_engineer_name,
		policies.uw_office_key,
		policies.wr_broker_key,
		policies.broker_contact_name,
		--ClaimTriggerCode,		--ZUMA.ClaimTriggerCode/Name needs to be added to dbo.PolicyDetails - LSMDATA-5173
		--ClaimTriggerName,
		policies.inception_date_key,
		policies.policy_status,
		policies.policy_status_detail_code,
		policies.policy_status_detail,
		policies.attachment_type_code,
		policies.attachment_type,
		policies.new_business_renewal,
		policies.direct_assumed,
		policies.lead_or_follow,
		policies.expiry_date,
		policies.policy_master_number,
		policies.policy_sequence_number,
		policies.policy_number,
		policies.policy_reference,
		policies.policy_title,
		policies.policy_written_date_key,
		policies.program_name,
		policies.project_name,
		policies.surplus_lines,	--PJD missing for dummy policies, causing duplicates with NULL/<<Unknown>>, solved with ctePJD
		policies.insured_name, 	  --data issue/duplication on BI_LZ
		policies.insured_code,  --data issue/duplication on BI_LZ
		policies.reassured_name,
		policies.reassured_code,
		policies.lgs_company,
		policies.lgs_company_code,
		policies.year_of_account,
		--AffiliateCode,	--needs to be added to PolicyDetails, all data is available in ODS_GENIUS - LSMDATA-5174
		--Affiliated	--needs to be added to PolicyDetails, all data is available in ODS_GENIUS - LSMDATA-5174
		policies.leader_name,
		policies.leader_policy_ref,
		policies.leader_administers_premiums_flag,
		policies.leader_administers_claims_flag,
		policies.__source_system_code,
		policies.__extraction_date_time,
		policies.__load_id,
		policies.__data_region,
		policies.__merge_key,
		policies.wr_policy_detail_key
	from policies
	left join dwh_broker as brk
		on policies.__broker_merge_key = brk.__merge_key

)
select *
from final