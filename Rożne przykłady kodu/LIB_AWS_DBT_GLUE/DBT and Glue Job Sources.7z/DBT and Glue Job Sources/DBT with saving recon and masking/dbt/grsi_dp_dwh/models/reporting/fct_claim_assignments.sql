{{
    generate_cte(
        [
            {"table": "claim", "alias": "claim", "columns": ["claim_key","policy_key"]},
            {"table": "claim_handler", "alias": "claim_handler", "columns": ["claim_handler_key"]},
            {"table": "claim_profile_history", "alias": "claim_profile_history", "columns": ["claim_key","previous_claim_handler_key","current_claim_handler_key","__effective_from_date"]}
        ]
    )
}},
assignments as (
    select
        claim.claim_key,
        claim.policy_key,
        claim_handler.claim_handler_key,
        cph.__effective_from_date as assignment_date,
        {{ get_date_key('cph.__effective_from_date') }} as assignment_date_key,
        1 as assignment_count,
        0 as reassignment_count
    from claim
    inner join claim_profile_history as cph
        on claim.claim_key = cph.claim_key
    inner join claim_handler
        on cph.current_claim_handler_key = claim_handler.claim_handler_key
    where
        cph.current_claim_handler_key != {{ get_unknown_member_key("null") }}
        and cph.current_claim_handler_key != cph.previous_claim_handler_key
),
reassignments as (
    select
        claim.claim_key,
        claim.policy_key,
        claim_handler.claim_handler_key,
        cph.__effective_from_date as assignment_date,
        {{ get_date_key('cph.__effective_from_date') }} as assignment_date_key,
        0 as assignment_count,
        1 as reassignment_count
    from claim
    inner join claim_profile_history as cph
        on claim.claim_key = cph.claim_key
    inner join claim_handler
        on cph.previous_claim_handler_key = claim_handler.claim_handler_key
    where
        cph.previous_claim_handler_key != {{ get_unknown_member_key("null") }}
        and cph.current_claim_handler_key != cph.previous_claim_handler_key
),
claim_assignments AS (
    select * from assignments
    union all
    select * from reassignments
),
final as (
    select
        row_number() over (order by assignment_date_key)::bigint as id,
        claim_key as dim_claim_key,
        policy_key as dim_policy_key,
        assignment_date_key as movement_date_key,
        claim_handler_key as dim_claim_handler_key,
        assignment_count,
        reassignment_count
    from claim_assignments
)
select *
from final