{{
    generate_cte(
        [
            {"table": "prep_dim_date_final", "alias": "src"}
        ]
    )
}},
date_source as (

    select 
        {{ get_date_key('date_day') }} as date_key,
        *
    from src
    
),

{% if is_incremental() %}

    final as (
        select *
        from date_source
        -- uses > to only include new dates added to spine - happens once per year
        where date_key > (select max(date_key) from {{ this }})
    )

{% else %}

    default_date_calculated as (select '{{ get_unknown_member_date() }}'::date as date_day),

    unknown_member as (
        select
            {{ get_date_key('date_day') }} as date_key,
            date_day,
            date_part('dayofweek', date_day)::int as day_number_of_week,
            to_char(date_day, 'Day') as english_day_name_of_week,
            date_part('day', date_day)::int as day_number_of_month,
            date_part('dayofyear', date_day)::int as day_number_of_year,
            date_part('week', date_day)::int as week_number_of_year,
            to_char(date_day, 'Mon') as english_month_name,
            to_char(date_day, 'Month') as english_full_month_name,
            to_char(date_day, 'Mon')
            || ' '
            || to_char(date_day, 'YYYY') as english_month_year,
            date_part('month', date_day)::int as month_number_of_year,
            (to_char(date_day, 'YYYY') || to_char(date_day, 'MM'))::int
            as calendar_year_month,
            date_part('quarter', date_day)::int as calendar_quarter,
            date_part('year', date_day)::int as calendar_year,
            case
                when date_part('quarter', date_day) <= 2 then 1 else 2
            end as calendar_semester,
            case
                when last_day(date_day) = trunc(date_day) then true else false
            end as is_last_day_of_month,
            '' as liberty_fiscal_period,
            '' as liberty_fiscal_year,
            '' as lmie_fiscal_period,
            '' as lmie_fiscal_year,
            'SYSTEM' as __source_system_code,
            sysdate as __extraction_date_time,
            -1 as __load_id
        from default_date_calculated
    ),

    final as (
        select *
        from date_source
        union all
        select *
        from unknown_member
    )

{% endif %}

select
    date_key,
    date_day,
    day_number_of_week,
    english_day_name_of_week,
    day_number_of_month,
    day_number_of_year,
    week_number_of_year,
    english_month_name,
    english_full_month_name,
    english_month_year,
    month_number_of_year,
    calendar_year_month,
    calendar_quarter,
    calendar_year,
    calendar_semester,
    is_last_day_of_month,
    liberty_fiscal_period,
    liberty_fiscal_year,
    lmie_fiscal_period,
    lmie_fiscal_year,
    __source_system_code,
    __extraction_date_time,
    __load_id
from final
