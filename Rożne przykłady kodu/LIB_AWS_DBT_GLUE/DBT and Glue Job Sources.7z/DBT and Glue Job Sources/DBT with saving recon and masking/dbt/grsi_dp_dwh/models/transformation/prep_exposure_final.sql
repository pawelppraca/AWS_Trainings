
{{
    generate_cte(
        [
            {"table": "prep_claim_filtered", "alias": "filtered_claim", "columns":["id","claim_number","policyid","state","retired"]},
            {"table": "staging_claim_center_cc_contact", "alias": "contact_source", "columns": ["id", "name","namedenorm","firstname","lastname"]},
            {"table": "staging_claim_center_cc_coverage", "alias": "coverage_source", "columns": ["id","type","ext_geniussecdet","ext_sfc2cd"]},
            {"table": "staging_claim_center_cc_exposure", "alias": "exposure_source", "columns":["id","claimid","claimorder","ext_parentpid","state","closedate","createtime","ext_losstransfer","assignedgroupid", "createuserid", "assigneduserid", "assignedbyuserid", "updateuserid","claimantdenormid","claimanttype","closedoutcome","reopendate","exposuretype","incidentid","ext_isojurisdictionstate","isostatus","ocr_ext","retired","coverageid"]},
            {"table": "staging_claim_center_cc_incident", "alias": "incident_source", "columns":["id","description"]},
            {"table": "staging_claim_center_cc_policy", "alias": "policy_source", "columns":["id","currency","retired","policynumber"]},
            {"table": "staging_claim_center_cctl_coveragetype", "alias": "coverage_type", "columns":["id","name","typecode"]},
            {"table": "staging_claim_center_cctl_currency", "alias": "currency", "columns":["id","name"]},
            {"table": "staging_claim_center_cctl_claimanttype", "alias": "claimant_type", "columns":["id","name"]},
            {"table": "staging_claim_center_cctl_exposureclosedoutcometype", "alias": "outcome_type", "columns":["id","name"]},
            {"table": "staging_claim_center_cctl_exposurestate", "alias": "exposure_state", "columns":["id","name"]},
            {"table": "staging_claim_center_cctl_exposuretype", "alias": "exposure_type", "columns":["id","name"]},
            {"table": "staging_claim_center_cctl_ext_isojurisdictionstate", "alias": "isojs", "columns":["id","name"]},
            {"table": "staging_claim_center_cctl_isostatus", "alias": "isostatus_table", "columns":["id","name"]},
            {"table": "staging_warehouse_repository_limits", "alias": "repo_limits", "columns": ["policykey","_mergekey","_effectiveto"]},
            {"table": "staging_warehouse_repository_policies", "alias": "repo_policy", "columns": ["policyreference","policykey","_effectiveto"]}
        ]
    )
}},
coverage_link_fields as (
    select
        exposure.id as exposure_id,
        coverage.ext_geniussecdet as section_detail,
        coverage_type.typecode	as coverage_code,
        exposure.claimorder as claim_order,
        coverage.ext_sfc2cd as class_long_name,
        right(left(replace(limits._mergekey, '][', '|'), 29), 28) as __coverage_merge_key
    from filtered_claim as claim
	inner join exposure_source AS exposure
        on claim.id = exposure.claimid
	inner join coverage_source as coverage
        on coverage.id = exposure.coverageid
	inner join coverage_type
        on coverage.type = coverage_type.id
	inner join policy_source as policy
        on policy.id = claim.policyid
    inner join repo_policy
        on repo_policy.policyreference = policy.policynumber
    inner join repo_limits as limits
        on limits.policykey = repo_policy.policykey
    where exposure.retired=0
        and claim.retired=0
        and policy.retired=0
        and repo_policy._effectiveto='9999-12-31 00:00:00.000000'
        and limits._effectiveto='9999-12-31 00:00:00.000000'
),
exposure as (
    select
        exposure.*,
        currency.name as currency_code,
        claim.claim_number,
        nullif(coalesce(nvl(contacts.name, contacts.namedenorm), nullif(trim(nvl(contacts.lastname, '') || ', ' || nvl(contacts.firstname,'')), ',')), '') as claimant,
        claimant_type."name" as claimant_type,
        case when exposure.closedate is not null and exposure.closedoutcome is null then 'Completed' else outcome_type."name" end as exposure_closed_outcome,
        exposure_type."name" as exposure_type,
        incident.description as exposure_description,
        isojs."name" as iso_jurisdiction,
        isostatus_table."name" as iso_status,
        exposure_state.name as exposure_state,
        coverage_link_fields.section_detail,
        coverage_link_fields.coverage_code,
        coverage_link_fields.class_long_name,
        coverage_link_fields.__coverage_merge_key,
        claim.state as claim_state,
        claim.retired as claim_retired
    from exposure_source as exposure
    inner join filtered_claim as claim
        on exposure.claimid = claim.id
    left join policy_source as policy
        on policy.id = claim.policyid
    left join currency
        on policy.currency = currency.id
    left join contact_source as contacts
        on exposure.claimantdenormid = contacts.id
    left join claimant_type
        on exposure.claimanttype = claimant_type.id
    left join exposure_state
        on exposure.state = exposure_state.id
    left join exposure_type
        on exposure.exposuretype = exposure_type.id
    left join incident_source as incident
        on incident.id = exposure.incidentid
    left outer join isojs
        on isojs.id = exposure.ext_isojurisdictionstate
    left join isostatus_table
        on isostatus_table.id = exposure.isostatus
    left join outcome_type
        on outcome_type.id = exposure.closedoutcome
    left join coverage_link_fields
        on exposure.id = exposure_id
        and coverage_link_fields.claim_order = exposure.claimorder
),
final as (
    select
        claimorder as exposure_number,
        claimant,
        claimant_type,
        exposure_closed_outcome,
        createtime as exposure_created_date,
        exposure_type,
        exposure_description,
        iso_jurisdiction,
        iso_status,
        ext_losstransfer as loss_transfer_flag,
        exposure_state,
        section_detail,
        coverage_code,
        class_long_name,
        __coverage_merge_key,
        {{ generate_merge_key(["__source_system_code", "claim_number"]) }} as __claim_merge_key,
        {{ generate_merge_key(["currency_code"]) }} as __currency_merge_key,
        {{ generate_merge_key(["__source_system_code", "createuserid"]) }} as __created_by_merge_key,
        {{ generate_merge_key(["__source_system_code", "assigneduserid"]) }} as __assigned_to_merge_key,
        {{ generate_merge_key(["__source_system_code", "assignedbyuserid"]) }} as __assigned_by_merge_key,
        {{ generate_merge_key(["__source_system_code", "updateuserid"]) }} as __updated_by_merge_key,
        {{ generate_merge_key(["__source_system_code", "assignedgroupid"]) }} as __assigned_group_merge_key,
         __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region,
        {{ generate_merge_key(["__source_system_code", "id::text"],)}} as __merge_key,
        row_number() over ( partition by __merge_key order by __extraction_date_time desc ) as __record_version
    from
    exposure
    where exposure.state <> 1
        and exposure.claim_state <> 1
        and exposure.retired = 0
        and exposure.claim_retired = 0
        and exposure.ext_parentpid is null
)
select *
from final