{{
    generate_cte(
        [
            {"table": "prep_claim_status_history", "alias": "claim_status_events"},
            {"table": "prep_cc_history_claim", "alias": "cc_history", "columns":["claimid", "claim_number", "eventtimestamp", "userid", "type"]}
        ]
    )
}},

assignment_events AS (
        SELECT
                claimid AS claim_id,
                claim_number,
                eventtimestamp AS event_timestamp,
                userid AS posted_by_user_id,
                __source_system_code,
                __extraction_date_time,
                __load_id,
                __data_region
        FROM cc_history  
        WHERE type = 4
),
all_events AS (
        SELECT 
                NVL(e1.claim_id, e2.claim_id) AS claim_id,
                NVL(e1.claim_number, e2.claim_number) AS claim_number,
                e1.claim_status, --could be NULL for assignment only events won't have a claim status --> look up later 
                NVL(e1.event_timestamp, e2.event_timestamp) AS event_timestamp,
                NVL(e1.posted_by_user_id, e2.posted_by_user_id) AS posted_by_user_id,
                NVL(e1.__source_system_code, e2.__source_system_code) AS __source_system_code,
                NVL(e1.__extraction_date_time, e2.__extraction_date_time) AS __extraction_date_time,
                NVL(e1.__load_id, e2.__load_id) AS __load_id,
                NVL(e1.__data_region, e2.__data_region) AS __data_region
        FROM claim_status_events e1
        FULL OUTER JOIN assignment_events e2
                ON  e1.__load_id = e2.__load_id
                AND e1.claim_id = e2.claim_id 
                AND e1.event_timestamp = e2.event_timestamp
),
final AS (
        SELECT
                {{
                        generate_merge_key(
                                [
                                "__source_system_code",
                                "claim_number",
                                ], preserve_nulls=True
                )
                }} as __claim_merge_key,
                {{
                        generate_merge_key(
                                [
                                "claim_status"
                                ], preserve_nulls=True
                )
                }} as __claim_status_merge_key,
                event_timestamp,
                 {{
                        generate_merge_key(
                                [
                                "__source_system_code",
                                "posted_by_user_id",
                                ], preserve_nulls=True
                )
                }} as __posted_by_merge_key,
                __source_system_code,
                __extraction_date_time,
                __load_id,
                __data_region
        FROM all_events
)
SELECT *
FROM final