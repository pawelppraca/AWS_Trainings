
{{
    generate_cte(
        [
            {"table": "staging_claim_center_cc_address", "alias": "address_source", "columns":["id","addressline1","addressline2","addressline3","ext_addressline4","ext_addressline5","ext_city","ext_state","country","postalcodedenorm","ext_region"]},
            {"table": "staging_claim_center_cctl_state", "alias": "state_source", "columns":["id","name"]},
            {"table": "staging_claim_center_cctl_country", "alias": "country_source", "columns":["id","name"]}
        ]
    )
}},
final as (
    select
        nvl(address.addressline1,'') as address_line_1,
        nvl(address.addressline2,'') as address_line_2,
        nvl(address.addressline3,'') as address_line_3,
        nvl(address.ext_addressline4,'') as address_line_4,
        nvl(address.ext_addressline5,'') as address_line_5,
        nvl(address.ext_city,'') as city,
        nvl(states.name,'') as state_name,
        nvl(country.name,'') as country_name,
        nvl(address.postalcodedenorm,'') as post_code,
        address.__source_system_code,
        address.__extraction_date_time,
        address.__load_id,
        address.__data_region,
        {{
            generate_merge_key(
                [
                    "address.__source_system_code",
                    "address.id::text"
                ],
            )
        }} as __merge_key,
        row_number() over (
                partition by __merge_key order by address.__extraction_date_time desc
        ) as __record_version
    from address_source as address
    left outer join state_source as states
        on states.id=address.ext_state
    left outer join	country_source as country
        on address.country = country.id
)
select *
from final