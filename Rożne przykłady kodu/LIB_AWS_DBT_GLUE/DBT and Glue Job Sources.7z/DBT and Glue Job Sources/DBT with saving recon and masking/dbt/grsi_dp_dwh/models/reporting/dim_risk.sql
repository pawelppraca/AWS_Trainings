{{
    generate_cte(
        [
            {"table": "risk", "alias": "risk"}
        ]
    )
}},
final as (
    select
        risk_key,
        policy_key,
        geography_key,
        industry_code,
        industry_name,
        risk_share,
        lob_code,
        lob_description,
        department_code,
        risk_description,
        section_type_code,
        section_type,
        fac_indicator,
        risk_number,
        wr_policykey,
        __source_system_code,
        __data_region,
        __merge_key,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'risk_key']) }} as __global_risk_key
    from risk
)
select *
from final