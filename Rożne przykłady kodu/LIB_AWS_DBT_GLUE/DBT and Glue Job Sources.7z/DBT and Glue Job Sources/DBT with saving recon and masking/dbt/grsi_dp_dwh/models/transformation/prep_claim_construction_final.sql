
{{
    generate_cte(
        [
            {"table": "staging_claim_center_cctl_ext_projectphase", "alias": "projectphase", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_projectdeliverytype", "alias": "projectdeliverytype", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cctl_extphaseofoperation", "alias": "phaseofoperation", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cc_claim", "alias": "claim", "columns": ["id", "ext_phaseofoperation", "ext_projectphase", "ext_projectdeliverytype"]}
        ]
    )
}},

meta_data as (
   
    select
        __load_id,
        __source_system_code,
        __data_region,
        max(__extraction_date_time) as __extraction_date_time
    from phaseofoperation
    group by __load_id, __source_system_code, __data_region

),
claim_construction AS (
    SELECT DISTINCT	
	    ISNULL(po.name,'NA')	AS	phase_of_operation
	    , ISNULL(pp.name,'NA')	AS	project_phase
	    , ISNULL(pd.name,'NA')	AS	project_delivery_type
        , c.__source_system_code
        , c.__load_id
        , c.__data_region
    FROM
        claim AS c
        LEFT JOIN phaseofoperation	AS po ON po.ID = c.ext_phaseofoperation
        LEFT JOIN projectphase		AS pp ON pp.ID = c.ext_projectphase
        LEFT JOIN projectdeliverytype	AS pd ON pd.ID = c.ext_projectdeliverytype
    GROUP BY 
	    ISNULL(po.name,'NA')
	    , ISNULL(pp.name,'NA')
	    , ISNULL(pd.name,'NA')
        , c.__source_system_code
        , c.__load_id
        , c.__data_region
),
join_meta_data AS (
    SELECT
        cs.phase_of_operation,
        cs.project_phase,
        cs.project_delivery_type,
        cs.__source_system_code,
        meta_data.__extraction_date_time,
        cs.__load_id,
        cs.__data_region
    FROM claim_construction as cs
    INNER JOIN meta_data
    ON cs.__load_id = meta_data.__load_id
    AND cs.__source_system_code = meta_data.__source_system_code
    AND cs.__data_region = meta_data.__data_region
),
final AS (
    SELECT
        phase_of_operation,
        project_phase,
        project_delivery_type,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region,
        {{
            generate_merge_key(
                [
                    "__source_system_code",
                    "phase_of_operation",
                    "project_phase",
                    "project_delivery_type"
                ]
            )
        }} AS __merge_key,
        row_number() OVER (
                PARTITION BY __merge_key ORDER BY __extraction_date_time DESC
        ) AS __record_version
    FROM join_meta_data
)
SELECT *
FROM final