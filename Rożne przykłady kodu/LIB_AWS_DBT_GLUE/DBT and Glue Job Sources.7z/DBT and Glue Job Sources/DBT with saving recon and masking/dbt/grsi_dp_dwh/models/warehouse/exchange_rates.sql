{{
    generate_cte(
        [
            {"table": "prep_exchange_rates_final", "alias": "fx_rates"}
        ]
    )
}},
final AS (

    SELECT 
        exchange_rate_type, 
        exchange_rate_from_date, 
        exchange_rate_to_date, 
        from_currency_code, 
        to_currency_code, 
        exchange_rate, 
        __source_system_code, 
        __extraction_date_time, 
        __load_id 
    FROM fx_rates
)
select *
from final
