{{
    generate_cte(
        [
            {"table": "prep_currency_final", "alias": "prep_currency_final"}
        ]
    )
}},
source_data AS (
    
    select  
        ROW_NUMBER() OVER (ORDER BY __extraction_date_time)::bigint AS currency_key,
        *
    from prep_currency_final
    where __record_version = 1
),
{{
    generate_unknown_member_cte(
        target_model="prep_currency_final",
        surrogate_key_column="currency_key"
    )
}},
final AS (

    select * from source_data
    union all
    select * from unknown_member
)
select 
    currency_key,
    currency_code,
    currency_name,
    __source_system_code,
    __extraction_date_time,
    __load_id,
    __data_region,
    __merge_key
from final