{{
    generate_cte(
        [
            {"table": "prep_claim_inventory_final", "alias": "prep_claim_inventory_final"},
            {"table": "claim", "alias": "claim", "columns": ["claim_key","__merge_key"]},
            {"table": "claim_handler", "alias": "claim_handler", "columns": ["claim_handler_key","__merge_key"]},
            {"table": "claim_handler_group", "alias": "claim_handler_group", "columns": ["claim_handler_group_key","__merge_key"]},
            {"table": "policy", "alias": "policy", "columns":["policy_key","__merge_key"]},
        ]
    )
}},
source_data as (
    select
        row_number() over (order by __extraction_date_time)::bigint as claim_inventory_key,
        *
    from prep_claim_inventory_final
    where __record_version = 1
),
{{
    generate_unknown_member_cte(
        target_model="prep_claim_inventory_final",
        surrogate_key_column="claim_inventory_key"
    )
}},
claim_inventory AS (
    select * from source_data
    union all
    select * from unknown_member
),
final as (
    select
        claim_inventory_key,
        inventory_movement_date,
        inventory_type,
        inventory_description,
        {{ get_unknown_member_key("claim.claim_key") }} as claim_key,
        {{ get_unknown_member_key("policy.policy_key") }} as policy_key,
        {{ get_unknown_member_key("created_by_ch.claim_handler_key") }} as created_by_claim_handler_key,
        {{ get_unknown_member_key("assigned_ch.claim_handler_key") }} as assigned_to_claim_handler_key,
        {{ get_unknown_member_key("assigned_by_ch.claim_handler_key") }} as assigned_by_claim_handler_key,
        {{ get_unknown_member_key("updated_by_ch.claim_handler_key") }} as updated_by_claim_handler_key,
        {{ get_unknown_member_key("assigned_group.claim_handler_group_key") }} as assigned_group_key,
        claim_inventory.__source_system_code,
        claim_inventory.__extraction_date_time,
        claim_inventory.__load_id,
        claim_inventory.__data_region,
        claim_inventory.__merge_key
    from claim_inventory
    left join claim
        on claim_inventory.__claim_merge_key = claim.__merge_key
    left join claim_handler AS created_by_ch
        on claim_inventory.__created_by_merge_key = created_by_ch.__merge_key
    left join claim_handler AS assigned_ch
        on claim_inventory.__assigned_to_merge_key = assigned_ch.__merge_key
    left join claim_handler AS assigned_by_ch
        on claim_inventory.__assigned_by_merge_key = assigned_by_ch.__merge_key
    left join claim_handler AS updated_by_ch
        on claim_inventory.__updated_by_merge_key = updated_by_ch.__merge_key
    left join claim_handler_group AS assigned_group
        on claim_inventory.__assigned_group_merge_key = assigned_group.__merge_key
    left join policy
        on claim_inventory.__policy_merge_key = policy.__merge_key
)
select *
from final

