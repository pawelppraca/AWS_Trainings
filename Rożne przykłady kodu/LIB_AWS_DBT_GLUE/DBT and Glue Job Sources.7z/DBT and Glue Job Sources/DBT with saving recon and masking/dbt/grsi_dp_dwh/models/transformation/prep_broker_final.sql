
{{
    generate_cte(
        [
            {"table": "staging_warehouse_repository_brokers", "alias": "broker_source", "columns":["BrokerKey", "BrokerCode","BrokerName", "BrokerState", "BrokerCountry", "_mergekey","_sourcesystemcode","_currentflag"]}
        ]
    )
}},
final as (

    select
        BrokerCode as broker_code,
        BrokerName as broker_name,
        BrokerState as broker_state,
        BrokerCountry as broker_country,
        _sourcesystemcode as __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region,
        --TODO: The Broker dim in Warehouse_repository is SCD Type 2 so to ensure we pick up the correct version we need to use the WR surrogate key
        --Change to the proper Genius merge key __source_system_code|brokercode when repointing to Data Lake.
        {{
                    generate_merge_key(
                        [
                            "_sourcesystemcode",
                            "BrokerKey::text"
                        ],
                    )
                }} as __merge_key,
        row_number() over (
                partition by __merge_key order by __extraction_date_time desc
            ) as __record_version,
        BrokerKey as wr_broker_key
    from broker_source
    where _currentflag = 1

)
select *
from final