{{
    generate_cte(
        [
            {"table": "prep_cc_policy", "alias": "cc_policy", "columns":["id", "policy_master_number", "policy_master_sequence"]},
            {"table": "prep_claim_apra_final", "alias": "claim_apra", "columns": ["apra_injury", "apra_col", "apra_jurisdiction", "apra_litigation", "apra_regulatory"]},
            {"table": "prep_claim_filtered", "alias": "clm", "columns":["publicid", "id", "claim_number", "assignmentdate", "claimsource", "reporteddate", "createtime",
                    "lossdate", "daterptdtoinsured", "ext_locationtext", "ext_addexposureunverified", "ext_alternateclaimfilenumber", "description", "reopendate", "ext_title",
                    "closedate", "flaggeddate", "ext_lastrevaldate", "updatetime", "flaggedreason", "ext_bizinterruption_money", "ext_prdamage_money", "ext_grounduplosstotal_money",
                    "insurerriskreference_syn", "ext_llrflagged", "ext_supplementalpaymentmade", "reinsurancereportable", "ext_tpaclaimnumber", "ucr_ext", "ext_coll1descother", "ext_coll2descother",
                    "ext_coll3descother", "ext_coll4descother", "ext_cyberconsiderationother", "syndicateid_syn", "ext_fasttrack", "ext_batchedclaim", "assignedgroupid", "createuserid",
                    "assigneduserid", "assignedbyuserid", "updateuserid", "policyid", "claimevent", "state", "claimtier", "ext_claimtype", "ext_handledby", "ext_isseveritycode", "ext_severity",
                    "permissionrequired", "ext_coll1", "ext_coll2", "ext_coll3", "ext_coll3_pi", "ext_coll4", "ext_collcode4", "ext_projecttype", "ext_typeofwork2", "ext_policycovsectionusa", "ext_coll5",
                    "causeoflosscode_syn", "ext_losscodeset", "ext_cyberconsideration", "ext_ransomwareaspect", "ext_claimsorganization", "ext_coverageindicatorpr", "ext_coverageindicator", "ext_deductibletype",
                    "faultrating", "ext_handlingtype", "largelossnotificationstatus", "howreported", "ext_isolosslocation", "reportedbytype", "ext_cargo", "ext_proceedings", "ext_proceedingspr",
                    "litigationstatus", "ext_product", "closedoutcome","catastropheid", "ext_apracol", "ext_aprainjury", "ext_apacjurisdiction", "ext_apralitcodes", "ext_regulatorycode", "ext_esmanufacturer",
                    "ext_esmodelnumber", "ext_estechnologytype", "ext_esvariant", "ext_equipmentstruct", "ext_section", "losslocationid", "ext_phaseofoperation", "ext_projectphase", "ext_projectdeliverytype",
                    "ext_blockfile","ext_lossfund","ext_generalclaimnote","ext_vulnerablecustomer","ext_datecoverageletterissued","ext_externalreference"]},
            {"table": "staging_claim_center_cc_coverage", "alias": "coverage_source", "columns":["ext_coveragelabel","ext_sectiondesc", "id"]},
            {"table": "staging_claim_center_cc_exposure", "alias": "exposure_source", "columns":["coverageid", "claimid"]},
            {"table": "staging_claim_center_cc_matter", "alias": "matter", "columns":["claimid", "closedate", "mattertype"]},
            {"table": "staging_claim_center_cc_incident", "alias": "incident", "columns":["claimid", "ext_injuredpersontype"]},
            {"table": "staging_claim_center_ccx_ext_claimevent", "alias": "clm_event", "columns":["id", "ext_name", "ext_description"]},
            {"table": "staging_claim_center_cctl_claimstate", "alias": "clm_state", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_claimtier", "alias": "clm_tier", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_extclaimtype", "alias": "clm_type", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_handledby", "alias": "clm_handled_by", "columns":["id", "description"]},
            {"table": "staging_claim_center_cctl_ext_isseveritycode", "alias": "is_sev_code", "columns":["id", "typecode"]},
            {"table": "staging_claim_center_cctl_extinjuredpersontype", "alias": "injured_person_type", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_extseverity", "alias": "clm_severity", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_claimsecuritytype", "alias": "clm_security_type", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_extcollcode", "alias": "cause_of_loss_code1", "columns":["id", "description"]},
            {"table": "staging_claim_center_cctl_extcollcode2", "alias": "cause_of_loss_code2", "columns":["id", "description"]},
            {"table": "staging_claim_center_cctl_extcollcode3", "alias": "cause_of_loss_code3", "columns":["id", "description"]},
            {"table": "staging_claim_center_cctl_ext_collcode3_pi", "alias": "cause_of_loss_code3_pi", "columns":["id", "description"]},
            {"table": "staging_claim_center_cctl_extcollcode4", "alias": "cause_of_loss_code4_a", "columns":["id", "description"]},
            {"table": "staging_claim_center_cctl_extcollcode4", "alias": "cause_of_loss_code4_b", "columns":["id", "description"]},
            {"table": "staging_claim_center_cctl_ext_projecttype", "alias": "project_type", "columns":["id", "description"]},
            {"table": "staging_claim_center_cctl_ext_typeofwork2", "alias": "type_of_work2", "columns":["id", "description"]},
            {"table": "staging_claim_center_cctl_ext_policycovsectionusa", "alias": "policy_cov_section_usa", "columns":["id", "description"]},
            {"table": "staging_claim_center_cctl_extcollcode5", "alias": "cause_of_loss_code5", "columns":["id", "description"]},
            {"table": "staging_claim_center_cctl_ecfcauseoflosscode_ext", "alias": "synd_cause_of_loss_code", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_losscodeset", "alias": "loss_code_set", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_extcyberconsideration", "alias": "cyber", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_extransomwareaspect", "alias": "ransomware", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_claimsorganization", "alias": "claims_org", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_coverageindicatorpr", "alias": "cover_ind_pr", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_extcoverageindicator", "alias": "cover_ind", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_deductibletype", "alias": "ded_type", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_faultrating", "alias": "fault_rating_type", "columns":["id", "description"]},
            {"table": "staging_claim_center_cctl_ext_handlingtype", "alias": "handling_type", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_largelossnotificationstat", "alias": "large_loss_status_type", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_howreportedtype", "alias": "how_reported_type", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_isolosslocation", "alias": "iso_loss_loc", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_lossevent", "alias": "loss_event_type", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_personrelationtype", "alias": "person_relation_type", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_cargo", "alias": "cargo", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_proceedingtype", "alias": "proceedings_type", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_proceedingspr", "alias": "proceedings_type_pr", "columns":["id", "name"]},
            {"table": "staging_claim_center_cc_subrogationsummary", "alias": "subrogation_summary", "columns":["id", "claimid"]},
            {"table": "staging_claim_center_cc_subrogation", "alias": "subrogation", "columns":["subrogationsummaryid", "status"]},
            {"table": "staging_claim_center_cctl_subrogationstatus", "alias": "subrogation_status_type", "columns":["id", "name"]},
            {"table": "staging_claim_center_cc_history", "alias": "cc_history", "columns":["id", "claimid", "eventtimestamp", "exposureid", "publicid", "type"]},
            {"table": "staging_claim_center_cctl_claimclosedoutcometype", "alias": "close_type", "columns":["id", "name"]},
            {"table": "staging_claim_center_ccx_lmmessage_ext", "alias": "ccx_lm_message", "columns":["claim","subtype","messagetype","responseacknowledgement","transactiontype","suspended","createtime","__load_id"]},
            {"table": "staging_claim_center_cctl_lmmessage_ext", "alias": "cctl_lm_message", "columns":["id","typecode"]},
            {"table": "staging_claim_center_cctl_lmmessagetype_ext", "alias": "cctl_lm_message_type", "columns":["id","typecode"]},
            {"table": "staging_claim_center_ccx_ecfmessagerspack_ext", "alias": "ccx_ecf_messagers_pack", "columns":["id","acknowledgementstatus","acklevel"]},
            {"table": "staging_claim_center_cctl_ecfacknowledgementstatus_ext", "alias": "cctl_ecf_ack_status", "columns":["id","typecode"]},
            {"table": "staging_claim_center_cctl_ecfacklevelcode_ext", "alias": "cctl_ecf_ack_level_code", "columns":["id","typecode"]},
            {"table": "staging_claim_center_cctl_ecfclaimtransactiontype_ext", "alias": "cctl_ecf_trans_type", "columns":["id","name"]},
            {"table": "staging_claim_center_cctl_ext_aprainjury", "alias": "aprainjury", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_apracol", "alias": "apracol", "columns": ["id", "description"]},
            {"table": "staging_claim_center_cctl_ext_apacjurisdiction", "alias": "apacjurisdiction", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_apralitcodes", "alias": "apralitigationcodes", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cctl_extregulatorycode", "alias": "apraregulatorycodes", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_esmanufacturer", "alias": "esmanufacturer", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_esmodelnumber", "alias": "esmodelnumber", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_estechnologytype", "alias": "estechnologytype", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_esvariant", "alias": "esvariant", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cctl_extequipmentstructure", "alias": "esequipmentstructure", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_projectphase", "alias": "projectphase", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_projectdeliverytype", "alias": "projectdeliverytype", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cctl_extphaseofoperation", "alias": "phaseofoperation", "columns": ["id", "name"]},
        ]
    )
}},
claim_created_dates as (
    select
        claimid,
        eventtimestamp as created_date,
        __load_id
    from cc_history
    where "type" = 15 
    and exposureid is null 
    and left(publicid, 4) = 'caip'
    qualify row_number() 
        over (partition by  __load_id, claimid order by id desc) = 1
),
claims_in_suit as (
    select
        matter.claimid,
        max(
            case
                when
                    (
                        coalesce(matter.closedate, to_date('99991231', 'yyyymmdd'))
                        > sysdate
                        and matter.mattertype in (10001, 10002, 10003)
                    )
                    or (clm.ext_proceedings in (10002, 10003, 10010, 10011))
                    or (clm.ext_proceedingspr in (10001, 10003))
                    or (clm.litigationstatus = 1 and clm.ext_product = 10001)
                then 1
                else 0
            end
        ) as in_suit_flag,
        matter.__load_id
    from matter
    inner join clm 
        on matter.claimid = clm.id
        and matter.__load_id = clm.__load_id
    group by matter.__load_id, matter.claimid
),
latest_ecf_trans_type as (
    select
        ccx_lm_message.claim as claim_id,
        cctl_ecf_trans_type.name as ecf_trans_type
    from ccx_lm_message
    inner join cctl_lm_message
        on ccx_lm_message.subtype = cctl_lm_message.id
    left join cctl_lm_message_type
        on ccx_lm_message.messagetype = cctl_lm_message_type.id
    left join ccx_ecf_messagers_pack
        on ccx_lm_message.responseacknowledgement = ccx_ecf_messagers_pack.id
    left join cctl_ecf_ack_status
        on ccx_ecf_messagers_pack.acknowledgementstatus = cctl_ecf_ack_status.id
    left join cctl_ecf_ack_level_code
        on ccx_ecf_messagers_pack.acklevel = cctl_ecf_ack_level_code.id
    left join cctl_ecf_trans_type
        on ccx_lm_message.transactiontype = cctl_ecf_trans_type.id
    where ccx_lm_message.suspended = 0
    and LOWER(cctl_lm_message.typecode) in ('ecfmessageclaimdata_ext','ecfmessageclaimnotifyrq_ext','ecfmessageclaimretrievers_ext')
    and NVL(LOWER(cctl_lm_message_type.typecode), '')!='responderrornotify'
    and NVL(LOWER(cctl_ecf_ack_status.typecode), '')!='rejected'
    and NVL(LOWER(cctl_ecf_ack_level_code.typecode), '') not in ('partialresponseclass','unavailable','requestinvalid','senderinvalid','notregistered','claimnotfound','unabletoretrieveclaim','orgconflicted')
    qualify row_number()
        over (partition by ccx_lm_message.__load_id, ccx_lm_message.claim order by ccx_lm_message.createtime desc) = 1
),
apra as (
        select 
        ISNULL(ai.name, 'NA')				as apra_injury
		, ISNULL(ac.description, 'NA')		as apra_col
		, ISNULL(aj.name, 'NA')				as apra_jurisdiction
		, ISNULL(al.name, 'NA')				as apra_litigation
		, ISNULL(ar.name, 'NA')				as apra_regulatory
        , c.id                              as claim_id
    from
        clm as c
        left join aprainjury            as ai on ai.ID = c.Ext_APRAinjury
        left join apracol               as ac on ac.ID = c.Ext_APRAcol
        left join apacjurisdiction      as aj on aj.ID = c.Ext_APACJurisdiction
        left join apralitigationcodes   as al on al.ID = c.Ext_APRAlitCodes
        left join apraregulatorycodes   as ar on ar.ID = c.Ext_RegulatoryCode
),
power_generation as (
    select
        ISNULL(eq.name, 'NA') as equipment_type
        , ISNULL(esm.name, 'NA') as manufacturer
        , ISNULL(mn.name, 'NA') as model_number
        , ISNULL(mv.name, 'NA') as model_variant
        , ISNULL(tt.name, 'NA') as technology_type
        , c.id                  as claim_id
    from
        clm as c
        left join esequipmentstructure as eq on eq.id = c.ext_equipmentstruct and c.ext_section <> 10100
        left join esmanufacturer as esm on c.ext_esmanufacturer = esm.id and c.ext_section = 10100
        left join esmodelnumber as mn on c.ext_esmodelnumber = mn.id and c.ext_section = 10100
        left join esvariant as mv on c.ext_esvariant = mv.id and c.ext_section = 10100
        left join estechnologytype as tt on c.ext_estechnologytype = tt.id and c.ext_section = 10100
),

construction as (
    select
        ISNULL(po.name,'NA') as phase_of_operation
        , ISNULL(pp.name,'NA') as project_phase
        , ISNULL(pd.name,'NA') as project_delivery_type
        , c.id as claim_id
    from
        clm as c
        left join phaseofoperation as po on c.ext_phaseofoperation = po.ID
        left join projectphase as pp on c.ext_projectphase = pp.ID
        left join projectdeliverytype as pd on c.ext_projectdeliverytype = pd.ID
),
multiple_coverages_flag as (
    select
        clm.id as claim_id,
        case when count(distinct(cov.ext_coveragelabel+cov.ext_sectiondesc)) = 1 then 'no' else 'yes' end as multi_coverages_flag
    from clm
    left outer join exposure_source as exp
        on exp.claimid = clm.id
    left outer join coverage_source as cov
        on cov.id = exp.coverageid
    group by clm.id
),
claim as (
    select
        clm.publicid,
        clm.id,
        clm.claim_number,
        clm_event.ext_name as event_name,
        clm_event.ext_description as event_description,
        clm_event.id as event_code,
        clm.assignmentdate as assigned_date,
        case
            when
                clm.claimsource = '10001'
                or (
                    clm.claimsource = '10003'
                    and claim_created_dates.created_date is null
                )
            then clm.reporteddate
            when clm.claimsource = '10003'  -- claim assure migrated claims
            then claim_created_dates.created_date
            else clm.createtime
        end as date_claim_created,
        clm.lossdate as date_of_loss,
        coalesce(clm.daterptdtoinsured, clm.reporteddate) as date_reported,
        clm.ext_locationtext as loss_location,
        clm.ext_addexposureunverified as additional_exposure_unverified,
        clm.ext_alternateclaimfilenumber as alternate_claim_number,
        clm."description" as claim_description,
        clm_state."name" as claim_state,
        {#  --Current Claim Status is taken from Claim Profile history
            case
            when clm.reopendate is not null then 'reopen' else upper(clm_state."name")
        end as claim_status, #}
        clm_tier."name" as claim_tier,
        clm.ext_title as claim_title,
        clm_type."name" as claim_type,
        clm.closedate as date_claim_closed,
        clm.flaggeddate as date_last_flagged,
        clm.ext_lastrevaldate as date_last_revalued,
        clm.updatetime as date_last_updated,
        clm.reporteddate as date_received,
        clm.flaggedreason as flagged_reason,
        clm.ext_bizinterruption_money::numeric(18,2) as ground_up_loss_bi_usd,
        clm.ext_prdamage_money::numeric(18,2) as ground_up_loss_pd_usd,
        clm.ext_grounduplosstotal_money::numeric(18,2) as ground_up_loss_total_usd,
        clm_handled_by."description" as handled_by,
        case claims_in_suit.in_suit_flag when 1 then true when 0 then false else null end as in_suit_flag,
        clm.insurerriskreference_syn as insurer_risk_reference,
        is_sev_code.typecode as is_severity,
        clm.ext_llrflagged as large_loss_report_flag,
        clm.ext_supplementalpaymentmade as post_close_payment_made,
        coalesce(clm.reinsurancereportable, false) as reinsurance_reportable,
        clm_severity."name" as severity,
        clm_security_type."name" as special_claim_permission,
        clm.ext_tpaclaimnumber as tpa_claim_number,
        clm.ucr_ext as unique_claim_reference,
        cause_of_loss_code1."description" as cause_of_loss1,
        cause_of_loss_code2."description" as cause_of_loss2,
        coalesce(
            cause_of_loss_code3."description", cause_of_loss_code3_pi."description"
        ) as cause_of_loss3,
        coalesce(
            cause_of_loss_code4_a."description",
            project_type."description",
            type_of_work2."description",
            policy_cov_section_usa."description",
            cause_of_loss_code4_b."description"
        ) as cause_of_loss4,
        cause_of_loss_code5."description" as cause_of_loss5,
        clm.ext_coll1descother as cause_of_loss1_other_description,
        clm.ext_coll2descother as cause_of_loss2_other_description,
        clm.ext_coll3descother as cause_of_loss3_other_description,
        clm.ext_coll4descother as cause_of_loss4_other_description,
        synd_cause_of_loss_code."name" as syndicate_cause_code,
        loss_code_set."name" as loss_code_group,
        cyber."name" as cyber_consideration,
        clm.ext_cyberconsiderationother as cyber_consideration_other,
        ransomware."name" as ransomware_aspect,
        claims_org."name" as claims_organisation,
        clm.syndicateid_syn as syndicate_id,
        clm.ext_fasttrack as fast_track,
        coalesce(cover_ind."name", cover_ind_pr."name") as coverage_indicator,
        ded_type."name" as deductible_type,
        fault_rating_type."description" as fault_rating,
        handling_type."name" as claim_handling_type,
        how_reported_type."name" as claim_how_reported,
        large_loss_status_type."name" as large_loss_notification_status,
        iso_loss_loc."name" as iso_loss_location,
        loss_event_type."name" as loss_event,
        person_relation_type."name" as reported_by_type,
        cargo."name" as cargo_type,
        coalesce(clm.ext_batchedclaim, false) as batched_claim_flag,
        coalesce(
            proceedings_type."name", proceedings_type_pr."name"
        ) as claim_proceedings_type,
        subrogation_status_type."name" as subrogation_status,
        ext_blockfile as block_file,
        ext_lossfund as loss_fund,
        ext_generalclaimnote as general_claim_note,
        ext_vulnerablecustomer as vulnerable_customer,
        ext_datecoverageletterissued as date_coverage_letter_issued,
        ext_externalreference as external_reference,
        case when ip_type.name is null then 'no' else 'yes' end as claim_involving_minor_flag,
        mcf.multi_coverages_flag as multiple_coverages_flag,
        close_type."name" as claim_closure_reason,
        --AL: foreign keys
        clm.assignedgroupid as assigned_group_id,
        clm.createuserid as created_by_user_id,
        clm.assigneduserid as assigned_to_user_id,
        clm.assignedbyuserid as assigned_by_user_id,
        clm.updateuserid as updated_by_user_id,
        clm.catastropheid as catastrophe_id,
        clm.losslocationid as loss_location_id,
        clm.__source_system_code,
        clm.__extraction_date_time,
        clm.__load_id,
        clm.__data_region,
        trans_type.ecf_trans_type as latest_ecf_transaction_type,
        cc_policy.__policy_source_system_code,
        cc_policy.policy_master_number,
        cc_policy.policy_master_sequence,
        apr.apra_injury,
        apr.apra_col,
        apr.apra_jurisdiction,
        apr.apra_litigation,
        apr.apra_regulatory,
        pg.equipment_type,
        pg.manufacturer,
        pg.model_number,
        pg.model_variant,
        pg.technology_type,
        cn.phase_of_operation,
        cn.project_phase,
        cn.project_delivery_type
    from clm
    left outer join cc_policy on clm.policyid = cc_policy.id and clm.__load_id = cc_policy.__load_id
    left outer join clm_event on clm.claimevent = clm_event.id and clm.__load_id = clm_event.__load_id
    left outer join claim_created_dates on clm.id = claim_created_dates.claimid and clm.__load_id = claim_created_dates.__load_id
    left outer join claims_in_suit on clm.id = claims_in_suit.claimid and clm.__load_id = claims_in_suit.__load_id
    left outer join clm_state on clm."state" = clm_state.id and clm.__load_id = clm_state.__load_id
    left outer join clm_tier on clm.claimtier = clm_tier.id and clm.__load_id = clm_tier.__load_id
    left outer join clm_type on clm.ext_claimtype = clm_type.id and clm.__load_id = clm_type.__load_id
    left outer join clm_handled_by on clm.ext_handledby = clm_handled_by.id and clm.__load_id = clm_handled_by.__load_id
    left outer join is_sev_code on clm.ext_isseveritycode = is_sev_code.id and clm.__load_id = is_sev_code.__load_id
    left outer join clm_severity on clm.ext_severity = clm_severity.id and clm.__load_id = clm_severity.__load_id
    left outer join clm_security_type on clm.permissionrequired = clm_security_type.id and clm.__load_id = clm_security_type.__load_id
    left outer join cause_of_loss_code1 on clm.ext_coll1 = cause_of_loss_code1.id and clm.__load_id = cause_of_loss_code1.__load_id
    left outer join cause_of_loss_code2 on clm.ext_coll2 = cause_of_loss_code2.id and clm.__load_id = cause_of_loss_code2.__load_id
    left outer join cause_of_loss_code3 on clm.ext_coll3 = cause_of_loss_code3.id and clm.__load_id = cause_of_loss_code3.__load_id
    left outer join cause_of_loss_code3_pi on clm.ext_coll3_pi = cause_of_loss_code3_pi.id and clm.__load_id = cause_of_loss_code3_pi.__load_id
    left outer join cause_of_loss_code4_a on clm.ext_coll4 = cause_of_loss_code4_a.id and clm.__load_id = cause_of_loss_code4_a.__load_id
    left outer join cause_of_loss_code4_b on clm.ext_collcode4 = cause_of_loss_code4_b.id and clm.__load_id = cause_of_loss_code4_b.__load_id
    left outer join project_type on clm.ext_projecttype = project_type.id and clm.__load_id = project_type.__load_id
    left outer join type_of_work2 on clm.ext_typeofwork2 = type_of_work2.id and clm.__load_id = type_of_work2.__load_id
    left outer join policy_cov_section_usa on clm.ext_policycovsectionusa = policy_cov_section_usa.id and clm.__load_id = policy_cov_section_usa.__load_id
    left outer join cause_of_loss_code5 on clm.ext_coll5 = cause_of_loss_code5.id and clm.__load_id = cause_of_loss_code5.__load_id
    left outer join synd_cause_of_loss_code on clm.causeoflosscode_syn = synd_cause_of_loss_code.id and clm.__load_id = synd_cause_of_loss_code.__load_id
    left outer join loss_code_set on clm.ext_losscodeset = loss_code_set.id and clm.__load_id = loss_code_set.__load_id
    left outer join cyber on clm.ext_cyberconsideration = cyber.id and clm.__load_id = cyber.__load_id
    left outer join ransomware on clm.ext_ransomwareaspect = ransomware.id and clm.__load_id = ransomware.__load_id
    left outer join claims_org on clm.ext_claimsorganization = claims_org.id and clm.__load_id = claims_org.__load_id
    left outer join cover_ind_pr on clm.ext_coverageindicatorpr = cover_ind_pr.id and clm.__load_id = cover_ind_pr.__load_id
    left outer join cover_ind on clm.ext_coverageindicator = cover_ind.id and clm.__load_id = cover_ind.__load_id
    left outer join ded_type on clm.ext_deductibletype = ded_type.id and clm.__load_id = ded_type.__load_id
    left outer join fault_rating_type on clm.faultrating = fault_rating_type.id and clm.__load_id = fault_rating_type.__load_id
    left outer join handling_type on clm.ext_handlingtype = handling_type.id and clm.__load_id = handling_type.__load_id
    left outer join large_loss_status_type on clm.largelossnotificationstatus = large_loss_status_type.id and clm.__load_id = large_loss_status_type.__load_id
    left outer join how_reported_type on clm.howreported = how_reported_type.id and clm.__load_id = how_reported_type.__load_id
    left outer join iso_loss_loc on clm.ext_isolosslocation = iso_loss_loc.id and clm.__load_id = iso_loss_loc.__load_id
    left outer join loss_event_type on clm.ext_isolosslocation = loss_event_type.id and clm.__load_id = loss_event_type.__load_id
    left outer join person_relation_type on clm.reportedbytype = person_relation_type.id and clm.__load_id = person_relation_type.__load_id
    left outer join cargo on clm.ext_cargo = cargo.id and clm.__load_id = cargo.__load_id
    left outer join proceedings_type on clm.ext_proceedings = proceedings_type.id and clm.__load_id = proceedings_type.__load_id
    left outer join proceedings_type_pr on clm.ext_proceedingspr = proceedings_type_pr.id and clm.__load_id = proceedings_type_pr.__load_id
    left outer join subrogation_summary on clm.id = subrogation_summary.claimid and clm.__load_id = subrogation_summary.__load_id
    left outer join subrogation on subrogation_summary.id = subrogation.subrogationsummaryid and subrogation_summary.__load_id = subrogation.__load_id
    left outer join subrogation_status_type on subrogation."status" = subrogation_status_type.id and subrogation.__load_id = subrogation_status_type.__load_id
    left outer join close_type on clm.closedoutcome = close_type.id
    left outer join latest_ecf_trans_type as trans_type on clm.id = trans_type.claim_id
    left outer join incident on incident.claimid = clm.id
    left outer join injured_person_type as ip_type on ip_type.id = incident.ext_injuredpersontype and ip_type.id = 10001
    left outer join multiple_coverages_flag as mcf on mcf.claim_id = clm.id
    left outer join apra as apr on apr.claim_id = clm.id
    left outer join power_generation as pg on pg.claim_id = clm.id
    left outer join construction as cn on cn.claim_id = clm.id
),
final as (
    select
        publicid,
        id,
        claim_number,
        event_name,
        event_description,
        event_code,
        assigned_date,
        date_claim_created,
        date_of_loss,
        date_reported,
        loss_location,
        additional_exposure_unverified,
        alternate_claim_number,
        claim_description,
        claim_state,
        claim_tier,
        claim_title,
        claim_type,
        date_claim_closed,
        date_last_flagged,
        date_last_revalued,
        date_last_updated,
        date_received,
        flagged_reason,
        ground_up_loss_bi_usd,
        ground_up_loss_pd_usd,
        ground_up_loss_total_usd,
        handled_by,
        in_suit_flag,
        insurer_risk_reference,
        is_severity,
        large_loss_report_flag,
        post_close_payment_made,
        reinsurance_reportable,
        severity,
        special_claim_permission,
        tpa_claim_number,
        unique_claim_reference,
        catastrophe_id,
        cause_of_loss1,
        cause_of_loss2,
        cause_of_loss3,
        cause_of_loss4,
        cause_of_loss5,
        cause_of_loss1_other_description,
        cause_of_loss2_other_description,
        cause_of_loss3_other_description,
        cause_of_loss4_other_description,
        syndicate_cause_code,
        loss_code_group,
        cyber_consideration,
        cyber_consideration_other,
        ransomware_aspect,
        claims_organisation,
        syndicate_id,
        fast_track,
        coverage_indicator,
        deductible_type,
        fault_rating,
        claim_handling_type,
        claim_how_reported,
        large_loss_notification_status,
        iso_loss_location,
        loss_event,
        reported_by_type,
        cargo_type,
        batched_claim_flag,
        claim_proceedings_type,
        subrogation_status,
        block_file,
        loss_fund,
        general_claim_note,
        vulnerable_customer,
        date_coverage_letter_issued,
        external_reference,
        claim_involving_minor_flag,
        multiple_coverages_flag,
        claim_closure_reason,
        latest_ecf_transaction_type,
        {{ generate_merge_key(["__source_system_code", "created_by_user_id"]) }} as __created_by_merge_key,
        {{ generate_merge_key(["__source_system_code", "assigned_to_user_id"]) }} as __assigned_to_merge_key,
        {{ generate_merge_key(["__source_system_code", "assigned_by_user_id"]) }} as __assigned_by_merge_key,
        {{ generate_merge_key(["__source_system_code", "updated_by_user_id"]) }} as __updated_by_merge_key,
        {{ generate_merge_key(["__source_system_code", "assigned_group_id"]) }} as __assigned_group_merge_key,
        {{ generate_merge_key(["__policy_source_system_code","policy_master_number", "policy_master_sequence"])}} as __policy_merge_key,
        {{ generate_merge_key(["__source_system_code","catastrophe_id"])}} as __catastrophe_merge_key,
        {{ generate_merge_key(["__source_system_code","loss_location_id"])}} as __loss_location_merge_key,
        {{ generate_merge_key(["__source_system_code", "apra_injury", "apra_col", "apra_jurisdiction", "apra_litigation", "apra_regulatory"]) }} as __claim_apra_merge_key,
        {{ generate_merge_key(["__source_system_code", "equipment_type", "manufacturer", "model_number", "model_variant", "technology_type"]) }} as __claim_power_generation_merge_key,
        {{ generate_merge_key(["__source_system_code", "phase_of_operation", "project_phase", "project_delivery_type"]) }} as __claim_construction_merge_key,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region,
        {{ generate_merge_key(["__source_system_code", "claim_number"]) }} as __merge_key,
        row_number() over (
            partition by __merge_key order by __extraction_date_time desc
        ) as __record_version
    from claim
)
select *
from final
