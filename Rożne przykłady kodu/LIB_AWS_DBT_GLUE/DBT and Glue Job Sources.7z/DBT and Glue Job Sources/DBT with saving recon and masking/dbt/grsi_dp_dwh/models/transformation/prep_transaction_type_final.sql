{{
    generate_cte(
        [
            {"table": "staging_reference_rtmi_transaction_type", "alias": "rtmi_transaction_type_source", "columns":["transactiontypecode", "transactiontypename", "transactiontypedescription", "transactiontypecategory", "paymenttype"]}
        ]
    )
}},
final as (

    select
        row_number() over (
            partition by __merge_key order by __extraction_date_time desc
        ) as __record_version,
        transactiontypecode as transaction_type_code,
        transactiontypename as transaction_type_name,
        transactiontypedescription as transaction_type_description,
        transactiontypecategory as transaction_type_category,
        paymenttype as payment_type,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region,
        {{
            generate_merge_key(
                [
                    "transactiontypecode",
                ],
            )
        }} as __merge_key
    from rtmi_transaction_type_source

)
select *
from final
