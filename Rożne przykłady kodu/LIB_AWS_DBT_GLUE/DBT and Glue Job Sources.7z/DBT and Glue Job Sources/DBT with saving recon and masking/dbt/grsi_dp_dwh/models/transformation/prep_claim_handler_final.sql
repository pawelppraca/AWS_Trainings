{{
    generate_cte(
        [
            {"table": "staging_claim_center_cc_user", "alias": "users", "columns": ["id", "contactid"]},
            {"table": "staging_claim_center_cc_contact", "alias": "cc_contacts", "columns": ["id", "publicid", "subtype", "firstname", "lastname"]},
            {"table": "staging_genius_zkt8", "alias": "zkt8", "columns": ["user_id", "full_name" ]}

        ]
    )
}},

contacts as (
    select
        *
    from cc_contacts
    where subtype = 14  -- person
),

genius_user as (
    select 
	    null as first_name,
		null as last_name,
		full_name,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region,
        {{
            generate_merge_key(
                [
                    "__source_system_code",
                    "user_id"
                ]
            )
        }}
    from zkt8 
),

claim_handler as (
    select
        contacts.firstname as first_name,
        contacts.lastname as last_name,
        contacts.firstname || ' ' || contacts.lastname as full_name,
        users.__source_system_code,
        users.__extraction_date_time,
        users.__load_id,
        users.__data_region,
        {{
            generate_merge_key(
                [
                    "users.__source_system_code",
                    "users.id",
                ],
            )
        }} as __merge_key
    from contacts
    inner join users
        on contacts.__load_id = users.__load_id
        and contacts.id = users.contactid 
),

claim_genius as (
    select * from claim_handler
    union all 
    select * from genius_user
),

final as (
    select
        first_name,
        last_name,
        full_name,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region,
        __merge_key,
        row_number() over (
            partition by __merge_key order by __extraction_date_time desc
        ) as __record_version
    from claim_genius


)
select *
from final
