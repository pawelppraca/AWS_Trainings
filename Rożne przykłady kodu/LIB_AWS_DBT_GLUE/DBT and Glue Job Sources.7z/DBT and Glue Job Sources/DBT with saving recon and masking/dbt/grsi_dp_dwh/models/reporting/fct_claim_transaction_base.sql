
{%- set base_measures = [
    {
        "measure_type_code":"PAID_IND_GROSS",
        "reverse_sign": true,
        "where_conditions":[
            {
                "column_name":"transaction_type_code",
                "operator": "in",
                "value_list": ["PMT"]
            },
            {
                "column_name":"ri_group",
                "operator": "in",
                "value_list": ["GROSS"]
            },
            {
                "column_name":"cost_type_code",
                "operator": "in",
                "value_list": ["IND"]
            },
            {
                "column_name":"cost_category_code",
                "operator": "not in",
                "value_list": ["GSC","MLE","MLW","MWI"]
            }
        ]
    },
    {
        "measure_type_code":"PAID_FEE_GROSS",
        "reverse_sign": true,
        "where_conditions":[
            {
                "column_name":"transaction_type_code",
                "operator": "in",
                "value_list": ["PMT"]
            },
            {
                "column_name":"ri_group",
                "operator": "in",
                "value_list": ["GROSS"]
            },
            {
                "column_name":"cost_type_code",
                "operator": "in",
                "value_list": ["FEE"]
            },
            {
                "column_name":"cost_category_code",
                "operator": "not in",
                "value_list": ["GSC","MLE","MLW","MWI"]
            }
        ]
    },
    {
        "measure_type_code":"PAID_GST_GROSS",
        "reverse_sign": true,
        "where_conditions":[
            {
                "column_name":"transaction_type_code",
                "operator": "in",
                "value_list": ["PMT"]
            },
            {
                "column_name":"ri_group",
                "operator": "in",
                "value_list": ["GROSS"]
            },
            {
                "column_name":"cost_type_code",
                "operator": "in",
                "value_list": ["IND", "FEE", "REC"]
            },
            {
                "column_name":"cost_category_code",
                "operator": "in",
                "value_list": ["GSC"]
            }
        ]
    },
    {
        "measure_type_code":"OS_IND_GROSS",
        "reverse_sign": true,
        "where_conditions":[
            {
                "column_name":"transaction_type_code",
                "operator": "in",
                "value_list": ["RSV","FXT","FXR"]
            },
            {
                "column_name":"ri_group",
                "operator": "in",
                "value_list": ["GROSS"]
            },
            {
                "column_name":"cost_type_code",
                "operator": "in",
                "value_list": ["IND"]
            },
            {
                "column_name":"cost_category_code",
                "operator": "not in",
                "value_list": ["GSC","MLE","MLW","MWI"]
            }
        ]
    },
    {
        "measure_type_code":"OS_FEE_GROSS",
        "reverse_sign": true,
        "where_conditions":[
            {
                "column_name":"transaction_type_code",
                "operator": "in",
                "value_list": ["RSV","FXT","FXR"]
            },
            {
                "column_name":"ri_group",
                "operator": "in",
                "value_list": ["GROSS"]
            },
            {
                "column_name":"cost_type_code",
                "operator": "in",
                "value_list": ["FEE"]
            },
            {
                "column_name":"cost_category_code",
                "operator": "not in",
                "value_list": ["GSC","MLE","MLW","MWI"]
            }
        ]
    },
    {
        "measure_type_code":"OS_REC_GROSS",
        "reverse_sign": true,
        "where_conditions":[
            {
                "column_name":"transaction_type_code",
                "operator": "in",
                "value_list": ["RSV","FXT","FXR"]
            },
            {
                "column_name":"ri_group",
                "operator": "in",
                "value_list": ["GROSS"]
            },
            {
                "column_name":"cost_type_code",
                "operator": "in",
                "value_list": ["REC"]
            },
            {
                "column_name":"cost_category_code",
                "operator": "not in",
                "value_list": ["GSC","MLE","MLW","MWI"]
            }
        ]
    },
    {
        "measure_type_code":"PAID_REC_GROSS",
        "reverse_sign": true,
        "where_conditions":[
            {
                "column_name":"transaction_type_code",
                "operator": "in",
                "value_list": ["PMT"]
            },
            {
                "column_name":"ri_group",
                "operator": "in",
                "value_list": ["GROSS"]
            },
            {
                "column_name":"cost_type_code",
                "operator": "in",
                "value_list": ["REC"]
            },
            {
                "column_name":"cost_category_code",
                "operator": "not in",
                "value_list": ["GSC","MLE","MLW","MWI"]
            }
        ]
    },
    {
        "measure_type_code":"PAID_IND_CEDED",
        "reverse_sign": false,
        "where_conditions":[
            {
                "column_name":"transaction_type_code",
                "operator": "in",
                "value_list": ["PMT"]
            },
            {
                "column_name":"ri_group",
                "operator": "in",
                "value_list": ["CEDED"]
            },
            {
                "column_name":"cost_type_code",
                "operator": "in",
                "value_list": ["IND"]
            },
            {
                "column_name":"cost_category_code",
                "operator": "not in",
                "value_list": ["GSC","MLE","MLW","MWI"]
            }
        ]
    },
    {
        "measure_type_code":"PAID_FEE_CEDED",
        "reverse_sign": false,
        "where_conditions":[
            {
                "column_name":"transaction_type_code",
                "operator": "in",
                "value_list": ["PMT"]
            },
            {
                "column_name":"ri_group",
                "operator": "in",
                "value_list": ["CEDED"]
            },
            {
                "column_name":"cost_type_code",
                "operator": "in",
                "value_list": ["FEE"]
            },
            {
                "column_name":"cost_category_code",
                "operator": "not in",
                "value_list": ["GSC","MLE","MLW","MWI"]
            }
        ]
    },
    {
        "measure_type_code":"OS_FEE_CEDED",
        "reverse_sign": false,
        "where_conditions":[
            {
                "column_name":"transaction_type_code",
                "operator": "in",
                "value_list": ["RSV","FXT","FXR"]
            },
            {
                "column_name":"ri_group",
                "operator": "in",
                "value_list": ["CEDED"]
            },
            {
                "column_name":"cost_type_code",
                "operator": "in",
                "value_list": ["FEE"]
            },
            {
                "column_name":"cost_category_code",
                "operator": "not in",
                "value_list": ["GSC","MLE","MLW","MWI"]
            }
        ]
    },
    {
        "measure_type_code":"OS_REC_CEDED",
        "reverse_sign": false,
        "where_conditions":[
            {
                "column_name":"transaction_type_code",
                "operator": "in",
                "value_list": ["RSV","FXT","FXR"]
            },
            {
                "column_name":"ri_group",
                "operator": "in",
                "value_list": ["CEDED"]
            },
            {
                "column_name":"cost_type_code",
                "operator": "in",
                "value_list": ["REC"]
            },
            {
                "column_name":"cost_category_code",
                "operator": "not in",
                "value_list": ["GSC","MLE","MLW","MWI"]
            }
        ]
    }
]
-%}

{{
    generate_cte(
        [
            {"table": "claim_transaction", "alias": "claim_trans_src"},
            {"table": "transaction_type", "alias": "trans_type", "columns": ["transaction_type_key", "transaction_type_code"]},
            {"table": "claim_movement_type", "alias": "claim_mvmt_type", "columns": ["claim_movement_type_key", "cost_type_code", "cost_category_code"]},
            {"table": "ri_code", "alias": "ri_code", "columns": ["ri_code_key", "ri_type_code", "ri_group"]}
        ],
        include_meta_data_columns=false
    )
}},
claim_trans AS (

    SELECT 
        ct.claim_transaction_key,
        ct.claim_key,
        ct.claim_profile_history_key,
        ct.claim_movement_type_key,
        ct.ri_code_key,
        ct.transaction_type_key,
        trans_type.transaction_type_code,
        claim_mvmt_type.cost_type_code,
        claim_mvmt_type.cost_category_code,
        ri_code.ri_type_code,
        ri_code.ri_group,
        {{ get_date_key('ct.transaction_date') }} as transaction_date_key,
        {{ get_date_key('ct.posting_date') }} as posting_date_key,
        {{ get_date_key('ct.fiscal_date') }} as fiscal_date_key,
        ct.original_currency_key,
        ct.local_currency_key,
        ct.group_currency_key,
        ct.amount_original,
        ct.amount_local,
        ct.amount_group
    FROM claim_trans_src AS ct
    INNER JOIN claim_mvmt_type
        ON ct.claim_movement_type_key = claim_mvmt_type.claim_movement_type_key
    INNER JOIN ri_code
        ON ct.ri_code_key = ri_code.ri_code_key
    INNER JOIN trans_type
        ON ct.transaction_type_key = trans_type.transaction_type_key
        
),
unioned AS (

    {% for measure in base_measures %}
    SELECT 
        claim_key,
        claim_profile_history_key,
        claim_movement_type_key,
        ri_code_key,
        transaction_type_key,
        '{{ measure.measure_type_code }}' as measure_type_code,
        UPPER(transaction_type_code) as transaction_type_code,
        UPPER(cost_type_code) as cost_type_code,
        UPPER(cost_category_code) as cost_category_code,
        UPPER(ri_type_code) as ri_type_code,
        UPPER(ri_group) as ri_group,
        transaction_date_key,
        posting_date_key,
        fiscal_date_key,
        original_currency_key,
        local_currency_key,
        group_currency_key,
        amount_original
        {%- if measure.reverse_sign %} * -1.0 as amount_original {%- endif %},
        amount_local
        {%- if measure.reverse_sign %} * -1.0 as amount_local {%- endif %},
        amount_group
        {%- if measure.reverse_sign %} * -1.0 as amount_group {%- endif %} 
    FROM claim_trans
    WHERE
    {% for condition in measure.where_conditions %}
        {%- if not loop.first -%} AND {% endif -%}
        {{ generate_sql_in_condition(condition.column_name, condition.value_list, condition.operator, quote_values=true, convert_to_upper_case=true) }}
    {% endfor %}

    {%- if not loop.last %}
    UNION ALL
    {% endif -%}

  {% endfor %}
),
final AS (

    SELECT
        claim_key, 
        claim_profile_history_key, 
        claim_movement_type_key, 
        ri_code_key, 
        transaction_type_key, 
        measure_type_code, 
        transaction_type_code, 
        cost_type_code, 
        cost_category_code, 
        ri_type_code, 
        ri_group, 
        transaction_date_key, 
        posting_date_key, 
        fiscal_date_key, 
        original_currency_key, 
        local_currency_key, 
        group_currency_key, 
        SUM(amount_original) as amount_original, 
        SUM(amount_local) as amount_local, 
        SUM(amount_group) as  amount_group
    FROM unioned
    GROUP BY
        claim_key, 
        claim_profile_history_key, 
        claim_movement_type_key, 
        ri_code_key, 
        transaction_type_key, 
        measure_type_code, 
        transaction_type_code, 
        cost_type_code, 
        cost_category_code, 
        ri_type_code, 
        ri_group, 
        transaction_date_key, 
        posting_date_key, 
        fiscal_date_key, 
        original_currency_key, 
        local_currency_key, 
        group_currency_key

)

SELECT *
FROM final 

