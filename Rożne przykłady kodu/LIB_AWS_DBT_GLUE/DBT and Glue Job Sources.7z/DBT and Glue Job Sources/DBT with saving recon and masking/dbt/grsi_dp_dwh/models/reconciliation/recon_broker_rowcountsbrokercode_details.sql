  -- depends_on: {{ ref('dbt_recon_results') }}
{{
  config(
    materialized = 'incremental',
    transient = False,
    unique_key = 'result_id',
  )
}}

{% set model_name = model.name | replace("_details", "") %}
{% set header_data = get_test_results_header_data(model_name) %}
{% set source_table = get_dbt_test_schema_name() ~ '.' ~ model_name %}
{% set source_row_count = get_rowcounts(source_table) %}

WITH cte as (
  select * from {{ source_table }}
), 

{% if header_data|length > 0 and source_row_count > 0  %}

    final as (
        select
            {%- for row in header_data %} 
                cast('{{row[0]}}' as int)  as header_key, 
                cast('{{row[1]}}' as TIMESTAMP) as header_time_stamp,
                cast('{{row[2]}}' as TIMESTAMP) as generated_date,
                cast('{{row[3]}}' as int)  as fail_rows,
                cast('{{row[4]}}' as float)  as execution_time,
                cast('{{row[5]}}' as varchar(100))  as table_name,
                cast('{{row[6]}}' as VARCHAR(1000))  as result_id,
            {%- endfor %} 
            cte.*
        FROM cte
    )

    select * 
    from final

{% else %}

    empty_table as (
        select
                cast('1' as int)  as header_key, 
                cast(getdate() as TIMESTAMP) as header_time_stamp,
                cast(getdate() as TIMESTAMP) as generated_date,
                cast('1' as int)  as fail_rows,
                cast('1' as float)  as execution_time,
                cast(null as varchar(100))  as table_name,
                cast(null as VARCHAR(1000))  as result_id,
            cte.*
        FROM cte
    )

  select * 
  from empty_table where 1=0

{% endif %}
