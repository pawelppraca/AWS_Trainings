{{
    generate_cte(
        [
            {"table": "claim_payments", "alias": "claim_payments"}
        ]
    )
}},
final AS (
    select
        claim_payments_key,
        payment_currency_code_key,
        payee_name,
        payment_flag,
        payment_posted_date,
        payment_type,
        total_payment_amount,
        created_by_claim_handler_key,
        date_invoice_received,
        date_payment_received_by_processor,
        date_payment_sent_to_handler_for_review,
        date_handler_advised_processor_to_process_payment,
        payment_approved_date,
        final_approver,
        payment_method,
        payee_ref,
        payee_address,
        payee_location,
        __source_system_code,
        __data_region,
        __merge_key,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'claim_payments_key']) }} as __global_claim_payments_key
    from claim_payments
)
select *
from final