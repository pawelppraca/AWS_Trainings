{{
    generate_cte(
        [
            {"table": "staging_genius_zacj", "alias": "zacj", "columns":["cjcncd", "cjd5e9", "cjcucd", "cjd5ff"]}
        ]
    )
}},
genius_fx_rates as (

    select
        'GENIUS' AS fx_rate_type_code,
        TRUNC(DATEADD(month, -1, TO_DATE('20' + REPLACE(cjd5e9, ' ', '') + '01', 'YYYYMMDD'))) as fiscal_period,
        cjcucd as currency_code,
        --This calculation replicates [Map].[FXRates_Genius] table on BILZ where
        --the rate is stored as an inverse and rounded to 8dp
        CONVERT(decimal(15,8), ROUND(1.0 / NULLIF(cjd5ff, 0), 8)) as rate,
        __source_system_code,
        __extraction_date_time,
        __load_id
    from zacj
    where cjcncd ilike 'LMUK'
    and (REGEXP_INSTR(cjd5e9, '[0-9][0-9] [0-9][0-9]') > 0 and LEN(cjd5e9) = 5) --'03 05' format

),
convert_to_usd_rates as (

    select
        fx_rate_type_code as exchange_rate_type,
        fiscal_period as exchange_rate_from_date,
        fiscal_period as exchange_rate_to_date,
        currency_code as from_currency_code,
        'USD' as to_currency_code,
        cast(rate as decimal(30, 8)) as exchange_rate,
        __source_system_code,
        __extraction_date_time,
        __load_id
    from genius_fx_rates

),
convert_from_usd_rates as (

    select
        fx_rate_type_code as exchange_rate_type,
        fiscal_period as exchange_rate_from_date,
        fiscal_period as exchange_rate_to_date,
        'USD' as from_currency_code,
        currency_code as to_currency_code,
        cast(((1::float) / (rate::float)) as decimal(30, 8)) as exchange_rate,
        __source_system_code,
        __extraction_date_time,
        __load_id
    from genius_fx_rates

),
final as (

    select *
    from convert_to_usd_rates
    union
    select *
    from convert_from_usd_rates

)
select *
from final

