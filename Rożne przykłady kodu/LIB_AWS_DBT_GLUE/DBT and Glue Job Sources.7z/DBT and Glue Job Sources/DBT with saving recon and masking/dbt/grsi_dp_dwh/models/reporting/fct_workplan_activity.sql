{{
    generate_cte(
        [
            {"table": "workplan_activity", "alias": "workplan_activity"},
            {"table": "dim_workplan_activity", "alias": "dim_workplan_activity"},
        ]
    )
}},

source_data AS (
    SELECT
        workplan_activity.*,
        {{ generate_merge_key([
            "workplan_activity.activity_status", 
            "workplan_activity.activity_priority", 
            "workplan_activity.activity_type", 
            "workplan_activity.activity_pattern_subject", 
            "workplan_activity.activity_description"
        ]) }} AS __dim_workplan_merge_key
    FROM workplan_activity
),

joined_workplan AS (
    select
        src.workplan_activity_key,
        src.claim_key,
        src.policy_key,
        src.claim_handler_group_key,
        src.assigned_by_claim_handler_key,
        src.assigned_to_claim_handler_key,
        src.closed_by_claim_handler_key,
        src.created_by_claim_handler_key,
        src.updated_by_claim_handler_key,
        src.activity_assignment_date,
        src.activity_created_date,
        src.activity_closed_date,
        src.activity_due_date,
        src.activity_escalation_date,
        dim.dim_workplan_activity_key,
        src.__merge_key,
        src.__event_sequence_number,
        src.__effective_from_date,
        src.__effective_to_date,
        src.__is_current
    from source_data as src
    left join dim_workplan_activity as dim
    on src.__dim_workplan_merge_key = dim.__merge_key
),

measures AS (
    SELECT
        src.*,
        1 as activity_count
    FROM joined_workplan as src
),

final AS (

    SELECT
        workplan_activity_key,
        policy_key,
        claim_key,
        claim_handler_group_key,
        assigned_by_claim_handler_key,
        assigned_to_claim_handler_key,
        created_by_claim_handler_key,
        updated_by_claim_handler_key,
        closed_by_claim_handler_key,
        {{ get_date_key('activity_created_date') }} AS activity_created_date_key,
        {{ get_date_key('activity_closed_date') }} AS activity_closed_date_key,
        {{ get_date_key('activity_due_date') }} AS activity_due_date_key,
        {{ get_date_key('activity_escalation_date') }} AS activity_escalation_date_key,
        {{ get_date_key('activity_assignment_date') }} AS activity_assignment_date_key,
        dim_workplan_activity_key,
        activity_count,
        __event_sequence_number,
        __effective_from_date,
        __effective_to_date,
        __is_current,
        __merge_key
    FROM measures
)
SELECT *
FROM final