{{
    generate_cte(
        [
            {"table": "ri_code", "alias": "ri_code"}
        ]
    )
}},
final AS (
    
    select
        ri_code_key, 
        ri_type_code, 
        ri_type, 
        ri_group,  
        __source_system_code,
        __data_region,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'ri_code_key']) }} as __global_ri_code_key
    from ri_code

)
select *
from final