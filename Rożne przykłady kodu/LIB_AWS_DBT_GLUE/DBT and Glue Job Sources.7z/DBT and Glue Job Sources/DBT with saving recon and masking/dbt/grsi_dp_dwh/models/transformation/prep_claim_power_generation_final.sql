{{
    generate_cte(
        [
            {"table": "staging_claim_center_cctl_ext_esmanufacturer", "alias": "esmanufacturer", "columns":["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_esmodelnumber", "alias": "esmodelnumber", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_estechnologytype", "alias": "estechnologytype", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cctl_ext_esvariant", "alias": "esvariant", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cctl_extequipmentstructure", "alias": "esequipmentstructure", "columns": ["id", "name"]},
            {"table": "staging_claim_center_cc_claim", "alias": "claim", "columns": ["id", "ext_equipmentstruct", "ext_section", "ext_esmanufacturer", "ext_esmodelnumber", "ext_esvariant", "ext_estechnologytype"]}
        ]
    )
}},

meta_data as (
    select
        __load_id,
        __source_system_code,
        __data_region,
        max(__extraction_date_time) as __extraction_date_time
    from esequipmentstructure
    group by __load_id, __source_system_code, __data_region
),
power_generation AS (
    SELECT DISTINCT
        ISNULL(eq.name, 'NA') AS equipment_type
        , ISNULL(esm.name, 'NA') AS manufacturer
        , ISNULL(mn.name, 'NA') AS model_number
        , ISNULL(mv.name, 'NA') AS model_variant
        , ISNULL(tt.name, 'NA') AS technology_type
        , c.__source_system_code
        , c.__load_id
        , c.__data_region
    FROM
        claim AS c
        LEFT JOIN esequipmentstructure AS eq ON eq.id = c.Ext_equipmentStruct AND c.Ext_Section <> 10100
        LEFT JOIN esmanufacturer AS esm ON c.Ext_ESManufacturer = esm.id AND c.Ext_Section = 10100
        LEFT JOIN esmodelnumber AS mn ON c.Ext_ESModelNumber = mn.id AND c.Ext_Section = 10100
        LEFT JOIN esvariant AS mv ON c.Ext_ESVariant = mv.id AND c.Ext_Section = 10100
        LEFT JOIN estechnologytype AS tt ON c.Ext_ESTechnologyType = tt.id AND c.Ext_Section = 10100
),
join_meta_data AS (
    SELECT
        power_generation.equipment_type,
        power_generation.manufacturer,
        power_generation.model_number,
        power_generation.model_variant,
        power_generation.technology_type,
        power_generation.__source_system_code,
        meta_data.__extraction_date_time,
        power_generation.__load_id,
        power_generation.__data_region
    FROM power_generation
    INNER JOIN meta_data
    ON power_generation.__load_id = meta_data.__load_id
    AND power_generation.__source_system_code = meta_data.__source_system_code
    AND power_generation.__data_region = meta_data.__data_region
),
final AS (
    SELECT
        equipment_type,
        manufacturer,
        model_number,
        model_variant,
        technology_type,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region,
        {{
            generate_merge_key(
                [
                    "__source_system_code",
                    "equipment_type",
                    "manufacturer",
                    "model_number",
                    "model_variant",
                    "technology_type"
                ]
            )
        }} AS __merge_key,
        row_number() OVER (
            PARTITION BY __merge_key ORDER BY __extraction_date_time DESC
        ) AS __record_version
    FROM join_meta_data
)
SELECT *
FROM final