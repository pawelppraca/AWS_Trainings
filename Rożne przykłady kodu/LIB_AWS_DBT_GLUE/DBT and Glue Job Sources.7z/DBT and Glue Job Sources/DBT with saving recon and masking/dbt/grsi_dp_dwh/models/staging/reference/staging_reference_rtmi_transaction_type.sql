{{ generate_staging_model('staging_reference', 'rtmi_transaction_type') }}
