
{{
    generate_cte(
        [
            {"table": "staging_claim_center_cc_claim", "alias": "claim_source", "columns":["id","claim_number"]},
            {"table": "staging_claim_center_ccx_locationids", "alias": "locationids_source", "columns":["id","claimid","location"]},
        ]
    )
}},
final as (
    select
        locationids.location as location_id,
        locationids.__source_system_code,
        locationids.__extraction_date_time,
        locationids.__load_id,
        locationids.__data_region,
        {{ generate_merge_key(["claim.__source_system_code", "claim.claim_number"]) }} as __claim_merge_key,
        {{generate_merge_key(["locationids.__source_system_code","locationids.id::text"])}} as __merge_key,
        row_number() over (partition by __merge_key order by locationids.__extraction_date_time desc) as __record_version
    from locationids_source as locationids
    left outer join claim_source as claim
        on locationids.claimid = claim.id
)
select *
from final