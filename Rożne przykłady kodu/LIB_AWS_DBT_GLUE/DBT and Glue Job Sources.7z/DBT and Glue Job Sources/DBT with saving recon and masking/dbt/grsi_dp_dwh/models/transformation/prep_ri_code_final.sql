{{
    generate_cte(
        [
            {"table": "staging_reference_rtmi_ri_code", "alias": "rtmi_ri_code_source", "columns":["ritypecode", "ritype", "rigroup"]}
        ]
    )
}},
final as (

    select
        row_number() over (
            partition by __merge_key order by __extraction_date_time desc
        ) as __record_version,
        ritypecode as ri_type_code,
        ritype as ri_type,
        rigroup as ri_group,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region,
        {{
            generate_merge_key(
                [
                    "ritypecode",
                ],
            )
        }} as __merge_key

    from rtmi_ri_code_source

)
select *
from final
