{{
    generate_cte(
        [
            {"table": "staging_reference_rtmi_exposure_status", "alias": "rtmi_exposure_status_source", "columns":["exposurestatus"]}
        ]
    )
}},
final as (
    select
        row_number() over (
            partition by __merge_key order by __extraction_date_time desc
        ) as __record_version,
        exposurestatus as exposure_status,
        __source_system_code,
        __extraction_date_time,
        __load_id,
        __data_region,
        {{
            generate_merge_key(
                [
                    "exposurestatus",
                ],
            )
        }} as __merge_key
    from rtmi_exposure_status_source
)
select *
from final
