{{
    generate_cte(
        [
            {"table": "claim_storage", "alias": "claim_storage"}
        ]
    )
}},
final AS (

    select
        claim_storage_key,
        claim_key,
        storage_box_number,
        storage_notes,
        record_retention_date,
        destruction_date,
        date_sent_to_storage
        __source_system_code,
        __data_region,
        __merge_key,
        {{ dbt_utils.generate_surrogate_key(['__data_region', 'claim_storage_key']) }} as __global_claim_storage_key
    from claim_storage

)
select *
from final