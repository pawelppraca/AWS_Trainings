{% test recon_policy_codes_row_count( model, condition ) %}

    {% set test_description %} Compare row_counts between model {{ model }}, risk and coverage group by branch_code, lob_code and coverage_code {% endset %}
    {% set fail_msg %} Found {{ result }} not equal rows of {{ model }}, risk and coverage group by branch_code, lob_code and coverage_code {% endset %}
    {{ config(description = test_description, fail_msg = fail_msg) }}

    WITH source_policy AS (
        SELECT * FROM {{ ref('staging_warehouse_repository_policies') }}
    ),
    source_limits AS (
        SELECT * FROM {{ ref('staging_warehouse_repository_limits') }}
    ),
    dwh_risk AS (
        SELECT * FROM {{ ref('risk') }}
    ),
    dwh_coverage AS (
        SELECT * FROM {{ ref('coverage') }}
    ),
    source_table as (
        select
            policy.BranchCode,
            policy.lobcode,
            coverage.qualifiercode as coveragecode,
            count(*) as source_count
        from source_policy as policy
        left outer join source_limits as coverage
        on policy.policykey = coverage.policykey
        group by policy.BranchCode,policy.lobcode,coveragecode
        order by source_count desc
    ),
    dwh_table as (
         select
             policy.branch_code,
             risk.lob_code,
             coverage.coverage_code,
             count(*) as dwh_count
         from {{ model }} as policy
                  left outer join dwh_risk as risk
                                  on policy.policy_key = risk.policy_key
                  left outer join dwh_coverage as coverage
                                  on risk.risk_key = coverage.risk_key
         group by policy.branch_code,risk.lob_code,coverage.coverage_code
         order by dwh_count desc
     ),
    result as (
         select
             dwh_table.branch_code,
             dwh_table.lob_code,
             dwh_table.coverage_code,
             dwh_table.dwh_count,
             source_table.source_count
         from dwh_table
            inner join source_table on dwh_table.branch_code = source_table.BranchCode
             and dwh_table.lob_code = source_table.lobcode
             and dwh_table.coverage_code = source_table.coveragecode
         where dwh_table.dwh_count != source_table.source_count
    )

select *
from result

{% endtest %}