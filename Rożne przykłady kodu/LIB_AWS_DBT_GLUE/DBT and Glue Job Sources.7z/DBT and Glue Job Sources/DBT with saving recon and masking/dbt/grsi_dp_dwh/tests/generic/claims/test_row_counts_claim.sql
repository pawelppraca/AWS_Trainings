{% test row_counts_claim ( model, source_column_name, target_column_name ) %}
  
    {% set test_name = 'row_counts__' ~ model.name ~ '__' ~ target_column_name %} 
    {% set test_description %} Compare row_counts between model {{ model }} and {{ source_model }} group by {{ target_column_name }} {% endset %}
    {% set fail_msg %} Found {{ result }} not equal rows of {{ model }} and {{ source_model }} group by {{ target_column_name }} {% endset %}
    {{ config(name = test_name, description = test_description, fail_msg = fail_msg) }}
	


    WITH cc_contacts AS (
            SELECT * FROM {{ ref('staging_claim_center_cc_contact') }} 
    ),
    cc_users AS (
            SELECT * FROM {{ ref('staging_claim_center_cc_user') }}
    ),

    users AS (
            SELECT 
                    c.firstname
                    , c.lastname 
                    ,u.id AS user_id 
            FROM cc_contacts c
            JOIN cc_users u 
                    ON u.__load_id = c.__load_id 
                    AND c.id = u.contactid
    ),


    claims_row_counts_by_created_user_source AS (
            SELECT  
                    DATE_PART_YEAR(trunc(lossdate)) AS LoassDate_Year_source
                    , u.Firstname
                    , u.Lastname
                    , count(c.id) count_of_claims_source
            from {{ ref('staging_claim_center_cc_claim') }} c
            JOIN users u ON u.user_id = c.{{source_column_name}}
            GROUP BY DATE_PART_YEAR(trunc(lossdate)) 
                    , u.Firstname
                    , u.Lastname
    ),

    claims_row_counts_by_created_user_target AS(
            SELECT 
                    DATE_PART_YEAR(trunc(date_of_loss)) AS LoassDate_Year_target 
                    , ch.first_name
                    , ch.last_name
                    , count(*) count_of_claims_target 
            FROM {{ model }} c
            JOIN {{ ref('claim_handler') }} ch ON ch.claim_handler_key = c.{{target_column_name}}
            WHERE ch.claim_handler_key <> -1  
            GROUP BY DATE_PART_YEAR(trunc(date_of_loss)) 
                    , ch.first_name
                    , ch.last_name
    )

    SELECT *
    FROM claims_row_counts_by_created_user_source s
    JOIN claims_row_counts_by_created_user_target t 
            ON t.LoassDate_Year_target = s.LoassDate_Year_source 
            AND s.firstname = t.first_name
            AND s.lastname = t.last_name
    WHERE s.count_of_claims_source <> t.count_of_claims_target

{% endtest %}
