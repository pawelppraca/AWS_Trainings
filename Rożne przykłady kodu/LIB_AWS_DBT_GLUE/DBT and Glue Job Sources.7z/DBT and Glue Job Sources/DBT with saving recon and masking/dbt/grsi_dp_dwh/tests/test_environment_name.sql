with
    
    expected as (
        select 'dev' as environment_name
        union
        select 'test'
        union
        select 'qa'
        union
        select 'production'
    ),

    actual as (
        select lower('{{ get_environment_name() }}') as environment_name
    )

select *
from actual
where environment_name not in (select environment_name from expected)
