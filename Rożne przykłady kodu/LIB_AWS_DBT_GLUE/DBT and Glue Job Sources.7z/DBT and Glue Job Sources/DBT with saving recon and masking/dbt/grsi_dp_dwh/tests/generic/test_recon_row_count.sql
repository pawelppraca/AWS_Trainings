{%- test recon_row_count( model,
                          join_model,
                          group_column_names, 
                          join_conditions,
                          join_type,
                          where_condition, 
                          having_condition,
                          source_model, 
                          source_join_model,
                          s_group_column_names, 
                          s_join_conditions,
                          s_join_type,
                          s_where_condition, 
                          s_having_condition
                          ) -%}
  
    {% set test_name = 'recon_row_counts__' ~ model.name ~ '__' ~ group_column_names %}
    {% set test_description %} Compare row_counts between model {{ model }} and {{ source_model }} group by {{ group_column_names }} {% endset %}
    {% set fail_msg %} Found {{ result }} not equal rows of {{ model }} and {{ source_model }} group by {{ group_column_names }} {% endset %}
    {{ config(name = test_name, description = test_description, fail_msg = fail_msg) }}
	


    WITH source_cte AS (
            SELECT  
                {% for s_col in s_group_column_names %}
                    {{ s_col }} {% if not loop.last %},{% endif %}
                {% endfor %}
                , COUNT(*) AS Source_records_qty
            FROM  {{ source_model }} AS source_model  
            {% if source_join_model != '' %}
                {{ s_join_type }} JOIN  {{ source_join_model }} AS source_join_model  ON
                        {% for s_condition in s_join_conditions %}
                            {{ s_condition }} {% if not loop.last %} AND {% endif %}
                        {% endfor %}
            {% endif %}
            --WHERE Clause
            {% if s_where_condition %}
                {{ "WHERE " ~ s_where_condition}}
            {% endif %}
            --GROUP BY
            {{ dbt_utils.group_by(n=s_group_column_names|length) }}
            --having clause
            {% if s_having_condition|length > 0 %}
                {{ "HAVING " ~ s_having_condition}}
            {% endif %}
        ),
   
    
    
        target_cte AS (
                SELECT 
                    {% for t_col in group_column_names %}
                        {{ t_col }} {% if not loop.last %},{% endif %}
                    {% endfor %}
                    , COUNT(*) AS Target_records_qty
                FROM  {{ model }} AS model
                {% if join_model != '' %}
                    {{ join_type }} JOIN  {{ join_model }} AS join_model ON
                        {% for t_condition in join_conditions%}
                            {{ t_condition }} {% if not loop.last %} AND {% endif %}
                        {% endfor %}
                {% endif %}
                --WHERE Clause
                {% if where_condition %}
                    {{ "WHERE " ~ where_condition}}
                {% endif %}
                --GROUP BY  
                {{ dbt_utils.group_by(n = group_column_names|length) }}
                --having clause
                {% if having_condition %}
                    {{ "HAVING " ~ having_condition}}
                {% endif %}
                
            )


    SELECT * FROM source_cte s
    JOIN target_cte t ON
            {% for t_col in group_column_names %}
                {{ "t." ~ t_col ~ " = s."~ s_group_column_names[loop.index-1] }} {% if not loop.last %} AND {% endif %}
            {% endfor %}
    WHERE Source_records_qty <> target_records_qty

{% endtest %}
