
{% test checksum_equality(  model, 
                            key_model, 
                            model_checksum_columns,
                            model_where_condition,
                            source, 
                            key_source, 
                            source_checksum_columns, 
                            source_where_condition
                            ) %} 

    {% set test_name = 'checksum_equality__' ~ model.name ~ '__' ~ source %} 

    {% set test_description %} Compare row_counts between model {{ model }} and {{ source }} group by {{ model_checksum_columns }} {% endset %}

    {% set fail_msg %} Found {{ result }} not equal rows of {{ model }} and {{ source }} group by {{ model_checksum_columns }} {% endset %}
            
    {{ config(name = test_name, description = test_description, fail_msg = fail_msg) }}



    WITH source_checksum AS (
        {{ checksum_for_table(source, key_source, source_checksum_columns, source_where_condition) }}
    ),
    target_checksum AS (
        {{ checksum_for_table(model, key_model, model_checksum_columns, model_where_condition) }}
    )

    SELECT
        source_checksum.checksum AS source_checksum,
        target_checksum.checksum AS target_checksum
    FROM source_checksum 
    FULL OUTER JOIN target_checksum
    ON source_checksum.key_id = target_checksum.key_id
    WHERE source_checksum.checksum != target_checksum.checksum


{% endtest %}
