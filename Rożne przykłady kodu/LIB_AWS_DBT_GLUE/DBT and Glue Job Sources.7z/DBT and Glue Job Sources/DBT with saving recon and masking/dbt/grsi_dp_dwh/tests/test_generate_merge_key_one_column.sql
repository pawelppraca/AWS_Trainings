with
    test_data_source as (
        select
            cast('test_genius' as varchar(50)) as __source_system_code,
            cast('test_value' as varchar(50)) as test_column
    ),

    expected as (select 'TEST_GENIUS' as __merge_key),

    actual as (
        select
            {{ generate_merge_key(["__source_system_code"]) }}
            as __merge_key
        from test_data_source
    )

select *
from actual
where __merge_key not in (select __merge_key from expected)
