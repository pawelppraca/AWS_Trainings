{% test recon_workplan_activity_join( model, condition ) %}

    {% set test_description %} Compare row_counts between model {{ model }} and cc_activity,cc_claim and cctl_claimstate {% endset %}
    {% set fail_msg %} Found {{ result }} not equal rows of {{ model }} and cc_activity,cc_claim and cctl_claimstate {% endset %}
    {{ config(description = test_description, fail_msg = fail_msg) }}

    with staging_cc_activity as (
        select * from {{ ref('staging_claim_center_cc_activity') }}
    ),
    staging_cc_claim as (
        select * from {{ ref('staging_claim_center_cc_claim') }}
    ),
    staging_cctl_claimstate as (
        select * from {{ ref('staging_claim_center_cctl_claimstate') }}
    ),
    result as (
        select workplan_activity.workplan_activity_key
        from staging_cc_activity as activity
        left join {{ model }} as workplan_activity
            on activity.id = right( workplan_activity.__merge_key, LENGTH( workplan_activity.__merge_key) -13)
        left join staging_cc_claim as claims
            on activity.ClaimID = claims.id
        left join staging_cctl_claimstate as claim_state
            on claim_state.ID = claims.state
        where workplan_activity.__merge_key IS NULL and claim_state.name <> 'Draft'
    )

select *
from result

{% endtest %}