
{% docs row_counts_claim %}

This test compares row counts between source and target only for claims. To comparison tables it uses sha1 hash function. Uses it to calculate hash on particular columns related to both tables. Columns used to calculate hash are set in argument  "source_checksum_columns" and "model_checksum_columns"

**Args:**

- `model` - (required): table which is used for testing as a target
- `source_column_name` - column name used to join claims with handlers from source side
- `target_column_name` - column name used to join claims with handlers from target side

- `model` 

**Usage:**
```
    Example include in _warehouse_properties.yml for table claims

    {% raw %}
 tests:
      - row_counts_claim:
          source_column_name: 'assignedbyuserid'
          target_column_name: 'assigned_by_claim_handler_key'
      - row_counts_claim:
          source_column_name: 'assigneduserid'
          target_column_name: 'assigned_to_claim_handler_key'
      - row_counts_claim:
          source_column_name: 'createuserid'
          target_column_name: 'created_by_claim_handler_key'
      - row_counts_claim:
          source_column_name: 'updateuserid'
          target_column_name: 'updated_by_claim_handler_key'

    {% endraw %}
```
{% enddocs %}


{% docs recon_claim %}

This test compares data between between models recon_claim_stg and recon_claim_dwh for claims. "model_checksum_columns"

**Args:**

- `model` - (required): table which is used for testing as a target - claim
- `condition` - (optional) condition use in WHERE calause

**Usage:**
```
    Example include in _warehouse_properties.yml for table claims

    {% raw %}
    tests:
      - recon_claim:
          condition: 'isnull(stg.amount_original, 0) - isnull(dwh.amount_original,0) != 0'
      - recon_claim:
          condition: 'isnull(stg.row_count, 0) - isnull(dwh.row_count,0) != 0'
      - recon_claim:
          condition: 'ABS(isnull(stg.amount_local, 0) - isnull(dwh.amount_local,0)) > 1'

    {% endraw %}
```
{% enddocs %}
