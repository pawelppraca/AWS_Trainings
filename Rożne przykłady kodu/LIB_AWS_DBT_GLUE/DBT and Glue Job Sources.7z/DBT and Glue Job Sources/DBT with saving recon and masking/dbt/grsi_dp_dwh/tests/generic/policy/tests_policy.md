{% recon_policy_codes_row_count %}

This test compares the row counts between the joined policy, risk and coverage tables with their corresponding tables from the data source and ensures a matchin row count when grouped by branch_code, lob_code and coverage_code

**Args:**

- `model` - (required): table which is used for testing as a target - policy

**Usage:**
```
    Example include in _warehouse_properties.yml for table claims

    {% raw %}
    tests:
      - recon_workplan_activity_join

    {% endraw %}
```
{% enddocs %}
