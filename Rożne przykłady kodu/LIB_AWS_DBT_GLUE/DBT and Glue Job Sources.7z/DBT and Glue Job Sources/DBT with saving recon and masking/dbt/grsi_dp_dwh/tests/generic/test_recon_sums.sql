
{% test recon_sums(
        model, 
        model_2, 
        group_column_names, 
        summary_column, 
        join_conditions, 
        where_condition, 
        having_condition,

        s_model_1, 
        s_model_2, 
        s_group_column_names, 
        s_summary_column, 
        s_join_conditions, 
        s_where_condition, 
        s_having_condition
    ) %}

      
    {% set test_name = 'recon_sums__' ~ model.name ~ '__' ~ summary_column %} 
    {% set test_description %} Compare sums of column {{ summary_column }} between model {{ model }} and {{ s_model_1 }} group by {{ group_column_names }} {% endset %}
    {% set fail_msg %} Found {{ result }} not equal sums of column {{ summary_column }} between model {{ model }} and {{ s_model_1 }} group by {{ group_column_names }} {% endset %}
    {{ config(name = test_name, description = test_description, fail_msg = fail_msg) }}
	


    WITH source_cte AS
    (
        SELECT 
            {% for s_col in s_group_column_names %}
                {{ s_col }} {% if not loop.last %},{% endif %}
            {% endfor %}
            , SUM({{ s_summary_column }}) AS source_SUM
        FROM  {{ s_model_1 }}  AS s_model_1 
        {% if s_model_2 != '' %}
            JOIN  {{ s_model_2 }} AS s_model_2 ON 
                    {% for s_condition in s_join_conditions %}
                        {{ s_condition }} {% if not loop.last %} AND {% endif %}
                    {% endfor %}
        {% endif %}        
        --WHERE Clause
        {% if s_where_condition %}
        WHERE {{ s_where_condition }}
        {% endif %}
        --GROUP BY  
        {{ dbt_utils.group_by(n=s_group_column_names|length) }}
        --having clause
        {% if s_having_condition %}
        HAVING {{ s_having_condition }}
        {% endif %}
        
    ),

    
        target_cte AS
            (
                SELECT 
                    {% for t_col in group_column_names %}
                        {{ t_col }} {% if not loop.last %},{% endif %}
                    {% endfor %}
                    ,SUM({{ summary_column }}) AS target_SUM
                FROM  {{ model }}  model
                {% if model_2 != '' %} model_2
                    JOIN  {{ model_2 }}  ON
                            {% for condition in join_conditions %}
                                {{ condition }} {% if not loop.last %} AND {% endif %}
                            {% endfor %}
                {% endif %}        
                --WHERE Clause
                {% if where_condition %}
                    WHERE  {{ where_condition }}
                {% endif %}
                --GROUP BY  
                {{ dbt_utils.group_by(n = group_column_names|length) }}
                --having clause
                {% if having_condition %}
                    HAVING {{ having_condition }}
                {% endif %}
                
            )

    
    SELECT * FROM source_cte s
    JOIN target_cte t ON
            {% for col in group_column_names %}
                {{ "t." ~ col ~ " = s."~ s_group_column_names[loop.index-1] }} {% if not loop.last %} AND {% endif %}
            {% endfor %}
    WHERE source_SUM <> target_SUM


{% endtest %}