{% docs checksum_equality %}

This test compares two tables source and model. To comparison tables it uses sha1 hash function. Uses it to calculate hash on particular columns related to both tables. Columns used to calculate hash are set in argument  "source_checksum_columns" and "model_checksum_columns"

**Args:**

- `model` (required): table which is used for testing as a target
- `key_model` (required): key kolumn in target table, which is used to join target table to source table
- `model_checksum_columns` (required): set of columns from target table which are used to calculate md5 hash
- `model_where_condition` (optional): target table where condition
- `source` (required): source table to compare with target
- `key_source` (required): key kolumn in source table, which is used to join target table to source table 
- `source_checksum_columns` (required): set of columns from source table which are used to calculate md5 hash 
- `source_where_condition`  (optional): source table where condition

**Usage:**
```
    Example include in _warehouse_properties.yml for table geography and broker

    {% raw %}
    tests:
        - checksum_equality:
            key_model: wr_area_key
            model_checksum_columns: ['state_code', 'state_name', 'iso_country_code', 'iso_country_name', 'iso_state_code', 'iso_state_name', 'region_code', 'region_name', 'sub_region_code', 'sub_region_name']
            model_where_condition: '1=1'
            source: ref('staging_warehouse_repository_areas')
            key_source: areakey
            source_checksum_columns: ['areacode', 'areaname', 'isoareacode', 'isoareaname', 'isostatecode', 'isostatename', 'regioncode', 'regionname', 'subregioncode', 'subregionname']
            source_where_condition: ''

    {% endraw %}
```
{% enddocs %}

{% docs recon_row_count %}

This test compares row counts group by group_column_names between two tables source and model. 
There can be use join from both sides source and target with one table using join_conditions and s_join_conditions

**Args:**

- `test_model` (required): table which is used for testing as a target

- `join_model` (optional): name of the second model joined to target model
- `group_column_names` (required): set of columns from target table which are used to group
- `join_conditions` (optional): condition to join test_model and join_model
- `join_type` (optional): set the type of join between test_model and join_model (eg 'inner', 'left', 'right')
- `where_condition` (optional): target table where condition
- `having_condition` (optional): target table having condition
- `source_model` (required): source table to compare with target
- `source_join_model` (optional): second source table to join with s_model_1 to compare with target
- `s_group_column_names` (required): set of columns from source tables which are used to group
- `s_join_conditions` (optional): condition to join s_model_1 and source_join_model
- `s_join_type` (optional): set the type of join between source_model and source_join_model (eg 'inner', 'left', 'right')
- `s_where_condition` (optional): source table where condition
- `s_having_condition`  (optional): source table having condition

**Usage:**
```
    Example include in _warehouse_properties.yml for table coverage

    {% raw %}

    tests:
      - recon_row_count:
          model_2: ''
          group_column_names: ['coverage_code','coverage_name']
          join_conditions: ''
          where_condition: ''
          having_condition: ''
          source_model: ref('staging_warehouse_repository_limits') 
          source_join_model: ref('staging_warehouse_repository_policies')
          s_group_column_names: ['qualifiercode','qualifiername']
          s_join_conditions: ['source_model.policykey = source_join_model.policykey']
          s_where_condition: 'source_model._currentflag = true'
          s_having_condition: ''

    {% endraw %}
```
{% enddocs %}


{% docs recon_sums %}

This test compares sum of particular summary_column group by group_column_names between two tables source and model. 
As source as target models can be (optionaly) joined with one model from both sides source and target using join_conditions and s_join_conditions

**Args:**

- `model` (required): table which is used for testing as a target
- `model_2` (optional): name of the second model joined to target model
- `group_column_names` (required): set of columns from target table which are used to group
- `summary_column` (required): name of the column which is sums and compared
- `join_conditions` (optional): condition to join model and model_2
- `where_condition` (optional): target table where condition
- `having_condition` (optional): target table having condition
- `s_model_1` (required): source table to compare with target
- `s_model_2` (optional): second source table to join with s_model_1 to compare with target
- `s_group_column_names` (required): set of columns from source tables which are used to group
- `s_summary_column` (required): name of the column which is sums and compared
- `s_join_conditions` (optional): condition to join s_model_1 and s_model_2
- `s_where_condition` (optional): source table where condition
- `s_having_condition`  (optional): source table having condition

**Usage:**
```
    Example include in _warehouse_properties.yml for table coverage

    {% raw %}

      - recon_sums:
          model_2: ''
          group_column_names: ['coverage_code','coverage_name']
          summary_column: 'coverage_whole_limit'
          join_conditions: ''
          where_condition: ''
          having_condition: ''
          s_model_1: ref('staging_warehouse_repository_limits') 
          s_model_2: ref('staging_warehouse_repository_policies')
          s_group_column_names: ['qualifiercode','qualifiername']
          s_summary_column: 'limitoriginalcurrency'
          s_join_conditions: ['s_model_1.policykey = s_model_2.policykey']
          s_where_condition: 's_model_1._currentflag = true'
          s_having_condition: ''

    {% endraw %}
```
{% enddocs %}

{% docs recon_sums %}

This test ensures that each entry in the target table has a corresponding entry in the source table through us of a join and where condition

**Args:**

- `model` (required): target table to be tested
- `join_model` (required): source table to be joined with target table
- `join_conditions` (required): conditions with which to join the tables
- `join_type` (optional): type of join to be used, if not specified, defaults to join
- `where_condition` (required): determines how to filter the results to ensure both tables match

**Usage:**
```
    Example include in _warehouse_properties.yml for table coverage

    {% raw %}

      - recon_row_count:
          join_model: ref('fct_workplan_activity')
          join_conditions: ['model.policy_key = join_model.policy_key']
          join_type: 'LEFT'
          where_condition: 'join_model.workplan_activity_key IS NULL'

    {% endraw %}
```
{% enddocs %}

