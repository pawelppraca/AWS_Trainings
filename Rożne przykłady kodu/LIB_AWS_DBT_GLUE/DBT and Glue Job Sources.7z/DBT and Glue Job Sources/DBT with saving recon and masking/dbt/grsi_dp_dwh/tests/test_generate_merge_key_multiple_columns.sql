with
    test_data_source as (
        select
            cast('test_genius' as varchar(50)) as __source_system_code,
            cast('test_value_1' as varchar(50)) as test_column_1,
            cast('test_value_2' as varchar(50)) as test_column_2,
            cast('test_value_3' as varchar(50)) as test_column_3
    ),

    expected as (
        select 'TEST_GENIUS|TEST_VALUE_1|TEST_VALUE_2|TEST_VALUE_3' as __merge_key
    ),

    actual as (
        select
            {{
                generate_merge_key(
                    ["__source_system_code", "test_column_1", "test_column_2", "test_column_3"],
                )
            }} as __merge_key
        from test_data_source
    )

select *
from actual
where __merge_key not in (select __merge_key from expected)
