{%- test recon_row_join(model,
                        join_models,
                        join_conditions,
                        join_types,
                        where_condition
                        )
-%}

    {% set test_name = 'recon_row_join__' ~ model.name ~ '__' ~ join_models[0] %}
    {% set test_description %} Compare row_counts between model {{ model }} and {{ join_models[0] }} {% endset %}
    {% set fail_msg %} Found discrepancies in row counts between {{ model }} and {{ join_models[0] }} {% endset %}
    {{ config(name = test_name, description = test_description, fail_msg = fail_msg) }}

    WITH result_set AS (
        SELECT model.*
        FROM  {{ model }} AS model
        {% for join_model, join_type in zip(join_models, join_types) %}
            {{ join_type }} JOIN  {{ join_model }} AS join_model ON
            {% for condition in join_conditions %}
                {{ condition }} {% if not loop.last %} AND {% endif %}
            {% endfor %}
        {% endfor %}
        {{ "WHERE " ~ where_condition}}
    )
SELECT * FROM result_set

    {% endtest %}