{% recon_workplan_activity_join %}

This test joins the workplan activity table with cc_activity, cc_claim and cctl_claimstate and mirrors current filter logic to ensure rows are filtered correctly

**Args:**

- `model` - (required): table which is used for testing as a target - policy

**Usage:**
```
    Example include in _warehouse_properties.yml for table claims

    {% raw %}
    tests:
      - recon_claim

    {% endraw %}
```
{% enddocs %}
