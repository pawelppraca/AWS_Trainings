
{% test recon_claim( model, condition ) %}


    WITH stg_claim AS (
        SELECT * FROM {{ ref ('recon_claim_stg') }}
    ),
    
    dwh_claim AS (
        SELECT * FROM {{ ref ('recon_claim_dwh') }}
    )
    
    SELECT 
            stg.claim_number                                                        AS stg_claim_number
            , dwh.claim_number                                                      AS dwh_claim_number
            , stg.claim_state                                                       AS stg_claim_state
            , stg.date_of_loss                                                      AS stg_date_of_loss
            , stg.claim_handler                                                     AS stg_claim_handler
            , stg.transaction_type_code                                             AS stg_transaction_type_code
            , stg.claim_movement_type                                               AS stg_claim_movement_type
            , dwh.claim_movement_type                                               AS dwh_claim_movement_type
            , stg.ri_code                                                           AS stg_ri_code
            , dwh.ri_code                                                           AS dwh_ri_code
            , stg.fiscal_date                                                       AS stg_fiscal_date
            , dwh.fiscal_date                                                       AS dwh_fiscal_date
            , stg.transaction_date                                                  AS stg_transaction_date
            , dwh.transaction_date                                                  AS dwh_transaction_date
            , stg.original_currency_code                                            AS stg_original_currency_code
            , dwh.original_currency_code                                            AS dwh_original_currency_code
            , stg.local_currency_code                                               AS stg_local_currency_code
            , dwh.local_currency_code                                               AS dwh_local_currency_code
            , stg.row_count                                                         AS staging_count
            , dwh.row_count                                                         AS dwh_count
            , isnull(stg.row_count, 0) - isnull(dwh.row_count,0)                    AS difference_in_count
            , stg.amount_original                                                   AS staging_amount_original
            , dwh.amount_original                                                   AS dwh_amount_original
            , isnull(stg.amount_original, 0) - isnull(dwh.amount_original,0)        AS difference_in_amount_original
            , stg.amount_local                                                      AS stg_amount_local
            , dwh.amount_local                                                      AS dwh_amount_local
            , isnull(stg.amount_local, 0) - isnull(dwh.amount_local,0)              AS difference_in_amount_local
    FROM stg_claim AS stg
    FULL OUTER JOIN dwh_claim dwh 
                        ON stg.date_of_loss = dwh.date_of_loss
                        AND stg.claim_state = dwh.claim_state
                        AND stg.claim_handler = dwh.claim_handler
                        AND stg.transaction_type_code = dwh.transaction_type_code
                        AND stg.claim_movement_type = dwh.claim_movement_type
                        AND isnull(stg.ri_code,'') = isnull(dwh.ri_code,'')
                        AND stg.fiscal_date = dwh.fiscal_date
                        AND stg.claim_number = dwh.claim_number
                        AND stg.original_currency_code = dwh.original_currency_code
                        AND stg.local_currency_code = dwh.local_currency_code
                        AND stg.transaction_date = dwh.transaction_date
    WHERE 1=1
    {% if condition %}
        {{ "AND " ~ condition}}
    {% endif %}



{% endtest %}