{% macro get_unknown_member_date() %}
        {{ return(modules.datetime.date(1900,1,1)) }}
{%- endmacro -%}