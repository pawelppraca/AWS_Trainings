{% macro generate_cte(dict_list, include_meta_data_columns=True, override_error_check=False) %}

{%- set re = modules.re -%}
    
with{% for cte in dict_list %} {{cte.get("alias")}} as (

    {%- set relation = ref(cte.get("table")) %}
    {%- set columns = cte.get("columns") %}

    {%- set is_staging_model = re.match("staging_", relation.identifier, re.IGNORECASE) -%}
    {%- if is_staging_model and not override_error_check -%}
         {%- if columns is none or columns|length <= 0 -%}
                {%- set error_message = 'Error: An explicit list of columns must be specified for ALL staging models. The [{}.{}] model triggered this warning when calling macro `generate_cte` for staging model [{}]. 
                                        '.format(model.package_name, model.name, relation.identifier) -%} 

                {%- do exceptions.raise_compiler_error(error_message) -%} 
        {# this is code for logging staging column meta-data to RedShift table --> not prod ready yet.... #}
        {# {%- else -%}
            {%- do log_staging_model_columns(model.name, cte.get("table"), cte.get("columns")) -%} #}
        {%- endif -%}
    {%- endif -%} 

    {%- if columns is none or columns|length <= 0 %}
    
    select *
    {%- else %}
    
        {%- if include_meta_data_columns -%}
            {%- set meta_columns = [] -%}
            {%- set meta_columns = get_columns_by_pattern(relation, '^\_\_') -%} 
            {%- if meta_columns is not none -%}
                {%- for meta_col in meta_columns -%}
                    {%- if meta_col|lower not in columns -%}
                        {% do columns.append(meta_col) -%}    
                    {%- endif -%}    
                {%- endfor -%}
            {%- endif -%}  
         {%- endif %}    

    select
    {%- for column in columns %}
        {{ column | trim }}
    {%- if not loop.last %},{%- endif -%}
    {%- endfor %}
    {%- endif %}
    from {{ relation }}

)
    {%- if not loop.last -%}
    ,
    {%- endif -%}
    
    {%- endfor -%}

{%- endmacro %}
