{% macro get_current_load_id() %}

    {{ return(var("current_load_id", 0) | as_number) }}

{% endmacro %}
