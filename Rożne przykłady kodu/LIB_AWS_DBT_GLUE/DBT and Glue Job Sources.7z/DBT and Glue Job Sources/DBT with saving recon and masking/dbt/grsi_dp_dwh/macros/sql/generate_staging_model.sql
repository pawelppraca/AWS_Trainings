{% macro generate_staging_model(source_name, table_name, quote_identifiers=false) %}
    
{#-- Prevent querying of db in parsing mode.-#}
{%- if not execute %}
    {{ return('') }}
{% endif -%}

{%- set source_columns = get_source_column_meta_data(source_name, table_name) %}

{# log("\n\nDictionary: \n\n" ~ source_columns, info=true) #}

{%- if source_columns|length <= 0 -%}
    {% do return("/* no columns returned from get_source_column_meta_data() macro */") %}
{% endif -%}

with source as (

    select * 
    from {{ source(source_name, table_name) }}
),
renamed as (

    select 
    {%- for column in source_columns.keys() -%}
        {%- set column_properties = source_columns.get(column) %}
        {%- set column_alias = column_properties.get("column_alias") %}
        {{ adapter.quote(column) if quote_identifiers else column }} {%- if column_alias is not none %} as {{ adapter.quote(column_alias) if quote_identifiers else column_alias }} {%- endif -%}
        {{',' if not loop.last }}
    {%- endfor %}
    from source
)
select * 
from renamed

{% endmacro %}