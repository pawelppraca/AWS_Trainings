{% macro get_scd_columns(model_name, scd_type=none) %}

    {%- set columns = [] %}

    {%- if scd_type is none -%}
        {% set columns = get_columns_by_meta_property(model_name, 'scd_type') -%}
    {% else %}
        {% set columns = get_columns_by_meta_property_value(model_name, 'scd_type', scd_type) -%}
    {% endif %}

    {{ return(columns) }} 

{% endmacro %}