{% macro get_columns_by_meta_property_value(model_name, property_name='', property_value=none) %}
    
    {# -- Prevent querying of db in parsing mode. #}
    {%- if not execute -%}
        {{ return([]) }}
    {% endif %}

    {% set model = graph.nodes.values()
    | selectattr("resource_type", "equalto", "model")
    | selectattr("name", "equalto", model_name)
    | first %}

    {%- set column_list = [] -%}
    {%- for column, properties in model.columns.items() -%}
            {%- do column_list.append(column) if properties.get('meta').get(property_name) == property_value -%}
    {%- endfor -%}

    {{ return(column_list) }}

{% endmacro %}