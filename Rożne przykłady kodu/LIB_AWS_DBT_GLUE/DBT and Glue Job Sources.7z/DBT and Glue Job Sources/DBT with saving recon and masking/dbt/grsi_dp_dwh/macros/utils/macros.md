{% docs get_source_column_meta_data %}
Retrieves a list of columns for a source from the database.  The following data is returned for each column:

1. name - column name
2. data_type
3. is_string - True | False
4. is_numeric - True | False
5. is_number - True | False
6. Any custom column "meta" properties defined in the sources YML file


Returns a dictionary of column names with each value itself a dictionary of column meta-data properies.
E.g. 'gross_premium': {'name': 'gross_premium', 'data_type': 'numeric(18,2)', 'is_string': False, 'is_numeric': True, 'is_number': True}

{% enddocs %}


{% docs get_current_load_id %}
Retrieves the load id for the current warehouse load.

Returns an int. If no load has been provided for the dbt run, a default value of 0 will be returned.

{% enddocs %}

{% docs get_columns_by_pattern %}
This macro returns an iterable Jinja list of columns for a given [relation](https://docs.getdbt.com/docs/writing-code-in-dbt/class-reference/#relation), (i.e. not from a CTE) that match a pattern.
The macro is based on [dbt_utils.get_filtered_columns_in_relation](https://github.com/dbt-labs/dbt-utils/blob/main/macros/sql/get_filtered_columns_in_relation.sql)

- pattern to match for column names: uses [Python Regex Search](https://docs.python.org/3/library/re.html#re.Pattern.search)
- optionally exclude columns
- the input values are not case-sensitive (input uppercase or lowercase and it will work!)

> Note: The native [`adapter.get_columns_in_relation` macro](https://docs.getdbt.com/reference/dbt-jinja-functions/adapter#get_columns_in_relation) allows you
to pull column names in a non-filtered fashion, also bringing along with it other (potentially unwanted) information, such as dtype, char_size, numeric_precision, etc.

**Args:**

- `from` (required): a [Relation](https://docs.getdbt.com/reference/dbt-classes#relation) (a `ref` or `source`) that contains the list of columns you wish to select from
- `column_pattern` (required): The column name pattern (case insensitive)
- `except` (optional, default=`[]`): The name of the columns you wish to exclude. (case-insensitive)

**Usage:**

```sql
{% raw %}
-- Returns a list of columns that start with a double underscore EXCEPT for "__my_field"
{% set column_names = get_columns_by_pattern(from=ref('your_model'), column_pattern='^\_\_', except=["__my_field"]) %}
...
{% for column_name in column_names %}
    max({{ column_name }}) ... as max_'{{ column_name }}',
{% endfor %}
...
{% endraw %}
```

{% enddocs %}


{% docs is_date_column %}
Returns true / false if the column is of type date.  

The macro extends the functionality of the [column](https://docs.getdbt.com/reference/dbt-classes#column-api) class as there is no equivalent instance method.

**Args:**

- `column` (required): a [column](https://docs.getdbt.com/reference/dbt-classes#column-api)

{% enddocs %}

{% docs get_environment_name %}
Returns the name for the current environment.

{% enddocs %}

{% docs expect_table_non_empty %}

This test checks if table (model) is empty and return fail if table is empty.

**Args**
- `model` (required):  model, table which is tested by the test
- `row_condition` (optional): condition which can be used in WHERE clause

**Usage:**
```
    Example include in _warehouse_properties.yml for table geography and broker

    {% raw %}

    tests:
      - expect_table_non_empty

    {% endraw %}
```

{% enddocs %}


{% docs checksum_for_table %}

Macro checksum_for_table return recordset from table <table_name> include <key_column> and <checksum> column which is calculated based on particular columns set in paramter 'checksum_columns.

**Args:**

- `table_name` (required): name of the table or model
- `key_column` (required): key attribute for the table or model
- `checksum_columns` (required): list of attributes to calculate checksum in List
- `where_condition` (optional): list of where conditions


**Usage:**
```
    See Example of usage of the macro in test checksum_equality.sql 

    {% raw %}

        WITH source_checksum AS (
            {{ checksum_for_table(source, key_source, source_checksum_columns, source_where_condition) }}
        ),

    {% endraw %}
```

{% enddocs %}

{% docs get_columns_by_meta_property %}
Returns an iterable Jinja list of columns for a given model that have the specified meta-data property defined (only checks for existence of the property NOT the value) in yml file.

**Args:**

- `model_name` (required): name of the target model
- `property_name` (required): name of the meta property to search for

**Usage:**

```yaml
{% raw %}
- name: my_model

    columns:
      - name: test_column_1
        meta:
          test_property: 1

      - name: test_column_2
{% endraw %}
```

```
{% raw %}

    get_columns_by_meta_property(
        model_name="my_model",
        property_name="test_property"
    )

{% endraw %}
```

Below is an example of the expected output:

["test_column_1"]

{% enddocs %}

{% docs get_columns_by_meta_property_value %}
Returns an iterable Jinja list of columns for a given model that have the specified meta-data property value defined in yml file.

**Args:**

- `model_name` (required): name of the target model
- `property_name` (required): name of the meta property to search for
- `property_value` (required): property value required for a match

**Usage:**

```yaml
{% raw %}
- name: my_model

    columns:
      - name: test_column_1
        meta:
          test_property: 1

      - name: test_column_2
        meta:
          test_property: 2
{% endraw %}
```

```
{% raw %}

    get_columns_by_meta_property_value(
        model_name="my_model",
        property_name="test_property",
        property_value=2
    )

{% endraw %}
```

Below is an example of the expected output:

["test_column_2"]

{% enddocs %}

