{% macro generate_unknown_member_cte(target_model, 
                                         surrogate_key_column=None,
                                         cte_name="unknown_member",
                                         default_string_value="Unknown",
                                         default_number_value=0,
                                         default_date_value="19000101",
                                         default_boolean_value=False,
                                         exclude_columns=[]) %}

{#-- Prevent querying of db in parsing mode.-#}
{%- if not execute %}
    {{ return('') }}
{% endif -%}

{%- set columns = adapter.get_columns_in_relation(ref(target_model)) -%}
{%- set exclude_columns = exclude_columns | map("lower") | list -%}

{{cte_name | trim}} as (

    select
    {%- if surrogate_key_column is not none %}
        {{ get_unknown_member_key("null") }} as {{surrogate_key_column}},
    {%- endif %}

    {%- for column in columns -%}    
    {%- if column.name.lower() not in exclude_columns %}
        {%- if column.is_string() %}
        '{{ default_string_value[:column.string_size()] }}' as {{column.name}}
        {%- elif column.is_number() %}
        {{ default_number_value }} as {{column.name}}
        {%- elif column.data_type.lower() == "boolean" %}
        {{ default_boolean_value }} as {{column.name}}
        {%- elif is_date_column(column) %}
        '{{ default_date_value }}' as {{column.name}}
        {%- else %}
        --Unknown data type
        null as {{column.name}}
        {%- endif -%}
        {% if not loop.last %},{% endif -%}
    {%- endif -%}
    {%- endfor %}
)

{%- endmacro -%}
