{% macro get_surrogate_key_column(model_name) %}

    {% set columns = get_columns_by_constraint(model_name, 'primary_key') -%}

    {%- if columns|length > 1 -%}

        {%- set error_message = 'Warning: A surrogate key can only be a single column. \
                                This model has a composite primary key with multiple columns {}. \
                                The {}.{} model triggered this warning. \ 
                                '.format(columns, model.package_name, model.name) -%} 

        {%- do exceptions.raise_compiler_error(error_message) -%} 
    
    {%- endif -%}

    {{ return(columns[0]) }} 

{% endmacro %}