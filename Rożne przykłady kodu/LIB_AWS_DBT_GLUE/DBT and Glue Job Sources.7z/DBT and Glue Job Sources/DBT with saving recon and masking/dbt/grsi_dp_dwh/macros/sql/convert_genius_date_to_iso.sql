{% macro convert_genius_date_to_iso(date_to_convert) %}
to_date((
    case
        when nvl({{date_to_convert}}, 0) = 0 then null
        when {{date_to_convert}} % 10000 = 0 then 19000101 + {{date_to_convert}}
        when {{date_to_convert}} % 100 = 0 then 19000001 + {{date_to_convert}}
        when {{date_to_convert}} in (1999999, 999999) then null
        else {{date_to_convert}} + 19000000
    end), 'yyyymmdd')
{% endmacro %}
