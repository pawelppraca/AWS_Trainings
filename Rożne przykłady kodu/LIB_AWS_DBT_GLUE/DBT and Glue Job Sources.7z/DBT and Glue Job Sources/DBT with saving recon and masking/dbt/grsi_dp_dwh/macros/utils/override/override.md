{% docs generate_schema_name %}

This macro overrides the dbt internal macro. 

By default, Dbt will generate the schema name for a model by concatenating the custom schema to the target schema, as in: <target_schema>_<custom_schema>;

This macro replaces the target schema with the custom schema.

Definitions:
    - custom_schema_name: schema provided via dbt_project.yml or model config
    - target.schema: schema provided by the target defined in profiles.yml

{% enddocs %}