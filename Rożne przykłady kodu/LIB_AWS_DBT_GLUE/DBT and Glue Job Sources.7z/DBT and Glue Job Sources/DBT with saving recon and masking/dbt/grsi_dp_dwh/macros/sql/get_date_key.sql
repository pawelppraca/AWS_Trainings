{% macro get_date_key(column) %}
        {% set default_date = get_unknown_member_date().strftime('%Y-%m-%d') %}
        {{- "CAST(TO_CHAR(NVL(" ~ column ~ ", '" ~ default_date ~ "')::DATE,'YYYYMMDD') AS INT)"  -}}
{%- endmacro -%}