{% macro get_columns_by_constraint(model_name, constraint_name) %}
    
    {# -- Prevent querying of db in parsing mode. #}
      {%- if not execute -%}
        {{ return([]) }}
    {% endif %}

    {% set model = graph.nodes.values()
    | selectattr("resource_type", "equalto", "model")
    | selectattr("name", "equalto", model_name)
    | first %}

    {%- set column_list = [] -%}
    {%- for column, properties in model.columns.items() -%}
        {# constraints is a list of dictionaries. #}
        {% for constraint in properties.constraints %}
             {%- do column_list.append(column) if constraint.get('type') == constraint_name -%}      
        {% endfor %}
    {%- endfor -%}

    {{ return(column_list) }}

{% endmacro %}