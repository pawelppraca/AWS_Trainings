{% macro get_source_column_meta_data(source_name, table_name) %}

    {# -- Prevent querying of db in parsing mode. #}
    {%- if not execute -%}
        {{ return({}) }}
    {% endif %}
    
    {% set src = graph.sources.values()
    | selectattr("resource_type", "equalto", "source")
    | selectattr("source_name", "equalto", source_name)
    | selectattr("name", "equalto", table_name)
    | first %}

    {%- if src|length == 0 -%}    

        {%- set error_message = 'Warning: The source [{}.{}] does NOT exist in this project  \
                                The {}.{} model triggered this warning. \ 
                                '.format(source_name, table_name, model.package_name, model.name) -%} 

        {%- do exceptions.raise_compiler_error(error_message) -%} 
    
    {%- endif -%}

    {# This macro returns a dictionary of dictionaries of column meta-data #}
    {%- set source_columns = {} %}

    {%- set cols = adapter.get_columns_in_relation(source(source_name, table_name)) %}
    {%- for col in cols -%}

        {# Add column meta data from the source table.  #}
        {%- set column_properties = {} %}
        {%- do column_properties.update({"name": col.name}) %}
        {%- do column_properties.update({"data_type": col.data_type}) %}
        {%- do column_properties.update({"is_string": col.is_string()}) %}
        {%- do column_properties.update({"is_numeric": col.is_numeric()}) %}
        {%- do column_properties.update({"is_number": col.is_number()}) %}

        {# Add any custom meta-data properties defined in the YML file for the source table.  #}
        {%- set column_config_properties = src.columns.get(col.name) %}

        {%- if column_config_properties is not none -%}
            {%- for meta_property in column_config_properties.meta.keys() -%}
                {%- do column_properties.update({ meta_property: column_config_properties.meta.get(meta_property) }) %}
            {%- endfor %}
        {% endif %}

        {% do source_columns.update({ col.name: column_properties }) %}
        
    {%- endfor %}

   {{ return(source_columns) }} 
    

{% endmacro %}