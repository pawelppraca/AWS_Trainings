{% macro get_rowcounts(table_name) %}

    {#-- Prevent querying of db in parsing mode.-#}
    {%- if not execute %}
        {{ return('') }}
    {% endif -%}

    {% set count_query %}
        SELECT count(*) row_count
        FROM  {{ table_name }}
    {% endset %}   

    
    {% set rowcount_results = run_query(count_query) %}

    {% set table_row_count = rowcount_results.columns[0].values()[0] %}
    
    {{ return(table_row_count) }} 


{% endmacro %}
