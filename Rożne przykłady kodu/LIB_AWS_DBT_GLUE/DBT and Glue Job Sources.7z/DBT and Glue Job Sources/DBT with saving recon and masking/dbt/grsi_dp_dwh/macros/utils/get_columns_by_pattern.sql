 {%macro get_columns_by_pattern(from, column_pattern, except=[]) %}

    {#-- Prevent querying of db in parsing mode.-#}
    {%- if not execute %}
        {{ return('') }}
    {% endif -%}

    {%- set include_cols = [] %}
    {% set re = modules.re %}

    {%- set cols = adapter.get_columns_in_relation(from) -%}
    {%- set except = except | map("lower") | list %}
    {%- for col in cols -%}
        {% set is_match = re.search(column_pattern, col.column, re.IGNORECASE) %}
        {%- if is_match %}
             {%- if col.column|lower not in except -%}
                {% do include_cols.append(col.column) %}
            {%- endif %}
        {%- endif %}
    {%- endfor %}

    {# log("\n\List: \n\n" ~ include_cols, info=true) #}

    {{ return(include_cols) }}

{% endmacro %}
