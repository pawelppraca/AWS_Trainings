{% macro is_pii_column(model_name, column_name) %}
    
    {# This macro checks if column should be PII masked #}

    {#-- Prevent querying of db in parsing mode.-#}
    {%- if not execute %}
        {{ return('') }}
    {% endif -%}

    {% set pii_columns = get_pii_columns(model_name) -%}
    
    {% set result = false %}

    {% if column_name in pii_columns %}
        {% set result = true %}
    {% endif %}

    {{ return(result) }}
{% endmacro %}