
{% macro log_staging_model_columns(target_model, staging_model, selected_columns) %}

     {%- if execute -%}

        {# {{ print("Target Model: {0}, Staging Model: {1}, Columns: {2}".format(target_model, staging_model, selected_columns))}} #}

        {% set re = modules.re %}

        {% set is_staging_model = re.match("staging_", staging_model, re.IGNORECASE) %}
        {%- if is_staging_model %}

            {% set column_list = [] %}
            {% if selected_columns is none or selected_columns|length <= 0 %}

                {% set column_list = get_columns_by_pattern(ref(staging_model), "[\s\S]*") %} 
            
            {% else %}

                {% set column_list = selected_columns.copy() %}

            {% endif %}

            {% call statement('insert', fetch_result=false, auto_begin=true) %}
                {# sql query is wrapped in a macro  #}
                {{ meta_data_insert_log_query(target_model, staging_model, column_list) }}
            {% endcall %}

            {# verify the results, print to stdout #}
            {# {% set results = run_query('SELECT * FROM transform.staging_meta_data') %} 
            {{ results.print_table() }} #}

        {% endif %}

    {% endif %}

{% endmacro %}

{% macro meta_data_insert_log_query(target_model, staging_model, selected_columns) %}

    create table if not exists transform.staging_meta_data ( 
        id int identity(1,1),
        target_model varchar(512),
        staging_table varchar(512),
        staging_column_name varchar(512),
        log_date_time timestamp DEFAULT SYSDATE 
    );

    insert into transform.staging_meta_data (target_model, staging_table, staging_column_name) values
    {%- for column in selected_columns %}
        ('{{ target_model | trim }}', '{{ staging_model | trim }}', '{{ column | trim }}')
    {%- if not loop.last %},{%- endif -%}
    {%- endfor %}
    ;

{% endmacro %}
