{% macro get_unknown_member_key(column) %}
        {{- "COALESCE(" ~ column ~ ", -1)"  -}}
{%- endmacro -%}