{%- test expect_table_non_empty(model, row_condition=None) -%}
    {{ default__test_expect_table_non_empty(model, row_condition) }}
{% endtest %}


{%- macro default__test_expect_table_non_empty(model, row_condition) -%}
WITH
    limited AS (
        SELECT 1
        FROM {{ model }}
        {%- if row_condition %} WHERE {{ row_condition }} {% endif %}
        LIMIT 1
    ),
    grouped_expression AS (SELECT COUNT(*) as expression FROM limited),
    validation_errors AS (SELECT * FROM grouped_expression WHERE NOT (expression > 0))

SELECT *
FROM validation_errors

{%- endmacro -%}