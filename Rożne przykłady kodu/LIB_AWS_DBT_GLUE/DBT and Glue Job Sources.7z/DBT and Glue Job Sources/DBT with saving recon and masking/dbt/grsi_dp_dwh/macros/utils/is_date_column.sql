{%- macro is_date_column(column) -%}
  {{ return(adapter.dispatch('is_date_column')(column)) }}
{%- endmacro -%}

{% macro default__is_date_column(column) %}
          
  {%- set is_date_flag = false %}

  {% set re = modules.re %}
  {%- if column -%}
    {% set is_date_match = re.search('date', column.data_type, re.IGNORECASE) %}
    {% set is_timestamp_match = re.search('timestamp', column.data_type, re.IGNORECASE) %}
    {%- if is_date_match or is_timestamp_match %}
      {%- set is_date_flag = true -%}
    {%- endif %}
  {%- endif %}

  {{ return(is_date_flag) }}

{% endmacro %}

{% macro redshift__is_date_column(column) %}

  {%- set date_types = ["DATE","TIMESTAMP","TIMESTAMP WITHOUT TIME ZONE","TIMESTAMPZ","TIMESTAMP WITH TIME ZONE"] %}
  {%- set is_date_flag = false %}
  
  {%- if column -%}
    {%- if column.data_type.upper() in date_types -%}
      {%- set is_date_flag = true -%}
    {%- endif %}
  {%- endif %}

  {{ return(is_date_flag) }}

{% endmacro %}


