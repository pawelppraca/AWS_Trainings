{% macro redshift_pii_masking_policy_attach(schema_name, table_name, column_name, role_name, priority) %}

    {% set masking_policy_name = table_name ~'_'~ column_name ~ '_unmasking' %}
    {% if role_name | lower == "public" %}
        {% set masking_policy_name = masking_policy_name | replace ('_unmasking','_masking') %}
    {% endif %}

    {% set table_name = schema_name ~'.'~ table_name %}


    {% if is_pii_masking_policy_attached(masking_policy_name,table_name) == false %} 
        {# Attaching Masking POLICY #}
        ATTACH MASKING POLICY {{ masking_policy_name }}
            ON {{ table_name }} ( {{ column_name }} )
            {# USING ( insured_code , {{ column_name }}) #}
            USING ( {{ column_name }})
        {% if role_name | lower == "public" -%}
            TO PUBLIC
        {% elif role_name[0:4] == "aad:" -%}  
            TO ROLE {{ '"' ~ role_name ~ '"' }} 
        {% else -%}
            TO {{ '"' ~ role_name ~ '"'}} 
        {% endif -%}  
        PRIORITY {{ priority }};
 
    {% endif -%}  

{% endmacro %}
