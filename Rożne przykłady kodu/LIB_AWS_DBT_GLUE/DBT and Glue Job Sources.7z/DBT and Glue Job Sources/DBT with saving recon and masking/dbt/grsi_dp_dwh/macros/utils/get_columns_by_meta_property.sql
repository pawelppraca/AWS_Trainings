{% macro get_columns_by_meta_property(model_name, property_name='') %}
    
    {# -- Prevent querying of db in parsing mode. #}
    {%- if not execute -%}
        {{ return([]) }}
    {% endif %}

    {% set model = graph.nodes.values()
    | selectattr("resource_type", "equalto", "model")
    | selectattr("name", "equalto", model_name)
    | first %}

    {%- set column_list = [] -%}
    {%- for column, properties in model.columns.items() -%}
            {%- do column_list.append(column) if properties.get('meta').get(property_name) is not none -%}
    {%- endfor -%}

    {{ return(column_list) }}

{% endmacro %}