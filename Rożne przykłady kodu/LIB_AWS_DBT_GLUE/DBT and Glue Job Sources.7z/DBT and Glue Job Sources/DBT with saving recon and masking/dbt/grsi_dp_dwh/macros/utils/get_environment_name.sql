{% macro get_environment_name() %}

    {{ return(env_var('ENVIRONMENT', "NOT_DEFINED")) }}

{% endmacro %}