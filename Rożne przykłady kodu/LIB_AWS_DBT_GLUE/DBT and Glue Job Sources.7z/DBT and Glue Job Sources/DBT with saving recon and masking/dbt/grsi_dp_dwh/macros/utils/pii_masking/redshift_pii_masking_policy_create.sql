{% macro redshift_pii_masking_policy_create(schema_name, table_name, column_name, role_name, mask, data_type) %}

    {% set masking_policy_name = table_name ~'_'~ column_name ~ '_unmasking' %}
    {% if role_name | lower == "public" %}
        {% set masking_policy_name = masking_policy_name | replace ('_unmasking','_masking') %}
    {% endif %}

    {% set table_name = schema_name ~'.'~ table_name %}

    {#  Checking if Masking Polisy is Attached #}
    {% if is_pii_masking_policy_exists (masking_policy_name,table_name) == false %}
      
        {# Creating Masking Policy #}
        CREATE MASKING POLICY {{ masking_policy_name }} 
        {# WITH ( insured_code VARCHAR(256)  ,  {{ column_name }} #}
        WITH ( {{ column_name }}
            {% if data_type | lower == "varchar" -%}
                VARCHAR(256) 
            {% elif data_type | lower == "number"-%}
                INT 
            {% elif data_type | lower == "date"-%}
                DATE 
            {% endif  -%}
        )
        USING
        (
            {% if mask  == ""-%}
                {{ column_name }}
            {% elif data_type | lower == "varchar" -%}
                {{ "'" ~ mask ~ "' :: TEXT" }} 
            {% elif data_type | lower == "number" -%}
                {{  mask ~ " :: INT" }} 
            {% elif data_type | lower == "date" -%}
                {{  "'" ~ mask ~ "' :: DATE"  }} 
            {% endif -%}  

        ) ;

    {% endif %}

{% endmacro %}
