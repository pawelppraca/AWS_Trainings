{% docs grant_perms_on_schemas %}
Generate GRANT statements for schema-level and database object permissions for the specified security group.

**Args:**

- `schemas` (required): a list of schemas
- `group` (required): database security group name
- `schema_perms` (required): list of schema permissions to be granted
- `table_perms` (required): list of table permissions to be granted

**Usage:**
```
{% raw %}

grant_perms_on_schemas(['dwh'], 'readwrite', schema_perms=['usage', 'create'], table_perms=['select', 'update', 'insert', 'delete', 'drop', 'alter'])

{% endraw %}
```
Below is an example of the expected output:

```sql
{% raw %}
grant usage, create on schema dwh to group readwrite;
grant select, update, insert, delete, drop, alter on all tables in schema dwh to group readwrite; 
{% endraw %}
```

{% enddocs %}

{% docs grant_select_on_schemas %}
Generates GRANT statements for granting SELECT permission on all tables to the specified security group.

**Args:**

- `schemas` (required): a list of schemas
- `group` (required): database security group name

{% enddocs %}

{% docs grant_readwrite_on_schemas %}
Generates GRANT statements for granting all DDL (CREATE/ALTER/DROP) and DML (INSERT/UPDATE/DELETE/SELECT) permissions on all tables to the specified security group.

**Args:**

- `schemas` (required): a list of schemas
- `group` (required): database security group name

{% enddocs %}

{% docs get_surrogate_key_column %}
Returns the name of the primary key column for a given model as defined in yml file.

> Note: The macro will raise an error for composite primary keys; surrogate keys must be a single column.

**Args:**

- `model_name` (required): name of the target model

**Usage:**

```yaml
{% raw %}
- name: sample_dimension

    columns:
      - name: dim_key
        data_type: bigint
        constraints:
          - type: not_null
          - type: primary_key
            warn_unenforced: false

      - name: my_attribute
        data_type: varchar

{% endraw %}
```

```
{% raw %}

    get_surrogate_key_column(model_name="sample_dimension")

{% endraw %}
```

Below is an example of the expected output:

"dim_key"

{% enddocs %}

{% docs get_scd_columns %}
Returns an iterable Jinja list of column names for a slowly-chaning dimension model that have the <scd_type> meta property defined in yml file.

If `None` is specified for <scd_type> then ALL SCD columns are returned. 

**Args:**

- `model_name` (required): name of the target model
- `scd_type` (optional): 1 = SCD type 1, 2 = SCD type 2

**Usage:**

```yaml
{% raw %}
- name: my_scd

    columns:
      - name: my_SK
        data_type: bigint
        constraints:
          - type: not_null
          - type: primary_key
            warn_unenforced: false

      - name: claim_key
        meta:
          scd_type: 1

      - name: status
        meta:
          scd_type: 2
{% endraw %}
```

```
{% raw %}

    get_scd_columns(
        model_name="my_model",
        scd_type=None,
    )

{% endraw %}
```

Below is an example of the expected output:

["claim_key", "status"]

{% enddocs %}

