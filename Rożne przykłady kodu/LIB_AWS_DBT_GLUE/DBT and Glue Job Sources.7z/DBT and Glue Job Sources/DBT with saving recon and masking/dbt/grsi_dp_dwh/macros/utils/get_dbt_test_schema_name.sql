{% macro get_dbt_test_schema_name() %}

{{ return("staging_test") }}

{% endmacro %}