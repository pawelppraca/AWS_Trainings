{%- macro grant_perms_on_schemas_to_role(schemas, role_name, schema_perms, table_perms) -%}
 
    {%- if not execute -%}
        {{ return('') }}
    {%- endif -%}
    {# Prevent the macro running when no models are being executed e.g. running tests #}
    {%- if schemas is none or schemas|length <= 0 -%}
        {{ return('') }}
    {%- endif -%}
 

    {%- set schema_perm_sql = schema_perms | join(', ') | lower %}
    {%- set table_perm_sql = table_perms | join(', ') | lower %}
 
    {% for schema in schemas %}
        {% do log("Granting schema permissions: [" ~ schema_perm_sql ~ "] on schema: [" ~ schema ~ "] to role: [" ~ role_name ~ "]...", info=True) %} 
        {% do log("Granting object-level permissions: [" ~ table_perm_sql ~ "] on ALL tables in schema: [" ~ schema ~ "] to role: [" ~ role_name ~ "]...", info=True) %} 
        grant {{ schema_perm_sql }} on schema {{ schema }} to ROLE "{{ role_name }}";
        grant {{ table_perm_sql }} on all tables in schema {{ schema }} to ROLE "{{ role_name }}";
        {% do log("Permissions successfully granted on schema: [" ~ schema ~ "]", info=True) %} 
    {% endfor %} 
 
{%- endmacro -%}

{%- macro grant_perms_on_schemas_to_group(schemas, group_name, schema_perms, table_perms) -%}

    {%- if not execute -%}
        {{ return('') }}
    {%- endif -%}
        
    {# Prevent the macro running when no models are being executed e.g. running tests #}
    {%- if schemas is none or schemas|length <= 0 -%}
        {{ return('') }}
    {%- endif -%}
    
    {%- set schema_perm_sql = schema_perms | join(', ') | lower %}
    {%- set table_perm_sql = table_perms | join(', ') | lower %}

    {% for schema in schemas %}
        {% do log("Granting schema permissions: [" ~ schema_perm_sql ~ "] on schema: [" ~ schema ~ "] to group: [" ~ group_name ~ "]...", info=True) %} 
        {% do log("Granting object-level permissions: [" ~ table_perm_sql ~ "] on ALL tables in schema: [" ~ schema ~ "] to group: [" ~ group_name ~ "]...", info=True) %} 
        grant {{ schema_perm_sql }} on schema {{ schema }} to GROUP {{ group_name }};
        grant {{ table_perm_sql }} on all tables in schema {{ schema }} to GROUP {{ group_name }};
        {% do log("Permissions successfully granted on schema: [" ~ schema ~ "]", info=True) %} 
    {% endfor %} 

{%- endmacro -%} 
 
 {%- macro grant_read_only_to_group(schemas, group) -%}
    {%- set target_environments = ['dev','test'] %}
    {%- set current_environment = get_environment_name() | lower -%}

    {%- if current_environment in target_environments -%}
        {{ return(grant_perms_on_schemas_to_group(schemas, group, schema_perms=['usage'], table_perms=['select'])) }} 
    {%- else -%}
        {% do log("INFO: Grant permissions on schemas is NOT enabled for this environment [" ~ current_environment ~ "].", info=True) %} 
    {%- endif %}

{%- endmacro -%}
 
 {%- macro grant_readwrite_to_group(schemas, group) -%}
    {%- set target_environments = ['dev','test'] %}
    {%- set current_environment = get_environment_name() | lower -%}

    {%- if current_environment in target_environments -%}
        {{ return(grant_perms_on_schemas_to_group(schemas, group, schema_perms=['usage', 'create'], table_perms=['select', 'update', 'insert', 'delete', 'drop', 'alter'])) }} 
    {%- else -%}
        {% do log("INFO: Grant permissions on schemas is NOT enabled for this environment [" ~ current_environment ~ "].", info=True) %} 
    {%- endif %}
{%- endmacro -%} 
 
{%- macro grant_read_only_to_ad_group(target_schemas) -%}
    {%- set current_environment = get_environment_name() | lower -%}
    {%- set all_schemas = ['transform', 'dwh', 'reporting'] -%}

    {%- if current_environment == 'production' -%}
        {%- set rs_role = 'aad:ggs-reds-dataplatform-redshift-pro' -%}
    {%- else -%}
        {%- set rs_role = 'aad:ggs-reds-dataplatform-redshift-npro' -%}
    {%- endif %}
 
    {%- if current_environment in ['dev', 'test'] -%}
        {{ return(grant_perms_on_schemas_to_role(target_schemas, rs_role, schema_perms=['usage'], table_perms=['select'])) }} 
    {%- elif current_environment in ['qa','production'] %}
        {{ return(grant_perms_on_schemas_to_role(all_schemas, rs_role, schema_perms=['usage'], table_perms=['select'])) }} 
    {%- else -%}
        {% do log("INFO: Grant permissions on schemas is NOT enabled for this environment [" ~ current_environment ~ "].", info=True) %} 
    {%- endif %}
{%- endmacro -%}

 
{%- macro grant_readwrite_to_ad_group(target_schemas) -%}
    {%- set current_environment = get_environment_name() | lower -%}
    {%- set all_schemas = ['transform', 'dwh', 'reporting'] -%}
    {%- set rs_role = 'aad:ggs-reds-dataplatform-redshift-np' -%}
 
    {%- if current_environment in ['dev', 'test'] -%}
        {{ return(grant_perms_on_schemas_to_role(target_schemas, rs_role, schema_perms=['usage', 'create'], table_perms=['select', 'update', 'insert', 'delete', 'drop', 'alter'])) }} 
    {%- elif current_environment in ['qa'] %}
        {{ return(grant_perms_on_schemas_to_role(all_schemas, rs_role, schema_perms=['usage', 'create'], table_perms=['select', 'update', 'insert', 'delete', 'drop', 'alter'])) }} 
    {%- else -%}
        {% do log("INFO: Grant permissions on schemas is NOT enabled for this environment [" ~ current_environment ~ "].", info=True) %} 
    {%- endif %}
{%- endmacro -%}