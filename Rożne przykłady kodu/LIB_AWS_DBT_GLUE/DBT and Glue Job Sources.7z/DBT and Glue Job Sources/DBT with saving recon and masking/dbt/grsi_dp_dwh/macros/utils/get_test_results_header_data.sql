-- depends_on: {{ ref('dbt_recon_results') }}

{% macro get_test_results_header_data(table_name, log_query=0) %}

    {#-- Prevent querying of db in parsing mode.-#}
    {%- if not execute %}
        {{ return('') }}
    {% endif -%}

    {% set result_summary_query %}
        SELECT top 1
            header_key,
            header_time_stamp,
            generated_date,
            fail_rows,
            execution_time,
            replace(replace(detail_table_name,schema_name+'.',''),database_name+'.','') AS table_name,
            result_id
        FROM  {{ ref("dbt_recon_results") }}
        WHERE lower(replace(replace(detail_table_name,schema_name+'.',''),database_name+'.','')) = lower(replace({{"'" ~ table_name ~"'" }}, '_details',''))  
        ORDER BY header_key desc
    {% endset %}

    {% if log_query == 1 %}
        {{ log(result_summary_query, info=True) }} 
      
    {% endif %}  

    {% set recon_summary_results = run_query(result_summary_query) %}

    {{ return(recon_summary_results) }} 

{% endmacro %}
