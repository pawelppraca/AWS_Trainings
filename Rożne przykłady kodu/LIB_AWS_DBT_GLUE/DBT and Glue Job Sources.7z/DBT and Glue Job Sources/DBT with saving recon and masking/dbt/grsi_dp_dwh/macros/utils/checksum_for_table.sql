{% macro checksum_for_table(table_name, key_column, field_list, where_condition) %}

    SELECT
        {{ key_column }} AS key_id,
        {{ dbt.hash(dbt.concat(field_list)) }}
        {{ " AS checksum"}}
    FROM {{ table_name }} 
    --WHERE Clause
    {% if where_condition %}
        {{ "WHERE " ~ where_condition}}
    {% endif %}

{% endmacro %}
