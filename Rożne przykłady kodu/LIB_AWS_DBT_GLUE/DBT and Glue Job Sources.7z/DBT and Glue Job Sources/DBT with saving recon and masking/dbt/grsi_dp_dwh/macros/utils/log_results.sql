
-- depends_on: {{ ref("dbt_tests_results") }}
{% macro log_results(results) %}

  {% if execute %}

{# Here shoud be check if results are related to tests only  - TBD #}
    {%- set parsed_results = parse_dbt_results(results) -%}
    {%- if parsed_results | length  > 0 -%}
            {%- for parsed_result_dict in parsed_results -%}
                {% set line -%}  {# it is only to show data parsed from results object #}
                    result_id:     {{ parsed_result_dict.get('result_id') }}
                    invocation_id: {{ parsed_result_dict.get('invocation_id') }}
                    unique_id:     {{ parsed_result_dict.get('unique_id') }}
                    database_name: {{ parsed_result_dict.get('database_name') }}
                    schema_name:   {{ parsed_result_dict.get('schema_name') }}
                    test_name:     {{ parsed_result_dict.get('test_name') }}
                    status:        {{ parsed_result_dict.get('status') }}
                    execution_time {{ parsed_result_dict.get('execution_time') }}
                    message:       {{ parsed_result_dict.get('message') }}
                    fail_rows:     {{ parsed_result_dict.get('fail_rows') }}
                    detail_table_name:  {{ parsed_result_dict.get('detail_table_name') }}
                    generated_date:{{ parsed_result_dict.get('generated_at') }}
                {%- endset %}
            {%- endfor -%}
            {# {{ log(line, info=True) }}  //show data inserted to recon summary table reconciliation.dbt_test_results #}

            {% set insert_dbt_results_query -%}
                insert into reconciliation.dbt_test_results
                    (
                        result_id,
                        invocation_id,
                        unique_id,
                        database_name,
                        schema_name,
                        test_name,
                        status,
                        execution_time,
                        message,
                        fail_rows, 
                        detail_table_name,
                        generated_date
                ) values
                    {%- for parsed_result_dict in parsed_results -%}
                        (
                            '{{ parsed_result_dict.get('result_id') }}',
                            '{{ parsed_result_dict.get('invocation_id') }}',
                            '{{ parsed_result_dict.get('unique_id') }}',
                            '{{ parsed_result_dict.get('database_name') }}',
                            '{{ parsed_result_dict.get('schema_name') }}',
                            '{{ parsed_result_dict.get('test_name') }}',
                            '{{ parsed_result_dict.get('status') }}',
                            '{{ parsed_result_dict.get('execution_time') }}',
                            '{{ parsed_result_dict.get('message') }}',
                            '{{ parsed_result_dict.get('fail_rows') }}', 
                            '{{ parsed_result_dict.get('detail_table_name') }}',
                            '{{ parsed_result_dict.get('generated_at') }}'
                        ) {{- "," if not loop.last else "" -}}
                    {%- endfor -%}
            {%- endset -%}
            {# {{ log(insert_dbt_results_query, info=True) }} -- It shows query to add records to reconciliation.dbt_test_results table  #}
            {% do run_query(insert_dbt_results_query) %} 

    {%- endif -%}
  {% endif %}

 {{ return ('') }}

{% endmacro %}