{% macro default__hash(field) -%}
    sha(cast({{ field }} as {{ api.Column.translate_type('string') }}))
{%- endmacro %}