{% macro generate_sql_in_condition(column_name, value_list, sql_operator='in', quote_values=true, convert_to_upper_case=true) %}
        {%- if quote_values -%}
            {%- set csv_string = '\'' + value_list|join('\', \'') + '\'' -%} 
        {%- else -%}
            {%- set csv_string = value_list|join(',') -%}
        {%- endif -%}

        {%- if convert_to_upper_case -%}
            {{- "UPPER(" ~ column_name ~ ") " ~ sql_operator ~ " (" ~ csv_string|upper ~ ")" -}}
        {%- else -%}
            {{- column_name ~ " " ~ sql_operator ~ " (" ~ csv_string ~ ")" -}}
        {%- endif -%}  
{%- endmacro -%}