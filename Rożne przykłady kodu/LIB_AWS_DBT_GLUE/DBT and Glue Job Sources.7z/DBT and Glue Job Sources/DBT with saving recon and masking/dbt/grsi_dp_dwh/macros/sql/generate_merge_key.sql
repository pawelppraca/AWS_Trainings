{% macro generate_merge_key(field_list, preserve_nulls=False, default_value="UNKNOWN") %}
{%- set fields = [] -%}
{%- set divider = "|" -%}

{%- if preserve_nulls -%}
    {%- set default_value = "null" -%} 
{%- else -%}
     {%- set default_value = "'" ~ default_value ~ "'" -%}
{%- endif -%}

{%- for field in field_list -%}

    {%- do fields.append(
        "coalesce(nullif(trim(" ~ field ~ "), ''), " ~ default_value ~ ")"
    ) -%}

    {%- if not loop.last %}
        {%- do fields.append("|| '" ~ divider ~ "' ||") -%}
    {%- endif -%}

{%- endfor -%}

{{ "cast(upper(" ~ fields|join(' ') ~ ") as varchar(255))" }}
{% endmacro %}
