{% macro create_pii_masking_policies(role_name_list, priority) %}
   
   {# run by post_hook of the model - to generate Redshift SQL CODE to create masking Policy for columns seta as meta “pii” : ‘yes’ #}
   
   {% if execute %}
  
       {# get pii columns in the relation #}
       {% set model_cols = adapter.get_columns_in_relation(this) %} 
       {% set table_name = this | replace (this.database ~ '.','') %}
       {% set table_name = table_name | replace (this.schema ~'.', '')  %}
       {% set schema_name = this.schema  %}
       
       {% set pii_columns = get_pii_columns(table_name) -%} 
      
        {# Create variables for SQL Code #}
        {% set masking_policy_code = namespace(value='') %}
        {% set masking_policy_code_part = namespace(value='') %}

        {# Loop for every column in the model to create and drop Masking Policy  #}
        {% for col in model_cols %}

            {% if is_pii_column(table_name, col.name) %} 
                {# If column is set for PII masking there are created masking policy for public and 1 unmasking policy for particular role #}

                {# Creating Masking Policies for PUBLIC#}
                {% set masking_policy_code_part.value  %}
                    {% if col.is_string() %} {#  Creating Policy for text values #}
                        {{ redshift_pii_masking_policy_create(schema_name, table_name, col.name, 'public', 'XXXXXXX', 'varchar') }}
                        {{ redshift_pii_masking_policy_attach(schema_name, table_name, col.name, 'public', priority) }}
                    {% elif col.is_number() %}  {#  Creating masking policy for numbers #}
                        {{ redshift_pii_masking_policy_create(schema_name, table_name, col.name, 'public', '-1', 'number') }}
                        {{ redshift_pii_masking_policy_attach(schema_name, table_name, col.name, 'public', priority) }}
                    {% elif is_date_column(col) %} {#  Creating masking policy for date and timestamp #}
                        {{ redshift_pii_masking_policy_create(schema_name, table_name, col.name, 'public', '7/4/1776', 'date') }}
                        {{ redshift_pii_masking_policy_attach(schema_name, table_name, col.name, 'public', priority) }}
                    {% endif %}
                {% endset %} {# end of set masking_policy_code_part #}

                {% set masking_policy_code.value = masking_policy_code.value ~ masking_policy_code_part.value %}
                {% set masking_policy_code_part.value = '' %}

                {% set masking_policy_code_part.value  %}
                
                    {# Creating UNMasking Policies #}
                    {% if col.is_string() %} {#  Creating Policy for text values #}
                        {{ redshift_pii_masking_policy_create(schema_name, table_name, col.name, role_name, '', 'varchar') }}
                    {% elif col.is_number() %}  {#  Creating masking policy for numbers #}
                        {{ redshift_pii_masking_policy_create(schema_name, table_name, col.name, role_name, '', 'number') }}
                    {% elif is_date_column(col) %} {#  Creating masking policy for date and timestamp #}
                        {{ redshift_pii_masking_policy_create(schema_name, table_name, col.name,  role_name, '', 'date') }}
                    {% endif %}

                {% endset %} {# end of set masking_policy_code #}

                {% set masking_policy_code.value = masking_policy_code.value ~ masking_policy_code_part.value %}
                {% set masking_policy_code_part.value = '' %}


                {% for role_name in role_name_list %}
                    {% set masking_policy_code_part.value  %}
                    
                        {# Creating UNMasking Policies #}
                        {% if col.is_string() %} {#  Creating Policy for text values #}
                            {{ redshift_pii_masking_policy_attach(schema_name, table_name, col.name, role_name, priority+10) }}
                        {% elif col.is_number() %}  {#  Creating masking policy for numbers #}
                            {{ redshift_pii_masking_policy_attach(schema_name, table_name, col.name, role_name, priority+10) }}
                        {% elif is_date_column(col) %} {#  Creating masking policy for date and timestamp #}
                            {{ redshift_pii_masking_policy_attach(schema_name, table_name, col.name,  role_name, priority+10) }}
                        {% endif %}

                    {% endset %} {# end of set masking_policy_code #}

                    {% set masking_policy_code.value = masking_policy_code.value ~ masking_policy_code_part.value %}
                    {% set masking_policy_code_part.value = '' %}

                {% endfor %}

            {% else %}
                {# Add macro to Drop Masking Policy for columns which has masking but there are no longer pii #}
            {% endif %}

        {% endfor %}


        {% do dbt_utils.log_info("masking_policy_code : " ~  masking_policy_code.value ) %} 

        {{ masking_policy_code.value }}

   {% endif %}
  
   select 1=1
  
{% endmacro %}