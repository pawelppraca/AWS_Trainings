{% docs generate_staging_model %}
Used to auto-generate the SQL for staging models.

To rename a column in the staging model add a column "meta" property called "column_alias" in the source YML file:


```yml
 tables:
      - name: users
      
        description: "Users table."
        columns:
          - name: id
            meta:
              column_alias: user_id
```

Below is an example of the expected output:

```sql
{% raw %}
with 
    source as (
        select * from {{ source(source_name, table_name) }}
    ),

    renamed as (
        
        select 
            id as my_alias
        from source
    )
select * from renamed
{% endraw %}
```

{% enddocs %}


{% docs generate_merge_key %}
This macro generates a merge key by concatenating a list of column values with the pipe delimiter.

Below is an example of the expected usage and compiled SQL output:

```sql
{% raw %}
{{ generate_merge_key(["__source_system_code", "claim_number"[,...]]) }}

--output
cast(upper(coalesce(nullif(trim(__source_system_code), ''), null) || '|' || coalesce(nullif(trim(claim_number), ''), null)) as varchar(255))
{% endraw %}
```

{% enddocs %}


{% docs generate_cte %}
This macro generates the SQL code for one or more ctes (common table expressions).

- Each cte that is generated will return the columns provided in the dictionary item. If no columns are provided, it will return all (*) from the table.
- By default, all model meta-data columns that are prefixed with a double underscore are included

**Args:**

- `dict_list` (required): a list of dictionary items with the following properties - table (string), alias (string) and columns (optional list of strings of column names).  
- `include_meta_data_columns` (optional, default=`True`): Specify whether to include all meta-data columns that are prefixed with a double underscore.
- `override_error_check` (optional, default=`False`): By default, an explicit list of columns should be specified when referencing staging models (this is so a list of columns from the data sources that are used in the warehouse can be logged via the macro) otherwise an error will be raised.  However, this check is unnecessary if all of the columns are being selected and it would be cumbersome for wide tables.  By setting the flag to `True` you can turn off the error check.

**Usage:**

```sql
{% raw %}
{{
    generate_cte(
        [
            {
                "table": "staging_claim_center_cc_contact",
                "alias": "contacts",
                "columns": [
                    "id",
                    "publicid",
                    "firstname",
                    "lastname"
                ],
            },
            {"table": "staging_claim_center_cc_user", "alias": "users"},
        ], include_meta_data_columns = True
    )
}}

--output
with contacts as (
    
    select
        id,
        publicid,
        firstname,
        lastname,
        __extraction_date_time,
        __source_system_code,
        __load_id
    from grsi_dp_eu_test.transform.staging_claim_center_cc_contact

), users as (
    
    select *
    from grsi_dp_eu_test.transform.staging_claim_center_cc_user

)
{% endraw %}
```

{% enddocs %}

{% docs convert_genius_date_to_iso %}
This macro generates the SQL code for converting a genius date to ISO format yyyymmdd

- Contains logic to handle missing dates
- Contains logic to handle invalid dates
- Contains logic to handle incomplete dates

**Args:**

- `date_to_convert` (required): an AS400 date to be converted

**Usage:**

```sql
{% raw %}
{{ 
    convert_genius_date_to_iso("cte_name.date_column") 
}} as my_converted_date,

--output
to_date((
    case when nvl(cte_name.date_column, 0) = 0 then null
        when cte_name.date_column % 10000 = 0 then 19000101 + cte_name.date_column
        when cte_name.date_column % 100 = 0 then 19000001 + cte_name.date_column
        when cte_name.date_column in (1999999, 999999) then null
        else cte_name.date_column + 19000000
    end), 'yyyymmdd')
 as my_converted_date,
{% endraw %}
```
{% enddocs %}


{% docs generate_unknown_member_cte %}
Generates the SQL code to insert a dummy member record into the target model as a CTE.  

- The macro will generate dummy values based on the target model column data types.
- Optionally, add a surrogate key column at index 0

**Args:**

- `target_model` (required): name of the target model
- `surrogate_key_column` (optional, default=`None`): name of the surrogate key column to be added to the SELECT query column list
- `cte_name` (optional, default=`unknown_member`): name of the common table expression
- `default_string_value` (optional, default=`Unknown`): default value assigned for text columns
- `default_number_value` (optional, default=`0`): default value assigned for numerical columns
- `default_date_value` (optional, default=`19000101`): default value assigned for date columns
- `default_boolean_value` (optional, default=`false`): default value assigned for boolean columns
- `exclude_columns` (optional, default=`[]`): The name of the columns you wish to exclude. (case-insensitive)

**Usage:**

```sql
{% raw %}
{{
    generate_unknown_member_cte(
        target_model="dim_person",
        surrogate_key_column="person_key"
    )
}},

--output
unknown_member as (

    select
        COALESCE(null, -1) as person_key,
        'Unknown' as first_name,
        'Unknown' as last_name,
        '19000101' as date_of_birth,
        0 as age,
        false as is_married
)
{% endraw %}
```

{% enddocs %}

{% docs get_unknown_member_key %}

Returns the default surrogate key value for the "unknown member" row added to dimension tables to represent missing attributes in fact rows.

```sql
SELECT * 
FROM dwh.dim_table 
WHERE dim_table_key = =-1;
```

{% enddocs %}

{% docs generate_sql_in_condition %}
This macro generates a SQL statement to test if an expression matches any value in a list of values.

**Args:**

- `column_name` (required): name of column
- `value_list` (required): list of values
- `sql_operator` (optional, default=`in`): sql operator: 'in' or 'not in'
- `quote_values` (optional, default=`true`): escape the list of values with single quotes
- `convert_to_upper_case` (optional, default=`true`): convert all the values to upper case strings

Below is an example of the expected usage and compiled SQL output:

```sql
{% raw %}
{{ generate_sql_in_condition("cost_category_code", ["GSC","MLE","MLW","MWI"], "not in", quote_values=true, convert_to_upper_case=true) }}

--output
UPPER(cost_category_code) not in ('GSC', 'MLE', 'MLW', 'MWI')
{% endraw %}
```

{% enddocs %}

{% docs get_date_key %}
Generates a SQL statement to convert a date column to an integer key in the format YYYYMMDD.

**Args:**

- `column_name` (required): name of column

Below is an example of the expected usage and compiled SQL output:

```sql
{% raw %}
{{ {{ get_date_key('transaction_date') }} }}

--output
CAST(TO_CHAR(NVL(transaction_date, '1900-01-01')::DATE,'YYYYMMDD') AS INT)
{% endraw %}
```

{% enddocs %}

{% docs get_unknown_member_date %}
Returns the default date value (unknown member) for date dimension used in the reporting layer.

Below is an example of the expected usage and compiled SQL output:

```sql
{% raw %}
{{ {{ get_unknown_member_date() }} }}

--output
'1900-01-01'
{% endraw %}
```

{% enddocs %}
